INSERT INTO `__PREFIX__packages`
(`name`, `price`, `duration_type`, `duration_days`, `storage_limit`, `traffic_limit`, `single_file_limit`, `allow_image`, `allow_netdisk`, `allow_api`, `allow_monitor`, `allow_multi_storage`, `allow_share`, `allow_subsite`, `subsite_limit`, `allow_video_preview`, `allow_external_link`, `status`, `sort_order`, `description`, `created_at`, `updated_at`)
VALUES
('免费套餐', 0.00, 'forever', 36500, 1073741824, 5368709120, 10485760, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, '适合个人轻量图片与文件管理，默认新用户套餐。', NOW(), NOW()),
('专业套餐', 29.00, 'month', 30, 10737418240, 107374182400, 104857600, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 10, '提供更大空间、API 上传、多存储线路、分享仓库、服务器运维监控、视频预览和个人分站能力。', NOW(), NOW());

INSERT INTO `__PREFIX__payment_config`
(`name`, `code`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`)
VALUES
('余额支付', 'balance', '{}', 1, 1, NOW(), NOW()),
('支付宝当面付', 'alipay', '{"app_id":"","private_key":"","alipay_public_key":"","sandbox":false,"notify_url":"","timeout_express":"10m"}', 0, 10, NOW(), NOW()),
('微信支付', 'wechat', '{}', 0, 20, NOW(), NOW()),
('易支付', 'epay', '{}', 0, 30, NOW(), NOW()),
('人工充值审核', 'manual', '{}', 1, 40, NOW(), NOW());

INSERT INTO `__PREFIX__coupons`
(`title`, `code`, `discount_type`, `discount_value`, `min_amount`, `package_scope`, `package_ids`, `start_at`, `end_at`, `total_limit`, `user_limit`, `first_order_only`, `status`, `sort_order`, `description`, `created_at`, `updated_at`)
VALUES
('新用户首购立减', 'NEW2026', 'fixed', 5.00, 10.00, 'all', '', NOW(), NULL, 0, 1, 1, 1, 1, '安装后默认营销活动，可用于测试套餐购买和优惠码核销流程。', NOW(), NOW());

INSERT INTO `__PREFIX__storage_drivers`
(`name`, `type`, `access_key`, `secret_key`, `bucket`, `region`, `endpoint`, `domain`, `prefix`, `is_enabled`, `is_default`, `is_public`, `created_at`, `updated_at`)
VALUES
('本地测试存储', 'local', '', '', '', '', '', '', 'uploads/files', 1, 1, 1, NOW(), NOW());

INSERT INTO `__PREFIX__settings`
(`setting_key`, `setting_value`, `created_at`, `updated_at`)
VALUES
('site_name', '__SITE_NAME__', NOW(), NOW()),
('site_public_url', '', NOW(), NOW()),
('site_logo', '', NOW(), NOW()),
('seo_keywords', '图床,网盘,对象存储,服务器状态,宝塔监控', NOW(), NOW()),
('seo_description', '综合型图床、轻量网盘、套餐充值、多对象存储与运营方服务器状态展示平台。', NOW(), NOW()),
('register_enabled', '1', NOW(), NOW()),
('register_email_code_enabled', '0', NOW(), NOW()),
('user_image_upload_enabled', '1', NOW(), NOW()),
('user_netdisk_enabled', '1', NOW(), NOW()),
('guest_image_upload_enabled', '0', NOW(), NOW()),
('guest_image_upload_user_id', '', NOW(), NOW()),
('guest_image_upload_max_size', '5242880', NOW(), NOW()),
('guest_image_upload_daily_ip_limit', '20', NOW(), NOW()),
('upload_max_concurrency', '2', NOW(), NOW()),
('upload_image_batch_limit', '20', NOW(), NOW()),
('upload_file_batch_limit', '10', NOW(), NOW()),
('upload_image_daily_limit', '0', NOW(), NOW()),
('upload_file_daily_limit', '0', NOW(), NOW()),
('security_login_max_attempts', '5', NOW(), NOW()),
('security_login_window_minutes', '10', NOW(), NOW()),
('security_login_lock_minutes', '15', NOW(), NOW()),
('security_email_code_max_per_hour', '5', NOW(), NOW()),
('security_email_code_ip_max_per_hour', '20', NOW(), NOW()),
('default_theme', 'auto', NOW(), NOW()),
('home_template', 'default', NOW(), NOW()),
('file_naming_strategy', 'random', NOW(), NOW()),
('default_free_package_id', '1', NOW(), NOW()),
('api_rate_limit_per_minute', '60', NOW(), NOW()),
('api_rate_limit_per_day', '1000', NOW(), NOW()),
('app_version', '1.0.0', NOW(), NOW()),
('update_manifest_url', '', NOW(), NOW()),
('email_host', '', NOW(), NOW()),
('email_port', '465', NOW(), NOW()),
('email_username', '', NOW(), NOW()),
('email_password', '', NOW(), NOW()),
('email_from', '', NOW(), NOW()),
('alert_webhook_enabled', '0', NOW(), NOW()),
('alert_wecom_webhook', '', NOW(), NOW()),
('alert_dingtalk_webhook', '', NOW(), NOW()),
('alert_dingtalk_secret', '', NOW(), NOW()),
('alert_telegram_bot_token', '', NOW(), NOW()),
('alert_telegram_chat_id', '', NOW(), NOW()),
('ssh_terminal_enabled', '1', NOW(), NOW()),
('ssh_terminal_user_server_limit', '5', NOW(), NOW()),
('ssh_terminal_session_timeout', '600', NOW(), NOW()),
('ssh_terminal_command_timeout', '30', NOW(), NOW()),
('ssh_terminal_gateway_url', '', NOW(), NOW()),
('subsite_enabled', '1', NOW(), NOW()),
('subsite_domain_suffixes', '', NOW(), NOW()),
('subsite_cname_target', '', NOW(), NOW()),
('subsite_https_mode', 'auto', NOW(), NOW()),
('subsite_custom_domain_enabled', '1', NOW(), NOW()),
('subsite_requires_review', '0', NOW(), NOW()),
('subsite_default_limit', '1', NOW(), NOW()),
('subsite_reserved_slugs', 'admin,api,www,cdn,static,status,login,register,assets,uploads,files,share', NOW(), NOW());

INSERT INTO `__PREFIX__announcements`
(`title`, `content`, `category`, `summary`, `is_top`, `show_home`, `status`, `published_at`, `created_at`, `updated_at`)
VALUES
('欢迎使用 __SITE_NAME__', '系统已安装完成。你可以在后台配置对象存储、支付方式、套餐、营销活动与运营方服务器状态监控。', 'platform', '系统安装完成后的默认公告。', 1, 1, 1, NOW(), NOW(), NOW());
