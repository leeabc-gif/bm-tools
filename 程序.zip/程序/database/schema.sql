SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `__PREFIX__users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `nickname` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(120) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `package_id` int(10) unsigned DEFAULT NULL,
  `allow_image_override` tinyint(2) NOT NULL DEFAULT '-1',
  `allow_netdisk_override` tinyint(2) NOT NULL DEFAULT '-1',
  `package_expire_time` datetime DEFAULT NULL,
  `used_storage` bigint(20) unsigned NOT NULL DEFAULT '0',
  `total_storage` bigint(20) unsigned NOT NULL DEFAULT '0',
  `used_traffic` bigint(20) unsigned NOT NULL DEFAULT '0',
  `total_traffic` bigint(20) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified_at` datetime DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `api_token_hash` char(64) DEFAULT NULL,
  `api_allowed_ips` text,
  `frontend_theme_style` varchar(20) NOT NULL DEFAULT '',
  `admin_theme_style` varchar(20) NOT NULL DEFAULT '',
  `server_ops_cron_token` char(64) DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_package` (`package_id`),
  KEY `idx_status` (`status`),
  KEY `idx_api_token_hash` (`api_token_hash`),
  KEY `idx_server_ops_cron_token` (`server_ops_cron_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__email_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(120) NOT NULL,
  `scene` varchar(32) NOT NULL,
  `code` varchar(12) NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT '0',
  `expired_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_scene` (`email`, `scene`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__login_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `account` varchar(120) NOT NULL,
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `is_success` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__security_rate_limits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scope` varchar(40) NOT NULL,
  `identity_hash` char(64) NOT NULL,
  `identity_label` varchar(180) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `attempt_count` int(10) unsigned NOT NULL DEFAULT '0',
  `locked_until` datetime DEFAULT NULL,
  `first_attempt_at` datetime NOT NULL,
  `last_attempt_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scope_identity` (`scope`, `identity_hash`),
  KEY `idx_locked_until` (`locked_until`),
  KEY `idx_last_attempt` (`last_attempt_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `duration_type` enum('month','quarter','year','forever') NOT NULL DEFAULT 'month',
  `duration_days` int(10) unsigned NOT NULL DEFAULT '30',
  `storage_limit` bigint(20) unsigned NOT NULL DEFAULT '0',
  `traffic_limit` bigint(20) unsigned NOT NULL DEFAULT '0',
  `single_file_limit` bigint(20) unsigned NOT NULL DEFAULT '0',
  `allow_image` tinyint(1) NOT NULL DEFAULT '1',
  `allow_netdisk` tinyint(1) NOT NULL DEFAULT '1',
  `allow_api` tinyint(1) NOT NULL DEFAULT '0',
  `allow_monitor` tinyint(1) NOT NULL DEFAULT '0',
  `allow_multi_storage` tinyint(1) NOT NULL DEFAULT '0',
  `allow_share` tinyint(1) NOT NULL DEFAULT '1',
  `allow_subsite` tinyint(1) NOT NULL DEFAULT '0',
  `subsite_limit` int(10) unsigned NOT NULL DEFAULT '1',
  `allow_video_preview` tinyint(1) NOT NULL DEFAULT '0',
  `allow_external_link` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status_sort` (`status`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(64) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` enum('package','recharge') NOT NULL,
  `package_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pay_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(32) NOT NULL DEFAULT 'balance',
  `status` enum('pending','paid','closed','refunded') NOT NULL DEFAULT 'pending',
  `trade_no` varchar(100) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__recharges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(32) NOT NULL DEFAULT 'manual',
  `status` enum('pending','paid','rejected') NOT NULL DEFAULT 'pending',
  `proof` varchar(255) DEFAULT NULL,
  `auditor_id` int(10) unsigned DEFAULT NULL,
  `audit_remark` varchar(255) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  UNIQUE KEY `uk_order` (`order_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__balance_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` enum('recharge','consume','refund','adjust') NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance_before` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance_after` decimal(10,2) NOT NULL DEFAULT '0.00',
  `related_type` varchar(50) DEFAULT NULL,
  `related_id` int(10) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__api_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `app_id` bigint(20) unsigned DEFAULT NULL,
  `endpoint` varchar(100) NOT NULL,
  `method` varchar(10) NOT NULL,
  `ip` varchar(45) NOT NULL DEFAULT '',
  `status_code` int(10) unsigned NOT NULL DEFAULT '200',
  `is_success` tinyint(1) NOT NULL DEFAULT '1',
  `message` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_app_time` (`app_id`, `created_at`),
  KEY `idx_endpoint` (`endpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__api_apps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `token_cipher` varchar(255) DEFAULT NULL,
  `scopes` varchar(255) NOT NULL DEFAULT 'upload,files,delete,quota',
  `allowed_ips` text,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token_hash` (`token_hash`),
  KEY `idx_user_status` (`user_id`, `status`),
  KEY `idx_last_used` (`last_used_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(40) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `detail` text,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_file` (`file_id`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__upload_failures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `scope` enum('image','file','guest','api','unknown') NOT NULL DEFAULT 'unknown',
  `file_name` varchar(255) NOT NULL DEFAULT '',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mime_type` varchar(120) NOT NULL DEFAULT '',
  `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
  `storage_id` int(10) unsigned DEFAULT NULL,
  `storage_type` varchar(32) NOT NULL DEFAULT '',
  `error_type` varchar(60) NOT NULL DEFAULT 'upload',
  `message` varchar(800) NOT NULL DEFAULT '',
  `suggestion` varchar(800) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_scope_time` (`scope`, `created_at`),
  KEY `idx_error_type` (`error_type`, `created_at`),
  KEY `idx_storage` (`storage_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__payment_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `code` varchar(32) NOT NULL,
  `config` text,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `code` varchar(40) NOT NULL,
  `discount_type` enum('fixed','percent') NOT NULL DEFAULT 'fixed',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `min_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `package_scope` enum('all','include','exclude') NOT NULL DEFAULT 'all',
  `package_ids` varchar(500) NOT NULL DEFAULT '',
  `start_at` datetime DEFAULT NULL,
  `end_at` datetime DEFAULT NULL,
  `total_limit` int(10) unsigned NOT NULL DEFAULT '0',
  `user_limit` int(10) unsigned NOT NULL DEFAULT '1',
  `first_order_only` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `description` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_status_time` (`status`, `start_at`, `end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__coupon_redemptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `package_id` int(10) unsigned DEFAULT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `final_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `used_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_coupon` (`coupon_id`),
  KEY `idx_user` (`user_id`),
  UNIQUE KEY `uk_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__redeem_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_no` varchar(40) NOT NULL,
  `title` varchar(120) NOT NULL,
  `type` enum('balance','package') NOT NULL,
  `code_hash` char(64) NOT NULL,
  `code_preview` varchar(32) NOT NULL DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `package_id` int(10) unsigned DEFAULT NULL,
  `duration_days` int(10) unsigned NOT NULL DEFAULT '0',
  `channel` varchar(80) NOT NULL DEFAULT '',
  `expire_at` datetime DEFAULT NULL,
  `status` enum('unused','used','disabled') NOT NULL DEFAULT 'unused',
  `used_by` int(10) unsigned DEFAULT NULL,
  `used_ip` varchar(45) NOT NULL DEFAULT '',
  `used_at` datetime DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `remark` varchar(255) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code_hash` (`code_hash`),
  KEY `idx_batch` (`batch_no`),
  KEY `idx_status_type` (`status`, `type`),
  KEY `idx_used_by` (`used_by`),
  KEY `idx_expire` (`expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__storage_drivers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `type` enum('local','oss','cos','kodo','s3','minio','r2','webdav','bmtools') NOT NULL,
  `access_key` varchar(255) NOT NULL DEFAULT '',
  `secret_key` varchar(255) NOT NULL DEFAULT '',
  `bucket` varchar(120) NOT NULL DEFAULT '',
  `region` varchar(80) NOT NULL DEFAULT '',
  `endpoint` varchar(255) NOT NULL DEFAULT '',
  `domain` varchar(255) NOT NULL DEFAULT '',
  `prefix` varchar(120) NOT NULL DEFAULT '',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_default` (`is_default`),
  KEY `idx_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__storage_backup_policies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `primary_storage_id` int(10) unsigned NOT NULL DEFAULT '0',
  `backup_storage_ids` text,
  `file_scope` enum('all','image','file') NOT NULL DEFAULT 'all',
  `mode` enum('sync','queue') NOT NULL DEFAULT 'sync',
  `failure_strategy` enum('ignore','warn','strict') NOT NULL DEFAULT 'warn',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_enabled_scope` (`is_enabled`, `file_scope`),
  KEY `idx_primary` (`primary_storage_id`),
  KEY `idx_sort` (`sort_order`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_storage_backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` int(10) unsigned NOT NULL,
  `storage_id` int(10) unsigned NOT NULL,
  `policy_id` int(10) unsigned NOT NULL DEFAULT '0',
  `object_key` varchar(500) NOT NULL DEFAULT '',
  `file_url` varchar(800) NOT NULL DEFAULT '',
  `status` enum('pending','success','failed','skipped','deleted') NOT NULL DEFAULT 'pending',
  `error_message` text,
  `attempts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_attempt_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_file_storage_policy` (`file_id`, `storage_id`, `policy_id`),
  KEY `idx_file` (`file_id`),
  KEY `idx_storage` (`storage_id`),
  KEY `idx_status` (`status`, `updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_folders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL,
  `path` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_parent` (`user_id`, `parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `storage_id` int(10) unsigned DEFAULT NULL,
  `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
  `file_type` enum('image','file') NOT NULL DEFAULT 'file',
  `file_name` varchar(180) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_ext` varchar(20) NOT NULL,
  `mime_type` varchar(120) NOT NULL DEFAULT '',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_path` varchar(500) NOT NULL,
  `file_url` varchar(800) NOT NULL,
  `thumbnail_url` varchar(800) DEFAULT NULL,
  `md5` varchar(32) DEFAULT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `download_count` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_storage` (`storage_id`),
  KEY `idx_folder` (`folder_id`),
  KEY `idx_type_created` (`file_type`, `created_at`),
  KEY `idx_md5` (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_shares` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned DEFAULT NULL,
  `folder_id` int(10) unsigned DEFAULT NULL,
  `share_code` varchar(32) NOT NULL,
  `extract_code` varchar(12) DEFAULT NULL,
  `expire_at` datetime DEFAULT NULL,
  `download_limit` int(10) unsigned NOT NULL DEFAULT '0',
  `download_count` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_share_code` (`share_code`),
  KEY `idx_user` (`user_id`),
  KEY `idx_file` (`file_id`),
  KEY `idx_folder` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_share_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `share_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `action` enum('view','download','auth_fail','blocked','expired') NOT NULL DEFAULT 'view',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `referer` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_share_time` (`share_id`, `created_at`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_repositories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(120) NOT NULL,
  `slug` varchar(80) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `cover_image` varchar(800) NOT NULL DEFAULT '',
  `tags` varchar(255) NOT NULL DEFAULT '',
  `access_type` enum('public','password','private') NOT NULL DEFAULT 'public',
  `password_hash` varchar(255) DEFAULT NULL,
  `expire_at` datetime DEFAULT NULL,
  `max_views` int(10) unsigned NOT NULL DEFAULT '0',
  `max_downloads` int(10) unsigned NOT NULL DEFAULT '0',
  `ip_daily_view_limit` int(10) unsigned NOT NULL DEFAULT '0',
  `ip_daily_download_limit` int(10) unsigned NOT NULL DEFAULT '0',
  `allow_download` tinyint(1) NOT NULL DEFAULT '1',
  `show_owner` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `admin_status` tinyint(1) NOT NULL DEFAULT '1',
  `admin_remark` varchar(255) NOT NULL DEFAULT '',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0',
  `download_count` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_repository_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repository_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `visibility` enum('public','private') NOT NULL DEFAULT 'public',
  `note` varchar(255) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_repo_file` (`repository_id`, `file_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_repo_visibility` (`repository_id`, `visibility`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_repository_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `repository_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned DEFAULT NULL,
  `action` enum('view','download','auth_success','auth_fail','blocked','expired') NOT NULL DEFAULT 'view',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `referer` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_repo_time` (`repository_id`, `created_at`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__subsites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `slug` varchar(40) NOT NULL,
  `platform_domain` varchar(180) NOT NULL,
  `custom_domain` varchar(180) NOT NULL DEFAULT '',
  `custom_domain_status` enum('none','pending','verified','failed') NOT NULL DEFAULT 'none',
  `verification_token` varchar(80) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `subtitle` varchar(240) NOT NULL DEFAULT '',
  `logo` varchar(800) NOT NULL DEFAULT '',
  `theme_color` varchar(20) NOT NULL DEFAULT '#2563EB',
  `hero_title` varchar(160) NOT NULL DEFAULT '',
  `hero_description` varchar(360) NOT NULL DEFAULT '',
  `announcement` varchar(500) NOT NULL DEFAULT '',
  `contact_email` varchar(120) NOT NULL DEFAULT '',
  `icp_text` varchar(120) NOT NULL DEFAULT '',
  `status` enum('pending','active','suspended','rejected') NOT NULL DEFAULT 'pending',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0',
  `last_viewed_at` datetime DEFAULT NULL,
  `domain_check_result` text,
  `domain_checked_at` datetime DEFAULT NULL,
  `admin_remark` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  UNIQUE KEY `uk_platform_domain` (`platform_domain`),
  KEY `idx_user_status` (`user_id`, `status`),
  KEY `idx_custom_domain` (`custom_domain`),
  KEY `idx_status_created` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__subsite_access_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subsite_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `host` varchar(180) NOT NULL DEFAULT '',
  `path` varchar(500) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `referer` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_subsite_time` (`subsite_id`, `created_at`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_host_time` (`host`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(10) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `slug` varchar(40) NOT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `avatar` varchar(800) NOT NULL DEFAULT '',
  `status` enum('active','archived','deleted') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_owner_status` (`owner_id`, `status`),
  KEY `idx_status_updated` (`status`, `updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__team_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `role` enum('owner','admin','member','viewer') NOT NULL DEFAULT 'member',
  `title` varchar(80) NOT NULL DEFAULT '',
  `joined_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_team_user` (`team_id`, `user_id`),
  KEY `idx_user_role` (`user_id`, `role`),
  KEY `idx_team_role` (`team_id`, `role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__team_invites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` int(10) unsigned NOT NULL,
  `invited_user_id` int(10) unsigned DEFAULT NULL,
  `invited_email` varchar(120) NOT NULL DEFAULT '',
  `role` enum('admin','member','viewer') NOT NULL DEFAULT 'member',
  `token` char(64) NOT NULL,
  `status` enum('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending',
  `message` varchar(300) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token` (`token`),
  KEY `idx_team_status` (`team_id`, `status`),
  KEY `idx_user_status` (`invited_user_id`, `status`),
  KEY `idx_email_status` (`invited_email`, `status`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__file_recycle_bin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `file_id` int(10) unsigned NOT NULL,
  `snapshot` text,
  `deleted_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_file` (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__monitor_servers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `monitor_type` enum('bt','ssh','agent') NOT NULL DEFAULT 'bt',
  `name` varchar(80) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `panel_url` varchar(255) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `panel_port` int(10) unsigned NOT NULL DEFAULT '8888',
  `server_ip` varchar(45) NOT NULL DEFAULT '',
  `ssh_host` varchar(120) DEFAULT NULL,
  `ssh_port` int(10) unsigned NOT NULL DEFAULT '22',
  `ssh_username` varchar(80) DEFAULT NULL,
  `ssh_auth_type` enum('password','key') NOT NULL DEFAULT 'password',
  `ssh_password` text,
  `ssh_private_key` mediumtext,
  `ssh_key_passphrase` text,
  `agent_url` varchar(255) DEFAULT NULL,
  `agent_token` varchar(120) DEFAULT NULL,
  `group_name` varchar(80) NOT NULL DEFAULT '',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `frequency` int(10) unsigned NOT NULL DEFAULT '60',
  `threshold_config` text,
  `status` enum('online','offline','unknown') NOT NULL DEFAULT 'unknown',
  `last_error` varchar(500) DEFAULT NULL,
  `last_checked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_user_type` (`user_id`, `monitor_type`),
  KEY `idx_status` (`status`),
  KEY `idx_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__monitor_metrics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `server_id` int(10) unsigned NOT NULL,
  `cpu_usage` decimal(5,2) NOT NULL DEFAULT '0.00',
  `memory_total` bigint(20) unsigned NOT NULL DEFAULT '0',
  `memory_used` bigint(20) unsigned NOT NULL DEFAULT '0',
  `memory_usage` decimal(5,2) NOT NULL DEFAULT '0.00',
  `disk_total` bigint(20) unsigned NOT NULL DEFAULT '0',
  `disk_used` bigint(20) unsigned NOT NULL DEFAULT '0',
  `disk_usage` decimal(5,2) NOT NULL DEFAULT '0.00',
  `net_upload` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_download` decimal(12,2) NOT NULL DEFAULT '0.00',
  `load_avg` varchar(80) NOT NULL DEFAULT '',
  `uptime` varchar(120) NOT NULL DEFAULT '',
  `nginx_status` varchar(32) NOT NULL DEFAULT 'unknown',
  `mysql_status` varchar(32) NOT NULL DEFAULT 'unknown',
  `php_status` varchar(32) NOT NULL DEFAULT 'unknown',
  `panel_status` varchar(32) NOT NULL DEFAULT 'unknown',
  `raw_data` mediumtext,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_server_time` (`server_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__monitor_alert_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `server_id` int(10) unsigned DEFAULT NULL,
  `metric` varchar(50) NOT NULL,
  `operator` varchar(10) NOT NULL DEFAULT '>',
  `threshold` decimal(10,2) NOT NULL DEFAULT '0.00',
  `duration` int(10) unsigned NOT NULL DEFAULT '1',
  `notify_email` tinyint(1) NOT NULL DEFAULT '0',
  `notify_site` tinyint(1) NOT NULL DEFAULT '1',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_server` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__monitor_alerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `level` enum('info','warning','danger') NOT NULL DEFAULT 'warning',
  `metric` varchar(50) NOT NULL,
  `title` varchar(120) NOT NULL,
  `content` text,
  `status` enum('unread','read','resolved') NOT NULL DEFAULT 'unread',
  `created_at` datetime NOT NULL,
  `resolved_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_server` (`server_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__server_ssh_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `gateway_url` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `status` enum('issued','connected','closed','expired','failed') NOT NULL DEFAULT 'issued',
  `started_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token_hash` (`token_hash`),
  KEY `idx_user_server` (`user_id`, `server_id`),
  KEY `idx_status_time` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__server_command_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `session_id` bigint(20) unsigned DEFAULT NULL,
  `command` text NOT NULL,
  `output_summary` mediumtext,
  `exit_status` int(11) DEFAULT NULL,
  `risk_level` enum('normal','warning','danger') NOT NULL DEFAULT 'normal',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`, `created_at`),
  KEY `idx_server_time` (`server_id`, `created_at`),
  KEY `idx_risk` (`risk_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__server_monitor_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `title` varchar(120) NOT NULL DEFAULT '',
  `token` varchar(64) NOT NULL,
  `visibility` enum('private','public','password') NOT NULL DEFAULT 'private',
  `password_hash` varchar(255) DEFAULT NULL,
  `show_metrics` tinyint(1) NOT NULL DEFAULT '1',
  `show_services` tinyint(1) NOT NULL DEFAULT '1',
  `expires_at` datetime DEFAULT NULL,
  `view_count` int(10) unsigned NOT NULL DEFAULT '0',
  `last_viewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token` (`token`),
  UNIQUE KEY `uk_server` (`server_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_visibility` (`visibility`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__server_service_checks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `type` enum('http','tcp','ssl') NOT NULL DEFAULT 'http',
  `name` varchar(120) NOT NULL,
  `target` varchar(500) NOT NULL,
  `port` int(10) unsigned NOT NULL DEFAULT '0',
  `method` varchar(8) NOT NULL DEFAULT 'HEAD',
  `expected_status` varchar(80) NOT NULL DEFAULT '200-399',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `timeout_seconds` int(10) unsigned NOT NULL DEFAULT '5',
  `frequency` int(10) unsigned NOT NULL DEFAULT '300',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `status` enum('up','down','unknown') NOT NULL DEFAULT 'unknown',
  `response_time_ms` int(10) unsigned NOT NULL DEFAULT '0',
  `status_code` int(10) unsigned DEFAULT NULL,
  `ssl_expires_at` datetime DEFAULT NULL,
  `last_error` varchar(500) NOT NULL DEFAULT '',
  `last_checked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_server` (`user_id`, `server_id`),
  KEY `idx_enabled_due` (`is_enabled`, `last_checked_at`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__server_service_check_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `check_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `status` enum('up','down') NOT NULL DEFAULT 'down',
  `response_time_ms` int(10) unsigned NOT NULL DEFAULT '0',
  `status_code` int(10) unsigned DEFAULT NULL,
  `ssl_expires_at` datetime DEFAULT NULL,
  `message` varchar(500) NOT NULL DEFAULT '',
  `checked_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_check_time` (`check_id`, `checked_at`),
  KEY `idx_server_time` (`server_id`, `checked_at`),
  KEY `idx_user_time` (`user_id`, `checked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `content` mediumtext NOT NULL,
  `category` varchar(40) NOT NULL DEFAULT 'platform',
  `summary` varchar(300) NOT NULL DEFAULT '',
  `cover_image` varchar(255) NOT NULL DEFAULT '',
  `tags` varchar(255) NOT NULL DEFAULT '',
  `content_format` varchar(20) NOT NULL DEFAULT 'html',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0',
  `is_top` tinyint(1) NOT NULL DEFAULT '0',
  `show_home` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category`, `status`, `published_at`),
  KEY `idx_status_pub` (`status`, `published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'system',
  `title` varchar(150) NOT NULL,
  `content` text,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`, `is_read`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `__PREFIX__admin_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `action` varchar(120) NOT NULL,
  `target_type` varchar(60) DEFAULT NULL,
  `target_id` int(10) unsigned DEFAULT NULL,
  `ip` varchar(45) NOT NULL DEFAULT '',
  `detail` text,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin` (`admin_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
