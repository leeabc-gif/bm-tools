-- BM TOOLS SSH monitor upgrade for existing installations.
-- The updater replaces __PREFIX__ with the configured table prefix before execution.
-- If you run this file manually, replace __PREFIX__ with your own table prefix first.

ALTER TABLE `__PREFIX__monitor_servers`
  ADD COLUMN `monitor_type` enum('bt','ssh','agent') NOT NULL DEFAULT 'bt' AFTER `user_id`,
  ADD COLUMN `ssh_host` varchar(120) DEFAULT NULL AFTER `server_ip`,
  ADD COLUMN `ssh_port` int(10) unsigned NOT NULL DEFAULT '22' AFTER `ssh_host`,
  ADD COLUMN `ssh_username` varchar(80) DEFAULT NULL AFTER `ssh_port`,
  ADD COLUMN `ssh_auth_type` enum('password','key') NOT NULL DEFAULT 'password' AFTER `ssh_username`,
  ADD COLUMN `ssh_password` text AFTER `ssh_auth_type`,
  ADD COLUMN `ssh_private_key` mediumtext AFTER `ssh_password`,
  ADD COLUMN `ssh_key_passphrase` text AFTER `ssh_private_key`,
  ADD COLUMN `agent_url` varchar(255) DEFAULT NULL AFTER `ssh_key_passphrase`,
  ADD COLUMN `agent_token` varchar(120) DEFAULT NULL AFTER `agent_url`;
