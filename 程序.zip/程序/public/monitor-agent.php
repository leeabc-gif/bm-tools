<?php
// BM TOOLS lightweight monitor agent.
// Put this file on the monitored server and set a strong token below.

$token = 'CHANGE_THIS_TOKEN';
$requestToken = isset($_GET['token']) ? (string) $_GET['token'] : '';
if ($token === 'CHANGE_THIS_TOKEN' || strlen($token) < 32 || preg_match('/[\x00-\x1F\x7F]/', $token) || !hash_equals($token, $requestToken)) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Forbidden'], JSON_UNESCAPED_UNICODE);
    exit;
}

function bm_agent_read($path)
{
    return is_readable($path) ? file_get_contents($path) : '';
}

function bm_agent_cpu_parts($line)
{
    $parts = preg_split('/\s+/', trim((string) $line));
    if (!$parts || $parts[0] !== 'cpu') {
        return ['total' => 0, 'idle' => 0];
    }
    $values = array_map('floatval', array_slice($parts, 1));
    return [
        'total' => array_sum($values),
        'idle' => (isset($values[3]) ? $values[3] : 0) + (isset($values[4]) ? $values[4] : 0),
    ];
}

function bm_agent_cpu_usage()
{
    $line1 = strtok(bm_agent_read('/proc/stat'), "\n");
    usleep(300000);
    $line2 = strtok(bm_agent_read('/proc/stat'), "\n");
    $a = bm_agent_cpu_parts($line1);
    $b = bm_agent_cpu_parts($line2);
    $total = $b['total'] - $a['total'];
    $idle = $b['idle'] - $a['idle'];
    return $total > 0 ? round(($total - $idle) / $total * 100, 2) : 0;
}

function bm_agent_memory()
{
    $rows = [];
    foreach (explode("\n", bm_agent_read('/proc/meminfo')) as $line) {
        if (preg_match('/^([A-Za-z_]+):\s+(\d+)/', $line, $m)) {
            $rows[$m[1]] = (float) $m[2] * 1024;
        }
    }
    $total = isset($rows['MemTotal']) ? $rows['MemTotal'] : 0;
    $available = isset($rows['MemAvailable']) ? $rows['MemAvailable'] : (isset($rows['MemFree']) ? $rows['MemFree'] : 0);
    $used = max(0, $total - $available);
    return [
        'total' => (int) $total,
        'used' => (int) $used,
        'usage' => $total > 0 ? round($used / $total * 100, 2) : 0,
    ];
}

function bm_agent_disks()
{
    $rows = [];
    if (function_exists('shell_exec')) {
        $df = shell_exec('df -B1 -P 2>/dev/null');
        foreach (explode("\n", trim((string) $df)) as $index => $line) {
            if ($index === 0 || trim($line) === '') {
                continue;
            }
            $parts = preg_split('/\s+/', trim($line));
            if (count($parts) >= 6) {
                $rows[] = [
                    'path' => $parts[5],
                    'total' => (int) $parts[1],
                    'used' => (int) $parts[2],
                ];
            }
        }
    }
    if (!$rows) {
        $path = DIRECTORY_SEPARATOR;
        $total = @disk_total_space($path);
        $free = @disk_free_space($path);
        $rows[] = [
            'path' => $path,
            'total' => (int) $total,
            'used' => (int) max(0, (float) $total - (float) $free),
        ];
    }
    return $rows;
}

function bm_agent_network()
{
    $rows = [];
    foreach (explode("\n", bm_agent_read('/proc/net/dev')) as $line) {
        if (strpos($line, ':') === false) {
            continue;
        }
        list($iface, $data) = explode(':', $line, 2);
        $iface = trim($iface);
        $parts = preg_split('/\s+/', trim($data));
        if ($iface === 'lo' || count($parts) < 16) {
            continue;
        }
        $rows[] = [
            'iface' => $iface,
            'rx' => (float) $parts[0],
            'tx' => (float) $parts[8],
        ];
    }
    return $rows;
}

function bm_agent_uptime()
{
    $uptime = trim(bm_agent_read('/proc/uptime'));
    if ($uptime === '') {
        return '';
    }
    $seconds = (int) floor((float) strtok($uptime, ' '));
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    return $days . 'd ' . $hours . 'h ' . $minutes . 'm';
}

$memory = bm_agent_memory();
$disks = bm_agent_disks();
$diskTotal = 0;
$diskUsed = 0;
foreach ($disks as $disk) {
    $diskTotal += (float) $disk['total'];
    $diskUsed += (float) $disk['used'];
}

$payload = [
    'success' => true,
    'source' => 'bmtools-agent',
    'time' => date('Y-m-d H:i:s'),
    'hostname' => php_uname('n'),
    'os' => php_uname('s') . ' ' . php_uname('r'),
    'cpu_usage' => bm_agent_cpu_usage(),
    'memory_total' => $memory['total'],
    'memory_used' => $memory['used'],
    'memory_usage' => $memory['usage'],
    'disk_total' => (int) $diskTotal,
    'disk_used' => (int) $diskUsed,
    'disk_usage' => $diskTotal > 0 ? round($diskUsed / $diskTotal * 100, 2) : 0,
    'disk' => $disks,
    'network' => bm_agent_network(),
    'load_avg' => is_readable('/proc/loadavg') ? trim(file_get_contents('/proc/loadavg')) : '',
    'uptime' => bm_agent_uptime(),
    'php_version' => PHP_VERSION,
];

header('Content-Type: application/json; charset=utf-8');
echo json_encode($payload, JSON_UNESCAPED_UNICODE);
