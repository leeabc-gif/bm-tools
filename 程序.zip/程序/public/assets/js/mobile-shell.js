(function () {
    var lockedScrollY = 0;
    var previousFocus = null;
    var lastMenuEventAt = 0;
    var lastTouchMenuAt = 0;
    var menuOpenedAt = 0;
    var suppressMenuClickUntil = 0;

    function qs(selector, root) {
        return (root || document).querySelector(selector);
    }

    function qsa(selector, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(selector));
    }

    function setMenuExpanded(open) {
        qsa('[data-mobile-menu-open]').forEach(function (button) {
            button.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    function openMenu() {
        var sheet = qs('[data-mobile-menu-sheet]');
        if (!sheet) return;
        if (document.body.classList.contains('m-menu-open')) return;
        lockedScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
        previousFocus = document.activeElement;
        document.documentElement.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.classList.add('m-menu-open');
        document.body.style.top = '-' + lockedScrollY + 'px';
        document.body.style.left = '0';
        document.body.style.right = '0';
        document.body.style.width = '100%';
        sheet.setAttribute('aria-hidden', 'false');
        menuOpenedAt = Date.now();
        suppressMenuClickUntil = menuOpenedAt + 520;
        setMenuExpanded(true);
    }

    function closeMenu(force) {
        var sheet = qs('[data-mobile-menu-sheet]');
        if (!document.body.classList.contains('m-menu-open')) return;
        if (!force && menuOpenedAt && Date.now() - menuOpenedAt < 260) return;
        document.body.classList.remove('m-menu-open');
        document.documentElement.style.overflow = '';
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.left = '';
        document.body.style.right = '';
        document.body.style.width = '';
        if (sheet) sheet.setAttribute('aria-hidden', 'true');
        window.scrollTo(0, lockedScrollY || 0);
        if (previousFocus && typeof previousFocus.focus === 'function') {
            try {
                previousFocus.focus({ preventScroll: true });
            } catch (e) {}
        }
        previousFocus = null;
        menuOpenedAt = 0;
        suppressMenuClickUntil = Date.now() + 160;
        setMenuExpanded(false);
    }

    function toggleMenu() {
        if (document.body.classList.contains('m-menu-open')) {
            closeMenu(true);
            return;
        }
        openMenu();
    }

    function closest(target, selector) {
        if (!target) return null;
        if (target.closest) return target.closest(selector);
        while (target && target.nodeType === 1) {
            if (target.matches && target.matches(selector)) return target;
            target = target.parentElement;
        }
        return null;
    }

    function isTouchLikeEvent(event) {
        return event && (event.type === 'touchend' || (event.type === 'pointerup' && event.pointerType && event.pointerType !== 'mouse'));
    }

    function allowMenuEvent(event) {
        var now = Date.now();
        if (event && event.type === 'click' && now - lastTouchMenuAt < 700) return false;
        if (event && event.type === 'click' && now < suppressMenuClickUntil) return false;
        if (isTouchLikeEvent(event)) lastTouchMenuAt = now;
        if (now - lastMenuEventAt < 180) return false;
        lastMenuEventAt = now;
        return true;
    }

    function handleMenuEvent(event) {
        var opener = closest(event.target, '[data-mobile-menu-open]');
        if (opener) {
            if (opener.tagName === 'A' && event.metaKey) return;
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            if (!allowMenuEvent(event)) return;
            toggleMenu();
            return;
        }

        if (closest(event.target, '[data-mobile-menu-close]')) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            if (!allowMenuEvent(event)) return;
            closeMenu(true);
            return;
        }

        var sheet = qs('[data-mobile-menu-sheet]');
        if (sheet && document.body.classList.contains('m-menu-open') && event.target === sheet) {
            event.preventDefault();
            closeMenu(true);
        }
    }

    function normalizeMenuText(value) {
        return String(value || '').replace(/\s+/g, '').toLowerCase();
    }

    function filterMobileMenu(value) {
        var sheet = qs('[data-mobile-menu-sheet]');
        if (!sheet) return;
        var keyword = normalizeMenuText(value);
        var visible = 0;
        qsa('.m-menu-groups section', sheet).forEach(function (group) {
            var groupVisible = false;
            qsa('[data-mobile-menu-item]', group).forEach(function (item) {
                var matched = !keyword || normalizeMenuText(item.textContent).indexOf(keyword) !== -1;
                item.hidden = !matched;
                if (matched) {
                    groupVisible = true;
                    visible += 1;
                }
            });
            group.hidden = !groupVisible;
        });
        var empty = qs('.m-menu-empty', sheet);
        if (empty) empty.hidden = visible > 0;
    }

    function iconRefresh() {
        if (window.lucide && typeof window.lucide.createIcons === 'function') {
            window.lucide.createIcons();
            return;
        }
        qsa('[data-lucide]').forEach(function (node) {
            if (node.querySelector('svg')) return;
            node.classList.add('lucide', 'lucide-fallback');
            node.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"></circle><path d="M12 8v8M8 12h8"></path></svg>';
        });
    }

    function ensureResultBox(form) {
        var box = qs('.m-upload-result', form);
        if (!box) {
            box = document.createElement('div');
            box.className = 'm-upload-result';
            box.setAttribute('aria-live', 'polite');
            form.appendChild(box);
        }
        return box;
    }

    function setButtonLoading(button, loading) {
        if (!button) return;
        if (!button.dataset.originalText) {
            button.dataset.originalText = button.textContent || '提交';
        }
        button.disabled = loading;
        button.textContent = loading ? '处理中...' : button.dataset.originalText;
    }

    function formatBytes(value) {
        var size = Number(value || 0);
        if (!size || size < 0) return '0 B';
        var units = ['B', 'KB', 'MB', 'GB', 'TB'];
        var index = 0;
        while (size >= 1024 && index < units.length - 1) {
            size /= 1024;
            index += 1;
        }
        return (index === 0 ? size : size.toFixed(size >= 10 ? 1 : 2)) + ' ' + units[index];
    }

    function copyText(text, button) {
        if (!text) return;
        var done = function () {
            if (!button) return;
            var old = button.textContent;
            button.textContent = '已复制';
            window.setTimeout(function () {
                button.textContent = old || '复制';
            }, 1200);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done).catch(function () {});
            return;
        }
        var input = document.createElement('textarea');
        input.value = text;
        input.setAttribute('readonly', 'readonly');
        input.style.position = 'fixed';
        input.style.left = '-9999px';
        document.body.appendChild(input);
        input.select();
        try {
            document.execCommand('copy');
            done();
        } catch (e) {}
        document.body.removeChild(input);
    }

    function addCopyRow(parent, label, value) {
        if (!value) return;
        var row = document.createElement('div');
        row.className = 'm-copy-row';
        var text = document.createElement('span');
        text.textContent = label + '：' + value;
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = '复制';
        button.addEventListener('click', function () {
            copyText(value, button);
        });
        row.appendChild(text);
        row.appendChild(button);
        parent.appendChild(row);
    }

    function uploadFieldName(form) {
        var fileInput = qs('input[type="file"]', form);
        if (!fileInput) return 'files[]';
        return fileInput.getAttribute('name') || 'files[]';
    }

    function uploadScopeLabel(form) {
        var name = uploadFieldName(form);
        var action = form.getAttribute('action') || '';
        if (name.indexOf('images') !== -1 || action.indexOf('/files/upload') !== -1) {
            return '图片';
        }
        return '文件';
    }

    function uploadScopeKey(form) {
        return uploadScopeLabel(form) === '图片' ? 'image' : 'file';
    }

    function uploadLimits() {
        var raw = window.SKY_UPLOAD_LIMITS || {};
        return {
            imageBatch: Math.max(1, parseInt(raw.imageBatch || 20, 10) || 20),
            fileBatch: Math.max(1, parseInt(raw.fileBatch || 10, 10) || 10),
            imageDaily: Math.max(0, parseInt(raw.imageDaily || 0, 10) || 0),
            fileDaily: Math.max(0, parseInt(raw.fileDaily || 0, 10) || 0),
            singleFileLimit: Math.max(0, parseInt(raw.singleFileLimit || 0, 10) || 0),
            storageRemaining: Math.max(0, parseInt(raw.storageRemaining || 0, 10) || 0),
            storageLimited: !!raw.storageLimited
        };
    }

    function validateUploadSelection(form, files) {
        var scope = uploadScopeKey(form);
        var limits = uploadLimits();
        var label = scope === 'image' ? '图片' : '文件';
        var batchLimit = scope === 'image' ? limits.imageBatch : limits.fileBatch;
        var dailyLimit = scope === 'image' ? limits.imageDaily : limits.fileDaily;
        var usedToday = scope === 'image' ? Math.max(0, parseInt((window.SKY_UPLOAD_LIMITS || {}).imageUsedToday || 0, 10) || 0) : Math.max(0, parseInt((window.SKY_UPLOAD_LIMITS || {}).fileUsedToday || 0, 10) || 0);
        if (batchLimit > 0 && files.length > batchLimit) {
            return label + '单次最多上传 ' + batchLimit + ' 个，当前选择 ' + files.length + ' 个，请减少后再试。';
        }
        if (dailyLimit > 0 && usedToday + files.length > dailyLimit) {
            return '今日' + label + '上传剩余额度不足：已上传 ' + usedToday + ' 个，最多 ' + dailyLimit + ' 个。';
        }
        var totalSize = 0;
        for (var i = 0; i < files.length; i += 1) {
            totalSize += files[i].size || 0;
            if ((files[i].size || 0) <= 0) {
                return '文件“' + (files[i].name || '未命名') + '”大小为 0，不能上传。';
            }
            if (limits.singleFileLimit > 0 && (files[i].size || 0) > limits.singleFileLimit) {
                return '文件“' + (files[i].name || '未命名') + '”超过单文件限制 ' + formatBytes(limits.singleFileLimit) + '。';
            }
        }
        if (limits.storageLimited && totalSize > limits.storageRemaining) {
            return '剩余空间不足：本次选择 ' + formatBytes(totalSize) + '，当前剩余 ' + formatBytes(limits.storageRemaining) + '。';
        }
        return '';
    }

    function ensureUploadPanel(form) {
        var panel = qs('.m-upload-panel', form);
        if (panel) return panel;

        panel = document.createElement('div');
        panel.className = 'm-upload-panel';
        panel.setAttribute('aria-live', 'polite');
        panel.innerHTML = [
            '<div class="m-upload-orbit" aria-hidden="true"><span></span><span></span><span></span></div>',
            '<div class="m-upload-panel-head"><strong>等待上传</strong><span>0%</span></div>',
            '<div class="m-upload-progress"><i></i></div>',
            '<div class="m-upload-panel-meta">选择文件后会显示上传状态。</div>',
            '<div class="m-upload-file-list"></div>',
            '<div class="m-upload-panel-actions" hidden></div>'
        ].join('');
        form.appendChild(panel);
        return panel;
    }

    function setUploadPanel(panel, percent, title, meta) {
        percent = Math.max(0, Math.min(100, Math.round(percent || 0)));
        var titleNode = qs('.m-upload-panel-head strong', panel);
        var percentNode = qs('.m-upload-panel-head span', panel);
        var bar = qs('.m-upload-progress i', panel);
        var metaNode = qs('.m-upload-panel-meta', panel);
        if (titleNode) titleNode.textContent = title || '正在上传';
        if (percentNode) percentNode.textContent = percent + '%';
        if (bar) bar.style.width = percent + '%';
        if (metaNode && meta !== undefined) metaNode.textContent = meta;
    }

    function setUploadState(panel, state) {
        panel.classList.remove('is-running', 'is-complete', 'has-error');
        if (state) panel.classList.add(state);
    }

    function uploadRows(panel, files) {
        var list = qs('.m-upload-file-list', panel);
        if (!list) return [];
        list.innerHTML = '';
        return files.map(function (file) {
            var row = document.createElement('article');
            row.className = 'm-upload-file-row is-waiting';
            row.innerHTML = '<div class="m-upload-file-main"><b></b><small></small></div><em>等待</em><div class="m-upload-file-bar"><i></i></div><div class="m-upload-file-message">等待开始上传</div>';
            qs('b', row).textContent = file.name || '文件';
            qs('small', row).textContent = formatBytes(file.size || 0);
            list.appendChild(row);
            return row;
        });
    }

    function selectedUploadFiles(form) {
        var files = [];
        qsa('input[type="file"]', form).forEach(function (input) {
            if (!input.files) return;
            Array.prototype.slice.call(input.files).forEach(function (file) {
                files.push(file);
            });
        });
        return files;
    }

    function renderUploadPreview(form) {
        var files = selectedUploadFiles(form);
        var panel = ensureUploadPanel(form);
        var actions = qs('.m-upload-panel-actions', panel);
        var submit = form.querySelector('button[type="submit"]');
        setUploadState(panel, '');
        var resultBox = qs('.m-upload-result', form);
        if (resultBox) resultBox.remove();
        if (!files.length) {
            setUploadPanel(panel, 0, '等待上传', '选择文件后会显示上传状态。');
            if (submit) submit.disabled = false;
            var list = qs('.m-upload-file-list', panel);
            if (list) list.innerHTML = '';
            if (actions) {
                actions.hidden = true;
                actions.innerHTML = '';
            }
            return;
        }
        var validationMessage = validateUploadSelection(form, files);
        uploadRows(panel, files);
        setUploadPanel(panel, 0, '已选择 ' + files.length + ' 个' + uploadScopeLabel(form), validationMessage || '确认无误后点击上传，系统会逐个处理并显示进度。');
        panel.classList.toggle('has-error', validationMessage !== '');
        if (submit) submit.disabled = validationMessage !== '';
        if (actions) {
            actions.hidden = false;
            actions.innerHTML = '';
            var clear = document.createElement('button');
            clear.type = 'button';
            clear.className = 'm-button ghost';
            clear.textContent = '重新选择';
            clear.addEventListener('click', function () {
                qsa('input[type="file"]', form).forEach(function (input) {
                    input.value = '';
                });
                renderUploadPreview(form);
            });
            actions.appendChild(clear);
        }
        iconRefresh();
    }

    function setUploadRow(row, state, label, percent, message) {
        row.className = 'm-upload-file-row ' + state;
        var stateNode = qs('em', row);
        var bar = qs('.m-upload-file-bar i', row);
        var msg = qs('.m-upload-file-message', row);
        if (stateNode) stateNode.textContent = label;
        if (bar) bar.style.width = Math.max(0, Math.min(100, Math.round(percent || 0))) + '%';
        if (msg) msg.textContent = message || '';
    }

    function addUploadRowActions(row, file) {
        var message = qs('.m-upload-file-message', row);
        if (!message || !file) return;
        var url = file.url || file.file_url || '';
        if (!url) {
            message.textContent = '上传完成';
            return;
        }
        message.innerHTML = '';
        var open = document.createElement('a');
        open.href = url;
        open.target = '_blank';
        open.rel = 'noopener';
        open.textContent = '打开';
        var copy = document.createElement('button');
        copy.type = 'button';
        copy.textContent = '复制链接';
        copy.addEventListener('click', function () {
            copyText(url, copy);
        });
        message.appendChild(open);
        message.appendChild(copy);
    }

    function singleFilePayload(form, fieldName, file) {
        var data = new FormData();
        qsa('input, select, textarea', form).forEach(function (node) {
            if (!node.name || node.type === 'file') return;
            if ((node.type === 'checkbox' || node.type === 'radio') && !node.checked) return;
            data.append(node.name, node.value);
        });
        data.set('ajax_upload', '1');
        data.append(fieldName, file, file.name);
        return data;
    }

    function parseUploadResponse(xhr) {
        var text = xhr.responseText || '';
        try {
            return text ? JSON.parse(text) : {};
        } catch (e) {
            var snippet = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 140);
            var statusText = xhr.status ? 'HTTP ' + xhr.status : '网络异常';
            var hint = xhr.status >= 200 && xhr.status < 300
                ? '服务器返回内容无法识别，请检查接口是否输出了 PHP 报错或 HTML。'
                : '服务器处理上传时出错，请检查对象存储配置、PHP 错误日志和上传临时目录。';
            return {
                success: false,
                status: xhr.status || 0,
                message: statusText + '：' + hint + (snippet ? ' 返回片段：' + snippet : '')
            };
        }
    }

    function uploadDiagnosticText(data) {
        if (!data) return '';
        var parts = [];
        if (data.failed_stage_label || data.failed_stage) {
            parts.push('不通步骤：' + (data.failed_stage_label || data.failed_stage));
        }
        if (data.failed_stage_hint) {
            parts.push('原因方向：' + data.failed_stage_hint);
        }
        if (data.suggestion) {
            parts.push('建议处理：' + data.suggestion);
        }
        return parts.join(' ');
    }

    function showUploadNotice(message, type) {
        var root = qs('.m-upload-toast-root');
        if (!root) {
            root = document.createElement('div');
            root.className = 'm-upload-toast-root';
            document.body.appendChild(root);
        }
        var item = document.createElement('div');
        item.className = 'm-upload-toast ' + (type || 'info');
        item.textContent = message;
        root.appendChild(item);
        window.setTimeout(function () {
            item.classList.add('is-out');
            window.setTimeout(function () {
                if (item.parentNode) item.parentNode.removeChild(item);
            }, 260);
        }, 2400);
    }

    function renderUploadResult(form, data) {
        var box = ensureResultBox(form);
        var success = !!(data && data.success);
        var files = data && Array.isArray(data.files) ? data.files : [];
        box.className = 'm-upload-result ' + (success ? 'success' : 'error');
        box.innerHTML = '';

        var title = document.createElement('strong');
        title.textContent = success ? (data.message || '上传成功') : (data && data.message ? data.message : '上传失败');
        box.appendChild(title);

        if (success && files.length) {
            var list = document.createElement('div');
            list.className = 'm-upload-links';
            files.slice(0, 12).forEach(function (file) {
                var item = document.createElement('article');
                var name = document.createElement('b');
                name.textContent = file.name || file.original_name || '文件';
                var meta = document.createElement('small');
                meta.textContent = formatBytes(file.size || file.file_size || 0);
                item.appendChild(name);
                item.appendChild(meta);
                addCopyRow(item, '链接', file.url || file.file_url || '');
                addCopyRow(item, 'Markdown', file.markdown || '');
                addCopyRow(item, 'HTML', file.html || '');
                list.appendChild(item);
            });
            box.appendChild(list);
        }

        if (success) {
            var actions = document.createElement('div');
            actions.className = 'm-inline-actions';
            var refresh = document.createElement('button');
            refresh.type = 'button';
            refresh.className = 'm-button ghost';
            refresh.textContent = '刷新列表';
            refresh.addEventListener('click', function () {
                window.location.reload();
            });
            actions.appendChild(refresh);
            box.appendChild(actions);
        } else if (data) {
            var detail = uploadDiagnosticText(data);
            if (detail) {
                var hint = document.createElement('small');
                hint.className = 'm-upload-error-detail';
                hint.textContent = detail;
                box.appendChild(hint);
            }
        }
    }

    function initUploadForms() {
        qsa('.m-upload').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!window.FormData || !window.XMLHttpRequest) return;
                event.preventDefault();

                var button = form.querySelector('button[type="submit"]');
                var files = selectedUploadFiles(form);
                if (!files.length) {
                    renderUploadResult(form, { success: false, message: '请先选择要上传的文件。' });
                    showUploadNotice('请先选择要上传的文件。', 'warn');
                    return;
                }
                var validationMessage = validateUploadSelection(form, files);
                if (validationMessage) {
                    renderUploadResult(form, { success: false, message: validationMessage });
                    renderUploadPreview(form);
                    showUploadNotice(validationMessage, 'warn');
                    return;
                }

                var fieldName = uploadFieldName(form);
                var scopeLabel = uploadScopeLabel(form);
                var panel = ensureUploadPanel(form);
                var rows = [];
                var resultBox = qs('.m-upload-result', form);
                if (resultBox) resultBox.remove();
                var state = null;

                function resetUploadState(nextFiles) {
                    files = nextFiles;
                    rows = uploadRows(panel, files);
                    state = {
                        index: 0,
                        success: 0,
                        failed: 0,
                        uploadedBytes: 0,
                        activeLoaded: 0,
                        totalBytes: files.reduce(function (sum, file) { return sum + (file.size || 0); }, 0),
                        files: [],
                        failedItems: [],
                        cancelled: false,
                        xhr: null
                    };
                    setUploadState(panel, 'is-running');
                    setUploadPanel(panel, 1, '准备上传', '共 ' + files.length + ' 个' + scopeLabel + '，正在建立上传队列。');
                    setButtonLoading(button, true);
                    var runningActions = qs('.m-upload-panel-actions', panel);
                    if (runningActions) {
                        runningActions.hidden = false;
                        runningActions.innerHTML = '';
                        var cancel = document.createElement('button');
                        cancel.type = 'button';
                        cancel.className = 'm-button danger';
                        cancel.textContent = '取消上传';
                        cancel.addEventListener('click', function () {
                            if (state.cancelled) return;
                            state.cancelled = true;
                            if (state.xhr) {
                                try { state.xhr.abort(); } catch (e) {}
                            }
                            showUploadNotice('已取消上传。', 'warn');
                        });
                        runningActions.appendChild(cancel);
                    }
                }

                resetUploadState(files);
                showUploadNotice('开始上传 ' + files.length + ' 个' + scopeLabel + '。', 'info');

                function updateSummary(title) {
                    var done = state.success + state.failed;
                    var percent = state.totalBytes > 0
                        ? Math.round((state.uploadedBytes + state.activeLoaded) / state.totalBytes * 100)
                        : Math.round(done / files.length * 100);
                    var pending = Math.max(0, files.length - done - (state.index < files.length ? 1 : 0));
                    setUploadPanel(panel, percent, title || '正在上传', '成功 ' + state.success + ' 个，失败 ' + state.failed + ' 个，队列中 ' + pending + ' 个。');
                }

                function finish() {
                    setButtonLoading(button, false);
                    var actions = qs('.m-upload-panel-actions', panel);
                    if (actions) {
                        actions.hidden = false;
                        actions.innerHTML = '';
                        var refresh = document.createElement('button');
                        refresh.type = 'button';
                        refresh.className = 'm-button ghost';
                        refresh.textContent = '刷新列表';
                        refresh.addEventListener('click', function () { window.location.reload(); });
                        var clear = document.createElement('button');
                        clear.type = 'button';
                        clear.className = 'm-button ghost';
                        clear.textContent = '清空状态';
                        clear.addEventListener('click', function () {
                            panel.remove();
                        });
                        if (!state.cancelled && state.failedItems.length) {
                            var retry = document.createElement('button');
                            retry.type = 'button';
                            retry.className = 'm-button';
                            retry.textContent = '重试失败文件';
                            retry.addEventListener('click', function () {
                                var retryFiles = state.failedItems.map(function (item) { return item.file; });
                                if (!retryFiles.length) return;
                                var retryResult = qs('.m-upload-result', form);
                                if (retryResult) retryResult.remove();
                                resetUploadState(retryFiles);
                                showUploadNotice('开始重试失败文件。', 'info');
                                uploadNext();
                            });
                            actions.appendChild(retry);
                        }
                        actions.appendChild(refresh);
                        actions.appendChild(clear);
                    }
                    if (state.cancelled) {
                        setUploadState(panel, 'has-error');
                        setUploadPanel(panel, state.success > 0 ? Math.round(state.success / files.length * 100) : 0, '上传已取消', '已成功 ' + state.success + ' 个，剩余文件未继续上传。');
                        renderUploadResult(form, { success: false, message: '上传已取消，已成功 ' + state.success + ' 个。' });
                        iconRefresh();
                        return;
                    }
                    if (state.failed > 0) {
                        setUploadState(panel, 'has-error');
                        setUploadPanel(panel, state.success > 0 ? Math.max(1, Math.round(state.success / files.length * 100)) : 0, '部分上传失败', '成功 ' + state.success + ' 个，失败 ' + state.failed + ' 个。请查看每个文件的错误提示。');
                        renderUploadResult(form, { success: false, message: '有 ' + state.failed + ' 个' + scopeLabel + '上传失败。' });
                        showUploadNotice('有文件上传失败，请查看原因。', 'error');
                    } else {
                        setUploadState(panel, 'is-complete');
                        setUploadPanel(panel, 100, '上传完成', '全部 ' + state.success + ' 个' + scopeLabel + '已上传完成。');
                        renderUploadResult(form, { success: true, message: '上传成功', files: state.files });
                        form.reset();
                        showUploadNotice(scopeLabel + '上传完成。', 'success');
                        window.setTimeout(function () {
                            if (document.body.contains(panel)) window.location.reload();
                        }, 2800);
                    }
                    iconRefresh();
                }

                function uploadNext() {
                    if (state.cancelled || state.index >= files.length) {
                        finish();
                        return;
                    }
                    var index = state.index;
                    var file = files[index];
                    var row = rows[index];
                    state.index += 1;
                    state.activeLoaded = 0;
                    setUploadRow(row, 'is-running', '上传中', 8, '正在连接服务器...');
                    updateSummary('正在上传 ' + (index + 1) + '/' + files.length);

                    var xhr = new XMLHttpRequest();
                    state.xhr = xhr;
                    xhr.open((form.method || 'POST').toUpperCase(), form.action, true);
                    xhr.withCredentials = true;
                    xhr.setRequestHeader('Accept', 'application/json');
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.upload.onprogress = function (progress) {
                        if (progress.lengthComputable) {
                            state.activeLoaded = progress.loaded;
                            var percent = Math.round(progress.loaded / progress.total * 100);
                            setUploadRow(row, 'is-running', percent + '%', percent, '已上传 ' + formatBytes(progress.loaded) + ' / ' + formatBytes(progress.total));
                        } else {
                            setUploadRow(row, 'is-running', '上传中', 35, '正在上传...');
                        }
                        updateSummary('正在上传 ' + (index + 1) + '/' + files.length);
                    };
                    xhr.onload = function () {
                        var data = parseUploadResponse(xhr);
                        var ok = xhr.status >= 200 && xhr.status < 300 && data && data.success;
                        if (ok) {
                            state.success += 1;
                            state.uploadedBytes += file.size || 0;
                            state.activeLoaded = 0;
                            var uploadedFile = data.files && data.files.length ? data.files[0] : { name: file.name, size: file.size };
                            state.files.push(uploadedFile);
                            setUploadRow(row, 'is-success', '成功', 100, '上传完成');
                            addUploadRowActions(row, uploadedFile);
                        } else {
                            state.failed += 1;
                            state.failedItems.push({ file: file });
                            state.uploadedBytes += file.size || 0;
                            state.activeLoaded = 0;
                            var diagnostic = uploadDiagnosticText(data);
                            setUploadRow(row, 'is-error', '失败', 100, (data && data.message ? data.message : '上传失败：服务器没有返回明确原因，请到后台异常事件或上传失败记录查看。') + (diagnostic ? ' ' + diagnostic : ''));
                        }
                        updateSummary(ok ? '上传成功' : '上传失败');
                        uploadNext();
                    };
                    xhr.onabort = function () {
                        setUploadRow(row, 'is-error', '已取消', 100, '上传已取消。');
                        finish();
                    };
                    xhr.onerror = function () {
                        if (state.cancelled) return;
                        state.failed += 1;
                        state.failedItems.push({ file: file });
                        state.uploadedBytes += file.size || 0;
                        state.activeLoaded = 0;
                        setUploadRow(row, 'is-error', '失败', 100, '网络异常，上传未完成。');
                        updateSummary('上传失败');
                        uploadNext();
                    };
                    xhr.send(singleFilePayload(form, fieldName, file));
                }

                uploadNext();
            });

            qsa('input[type="file"]', form).forEach(function (input) {
                input.addEventListener('change', function () {
                    renderUploadPreview(form);
                });
            });
        });
    }

    function initServerForms() {
        qsa('.m-server-form').forEach(function (form) {
            var type = qs('[data-m-server-type]', form);
            var auth = qs('[data-m-ssh-auth]', form);
            function sync() {
                var isAgent = type && type.value === 'agent';
                var isKey = auth && auth.value === 'key';
                qsa('[data-m-ssh-field]', form).forEach(function (node) {
                    node.hidden = isAgent;
                });
                qsa('[data-m-agent-field]', form).forEach(function (node) {
                    node.hidden = !isAgent;
                });
                qsa('[data-m-auth-password]', form).forEach(function (node) {
                    node.hidden = isAgent || isKey;
                });
                qsa('[data-m-auth-key]', form).forEach(function (node) {
                    node.hidden = isAgent || !isKey;
                });
            }
            if (type) type.addEventListener('change', sync);
            if (auth) auth.addEventListener('change', sync);
            sync();
        });
    }

    function initStorageForms() {
        qsa('.m-storage-form').forEach(function (form) {
            var type = qs('[data-m-storage-type]', form);
            var cloudFields = qs('[data-m-storage-cloud]', form);
            var regionFields = qs('[data-m-storage-region]', form);
            var domain = qs('[data-m-storage-domain]', form);
            var help = qs('[data-m-storage-help]', form);
            var secret = qs('[name="secret_key"]', form);
            var access = qs('[name="access_key"]', form);
            var bucket = qs('[name="bucket"]', form);
            var endpoint = qs('[name="endpoint"]', form);

            function setHidden(node, hidden) {
                if (node) node.hidden = !!hidden;
            }

            function sync() {
                var value = type ? type.value : 'local';
                var isLocal = value === 'local';
                var isWebdav = value === 'webdav';
                var isBmtools = value === 'bmtools';
                setHidden(cloudFields, isLocal);
                setHidden(regionFields, isLocal);
                setHidden(domain, isLocal || isBmtools);

                if (access) {
                    access.placeholder = isWebdav ? 'WebDAV 用户名' : (value === 'cos' ? '腾讯云 SecretId' : (isBmtools ? '可留空，远端账号备注' : 'AccessKey'));
                }
                if (secret) {
                    var saved = secret.placeholder && secret.placeholder.indexOf('留空不修改') !== -1;
                    secret.placeholder = saved ? secret.placeholder : (isWebdav ? 'WebDAV 密码或应用 Token' : (isBmtools ? '远端用户 API Token' : (value === 'cos' ? '腾讯云 SecretKey' : 'SecretKey')));
                }
                if (bucket) {
                    bucket.placeholder = isWebdav ? '远程目录，可留空' : (isBmtools ? '同系统对接不用填写' : 'Bucket / 空间名称');
                }
                if (endpoint) {
                    endpoint.placeholder = isBmtools ? 'https://store.example.com' : (isWebdav ? 'https://dav.example.com/path' : 'Endpoint / 上传域名');
                }
                if (help) {
                    if (isLocal) {
                        help.textContent = '本地存储只需要名称和目录前缀。';
                    } else if (isBmtools) {
                        help.textContent = '同系统对接填写远端 HTTPS 根地址和远端用户 API Token，不能填写当前站点自身地址。';
                    } else if (value === 'kodo') {
                        help.textContent = '七牛云必须填写访问域名；Region 请选择空间所在区域，Endpoint 一般可留空。';
                    } else if (value === 'cos') {
                        help.textContent = '腾讯云 COS 建议填写完整 Bucket、SecretId、SecretKey 和 Region，例如 ap-guangzhou。';
                    } else {
                        help.textContent = '云存储请填写 Key、Bucket、Endpoint/Region 和访问域名，保存后执行真实测试。';
                    }
                }
            }
            if (type) type.addEventListener('change', sync);
            sync();
        });
    }

    function parseJsonResponse(response) {
        if (window.SKY_PARSE_JSON_RESPONSE) {
            return window.SKY_PARSE_JSON_RESPONSE(response);
        }
        return response.json();
    }

    function initTerminalToolForms() {
        function renderSteps(steps) {
            if (!Array.isArray(steps) || !steps.length) return '';
            return '\n\n检查结果：\n' + steps.map(function (step, index) {
                var label = step.label || ('步骤 ' + (index + 1));
                var status = step.status || 'pending';
                var message = step.message || '';
                return '- [' + status + '] ' + label + (message ? '：' + message : '');
            }).join('\n');
        }
        function formatDuration(ms) {
            var value = Number(ms || 0);
            if (!value || value < 0) return '';
            if (value < 1000) return value + 'ms';
            return (value / 1000).toFixed(2) + 's';
        }
        qsa('.m-terminal-form').forEach(function (form) {
            var output = qs('#mTerminalOutput');
            var state = qs('[data-terminal-state]', form);
            var input = qs('[name="command"]', form);
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                if (!input || !input.value.trim()) {
                    if (state) state.textContent = '请输入命令后再执行。';
                    return;
                }
                var command = input.value;
                var button = qs('button[type="submit"]', form);
                if (output) output.textContent += '\n$ ' + command;
                if (state) state.textContent = '正在执行，请等待服务器返回...';
                setButtonLoading(button, true);
                fetch(form.getAttribute('action'), {
                    method: 'POST',
                    body: new FormData(form),
                    credentials: 'same-origin',
                    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                }).then(parseJsonResponse).then(function (json) {
                    var duration = formatDuration(json.duration_ms);
                    if (output) {
                        output.textContent += '\n' + (json.success ? (json.output || '[无输出]') : ('ERROR: ' + (json.message || '执行失败') + renderSteps(json.steps)));
                        output.scrollTop = output.scrollHeight;
                    }
                    if (state) state.textContent = json.success ? ('完成：' + (json.time || '') + (duration ? ' / ' + duration : '')) : ('执行失败' + (duration ? ' / ' + duration : '') + '，请查看输出。');
                    if (json.success) input.value = '';
                }).catch(function (error) {
                    if (output) output.textContent += '\nERROR: ' + (error && error.message ? error.message : '请求失败');
                    if (state) state.textContent = '请求失败。';
                }).finally(function () {
                    setButtonLoading(button, false);
                    if (input) input.focus();
                });
            });
        });
        qsa('[data-terminal-snippet]').forEach(function (button) {
            button.addEventListener('click', function () {
                var input = qs('.m-terminal-form [name="command"]');
                var state = qs('.m-terminal-form [data-terminal-state]');
                if (!input) return;
                input.value = button.getAttribute('data-terminal-snippet') || '';
                input.focus();
                if (state) state.textContent = '已填入快捷命令，确认后执行。';
            });
        });
        qsa('[data-mobile-terminal-clear]').forEach(function (button) {
            button.addEventListener('click', function () {
                var output = qs('#mTerminalOutput');
                var state = qs('.m-terminal-form [data-terminal-state]');
                if (output) output.textContent = 'BM ucloud tools mobile terminal\n\n输出已清空。';
                if (state) state.textContent = '输出已清空。';
            });
        });
    }

    function initProbeForms() {
        qsa('.m-probe-form').forEach(function (form) {
            var type = qs('[data-m-probe-type]', form);
            var result = qs('[data-m-probe-result]', form);
            function sync() {
                var isHttp = !type || type.value === 'http';
                qsa('[data-m-http-field]', form).forEach(function (node) {
                    node.hidden = !isHttp;
                });
            }
            if (type) type.addEventListener('change', sync);
            sync();
            var testButton = qs('[data-m-probe-test]', form);
            if (testButton) {
                testButton.addEventListener('click', function () {
                    var action = testButton.getAttribute('data-url');
                    if (!action) return;
                    setButtonLoading(testButton, true);
                    var data = new FormData(form);
                    data.append('payload_test', '1');
                    fetch(action, {
                        method: 'POST',
                        body: data,
                        credentials: 'same-origin',
                        headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                    }).then(parseJsonResponse).then(function (json) {
                        if (result) {
                            result.hidden = false;
                            result.textContent = json.message || (json.success ? '检测通过。' : '检测失败。');
                        }
                    }).catch(function (error) {
                        if (result) {
                            result.hidden = false;
                            result.textContent = error && error.message ? error.message : '请求失败。';
                        }
                    }).finally(function () {
                        setButtonLoading(testButton, false);
                    });
                });
            }
        });
        qsa('[data-m-saved-probe-test]').forEach(function (button) {
            button.addEventListener('click', function () {
                var data = new FormData();
                data.append('_token', button.getAttribute('data-token') || '');
                data.append('server_id', button.getAttribute('data-server-id') || '');
                data.append('id', button.getAttribute('data-id') || '');
                setButtonLoading(button, true);
                fetch(button.getAttribute('data-url'), {
                    method: 'POST',
                    body: data,
                    credentials: 'same-origin',
                    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                }).then(parseJsonResponse).then(function (json) {
                    showUploadNotice(json.message || (json.success ? '检测通过。' : '检测失败。'), json.success ? 'success' : 'warn');
                    if (json.success) window.setTimeout(function () { window.location.reload(); }, 650);
                }).catch(function (error) {
                    showUploadNotice(error && error.message ? error.message : '请求失败。', 'error');
                }).finally(function () {
                    setButtonLoading(button, false);
                });
            });
        });
    }

    function initFillButtons() {
        qsa('[data-fill-target][data-fill-value]').forEach(function (button) {
            button.addEventListener('click', function () {
                var target = qs(button.getAttribute('data-fill-target') || '');
                if (!target) return;
                target.value = button.getAttribute('data-fill-value') || '';
                target.focus();
                try {
                    target.dispatchEvent(new Event('input', { bubbles: true }));
                    target.dispatchEvent(new Event('change', { bubbles: true }));
                } catch (e) {}
            });
        });
    }

    function initPageFilters() {
        qsa('[data-mobile-filter-input]').forEach(function (input) {
            var selector = input.getAttribute('data-mobile-filter-input') || '';
            var target = selector ? qs(selector) : closest(input, '[data-mobile-filter-scope]');
            if (!target) return;
            var empty = qs('[data-mobile-filter-empty]', target);
            var label = closest(input, '.m-list-search');
            var count = label ? qs('[data-mobile-filter-count]', label) : null;
            if (label && !count) {
                count = document.createElement('span');
                count.setAttribute('data-mobile-filter-count', '');
                count.textContent = '0';
                label.appendChild(count);
            }
            var items = function () {
                return qsa('[data-mobile-filter-item]', target);
            };
            var apply = function () {
                var keyword = normalizeMenuText(input.value);
                var visible = 0;
                var total = 0;
                items().forEach(function (item) {
                    total += 1;
                    var matched = !keyword || normalizeMenuText(item.textContent).indexOf(keyword) !== -1;
                    item.hidden = !matched;
                    if (matched) visible += 1;
                });
                if (empty) empty.hidden = visible > 0 || keyword === '';
                if (count) count.textContent = keyword ? (visible + '/' + total) : String(total);
                qsa('[data-mobile-filter-group]', target).forEach(function (group) {
                    var groupVisible = qsa('[data-mobile-filter-item]', group).some(function (item) {
                        return !item.hidden;
                    });
                    group.hidden = !groupVisible && keyword !== '';
                });
            };
            input.addEventListener('input', apply);
            apply();
        });
    }

    if (window.PointerEvent) {
        document.addEventListener('pointerup', handleMenuEvent, true);
        document.addEventListener('click', handleMenuEvent, true);
    } else {
        document.addEventListener('touchend', handleMenuEvent, true);
        document.addEventListener('click', handleMenuEvent, true);
    }

    document.addEventListener('click', function (event) {
        var copyNode = closest(event.target, '[data-copy-text]');
        if (copyNode) {
            event.preventDefault();
            copyText(copyNode.getAttribute('data-copy-text') || '', copyNode);
            return;
        }
        var copyOutputNode = closest(event.target, '[data-copy-output]');
        if (copyOutputNode) {
            event.preventDefault();
            var target = qs(copyOutputNode.getAttribute('data-copy-output') || '');
            copyText(target ? target.textContent : '', copyOutputNode);
            return;
        }
        var confirmNode = closest(event.target, '[data-mobile-confirm]');
        if (confirmNode && !window.confirm(confirmNode.getAttribute('data-mobile-confirm') || '确认继续操作吗？')) {
            event.preventDefault();
            event.stopPropagation();
            return;
        }
    }, true);

    document.addEventListener('input', function (event) {
        if (!closest(event.target, '[data-mobile-menu-search]')) return;
        filterMobileMenu(event.target.value);
    });

    document.addEventListener('touchmove', function (event) {
        var sheet = qs('[data-mobile-menu-sheet]');
        if (!sheet || !document.body.classList.contains('m-menu-open')) return;
        if (!closest(event.target, '.m-menu-panel')) {
            event.preventDefault();
        }
    }, { passive: false });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeMenu(true);
    });

    qsa('.m-menu-sheet a').forEach(function (link) {
        link.addEventListener('click', function (event) {
            if (event.defaultPrevented) return;
            closeMenu(true);
        });
    });

    initUploadForms();
    initServerForms();
    initStorageForms();
    initTerminalToolForms();
    initProbeForms();
    initFillButtons();
    initPageFilters();
    iconRefresh();

    setMenuExpanded(false);
    window.addEventListener('pageshow', function () {
        closeMenu(true);
        setMenuExpanded(false);
    });
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 900) closeMenu(true);
    });
})();
