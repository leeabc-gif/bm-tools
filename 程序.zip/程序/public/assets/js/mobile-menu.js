(function () {
    function closest(node, selector) {
        while (node && node.nodeType === 1) {
            if (node.matches && node.matches(selector)) return node;
            node = node.parentElement;
        }
        return null;
    }

    function ensureMask() {
        var mask = document.querySelector('.mobile-menu-mask');
        if (!mask) {
            mask = document.createElement('div');
            mask.className = 'mobile-menu-mask';
            mask.setAttribute('aria-hidden', 'true');
            document.body.appendChild(mask);
        }
        return mask;
    }

    function sidebarNodes() {
        return Array.prototype.slice.call(document.querySelectorAll('.site-nav, .console-sidebar, .admin-sidebar'));
    }

    function isOpen() {
        return document.body.classList.contains('mobile-menu-open');
    }

    function adminSheetOpen() {
        return document.body && document.body.classList.contains('admin-mobile-menu-open');
    }

    function adminPage() {
        return document.body && document.body.classList.contains('admin-body');
    }

    function setOpen(open) {
        if (adminSheetOpen()) {
            open = false;
        }
        open = !!open;
        var mobile = window.innerWidth <= 900;
        sidebarNodes().forEach(function (node) {
            node.classList.toggle('open', open);
            node.setAttribute('aria-hidden', mobile && !open ? 'true' : 'false');
        });

        Array.prototype.slice.call(document.querySelectorAll('.console-layout')).forEach(function (node) {
            node.classList.toggle('menu-open', open);
        });

        document.body.classList.toggle('mobile-menu-open', open);
        document.body.classList.toggle('admin-mobile-drawer-open', open && document.body.classList.contains('admin-body'));
        document.body.setAttribute('data-mobile-menu', open ? 'open' : 'closed');

        Array.prototype.slice.call(document.querySelectorAll('.mobile-menu-btn')).forEach(function (node) {
            node.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        ensureMask();
    }

    function releaseScrollLock() {
        document.documentElement.style.overflow = '';
        document.body.style.overflow = '';
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.width = '';
    }

    function syncSidebarState() {
        var open = isOpen();
        var mobile = window.innerWidth <= 900;
        sidebarNodes().forEach(function (node) {
            node.setAttribute('aria-hidden', mobile && !open ? 'true' : 'false');
        });
    }

    function close() {
        setOpen(false);
        releaseScrollLock();
    }

    var lastToggleAt = 0;

    function toggleFromButton(event) {
        if (adminPage()) return false;
        if (adminSheetOpen()) return false;
        var button = closest(event.target, '.mobile-menu-btn');
        if (!button) return false;

        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();

        var now = Date.now();
        if (now - lastToggleAt < 420) {
            return true;
        }
        lastToggleAt = now;

        setOpen(!isOpen());
        return true;
    }

    function closeFromButton(event) {
        if (adminPage()) return false;
        if (adminSheetOpen()) return false;
        var button = closest(event.target, '.console-menu-close');
        if (!button) return false;

        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
        close();
        return true;
    }

    window.SKY_MOBILE_MENU = {
        open: function () { setOpen(true); },
        close: close,
        toggle: function () { setOpen(!isOpen()); },
        isOpen: isOpen
    };

    document.addEventListener('click', toggleFromButton, true);
    document.addEventListener('touchend', toggleFromButton, true);
    document.addEventListener('click', closeFromButton, true);
    document.addEventListener('touchend', closeFromButton, true);

    document.addEventListener('click', function (event) {
        if (adminPage()) return;
        if (adminSheetOpen()) return;
        if (closest(event.target, '.mobile-menu-mask')) {
            event.preventDefault();
            close();
            return;
        }

        if (!isOpen() || window.innerWidth > 900) return;
        if (closest(event.target, '.site-nav a, .console-sidebar a, .admin-sidebar a')) {
            close();
            return;
        }
        if (closest(event.target, '.site-nav, .console-sidebar, .admin-sidebar, .mobile-menu-btn')) return;
        if (closest(event.target, '.console-content, .console-topbar, main')) close();
    });

    document.addEventListener('pointerdown', function (event) {
        if (adminPage()) return;
        if (adminSheetOpen()) return;
        if (!isOpen() || window.innerWidth > 900) return;
        if (closest(event.target, '.site-nav a, .console-sidebar a, .admin-sidebar a')) {
            close();
        }
    }, true);

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') close();
    });

    document.addEventListener('admin-mobile-menu:open', close);

    window.addEventListener('resize', function () {
        if (window.innerWidth > 900) close();
        syncSidebarState();
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            ensureMask();
            close();
            syncSidebarState();
        });
    } else {
        ensureMask();
        close();
        syncSidebarState();
    }

    window.addEventListener('pageshow', function () {
        close();
        syncSidebarState();
    });
})();
