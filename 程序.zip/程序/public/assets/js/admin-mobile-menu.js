(function () {
    function closest(node, selector) {
        while (node && node.nodeType === 1) {
            if (node.matches && node.matches(selector)) return node;
            node = node.parentElement;
        }
        return null;
    }

    function isAdmin() {
        return document.body && document.body.classList.contains('admin-body');
    }

    function sheet() {
        return document.querySelector('.admin-mobile-menu-sheet');
    }

    function buttons() {
        return Array.prototype.slice.call(document.querySelectorAll('.admin-mobile-menu-btn'));
    }

    function setExpanded(open) {
        buttons().forEach(function (button) {
            button.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    function eventName(name) {
        return 'admin-mobile-menu:' + name;
    }

    function emit(name) {
        var event;
        var fullName = eventName(name);
        if (typeof CustomEvent === 'function') {
            event = new CustomEvent(fullName);
        } else {
            event = document.createEvent('CustomEvent');
            event.initCustomEvent(fullName, false, false, null);
        }
        document.dispatchEvent(event);
    }

    function isTouchLike() {
        return window.matchMedia && window.matchMedia('(hover: none), (pointer: coarse)').matches;
    }

    function compactText(node) {
        return String((node && node.textContent) || '').replace(/\s+/g, ' ').trim();
    }

    function hydrateResponsiveTables(root) {
        if (!isAdmin()) return;
        root = root || document;
        var tables = [];
        if (root.nodeType === 1 && root.matches && root.matches('table')) {
            tables.push(root);
        }
        tables = tables.concat(Array.prototype.slice.call(root.querySelectorAll ? root.querySelectorAll('table') : []));

        tables.forEach(function (table) {
            var heads = Array.prototype.slice.call(table.querySelectorAll('thead th')).map(compactText);
            if (heads.length) {
                Array.prototype.slice.call(table.querySelectorAll('tbody tr')).forEach(function (row) {
                    var cells = Array.prototype.slice.call(row.children).filter(function (cell) {
                        return cell && cell.tagName && cell.tagName.toLowerCase() === 'td';
                    });
                    cells.forEach(function (cell, index) {
                        if (cell.hasAttribute('colspan')) {
                            cell.classList.add('responsive-table-span');
                            return;
                        }
                        if (!cell.getAttribute('data-label')) {
                            var fallback = heads[index] || heads[Math.min(index, heads.length - 1)] || '\u4fe1\u606f';
                            if (cell.classList.contains('table-actions') || cell.querySelector('form, button, .btn, .bm-btn')) {
                                fallback = fallback || '\u64cd\u4f5c';
                            }
                            cell.setAttribute('data-label', fallback);
                        }
                    });
                });
            } else {
                Array.prototype.slice.call(table.querySelectorAll('td[colspan]')).forEach(function (cell) {
                    cell.classList.add('responsive-table-span');
                });
            }
            table.classList.add('admin-responsive-table');
        });
    }

    function hydrateAdminDivTables(root) {
        if (!isAdmin()) return;
        root = root || document;
        var tables = [];
        if (root.nodeType === 1 && root.matches && root.matches('.bm-admin-table')) {
            tables.push(root);
        }
        tables = tables.concat(Array.prototype.slice.call(root.querySelectorAll ? root.querySelectorAll('.bm-admin-table') : []));

        tables.forEach(function (table) {
            var labels = Array.prototype.slice.call(table.querySelectorAll('.bm-admin-table-head > *')).map(compactText);
            Array.prototype.slice.call(table.querySelectorAll('.bm-admin-table-row')).forEach(function (row) {
                Array.prototype.slice.call(row.children).forEach(function (cell, index) {
                    if (!cell.getAttribute('data-label')) {
                        cell.setAttribute('data-label', labels[index] || '\u4fe1\u606f');
                    }
                });
            });
        });
    }

    function hydrateMobileContent(root) {
        hydrateResponsiveTables(root);
        hydrateAdminDivTables(root);
    }

    var lockedScrollY = 0;
    var menuOpenedAt = 0;
    var suppressOpenerClickUntil = 0;

    function clearLegacyDrawerState() {
        document.body.classList.remove('mobile-menu-open', 'admin-mobile-drawer-open');
        document.body.setAttribute('data-mobile-menu', 'closed');
        Array.prototype.slice.call(document.querySelectorAll('.site-nav, .console-sidebar, .admin-sidebar')).forEach(function (node) {
            node.classList.remove('open');
            node.setAttribute('aria-hidden', 'true');
        });
        Array.prototype.slice.call(document.querySelectorAll('.console-layout')).forEach(function (node) {
            node.classList.remove('menu-open');
        });
    }

    function lockPageScroll() {
        lockedScrollY = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
        document.documentElement.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.style.top = '-' + lockedScrollY + 'px';
        document.body.style.left = '0';
        document.body.style.right = '0';
        document.body.style.width = '100%';
    }

    function unlockPageScroll() {
        document.documentElement.style.overflow = '';
        document.body.style.overflow = '';
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.left = '';
        document.body.style.right = '';
        document.body.style.width = '';
        if (lockedScrollY > 0) {
            window.scrollTo(0, lockedScrollY);
        }
        lockedScrollY = 0;
    }

    function openMenu() {
        if (!isAdmin()) return;
        if (window.SKY_MOBILE_MENU && typeof window.SKY_MOBILE_MENU.close === 'function') {
            window.SKY_MOBILE_MENU.close();
        }
        clearLegacyDrawerState();
        var panel = sheet();
        if (!panel) return;
        document.body.classList.add('admin-mobile-menu-open');
        panel.setAttribute('aria-hidden', 'false');
        setExpanded(true);
        menuOpenedAt = Date.now();
        suppressOpenerClickUntil = menuOpenedAt + 760;
        emit('open');
        lockPageScroll();
        window.setTimeout(function () {
            var closeButton = panel.querySelector('.admin-mobile-menu-close');
            if (closeButton && window.innerWidth <= 900 && !isTouchLike()) {
                try {
                    closeButton.focus({ preventScroll: true });
                } catch (error) {
                    closeButton.focus();
                }
            }
        }, 80);
    }

    function closeMenu(force) {
        if (!force && menuOpenedAt && Date.now() - menuOpenedAt < 360) return;
        var panel = sheet();
        document.body.classList.remove('admin-mobile-menu-open');
        if (panel) panel.setAttribute('aria-hidden', 'true');
        setExpanded(false);
        unlockPageScroll();
        menuOpenedAt = 0;
        suppressOpenerClickUntil = Date.now() + 180;
        emit('close');
    }

    function toggleMenu() {
        if (document.body.classList.contains('admin-mobile-menu-open')) closeMenu();
        else openMenu();
    }

    function normalize(value) {
        return String(value || '').replace(/\s+/g, '').toLowerCase();
    }

    function filterMenu(value) {
        var panel = sheet();
        if (!panel) return;
        var keyword = normalize(value);
        var visibleCount = 0;
        Array.prototype.slice.call(panel.querySelectorAll('.admin-mobile-menu-group')).forEach(function (group) {
            var groupVisible = false;
            Array.prototype.slice.call(group.querySelectorAll('[data-admin-mobile-menu-item]')).forEach(function (item) {
                var match = !keyword || normalize(item.textContent).indexOf(keyword) !== -1;
                item.hidden = !match;
                if (match) {
                    groupVisible = true;
                    visibleCount++;
                }
            });
            group.hidden = !groupVisible;
        });
        var empty = panel.querySelector('.admin-mobile-menu-empty');
        if (empty) empty.hidden = visibleCount > 0;
    }

    function jumpToGroup(button) {
        var panel = sheet();
        if (!panel || !button) return;
        var id = button.getAttribute('data-admin-mobile-menu-jump') || '';
        if (!id) return;
        var target = document.getElementById(id);
        var scroller = panel.querySelector('.admin-mobile-menu-groups');
        if (!target || !scroller) return;

        Array.prototype.slice.call(panel.querySelectorAll('[data-admin-mobile-menu-jump]')).forEach(function (item) {
            item.classList.toggle('active', item === button);
        });

        var offset = target.offsetTop - scroller.offsetTop;
        scroller.scrollTo({ top: Math.max(0, offset - 4), behavior: 'smooth' });
    }

    var lastHandledAt = 0;
    var lastTouchLikeAt = 0;

    function isTouchEvent(event) {
        return event && (event.type === 'touchend' || (event.type === 'pointerup' && event.pointerType && event.pointerType !== 'mouse'));
    }

    function shouldHandleNow(event) {
        var now = Date.now();
        if (event && event.type === 'click' && now - lastTouchLikeAt < 800) return false;
        if (isTouchEvent(event)) lastTouchLikeAt = now;
        if (now - lastHandledAt < 240) return false;
        lastHandledAt = now;
        return true;
    }

    function handleMenuEvent(event) {
        if (!isAdmin()) return;

        var opener = closest(event.target, '.admin-mobile-menu-btn');
        if (opener) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            if (!shouldHandleNow(event)) return;
            if (document.body.classList.contains('admin-mobile-menu-open') && menuOpenedAt && Date.now() - menuOpenedAt < 700) return;
            toggleMenu();
            return;
        }

        if (closest(event.target, '.admin-mobile-menu-close')) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            if (!shouldHandleNow(event)) return;
            closeMenu(true);
            return;
        }

        var panel = sheet();
        if (!panel || !document.body.classList.contains('admin-mobile-menu-open')) return;

        var jump = closest(event.target, '[data-admin-mobile-menu-jump]');
        if (jump) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            if (!shouldHandleNow(event)) return;
            jumpToGroup(jump);
            return;
        }

        if (event.target === panel) {
            event.preventDefault();
            closeMenu();
            return;
        }

        var link = closest(event.target, '.admin-mobile-menu-grid a, .admin-mobile-menu-actions a');
        if (link && event.type === 'click') closeMenu(true);
    }

    function suppressGhostOpenerEvent(event) {
        if (!isAdmin()) return;
        if (Date.now() > suppressOpenerClickUntil) return;
        if (!closest(event.target, '.admin-mobile-menu-btn')) return;
        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }

    if (window.PointerEvent) {
        document.addEventListener('pointerup', handleMenuEvent, true);
        document.addEventListener('touchend', suppressGhostOpenerEvent, true);
        document.addEventListener('click', suppressGhostOpenerEvent, true);
        document.addEventListener('click', handleMenuEvent, true);
    } else {
        document.addEventListener('touchend', handleMenuEvent, true);
        document.addEventListener('click', handleMenuEvent, true);
    }

    document.addEventListener('input', function (event) {
        if (!closest(event.target, '[data-admin-mobile-menu-search]')) return;
        filterMenu(event.target.value);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeMenu(true);
    });

    function boot() {
        if (!isAdmin()) return;
        document.body.setAttribute('data-admin-mobile-ready', '1');
        hydrateMobileContent(document);
        if (window.MutationObserver) {
            var pending = 0;
            var observer = new MutationObserver(function (mutations) {
                if (pending) window.clearTimeout(pending);
                pending = window.setTimeout(function () {
                    pending = 0;
                    mutations.forEach(function (mutation) {
                        Array.prototype.slice.call(mutation.addedNodes || []).forEach(function (node) {
                            if (node && node.nodeType === 1) hydrateMobileContent(node);
                        });
                    });
                }, 120);
            });
            observer.observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    window.addEventListener('resize', function () {
        if (window.innerWidth > 900) closeMenu(true);
    });

    window.addEventListener('pageshow', function () {
        closeMenu(true);
    });

    window.SKY_ADMIN_MOBILE_MENU = {
        open: openMenu,
        close: closeMenu,
        toggle: toggleMenu,
        hydrate: hydrateMobileContent
    };
})();
