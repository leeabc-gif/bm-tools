(function () {
    var baseUrl = (window.SKY_BASE_URL || '').replace(/\/$/, '');
    function api(path) { return baseUrl + '/' + path.replace(/^\//, ''); }

    function textFromHtml(source) {
        var text = String(source || '')
            .replace(/<script[\s\S]*?<\/script>/gi, ' ')
            .replace(/<style[\s\S]*?<\/style>/gi, ' ')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        return text.length > 220 ? text.slice(0, 220) + '...' : text;
    }

    function safeJsonMessage(response, text) {
        var lower = String(text || '').toLowerCase();
        if (response && (response.status === 401 || response.status === 403)) {
            return '登录状态已失效或权限不足，请重新登录后再试。';
        }
        if (lower.indexOf('<!doctype') !== -1 || lower.indexOf('<html') !== -1) {
            if (lower.indexOf('login') !== -1 || lower.indexOf('登录') !== -1) {
                return '登录状态可能已失效，请刷新页面后重新登录。';
            }
            return '接口返回了页面内容而不是 JSON：' + (textFromHtml(text) || '请检查服务器错误日志。');
        }
        if (response && response.status >= 500) {
            return '服务器内部异常（HTTP ' + response.status + '），请进入系统维护检查数据库和运行日志。';
        }
        return textFromHtml(text) || '接口返回为空，请检查网络、登录状态或伪静态配置。';
    }

    function parseJsonResponse(response) {
        return response.text().then(function (text) {
            var json;
            try {
                json = text ? JSON.parse(text) : {};
            } catch (error) {
                var message = safeJsonMessage(response, text);
                var parseError = new Error(message);
                parseError.httpStatus = response ? response.status : 0;
                parseError.responseText = text;
                throw parseError;
            }
            if (json && typeof json === 'object') {
                json.httpStatus = response ? response.status : 0;
                if (response && !response.ok && !json.message) {
                    json.message = '请求失败（HTTP ' + response.status + '）。';
                }
            }
            return json;
        });
    }

    window.SKY_PARSE_JSON_RESPONSE = parseJsonResponse;
    window.SKY_SAFE_JSON_MESSAGE = safeJsonMessage;

    function ajaxErrorMessage(xhr, fallback) {
        if (xhr && xhr.responseJSON && xhr.responseJSON.message) {
            return xhr.responseJSON.message;
        }
        if (xhr && xhr.responseText) {
            return safeJsonMessage({ status: xhr.status || 0 }, xhr.responseText);
        }
        return fallback || '请求没有返回可用结果，请刷新页面确认登录状态；如果仍失败，请查看后台系统维护里的运行日志。';
    }

    window.SKY_AJAX_ERROR_MESSAGE = ajaxErrorMessage;

    function toastType(type) {
        return type === 'success' || type === 'error' || type === 'warning' || type === 'info' ? type : 'info';
    }

    function showToast(message, type, timeout) {
        message = String(message || '').trim();
        if (!message) return;
        type = toastType(type);
        var root = document.querySelector('.sky-toast-root');
        if (!root) {
            root = document.createElement('div');
            root.className = 'sky-toast-root';
            root.setAttribute('aria-live', 'polite');
            root.setAttribute('aria-atomic', 'false');
            document.body.appendChild(root);
        }
        var item = document.createElement('div');
        item.className = 'sky-toast sky-toast-' + type;
        item.setAttribute('role', type === 'error' ? 'alert' : 'status');
        item.innerHTML = '<span class="sky-toast-dot" aria-hidden="true"></span><b></b><button type="button" aria-label="关闭提示">×</button>';
        item.querySelector('b').textContent = message;
        var close = function () {
            item.classList.remove('show');
            window.setTimeout(function () {
                if (item.parentNode) item.parentNode.removeChild(item);
                if (root && !root.children.length && root.parentNode) root.parentNode.removeChild(root);
            }, 180);
        };
        item.querySelector('button').addEventListener('click', close);
        root.appendChild(item);
        window.setTimeout(function () { item.classList.add('show'); }, 16);
        window.setTimeout(close, Math.max(1800, timeout || (type === 'error' ? 5200 : 3000)));
    }

    window.SKY_TOAST = showToast;

    function showConfirm(message, options) {
        options = options || {};
        message = String(message || '确定执行该操作吗？').trim() || '确定执行该操作吗？';
        return new Promise(function (resolve) {
            var old = document.querySelector('.sky-confirm-backdrop');
            if (old && old.parentNode) old.parentNode.removeChild(old);

            var danger = options.danger;
            if (danger === undefined) danger = /删除|清空|关闭|重置|彻底|下架|停用|修复|安装/.test(message);
            var backdrop = document.createElement('div');
            backdrop.className = 'sky-confirm-backdrop' + (danger ? ' sky-confirm-danger' : '');
            backdrop.setAttribute('role', 'presentation');
            backdrop.innerHTML = [
                '<section class="sky-confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="sky-confirm-title">',
                '<div class="sky-confirm-head">',
                '<span class="sky-confirm-icon" aria-hidden="true"></span>',
                '<div><b id="sky-confirm-title"></b><p></p></div>',
                '</div>',
                '<div class="sky-confirm-actions">',
                '<button type="button" class="sky-confirm-cancel"></button>',
                '<button type="button" class="sky-confirm-ok"></button>',
                '</div>',
                '</section>'
            ].join('');
            var dialog = backdrop.querySelector('.sky-confirm-dialog');
            var title = backdrop.querySelector('#sky-confirm-title');
            var text = backdrop.querySelector('p');
            var cancel = backdrop.querySelector('.sky-confirm-cancel');
            var ok = backdrop.querySelector('.sky-confirm-ok');
            title.textContent = options.title || (danger ? '确认高风险操作' : '确认操作');
            text.textContent = message;
            cancel.textContent = options.cancelText || '取消';
            ok.textContent = options.confirmText || '确认';

            function close(result) {
                backdrop.classList.remove('show');
                document.body.classList.remove('sky-confirm-open');
                document.removeEventListener('keydown', onKeydown);
                window.setTimeout(function () {
                    if (backdrop.parentNode) backdrop.parentNode.removeChild(backdrop);
                    resolve(!!result);
                }, 160);
            }

            function onKeydown(event) {
                if (event.key === 'Escape') close(false);
            }

            backdrop.addEventListener('click', function (event) {
                if (event.target === backdrop) close(false);
            });
            cancel.addEventListener('click', function () { close(false); });
            ok.addEventListener('click', function () { close(true); });
            dialog.addEventListener('click', function (event) { event.stopPropagation(); });
            document.addEventListener('keydown', onKeydown);
            document.body.appendChild(backdrop);
            document.body.classList.add('sky-confirm-open');
            window.setTimeout(function () {
                backdrop.classList.add('show');
                ok.focus();
            }, 16);
        });
    }

    window.SKY_CONFIRM = showConfirm;

    function autoTheme() {
        var hour = new Date().getHours();
        return hour >= 7 && hour < 19 ? 'light' : 'dark';
    }

    function normalizeThemeMode(mode) {
        return mode === 'light' || mode === 'dark' || mode === 'auto' ? mode : 'auto';
    }

    function normalizeThemeStyle(style) {
        return style === 'anime' ? 'anime' : 'classic';
    }

    function applyTheme(mode, persist) {
        mode = normalizeThemeMode(mode);
        var resolved = mode === 'auto' ? autoTheme() : mode;
        document.body.setAttribute('data-theme-mode', mode);
        document.body.setAttribute('data-theme', resolved);
        $('.theme-toggle').attr('title', mode === 'auto' ? '主题：自动' : (mode === 'dark' ? '主题：深色' : '主题：浅色'));
        if (persist) localStorage.setItem('sky_theme_mode', mode);
    }

    var defaultTheme = normalizeThemeMode(window.SKY_DEFAULT_THEME || document.body.getAttribute('data-theme') || 'auto');
    var savedTheme = normalizeThemeMode(localStorage.getItem('sky_theme_mode') || localStorage.getItem('sky_theme') || defaultTheme);
    applyTheme(savedTheme, false);

    var themeScope = window.SKY_THEME_SCOPE || (document.body.classList.contains('admin-body') ? 'admin' : 'front');
    var themeStyleKey = 'sky_theme_style_' + themeScope;
    var defaultThemeStyle = normalizeThemeStyle(window.SKY_THEME_STYLE || document.body.getAttribute('data-theme-style') || 'classic');

    function applyThemeStyle(style, persist) {
        style = normalizeThemeStyle(style);
        document.body.setAttribute('data-theme-style', style);
        $('.theme-style-option:not([data-target-select]), .theme-style-option[data-target-select="#admin-theme-style"]').removeClass('active');
        $('.theme-style-option:not([data-target-select])[data-theme-style="' + style + '"], .theme-style-option[data-target-select="#admin-theme-style"][data-theme-style="' + style + '"]').addClass('active');
        $('.theme-style-select').val(style);
        if (persist) localStorage.setItem(themeStyleKey, style);
    }

    applyThemeStyle(defaultThemeStyle, true);

    function toggleTheme() {
        var current = normalizeThemeMode(document.body.getAttribute('data-theme-mode') || savedTheme);
        applyTheme(current === 'auto' ? 'light' : (current === 'light' ? 'dark' : 'auto'), true);
    }

    var iconMap = {
        '保存': 'save',
        '删除': 'trash-2',
        '批量删除': 'trash-2',
        '编辑': 'pencil',
        '搜索': 'search',
        '筛选': 'filter',
        '重置': 'rotate-ccw',
        '上传': 'upload-cloud',
        '上传图片': 'upload-cloud',
        '开始上传': 'upload-cloud',
        '复制': 'copy',
        '分享': 'share-2',
        '关闭': 'x-circle',
        '启用': 'check-circle',
        '停用': 'pause-circle',
        '移动': 'folder-input',
        '测试': 'plug-zap',
        '发送': 'send',
        '导出': 'download',
        '通过': 'check',
        '拒绝': 'x',
        '购买': 'shopping-cart',
        '登录': 'log-in',
        '注册': 'user-plus',
        '退出': 'log-out',
        '返回': 'arrow-left',
        '下载': 'download',
        '立即采集': 'activity',
        '个人中心': 'layout-dashboard',
        '营销活动': 'badge-percent'
    };

    function iconNameFor(el) {
        var explicit = el.getAttribute('data-icon');
        if (explicit) return explicit;
        var text = (el.textContent || '').replace(/\s+/g, '').trim();
        if (iconMap[text]) return iconMap[text];
        Object.keys(iconMap).some(function (key) {
            if (text.indexOf(key) !== -1) {
                explicit = iconMap[key];
                return true;
            }
            return false;
        });
        return explicit || '';
    }

    function enhanceIcons() {
        document.querySelectorAll('.btn, .bm-btn, .icon-btn, .space-button, .space-nav a, .site-nav a, .console-nav a, .admin-nav a, .admin-mobile-control-panel a, .admin-mobile-control-panel button, .mobile-bottom-nav a, .admin-menu-toggle, .admin-right-rail button, .admin-right-rail a, .context-menu button, .product-link, .editor-toolbar button, [data-lucide]').forEach(function (el) {
            if (el.querySelector('.btn-icon')) return;
            if (el.hasAttribute('data-lucide') && !el.classList.contains('btn') && !el.classList.contains('icon-btn')) return;
            var icon = iconNameFor(el);
            if (!icon) return;
            var span = document.createElement('span');
            span.className = 'btn-icon';
            span.setAttribute('data-lucide', icon);
            el.insertBefore(span, el.firstChild);
        });
        if (window.lucide) {
            window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
        } else {
            document.querySelectorAll('[data-lucide]').forEach(function (node) {
                if (node.querySelector('svg')) return;
                node.classList.add('lucide', 'lucide-fallback');
                node.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"></circle><path d="M12 8v8M8 12h8"></path></svg>';
            });
        }
    }

    function setButtonText(btn, text) {
        btn.text(text);
        enhanceIcons();
    }

    function markActiveNav() {
        function normalizeNavPath(path) {
            path = (path || '/').replace(/\/$/, '') || '/';
            var aliases = ['/user/center', '/user/dashboard', '/console', '/user'];
            for (var i = 0; i < aliases.length; i++) {
                var alias = aliases[i];
                if (path === alias || path.slice(-alias.length) === alias) {
                    return path.slice(0, path.length - alias.length) + '/dashboard';
                }
            }
            return path;
        }
        var current = normalizeNavPath(window.location.pathname);
        $('.site-nav a, .console-nav a, .admin-nav a, .mobile-bottom-nav a').each(function () {
            var link = document.createElement('a');
            link.href = this.href;
            var path = normalizeNavPath(link.pathname);
            if (path === current || (path !== '/' && current.indexOf(path) === 0)) $(this).addClass('active');
        });
    }

    function hydrateResponsiveTables() {
        $('table').each(function () {
            var headers = [];
            $(this).find('thead th').each(function () {
                headers.push(($(this).text() || '').replace(/\s+/g, ' ').trim());
            });
            if (!headers.length) return;
            $(this).find('tbody tr').each(function () {
                $(this).children('td').each(function (index) {
                    if (this.hasAttribute('colspan') || this.hasAttribute('rowspan')) {
                        this.classList.add('responsive-table-span');
                        this.removeAttribute('data-label');
                        return;
                    }
                    if (!this.getAttribute('data-label') && headers[index]) {
                        this.setAttribute('data-label', headers[index]);
                    }
                    if (!this.getAttribute('data-label')) {
                        this.classList.add('responsive-table-no-label');
                    }
                });
            });
        });
    }

    function markFormLoading(form) {
        var submit = form.find('button[type="submit"], .btn-primary').filter('button').first();
        if (submit.length && !submit.prop('disabled')) {
            submit.addClass('is-loading').prop('disabled', true);
            submit.append('<span class="loading-dot"></span>');
        }
    }

    $('.theme-toggle').on('click', toggleTheme);
    $(document).on('change', '.theme-style-select', function () {
        applyThemeStyle(this.value, true);
    });
    $(document).on('click', '.theme-style-option', function () {
        var style = this.getAttribute('data-theme-style') || 'classic';
        var target = this.getAttribute('data-target-select');
        if (target) {
            $(target).val(style);
            $(this).closest('.theme-choice-grid').find('.theme-style-option').removeClass('active');
            $(this).addClass('active');
            if (target === '#admin-theme-style') applyThemeStyle(style, true);
            return;
        }
        applyThemeStyle(style, true);
    });
    $(document).on('click', '.home-style-option', function () {
        var style = this.getAttribute('data-home-style') || 'default';
        var target = this.getAttribute('data-target-select');
        if (target) {
            $(target).val(style);
        }
        $(this).closest('.theme-choice-grid').find('.home-style-option').removeClass('active');
        $(this).addClass('active');
    });
    $(document).on('change', '.theme-select-control[data-theme-value]', function () {
        var target = this.getAttribute('data-theme-value');
        if (target) $(target).val(this.value);
        if (target === '#admin-theme-style') applyThemeStyle(this.value, true);
    });
    $(document).on('change', '.theme-select-control[data-home-value]', function () {
        var target = this.getAttribute('data-home-value');
        if (target) $(target).val(this.value);
    });
    $(document).on('submit', '.theme-save-form', function () {
        var style = normalizeThemeStyle($(this).find('input[name$="_theme_style"]').val() || document.body.getAttribute('data-theme-style') || 'classic');
        applyThemeStyle(style, true);
    });

    function mobileMenuManagedExternally() {
        if ($('body').hasClass('admin-body')) {
            return true;
        }
        return window.SKY_MOBILE_MENU && typeof window.SKY_MOBILE_MENU.toggle === 'function';
    }

    function closeMobileMenu() {
        if (window.SKY_MOBILE_MENU && typeof window.SKY_MOBILE_MENU.close === 'function') {
            window.SKY_MOBILE_MENU.close();
            return;
        }
        $('.site-nav, .console-sidebar, .admin-sidebar').removeClass('open').attr('aria-hidden', 'true');
        $('.console-layout').removeClass('menu-open');
        $('body').removeClass('mobile-menu-open admin-mobile-drawer-open').attr('data-mobile-menu', 'closed');
        $('.mobile-menu-btn').attr('aria-expanded', 'false');
    }

    $('.mobile-menu-btn').on('click', function (e) {
        if (mobileMenuManagedExternally()) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();
        $('.site-nav, .console-sidebar, .admin-sidebar').toggleClass('open');
        $('.console-layout').toggleClass('menu-open');
        var opened = $('.console-layout').hasClass('menu-open');
        $('body').toggleClass('mobile-menu-open', opened).toggleClass('admin-mobile-drawer-open', opened && $('body').hasClass('admin-body')).attr('data-mobile-menu', opened ? 'open' : 'closed');
        $('.mobile-menu-btn').attr('aria-expanded', opened ? 'true' : 'false');
    });

    if (!mobileMenuManagedExternally() && !$('body').hasClass('cloud-home-body') && !$('.mobile-menu-mask').length) {
        $('body').append('<div class="mobile-menu-mask" aria-hidden="true"></div>');
    }
    $(document).on('click', '.mobile-menu-mask', function () {
        if (mobileMenuManagedExternally()) return;
        closeMobileMenu();
    });
    $(document).on('click', '.console-layout.menu-open .console-content, .console-layout.menu-open .console-topbar, .console-layout.menu-open main', function (e) {
        if (mobileMenuManagedExternally()) return;
        if ($(e.target).closest('.mobile-menu-btn, .site-nav, .console-sidebar, .admin-sidebar').length) {
            return;
        }
        if (window.innerWidth <= 900) {
            closeMobileMenu();
        }
    });
    $(window).on('resize', function () {
        if (!mobileMenuManagedExternally() && window.innerWidth > 900) closeMobileMenu();
    });
    $(document).on('keydown', function (e) {
        if (!mobileMenuManagedExternally() && e.key === 'Escape') closeMobileMenu();
    });

    function syncMobileActionPanels() {
        var mobile = window.innerWidth <= 920;
        $('.mobile-action-panel').each(function () {
            if (mobile) {
                if (!this.dataset.mobileReady) {
                    this.open = false;
                    this.dataset.mobileReady = '1';
                }
            } else {
                this.open = true;
                delete this.dataset.mobileReady;
            }
        });
    }

    syncMobileActionPanels();
    $(window).on('resize.mobilePanels', syncMobileActionPanels);

    var lastScrollTop = window.scrollY || 0;
    $(window).on('scroll.mobileNav', function () {
        if (window.innerWidth > 920) return;
        var currentTop = window.scrollY || 0;
        var goingDown = currentTop > lastScrollTop && currentTop > 120;
        $('body').toggleClass('mobile-nav-compact', goingDown);
        lastScrollTop = Math.max(0, currentTop);
    });

    $('.admin-menu-group').each(function () {
        var key = $(this).data('menu-key');
        if (!key || $(this).find('.admin-submenu a.active').length) return;
        var saved = localStorage.getItem(key);
        if (saved === '1') $(this).addClass('open');
        if (saved === '0') $(this).removeClass('open');
    });

    $(document).on('click', '.admin-menu-toggle', function () {
        var group = $(this).closest('.admin-menu-group');
        group.toggleClass('open');
        var key = group.data('menu-key');
        if (key) localStorage.setItem(key, group.hasClass('open') ? '1' : '0');
    });

    $('.admin-right-rail [data-admin-tool]').on('click', function () {
        var tool = $(this).data('admin-tool');
        if (tool === 'search') {
            var field = $('input[type="search"], input[name="keyword"], input[name="q"], input[placeholder*="搜索"]').filter(':visible').first();
            field.length ? field.focus() : showToast('当前页面没有可聚焦的搜索框。', 'info');
        }
        if (tool === 'favorite') {
            showToast('请使用浏览器收藏当前页面。', 'info');
        }
    });

    $('.fill-public-url').on('click', function () {
        var input = $('input[name="site_public_url"]').first();
        var base = (window.SKY_BASE_URL || '').replace(/\/$/, '');
        var origin = window.location.origin || (window.location.protocol + '//' + window.location.host);
        var value = /^https?:\/\//i.test(base) ? base : origin + base;
        input.val(value.replace(/\/$/, '')).focus().select();
    });

    $(document).on('focus click', '[data-auto-select]', function () {
        if (typeof this.select === 'function') this.select();
    });

    $(document).on('click', '[data-reload-page]', function () {
        window.location.reload();
    });

    enhanceIcons();
    markActiveNav();
    hydrateResponsiveTables();
    if ($('.repository-public-hero').length) {
        $('body').addClass('repository-public-body');
    }
    if ($('.cloud-home, .pro-home, .space-home').length) {
        $('body').addClass('cloud-home-body');
    }
    document.body.classList.add('page-ready');

    $(window).on('scroll', function () {
        var total = document.documentElement.scrollHeight - window.innerHeight;
        var pct = total > 0 ? (window.scrollY / total) * 100 : 0;
        $('.scroll-progress').css('width', pct + '%');
        $('.back-top').toggleClass('show', window.scrollY > 360);
    }).trigger('scroll');

    $('.back-top').on('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    var observer = window.IntersectionObserver ? new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) entry.target.classList.add('visible');
        });
    }, { threshold: 0.12 }) : null;
    document.querySelectorAll('.reveal').forEach(function (el) {
        if (observer) observer.observe(el); else el.classList.add('visible');
    });

    $('.drop-zone').on('dragenter dragover', function (e) {
        e.preventDefault();
        $(this).addClass('dragging');
    }).on('dragleave drop', function () {
        $(this).removeClass('dragging');
    });

    $(document).on('change', '.drop-zone input[type="file"]', function () {
        var input = this;
        var zone = $(input).closest('.drop-zone');
        var small = zone.find('small').first();
        if (!small.length) small = zone.children('small, span').first();
        if (!small.length) small = zone.find('.drop-zone-hint, .bm-drop-zone > span').first();
        if (!small.length) return;
        if (!small.data('defaultText')) small.data('defaultText', small.text());
        if (!input.files || !input.files.length) {
            small.text(small.data('defaultText'));
            return;
        }
        var total = 0;
        Array.prototype.forEach.call(input.files, function (file) { total += file.size || 0; });
        var sizeText = total >= 1024 * 1024 ? (total / 1024 / 1024).toFixed(2) + ' MB' : (total / 1024).toFixed(1) + ' KB';
        small.text('已选择 ' + input.files.length + ' 个文件，共 ' + sizeText + '。');
        zone.addClass('dragging');
        setTimeout(function () { zone.removeClass('dragging'); }, 500);
    });

    document.addEventListener('paste', function (e) {
        var fileInput = document.querySelector('.upload-form input[type=file]');
        if (!fileInput || !e.clipboardData || !e.clipboardData.files.length) return;
        fileInput.files = e.clipboardData.files;
        if (window.jQuery) $(fileInput).trigger('change');
        var zone = fileInput.closest('.drop-zone');
        if (zone) {
            zone.classList.add('dragging');
            setTimeout(function () { zone.classList.remove('dragging'); }, 500);
        }
    });

    function formatUploadSize(bytes) {
        bytes = Number(bytes || 0);
        if (bytes >= 1024 * 1024 * 1024) return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
        if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(2) + ' MB';
        if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return bytes + ' B';
    }

    function uploadScope(form, fileInput) {
        var action = String(form.attr('action') || '');
        var name = String(fileInput && fileInput.name || '');
        return action.indexOf('/files/upload') !== -1 || name.indexOf('images') !== -1 ? 'image' : 'file';
    }

    function uploadLimitsFor(scope) {
        var raw = window.SKY_UPLOAD_LIMITS || {};
        var concurrency = Math.max(1, Math.min(8, parseInt(raw.concurrency || 2, 10) || 2));
        var batch = scope === 'image' ? parseInt(raw.imageBatch || 20, 10) : parseInt(raw.fileBatch || 10, 10);
        return {
            concurrency: concurrency,
            batch: Math.max(1, batch || (scope === 'image' ? 20 : 10))
        };
    }

    function ensureUploadProgress(form) {
        var box = form.find('.upload-progress-box');
        if (!box.length) {
            box = $('<div class="upload-progress-box"><div class="upload-progress-top"><div class="upload-progress-visual" aria-hidden="true"><span></span><span></span><span></span></div><div class="upload-progress-head"><b>准备上传</b><span>0%</span></div></div><div class="upload-progress-bar"><i></i></div><div class="upload-progress-meta">等待选择文件</div><div class="upload-file-list"></div><div class="upload-progress-actions" hidden><button type="button" class="btn btn-primary upload-refresh-btn" data-icon="refresh-cw">刷新列表</button><button type="button" class="btn btn-ghost upload-clear-btn" data-icon="x">清空状态</button></div></div>');
            form.append(box);
        }
        return box;
    }

    function setUploadProgress(box, percent, text) {
        percent = Math.max(0, Math.min(100, Math.round(percent || 0)));
        box.find('.upload-progress-head b').text(text || '正在上传');
        box.find('.upload-progress-head span').text(percent + '%');
        box.find('.upload-progress-bar i').css('width', percent + '%');
        box.toggleClass('done', percent >= 100);
    }

    function parseUploadResponse(xhr) {
        var text = xhr.responseText || '';
        try {
            return JSON.parse(text);
        } catch (e) {
            if (xhr.status === 413) return { success: false, message: '上传内容超过服务器 post_max_size 限制，请减少文件数量或调大 PHP 配置。' };
            if (xhr.status === 419 || xhr.status === 403) return { success: false, message: '登录状态或表单令牌已失效，请刷新页面后重试。' };
            if (xhr.status >= 500) {
                return { success: false, message: text ? safeJsonMessage({ status: xhr.status || 500 }, text) : '服务器处理上传时出现内部异常，请查看 storage/logs 当天日志。' };
            }
            return { success: false, message: text ? safeJsonMessage({ status: xhr.status || 0 }, text) : '上传失败，服务器没有返回可读错误。' };
        }
    }

    function uploadDiagnosticText(res) {
        if (!res) return '';
        var parts = [];
        if (res.failed_stage_label || res.failed_stage) {
            parts.push('不通步骤：' + (res.failed_stage_label || res.failed_stage));
        }
        if (res.failed_stage_hint) {
            parts.push('原因方向：' + res.failed_stage_hint);
        }
        if (res.suggestion) {
            parts.push('建议处理：' + res.suggestion);
        }
        if (res.repair_url || res.storage_url) {
            parts.push('修复入口：' + (res.repair_url || res.storage_url));
        }
        return parts.join(' ');
    }

    function makeUploadFormData(formEl, fileInput, file) {
        var data = new FormData();
        Array.prototype.forEach.call(formEl.elements, function (el) {
            if (!el.name || el.disabled || el.type === 'file') return;
            if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
            data.append(el.name, el.value);
        });
        data.append('ajax_upload', '1');
        data.append(fileInput.name || 'files[]', file, file.name);
        return data;
    }

    function updateUploadSummary(box, state, totalBytes) {
        var done = state.success + state.failed;
        var fileRatio = state.total ? done / state.total : 0;
        var byteRatio = totalBytes > 0 ? state.loaded / totalBytes : 0;
        var percent = Math.round(((fileRatio * 0.72) + (byteRatio * 0.28)) * 100);
        if (done === state.total) percent = 100;
        var title = state.failed ? '部分文件上传失败' : (done === state.total ? '上传完成' : '正在上传');
        if (state.failed && !state.success && done === state.total) title = '上传失败';
        setUploadProgress(box, percent, title);
        box.find('.upload-progress-meta').text('共 ' + state.total + ' 个，成功 ' + state.success + ' 个，失败 ' + state.failed + ' 个，队列中 ' + Math.max(0, state.total - done - state.active) + ' 个。');
    }

    $('.upload-form').on('click', '.upload-refresh-btn', function () {
        window.location.reload();
    });

    $('.upload-form').on('click', '.upload-clear-btn', function () {
        var box = $(this).closest('.upload-progress-box');
        box.find('.upload-file-list').empty();
        box.find('.upload-progress-actions').prop('hidden', true);
        box.removeClass('done has-error is-running is-complete');
        setUploadProgress(box, 0, '准备上传');
        box.find('.upload-progress-meta').text('等待选择文件');
    });

    $(document).on('submit', '.upload-form', function (e) {
        var form = $(this);
        var fileInput = form.find('input[type="file"]').get(0);
        if (!fileInput || !fileInput.files || !fileInput.files.length || !window.FormData || !window.XMLHttpRequest) return;
        e.preventDefault();
        var submit = form.find('button[type="submit"]').first();
        var progress = ensureUploadProgress(form);
        var files = Array.prototype.slice.call(fileInput.files);
        var scope = uploadScope(form, fileInput);
        var limits = uploadLimitsFor(scope);
        if (files.length > limits.batch) {
            progress.removeClass('is-running is-complete').addClass('has-error');
            setUploadProgress(progress, 0, '超过单次数量限制');
            progress.find('.upload-progress-meta').text((scope === 'image' ? '图片' : '文件') + '单次最多上传 ' + limits.batch + ' 个，当前选择 ' + files.length + ' 个。');
            progress.find('.upload-file-list').empty();
            progress.find('.upload-progress-actions').prop('hidden', true);
            return;
        }

        var totalBytes = files.reduce(function (sum, file) { return sum + (file.size || 0); }, 0);
        var state = { total: files.length, success: 0, failed: 0, active: 0, loaded: 0 };
        var loadedByIndex = {};
        var nextIndex = 0;
        var rows = [];
        var formEl = form.get(0);
        progress.removeClass('done has-error is-complete').addClass('is-running');
        progress.find('.upload-file-list').empty();
        progress.find('.upload-progress-actions').prop('hidden', true);
        files.forEach(function (file, index) {
            var row = $('<article class="upload-file-row is-waiting"><div class="upload-file-main"><strong></strong><small></small></div><div class="upload-file-state">等待中</div><div class="upload-file-progress"><i></i></div><div class="upload-file-message"></div></article>');
            row.find('strong').text(file.name || ('文件 ' + (index + 1)));
            row.find('small').text(formatUploadSize(file.size || 0));
            progress.find('.upload-file-list').append(row);
            rows[index] = row;
        });

        submit.prop('disabled', true).addClass('is-loading');
        updateUploadSummary(progress, state, totalBytes);

        function finishOne(index, ok, message, res) {
            var row = rows[index];
            state.active = Math.max(0, state.active - 1);
            if (ok) {
                state.success += 1;
                row.removeClass('is-waiting is-running is-error').addClass('is-success');
                row.find('.upload-file-state').text('成功');
                row.find('.upload-file-progress i').css('width', '100%');
                var first = res && res.files && res.files[0] ? res.files[0] : null;
                if (first && first.url) {
                    row.find('.upload-file-message').empty()
                        .append($('<a></a>').attr({ href: first.url, target: '_blank', rel: 'noopener' }).text('打开文件'))
                        .append(' ')
                        .append($('<button type="button" class="upload-copy-link copy-text-btn"></button>').attr('data-copy-text', first.url).text('复制链接'));
                } else {
                    row.find('.upload-file-message').text('上传完成');
                }
            } else {
                state.failed += 1;
                progress.addClass('has-error');
                row.removeClass('is-waiting is-running is-success').addClass('is-error');
                row.find('.upload-file-state').text('失败');
                var diagnostic = uploadDiagnosticText(res);
                row.find('.upload-file-message').text((message || '上传失败') + (diagnostic ? ' ' + diagnostic : ''));
            }
            loadedByIndex[index] = files[index] ? files[index].size || 0 : 0;
            state.loaded = Object.keys(loadedByIndex).reduce(function (sum, key) { return sum + (loadedByIndex[key] || 0); }, 0);
            updateUploadSummary(progress, state, totalBytes);
            runNext();
        }

        function allDone() {
            return state.success + state.failed >= state.total;
        }

        function completeQueue() {
            submit.prop('disabled', false).removeClass('is-loading');
            progress.removeClass('is-running').toggleClass('is-complete', state.success > 0 && state.failed === 0);
            progress.find('.upload-progress-actions').prop('hidden', false);
            if (state.success && !state.failed) {
                setUploadProgress(progress, 100, '上传完成');
                progress.find('.upload-progress-meta').text('全部上传完成，已生成打开和复制入口。列表将在 3 秒后刷新。');
                setTimeout(function () { window.location.reload(); }, 3000);
            }
        }

        function runNext() {
            if (allDone()) {
                completeQueue();
                return;
            }
            while (state.active < limits.concurrency && nextIndex < files.length) {
                uploadOne(nextIndex++);
            }
        }

        function uploadOne(index) {
            var file = files[index];
            var row = rows[index];
            var xhr = new XMLHttpRequest();
            state.active += 1;
            row.removeClass('is-waiting is-error is-success').addClass('is-running');
            row.find('.upload-file-state').text('上传中');
            row.find('.upload-file-message').text('正在连接对象存储...');
            xhr.open((form.attr('method') || 'POST').toUpperCase(), form.attr('action'), true);
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xhr.setRequestHeader('Accept', 'application/json');
            xhr.upload.onprogress = function (event) {
                var loaded = event.lengthComputable ? event.loaded : Math.min(file.size || 0, loadedByIndex[index] || 0);
                loadedByIndex[index] = loaded;
                state.loaded = Object.keys(loadedByIndex).reduce(function (sum, key) { return sum + (loadedByIndex[key] || 0); }, 0);
                row.find('.upload-file-progress i').css('width', (event.lengthComputable ? Math.round(event.loaded / event.total * 100) : 35) + '%');
                row.find('.upload-file-message').text(event.lengthComputable ? ('已上传 ' + formatUploadSize(event.loaded) + ' / ' + formatUploadSize(event.total)) : '正在上传...');
                updateUploadSummary(progress, state, totalBytes);
            };
            xhr.onreadystatechange = function () {
                if (xhr.readyState !== 4) return;
                var res = parseUploadResponse(xhr);
                var ok = xhr.status >= 200 && xhr.status < 400 && res && res.success !== false;
                finishOne(index, ok, ok ? '上传成功' : (res && res.message ? res.message : '上传失败'), res);
            };
            xhr.onerror = function () {
                finishOne(index, false, '网络异常，上传未完成。', null);
            };
            xhr.send(makeUploadFormData(formEl, fileInput, file));
        }

        runNext();
    });

    function notifyButton(btn, text) {
        if (!btn || !btn.length) return;
        var oldText = btn.data('oldText') || btn.text();
        btn.data('oldText', oldText);
        setButtonText(btn, text);
        btn.addClass('copy-ok');
        setTimeout(function () {
            setButtonText(btn, oldText);
            btn.removeClass('copy-ok');
        }, 1200);
    }

    function copyText(text, btn, successText) {
        if (!text) return false;
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
                notifyButton(btn, successText || '已复制');
            }).catch(function () {
                showToast('复制失败，请手动选中内容复制。', 'error');
            });
            return true;
        }
        var tmp = $('<textarea readonly></textarea>').val(text).css({ position: 'fixed', left: '-9999px', top: '0' }).appendTo('body');
        tmp.get(0).select();
        try {
            document.execCommand('copy');
            notifyButton(btn, successText || '已复制');
        } catch (e) {
            showToast('复制失败，请手动选中内容复制。', 'error');
        }
        tmp.remove();
        return true;
    }

    $('.copy-selected').on('click', function () {
        var btn = $(this);
        var urls = [];
        $('input[name="ids[]"]:checked').each(function () { urls.push($(this).data('url')); });
        if (!urls.length) return showToast('请选择图片。', 'warning');
        copyText(urls.join('\n'), btn, '已复制');
    });

    $('.copy-current-inputs').on('click', function () {
        var btn = $(this);
        var values = [];
        var scope = btn.closest('.bm-copy-scope, .bm-card, .bm-admin-panel, .detail-panel, .image-card, .table-card, .file-row, .link-box, .repository-link-box, .share-link-cell');
        var selector = btn.data('copy-selector') || 'input[readonly], textarea[readonly]';
        scope.find(selector).each(function () { values.push($(this).val()); });
        if (!values.length) return showToast('没有可复制内容。', 'warning');
        copyText(values.join('\n'), btn, '已复制');
    });

    $(document).on('click', '.copy-text-btn', function () {
        var btn = $(this);
        copyText(btn.attr('data-copy-text') || '', btn, '已复制');
    });

    $('.native-share-btn').on('click', function () {
        var btn = $(this);
        var data = {
            title: btn.attr('data-share-title') || document.title,
            text: btn.attr('data-share-text') || '',
            url: btn.attr('data-share-url') || window.location.href
        };
        if (navigator.share) {
            navigator.share(data).catch(function () {});
            return;
        }
        copyText((data.text ? data.text + '\n' : '') + data.url, btn, '已复制');
    });

    $('.select-all').on('change', function () {
        $('input[data-group="' + $(this).data('target') + '"]').prop('checked', this.checked);
    });

    $(document).on('click', '.netdisk-batch-download-btn', function () {
        var form = $($(this).data('download-form') || '#batchDownloadForm');
        if (!form.length) return;
        var ids = [];
        $('input[data-group="netdisk-file"]:checked').each(function () {
            ids.push(this.value);
        });
        if (!ids.length) {
            showToast('请选择要下载的文件。', 'warning');
            return;
        }
        form.find('input[name="ids[]"]').remove();
        ids.forEach(function (id) {
            $('<input type="hidden" name="ids[]">').val(id).appendTo(form);
        });
        form.get(0).submit();
    });

    $(document).on('click', '.batch-download-start', function () {
        var btn = $(this);
        var items = $('.batch-download-item[data-download-url]');
        if (!items.length) {
            showToast('没有可下载文件，请检查文件链接或存储配置。', 'warning');
            return;
        }
        btn.prop('disabled', true).addClass('is-loading');
        setButtonText(btn, '正在触发');
        var index = 0;
        var blocked = 0;
        function next() {
            if (index >= items.length) {
                btn.prop('disabled', false).removeClass('is-loading');
                setButtonText(btn, blocked ? '部分被拦截' : '已全部触发');
                if (blocked) {
                    showToast('浏览器可能拦截了部分下载窗口，请使用下方逐个下载或复制全部链接。', 'warning', 5200);
                }
                return;
            }
            var item = $(items[index]);
            var state = item.find('.batch-download-state');
            var url = item.data('download-url');
            state.removeClass('muted danger ok').addClass('soft').text('触发中');
            var opened = window.open(url, '_blank', 'noopener');
            if (!opened) {
                blocked += 1;
                state.removeClass('soft ok').addClass('danger').text('被拦截');
            } else {
                state.removeClass('soft danger').addClass('ok').text('已触发');
            }
            index += 1;
            setTimeout(next, 720);
        }
        next();
    });

    $(document).on('change', '.bm-payment-card input[type="radio"], .payment-method-card input[type="radio"]', function () {
        var name = this.name;
        $('input[type="radio"][name="' + name + '"]').closest('.bm-payment-card, .payment-method-card').removeClass('active');
        $(this).closest('.bm-payment-card, .payment-method-card').addClass('active');
    });

    $(document).on('click', '.btn, .bm-btn, .icon-btn, .admin-nav a, .site-nav a, .console-nav a, .context-menu button', function (e) {
        if (document.body && document.body.getAttribute('data-ui-motion') !== 'ripple') return;
        var target = $(this);
        var offset = target.offset();
        if (!offset) return;
        var ripple = $('<span class="click-ripple"></span>');
        var size = Math.max(target.outerWidth(), target.outerHeight());
        ripple.css({ width: size, height: size, left: e.pageX - offset.left - size / 2, top: e.pageY - offset.top - size / 2 });
        target.append(ripple);
        setTimeout(function () { ripple.remove(); }, 520);
    });

    $(document).on('submit', 'form:not(.confirm-form):not(.inline-confirm-form):not(.upload-form)', function () { markFormLoading($(this)); });
    $(document).on('submit', '.confirm-form, .inline-confirm-form', function (e) {
        var form = $(this);
        if (form.data('confirmed') === '1') {
            markFormLoading(form);
            return true;
        }
        var requiredGroup = form.data('require-selection');
        if (requiredGroup && !$('input[data-group="' + requiredGroup + '"]:checked').length) {
            showToast(form.data('selection-message') || '请先选择要操作的项目。', 'warning');
            e.preventDefault();
            return false;
        }
        e.preventDefault();
        showConfirm(form.data('confirm') || '确定执行该操作吗？').then(function (ok) {
            if (!ok) return;
            form.data('confirmed', '1');
            markFormLoading(form);
            form.get(0).submit();
        });
        return false;
    });

    $('.send-code-btn').on('click', function () {
        var btn = $(this);
        var email = $('input[name="email"]').val();
        setButtonText(btn.prop('disabled', true), '发送中');
        $.post(api('/email-code'), { email: email, scene: btn.data('scene'), _token: btn.data('token') })
            .done(function (res) { showToast(res.message || '验证码已发送。', 'success'); })
            .fail(function (xhr) { showToast(ajaxErrorMessage(xhr, '发送失败'), 'error'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '发送'); });
    });

    $('.context-menu [data-action]').on('click', function () {
        var action = $(this).data('action');
        $('.context-menu').hide();
        if (action === 'refresh') location.reload();
        if (action === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
        if (action === 'theme') toggleTheme();
    });

    $(document).on('contextmenu', function (e) {
        if ($(e.target).closest('input,textarea,select').length) return;
        e.preventDefault();
        $('.context-menu').css({ left: e.clientX, top: e.clientY }).show();
    }).on('click', function () { $('.context-menu').hide(); });

    $('.collect-btn').on('click', function () {
        var btn = $(this);
        setButtonText(btn.prop('disabled', true), '采集中');
        $.post(api('/monitor/collect'), { id: btn.data('id'), _token: btn.data('token') })
            .done(function (res) { showToast(res.message || '采集完成。', 'success'); setTimeout(function () { location.reload(); }, 650); })
            .fail(function (xhr) { showToast(ajaxErrorMessage(xhr, '采集失败'), 'error'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '立即采集'); });
    });

    $(document).on('click', '.server-collect-btn', function () {
        var btn = $(this);
        setButtonText(btn.prop('disabled', true), '采集中');
        $.ajax({
            url: api('/servers/collect'),
            method: 'POST',
            data: { id: btn.data('id'), _token: btn.data('token') },
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        })
            .done(function (res) { showToast(res.message || '采集完成。', 'success'); setTimeout(function () { location.reload(); }, 650); })
            .fail(function (xhr) { showToast(ajaxErrorMessage(xhr, '采集失败'), 'error'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '立即采集'); });
    });

    $('.monitor-test-btn').on('click', function () {
        var btn = $(this), form = btn.closest('form');
        setButtonText(btn.prop('disabled', true), '测试中');
        var endpoint = form.attr('action') && form.attr('action').indexOf('/admin/monitors/save') !== -1 ? '/admin/monitors/test' : '/monitor/test';
        $.post(api(endpoint), form.serialize() + '&_token=' + encodeURIComponent(btn.data('token')))
            .done(function (res) { showToast((res && res.message) || '连接成功。', res && res.success === false ? 'warning' : 'success'); })
            .fail(function (xhr) { showToast(ajaxErrorMessage(xhr, '连接失败'), 'error'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '测试连接'); });
    });

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char];
        });
    }

    function renderStorageChecks(res) {
        var ok = !!(res && res.success);
        var partial = !!(res && res.partial_success);
        var checks = res && Array.isArray(res.checks) ? res.checks : [];
        var failedStage = (res && (res.failed_stage_label || res.failed_stage)) || '';
        var failedStageHint = (res && res.failed_stage_hint) || '';
        var nextAction = (res && res.next_action) || '';
        var docsUrl = (res && res.docs_url) || '';
        var repairUrl = (res && (res.repair_url || res.storage_url)) || '';
        var technical = (res && res.technical_message) || '';
        var publicUrl = (res && (res.public_url || res.url)) || '';
        var objectKey = (res && res.object_key) || '';
        var title = ok ? '测试通过' : (partial ? '部分通过' : '测试失败');
        var html = '<div class="storage-test-summary"><b>' + title + '</b><span>' + escapeHtml((res && res.message) || '') + '</span></div>';
        var meta = [];
        if (res && res.upload_ms) meta.push('上传耗时 ' + escapeHtml(res.upload_ms) + 'ms');
        if (objectKey) meta.push('对象路径 ' + escapeHtml(objectKey));
        if (publicUrl) meta.push('外链已生成');
        if (meta.length) {
            html += '<div class="storage-test-meta">' + meta.map(function (item) { return '<span>' + item + '</span>'; }).join('') + '</div>';
        }
        if (!ok && failedStage) {
            html += '<div class="storage-test-diagnosis"><b>当前不通步骤：' + escapeHtml(failedStage) + '</b>';
            if (failedStageHint) html += '<span>原因方向：' + escapeHtml(failedStageHint) + '</span>';
            if (nextAction) html += '<span>建议检查：' + escapeHtml(nextAction) + '</span>';
            if (repairUrl) html += '<a href="' + escapeHtml(repairUrl) + '">进入修复页面</a>';
            if (docsUrl) html += '<a href="' + escapeHtml(docsUrl) + '" target="_blank" rel="noopener">查看官方接口文档</a>';
            html += '</div>';
        } else if (ok && nextAction) {
            html += '<div class="storage-test-diagnosis ok"><b>下一步</b><span>' + escapeHtml(nextAction) + '</span>';
            if (docsUrl) html += '<a href="' + escapeHtml(docsUrl) + '" target="_blank" rel="noopener">查看官方接口文档</a>';
            html += '</div>';
        }
        if (technical) {
            html += '<div class="storage-test-technical"><b>技术细节</b><code>' + escapeHtml(technical) + '</code></div>';
        }
        if (checks.length) {
            html += '<div class="storage-test-steps">';
            checks.forEach(function (item, index) {
                var status = item.status || 'warn';
                var label = item.label || ('步骤 ' + (index + 1));
                var message = item.message || '';
                var hint = item.hint || '';
                var url = item.url || '';
                var itemDocsUrl = item.docs_url || '';
                var stepMeta = [];
                if (item.method) stepMeta.push('方法 ' + item.method);
                if (item.http_code || item.http_code === 0) stepMeta.push('HTTP ' + item.http_code);
                if (item.upload_ms) stepMeta.push(item.upload_ms + 'ms');
                if (item.object_key) stepMeta.push('路径 ' + item.object_key);
                html += '<div class="storage-test-step ' + escapeHtml(status) + '">';
                html += '<i>' + (index + 1) + '</i>';
                html += '<div><b>' + escapeHtml(label) + '</b>';
                if (stepMeta.length) html += '<em>' + stepMeta.map(escapeHtml).join(' · ') + '</em>';
                if (message) html += '<span>' + escapeHtml(message) + '</span>';
                if (hint) html += '<small>' + escapeHtml(hint) + '</small>';
                if (item.technical_message) html += '<code>' + escapeHtml(item.technical_message) + '</code>';
                if (url) html += '<a href="' + escapeHtml(url) + '" target="_blank" rel="noopener">打开测试链接</a>';
                if (itemDocsUrl) html += '<a href="' + escapeHtml(itemDocsUrl) + '" target="_blank" rel="noopener">官方文档</a>';
                html += '</div></div>';
            });
            html += '</div>';
        }
        return html;
    }

    $('.storage-test-btn').on('click', function () {
        var btn = $(this);
        var id = btn.data('id');
        var box = $('#storage-test-result-' + id + ' .storage-test-result');
        box.removeClass('ok warn error muted').addClass('warn').html('<div class="storage-test-summary"><b>测试中</b><span>正在按步骤检查：基础配置、上传、访问链接、删除权限。</span></div>');
        setButtonText(btn.prop('disabled', true), '测试中');
        $.post(api('/admin/storages/test'), { id: id, _token: btn.data('token') })
            .done(function (res) {
                var ok = res && res.success;
                box.removeClass('ok warn error muted').addClass(ok ? 'ok' : 'error').html(renderStorageChecks(res));
            })
            .fail(function (xhr) {
                var msg = ajaxErrorMessage(xhr, '测试失败');
                var payload = (xhr && xhr.responseJSON) ? xhr.responseJSON : {};
                var failedStage = payload.failed_stage || payload.stage || (payload.error_type === 'schema' ? 'database' : 'request');
                var failedLabel = payload.failed_stage_label || (payload.error_type === 'schema' ? '数据库结构' : '请求接口');
                var failedHint = payload.failed_stage_hint || payload.suggestion || (payload.repair_url ? '请进入修复页面处理后重试。' : '请检查后台登录状态、CSRF Token、服务器网络或 PHP 错误日志。');
                box.removeClass('ok warn error muted').addClass('error').html(renderStorageChecks({
                    success: false,
                    message: msg,
                    failed_stage: failedStage,
                    failed_stage_label: failedLabel,
                    failed_stage_hint: failedHint,
                    next_action: payload.next_action || payload.suggestion || '',
                    repair_url: payload.repair_url || payload.storage_url || '',
                    docs_url: payload.docs_url || '',
                    technical_message: payload.technical_message || '',
                    error_type: payload.error_type || 'request',
                    checks: [{
                        key: failedStage,
                        label: failedLabel,
                        status: 'fail',
                        message: msg,
                        hint: failedHint,
                        docs_url: payload.docs_url || ''
                    }]
                }));
            })
            .always(function () { setButtonText(btn.prop('disabled', false), '真实测试'); });
    });

    $(document).on('click', '.quick-amount', function (e) {
        e.preventDefault();
        var amount = $(this).data('amount');
        var form = $(this).closest('form');
        var input = form.find('input[name="amount"]');
        if (!input.length) input = $('#rechargeAmount');
        input.val(amount).trigger('input').trigger('change').focus();
        form.find('.quick-amount').removeClass('active');
        $(this).addClass('active');
    });

    $('.payment-method-card input[type="radio"]').on('change', function () {
        $('.payment-method-card').removeClass('active');
        $(this).closest('.payment-method-card').addClass('active');
    });

    function activeEditor() {
        var editor = document.getElementById('announcementEditor');
        return editor && editor.tagName === 'TEXTAREA' ? editor : null;
    }

    function insertIntoEditor(text, wrap) {
        var editor = activeEditor();
        if (!editor) return;
        var start = editor.selectionStart || 0;
        var end = editor.selectionEnd || 0;
        var value = editor.value || '';
        var selected = value.substring(start, end);
        var output = text;
        var caretOffset = text.length;
        if (wrap) {
            output = wrap.replace('|', selected || text);
            caretOffset = selected ? output.length : output.indexOf(text) + text.length;
        }
        editor.value = value.substring(0, start) + output + value.substring(end);
        editor.focus();
        var cursor = start + Math.max(0, caretOffset);
        editor.setSelectionRange(cursor, cursor);
        $(editor).trigger('input');
    }

    $(document).on('click', '[data-editor-insert]', function () {
        insertIntoEditor($(this).attr('data-editor-insert') || '', null);
    });

    $(document).on('click', '[data-editor-wrap]', function () {
        insertIntoEditor('文字内容', $(this).attr('data-editor-wrap') || '|');
    });

    $(document).on('click', '[data-editor-preview]', function () {
        var editor = activeEditor();
        var preview = document.getElementById('announcementPreview');
        if (!editor || !preview) return;
        var visible = !preview.hasAttribute('hidden');
        if (visible) {
            preview.setAttribute('hidden', 'hidden');
            $(this).removeClass('active');
            return;
        }
        var mode = $('select[name="content_format"]').val() || 'html';
        var content = editor.value || '';
        preview.innerHTML = mode === 'plain'
            ? $('<div>').text(content).html().replace(/\n/g, '<br>')
            : content;
        preview.removeAttribute('hidden');
        $(this).addClass('active');
    });

    $(document).on('input', '#announcementEditor', function () {
        var preview = document.getElementById('announcementPreview');
        if (!preview || preview.hasAttribute('hidden')) return;
        var mode = $('select[name="content_format"]').val() || 'html';
        var content = this.value || '';
        preview.innerHTML = mode === 'plain'
            ? $('<div>').text(content).html().replace(/\n/g, '<br>')
            : content;
    });

    function renderMonitorChart() {
        var el = document.getElementById('monitorChart');
        if (!el || typeof echarts === 'undefined') return;
        var chart = echarts.init(el);
        function load() {
            $.get(api('/monitor/' + el.dataset.server + '/metrics'), { range: $('#rangeSelect').val() || '1h' }, function (res) {
                var rows = res.data || [];
                chart.setOption({
                    tooltip: { trigger: 'axis' },
                    legend: { data: ['CPU', '内存', '磁盘'] },
                    grid: { left: 40, right: 24, top: 48, bottom: 36 },
                    xAxis: { type: 'category', data: rows.map(function (r) { return r.created_at; }) },
                    yAxis: { type: 'value', max: 100 },
                    series: [
                        { name: 'CPU', type: 'line', smooth: true, data: rows.map(function (r) { return Number(r.cpu_usage); }) },
                        { name: '内存', type: 'line', smooth: true, data: rows.map(function (r) { return Number(r.memory_usage); }) },
                        { name: '磁盘', type: 'line', smooth: true, data: rows.map(function (r) { return Number(r.disk_usage); }) }
                    ]
                });
            });
        }
        $('#rangeSelect').on('change', load);
        load();
        window.addEventListener('resize', function () { chart.resize(); });
    }

    renderMonitorChart();
})();
