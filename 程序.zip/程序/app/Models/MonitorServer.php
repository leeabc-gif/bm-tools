<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class MonitorServer extends Model
{
    protected $table = 'monitor_servers';

    public function userServers($userId)
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' WHERE user_id = ? AND monitor_type IN (?, ?) ORDER BY id DESC', [$userId, 'ssh', 'agent']);
    }

    public function enabledDue()
    {
        return Database::fetchAll(
            'SELECT * FROM ' . $this->table() . ' WHERE monitor_type = ? AND is_enabled = 1 AND (last_checked_at IS NULL OR TIMESTAMPDIFF(SECOND, last_checked_at, NOW()) >= frequency)',
            ['bt']
        );
    }
}
