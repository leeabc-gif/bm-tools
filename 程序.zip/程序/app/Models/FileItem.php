<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class FileItem extends Model
{
    protected $table = 'files';

    public function userFiles($userId, $type = null, $folderId = null)
    {
        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE user_id = ?';
        $params = [$userId];
        if ($type) {
            $sql .= ' AND file_type = ?';
            $params[] = $type;
        }
        if ($folderId !== null) {
            $sql .= ' AND folder_id = ?';
            $params[] = (int) $folderId;
        }
        $sql .= ' ORDER BY id DESC';
        return Database::fetchAll($sql, $params);
    }

    public function searchUserFiles($userId, $type = null, $folderId = null, $keyword = '', $dateStart = '', $dateEnd = '', $category = '')
    {
        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE user_id = ?';
        $params = [$userId];
        if ($type) {
            $sql .= ' AND file_type = ?';
            $params[] = $type;
        }
        if ($folderId !== null) {
            $sql .= ' AND folder_id = ?';
            $params[] = (int) $folderId;
        }
        if ($keyword !== '') {
            $sql .= ' AND (original_name LIKE ? OR file_name LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        if ($dateStart !== '') {
            $sql .= ' AND created_at >= ?';
            $params[] = $dateStart . ' 00:00:00';
        }
        if ($dateEnd !== '') {
            $sql .= ' AND created_at <= ?';
            $params[] = $dateEnd . ' 23:59:59';
        }
        if ($category !== '') {
            $category = strtolower($category);
            if ($category === 'image') {
                $sql .= " AND (file_type = 'image' OR mime_type LIKE 'image/%' OR file_ext IN ('jpg','jpeg','png','gif','webp','bmp'))";
            } elseif ($category === 'document') {
                $sql .= " AND file_type = 'file' AND file_ext IN ('pdf','doc','docx','xls','xlsx','ppt','pptx','txt','md','csv')";
            } elseif ($category === 'archive') {
                $sql .= " AND file_type = 'file' AND file_ext IN ('zip','rar','7z','tar','gz','bz2')";
            } elseif ($category === 'video') {
                $sql .= " AND file_type = 'file' AND (mime_type LIKE 'video/%' OR file_ext IN ('mp4','mov','mkv','avi','webm','flv'))";
            } elseif ($category === 'audio') {
                $sql .= " AND file_type = 'file' AND (mime_type LIKE 'audio/%' OR file_ext IN ('mp3','wav','flac','aac','ogg','m4a'))";
            } elseif ($category === 'other') {
                $sql .= " AND file_type = 'file' AND file_ext NOT IN ('pdf','doc','docx','xls','xlsx','ppt','pptx','txt','md','csv','zip','rar','7z','tar','gz','bz2','mp4','mov','mkv','avi','webm','flv','mp3','wav','flac','aac','ogg','m4a')";
            }
        }
        $sql .= ' ORDER BY id DESC LIMIT 300';
        return Database::fetchAll($sql, $params);
    }
}
