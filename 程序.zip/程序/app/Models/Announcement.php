<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Announcement extends Model
{
    protected $table = 'announcements';

    public static function categories()
    {
        return [
            'platform' => ['name' => '平台公告', 'icon' => 'megaphone', 'desc' => '平台运营、服务变更、维护通知'],
            'system' => ['name' => '系统公告', 'icon' => 'bell-ring', 'desc' => '系统升级、安全提醒、故障说明'],
            'help' => ['name' => '平台帮助', 'icon' => 'circle-help', 'desc' => '常见问题、功能说明、使用帮助'],
            'tutorial' => ['name' => '平台教程', 'icon' => 'book-open-check', 'desc' => '图床、网盘、API、对象存储教程'],
            'docs' => ['name' => '站点文档', 'icon' => 'file-text', 'desc' => '服务条款、隐私政策、关于我们等固定说明'],
        ];
    }

    public static function documentTemplates()
    {
        return [
            'imgurl-links' => [
                'title' => 'ImgURL和图链',
                'summary' => '了解 ImgURL 的图链能力、适用场景和基础使用方式。',
                'icon' => 'link-2',
                'content' => '<h2>ImgURL 和图链</h2><p>ImgURL 提供图片上传、图链生成、格式复制和资源管理能力，适合博客写作、内容发布、项目文档和日常素材归档。</p><p>上传图片后，系统会生成直链、Markdown、HTML、BBCode 等常用引用格式，便于在不同平台快速使用。</p>',
            ],
            'terms' => [
                'title' => 'ImgURL 服务条款',
                'summary' => '查看平台使用规则、内容规范和账号责任说明。',
                'icon' => 'scroll-text',
                'content' => '<h2>服务条款</h2><p>使用本站服务前，请确认你已了解并同意平台规则。用户应保证上传内容合法合规，不得上传侵权、违法、恶意或影响平台稳定运行的内容。</p><p>平台会根据法律法规、服务安全和运营需要，对违规内容进行处理。</p>',
            ],
            'about' => [
                'title' => '关于我们',
                'summary' => '了解平台定位、核心能力和长期维护方向。',
                'icon' => 'badge-info',
                'content' => '<h2>关于我们</h2><p>我们希望提供一个简洁、稳定、易用的图片与资源管理工具，让创作者、站长和开发者可以更高效地管理图片、生成外链并维护自己的内容资产。</p>',
            ],
            'privacy' => [
                'title' => 'ImgURL 隐私政策',
                'summary' => '了解账号信息、上传记录和访问数据的使用与保护方式。',
                'icon' => 'shield-check',
                'content' => '<h2>隐私政策</h2><p>平台会在提供基础服务所必需的范围内处理账号信息、上传记录、访问日志等数据，用于身份识别、安全审计、服务优化和故障排查。</p><p>我们会尽力采取合理措施保护用户数据安全，并避免无关的数据收集。</p>',
            ],
        ];
    }

    public function siteDocuments($onlyVisible = true)
    {
        $documents = [];
        $templates = self::documentTemplates();
        if (!$onlyVisible) {
            foreach ($templates as $key => $template) {
                $documents[$key] = array_merge($template, [
                    'key' => $key,
                    'id' => null,
                    'url' => url('announcements?category=docs'),
                    'published_at' => '',
                    'created_at' => '',
                ]);
            }
        }

        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE category = ?';
        $params = ['docs'];
        if ($onlyVisible) {
            $sql .= ' AND status = 1 AND (published_at IS NULL OR published_at <= ?)';
            $params[] = now();
        }
        $sql .= ' ORDER BY FIELD(title, ?, ?, ?, ?), id ASC';
        foreach ($templates as $template) {
            $params[] = $template['title'];
        }

        foreach (Database::fetchAll($sql, $params) as $row) {
            foreach ($templates as $key => $template) {
                if ($row['title'] === $template['title']) {
                    $documents[$key] = array_merge($template, $row, [
                        'key' => $key,
                        'icon' => $template['icon'],
                        'url' => url('announcements/' . $row['id']),
                    ]);
                    break;
                }
            }
        }

        $ordered = [];
        foreach (array_keys($templates) as $key) {
            if (isset($documents[$key])) {
                $ordered[] = $documents[$key];
            }
        }
        return $ordered;
    }

    public function visible($limit = null, $homeOnly = false)
    {
        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE status = 1 AND (published_at IS NULL OR published_at <= ?)';
        $params = [now()];
        if ($homeOnly) {
            $sql .= ' AND show_home = 1';
        }
        $sql .= ' ORDER BY is_top DESC, published_at DESC, id DESC';
        if ($limit) {
            $sql .= Database::limitClause($limit, 1, 100);
        }
        return Database::fetchAll($sql, $params);
    }

    public function visibleByCategory($category = '', $keyword = '', $limit = null)
    {
        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE status = 1 AND (published_at IS NULL OR published_at <= ?)';
        $params = [now()];
        if ($category !== '' && isset(self::categories()[$category])) {
            $sql .= ' AND category = ?';
            $params[] = $category;
        }
        if ($keyword !== '') {
            $sql .= ' AND (title LIKE ? OR summary LIKE ? OR tags LIKE ? OR content LIKE ?)';
            $like = '%' . $keyword . '%';
            array_push($params, $like, $like, $like, $like);
        }
        $sql .= ' ORDER BY is_top DESC, published_at DESC, id DESC';
        if ($limit) {
            $sql .= Database::limitClause($limit, 1, 100);
        }
        return Database::fetchAll($sql, $params);
    }

    public function categoryCounts()
    {
        $rows = Database::fetchAll('SELECT category, COUNT(*) AS c FROM ' . $this->table() . ' WHERE status = 1 AND (published_at IS NULL OR published_at <= ?) GROUP BY category', [now()]);
        $counts = ['all' => 0];
        foreach (array_keys(self::categories()) as $key) {
            $counts[$key] = 0;
        }
        foreach ($rows as $row) {
            $key = $row['category'] ?: 'platform';
            if (!isset($counts[$key])) {
                $counts[$key] = 0;
            }
            $counts[$key] = (int) $row['c'];
            $counts['all'] += (int) $row['c'];
        }
        return $counts;
    }

    public function incrementViews($id)
    {
        Database::execute('UPDATE ' . $this->table() . ' SET view_count = view_count + 1 WHERE id = ?', [(int) $id]);
    }
}
