<?php
namespace App\Core;

class Csrf
{
    public static function token()
    {
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf_token'];
    }

    public static function rotate()
    {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        return $_SESSION['_csrf_token'];
    }

    public static function clear()
    {
        unset($_SESSION['_csrf_token']);
    }

    public static function verify($token)
    {
        return is_string($token) && hash_equals(self::token(), $token);
    }
}
