<?php
namespace App\Core;

use PDO;
use PDOException;

class Database
{
    protected static $pdo;
    protected static $prefix;

    public static function getInstance()
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $configPath = APP_ROOT . '/config/database.php';
        if (!is_file($configPath)) {
            throw new \RuntimeException('数据库配置不存在，请先完成安装。');
        }

        $config = require $configPath;
        self::$prefix = isset($config['prefix']) ? $config['prefix'] : 'bm_';
        $charset = isset($config['charset']) ? $config['charset'] : 'utf8mb4';
        $dsn = 'mysql:host=' . $config['host'] . ';port=' . $config['port'] . ';dbname=' . $config['database'] . ';charset=' . $charset;

        try {
            self::$pdo = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            throw new \RuntimeException('数据库连接失败：' . $e->getMessage());
        }

        return self::$pdo;
    }

    public static function connectionFromConfig(array $override)
    {
        $configPath = APP_ROOT . '/config/database.php';
        if (!is_file($configPath)) {
            throw new \RuntimeException('数据库配置不存在，请先完成安装。');
        }

        $config = require $configPath;
        $config = array_merge($config, $override);
        $charset = isset($config['charset']) ? $config['charset'] : 'utf8mb4';
        $dsn = 'mysql:host=' . $config['host'] . ';port=' . $config['port'] . ';dbname=' . $config['database'] . ';charset=' . $charset;

        try {
            return new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            throw new \RuntimeException('临时数据库管理员账号连接失败：' . $e->getMessage());
        }
    }

    public static function swapConnection(PDO $pdo)
    {
        self::$pdo = $pdo;
    }

    public static function resetConnection()
    {
        self::$pdo = null;
    }

    public static function prefix()
    {
        if (self::$prefix === null) {
            $configPath = APP_ROOT . '/config/database.php';
            if (is_file($configPath)) {
                $config = require $configPath;
                self::$prefix = isset($config['prefix']) ? $config['prefix'] : 'bm_';
            } else {
                self::$prefix = 'bm_';
            }
        }
        return self::$prefix;
    }

    public static function table($table)
    {
        return self::prefix() . self::validateIdentifier($table, 'table');
    }

    public static function placeholders($count)
    {
        $count = max(0, (int) $count);
        return implode(',', array_fill(0, $count, '?'));
    }

    public static function limitClause($limit, $min = 1, $max = 500, $default = null)
    {
        if ($default === null) {
            $default = $min;
        }
        $min = max(0, (int) $min);
        $max = max($min, (int) $max);
        $limit = (int) $limit;
        if ($limit < $min) {
            $limit = (int) $default;
        }
        $limit = max($min, min($max, $limit));
        return ' LIMIT ' . $limit;
    }

    public static function offsetLimitClause($offset, $limit, $maxLimit = 500)
    {
        $offset = max(0, (int) $offset);
        $limit = max(1, min((int) $maxLimit, (int) $limit));
        return ' LIMIT ' . $offset . ',' . $limit;
    }

    public static function orderByClause($order, $default = 'id DESC')
    {
        $order = trim((string) $order);
        if ($order === '') {
            $order = $default;
        }
        $parts = [];
        foreach (explode(',', $order) as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            if (!preg_match('/^([A-Za-z0-9_]+)(?:\s+(ASC|DESC))?$/i', $part, $match)) {
                throw new \InvalidArgumentException('Invalid ORDER BY fragment: ' . $part);
            }
            $direction = isset($match[2]) && $match[2] !== '' ? strtoupper($match[2]) : 'ASC';
            $parts[] = self::validateIdentifier($match[1], 'column') . ' ' . $direction;
        }
        if (!$parts) {
            return self::orderByClause($default, 'id DESC');
        }
        return ' ORDER BY ' . implode(', ', $parts);
    }

    public static function validateIdentifier($identifier, $label = 'identifier')
    {
        $identifier = (string) $identifier;
        if (!preg_match('/^[A-Za-z0-9_]+$/', $identifier)) {
            throw new \InvalidArgumentException('Invalid database ' . $label . ': ' . $identifier);
        }
        return $identifier;
    }

    public static function tableExists($table)
    {
        $table = self::validateIdentifier(trim((string) $table, '` '), 'table');
        return (bool) self::fetch(
            'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1',
            [$table]
        );
    }

    public static function columnInfo($table, $column)
    {
        $table = self::validateIdentifier(trim((string) $table, '` '), 'table');
        $column = self::validateIdentifier(trim((string) $column, '` '), 'column');
        return self::fetch(
            'SELECT COLUMN_NAME AS Field, COLUMN_TYPE AS Type, IS_NULLABLE AS `Null`, COLUMN_KEY AS `Key`, COLUMN_DEFAULT AS `Default`, EXTRA AS Extra
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
             LIMIT 1',
            [$table, $column]
        );
    }

    public static function columnExists($table, $column)
    {
        return (bool) self::columnInfo($table, $column);
    }

    public static function indexExists($table, $index)
    {
        $table = self::validateIdentifier(trim((string) $table, '` '), 'table');
        $index = trim((string) $index, '` ');
        if ($index === '') {
            return false;
        }
        return (bool) self::fetch(
            'SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1',
            [$table, $index]
        );
    }

    public static function query($sql, array $params = [])
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function fetch($sql, array $params = [])
    {
        $stmt = self::query($sql, $params);
        $row = $stmt->fetch();
        return $row ? $row : null;
    }

    public static function fetchAll($sql, array $params = [])
    {
        return self::query($sql, $params)->fetchAll();
    }

    public static function execute($sql, array $params = [])
    {
        return self::query($sql, $params)->rowCount();
    }

    public static function lastInsertId()
    {
        return self::getInstance()->lastInsertId();
    }

    public static function begin()
    {
        self::getInstance()->beginTransaction();
    }

    public static function commit()
    {
        self::getInstance()->commit();
    }

    public static function rollBack()
    {
        if (self::getInstance()->inTransaction()) {
            self::getInstance()->rollBack();
        }
    }
}
