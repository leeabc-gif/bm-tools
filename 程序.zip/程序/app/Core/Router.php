<?php
namespace App\Core;

class Router
{
    protected static $routes = [
        'GET' => [
            '/' => 'HomeController@index',
            '/status' => 'HomeController@status',
            '/install' => 'InstallController@index',
            '/install/success' => 'InstallController@success',
            '/login' => 'AuthController@login',
            '/register' => 'AuthController@register',
            '/forgot' => 'AuthController@forgot',
            '/logout' => 'AuthController@logout',
            '/m' => 'MobileController@dashboard',
            '/m/dashboard' => 'MobileController@dashboard',
            '/m/files' => 'MobileController@files',
            '/m/files/detail' => 'MobileController@fileDetail',
            '/m/netdisk' => 'MobileController@netdisk',
            '/m/repository' => 'MobileController@repositories',
            '/m/subsites' => 'MobileController@subsites',
            '/m/teams' => 'MobileController@teams',
            '/m/servers' => 'MobileController@servers',
            '/m/servers/create' => 'MobileController@serverForm',
            '/m/servers/commands' => 'MobileController@serverCommands',
            '/m/orders' => 'MobileController@orders',
            '/m/balance' => 'MobileController@balanceLogs',
            '/m/balance/logs' => 'MobileController@balanceLogs',
            '/m/recharge' => 'MobileController@recharge',
            '/m/cards' => 'MobileController@cards',
            '/m/packages' => 'MobileController@packages',
            '/m/api' => 'MobileController@apiConsole',
            '/m/alerts' => 'MobileController@alerts',
            '/m/notifications' => 'MobileController@notifications',
            '/m/profile' => 'MobileController@profile',
            '/m/profile/edit' => 'MobileController@editProfile',
            '/m/password' => 'MobileController@password',
            '/m/menu' => 'MobileController@menu',
            '/user' => 'UserController@dashboard',
            '/user/center' => 'UserController@dashboard',
            '/user/dashboard' => 'UserController@dashboard',
            '/console' => 'UserController@dashboard',
            '/dashboard' => 'UserController@dashboard',
            '/profile' => 'UserController@profile',
            '/theme' => 'UserController@theme',
            '/password' => 'UserController@password',
            '/packages' => 'PackageController@index',
            '/recharge' => 'RechargeController@index',
            '/cards' => 'CardController@index',
            '/balance/logs' => 'RechargeController@balanceLogs',
            '/orders' => 'RechargeController@orders',
            '/pay/alipay/notify' => 'PaymentController@alipayNotify',
            '/files' => 'FileController@index',
            '/files/detail' => 'FileController@detail',
            '/files/download' => 'FileController@downloadImage',
            '/files/logs' => 'FileController@logs',
            '/files/logs/export' => 'FileController@exportLogs',
            '/guest/upload/result' => 'FileController@guestUploadResult',
            '/netdisk' => 'NetdiskController@index',
            '/netdisk/download' => 'NetdiskController@download',
            '/netdisk/recycle' => 'NetdiskController@recycle',
            '/shares' => 'NetdiskController@shares',
            '/repository' => 'NetdiskController@repository',
            '/repository/create' => 'NetdiskController@repositoryCreate',
            '/repository/files' => 'NetdiskController@repositoryFiles',
            '/repository/settings' => 'NetdiskController@repositorySettings',
            '/repository/logs/access' => 'NetdiskController@repositoryAccessLogs',
            '/repository/logs/download' => 'NetdiskController@repositoryDownloadLogs',
            '/repository/logs/export' => 'NetdiskController@exportRepositoryLogs',
            '/subsites' => 'UserController@subsites',
            '/teams' => 'UserController@teams',
            '/monitor' => 'MonitorController@index',
            '/cron/monitor/collect' => 'MonitorController@cronCollect',
            '/cron/server-ops/collect' => 'ServerController@cronCollect',
            '/cron/user-servers/collect' => 'ServerController@userCronCollect',
            '/monitor/create' => 'MonitorController@create',
            '/servers' => 'ServerController@index',
            '/servers/create' => 'ServerController@create',
            '/servers/commands' => 'ServerController@commandLogs',
            '/alerts' => 'MonitorController@alerts',
            '/api/console' => 'ApiController@console',
            '/api/picgo-config' => 'ApiController@picgoConfig',
            '/api/sharex-config' => 'ApiController@sharexConfig',
            '/announcements' => 'AnnouncementController@index',
            '/notifications' => 'NotificationController@index',
            '/admin/m' => 'AdminMobileController@dashboard',
            '/admin/m/dashboard' => 'AdminMobileController@dashboard',
            '/admin/m/users' => 'AdminMobileController@users',
            '/admin/m/files' => 'AdminMobileController@files',
            '/admin/m/orders' => 'AdminMobileController@orders',
            '/admin/m/packages' => 'AdminMobileController@packages',
            '/admin/m/coupons' => 'AdminMobileController@coupons',
            '/admin/m/cards' => 'AdminMobileController@cards',
            '/admin/m/payments' => 'AdminMobileController@payments',
            '/admin/m/storages' => 'AdminMobileController@storages',
            '/admin/m/storage-backups' => 'AdminMobileController@storageBackups',
            '/admin/m/repositories' => 'AdminMobileController@repositories',
            '/admin/m/subsites' => 'AdminMobileController@subsites',
            '/admin/m/servers' => 'AdminMobileController@servers',
            '/admin/m/logs' => 'AdminMobileController@logs',
            '/admin/m/incidents' => 'AdminMobileController@incidents',
            '/admin/m/announcements' => 'AdminMobileController@announcements',
            '/admin/m/upload-limits' => 'AdminMobileController@uploadLimits',
            '/admin/m/settings' => 'AdminMobileController@settings',
            '/admin/m/schema-audit' => 'AdminMobileController@schemaAudit',
            '/admin/m/menu' => 'AdminMobileController@menu',
            '/admin' => 'AdminController@dashboard',
            '/admin/screen' => 'AdminController@screen',
            '/admin/users' => 'AdminController@users',
            '/admin/package-expiry' => 'AdminController@packageExpiry',
            '/admin/packages' => 'AdminController@packages',
            '/admin/coupons' => 'AdminController@coupons',
            '/admin/cards' => 'AdminController@cards',
            '/admin/orders' => 'AdminController@orders',
            '/admin/orders/export' => 'AdminController@exportOrders',
            '/admin/recharges' => 'AdminController@recharges',
            '/admin/payments' => 'AdminController@payments',
            '/admin/storages' => 'AdminController@storages',
            '/admin/storage-integrations' => 'AdminController@storageIntegrations',
            '/admin/storage-backups' => 'AdminController@storageBackups',
            '/admin/storage-backups/tasks' => 'AdminController@storageBackupTasks',
            '/admin/storage-backups/backfill' => 'AdminController@storageBackupBackfill',
            '/admin/storage-migration' => 'AdminController@storageMigration',
            '/admin/files' => 'AdminController@files',
            '/admin/repositories' => 'AdminController@repositories',
            '/admin/repositories/detail' => 'AdminController@repositoryDetail',
            '/admin/subsites' => 'AdminController@subsites',
            '/admin/user-servers' => 'AdminController@serverOps',
            '/admin/ssh-sessions' => 'AdminController@sshSessions',
            '/admin/command-logs' => 'AdminController@commandLogs',
            '/admin/server-ops/settings' => 'AdminController@serverOpsSettings',
            '/admin/api-logs' => 'AdminController@apiLogs',
            '/admin/balance-logs' => 'AdminController@balanceLogs',
            '/admin/incident-center' => 'AdminController@incidentCenter',
            '/admin/feature-audit' => 'AdminController@featureAudit',
            '/admin/monitors' => 'AdminController@monitors',
            '/admin/monitor-sla' => 'AdminController@monitorSla',
            '/admin/monitor-sla/export' => 'AdminController@exportMonitorSla',
            '/admin/announcements' => 'AdminController@announcements',
            '/admin/maintenance' => 'AdminController@maintenance',
            '/admin/maintenance/schema-audit' => 'AdminController@schemaAudit',
            '/admin/maintenance/update' => 'AdminController@maintenanceUpdate',
            '/admin/maintenance/environment' => 'AdminController@maintenanceEnvironment',
            '/admin/settings' => 'AdminController@settings',
            '/admin/settings/site' => 'AdminController@settingsSite',
            '/admin/settings/security' => 'AdminController@settingsSecurity',
            '/admin/settings/upload' => 'AdminController@settingsUpload',
            '/admin/upload-limits' => 'AdminController@uploadLimits',
            '/admin/settings/api' => 'AdminController@settingsApi',
            '/admin/settings/email' => 'AdminController@settingsEmail',
            '/admin/themes' => 'AdminController@themes',
            '/admin/logs' => 'AdminController@logs',
        ],
        'POST' => [
            '/install' => 'InstallController@install',
            '/install/test-db' => 'InstallController@testDatabase',
            '/login' => 'AuthController@postLogin',
            '/register' => 'AuthController@postRegister',
            '/email-code' => 'AuthController@sendEmailCode',
            '/forgot' => 'AuthController@postForgot',
            '/reset-password' => 'AuthController@postResetPassword',
            '/profile' => 'UserController@updateProfile',
            '/theme' => 'UserController@saveTheme',
            '/profile/api-token/reset' => 'UserController@resetApiToken',
            '/password' => 'UserController@updatePassword',
            '/packages/buy' => 'PackageController@buy',
            '/recharge' => 'RechargeController@create',
            '/orders/close' => 'RechargeController@closeOrder',
            '/cards/redeem' => 'CardController@redeem',
            '/pay/alipay/notify' => 'PaymentController@alipayNotify',
            '/pay/alipay/query' => 'PaymentController@alipayQuery',
            '/files/upload' => 'FileController@upload',
            '/guest/upload' => 'FileController@guestUpload',
            '/files/fetch' => 'FileController@fetchUrl',
            '/files/delete' => 'FileController@delete',
            '/m/netdisk/folder' => 'MobileController@createFolder',
            '/m/netdisk/folder/delete' => 'MobileController@deleteFolder',
            '/m/netdisk/delete' => 'MobileController@deleteFile',
            '/m/repository/save' => 'MobileController@saveRepository',
            '/m/repository/delete' => 'MobileController@deleteRepository',
            '/m/subsites/save' => 'MobileController@saveSubsite',
            '/m/subsites/check' => 'MobileController@checkSubsiteDomain',
            '/m/subsites/delete' => 'MobileController@deleteSubsite',
            '/m/teams/save' => 'MobileController@saveTeam',
            '/m/teams/delete' => 'MobileController@deleteTeam',
            '/m/teams/invites/create' => 'MobileController@createTeamInvite',
            '/m/teams/invites/cancel' => 'MobileController@cancelTeamInvite',
            '/m/teams/invites/accept' => 'MobileController@acceptTeamInvite',
            '/m/teams/invites/decline' => 'MobileController@declineTeamInvite',
            '/m/teams/members/update' => 'MobileController@updateTeamMember',
            '/m/teams/members/remove' => 'MobileController@removeTeamMember',
            '/m/teams/leave' => 'MobileController@leaveTeam',
            '/m/servers/collect' => 'MobileController@collectServer',
            '/m/servers/delete' => 'MobileController@deleteServer',
            '/m/servers/save' => 'MobileController@saveServer',
            '/m/servers/terminal/command' => 'MobileController@runServerCommand',
            '/m/servers/probes/save' => 'MobileController@saveServerProbe',
            '/m/servers/probes/test' => 'MobileController@testServerProbe',
            '/m/servers/probes/delete' => 'MobileController@deleteServerProbe',
            '/m/servers/share/save' => 'MobileController@saveServerShare',
            '/m/packages/buy' => 'MobileController@buyPackage',
            '/m/recharge' => 'MobileController@createRecharge',
            '/m/cards/redeem' => 'MobileController@redeemCard',
            '/m/orders/close' => 'MobileController@closeOrder',
            '/m/api/token/reset' => 'MobileController@resetApiToken',
            '/m/api/apps/create' => 'ApiController@createApp',
            '/m/api/apps/update' => 'ApiController@updateApp',
            '/m/api/apps/rotate' => 'ApiController@rotateApp',
            '/m/api/apps/delete' => 'ApiController@deleteApp',
            '/m/alerts/read' => 'MobileController@markAlertRead',
            '/m/alerts/resolve' => 'MobileController@resolveAlert',
            '/m/notifications/read-all' => 'MobileController@readNotifications',
            '/m/profile' => 'MobileController@saveProfile',
            '/m/password' => 'MobileController@updatePassword',
            '/netdisk/folder' => 'NetdiskController@createFolder',
            '/netdisk/folder/delete' => 'NetdiskController@deleteFolder',
            '/netdisk/upload' => 'NetdiskController@upload',
            '/netdisk/batch-download' => 'NetdiskController@batchDownload',
            '/netdisk/rename' => 'NetdiskController@rename',
            '/netdisk/move' => 'NetdiskController@move',
            '/netdisk/share' => 'NetdiskController@createShare',
            '/netdisk/share/status' => 'NetdiskController@shareStatus',
            '/repository/create' => 'NetdiskController@createRepository',
            '/repository/save' => 'NetdiskController@saveRepository',
            '/repository/file' => 'NetdiskController@saveRepositoryItem',
            '/repository/file/delete' => 'NetdiskController@removeRepositoryItem',
            '/repository/files/batch' => 'NetdiskController@batchRepositoryItems',
            '/repository/delete' => 'NetdiskController@deleteRepository',
            '/repository/logs/clear' => 'NetdiskController@clearRepositoryLogs',
            '/subsites/save' => 'UserController@saveSubsite',
            '/subsites/check' => 'UserController@checkSubsiteDomain',
            '/subsites/delete' => 'UserController@deleteSubsite',
            '/teams/save' => 'UserController@saveTeam',
            '/teams/delete' => 'UserController@deleteTeam',
            '/teams/invites/create' => 'UserController@createTeamInvite',
            '/teams/invites/cancel' => 'UserController@cancelTeamInvite',
            '/teams/invites/accept' => 'UserController@acceptTeamInvite',
            '/teams/invites/decline' => 'UserController@declineTeamInvite',
            '/teams/members/update' => 'UserController@updateTeamMember',
            '/teams/members/remove' => 'UserController@removeTeamMember',
            '/teams/leave' => 'UserController@leaveTeam',
            '/netdisk/delete' => 'NetdiskController@delete',
            '/netdisk/batch-delete' => 'NetdiskController@batchDelete',
            '/netdisk/restore' => 'NetdiskController@restore',
            '/netdisk/purge' => 'NetdiskController@purge',
            '/monitor' => 'MonitorController@store',
            '/monitor/test' => 'MonitorController@test',
            '/monitor/collect' => 'MonitorController@collect',
            '/monitor/toggle' => 'MonitorController@toggle',
            '/monitor/delete' => 'MonitorController@delete',
            '/agent/report' => 'AgentController@report',
            '/servers/save' => 'ServerController@save',
            '/servers/test' => 'ServerController@test',
            '/servers/collect' => 'ServerController@collect',
            '/servers/delete' => 'ServerController@delete',
            '/servers/probes/save' => 'ServerController@saveProbe',
            '/servers/probes/test' => 'ServerController@testProbe',
            '/servers/probes/delete' => 'ServerController@deleteProbe',
            '/servers/terminal/command' => 'ServerController@command',
            '/servers/terminal/token' => 'ServerController@terminalToken',
            '/servers/share/save' => 'ServerController@saveShare',
            '/servers/cron-token/reset' => 'ServerController@resetCronToken',
            '/alerts/read' => 'MonitorController@markAlertRead',
            '/alerts/resolve' => 'MonitorController@resolveAlert',
            '/notifications/read-all' => 'NotificationController@readAll',
            '/admin/m/orders/manual-paid' => 'AdminMobileController@manualPaidOrder',
            '/admin/m/recharges/audit' => 'AdminMobileController@auditRecharge',
            '/admin/m/users/create' => 'AdminMobileController@createUser',
            '/admin/m/users/update' => 'AdminMobileController@updateUser',
            '/admin/m/files/delete' => 'AdminMobileController@deleteFile',
            '/admin/m/storages/save' => 'AdminMobileController@saveStorage',
            '/admin/m/storages/test' => 'AdminMobileController@testStorage',
            '/admin/m/storages/default' => 'AdminMobileController@setDefaultStorage',
            '/admin/m/storages/toggle' => 'AdminMobileController@toggleStorage',
            '/admin/m/storages/delete' => 'AdminMobileController@deleteStorage',
            '/admin/m/packages/save' => 'AdminMobileController@savePackage',
            '/admin/m/packages/delete' => 'AdminMobileController@deletePackage',
            '/admin/m/coupons/save' => 'AdminMobileController@saveCoupon',
            '/admin/m/coupons/delete' => 'AdminMobileController@deleteCoupon',
            '/admin/m/cards/generate' => 'AdminMobileController@generateCards',
            '/admin/m/cards/status' => 'AdminMobileController@updateCardStatus',
            '/admin/m/cards/delete' => 'AdminMobileController@deleteCard',
            '/admin/m/payments/save' => 'AdminMobileController@savePayment',
            '/admin/m/repositories/status' => 'AdminMobileController@repositoryStatus',
            '/admin/m/repositories/delete' => 'AdminMobileController@deleteRepository',
            '/admin/m/storage-backups/save' => 'AdminMobileController@saveStorageBackupPolicy',
            '/admin/m/storage-backups/delete' => 'AdminMobileController@deleteStorageBackupPolicy',
            '/admin/m/storage-backups/retry' => 'AdminMobileController@retryStorageBackup',
            '/admin/m/storage-backups/retry-failed' => 'AdminMobileController@retryFailedStorageBackups',
            '/admin/m/storage-migration/run' => 'AdminMobileController@runStorageMigration',
            '/admin/m/subsites/status' => 'AdminMobileController@updateSubsiteStatus',
            '/admin/m/subsites/check' => 'AdminMobileController@checkSubsiteDomain',
            '/admin/m/subsites/delete' => 'AdminMobileController@deleteSubsite',
            '/admin/m/monitors/toggle' => 'AdminMobileController@toggleMonitor',
            '/admin/m/monitors/collect' => 'AdminMobileController@collectMonitor',
            '/admin/m/monitors/delete' => 'AdminMobileController@deleteMonitor',
            '/admin/m/announcements/save' => 'AdminMobileController@saveAnnouncement',
            '/admin/m/announcements/delete' => 'AdminMobileController@deleteAnnouncement',
            '/admin/m/upload-limits' => 'AdminMobileController@saveUploadLimits',
            '/admin/m/settings/site' => 'AdminMobileController@saveSettingsSite',
            '/admin/m/settings/security' => 'AdminMobileController@saveSettingsSecurity',
            '/admin/m/settings/upload' => 'AdminMobileController@saveSettingsUpload',
            '/admin/m/settings/api' => 'AdminMobileController@saveSettingsApi',
            '/admin/m/settings/email' => 'AdminMobileController@saveSettingsEmail',
            '/admin/m/settings/notify' => 'AdminMobileController@saveSettingsNotify',
            '/admin/m/settings/notify/test' => 'AdminMobileController@testNotifyChannel',
            '/admin/m/settings/themes' => 'AdminMobileController@saveThemes',
            '/admin/m/maintenance/toggle' => 'AdminMobileController@toggleMaintenance',
            '/admin/m/maintenance/repair-schema' => 'AdminMobileController@repairSchema',
            '/admin/m/maintenance/repair-schema-admin' => 'AdminMobileController@repairSchemaWithTemporaryAdmin',
            '/admin/users/create' => 'AdminController@createUser',
            '/admin/users/update' => 'AdminController@updateUser',
            '/admin/package-expiry/remind' => 'AdminController@sendPackageExpiryReminders',
            '/admin/packages/save' => 'AdminController@savePackage',
            '/admin/packages/delete' => 'AdminController@deletePackage',
            '/admin/coupons/save' => 'AdminController@saveCoupon',
            '/admin/coupons/delete' => 'AdminController@deleteCoupon',
            '/admin/cards/generate' => 'AdminController@generateCards',
            '/admin/cards/status' => 'AdminController@updateCardStatus',
            '/admin/cards/delete' => 'AdminController@deleteCard',
            '/admin/storages/save' => 'AdminController@saveStorage',
            '/admin/storages/test' => 'AdminController@testStorage',
            '/admin/storages/default' => 'AdminController@setDefaultStorage',
            '/admin/storages/delete' => 'AdminController@deleteStorage',
            '/admin/storage-backups/save' => 'AdminController@saveStorageBackupPolicy',
            '/admin/storage-backups/delete' => 'AdminController@deleteStorageBackupPolicy',
            '/admin/storage-backups/retry' => 'AdminController@retryStorageBackup',
            '/admin/storage-backups/retry-failed' => 'AdminController@retryFailedStorageBackups',
            '/admin/storage-backups/backfill' => 'AdminController@runStorageBackupBackfill',
            '/admin/storage-migration/run' => 'AdminController@runStorageMigration',
            '/admin/files/delete' => 'AdminController@deleteFile',
            '/admin/repositories/status' => 'AdminController@repositoryStatus',
            '/admin/repositories/delete' => 'AdminController@deleteRepository',
            '/admin/repositories/logs/clear' => 'AdminController@clearRepositoryLogs',
            '/admin/subsites/settings' => 'AdminController@saveSubsiteSettings',
            '/admin/subsites/check' => 'AdminController@checkSubsiteDomain',
            '/admin/subsites/status' => 'AdminController@updateSubsiteStatus',
            '/admin/subsites/delete' => 'AdminController@deleteSubsite',
            '/admin/monitors/toggle' => 'AdminController@toggleMonitor',
            '/admin/monitors/delete' => 'AdminController@deleteMonitor',
            '/admin/monitors/collect' => 'AdminController@collectMonitor',
            '/admin/monitors/save' => 'AdminController@saveMonitor',
            '/admin/monitors/test' => 'AdminController@testMonitor',
            '/admin/server-ops/settings' => 'AdminController@saveServerOpsSettings',
            '/admin/alerts/resolve' => 'AdminController@resolveAlert',
            '/admin/announcements/save' => 'AdminController@saveAnnouncement',
            '/admin/announcements/delete' => 'AdminController@deleteAnnouncement',
            '/admin/maintenance' => 'AdminController@saveMaintenance',
            '/admin/maintenance/repair-schema' => 'AdminController@repairSchema',
            '/admin/maintenance/repair-schema-admin' => 'AdminController@repairSchemaWithTemporaryAdmin',
            '/admin/maintenance/export-db' => 'AdminController@exportDatabase',
            '/admin/maintenance/update-check' => 'AdminController@checkUpdate',
            '/admin/maintenance/update-download' => 'AdminController@downloadUpdate',
            '/admin/maintenance/update-install' => 'AdminController@installUpdate',
            '/admin/settings' => 'AdminController@saveSettings',
            '/admin/settings/site' => 'AdminController@saveSettingsSite',
            '/admin/settings/security' => 'AdminController@saveSettingsSecurity',
            '/admin/settings/upload' => 'AdminController@saveSettingsUpload',
            '/admin/upload-limits' => 'AdminController@saveUploadLimits',
            '/admin/settings/api' => 'AdminController@saveSettingsApi',
            '/admin/settings/email' => 'AdminController@saveSettingsEmail',
            '/admin/settings/notify' => 'AdminController@saveSettingsNotify',
            '/admin/settings/notify/test' => 'AdminController@testNotifyChannel',
            '/admin/themes' => 'AdminController@saveThemes',
            '/admin/email/test' => 'AdminController@testEmail',
            '/admin/settings/email/test' => 'AdminController@testEmail',
            '/admin/recharges/audit' => 'AdminController@auditRecharge',
            '/admin/orders/manual-paid' => 'AdminController@manualPaidOrder',
            '/admin/payments/save' => 'AdminController@savePayment',
            '/api/upload' => 'ApiController@upload',
            '/api/files' => 'ApiController@files',
            '/api/delete' => 'ApiController@delete',
            '/api/quota' => 'ApiController@quota',
            '/api/apps/create' => 'ApiController@createApp',
            '/api/apps/update' => 'ApiController@updateApp',
            '/api/apps/rotate' => 'ApiController@rotateApp',
            '/api/apps/delete' => 'ApiController@deleteApp',
        ],
    ];

    public static function dispatch()
    {
        define('APP_DEBUG', (bool) Config::get('app.debug', false));

        $uri = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
        $uri = '/' . trim($uri, '/');
        if ($uri === '//') {
            $uri = '/';
        }
        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';

        if (!self::installed() && strpos($uri, '/install') !== 0) {
            header('Location: ' . url('install'));
            exit;
        }

        if (self::installed()) {
            $mobileTarget = self::mobileRedirectTarget($method, $uri);
            if ($mobileTarget !== '') {
                header('Location: ' . $mobileTarget);
                exit;
            }
        }

        if (self::installed() && self::maintenanceActive($uri)) {
            http_response_code(503);
            header('Content-Type: text/html; charset=utf-8');
            $siteName = function_exists('setting') ? setting('site_name', app_brand_name()) : app_brand_name();
            $message = function_exists('setting') ? setting('maintenance_message', '系统正在维护升级，请稍后再访问。') : '系统正在维护升级，请稍后再访问。';
            echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>系统维护中</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;font-family:Arial,"Microsoft YaHei",sans-serif;color:#10243f;background:linear-gradient(135deg,#eef6ff,#ffffff)}.card{width:min(520px,calc(100% - 32px));padding:34px;border-radius:18px;background:rgba(255,255,255,.86);box-shadow:0 24px 70px rgba(23,107,255,.12);border:1px solid #dce9fb}.tag{color:#176bff;font-weight:900;letter-spacing:.08em}.card h1{font-size:34px;margin:12px 0}.card p{line-height:1.8;color:#60748d}.btn{display:inline-flex;margin-top:16px;padding:11px 16px;border-radius:10px;color:#fff;background:#176bff;text-decoration:none;font-weight:900}</style></head><body><main class="card"><span class="tag">' . htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8') . '</span><h1>系统维护中</h1><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><a class="btn" href="' . htmlspecialchars(url('login'), ENT_QUOTES, 'UTF-8') . '">管理员登录</a></main></body></html>';
            return;
        }

        $target = isset(self::$routes[$method][$uri]) ? self::$routes[$method][$uri] : null;

        if (!$target) {
            if (preg_match('#^/monitor/(\d+)$#', $uri, $m)) {
                $target = 'MonitorController@show';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/monitor/(\d+)/metrics$#', $uri, $m)) {
                $target = 'MonitorController@metrics';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/servers/(\d+)$#', $uri, $m)) {
                $target = 'ServerController@show';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/servers/(\d+)/terminal$#', $uri, $m)) {
                $target = 'ServerController@terminal';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/servers/(\d+)/probes$#', $uri, $m)) {
                $target = 'ServerController@probes';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/servers/(\d+)/share$#', $uri, $m)) {
                $target = 'ServerController@share';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/m/servers/(\d+)/terminal$#', $uri, $m)) {
                $target = 'MobileController@serverTerminal';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/m/servers/(\d+)/probes$#', $uri, $m)) {
                $target = 'MobileController@serverProbes';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/m/servers/(\d+)/share$#', $uri, $m)) {
                $target = 'MobileController@serverShare';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/m/servers/(\d+)$#', $uri, $m)) {
                $target = 'MobileController@serverDetail';
                $_GET['id'] = (int) $m[1];
            } elseif ($method === 'GET' && preg_match('#^/agent/install/(\d+)/([A-Za-z0-9_-]+)$#', $uri, $m)) {
                $target = 'AgentController@installScript';
                $_GET['id'] = (int) $m[1];
                $_GET['token'] = $m[2];
            } elseif (($method === 'GET' || $method === 'POST') && preg_match('#^/s/([A-Za-z0-9_-]+)$#', $uri, $m)) {
                $target = 'ServerController@publicStatus';
                $_GET['token'] = $m[1];
            } elseif ($method === 'GET' && preg_match('#^/site/([A-Za-z0-9-]+)$#', $uri, $m)) {
                $target = 'HomeController@subsite';
                $_GET['slug'] = $m[1];
            } elseif (preg_match('#^/announcements/(\d+)$#', $uri, $m)) {
                $target = 'AnnouncementController@show';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/admin/orders/(\d+)$#', $uri, $m)) {
                $target = 'AdminController@orderDetail';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/pay/alipay/([A-Za-z0-9]+)$#', $uri, $m)) {
                $target = 'PaymentController@alipayPage';
                $_GET['order_no'] = $m[1];
            } elseif ($method === 'GET' && preg_match('#^/r/([A-Za-z0-9_-]+)/download/(\d+)$#', $uri, $m)) {
                $target = 'NetdiskController@repositoryDownload';
                $_GET['slug'] = $m[1];
                $_GET['file_id'] = (int) $m[2];
            } elseif ($method === 'GET' && preg_match('#^/r/([A-Za-z0-9_-]+)/download-zip$#', $uri, $m)) {
                $target = 'NetdiskController@repositoryDownloadZip';
                $_GET['slug'] = $m[1];
            } elseif ($method === 'POST' && preg_match('#^/r/([A-Za-z0-9_-]+)/auth$#', $uri, $m)) {
                $target = 'NetdiskController@repositoryAuth';
                $_GET['slug'] = $m[1];
            } elseif ($method === 'GET' && preg_match('#^/r/([A-Za-z0-9_-]+)$#', $uri, $m)) {
                $target = 'NetdiskController@repositoryPublic';
                $_GET['slug'] = $m[1];
            } elseif (preg_match('#^/share/([A-Za-z0-9]+)/download$#', $uri, $m)) {
                $target = 'NetdiskController@shareDownload';
                $_GET['code'] = $m[1];
            } elseif (preg_match('#^/share/([A-Za-z0-9]+)$#', $uri, $m)) {
                $target = 'NetdiskController@shareView';
                $_GET['code'] = $m[1];
            }
        }

        if (!$target) {
            http_response_code(404);
            echo '404 Not Found';
            return;
        }

        if (self::installed() && strpos($uri, '/admin') === 0) {
            $repairPaths = [
                '/admin/maintenance',
                '/admin/maintenance/schema-audit',
                '/admin/maintenance/environment',
                '/admin/maintenance/repair-schema',
                '/admin/maintenance/repair-schema-admin',
                '/admin/feature-audit',
                '/admin/m/settings',
                '/admin/m/maintenance/repair-schema',
            ];
            try {
                if (!Auth::check()) {
                    if (function_exists('bm_request_expects_json') && bm_request_expects_json()) {
                        bm_emit_json_error('后台登录状态已失效，请重新登录后再操作。', 401);
                        return;
                    }
                    if ($method === 'GET') {
                        $_SESSION['intended_url'] = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : $uri;
                    }
                    set_flash('error', '请先登录后台。');
                    header('Location: ' . url('login'));
                    return;
                }

                $user = Auth::user();
                if (!$user || !isset($user['role']) || $user['role'] !== 'admin') {
                    if (function_exists('bm_request_expects_json') && bm_request_expects_json()) {
                        bm_emit_json_error('当前账号没有后台管理权限。', 403);
                        return;
                    }
                    http_response_code(403);
                    echo '403 Forbidden';
                    return;
                }

                $schemaReady = \App\Services\DatabaseUpgradeService::ensureRuntimeSchema();
                if (!$schemaReady && !in_array($uri, $repairPaths, true)) {
                    if (function_exists('bm_request_expects_json') && bm_request_expects_json()) {
                        bm_emit_json_error('后台数据库结构未准备完成，请先进入系统维护执行数据库一键修复。', 500, [
                            'error_type' => 'schema',
                            'repair_url' => url('admin/maintenance/schema-audit'),
                        ]);
                        return;
                    }
                    set_flash('error', '后台数据库结构未准备完成，请先执行数据库巡检和一键修复。');
                    header('Location: ' . url('admin/maintenance/schema-audit'));
                    return;
                }
            } catch (\Throwable $e) {
                Logger::error('后台入口数据库结构预检查失败：' . $e->getMessage());
                if (function_exists('bm_request_expects_json') && bm_request_expects_json()) {
                    bm_emit_json_error('后台入口预检查失败，请进入系统维护执行数据库巡检修复。', 500, [
                        'error_type' => 'schema',
                        'repair_url' => url('admin/maintenance/schema-audit'),
                    ]);
                    return;
                }
                if (!in_array($uri, $repairPaths, true)) {
                    set_flash('error', '后台入口预检查失败，请先进入数据库巡检执行一键修复。');
                    header('Location: ' . url('admin/maintenance/schema-audit'));
                    return;
                }
                if (function_exists('bm_emit_html_error')) {
                    bm_emit_html_error('后台入口预检查失败', '系统无法完成后台入口数据库结构检查。请进入数据库巡检或系统维护查看环境、数据库连接和运行日志。', '', [
                        ['href' => url('admin/maintenance/schema-audit'), 'label' => '进入数据库巡检', 'primary' => true],
                        ['href' => url('admin/maintenance/environment'), 'label' => '环境信息'],
                    ]);
                    return;
                }
                http_response_code(500);
                echo 'Admin schema precheck failed.';
                return;
            }
        }

        list($controller, $action) = explode('@', $target);
        $class = 'App\\Controllers\\' . $controller;
        $instance = new $class();
        call_user_func([$instance, $action]);
    }

    public static function installed()
    {
        return is_file(APP_ROOT . '/storage/install.lock') && is_file(APP_ROOT . '/config/database.php');
    }

    protected static function maintenanceActive($uri)
    {
        if (strpos($uri, '/admin') === 0 || strpos($uri, '/install') === 0 || strpos($uri, '/agent') === 0 || $uri === '/login' || $uri === '/logout' || $uri === '/pay/alipay/notify') {
            return false;
        }
        try {
            if (class_exists('App\\Core\\Auth') && Auth::check()) {
                $user = Auth::user();
                if ($user && isset($user['role']) && $user['role'] === 'admin') {
                    return false;
                }
            }
            return function_exists('setting') && (string) setting('site_maintenance', '0') === '1';
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected static function mobileRedirectTarget($method, $uri)
    {
        if ($method !== 'GET' || !self::isMobileRequest()) {
            return '';
        }
        if (isset($_GET['desktop']) || isset($_GET['pc']) || isset($_GET['full'])) {
            return '';
        }
        if (strpos($uri, '/m') === 0 || strpos($uri, '/admin/m') === 0 || strpos($uri, '/api') === 0 || strpos($uri, '/cron') === 0 || strpos($uri, '/install') === 0) {
            return '';
        }

        $adminMap = [
            '/admin' => 'admin/m',
            '/admin/users' => 'admin/m/users',
            '/admin/files' => 'admin/m/files',
            '/admin/packages' => 'admin/m/packages',
            '/admin/cards' => 'admin/m/cards',
            '/admin/coupons' => 'admin/m/coupons',
            '/admin/orders' => 'admin/m/orders',
            '/admin/recharges' => 'admin/m/orders',
            '/admin/payments' => 'admin/m/payments',
            '/admin/storages' => 'admin/m/storages',
            '/admin/storage-integrations' => 'admin/m/storages',
            '/admin/storage-backups' => 'admin/m/storage-backups',
            '/admin/storage-backups/tasks' => 'admin/m/storage-backups',
            '/admin/storage-backups/backfill' => 'admin/m/storage-backups',
            '/admin/storage-migration' => 'admin/m/storage-backups',
            '/admin/repositories' => 'admin/m/repositories',
            '/admin/subsites' => 'admin/m/subsites',
            '/admin/monitors' => 'admin/m/servers',
            '/admin/user-servers' => 'admin/m/servers',
            '/admin/logs' => 'admin/m/logs',
            '/admin/api-logs' => 'admin/m/logs',
            '/admin/balance-logs' => 'admin/m/logs',
            '/admin/command-logs' => 'admin/m/logs',
            '/admin/ssh-sessions' => 'admin/m/logs',
            '/admin/announcements' => 'admin/m/announcements',
            '/admin/settings' => 'admin/m/settings',
            '/admin/settings/site' => 'admin/m/settings',
            '/admin/settings/security' => 'admin/m/settings',
            '/admin/settings/upload' => 'admin/m/settings',
            '/admin/settings/api' => 'admin/m/settings',
            '/admin/settings/email' => 'admin/m/settings',
            '/admin/settings/notify' => 'admin/m/settings',
            '/admin/maintenance' => 'admin/m/settings',
            '/admin/maintenance/schema-audit' => 'admin/m/schema-audit',
            '/admin/themes' => 'admin/m/settings',
            '/admin/upload-limits' => 'admin/m/upload-limits',
        ];
        if (isset($adminMap[$uri])) {
            return self::mobileUrlWithQuery($adminMap[$uri]);
        }

        $userMap = [
            '/user' => 'm',
            '/user/center' => 'm',
            '/user/dashboard' => 'm',
            '/console' => 'm',
            '/dashboard' => 'm',
            '/profile' => 'm/profile',
            '/password' => 'm/password',
            '/files' => 'm/files',
            '/netdisk' => 'm/netdisk',
            '/repository' => 'm/repository',
            '/subsites' => 'm/subsites',
            '/teams' => 'm/teams',
            '/servers' => 'm/servers',
            '/servers/create' => 'm/servers/create',
            '/servers/commands' => 'm/servers/commands',
            '/orders' => 'm/orders',
            '/balance/logs' => 'm/balance',
            '/recharge' => 'm/recharge',
            '/cards' => 'm/cards',
            '/packages' => 'm/packages',
            '/api/console' => 'm/api',
            '/alerts' => 'm/alerts',
            '/notifications' => 'm/notifications',
        ];
        if (isset($userMap[$uri])) {
            return self::mobileUrlWithQuery($userMap[$uri]);
        }

        return '';
    }

    protected static function mobileUrlWithQuery($path)
    {
        $query = isset($_SERVER['QUERY_STRING']) ? trim((string) $_SERVER['QUERY_STRING']) : '';
        if ($query !== '') {
            return url($path) . '?' . $query;
        }
        return url($path);
    }

    protected static function isMobileRequest()
    {
        if (isset($_SERVER['HTTP_SEC_CH_UA_MOBILE']) && trim((string) $_SERVER['HTTP_SEC_CH_UA_MOBILE']) === '?1') {
            return true;
        }
        $ua = strtolower(isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '');
        if ($ua === '') {
            return false;
        }
        return (bool) preg_match('/android|iphone|ipod|mobile|windows phone|blackberry|opera mini|micromessenger|mqqbrowser/i', $ua);
    }
}
