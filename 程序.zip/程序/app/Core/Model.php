<?php
namespace App\Core;

class Model
{
    protected $table = '';
    protected $primaryKey = 'id';

    protected function table()
    {
        return Database::table($this->table);
    }

    public function find($id)
    {
        return Database::fetch('SELECT * FROM ' . $this->table() . ' WHERE ' . Database::validateIdentifier($this->primaryKey, 'primary key') . ' = ? LIMIT 1', [$id]);
    }

    public function all($order = 'id DESC')
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . Database::orderByClause($order));
    }

    public function create(array $data)
    {
        $keys = array_keys($data);
        $fields = implode(',', array_map(function ($key) {
            return Database::validateIdentifier($key, 'column');
        }, $keys));
        $marks = implode(',', array_fill(0, count($keys), '?'));
        Database::execute('INSERT INTO ' . $this->table() . ' (' . $fields . ') VALUES (' . $marks . ')', array_values($data));
        return Database::lastInsertId();
    }

    public function update($id, array $data)
    {
        $sets = [];
        foreach ($data as $key => $value) {
            $sets[] = Database::validateIdentifier($key, 'column') . ' = ?';
        }
        $params = array_values($data);
        $params[] = $id;
        return Database::execute('UPDATE ' . $this->table() . ' SET ' . implode(',', $sets) . ' WHERE ' . Database::validateIdentifier($this->primaryKey, 'primary key') . ' = ?', $params);
    }

    public function delete($id)
    {
        return Database::execute('DELETE FROM ' . $this->table() . ' WHERE ' . Database::validateIdentifier($this->primaryKey, 'primary key') . ' = ?', [$id]);
    }
}
