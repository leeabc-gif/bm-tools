<?php
namespace App\Core;

class Controller
{
    protected function view($view, array $data = [], $layout = 'layouts/app')
    {
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=utf-8');
            if ($layout === 'layouts/admin' || $layout === 'layouts/auth' || $this->isAuthenticatedRequest()) {
                $this->privateNoStoreHeaders();
            }
        }
        extract($data);
        $viewFile = APP_ROOT . '/app/Views/' . $view . '.php';
        if (!is_file($viewFile)) {
            throw new \RuntimeException('视图不存在：' . $view);
        }
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        $layoutFile = APP_ROOT . '/app/Views/' . $layout . '.php';
        if ($layout && is_file($layoutFile)) {
            require $layoutFile;
        } else {
            echo $content;
        }
    }

    protected function adminView($view, array $data = [])
    {
        $this->requireAdmin();
        $this->view($view, $data, 'layouts/admin');
    }

    protected function json($data, $status = 200)
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function redirect($path)
    {
        header('Location: ' . $this->safeRedirectTarget($path));
        exit;
    }

    protected function requireLogin()
    {
        if (!Auth::check()) {
            if ($this->expectsJson()) {
                $this->json(['success' => false, 'message' => '登录状态已失效，请重新登录后再上传。'], 401);
            }
            $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
            $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
            if ($method === 'GET' && $uri !== '' && strpos($uri, '/login') === false && strpos($uri, '/logout') === false) {
                $_SESSION['intended_url'] = $uri;
            }
            set_flash('error', '请先登录。');
            $this->redirect('login');
        }
        if (!headers_sent()) {
            $this->privateNoStoreHeaders();
        }
        try {
            \App\Services\DatabaseUpgradeService::ensureRuntimeSchema();
        } catch (\Throwable $e) {
            Logger::error('Runtime schema guard failed for authenticated request: ' . $e->getMessage());
        }
    }

    protected function requireAdmin()
    {
        $this->requireLogin();
        $user = Auth::user();
        if (!$user || $user['role'] !== 'admin') {
            http_response_code(403);
            echo '403 Forbidden';
            exit;
        }
        try {
            \App\Services\DatabaseUpgradeService::ensureRuntimeSchema();
        } catch (\Throwable $e) {
            Logger::error('后台运行时数据库结构检查失败：' . $e->getMessage());
        }
    }

    protected function verifyCsrf()
    {
        $token = isset($_POST['_token']) ? $_POST['_token'] : '';
        if ($token === '' && !empty($_SERVER['HTTP_X_CSRF_TOKEN'])) {
            $token = (string) $_SERVER['HTTP_X_CSRF_TOKEN'];
        }
        if ($token === '' && !empty($_SERVER['HTTP_X_CSRF'])) {
            $token = (string) $_SERVER['HTTP_X_CSRF'];
        }
        if (!Csrf::verify($token)) {
            if ($this->expectsJson()) {
                if ($this->requestExceedsPostMaxSize()) {
                    $this->json(['success' => false, 'message' => '上传内容超过服务器 post_max_size 限制，请减少单个文件大小，或在 PHP 配置中调大 post_max_size 和 upload_max_filesize。'], 413);
                }
                $this->json(['success' => false, 'message' => '表单已过期，请刷新页面后重试。'], 419);
            }
            set_flash('error', '表单已过期，请重试。');
            remember_old();
            $this->back();
        }
    }

    protected function ensureFeatureReady($ready, $featureLabel, $back = 'user', $message = '')
    {
        if ($ready) {
            return true;
        }
        try {
            if (\App\Services\DatabaseUpgradeService::standardSchemaReady()) {
                return true;
            }
        } catch (\Throwable $e) {
            Logger::error('Feature readiness fallback schema check failed: ' . $featureLabel . ' / ' . $e->getMessage());
        }

        $message = $message !== '' ? $message : ($featureLabel . '数据结构未准备完成，请联系管理员进入后台系统维护执行数据库一键修复。');
        Logger::error('Feature schema is not ready: ' . $featureLabel);

        $repairUrl = '';
        try {
            if (Auth::check()) {
                $user = Auth::user();
                if ($user && isset($user['role']) && $user['role'] === 'admin') {
                    $repairUrl = url('admin/maintenance/schema-audit');
                }
            }
        } catch (\Throwable $e) {
            $repairUrl = '';
        }

        $requestPath = parse_url(isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
        $machineReadable = $this->expectsJson()
            || strpos((string) $requestPath, '/cron/') === 0
            || strpos((string) $requestPath, '/api/') === 0
            || strpos((string) $requestPath, '/agent/') === 0;

        if ($machineReadable) {
            $payload = [
                'success' => false,
                'message' => $message,
                'error_type' => 'schema',
            ];
            if ($repairUrl !== '') {
                $payload['repair_url'] = $repairUrl;
            }
            $this->json($payload, 503);
        }

        set_flash('error', $message);
        if ($repairUrl !== '') {
            $this->redirect('admin/maintenance/schema-audit');
        }
        $this->redirect($back !== '' ? $back : 'user');
        return false;
    }

    protected function expectsJson()
    {
        $accept = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
        $xhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) : '';
        return $xhr === 'xmlhttprequest' || stripos($accept, 'application/json') !== false || !empty($_POST['ajax_upload']);
    }

    protected function requestExceedsPostMaxSize()
    {
        $contentLength = isset($_SERVER['CONTENT_LENGTH']) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
        if ($contentLength <= 0) {
            return false;
        }
        $postMax = $this->iniBytes(ini_get('post_max_size'));
        return $postMax > 0 && $contentLength > $postMax;
    }

    protected function iniBytes($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return 0;
        }
        $unit = strtolower(substr($value, -1));
        $number = (float) $value;
        if ($unit === 'g') {
            $number *= 1024 * 1024 * 1024;
        } elseif ($unit === 'm') {
            $number *= 1024 * 1024;
        } elseif ($unit === 'k') {
            $number *= 1024;
        }
        return (int) $number;
    }

    protected function back()
    {
        $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : url('/');
        if (!$this->isSafeRedirectUrl($referer)) {
            $referer = url('/');
        }
        header('Location: ' . $referer);
        exit;
    }

    protected function isSafeRedirectUrl($url)
    {
        $url = (string) $url;
        if ($url === '' || preg_match('/[\r\n]/', $url)) {
            return false;
        }
        if (strpos($url, '/') === 0 && strpos($url, '//') !== 0) {
            return true;
        }
        $target = parse_url($url);
        if (!$target || empty($target['host'])) {
            return false;
        }
        $currentHost = !empty($_SERVER['HTTP_HOST']) ? strtolower(preg_replace('/:\d+$/', '', (string) $_SERVER['HTTP_HOST'])) : '';
        $targetHost = strtolower((string) $target['host']);
        return $currentHost !== '' && hash_equals($currentHost, $targetHost);
    }

    protected function safeRedirectTarget($path)
    {
        $path = (string) $path;
        if ($path === '' || preg_match('/[\r\n]/', $path)) {
            return url('/');
        }
        if ($this->isSafeRedirectUrl($path)) {
            return $path;
        }
        if (preg_match('#^[a-z][a-z0-9+\-.]*:#i', $path) || strpos($path, '//') === 0) {
            return url('/');
        }
        return url($path);
    }

    protected function privateNoStoreHeaders()
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
        header('Pragma: no-cache');
        header('Expires: 0');
    }

    protected function isAuthenticatedRequest()
    {
        try {
            return Auth::check();
        } catch (\Throwable $e) {
            return false;
        }
    }
}
