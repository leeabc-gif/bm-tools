<?php
namespace App\Core;

class Auth
{
    protected static $user;

    public static function check()
    {
        return self::user() !== null;
    }

    public static function id()
    {
        $user = self::user();
        return $user ? (int) $user['id'] : null;
    }

    public static function user()
    {
        if (self::$user !== null) {
            return self::$user;
        }
        if (empty($_SESSION['user_id'])) {
            return null;
        }
        self::$user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$_SESSION['user_id']]);
        if (self::$user) {
            $model = new \App\Models\User();
            if ($model->downgradeIfExpired(self::$user)) {
                self::$user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$_SESSION['user_id']]);
            }
        }
        return self::$user ?: null;
    }

    public static function attempt($account, $password, $remember = false)
    {
        $account = text_limit(trim((string) $account), 180);
        $user = Database::fetch(
            'SELECT * FROM ' . Database::table('users') . ' WHERE (username = ? OR email = ?) LIMIT 1',
            [$account, $account]
        );

        if (!$user || (int) $user['status'] !== 1 || !password_verify($password, $user['password'])) {
            self::logLogin($account, 0);
            return false;
        }

        self::login($user, $remember);
        self::logLogin($account, 1, (int) $user['id']);
        return true;
    }

    public static function login(array $user, $remember = false)
    {
        session_regenerate_id(true);
        Csrf::rotate();
        $_SESSION['user_id'] = (int) $user['id'];
        self::$user = $user;

        $token = $remember ? bin2hex(random_bytes(32)) : null;
        if ($remember) {
            self::cookie('remember_token', $token, time() + 86400 * 30);
        } else {
            self::cookie('remember_token', '', time() - 3600);
        }

        Database::execute(
            'UPDATE ' . Database::table('users') . ' SET remember_token = ?, last_login_ip = ?, last_login_time = ?, updated_at = ? WHERE id = ?',
            [$token ? hash('sha256', $token) : null, self::ip(), now(), now(), $user['id']]
        );
    }

    public static function logout()
    {
        if (self::id()) {
            Database::execute('UPDATE ' . Database::table('users') . ' SET remember_token = NULL WHERE id = ?', [self::id()]);
        }
        self::$user = null;
        $_SESSION = [];
        Csrf::clear();
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => isset($params['path']) ? $params['path'] : '/',
                'domain' => isset($params['domain']) ? $params['domain'] : '',
                'secure' => isset($params['secure']) ? (bool) $params['secure'] : false,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        self::cookie('remember_token', '', time() - 3600);
        session_destroy();
    }

    public static function bootRemember()
    {
        if (!empty($_SESSION['user_id']) || empty($_COOKIE['remember_token'])) {
            return;
        }
        $token = (string) $_COOKIE['remember_token'];
        if (!preg_match('/^[a-f0-9]{64}$/i', $token)) {
            self::cookie('remember_token', '', time() - 3600);
            return;
        }
        $tokenHash = hash('sha256', $token);
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE (remember_token = ? OR remember_token = ?) AND status = 1 LIMIT 1', [$tokenHash, $token]);
        if ($user) {
            $newToken = bin2hex(random_bytes(32));
            Database::execute('UPDATE ' . Database::table('users') . ' SET remember_token = ?, updated_at = ? WHERE id = ?', [hash('sha256', $newToken), now(), $user['id']]);
            self::cookie('remember_token', $newToken, time() + 86400 * 30);
            session_regenerate_id(true);
            Csrf::rotate();
            $_SESSION['user_id'] = (int) $user['id'];
            self::$user = $user;
        }
    }

    protected static function logLogin($account, $success, $userId = null)
    {
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('login_logs') . ' (user_id, account, ip, user_agent, is_success, created_at) VALUES (?,?,?,?,?,?)',
                [$userId, text_limit((string) $account, 180), self::ip(), isset($_SERVER['HTTP_USER_AGENT']) ? text_limit((string) $_SERVER['HTTP_USER_AGENT'], 255) : '', $success, now()]
            );
        } catch (\Throwable $e) {
            Logger::error('登录日志写入失败：' . $e->getMessage());
        }
    }

    public static function ip()
    {
        $remote = !empty($_SERVER['REMOTE_ADDR']) ? trim((string) $_SERVER['REMOTE_ADDR']) : '';
        if ($remote !== '' && self::isPrivateOrLocalIp($remote)) {
            foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP'] as $key) {
                if (empty($_SERVER[$key])) {
                    continue;
                }
                foreach (explode(',', (string) $_SERVER[$key]) as $candidate) {
                    $candidate = trim($candidate);
                    if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                        return $candidate;
                    }
                }
            }
        }
        if ($remote !== '' && filter_var($remote, FILTER_VALIDATE_IP)) {
            return $remote;
        }
        return '0.0.0.0';
    }

    protected static function isPrivateOrLocalIp($ip)
    {
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return false;
        }
        return !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }

    protected static function cookie($name, $value, $expires)
    {
        $secure = function_exists('bm_is_https_request') ? bm_is_https_request() : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443));
        setcookie($name, $value, [
            'expires' => $expires,
            'path' => '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
}
