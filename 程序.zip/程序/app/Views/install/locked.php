<div class="install-hero-brand">
    <div class="install-hero-title"><span data-icon="trophy"></span><b>BM TOOLS 安装向导</b></div>
    <p>轻量图床网盘系统 · 初始化配置</p>
</div>

<section class="install-card glass reveal">
    <p class="eyebrow">Installed</p>
    <h1>系统已安装</h1>
    <p>检测到安装锁文件，安装入口已禁用，避免重复初始化数据。</p>
    <div class="install-success-grid compact">
        <a class="install-success-link primary" href="<?= url('admin') ?>">
            <span data-icon="layout-dashboard"></span>
            <b>后台管理</b>
            <small>进入后台控制台继续配置站点。</small>
            <em>打开后台</em>
        </a>
        <a class="install-success-link" href="<?= url('/') ?>">
            <span data-icon="home"></span>
            <b>前台首页</b>
            <small>查看前台展示和用户入口。</small>
            <em>打开前台</em>
        </a>
    </div>
</section>

<footer class="install-hero-footer">BM TOOLS · Secure installer</footer>
