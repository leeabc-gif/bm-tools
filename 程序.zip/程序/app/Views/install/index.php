<?php
$allPassed = true;
$failedNames = [];
foreach ($checks as $check) {
    if (!$check['ok']) {
        $allPassed = false;
        $failedNames[] = $check['name'];
    }
}
?>

<div class="install-hero-brand">
    <div class="install-hero-title"><span data-icon="trophy"></span><b>BM TOOLS 安装向导</b></div>
    <p>轻量图床网盘系统 · 初始化配置</p>
</div>

<section class="install-console" data-install-wizard>
    <aside class="install-menu glass">
        <a class="console-brand" href="<?= url('install') ?>">
            <span class="brand-mark"><img src="<?= asset('icons/logo-mark.svg') ?>" alt="BM TOOLS Logo"></span>
            <span><b>BM TOOLS</b><small>Installer</small></span>
        </a>
        <nav class="console-nav install-nav">
            <p>安装步骤</p>
            <a class="active" href="#step-1" data-step-nav="1" data-icon="monitor-check">环境检测</a>
            <a href="#step-2" data-step-nav="2" data-icon="database">数据库配置</a>
            <a href="#step-3" data-step-nav="3" data-icon="shield-user">管理员配置</a>
            <a href="#step-4" data-step-nav="4" data-icon="rocket">开始安装</a>
        </nav>
    </aside>

    <div class="install-workspace">
        <header class="install-topbar glass">
            <div>
                <strong>BM TOOLS 安装向导</strong>
                <small>白蓝控制台风格 · 宝塔面板部署</small>
            </div>
            <span class="install-status-pill <?= $allPassed ? 'ok' : 'bad' ?>"><?= $allPassed ? '环境可用' : '需要修复环境' ?></span>
        </header>

        <main class="install-content">
            <?php if ($msg = flash('success')): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="alert error"><?= e($msg) ?></div><?php endif; ?>

            <form class="install-panel glass" method="post" action="<?= url('install') ?>" novalidate>
                <?= csrf_field() ?>
                <div class="install-panel-head">
                    <div>
                        <h1 data-step-title>环境检测</h1>
                        <p data-step-desc>确认 PHP 扩展、运行目录和缓存目录权限。</p>
                    </div>
                    <div class="install-progress"><span data-progress-bar></span></div>
                </div>

                <section class="install-screen active" data-step-panel="1">
                    <?php if (!$allPassed): ?>
                        <div class="alert error">未通过项目：<?= e(implode('、', $failedNames)) ?>。请在宝塔面板修复后刷新页面。</div>
                    <?php endif; ?>
                    <div class="install-table-grid">
                        <?php foreach ($checks as $check): ?>
                            <article class="<?= $check['ok'] ? 'ok' : 'bad' ?>">
                                <span class="status-dot <?= $check['ok'] ? 'online' : 'offline' ?>"><?= $check['ok'] ? '通过' : '异常' ?></span>
                                <h3><?= e($check['name']) ?></h3>
                                <?php if ($check['name'] === '目录权限'): ?>
                                    <div class="mini-table">
                                        <?php foreach ($check['value'] as $dir): ?>
                                            <p><span><?= e($dir['name']) ?></span><b><?= e($dir['value']) ?></b></p>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <b><?= e($check['value']) ?></b>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="install-screen" data-step-panel="2">
                    <div class="install-tip">
                        <b>数据库连接必须先测试通过</b>
                        <span>宝塔环境请填写数据库页面显示的专用账号和密码。`root` 经常因为密码或权限导致 1045。</span>
                    </div>
                    <div class="form-grid two">
                        <label>数据库地址<input name="db_host" value="<?= e(old('db_host', '127.0.0.1')) ?>" required data-summary-label="数据库地址"></label>
                        <label>数据库端口<input name="db_port" value="<?= e(old('db_port', '3306')) ?>" required data-summary-label="数据库端口"></label>
                        <label>数据库名<input name="db_name" value="<?= e(old('db_name')) ?>" required data-summary-label="数据库名"></label>
                        <label>数据库用户<input name="db_user" value="<?= e(old('db_user')) ?>" required data-summary-label="数据库用户"></label>
                        <label>数据库密码<input type="password" name="db_pass" value="<?= e(old('db_pass')) ?>" data-summary-label="数据库密码"></label>
                        <label>表前缀<input name="table_prefix" value="<?= e(old('table_prefix', 'bm_')) ?>" required pattern="[A-Za-z0-9_]+" data-summary-label="表前缀"></label>
                    </div>
                    <div class="install-test-result" data-db-result></div>
                </section>

                <section class="install-screen" data-step-panel="3">
                    <div class="form-grid two">
                        <label class="span-all">网站名称<input name="site_name" value="<?= e(old('site_name', app_brand_name())) ?>" required data-summary-label="网站名称"></label>
                        <label>管理员用户名<input name="admin_username" value="<?= e(old('admin_username', 'admin')) ?>" required minlength="3" maxlength="32" pattern="[A-Za-z0-9_]+" data-summary-label="管理员用户名"></label>
                        <label>管理员邮箱<input type="email" name="admin_email" value="<?= e(old('admin_email')) ?>" required data-summary-label="管理员邮箱"></label>
                        <label class="span-all">管理员密码<input type="password" name="admin_password" required minlength="6" autocomplete="new-password" data-summary-label="管理员密码"></label>
                    </div>
                </section>

                <section class="install-screen" data-step-panel="4">
                    <div class="install-summary-grid">
                        <div><span>数据库</span><b data-summary="db_name">-</b></div>
                        <div><span>数据库用户</span><b data-summary="db_user">-</b></div>
                        <div><span>表前缀</span><b data-summary="table_prefix">-</b></div>
                        <div><span>网站名称</span><b data-summary="site_name">-</b></div>
                        <div><span>管理员</span><b data-summary="admin_username">-</b></div>
                        <div><span>数据库测试</span><b data-db-summary>未测试</b></div>
                    </div>
                    <label class="inline-check install-confirm">
                        <input type="checkbox" name="install_confirm" required>
                        <span>我确认数据库信息正确，并允许安装程序写入 BM TOOLS 数据表和初始化数据。</span>
                    </label>
                </section>

                <div class="install-actions">
                    <button class="btn btn-ghost" type="button" data-prev>上一步</button>
                    <button class="btn btn-primary" type="button" data-next>下一步</button>
                    <button class="btn btn-primary" type="button" data-test-db>测试数据库，下一步</button>
                    <button class="btn btn-primary" type="submit" data-submit>开始安装</button>
                </div>
                <div class="install-inline-error" data-install-error></div>
            </form>
        </main>
    </div>
</section>

<footer class="install-hero-footer">BM TOOLS · Secure installer</footer>

<script>
(function () {
    var root = document.querySelector('[data-install-wizard]');
    if (!root) return;
    var form = root.querySelector('.install-panel');
    var screens = Array.prototype.slice.call(root.querySelectorAll('[data-step-panel]'));
    var navs = Array.prototype.slice.call(root.querySelectorAll('[data-step-nav]'));
    var prevBtn = root.querySelector('[data-prev]');
    var nextBtn = root.querySelector('[data-next]');
    var testBtn = root.querySelector('[data-test-db]');
    var submitBtn = root.querySelector('[data-submit]');
    var errorBox = root.querySelector('[data-install-error]');
    var title = root.querySelector('[data-step-title]');
    var desc = root.querySelector('[data-step-desc]');
    var bar = root.querySelector('[data-progress-bar]');
    var dbResult = root.querySelector('[data-db-result]');
    var dbSummary = root.querySelector('[data-db-summary]');
    var dbOk = false;
    var current = 0;
    var installing = false;
    var titles = [
        ['环境检测', '确认 PHP 扩展、运行目录和缓存目录权限。'],
        ['数据库配置', '填写并测试宝塔 MySQL 数据库连接。'],
        ['管理员配置', '创建第一个后台管理员账号。'],
        ['确认安装', '写入配置、初始化数据并进入后台。']
    ];

    function setError(message) {
        errorBox.textContent = message || '';
        errorBox.classList.toggle('show', !!message);
    }
    function setDbResult(type, message) {
        dbResult.textContent = message || '';
        dbResult.className = 'install-test-result' + (message ? ' show ' + type : '');
        if (dbSummary) dbSummary.textContent = dbOk ? '已通过' : '未通过';
    }
    function show(index) {
        current = Math.max(0, Math.min(3, index));
        screens.forEach(function (screen, i) { screen.classList.toggle('active', i === current); });
        navs.forEach(function (nav, i) {
            nav.classList.toggle('active', i === current);
            nav.classList.toggle('done', i < current);
        });
        title.textContent = titles[current][0];
        desc.textContent = titles[current][1];
        bar.style.width = ((current + 1) / 4 * 100) + '%';
        prevBtn.style.display = current === 0 ? 'none' : 'inline-flex';
        nextBtn.style.display = current === 0 || current === 2 ? 'inline-flex' : 'none';
        testBtn.style.display = current === 1 ? 'inline-flex' : 'none';
        submitBtn.style.display = current === 3 ? 'inline-flex' : 'none';
        setError('');
        updateSummary();
    }
    function validate(index) {
        var fields = screens[index].querySelectorAll('input, select, textarea');
        for (var i = 0; i < fields.length; i++) {
            if (!fields[i].checkValidity()) {
                show(index);
                fields[i].focus();
                setError(fields[i].getAttribute('data-summary-label') ? '请检查：' + fields[i].getAttribute('data-summary-label') : '请完整填写当前步骤。');
                fields[i].reportValidity();
                return false;
            }
        }
        return true;
    }
    function value(name) {
        var field = form.elements[name];
        return field && field.value ? field.value.trim() : '未填写';
    }
    function compactText(source) {
        var text = String(source || '')
            .replace(/<script[\s\S]*?<\/script>/gi, ' ')
            .replace(/<style[\s\S]*?<\/style>/gi, ' ')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        return text.length > 180 ? text.slice(0, 180) + '...' : text;
    }
    function installJson(res) {
        return res.text().then(function (text) {
            try {
                return text ? JSON.parse(text) : {};
            } catch (error) {
                throw new Error(compactText(text) || ('接口返回异常，HTTP ' + res.status));
            }
        });
    }
    function updateSummary() {
        root.querySelectorAll('[data-summary]').forEach(function (node) {
            node.textContent = value(node.getAttribute('data-summary'));
        });
        if (dbSummary) dbSummary.textContent = dbOk ? '已通过' : '未测试';
    }
    function testDb() {
        if (!validate(1)) return;
        testBtn.disabled = true;
        testBtn.textContent = '测试中...';
        setDbResult('loading', '正在连接数据库...');
        fetch("<?= e(url('install/test-db')) ?>", {
            method: 'POST',
            body: new FormData(form),
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (res) {
            return installJson(res);
        }).then(function (json) {
            dbOk = !!json.success;
            if (!dbOk) {
                setDbResult('error', json.message || '数据库连接失败。');
                setError(json.message || '数据库连接失败。');
                return;
            }
            setDbResult('success', (json.message || '数据库连接成功。') + (json.version ? ' MySQL ' + json.version : ''));
            show(2);
        }).catch(function (error) {
            dbOk = false;
            setDbResult('error', error && error.message ? error.message : '数据库测试请求失败，请检查伪静态和 PHP 会话。');
        }).finally(function () {
            testBtn.disabled = false;
            testBtn.textContent = '测试数据库，下一步';
            updateSummary();
        });
    }
    prevBtn.addEventListener('click', function () { show(current - 1); });
    nextBtn.addEventListener('click', function () { if (validate(current)) show(current + 1); });
    testBtn.addEventListener('click', testDb);
    form.addEventListener('input', function (e) {
        if (e.target && ['db_host', 'db_port', 'db_name', 'db_user', 'db_pass', 'table_prefix'].indexOf(e.target.name) !== -1) {
            dbOk = false;
            setDbResult('', '');
        }
        updateSummary();
    });
    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (installing) return;
        if (!validate(1) || !validate(2) || !validate(3)) return;
        if (!dbOk) {
            show(1);
            setError('请先测试数据库连接，通过后再安装。');
            return;
        }
        installing = true;
        submitBtn.disabled = true;
        submitBtn.textContent = '正在安装...';
        HTMLFormElement.prototype.submit.call(form);
    });
    navs.forEach(function (nav, index) {
        nav.addEventListener('click', function (event) {
            event.preventDefault();
            if (index <= current) show(index);
        });
    });
    show(0);
})();
</script>
