<div class="install-hero-brand">
    <div class="install-hero-title"><span data-icon="check-circle-2"></span><b>BM TOOLS 安装完成</b></div>
    <p>系统已经可以使用，请从下面选择要进入的区域。</p>
</div>

<section class="install-card install-success-card glass reveal">
    <p class="eyebrow">Success</p>
    <h1>安装成功，下一步从这里开始</h1>
    <p>数据库表、初始套餐、支付配置、公告和管理员账号已创建。安装完成后会自动保持管理员会话，你可以直接进入后台配置站点，也可以先打开前台检查首页和用户入口。</p>

    <div class="install-success-grid">
        <a class="install-success-link primary" href="<?= e($adminUrl) ?>">
            <span data-icon="layout-dashboard"></span>
            <b>进入后台管理</b>
            <small>配置站点、套餐、存储、支付、公告、服务器监控等后台功能。</small>
            <em>打开后台</em>
        </a>
        <a class="install-success-link" href="<?= e($frontUrl) ?>">
            <span data-icon="home"></span>
            <b>查看前台首页</b>
            <small>检查前台首页、登录注册入口、用户中心入口和移动端展示。</small>
            <em>打开前台</em>
        </a>
    </div>

    <div class="install-success-note">
        <span data-icon="info"></span>
        <div>
            <b>重要提示</b>
            <p>生产环境建议把网站运行目录指向 <code>public</code>，保留 <code>storage/install.lock</code>，并尽快到后台完善站点地址、存储源和邮件配置。</p>
        </div>
    </div>
</section>

<footer class="install-hero-footer">BM TOOLS · Ready for launch</footer>
