<?php
$productBrand = app_brand_name();
$siteName = setting('site_name', $productBrand);
$currentUser = \App\Core\Auth::user();
$frontThemeStyle = setting('frontend_theme_style', 'classic') === 'anime' ? 'anime' : 'classic';
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="application-name" content="<?= e($productBrand) ?>">
    <?= favicon_tags() ?>
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : '公告中心 - ' . $siteName) ?></title>
    <meta name="keywords" content="<?= e(setting('seo_keywords', '图床,网盘,对象存储,公告,帮助中心')) ?>">
    <meta name="description" content="<?= e(setting('seo_description', app_brand_name() . ' 博客，记录平台公告、使用教程、维护笔记和产品更新。')) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/mobile.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/theme-anime.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/responsive-fix.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/macos-liquid.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/product-clean.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/front-cloud.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="notice-body cloud-home-body" data-theme="<?= e(setting('default_theme', 'auto')) ?>" data-theme-style="<?= e($frontThemeStyle) ?>">
<section class="cloud-home pro-home space-home notice-space-app">
    <header class="space-header notice-space-header">
        <div class="space-shell space-header-shell">
            <a class="space-brand" href="<?= url('/') ?>" aria-label="<?= e($siteName) ?>">
                <span class="space-brand-mark" aria-hidden="true"><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
                <span><?= e($siteName) ?></span>
            </a>
            <nav class="space-nav" aria-label="主导航">
                <a class="space-nav-link" href="<?= url('/') ?>">首页</a>
                <a class="space-nav-link" href="<?= url('announcements') ?>">公告</a>
                <a class="space-nav-link" href="<?= url('status') ?>">服务器状态</a>
                <?php if ($currentUser): ?>
                    <a class="space-nav-link" href="<?= url('dashboard') ?>">个人中心</a>
                <?php else: ?>
                    <a class="space-nav-link" href="<?= url('register') ?>">注册</a>
                <?php endif; ?>
            </nav>
            <div class="space-header-actions">
                <?php if ($currentUser): ?>
                    <a class="space-button space-button-ghost" href="<?= url('status') ?>">状态</a>
                    <a class="space-button space-button-dark" href="<?= url('dashboard') ?>">控制台</a>
                <?php else: ?>
                    <a class="space-button space-button-ghost" href="<?= url('register') ?>">注册</a>
                    <a class="space-button space-button-dark" href="<?= url('login') ?>">登录</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main class="space-main notice-space-main">
        <?= $content ?>
    </main>

    <footer class="space-footer notice-space-footer">
        <div class="space-shell space-footer-shell">
            <b><?= e($productBrand) ?></b>
            <span>公告、教程、维护记录与产品更新</span>
            <nav aria-label="页脚导航">
                <a href="<?= url('announcements') ?>">公告</a>
                <a href="<?= url('status') ?>">服务器状态</a>
                <?php if ($currentUser): ?>
                    <a href="<?= url('dashboard') ?>">个人中心</a>
                <?php else: ?>
                    <a href="<?= url('login') ?>">登录</a>
                <?php endif; ?>
            </nav>
        </div>
    </footer>
</section>

<script>
window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
window.SKY_DEFAULT_THEME = "<?= e(setting('default_theme', 'auto')) ?>";
window.SKY_THEME_SCOPE = "front";
window.SKY_THEME_STYLE = "<?= e($frontThemeStyle) ?>";
</script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
