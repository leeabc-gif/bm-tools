<?php $productBrand = app_brand_name(); $siteName = setting('site_name', $productBrand); ?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="application-name" content="<?= e($productBrand) ?>">
    <?= favicon_tags() ?>
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : $siteName) ?></title>
    <style>
        *{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",Arial,sans-serif;color:#2f3b52;background:#f3f6fb;font-size:14px}a{text-decoration:none;color:inherit}button{font:inherit}
        .ops-app{min-height:100vh;background:#f3f6fb}.ops-top{height:58px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;background:rgba(255,255,255,.92);backdrop-filter:blur(14px);border-bottom:1px solid #e7edf5;box-shadow:0 2px 10px rgba(34,55,90,.04);position:sticky;top:0;z-index:20}.ops-top-left,.ops-top-right{display:flex;align-items:center;gap:12px}.ops-icon{width:34px;height:34px;border:1px solid transparent;background:transparent;color:#506078;display:grid;place-items:center;border-radius:8px;cursor:pointer}.ops-icon svg{width:17px;height:17px;stroke:currentColor;stroke-width:2;fill:none}.ops-icon:hover{background:#f0f5fb;border-color:#dfe9f6}.ops-mode{height:34px;border:1px solid #dbe6f3;background:#f8fbff;color:#40516a;border-radius:8px;padding:0 12px;cursor:pointer;font-weight:800}.ops-mode:hover{border-color:#9ac5ff;color:#1268e8}.ops-user{display:flex;align-items:center;gap:9px;color:#1268e8;font-weight:800}.ops-avatar{width:32px;height:32px;border-radius:999px;background:linear-gradient(135deg,#3ad0c4,#3d8cff);box-shadow:0 8px 18px rgba(52,124,255,.18)}
        .ops-tabs{height:42px;display:flex;align-items:center;gap:2px;padding:0 18px;background:#fff;border-bottom:1px solid #e7edf5;color:#63748b;font-size:13px}.ops-tab{height:100%;display:inline-flex;align-items:center;gap:8px;padding:0 16px;border-right:1px solid #edf1f6}.ops-tab.active{color:#1268e8;background:#f8fbff}.ops-page{padding:18px 22px 44px}
        .ops-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}.ops-card{min-height:96px;border-radius:10px;padding:18px 20px;color:#fff;box-shadow:0 8px 18px rgba(40,73,120,.13);display:grid;align-content:center;gap:8px;position:relative;overflow:hidden}.ops-card:after{content:"";position:absolute;right:-24px;top:-28px;width:92px;height:92px;border-radius:50%;background:rgba(255,255,255,.15)}.ops-card span{font-size:13px;font-weight:800}.ops-card b{font-size:29px;line-height:1}.ops-card small{opacity:.86}.ops-cyan{background:linear-gradient(135deg,#2abfd2,#1ca7d8)}.ops-green{background:linear-gradient(135deg,#18c783,#10a874)}.ops-red{background:linear-gradient(135deg,#ff7b61,#f05d6e)}.ops-purple{background:linear-gradient(135deg,#347cff,#46b6ff)}
        .ops-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(420px,.8fr);gap:18px}.ops-panel{background:#fff;border:1px solid #dde6f2;border-radius:8px;box-shadow:0 2px 12px rgba(47,70,105,.08);overflow:hidden}.ops-panel-head{height:46px;display:flex;align-items:center;gap:20px;padding:0 16px;border-bottom:1px solid #e8eef6;color:#2f3b52;font-weight:800}.ops-panel-head span{color:#8795aa;font-weight:600}.ops-panel-body{padding:16px}
        .server-list{display:grid;gap:10px}.server-row{width:100%;display:grid;grid-template-columns:minmax(190px,1.2fr) 84px 84px 130px 130px 84px 84px;align-items:center;gap:10px;border:1px solid #e5edf6;background:#fff;border-radius:8px;padding:12px;text-align:left;cursor:pointer;transition:.18s ease}.server-row:hover{border-color:#b9d5ff;box-shadow:0 8px 18px rgba(37,100,190,.08);transform:translateY(-1px)}.server-name{display:grid;gap:4px}.server-name b{font-size:15px;color:#21304a}.server-name span{color:#7d8da4;font-size:12px}.server-tag{display:inline-flex;align-items:center;width:max-content;min-height:20px;padding:0 7px;border-radius:99px;background:#eaf4ff;color:#1268e8;font-size:11px;font-weight:800}.mini-ring{--p:0;--c:#347cff;width:54px;height:54px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(var(--c) calc(var(--p)*1%),#e9eff6 0);position:relative}.mini-ring:after{content:"";position:absolute;inset:7px;background:#fff;border-radius:inherit}.mini-ring i{position:relative;z-index:1;font-style:normal;color:#1d2a42;font-size:12px;font-weight:900}.disk-mini{display:grid;gap:4px}.disk-mini b{font-size:12px;color:#26344e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.disk-mini span{font-size:11px;color:#718198}.disk-bar{height:8px;border-radius:99px;background:#e9eff6;overflow:hidden}.disk-bar i{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#40c77a,#1abf8f)}.net-mini{display:grid;gap:4px;color:#65768d;font-size:12px;font-weight:700}.load-mini{font-size:20px;font-weight:900;color:#26344e;text-align:center}.state-pill{display:inline-flex;align-items:center;justify-content:center;min-height:24px;border-radius:99px;padding:0 10px;font-size:12px;font-weight:900}.state-ok{color:#07936b;background:#dff8ed}.state-bad{color:#c25d00;background:#fff0da}.empty-state{padding:28px;color:#718198}
        .notice-list{display:grid;gap:12px;line-height:1.75;color:#42526b}.notice-row{display:grid;grid-template-columns:34px 1fr;gap:10px;align-items:flex-start;margin:0}.notice-mark{width:28px;height:28px;border-radius:8px;background:#eaf4ff;color:#1268e8;display:grid;place-items:center;font-size:12px;font-weight:900}.detail-panel{margin-top:18px}.metric-cards{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px;margin-bottom:14px}.metric-card{height:80px;border:1px solid #dbe5f1;border-radius:10px;background:#fbfdff;display:grid;place-items:center;position:relative;overflow:hidden}.metric-card:before{content:"";position:absolute;left:13px;right:13px;top:14px;height:12px;border-radius:99px;background:linear-gradient(90deg,#347cff var(--w,0%),#e8eef6 0)}.metric-card span{margin-top:18px;color:#72829a;font-size:11px;font-weight:900}.metric-card b{color:#26344e;font-size:18px}
        .range-tabs{display:flex;align-items:center;gap:5px;flex-wrap:wrap;padding-bottom:12px;border-bottom:1px solid #dfe7f2;margin-bottom:16px}.range-tabs button{height:26px;min-width:34px;border:1px solid #d6e3f3;background:#f8fbff;color:#6d7e96;border-radius:6px;cursor:pointer}.range-tabs button.active{border-color:#84b7ff;color:#1268e8;background:#eaf3ff}.range-tabs span{margin-left:auto;color:#7a8aa1;font-size:12px}
        .charts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.chart-card{border:1px solid #dbe5f1;border-radius:10px;background:#fff;overflow:hidden}.chart-title{height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;border-bottom:1px solid #dbe5f1;color:#39465a;font-weight:900}.chart-title small{color:#8492a8}.chart-card canvas{width:100%;display:block}.detail-bottom{display:grid;grid-template-columns:.8fr 1.2fr;gap:14px;margin-top:14px}.service-box,.disk-box{display:grid;gap:8px;padding:14px;border:1px solid #dbe5f1;border-radius:10px;background:#fff}.service-box span{display:flex;justify-content:space-between;color:#65768d}.service-box em{font-style:normal;color:#1268e8;font-weight:900}.disk-box span{display:grid;gap:5px}.disk-box strong,.disk-box em{font-style:normal;color:#39465a}.disk-box i{height:8px;border-radius:99px;background:#e7edf5;overflow:hidden}.disk-box u{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#347cff,#45c4ff)}
        .drawer{position:fixed;inset:0;background:rgba(26,42,64,.38);z-index:100;display:none;align-items:stretch;justify-content:flex-end}.drawer.open{display:flex}.drawer-card{width:min(860px,100%);margin:12px;background:#fff;border-radius:10px;box-shadow:0 18px 60px rgba(0,0,0,.22);overflow:auto}.drawer-head{height:58px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid #e5edf6}.drawer-head h2{margin:0;font-size:18px;color:#21304a}.drawer-head span{color:#7a8aa1;font-size:12px}.drawer-body{padding:16px}.close-btn{border:1px solid #dbe5f1;background:#fff;border-radius:6px;height:30px;padding:0 10px;cursor:pointer}
        body.night{background:#111a2c;color:#eef4ff}.night .ops-top,.night .ops-tabs,.night .ops-panel,.night .server-row,.night .drawer-card,.night .chart-card,.night .service-box,.night .disk-box{background:#17233b;border-color:#2d3a55}.night .ops-panel-head,.night .server-name b,.night .load-mini,.night .metric-card b,.night .chart-title,.night .drawer-head h2{color:#eef4ff}.night .metric-card,.night .mini-ring:after{background:#17233b}.night .server-name span,.night .notice-list,.night .range-tabs span{color:#a7b4c8}.night .ops-tab.active,.night .notice-mark{background:#1d2b49}.night .ops-mode{background:#1d2b49;border-color:#334362;color:#dbe9ff}
        @media(max-width:1100px){.ops-grid{grid-template-columns:1fr}.metric-cards{grid-template-columns:repeat(3,1fr)}.server-list{overflow:visible}.server-row{min-width:0}.ops-summary{grid-template-columns:repeat(2,1fr)}}@media(max-width:680px){.ops-page{padding:12px}.ops-summary{grid-template-columns:1fr}.ops-grid,.charts,.detail-bottom{grid-template-columns:1fr}.metric-cards{grid-template-columns:repeat(2,1fr)}.ops-tabs{overflow-x:auto}.drawer-card{margin:0;border-radius:0}}

        /* Server-first status dashboard */
        body{background:#f5f7fb;color:#172033}.ops-app{background:#f5f7fb}.ops-top{height:56px;background:#fff;border-bottom:1px solid #e2e8f0;box-shadow:none;backdrop-filter:none}.ops-tabs{height:44px;background:#fff;border-bottom:1px solid #e2e8f0}.ops-tab{border-right:0;border-bottom:2px solid transparent}.ops-tab.active{background:#fff;color:#2563eb;border-bottom-color:#2563eb}.ops-page{padding:16px;max-width:1680px;margin:0 auto}.ops-summary{grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:14px}.ops-card{min-height:78px;padding:14px 16px;border:1px solid #e2e8f0;border-radius:12px;background:#fff!important;color:#172033;box-shadow:0 8px 24px rgba(15,23,42,.055);overflow:hidden}.ops-card:after{display:none}.ops-card span{color:#64748b}.ops-card b{font-size:26px;color:#172033}.ops-card small{color:#64748b;opacity:1}.ops-grid{grid-template-columns:minmax(560px,.95fr) minmax(520px,1.05fr);gap:14px;align-items:start}.ops-panel{border:1px solid #e2e8f0;border-radius:14px;background:#fff;box-shadow:0 8px 24px rgba(15,23,42,.055)}.ops-panel-head{min-height:54px;height:auto;padding:12px 16px;border-bottom:1px solid #e2e8f0;justify-content:space-between}.ops-panel-head>div{display:grid;gap:4px}.ops-panel-head b{font-size:15px;color:#172033}.ops-panel-head span{font-size:12px;color:#64748b}.ops-panel-body{padding:14px}.server-list{gap:8px}.server-row{grid-template-columns:minmax(180px,1.2fr) 74px 74px minmax(150px,.9fr) minmax(112px,.7fr) 58px 70px;gap:10px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;padding:12px;box-shadow:none;transition:border-color .16s ease,background .16s ease}.server-row:hover,.server-row.active{transform:none;border-color:#93c5fd;background:#f8fbff;box-shadow:none}.server-name b{font-size:14px;color:#172033}.server-name span{font-size:12px;color:#64748b}.server-tag{background:#eff6ff;color:#2563eb}.mini-ring{width:54px;height:54px;background:#f1f5f9;border:1px solid #e2e8f0}.mini-ring:after{inset:0;background:transparent}.mini-ring i{color:#172033}.disk-bar,.home-progress-track{background:#e2e8f0}.disk-bar i,.disk-box u{background:#2563eb}.state-pill{border-radius:999px}.state-ok{color:#166534;background:#dcfce7}.state-bad{color:#991b1b;background:#fee2e2}.state-muted{color:#475569;background:#f1f5f9}.server-detail-card{position:sticky;top:114px}.server-detail-body{display:grid;gap:14px}.metric-cards{grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-bottom:0}.metric-card{height:76px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;place-items:start;padding:14px;box-shadow:none}.metric-card:before{left:14px;right:14px;top:auto;bottom:12px;height:7px;background:linear-gradient(90deg,#2563eb var(--w,0%),#e2e8f0 0)}.metric-card span{margin:0;color:#64748b;font-size:12px}.metric-card b{font-size:20px;color:#172033}.charts{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.chart-card{border:1px solid #e2e8f0;border-radius:12px}.chart-title{height:38px;border-bottom:1px solid #e2e8f0;color:#172033}.detail-bottom{grid-template-columns:.8fr 1.2fr;gap:10px;margin-top:0}.service-box,.disk-box{border:1px solid #e2e8f0;border-radius:12px;background:#fff}.compact-notice{padding-top:4px;border-top:1px solid #e2e8f0}.notice-row{grid-template-columns:28px 1fr}.notice-mark{width:24px;height:24px;border-radius:8px;background:#eff6ff;color:#2563eb}.drawer{display:none!important}.night{background:#0f172a}.night .ops-app{background:#0f172a}.night .ops-top,.night .ops-tabs,.night .ops-panel,.night .ops-card,.night .server-row,.night .chart-card,.night .service-box,.night .disk-box,.night .metric-card{background:#111827!important;border-color:#263244;color:#e5edf8}.night .ops-panel-head,.night .server-name b,.night .load-mini,.night .metric-card b,.night .chart-title,.night .ops-card b{color:#e5edf8}.night .ops-card span,.night .ops-card small,.night .server-name span,.night .notice-list,.night .ops-panel-head span{color:#94a3b8}.night .server-row:hover,.night .server-row.active{background:#162033;border-color:#3b82f6}.night .mini-ring{background:#172033;border-color:#263244}.night .mini-ring i{color:#e5edf8}
        /* Responsive server cards: no clipped right side, no forced horizontal table row */
        .server-list{overflow:visible!important}
        .server-row{width:100%;min-width:0!important;grid-template-columns:minmax(180px,1.2fr) repeat(2,64px) minmax(140px,.9fr) minmax(106px,.7fr) 64px auto!important;gap:10px!important;overflow:visible!important}
        .server-row>*{min-width:0}
        .server-name b,.server-name span,.disk-mini b,.disk-mini span,.net-mini span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .mini-ring{width:48px!important;height:48px!important}
        .mini-ring i{font-size:11px!important}.load-mini{font-size:18px!important}.state-pill{white-space:nowrap}
        @media(max-width:1500px){.ops-grid{grid-template-columns:1fr}.server-detail-card{position:static}.server-row{grid-template-columns:minmax(220px,1fr) repeat(2,64px) minmax(170px,1fr) minmax(120px,.7fr) 64px auto!important}}
        @media(max-width:980px){.server-row{grid-template-columns:minmax(0,1fr) repeat(2,58px) auto!important}.disk-mini,.net-mini,.load-mini{grid-column:auto}.state-pill{justify-self:end}.disk-mini{grid-column:1 / -1}.net-mini{grid-column:1 / span 2;display:flex;gap:12px;flex-wrap:wrap}.load-mini{grid-column:3 / span 1;text-align:left}.server-name b,.server-name span,.disk-mini b,.disk-mini span,.net-mini span{white-space:normal}.ops-summary{grid-template-columns:repeat(2,minmax(0,1fr))}}
        @media(max-width:760px){.ops-page{padding:10px}.ops-grid{gap:10px}.metric-cards,.charts,.detail-bottom{grid-template-columns:1fr}.ops-top{padding:0 10px}.ops-tabs{padding:0 10px;overflow-x:auto}.ops-user span:last-child{display:none}.server-row{grid-template-columns:minmax(0,1fr) auto!important;align-items:start}.server-name{grid-column:1 / 2}.mini-ring{width:46px!important;height:46px!important}.server-row .mini-ring:nth-of-type(1){grid-column:1 / 2}.server-row .mini-ring:nth-of-type(2){grid-column:2 / 3}.disk-mini,.net-mini,.load-mini{grid-column:1 / -1}.state-pill{grid-column:2 / 3;grid-row:1 / 2;justify-self:end}.net-mini{display:flex;gap:10px}.load-mini{text-align:left;font-size:16px!important}}
        @media(max-width:520px){.ops-summary{grid-template-columns:1fr}.ops-card b{font-size:22px}.server-row{padding:10px}.ops-panel-body{padding:10px}}
        /* Mobile status detail: compact cards, readable service/disk blocks, no clipped content */
        @media(max-width:760px){
            html,body{width:100%;overflow-x:hidden}
            .ops-app{min-width:0}
            .ops-top{height:52px;padding:0 12px}
            .ops-top-left{min-width:0;gap:8px}
            .ops-top-left b{max-width:42vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
            .ops-mode{height:32px;padding:0 9px;font-size:12px}
            .ops-user{gap:6px;font-size:12px}
            .ops-avatar{width:28px;height:28px}
            .ops-tabs{height:40px;padding:0 8px;gap:0;overflow-x:auto;scrollbar-width:none}
            .ops-tabs::-webkit-scrollbar{display:none}
            .ops-tab{min-width:max-content;padding:0 12px;font-size:12px}
            .ops-page{width:100%;padding:10px 10px 84px}
            .ops-summary{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:10px}
            .ops-card{min-height:72px;padding:12px;border-radius:12px;box-shadow:none}
            .ops-card b{font-size:22px}
            .ops-card span,.ops-card small{font-size:12px}
            .ops-grid{display:grid;grid-template-columns:1fr;gap:10px}
            .ops-panel{border-radius:12px;box-shadow:none}
            .ops-panel-head{min-height:48px;padding:10px 12px;gap:10px}
            .ops-panel-head b{font-size:14px}
            .ops-panel-head span{font-size:11px}
            .ops-panel-body{padding:10px}
            .server-list{gap:8px}
            .server-row{display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;gap:8px!important;padding:10px!important;border-radius:12px!important}
            .server-name{grid-column:1 / 2;min-width:0}
            .server-name b{font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
            .server-name span{font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
            .server-row .mini-ring{display:none!important}
            .disk-mini{grid-column:1 / -1!important;display:grid;gap:5px}
            .net-mini{grid-column:1 / -1!important;display:grid!important;grid-template-columns:1fr 1fr;gap:6px;color:#64748b;font-size:11px}
            .load-mini{grid-column:1 / 2!important;font-size:13px!important;text-align:left}
            .state-pill{grid-column:2 / 3!important;grid-row:1 / 2!important;min-height:22px;padding:0 8px;font-size:11px}
            .server-detail-card{position:static!important}
            .server-detail-body{gap:10px}
            .metric-cards{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important}
            .metric-card{height:auto;min-height:68px;padding:10px;border-radius:10px}
            .metric-card span{font-size:11px}
            .metric-card b{font-size:16px;line-height:1.15;word-break:break-all}
            .metric-card:before{left:10px;right:10px;bottom:9px;height:6px}
            .charts{display:grid!important;grid-template-columns:1fr!important;gap:8px!important}
            .chart-title{height:auto;min-height:36px;padding:8px 10px;font-size:12px}
            .chart-card canvas{height:120px!important}
            .detail-bottom{display:grid!important;grid-template-columns:1fr!important;gap:8px!important}
            .service-box,.disk-box{padding:12px;border-radius:10px;gap:8px}
            .service-box b,.disk-box b{font-size:13px}
            .service-box span{font-size:12px;gap:10px}
            .service-box em{max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
            .disk-box span{gap:5px}
            .disk-box strong,.disk-box em{font-size:12px;overflow-wrap:anywhere}
            .notice-list{gap:8px;font-size:12px;line-height:1.65}
            .notice-row{grid-template-columns:26px 1fr;gap:8px}
            .notice-mark{width:22px;height:22px;border-radius:7px;font-size:11px}
        }
        @media(max-width:420px){
            .ops-summary{grid-template-columns:1fr}
            .metric-cards{grid-template-columns:1fr!important}
            .net-mini{grid-template-columns:1fr}
            .ops-top-left b{max-width:34vw}
        }
        @media(max-width:768px){
            html,body{width:100%!important;max-width:100%!important;min-width:0!important;margin:0!important;padding:0!important;overflow-x:hidden!important;font-size:14px!important}
            *{box-sizing:border-box!important}
            .ops-app{width:100%!important;min-width:0!important;overflow-x:hidden!important;background:#f6f8fb!important}
            .ops-top{height:auto!important;min-height:56px!important;padding:8px 10px!important;gap:8px!important;position:sticky!important;top:0!important;z-index:60!important}
            .ops-top-left,.ops-top-right{min-width:0!important;gap:8px!important}
            .ops-top-left b{max-width:44vw!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}
            .ops-mode,.ops-icon{min-width:44px!important;min-height:44px!important;border-radius:12px!important}
            .ops-tabs{height:auto!important;min-height:42px!important;padding:0 8px!important;overflow-x:auto!important;white-space:nowrap!important;scrollbar-width:none!important}
            .ops-tabs::-webkit-scrollbar{display:none!important}
            .ops-tab{min-width:max-content!important;padding:0 12px!important}
            .ops-page{width:100%!important;max-width:100%!important;padding:10px!important;overflow-x:hidden!important}
            .ops-summary,.ops-grid,.metric-cards,.charts,.detail-bottom{width:100%!important;max-width:100%!important;display:grid!important;grid-template-columns:1fr!important;gap:12px!important}
            .ops-card,.ops-panel,.chart-card,.service-box,.disk-box,.metric-card{width:100%!important;max-width:100%!important;min-width:0!important;border-radius:16px!important;box-shadow:0 2px 12px rgba(15,23,42,.08)!important;overflow:hidden!important}
            .server-list{width:100%!important;display:grid!important;gap:10px!important;overflow:visible!important}
            .server-row{width:100%!important;max-width:100%!important;min-width:0!important;display:grid!important;grid-template-columns:1fr auto!important;gap:8px!important;padding:12px!important;border-radius:16px!important;box-shadow:0 2px 12px rgba(15,23,42,.08)!important}
            .server-row>*{min-width:0!important}
            .server-name{grid-column:1 / 2!important}
            .server-name b,.server-name span{max-width:100%!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}
            .server-row .mini-ring{display:none!important}
            .disk-mini,.net-mini,.load-mini{grid-column:1 / -1!important}
            .state-pill{grid-column:2 / 3!important;grid-row:1 / 2!important;min-height:28px!important;border-radius:999px!important}
            .chart-card canvas{width:100%!important;height:130px!important}
            .drawer-card,.status-detail-panel{width:calc(100vw - 20px)!important;max-width:calc(100vw - 20px)!important;margin:10px!important;border-radius:16px!important}
        }
        /* Rectangular resource metrics: cleaner than circular usage rings */
        .mini-ring{display:none!important}
        .server-row{grid-template-columns:minmax(190px,1.15fr) minmax(108px,.58fr) minmax(108px,.58fr) minmax(150px,.86fr) minmax(112px,.68fr) 58px 70px!important}
        .server-metric{min-width:0;display:grid;grid-template-columns:auto auto;align-items:center;gap:5px 8px}
        .server-metric span{color:#64748b;font-size:11px;font-weight:800;letter-spacing:0}
        .server-metric b{justify-self:end;color:#172033;font-size:13px;font-weight:900;line-height:1}
        .server-metric i{grid-column:1 / -1;display:block;height:6px;border-radius:999px;background:#e2e8f0;overflow:hidden}
        .server-metric u{display:block;height:100%;border-radius:inherit;background:#2563eb}
        .server-metric + .server-metric u{background:#0891b2}
        .night .server-metric span{color:#94a3b8}
        .night .server-metric b{color:#e5edf8}
        .night .server-metric i{background:#263244}
        @media(max-width:980px){
            .server-row{grid-template-columns:minmax(0,1fr) auto!important;align-items:start!important}
            .server-name{grid-column:1 / 2!important}
            .server-metric{grid-column:1 / -1!important;grid-template-columns:52px 58px minmax(0,1fr)!important;gap:8px!important}
            .server-metric b{justify-self:start!important}
            .server-metric i{grid-column:3 / 4!important;align-self:center!important}
            .disk-mini,.net-mini,.load-mini{grid-column:1 / -1!important}
            .state-pill{grid-column:2 / 3!important;grid-row:1 / 2!important;justify-self:end!important}
        }
        @media(max-width:520px){
            .server-metric{grid-template-columns:48px 54px minmax(0,1fr)!important}
            .server-metric span,.server-metric b{font-size:11px!important}
            .server-metric i{height:5px!important}
        }
    </style>
    <link rel="stylesheet" href="<?= asset('css/responsive-fix.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/macos-liquid.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/product-clean.css') ?>">
</head>
<body>
<?= $content ?>
<script>
(function(){
    function $(id){return document.getElementById(id);}
    function draw(canvas, series, colors){
        if(!canvas)return;var ctx=canvas.getContext('2d'),w=canvas.clientWidth||360,h=parseInt(canvas.getAttribute('height')||170,10),r=window.devicePixelRatio||1;
        canvas.width=w*r;canvas.height=h*r;ctx.setTransform(r,0,0,r,0,0);ctx.clearRect(0,0,w,h);
        var p={l:36,r:12,t:14,b:24};ctx.strokeStyle='#dfe7f2';ctx.lineWidth=1;ctx.font='11px Arial';ctx.fillStyle='#8090a8';
        for(var i=0;i<=4;i++){var y=p.t+(h-p.t-p.b)*i/4;ctx.beginPath();ctx.moveTo(p.l,y);ctx.lineTo(w-p.r,y);ctx.stroke();ctx.fillText((100-i*25)+'%',5,y+4)}
        (series||[]).forEach(function(vals,idx){vals=vals&&vals.length?vals:[0];ctx.strokeStyle=colors[idx]||'#347cff';ctx.lineWidth=2;ctx.beginPath();vals.forEach(function(v,n){var x=p.l+(w-p.l-p.r)*(vals.length===1?0:n/(vals.length-1));var y=p.t+(h-p.t-p.b)*(1-Math.max(0,Math.min(100,Number(v)||0))/100);if(n===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});ctx.stroke()});
    }
    function text(id,v){var el=$(id);if(el)el.textContent=v}
    function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(s){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[s]})}
    function openDetail(data){
        text('detailName',data.name||'服务器详情');text('detailMeta',(data.source||'-')+' · '+(data.age||'-')+' · '+(data.version||'-'));
        text('detailCpu',Number(data.cpu||0).toFixed(1)+'%');text('detailMemory',Number(data.memory||0).toFixed(1)+'%');text('detailDisk',Number(data.disk||0).toFixed(1)+'%');text('detailLoad',data.load||'0.00');text('detailDownload',data.download||'0 Kbps');text('detailUpload',data.upload||'0 Kbps');
        ['Cpu','Memory','Disk'].forEach(function(k){var b=$('detail'+k+'Bar');var v=data[k.toLowerCase()]||0;if(b)b.style.setProperty('--w',Math.max(0,Math.min(100,v))+'%')});var lb=$('detailLoadBar');if(lb)lb.style.setProperty('--w',Math.max(0,Math.min(100,Number(data.load||0)*25))+'%');
        text('detailCpuSub',Number(data.cpu||0).toFixed(1)+'%');text('detailLoadSub',data.load||'0.00');text('detailMemorySub',data.memory_text||'0 B');text('detailDiskSub',data.disk_text||'0 B');text('detailPanel',data.panel||'unknown');text('detailNginx',data.nginx||'unknown');text('detailMysql',data.mysql||'unknown');text('detailPhp',data.php||'unknown');
        var state=$('detailState');if(state){var ok=data.state==='online';state.textContent=ok?'在线':'异常';state.className='state-pill '+(ok?'state-ok':'state-bad')}
        var disks=$('detailDisks');if(disks){disks.innerHTML='<b>硬盘信息</b>'+(data.disks||[]).map(function(d){var p=Math.max(0,Math.min(100,Number(d.percent)||0));return '<span><strong>'+esc(d.path)+'</strong><em>'+esc(d.used)+' / '+esc(d.total)+'</em><i><u style="width:'+p+'%"></u></i></span>'}).join('')}
        var h=data.history||{};draw($('statusCpuChart'),[h.cpu||[]],['#347cff']);draw($('statusLoadChart'),[h.load||[]],['#ff6262']);draw($('statusMemoryChart'),[h.memory||[]],['#17b9cf']);draw($('statusDiskChart'),[h.disk||[]],['#20c987']);
    }
    document.querySelectorAll('[data-detail]').forEach(function(row,index){row.addEventListener('click',function(){try{document.querySelectorAll('[data-detail]').forEach(function(item){item.classList.remove('active')});row.classList.add('active');openDetail(JSON.parse(row.getAttribute('data-detail')||'{}'))}catch(e){}});if(index===0){row.click()}});
    var theme=$('themeToggle');if(theme){theme.addEventListener('click',function(){document.body.classList.toggle('night');theme.textContent=document.body.classList.contains('night')?'白天模式':'夜间模式'})}
})();
</script>
</body>
</html>
