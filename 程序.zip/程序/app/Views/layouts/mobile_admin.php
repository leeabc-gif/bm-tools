<?php
$currentUser = \App\Core\Auth::user();
$siteName = setting('site_name', app_brand_name());
$mobilePath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/admin/m', PHP_URL_PATH);
$mobileNav = [
    ['path' => '/admin/m', 'url' => 'admin/m', 'icon' => 'layout-dashboard', 'label' => '首页'],
    ['path' => '/admin/m/users', 'url' => 'admin/m/users', 'icon' => 'users', 'label' => '用户'],
    ['path' => '/admin/m/orders', 'url' => 'admin/m/orders', 'icon' => 'receipt-text', 'label' => '订单'],
    ['path' => '/admin/m/servers', 'url' => 'admin/m/servers', 'icon' => 'activity', 'label' => '监控'],
    ['path' => '/admin/m/menu', 'url' => 'admin/m/menu', 'icon' => 'grid-3x3', 'label' => '功能', 'drawer' => true],
];
$mobileMenuGroups = [
    [
        'title' => '日常运营',
        'items' => [
            ['url' => 'admin/m/dashboard', 'icon' => 'layout-dashboard', 'label' => '运营首页'],
            ['url' => 'admin/m/users', 'icon' => 'users', 'label' => '用户管理'],
            ['url' => 'admin/m/packages', 'icon' => 'badge-dollar-sign', 'label' => '套餐权益'],
            ['url' => 'admin/m/coupons', 'icon' => 'percent', 'label' => '营销活动'],
            ['url' => 'admin/m/orders', 'icon' => 'receipt-text', 'label' => '订单充值'],
            ['url' => 'admin/m/payments', 'icon' => 'credit-card', 'label' => '支付配置'],
            ['url' => 'admin/m/cards', 'icon' => 'ticket', 'label' => '卡密管理'],
        ],
    ],
    [
        'title' => '资源能力',
        'items' => [
            ['url' => 'admin/m/files', 'icon' => 'files', 'label' => '文件管理'],
            ['url' => 'admin/m/storages', 'icon' => 'database', 'label' => '存储状态'],
            ['url' => 'admin/m/storage-backups', 'icon' => 'database-backup', 'label' => '存储备份'],
            ['url' => 'admin/m/storage-backups#backupMigration', 'icon' => 'replace-all', 'label' => '存储迁移'],
            ['url' => 'admin/m/repositories', 'icon' => 'library', 'label' => '分享仓库'],
            ['url' => 'admin/m/subsites', 'icon' => 'globe-2', 'label' => '分站管理'],
            ['url' => 'admin/m/servers', 'icon' => 'activity', 'label' => '服务器监控'],
        ],
    ],
    [
        'title' => '系统维护',
        'items' => [
            ['url' => 'admin/m/settings', 'icon' => 'settings', 'label' => '系统状态'],
            ['url' => 'admin/m/upload-limits', 'icon' => 'gauge', 'label' => '上传限制'],
            ['url' => 'admin/m/announcements', 'icon' => 'megaphone', 'label' => '公告管理'],
            ['url' => 'admin/m/incidents', 'icon' => 'shield-alert', 'label' => '异常事件'],
            ['url' => 'admin/m/logs', 'icon' => 'file-search', 'label' => '审计日志'],
            ['url' => 'admin/m/schema-audit', 'icon' => 'database-zap', 'label' => '数据库巡检'],
            ['url' => 'admin/m/settings', 'icon' => 'palette', 'label' => '主题设置'],
        ],
    ],
];
$isActiveMobile = function ($path) use ($mobilePath) {
    if ($path === '/admin/m') {
        return $mobilePath === '/admin/m' || $mobilePath === '/admin/m/dashboard';
    }
    return strpos($mobilePath, $path) === 0;
};
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="application-name" content="<?= e($siteName) ?>">
    <?= favicon_tags() ?>
    <title><?= e(isset($title) ? $title . ' - 移动后台' : '移动后台') ?></title>
    <link rel="stylesheet" href="<?= asset('css/mobile-shell.css') ?>">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="m-shell m-admin-shell">
<header class="m-topbar">
    <a class="m-brand" href="<?= url('admin/m') ?>">
        <span><?= e(text_initial($siteName, 'B')) ?></span>
        <b>移动后台</b>
    </a>
    <div class="m-topbar-actions">
        <a class="m-icon-btn" href="<?= url('m') ?>" aria-label="用户端"><i data-lucide="smartphone"></i></a>
        <a class="m-icon-btn" href="<?= url('admin/m/menu') ?>" aria-label="功能菜单" role="button" data-mobile-menu-open><i data-lucide="grid-3x3"></i></a>
    </div>
</header>

<main class="m-main">
    <?php if ($msg = flash('success')): ?><div class="m-alert success"><?= e($msg) ?></div><?php endif; ?>
    <?php if ($msg = flash('error')): ?><div class="m-alert error"><?= e($msg) ?></div><?php endif; ?>
    <?= $content ?>
</main>

<nav class="m-bottom-nav" aria-label="移动后台导航">
    <?php foreach ($mobileNav as $item): ?>
        <?php if (!empty($item['drawer'])): ?>
            <a href="<?= url($item['url']) ?>" class="<?= $isActiveMobile($item['path']) ? 'active' : '' ?>" role="button" data-mobile-menu-open>
                <i data-lucide="<?= e($item['icon']) ?>"></i>
                <span><?= e($item['label']) ?></span>
            </a>
        <?php else: ?>
            <a href="<?= url($item['url']) ?>" class="<?= $isActiveMobile($item['path']) ? 'active' : '' ?>">
                <i data-lucide="<?= e($item['icon']) ?>"></i>
                <span><?= e($item['label']) ?></span>
            </a>
        <?php endif; ?>
    <?php endforeach; ?>
</nav>

<section class="m-menu-sheet" data-mobile-menu-sheet aria-hidden="true" role="dialog" aria-modal="true" aria-label="功能菜单">
    <div class="m-menu-panel">
        <header>
            <div>
                <span>Admin</span>
                <strong>功能中心</strong>
            </div>
            <button class="m-icon-btn" type="button" aria-label="关闭菜单" data-mobile-menu-close><i data-lucide="x"></i></button>
        </header>
        <label class="m-menu-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索后台功能" autocomplete="off" data-mobile-menu-search>
        </label>
        <div class="m-menu-groups">
            <?php foreach ($mobileMenuGroups as $group): ?>
                <section>
                    <h2><?= e($group['title']) ?></h2>
                    <div>
                        <?php foreach ($group['items'] as $item): ?>
                            <a href="<?= url($item['url']) ?>" data-mobile-menu-item>
                                <i data-lucide="<?= e($item['icon']) ?>"></i>
                                <span><?= e($item['label']) ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
            <div class="m-menu-empty" hidden>没有找到匹配功能。</div>
        </div>
        <a class="m-logout" href="<?= url('logout') ?>"><i data-lucide="log-out"></i><span>退出登录</span></a>
    </div>
</section>

<script src="<?= asset('js/mobile-shell.js') ?>"></script>
</body>
</html>
