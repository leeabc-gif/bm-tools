<?php
$currentUser = \App\Core\Auth::user();
$siteName = setting('site_name', app_brand_name());
$mobilePath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/m', PHP_URL_PATH);
$mobileNav = [
    ['path' => '/m', 'url' => 'm', 'icon' => 'layout-dashboard', 'label' => '首页'],
    ['path' => '/m/files', 'url' => 'm/files', 'icon' => 'image', 'label' => '图床'],
    ['path' => '/m/netdisk', 'url' => 'm/netdisk', 'icon' => 'hard-drive', 'label' => '网盘'],
    ['path' => '/m/servers', 'url' => 'm/servers', 'icon' => 'server-cog', 'label' => '服务器'],
    ['path' => '/m/menu', 'url' => 'm/menu', 'icon' => 'grid-3x3', 'label' => '功能', 'drawer' => true],
];
$mobileMenuGroups = [
    [
        'title' => '文件资源',
        'items' => [
            ['url' => 'm/files', 'icon' => 'image', 'label' => '图片上传'],
            ['url' => 'm/netdisk', 'icon' => 'hard-drive', 'label' => '个人网盘'],
            ['url' => 'm/repository', 'icon' => 'library', 'label' => '分享仓库'],
            ['url' => 'm/subsites', 'icon' => 'globe-2', 'label' => '我的分站'],
            ['url' => 'm/teams', 'icon' => 'users-round', 'label' => '团队空间'],
        ],
    ],
    [
        'title' => '服务器运维',
        'items' => [
            ['url' => 'm/servers', 'icon' => 'server-cog', 'label' => '服务器管家'],
            ['url' => 'm/servers/create', 'icon' => 'plus-circle', 'label' => '添加服务器'],
            ['url' => 'm/servers/commands', 'icon' => 'terminal', 'label' => '命令记录'],
            ['url' => 'm/alerts', 'icon' => 'bell-ring', 'label' => '监控告警'],
        ],
    ],
    [
        'title' => '账户与计费',
        'items' => [
            ['url' => 'm/orders', 'icon' => 'receipt-text', 'label' => '订单余额'],
            ['url' => 'm/balance', 'icon' => 'coins', 'label' => '余额流水'],
            ['url' => 'm/recharge', 'icon' => 'wallet-cards', 'label' => '账户充值'],
            ['url' => 'm/cards', 'icon' => 'ticket-check', 'label' => '卡密兑换'],
            ['url' => 'm/packages', 'icon' => 'badge-dollar-sign', 'label' => '套餐升级'],
            ['url' => 'm/api', 'icon' => 'key-round', 'label' => 'API 管理'],
            ['url' => 'm/profile', 'icon' => 'user', 'label' => '账户资料'],
        ],
    ],
];
$isActiveMobile = function ($path) use ($mobilePath) {
    if ($path === '/m') {
        return $mobilePath === '/m' || $mobilePath === '/m/dashboard';
    }
    return strpos($mobilePath, $path) === 0;
};
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="application-name" content="<?= e($siteName) ?>">
    <?= favicon_tags() ?>
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : $siteName) ?></title>
    <link rel="stylesheet" href="<?= asset('css/mobile-shell.css') ?>">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="m-shell m-user-shell">
<header class="m-topbar">
    <a class="m-brand" href="<?= url('m') ?>">
        <span><?= e(text_initial($siteName, 'B')) ?></span>
        <b><?= e($siteName) ?></b>
    </a>
    <div class="m-topbar-actions">
        <?php if ($currentUser && $currentUser['role'] === 'admin'): ?><a class="m-icon-btn" href="<?= url('admin/m') ?>" aria-label="后台"><i data-lucide="shield-check"></i></a><?php endif; ?>
        <a class="m-icon-btn" href="<?= url('m/menu') ?>" aria-label="功能菜单" role="button" data-mobile-menu-open><i data-lucide="grid-3x3"></i></a>
    </div>
</header>

<main class="m-main">
    <?php if ($msg = flash('success')): ?><div class="m-alert success"><?= e($msg) ?></div><?php endif; ?>
    <?php if ($msg = flash('error')): ?><div class="m-alert error"><?= e($msg) ?></div><?php endif; ?>
    <?= $content ?>
</main>

<nav class="m-bottom-nav" aria-label="移动端导航">
    <?php foreach ($mobileNav as $item): ?>
        <?php if (!empty($item['drawer'])): ?>
            <a href="<?= url($item['url']) ?>" class="<?= $isActiveMobile($item['path']) ? 'active' : '' ?>" role="button" data-mobile-menu-open>
                <i data-lucide="<?= e($item['icon']) ?>"></i>
                <span><?= e($item['label']) ?></span>
            </a>
        <?php else: ?>
            <a href="<?= url($item['url']) ?>" class="<?= $isActiveMobile($item['path']) ? 'active' : '' ?>">
                <i data-lucide="<?= e($item['icon']) ?>"></i>
                <span><?= e($item['label']) ?></span>
            </a>
        <?php endif; ?>
    <?php endforeach; ?>
</nav>

<section class="m-menu-sheet" data-mobile-menu-sheet aria-hidden="true" role="dialog" aria-modal="true" aria-label="功能菜单">
    <div class="m-menu-panel">
        <header>
            <div>
                <span>Menu</span>
                <strong>功能中心</strong>
            </div>
            <button class="m-icon-btn" type="button" aria-label="关闭菜单" data-mobile-menu-close><i data-lucide="x"></i></button>
        </header>
        <label class="m-menu-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索功能" autocomplete="off" data-mobile-menu-search>
        </label>
        <div class="m-menu-groups">
            <?php foreach ($mobileMenuGroups as $group): ?>
                <section>
                    <h2><?= e($group['title']) ?></h2>
                    <div>
                        <?php foreach ($group['items'] as $item): ?>
                            <a href="<?= url($item['url']) ?>" data-mobile-menu-item>
                                <i data-lucide="<?= e($item['icon']) ?>"></i>
                                <span><?= e($item['label']) ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
            <div class="m-menu-empty" hidden>没有找到匹配功能。</div>
        </div>
        <a class="m-logout" href="<?= url('logout') ?>"><i data-lucide="log-out"></i><span>退出登录</span></a>
    </div>
</section>

<script>
window.SKY_UPLOAD_LIMITS = {
    concurrency: <?= (int) setting('upload_max_concurrency', 2) ?>,
    imageBatch: <?= (int) setting('upload_image_batch_limit', 20) ?>,
    fileBatch: <?= (int) setting('upload_file_batch_limit', 10) ?>,
    imageDaily: <?= (int) setting('upload_image_daily_limit', 0) ?>,
    fileDaily: <?= (int) setting('upload_file_daily_limit', 0) ?>,
    imageUsedToday: <?= isset($uploadLimits) && is_array($uploadLimits) && isset($uploadLimits['scope']) && $uploadLimits['scope'] === 'image' ? (int) $uploadLimits['used_today'] : 0 ?>,
    fileUsedToday: <?= isset($uploadLimits) && is_array($uploadLimits) && isset($uploadLimits['scope']) && $uploadLimits['scope'] === 'file' ? (int) $uploadLimits['used_today'] : 0 ?>,
    singleFileLimit: <?= isset($uploadLimits) && is_array($uploadLimits) ? (int) $uploadLimits['single_file_limit'] : 0 ?>,
    storageRemaining: <?= isset($uploadLimits) && is_array($uploadLimits) && $uploadLimits['storage_remaining'] !== null ? (int) $uploadLimits['storage_remaining'] : 0 ?>,
    storageLimited: <?= isset($uploadLimits) && is_array($uploadLimits) && $uploadLimits['storage_remaining'] !== null ? 'true' : 'false' ?>
};
</script>
<script src="<?= asset('js/mobile-shell.js') ?>"></script>
</body>
</html>
