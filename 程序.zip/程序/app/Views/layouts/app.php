<?php
$currentUser = \App\Core\Auth::user();
$productBrand = app_brand_name();
$siteName = setting('site_name', $productBrand);
$isAdmin = $currentUser && (($currentUser['role'] ?? '') === 'admin');
$frontThemeStyle = setting('frontend_theme_style', 'classic') === 'anime' ? 'anime' : 'classic';
$explicitCloudHome = !empty($isCloudHome);
$isCloudHome = $explicitCloudHome || (isset($content) && preg_match('/class=(["\'])[^"\']*(cloud-home|pro-home|space-home)[^"\']*\1/', $content));
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="application-name" content="<?= e($productBrand) ?>">
    <?= favicon_tags() ?>
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : $siteName) ?></title>
    <meta name="keywords" content="<?= e(setting('seo_keywords', 'image hosting,netdisk,share repository,API upload,content delivery')) ?>">
    <meta name="description" content="<?= e(setting('seo_description', 'A personal image hosting, netdisk, share repository and server operations platform.')) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/mobile.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/theme-anime.css') ?>">
    <?php if (!$isCloudHome): ?><link rel="stylesheet" href="<?= asset('css/workspace-pro.css') ?>"><?php endif; ?>
    <link rel="stylesheet" href="<?= asset('css/responsive-fix.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/macos-liquid.css') ?>">
    <?php if ($isCloudHome): ?><link rel="stylesheet" href="<?= asset('css/front-cloud.css') ?>"><?php endif; ?>
    <?php if (!$isCloudHome): ?><link rel="stylesheet" href="<?= asset('css/v2/workspace.css') ?>"><?php endif; ?>
    <link rel="stylesheet" href="<?= asset('css/product-clean.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="console-body<?= $isCloudHome ? ' cloud-home-body' : '' ?>" data-theme="<?= e(setting('default_theme', 'light')) ?>" data-theme-style="<?= e($frontThemeStyle) ?>">
<?php if ($isCloudHome): ?>
    <?= $content ?>
<?php else: ?>
    <div class="console-layout">
        <aside class="console-sidebar glass">
            <a class="console-brand" href="<?= url('/') ?>">
                <span class="brand-mark"><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
                <span><b><?= e($siteName) ?></b><small>&#20113;&#24037;&#20855;&#38754;&#26495;</small></span>
            </a>
            <button class="icon-btn console-menu-close" type="button" title="&#20851;&#38381;&#33756;&#21333;" aria-label="&#20851;&#38381;&#33756;&#21333;" data-icon="x"></button>
            <nav class="console-nav">
                <p>&#24179;&#21488;&#26381;&#21153;</p>
                <a href="<?= url('/') ?>" data-icon="home">&#39318;&#39029;</a>
                <a href="<?= url('announcements') ?>" data-icon="megaphone">&#20844;&#21578;&#36890;&#30693;</a>
                <a href="<?= url('status') ?>" data-icon="activity">&#26381;&#21153;&#29366;&#24577;</a>
                <?php if ($currentUser): ?>
                    <p>&#24037;&#20316;&#21488;</p>
                    <a href="<?= url('dashboard') ?>" data-icon="layout-dashboard">&#20010;&#20154;&#20013;&#24515;</a>
                    <a href="<?= url('m') ?>" data-icon="smartphone">&#25163;&#26426;&#24037;&#20316;&#21488;</a>
                    <a href="<?= url('notifications') ?>" data-icon="bell">&#28040;&#24687;&#20013;&#24515;</a>
                    <p>&#36164;&#28304;&#19982;&#20998;&#20139;</p>
                    <a href="<?= url('files') ?>" data-icon="image">&#22270;&#24202;&#26381;&#21153;</a>
                    <a href="<?= url('netdisk') ?>" data-icon="hard-drive">&#20010;&#20154;&#32593;&#30424;</a>
                    <a href="<?= url('files/logs') ?>" data-icon="clipboard-list">&#25991;&#20214;&#35760;&#24405;</a>
                    <a href="<?= url('repository') ?>" data-icon="library">&#20998;&#20139;&#20179;&#24211;</a>
                    <a href="<?= url('subsites') ?>" data-icon="globe-2">&#25105;&#30340;&#20998;&#31449;</a>
                    <a href="<?= url('teams') ?>" data-icon="users-round">&#22242;&#38431;&#31354;&#38388;</a>
                    <p>&#26381;&#21153;&#22120;&#36816;&#32500;</p>
                    <a href="<?= url('servers') ?>" data-icon="server-cog">&#26381;&#21153;&#22120;&#31649;&#23478;</a>
                    <a href="<?= url('alerts') ?>" data-icon="bell-ring">&#30417;&#25511;&#21578;&#35686;</a>
                    <p>&#36134;&#25143;&#19982;&#21830;&#19994;</p>
                    <a href="<?= url('packages') ?>" data-icon="badge-dollar-sign">&#22871;&#39184;&#21319;&#32423;</a>
                    <a href="<?= url('recharge') ?>" data-icon="wallet">&#36134;&#25143;&#20805;&#20540;</a>
                    <a href="<?= url('cards') ?>" data-icon="ticket">&#21345;&#23494;&#20817;&#25442;</a>
                    <a href="<?= url('orders') ?>" data-icon="receipt-text">&#35746;&#21333;&#35760;&#24405;</a>
                    <p>&#35774;&#32622;&#19982;&#25509;&#20837;</p>
                    <a href="<?= url('profile') ?>" data-icon="user-round-cog">&#36134;&#25143;&#36164;&#26009;</a>
                    <a href="<?= url('api/console') ?>" data-icon="terminal">API &#31649;&#29702;</a>
                    <?php if ($isAdmin): ?>
                        <a href="<?= url('admin') ?>" data-icon="shield-check">&#21518;&#21488;&#31649;&#29702;</a>
                    <?php endif; ?>
                <?php else: ?>
                    <p>&#36134;&#25143;</p>
                    <a href="<?= url('login') ?>" data-icon="log-in">&#30331;&#24405;</a>
                    <a href="<?= url('register') ?>" data-icon="user-plus">&#27880;&#20876;</a>
                <?php endif; ?>
            </nav>
        </aside>

        <section class="console-workspace">
            <header class="console-topbar glass">
                <div>
                    <button class="icon-btn mobile-menu-btn" type="button" title="&#33756;&#21333;" aria-label="&#25171;&#24320;&#33756;&#21333;" aria-expanded="false" data-icon="menu"></button>
                    <strong><?= e(isset($title) ? $title : $siteName) ?></strong>
                </div>
                <div class="console-actions">
                    <?php if ($currentUser): ?>
                        <?php if ($isAdmin): ?><a class="btn btn-ghost" href="<?= url('admin') ?>" data-icon="shield-check">&#21518;&#21488;</a><?php endif; ?>
                        <a class="btn btn-ghost" href="<?= url('profile') ?>" data-icon="user">&#36164;&#26009;</a>
                        <a class="btn btn-primary" href="<?= url('logout') ?>" data-icon="log-out">&#36864;&#20986;</a>
                    <?php else: ?>
                        <a class="btn btn-ghost" href="<?= url('login') ?>" data-icon="log-in">&#30331;&#24405;</a>
                        <a class="btn btn-primary" href="<?= url('register') ?>" data-icon="user-plus">&#27880;&#20876;</a>
                    <?php endif; ?>
                </div>
            </header>

            <main class="console-content">
                <?php if ($msg = flash('success')): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
                <?php if ($msg = flash('error')): ?><div class="alert error"><?= e($msg) ?></div><?php endif; ?>
                <?= $content ?>
            </main>
        </section>
    </div>

    <nav class="mobile-bottom-nav" aria-label="&#31227;&#21160;&#31471;&#24555;&#25463;&#23548;&#33322;">
        <a href="<?= url('/') ?>" data-icon="home"><span>&#39318;&#39029;</span></a>
        <?php if ($currentUser): ?>
            <a href="<?= url('m') ?>" data-icon="layout-dashboard"><span>&#25163;&#26426;&#31471;</span></a>
            <a href="<?= url('m/files') ?>" data-icon="image"><span>&#22270;&#24202;</span></a>
            <a href="<?= url('m/netdisk') ?>" data-icon="hard-drive"><span>&#32593;&#30424;</span></a>
            <a href="<?= url('m/servers') ?>" data-icon="server-cog"><span>&#26381;&#21153;&#22120;</span></a>
        <?php else: ?>
            <a href="<?= url('announcements') ?>" data-icon="megaphone"><span>&#20844;&#21578;</span></a>
            <a href="<?= url('status') ?>" data-icon="activity"><span>&#29366;&#24577;</span></a>
            <a href="<?= url('login') ?>" data-icon="log-in"><span>&#30331;&#24405;</span></a>
            <a href="<?= url('register') ?>" data-icon="user-plus"><span>&#27880;&#20876;</span></a>
        <?php endif; ?>
    </nav>

    <button class="back-top" type="button" data-icon="arrow-up"></button>
<?php endif; ?>
<script>
window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
window.SKY_DEFAULT_THEME = "<?= e(setting('default_theme', 'light')) ?>";
window.SKY_THEME_SCOPE = "front";
window.SKY_THEME_STYLE = "<?= e($frontThemeStyle) ?>";
window.SKY_UPLOAD_LIMITS = {
    concurrency: <?= (int) setting('upload_max_concurrency', 2) ?>,
    imageBatch: <?= (int) setting('upload_image_batch_limit', 20) ?>,
    fileBatch: <?= (int) setting('upload_file_batch_limit', 10) ?>,
    imageDaily: <?= (int) setting('upload_image_daily_limit', 0) ?>,
    fileDaily: <?= (int) setting('upload_file_daily_limit', 0) ?>
};
</script>
<?php if (!$isCloudHome): ?><script src="<?= asset('js/mobile-menu.js') ?>"></script><?php endif; ?>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
