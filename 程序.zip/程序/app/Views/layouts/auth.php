<?php $productBrand = app_brand_name(); $siteName = setting('site_name', $productBrand); ?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="application-name" content="<?= e($productBrand) ?>">
    <?= favicon_tags() ?>
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : $siteName) ?></title>
    <link rel="stylesheet" href="<?= asset('css/auth-space.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/responsive-fix.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/macos-liquid.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/product-clean.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="auth-brand-body">
    <?= $content ?>
    <script>
    window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
    </script>
    <script src="<?= asset('js/app.js') ?>"></script>
    <script>
    if (window.lucide) {
        window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
    }
    </script>
</body>
</html>
