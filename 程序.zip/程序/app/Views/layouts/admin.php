<?php
$currentUser = \App\Core\Auth::user();
$productBrand = app_brand_name();
$siteName = setting('site_name', $productBrand);
$adminThemeStyle = setting('admin_theme_style', 'classic') === 'anime' ? 'anime' : 'classic';
if ($currentUser && isset($currentUser['admin_theme_style']) && in_array($currentUser['admin_theme_style'], ['classic', 'anime'], true)) {
    $adminThemeStyle = $currentUser['admin_theme_style'];
}
$adminPath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/admin', PHP_URL_PATH);
$adminText = [
    'backend' => '后台',
    'operationBackend' => '运营后台',
    'operations' => '运营管理',
    'commerce' => '商业交易',
    'resources' => '资源功能管理',
    'audit' => '系统设置',
    'dashboard' => '控制台',
    'screen' => '数据大屏',
    'users' => '用户管理',
    'packages' => '套餐管理',
    'coupons' => '营销活动',
    'cards' => '卡密管理',
    'orders' => '订单管理',
    'recharges' => '充值审核',
    'payments' => '支付配置',
    'balanceLogs' => '余额流水',
    'storages' => '资源功能管理',
    'storageIntegrations' => '同系统对接',
    'storageBackups' => '备份策略',
    'storageBackupTasks' => '备份任务',
    'storageBackupBackfill' => '历史补备',
    'storageMigration' => '存储迁移',
    'files' => '文件管理',
    'repositories' => '分享仓库',
    'subsites' => '分站管理',
    'monitors' => '监控管理',
    'userServers' => '用户服务器',
    'sshSessions' => 'SSH 会话',
    'commandLogs' => '命令审计',
    'serverOpsSettings' => '运维设置',
    'announcements' => '公告管理',
    'apiLogs' => 'API 日志',
    'incidentCenter' => '异常事件中心',
    'featureAudit' => '功能巡检',
    'settings' => '系统设置',
    'themes' => '主题设置',
    'uploadLimits' => '上传限制',
    'adminLogs' => '管理员日志',
    'menu' => '菜单',
    'current' => '当前位置',
    'theme' => '切换主题',
    'frontend' => '前台',
    'logout' => '退出',
    'copyright' => app_copyright_text() . ' · All rights reserved',
    'search' => '搜索',
    'favorite' => '收藏',
    'record' => '记录',
    'log' => '日志',
];

function admin_badge_table_exists($table)
{
    static $cache = [];
    $table = trim((string) $table, '` ');
    if ($table === '') {
        return true;
    }
    if (isset($cache[$table])) {
        return $cache[$table];
    }
    try {
        $cache[$table] = \App\Core\Database::tableExists($table);
    } catch (\Throwable $e) {
        $cache[$table] = false;
    }
    return $cache[$table];
}

function admin_count_badge($sql)
{
    try {
        if (preg_match_all('/\b(?:FROM|JOIN)\s+`?([A-Za-z0-9_]+)`?/i', (string) $sql, $matches)) {
            foreach ($matches[1] as $table) {
                if (!admin_badge_table_exists($table)) {
                    return 0;
                }
            }
        }
        foreach ([
            'redeem_cards',
            'file_storage_backups',
            'server_command_logs',
            'api_logs',
            'file_repositories',
            'subsites',
            'monitor_alerts',
            'monitor_servers',
            'upload_failures',
        ] as $featureTable) {
            $table = \App\Core\Database::table($featureTable);
            if (strpos((string) $sql, $table) !== false && !admin_badge_table_exists($table)) {
                return 0;
            }
        }
        $row = \App\Core\Database::fetch($sql);
        return $row ? (int) $row['c'] : 0;
    } catch (\Throwable $e) {
        return 0;
    }
}

$adminBadges = [
    '/admin/orders' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('orders') . " WHERE status = 'pending'"),
    '/admin/recharges' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('recharges') . " WHERE status = 'pending'"),
    '/admin/monitors' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('monitor_servers') . " WHERE monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'"),
    '/admin/monitor-sla' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('monitor_alerts') . " a INNER JOIN " . \App\Core\Database::table('monitor_servers') . " s ON a.server_id = s.id WHERE s.monitor_type = 'bt' AND a.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"),
    '/admin/user-servers' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('monitor_servers') . " WHERE monitor_type IN ('ssh','agent')"),
    '/admin/command-logs' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('server_command_logs') . " WHERE risk_level IN ('warning','danger') AND DATE(created_at) = CURDATE()"),
    '/admin/api-logs' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('api_logs') . " WHERE DATE(created_at) = CURDATE()"),
    '/admin/incident-center' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('api_logs') . " WHERE is_success = 0 AND DATE(created_at) = CURDATE()")
        + admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('file_storage_backups') . " WHERE status = 'failed'")
        + admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('server_command_logs') . " WHERE risk_level IN ('warning','danger') AND DATE(created_at) = CURDATE()")
        + admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('upload_failures') . " WHERE DATE(created_at) = CURDATE()"),
    '/admin/repositories' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('file_repositories') . " WHERE admin_status = 0"),
    '/admin/subsites' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('subsites') . " WHERE status = 'pending'"),
    '/admin/package-expiry' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('users') . " WHERE status = 1 AND package_expire_time IS NOT NULL AND package_expire_time >= NOW() AND package_expire_time < DATE_ADD(NOW(), INTERVAL 7 DAY)"),
    '/admin/cards' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('redeem_cards') . " WHERE status = 'unused'"),
    '/admin/storage-backups/tasks' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('file_storage_backups') . " WHERE status = 'failed'"),
];
$adminUnreadAlerts = admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('monitor_alerts') . " a INNER JOIN " . \App\Core\Database::table('monitor_servers') . " s ON a.server_id = s.id WHERE a.status = 'unread' AND s.monitor_type = 'bt'");
$adminBadges['/admin/monitors'] += $adminUnreadAlerts;

$adminMenus = [
    [
        'title' => $adminText['operations'],
        'icon' => 'layout-dashboard',
        'items' => [
            ['path' => '/admin', 'url' => 'admin', 'icon' => 'layout-dashboard', 'label' => $adminText['dashboard']],
            ['path' => '/admin/m', 'url' => 'admin/m', 'icon' => 'smartphone', 'label' => '移动后台'],
            ['path' => '/admin/screen', 'url' => 'admin/screen', 'icon' => 'monitor-smartphone', 'label' => $adminText['screen']],
            ['path' => '/admin/users', 'url' => 'admin/users', 'icon' => 'users', 'label' => $adminText['users']],
            ['path' => '/admin/package-expiry', 'url' => 'admin/package-expiry', 'icon' => 'calendar-clock', 'label' => '套餐到期提醒'],
            ['path' => '/admin/packages', 'url' => 'admin/packages', 'icon' => 'package', 'label' => $adminText['packages']],
            ['path' => '/admin/coupons', 'url' => 'admin/coupons', 'icon' => 'badge-percent', 'label' => $adminText['coupons']],
            ['path' => '/admin/cards', 'url' => 'admin/cards', 'icon' => 'ticket', 'label' => $adminText['cards']],
        ],
    ],
    [
        'title' => $adminText['commerce'],
        'icon' => 'wallet-cards',
        'items' => [
            ['path' => '/admin/orders', 'url' => 'admin/orders', 'icon' => 'receipt-text', 'label' => $adminText['orders']],
            ['path' => '/admin/recharges', 'url' => 'admin/recharges', 'icon' => 'wallet-cards', 'label' => $adminText['recharges']],
            ['path' => '/admin/payments', 'url' => 'admin/payments', 'icon' => 'credit-card', 'label' => $adminText['payments']],
            ['path' => '/admin/balance-logs', 'url' => 'admin/balance-logs', 'icon' => 'coins', 'label' => $adminText['balanceLogs']],
        ],
    ],
    [
        'title' => $adminText['resources'],
        'icon' => 'folder-cog',
        'items' => [
            ['path' => '/admin/storages', 'url' => 'admin/storages', 'icon' => 'database', 'label' => $adminText['storages']],
            ['path' => '/admin/storage-integrations', 'url' => 'admin/storage-integrations', 'icon' => 'network', 'label' => $adminText['storageIntegrations']],
            ['path' => '/admin/storage-backups/tasks', 'url' => 'admin/storage-backups/tasks', 'icon' => 'list-checks', 'label' => $adminText['storageBackupTasks']],
            ['path' => '/admin/storage-backups/backfill', 'url' => 'admin/storage-backups/backfill', 'icon' => 'archive-restore', 'label' => $adminText['storageBackupBackfill']],
            ['path' => '/admin/storage-migration', 'url' => 'admin/storage-migration', 'icon' => 'replace-all', 'label' => $adminText['storageMigration']],
            ['path' => '/admin/storage-backups', 'url' => 'admin/storage-backups', 'icon' => 'database-backup', 'label' => $adminText['storageBackups']],
            ['path' => '/admin/files', 'url' => 'admin/files', 'icon' => 'files', 'label' => $adminText['files']],
            ['path' => '/admin/repositories', 'url' => 'admin/repositories', 'icon' => 'library', 'label' => $adminText['repositories']],
            ['path' => '/admin/subsites', 'url' => 'admin/subsites', 'icon' => 'globe-2', 'label' => $adminText['subsites']],
            ['path' => '/admin/monitors', 'url' => 'admin/monitors', 'icon' => 'activity', 'label' => $adminText['monitors']],
            ['path' => '/admin/monitor-sla', 'url' => 'admin/monitor-sla', 'icon' => 'chart-no-axes-combined', 'label' => 'SLA &#32479;&#35745;'],
            ['path' => '/admin/user-servers', 'url' => 'admin/user-servers', 'icon' => 'server-cog', 'label' => $adminText['userServers']],
            ['path' => '/admin/ssh-sessions', 'url' => 'admin/ssh-sessions', 'icon' => 'screen-share', 'label' => $adminText['sshSessions']],
            ['path' => '/admin/command-logs', 'url' => 'admin/command-logs', 'icon' => 'square-terminal', 'label' => $adminText['commandLogs']],
            ['path' => '/admin/announcements', 'url' => 'admin/announcements', 'icon' => 'megaphone', 'label' => $adminText['announcements']],
        ],
    ],
    [
        'title' => $adminText['audit'],
        'icon' => 'settings',
        'items' => [
            ['path' => '/admin/settings/site', 'url' => 'admin/settings/site', 'icon' => 'globe', 'label' => '&#31449;&#28857;&#20449;&#24687;'],
            ['path' => '/admin/settings/security', 'url' => 'admin/settings/security', 'icon' => 'shield-check', 'label' => '&#23433;&#20840;&#19982;&#27880;&#20876;'],
            ['path' => '/admin/settings/upload', 'url' => 'admin/settings/upload', 'icon' => 'upload-cloud', 'label' => '&#19978;&#20256;&#26435;&#38480;'],
            ['path' => '/admin/upload-limits', 'url' => 'admin/upload-limits', 'icon' => 'gauge', 'label' => $adminText['uploadLimits']],
            ['path' => '/admin/settings/api', 'url' => 'admin/settings/api', 'icon' => 'terminal', 'label' => 'API &#38480;&#21046;'],
            ['path' => '/admin/settings/email', 'url' => 'admin/settings/email', 'icon' => 'mail', 'label' => '&#37038;&#20214;&#26381;&#21153;'],
            ['path' => '/admin/server-ops/settings', 'url' => 'admin/server-ops/settings', 'icon' => 'sliders-horizontal', 'label' => $adminText['serverOpsSettings']],
            ['path' => '/admin/themes', 'url' => 'admin/themes', 'icon' => 'palette', 'label' => $adminText['themes']],
            ['path' => '/admin/settings', 'url' => 'admin/settings', 'icon' => 'settings', 'label' => $adminText['settings']],
            ['path' => '/admin/api-logs', 'url' => 'admin/api-logs', 'icon' => 'terminal', 'label' => $adminText['apiLogs']],
            ['path' => '/admin/incident-center', 'url' => 'admin/incident-center', 'icon' => 'shield-alert', 'label' => $adminText['incidentCenter']],
            ['path' => '/admin/maintenance/schema-audit', 'url' => 'admin/maintenance/schema-audit', 'icon' => 'database-zap', 'label' => '&#25968;&#25454;&#24211;&#24033;&#26816;'],
            ['path' => '/admin/feature-audit', 'url' => 'admin/feature-audit', 'icon' => 'radar', 'label' => $adminText['featureAudit']],
            ['path' => '/admin/maintenance', 'url' => 'admin/maintenance', 'icon' => 'wrench', 'label' => '&#31995;&#32479;&#32500;&#25252;'],
            ['path' => '/admin/logs', 'url' => 'admin/logs', 'icon' => 'clipboard-list', 'label' => $adminText['adminLogs']],
        ],
    ],
];
$isActiveAdminPath = function ($path) use ($adminPath) {
    if ($path === '/admin') {
        return $adminPath === '/admin';
    }
    return strpos($adminPath, $path) === 0;
};
$activeGroup = $adminText['backend'];
$activeLabel = isset($title) ? e($title) : $adminText['dashboard'];
foreach ($adminMenus as $group) {
    foreach ($group['items'] as $item) {
        if ($isActiveAdminPath($item['path'])) {
            $activeGroup = $group['title'];
            $activeLabel = $item['label'];
            break 2;
        }
    }
}
$adminTodoItems = [
    ['label' => '&#24453;&#22788;&#29702;&#35746;&#21333;', 'value' => $adminBadges['/admin/orders'], 'url' => 'admin/orders', 'icon' => 'receipt-text'],
    ['label' => '&#24453;&#23457;&#26680;&#20805;&#20540;', 'value' => $adminBadges['/admin/recharges'], 'url' => 'admin/recharges', 'icon' => 'wallet-cards'],
    ['label' => '&#30417;&#25511;&#25552;&#37266;', 'value' => $adminBadges['/admin/monitors'], 'url' => 'admin/monitors', 'icon' => 'activity'],
];
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="application-name" content="<?= e($siteName) ?>">
    <?= favicon_tags() ?>
    <title><?= isset($title) ? e($title) . ' - ' : '' ?><?= $adminText['backend'] ?></title>
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/theme-anime.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/responsive-fix.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/macos-liquid.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/v2/workspace.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/product-clean.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/admin-mobile-menu.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body data-theme="<?= e(setting('default_theme', 'auto')) ?>" data-theme-style="<?= e($adminThemeStyle) ?>" class="console-body admin-body">
<div class="console-layout admin-layout">
    <aside class="console-sidebar admin-sidebar glass">
        <a class="console-brand" href="<?= url('admin') ?>">
            <span class="brand-mark"><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
            <span><b><?= e($siteName) ?></b><small><?= $adminText['operationBackend'] ?></small></span>
        </a>
        <button class="icon-btn console-menu-close admin-menu-close" type="button" title="&#20851;&#38381;&#33756;&#21333;" aria-label="&#20851;&#38381;&#33756;&#21333;" data-icon="x"></button>
        <nav class="console-nav admin-nav admin-tree-nav">
            <?php foreach ($adminMenus as $groupIndex => $group): ?>
                <?php if (!empty($group['hidden'])) continue; ?>
                <?php
                $groupOpen = false;
                foreach ($group['items'] as $item) {
                    if ($isActiveAdminPath($item['path'])) {
                        $groupOpen = true;
                        break;
                    }
                }
                ?>
                <section class="admin-menu-group <?= $groupOpen ? 'open' : '' ?>" data-menu-key="admin_menu_<?= e($groupIndex) ?>">
                    <button class="admin-menu-toggle" type="button" data-icon="<?= e($group['icon']) ?>">
                        <span><?= $group['title'] ?></span>
                        <i data-lucide="chevron-down"></i>
                    </button>
                    <div class="admin-submenu">
                        <?php foreach ($group['items'] as $item): ?>
                            <?php $badge = isset($adminBadges[$item['path']]) ? (int) $adminBadges[$item['path']] : 0; ?>
                            <a href="<?= url($item['url']) ?>" data-icon="<?= e($item['icon']) ?>" class="<?= $isActiveAdminPath($item['path']) ? 'active' : '' ?>">
                                <span><?= $item['label'] ?></span>
                                <?php if ($badge > 0): ?><em class="admin-menu-badge"><?= e($badge > 99 ? '99+' : $badge) ?></em><?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        </nav>
    </aside>
    <section class="console-workspace admin-main">
        <header class="console-topbar admin-top glass">
            <div class="admin-top-title">
                <button class="icon-btn admin-mobile-menu-btn" type="button" title="<?= $adminText['menu'] ?>" aria-label="<?= $adminText['menu'] ?>" aria-expanded="false" data-icon="menu"></button>
                <div>
                    <nav class="admin-breadcrumb" aria-label="<?= $adminText['current'] ?>">
                        <span><?= $adminText['backend'] ?></span>
                        <i>/</i>
                        <span><?= $activeGroup ?></span>
                    </nav>
                    <strong><?= $activeLabel ?></strong>
                </div>
            </div>
            <div class="console-actions">
                <button class="theme-toggle icon-btn" type="button" title="<?= $adminText['theme'] ?>" aria-label="<?= $adminText['theme'] ?>" data-icon="sun-moon"></button>
                <a class="btn btn-ghost" href="<?= url('admin/m') ?>" data-icon="smartphone">移动后台</a>
                <a class="btn btn-ghost" href="<?= url('/') ?>" data-icon="home"><?= $adminText['frontend'] ?></a>
                <a class="btn btn-primary" href="<?= url('logout') ?>" data-icon="log-out"><?= $adminText['logout'] ?></a>
            </div>
        </header>
        <section class="admin-mobile-control-panel glass" aria-label="&#31227;&#21160;&#31471;&#21518;&#21488;&#25511;&#21046;&#21306;">
            <div class="admin-mobile-control-head">
                <div>
                    <span>&#24403;&#21069;&#39029;&#38754;</span>
                    <strong><?= $activeLabel ?></strong>
                    <small><?= $activeGroup ?></small>
                </div>
                <button class="btn btn-primary admin-mobile-menu-btn" type="button" aria-label="<?= $adminText['menu'] ?>" aria-expanded="false" data-icon="menu"><?= $adminText['menu'] ?></button>
            </div>
            <div class="admin-mobile-quick-actions">
                <a href="<?= url('admin') ?>" data-icon="layout-dashboard"><?= $adminText['dashboard'] ?></a>
                <a href="<?= url('/') ?>" data-icon="home"><?= $adminText['frontend'] ?></a>
                <button class="theme-toggle" type="button" data-icon="sun-moon"><?= $adminText['theme'] ?></button>
                <a href="<?= url('logout') ?>" data-icon="log-out"><?= $adminText['logout'] ?></a>
            </div>
            <div class="admin-mobile-todo-grid">
                <?php foreach ($adminTodoItems as $todo): ?>
                    <a href="<?= url($todo['url']) ?>" data-icon="<?= e($todo['icon']) ?>">
                        <span><?= $todo['label'] ?></span>
                        <b><?= e($todo['value']) ?></b>
                    </a>
                <?php endforeach; ?>
            </div>
            <nav class="admin-mobile-section-tabs" aria-label="&#21518;&#21488;&#27169;&#22359;">
                <?php foreach ($adminMenus as $group): ?>
                    <?php if (!empty($group['hidden'])) continue; ?>
                    <?php
                    $groupOpen = false;
                    foreach ($group['items'] as $item) {
                        if ($isActiveAdminPath($item['path'])) {
                            $groupOpen = true;
                            break;
                        }
                    }
                    $firstItem = isset($group['items'][0]) ? $group['items'][0] : null;
                    ?>
                    <?php if ($firstItem): ?>
                        <a href="<?= url($firstItem['url']) ?>" class="<?= $groupOpen ? 'active' : '' ?>" data-icon="<?= e($group['icon']) ?>"><?= $group['title'] ?></a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>
            <nav class="admin-mobile-current-links" aria-label="&#24403;&#21069;&#27169;&#22359;&#39029;&#38754;">
                <?php foreach ($adminMenus as $group): ?>
                    <?php
                    $groupOpen = false;
                    foreach ($group['items'] as $item) {
                        if ($isActiveAdminPath($item['path'])) {
                            $groupOpen = true;
                            break;
                        }
                    }
                    if (!$groupOpen) continue;
                    ?>
                    <?php foreach ($group['items'] as $item): ?>
                        <?php $badge = isset($adminBadges[$item['path']]) ? (int) $adminBadges[$item['path']] : 0; ?>
                        <a href="<?= url($item['url']) ?>" data-icon="<?= e($item['icon']) ?>" class="<?= $isActiveAdminPath($item['path']) ? 'active' : '' ?>">
                            <span><?= $item['label'] ?></span>
                            <?php if ($badge > 0): ?><em><?= e($badge > 99 ? '99+' : $badge) ?></em><?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                    <?php break; ?>
                <?php endforeach; ?>
            </nav>
        </section>
        <section class="admin-mobile-menu-sheet" aria-hidden="true" role="dialog" aria-modal="true" aria-label="<?= $adminText['menu'] ?>">
            <div class="admin-mobile-menu-panel">
                <header class="admin-mobile-menu-header">
                    <div>
                        <span><?= $adminText['operationBackend'] ?></span>
                        <strong><?= $adminText['menu'] ?></strong>
                        <small><?= $activeGroup ?> / <?= $activeLabel ?></small>
                    </div>
                    <button class="icon-btn admin-mobile-menu-close" type="button" aria-label="&#20851;&#38381;&#33756;&#21333;" data-icon="x"></button>
                </header>
                <div class="admin-mobile-menu-search">
                    <i data-lucide="search"></i>
                    <input type="search" placeholder="<?= $adminText['search'] ?><?= $adminText['menu'] ?>" data-admin-mobile-menu-search>
                </div>
                <div class="admin-mobile-menu-actions">
                    <a href="<?= url('admin') ?>"><i data-lucide="layout-dashboard"></i><span><?= $adminText['dashboard'] ?></span></a>
                    <a href="<?= url('/') ?>"><i data-lucide="home"></i><span><?= $adminText['frontend'] ?></span></a>
                    <button class="theme-toggle" type="button"><i data-lucide="sun-moon"></i><span><?= $adminText['theme'] ?></span></button>
                    <a href="<?= url('logout') ?>"><i data-lucide="log-out"></i><span><?= $adminText['logout'] ?></span></a>
                </div>
                <nav class="admin-mobile-menu-jump" aria-label="&#21151;&#33021;&#20998;&#21306;">
                    <?php foreach ($adminMenus as $mobileGroupIndex => $group): ?>
                        <?php if (!empty($group['hidden'])) continue; ?>
                        <?php
                        $groupOpen = false;
                        foreach ($group['items'] as $item) {
                            if ($isActiveAdminPath($item['path'])) {
                                $groupOpen = true;
                                break;
                            }
                        }
                        ?>
                        <button type="button" class="<?= $groupOpen ? 'active' : '' ?>" data-admin-mobile-menu-jump="admin-mobile-menu-group-<?= e($mobileGroupIndex) ?>">
                            <i data-lucide="<?= e($group['icon']) ?>"></i>
                            <span><?= $group['title'] ?></span>
                        </button>
                    <?php endforeach; ?>
                </nav>
                <div class="admin-mobile-menu-groups">
                    <?php foreach ($adminMenus as $mobileGroupIndex => $group): ?>
                        <?php if (!empty($group['hidden'])) continue; ?>
                        <?php
                        $groupOpen = false;
                        foreach ($group['items'] as $item) {
                            if ($isActiveAdminPath($item['path'])) {
                                $groupOpen = true;
                                break;
                            }
                        }
                        ?>
                        <article class="admin-mobile-menu-group <?= $groupOpen ? 'active' : '' ?>" id="admin-mobile-menu-group-<?= e($mobileGroupIndex) ?>">
                            <h2><i data-lucide="<?= e($group['icon']) ?>"></i><span><?= $group['title'] ?></span></h2>
                            <div class="admin-mobile-menu-grid">
                                <?php foreach ($group['items'] as $item): ?>
                                    <?php $badge = isset($adminBadges[$item['path']]) ? (int) $adminBadges[$item['path']] : 0; ?>
                                    <a href="<?= url($item['url']) ?>" class="<?= $isActiveAdminPath($item['path']) ? 'active' : '' ?>" data-admin-mobile-menu-item>
                                        <i data-lucide="<?= e($item['icon']) ?>"></i>
                                        <span><?= $item['label'] ?></span>
                                        <?php if ($badge > 0): ?><em><?= e($badge > 99 ? '99+' : $badge) ?></em><?php endif; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p class="admin-mobile-menu-empty" hidden><?= $adminText['search'] ?><?= $adminText['menu'] ?><?= $adminText['record'] ?>为空</p>
            </div>
        </section>
        <nav class="admin-mobile-bottom-bar" aria-label="&#21518;&#21488;&#24555;&#25463;&#25805;&#20316;">
            <a href="<?= url('admin') ?>" class="<?= $isActiveAdminPath('/admin') ? 'active' : '' ?>">
                <i data-lucide="layout-dashboard"></i>
                <span>&#25511;&#21046;&#21488;</span>
            </a>
            <button class="admin-mobile-menu-btn" type="button" aria-label="<?= $adminText['menu'] ?>" aria-expanded="false">
                <i data-lucide="grid-3x3"></i>
                <span>&#21151;&#33021;</span>
            </button>
            <a href="<?= url('admin/files') ?>" class="<?= $isActiveAdminPath('/admin/files') ? 'active' : '' ?>">
                <i data-lucide="files"></i>
                <span>&#25991;&#20214;</span>
            </a>
            <a href="<?= url('admin/settings') ?>" class="<?= $isActiveAdminPath('/admin/settings') ? 'active' : '' ?>">
                <i data-lucide="settings"></i>
                <span>&#35774;&#32622;</span>
            </a>
        </nav>
        <main class="console-content">
            <?php if ($msg = flash('success')): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="alert error"><?= e($msg) ?></div><?php endif; ?>
            <?= $content ?>
            <footer class="admin-global-footer glass">
                <b><?= e($productBrand) ?></b>
                <span><?= $adminText['copyright'] ?></span>
            </footer>
        </main>
    </section>
    <aside class="admin-right-rail">
        <button type="button" title="<?= $adminText['search'] ?>" data-icon="search" data-admin-tool="search"></button>
        <button type="button" title="<?= $adminText['favorite'] ?>" data-icon="star" data-admin-tool="favorite"></button>
        <a href="<?= url('admin/logs') ?>" title="<?= $adminText['record'] ?>" data-icon="clock-3"></a>
        <a href="<?= url('admin/settings') ?>" title="<?= $adminText['settings'] ?>" data-icon="settings"></a>
        <a href="<?= url('admin/logs') ?>" title="<?= $adminText['log'] ?>" data-icon="clipboard-list"></a>
    </aside>
</div>
<script>
window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
window.SKY_DEFAULT_THEME = "<?= e(setting('default_theme', 'auto')) ?>";
window.SKY_THEME_SCOPE = "admin";
window.SKY_THEME_STYLE = "<?= e($adminThemeStyle) ?>";
</script>
<script src="<?= asset('js/mobile-menu.js') ?>"></script>
<script src="<?= asset('js/app.js') ?>"></script>
<script src="<?= asset('js/admin-mobile-menu.js') ?>"></script>
</body>
</html>
