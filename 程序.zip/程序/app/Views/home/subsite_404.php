<section class="subsite-public subsite-not-found">
    <main class="subsite-public-shell">
        <div class="subsite-empty-page">
            <span>404</span>
            <h1>分站不存在或尚未启用</h1>
            <p>该分站可能正在审核、已停用，或访问地址不正确。</p>
            <a href="<?= url('/') ?>">返回主站</a>
        </div>
    </main>
</section>
