<?php
if (!function_exists('ops_status_percent')) {
function ops_status_percent($value)
{
    $value = is_numeric($value) ? (float) $value : 0;
    return max(0, min(100, $value));
}

function ops_status_parse_size($value)
{
    if (is_numeric($value)) {
        return (float) $value;
    }
    if (!preg_match('/([\d\.]+)\s*([KMGTP]?B?)/i', trim((string) $value), $m)) {
        return 0;
    }
    $num = (float) $m[1];
    $unit = strtoupper(rtrim($m[2], 'B'));
    $map = ['K' => 1024, 'M' => 1048576, 'G' => 1073741824, 'T' => 1099511627776, 'P' => 1125899906842624];
    return $num * (isset($map[$unit]) ? $map[$unit] : 1);
}

function ops_status_speed($value)
{
    $value = (float) $value;
    return $value > 0 ? format_bytes($value) . '/s' : '0 Kbps';
}

function ops_status_source(array $server)
{
    $type = isset($server['monitor_type']) ? $server['monitor_type'] : 'bt';
    if ($type === 'ssh') {
        return 'SSH';
    }
    if ($type === 'agent') {
        return '探针';
    }
    return '宝塔';
}

function ops_status_age($time)
{
    if (!$time) {
        return '从未采集';
    }
    $seconds = time() - strtotime($time);
    if ($seconds < 60) {
        return '刚刚更新';
    }
    if ($seconds < 3600) {
        return floor($seconds / 60) . ' 分钟前';
    }
    if ($seconds < 86400) {
        return floor($seconds / 3600) . ' 小时前';
    }
    return floor($seconds / 86400) . ' 天前';
}

function ops_status_stale(array $server)
{
    $time = !empty($server['metric_time']) ? $server['metric_time'] : (isset($server['last_checked_at']) ? $server['last_checked_at'] : '');
    if (!$time) {
        return true;
    }
    $frequency = isset($server['frequency']) && (int) $server['frequency'] > 0 ? (int) $server['frequency'] : 300;
    return (time() - strtotime($time)) > max(600, $frequency * 3);
}

function ops_status_disks(array $server)
{
    $raw = json_decode((string) (isset($server['raw_data']) ? $server['raw_data'] : ''), true);
    $rawDisks = [];
    if (is_array($raw) && isset($raw['disk']) && is_array($raw['disk'])) {
        $rawDisks = $raw['disk'];
    } elseif (is_array($raw) && isset($raw['agent']['disk']) && is_array($raw['agent']['disk'])) {
        $rawDisks = $raw['agent']['disk'];
    } elseif (is_array($raw) && isset($raw['ssh']['disk']) && is_array($raw['ssh']['disk'])) {
        $rawDisks = $raw['ssh']['disk'];
    }

    $rows = [];
    $skip = ['/run', '/dev', '/sys', '/proc', '/var/lib/docker/overlay', '/var/lib/docker/containers'];
    foreach ($rawDisks as $disk) {
        if (!is_array($disk)) {
            continue;
        }
        $path = isset($disk['path']) ? $disk['path'] : (isset($disk['mountpoint']) ? $disk['mountpoint'] : '/');
        $fs = isset($disk['filesystem']) ? $disk['filesystem'] : '';
        $ignore = false;
        foreach ($skip as $prefix) {
            if ($path === $prefix || strpos($path, $prefix . '/') === 0 || stripos($fs, 'overlay') !== false || stripos($fs, 'tmpfs') !== false) {
                $ignore = true;
                break;
            }
        }
        if ($ignore) {
            continue;
        }
        $total = ops_status_parse_size(isset($disk['total']) ? $disk['total'] : (isset($disk['size']) ? $disk['size'] : 0));
        $used = ops_status_parse_size(isset($disk['used']) ? $disk['used'] : 0);
        if ($total <= 0) {
            continue;
        }
        $rows[] = ['path' => $path ?: '/', 'total' => $total, 'used' => $used];
    }

    if (!$rows) {
        $rows[] = [
            'path' => '/',
            'total' => (float) (isset($server['disk_total']) ? $server['disk_total'] : 0),
            'used' => (float) (isset($server['disk_used']) ? $server['disk_used'] : 0),
        ];
    }
    return array_slice($rows, 0, 4);
}

function ops_status_load(array $server)
{
    $load = trim((string) (isset($server['load_avg']) ? $server['load_avg'] : ''));
    if ($load === '') {
        return '0.00';
    }
    $parts = preg_split('/[\s,\/]+/', $load);
    return isset($parts[0]) && $parts[0] !== '' ? $parts[0] : '0.00';
}

function ops_status_version(array $server)
{
    $raw = json_decode((string) (isset($server['raw_data']) ? $server['raw_data'] : ''), true);
    if (is_array($raw) && isset($raw['system']) && is_array($raw['system'])) {
        foreach (['version', 'panel_version', 'bt_version'] as $key) {
            if (!empty($raw['system'][$key])) {
                return $raw['system'][$key];
            }
        }
    }
    return '-';
}

function ops_status_series(array $rows, $key)
{
    $out = [];
    foreach ($rows as $row) {
        $out[] = isset($row[$key]) ? (float) $row[$key] : 0;
    }
    return $out;
}

function ops_status_load_series(array $rows)
{
    $out = [];
    foreach ($rows as $row) {
        $parts = !empty($row['load_avg']) ? preg_split('/[\s,\/]+/', trim((string) $row['load_avg'])) : [];
        $out[] = min(100, (isset($parts[0]) ? (float) $parts[0] : 0) * 25);
    }
    return $out;
}

function ops_status_icon($name)
{
    $icons = [
        'menu' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
        'refresh' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>',
    ];
    return isset($icons[$name]) ? $icons[$name] : '';
}
}

$metricHistory = isset($metricHistory) ? $metricHistory : [];
$statusSummary = isset($statusSummary) ? $statusSummary : ['total' => count($servers), 'online' => (int) $stats['online_servers'], 'abnormal' => (int) $stats['offline_servers'], 'stale' => 0];
?>

<main class="ops-app">
    <header class="ops-top">
        <div class="ops-top-left">
            <button class="ops-icon" type="button" aria-label="菜单"><?= ops_status_icon('menu') ?></button>
            <button class="ops-icon" type="button" data-reload-page aria-label="刷新"><?= ops_status_icon('refresh') ?></button>
        </div>
        <div class="ops-top-right">
            <button class="ops-mode" type="button" id="themeToggle">夜间模式</button>
            <div class="ops-user"><span class="ops-avatar"></span><span><?= e(app_brand_name()) ?></span></div>
        </div>
    </header>

    <nav class="ops-tabs">
        <a class="ops-tab" href="<?= url('/') ?>">首页</a>
        <span class="ops-tab active">服务器状态</span>
        <span class="ops-tab">运行概览</span>
        <span class="ops-tab">节点详情</span>
    </nav>

    <section class="ops-page">
        <div class="ops-summary">
            <div class="ops-card ops-cyan"><span>在线节点</span><b><?= e((int) $statusSummary['online']) ?></b><small>当前可用服务器</small></div>
            <div class="ops-card ops-green"><span>监控节点</span><b><?= e((int) $statusSummary['total']) ?></b><small>已接入状态展示</small></div>
            <div class="ops-card ops-red"><span>异常节点</span><b><?= e((int) $statusSummary['abnormal']) ?></b><small>离线或数据过期</small></div>
            <div class="ops-card ops-purple"><span>最近告警</span><b><?= e(count($alerts)) ?></b><small>页面生成 <?= e(date('H:i')) ?></small></div>
        </div>

        <?php if (!empty($statusError)): ?>
            <div class="ops-panel" style="margin-bottom:18px"><div class="ops-panel-body"><?= e($statusError) ?></div></div>
        <?php endif; ?>

        <div class="ops-grid">
            <section class="ops-panel">
                <div class="ops-panel-head"><b>基础信息</b><span>点击服务器查看详细指标</span></div>
                <div class="ops-panel-body">
                    <div class="server-list">
                        <?php if (!$servers): ?>
                            <div class="empty-state">暂无公开服务器，请管理员在后台添加监控服务器并开启状态展示。</div>
                        <?php endif; ?>

                        <?php foreach ($servers as $server): ?>
                            <?php
                            $serverId = (int) $server['id'];
                            $cpu = ops_status_percent(isset($server['cpu_usage']) ? $server['cpu_usage'] : 0);
                            $memory = ops_status_percent(isset($server['memory_usage']) ? $server['memory_usage'] : 0);
                            $disks = ops_status_disks($server);
                            $mainDisk = $disks ? $disks[0] : ['path' => '/', 'total' => 0, 'used' => 0];
                            $diskPercent = $mainDisk['total'] > 0 ? ops_status_percent($mainDisk['used'] / $mainDisk['total'] * 100) : ops_status_percent(isset($server['disk_usage']) ? $server['disk_usage'] : 0);
                            $isStale = ops_status_stale($server);
                            $age = ops_status_age(!empty($server['metric_time']) ? $server['metric_time'] : (isset($server['last_checked_at']) ? $server['last_checked_at'] : ''));
                            $historyRows = isset($metricHistory[$serverId]) ? $metricHistory[$serverId] : [];
                            $detailPayload = [
                                'name' => $server['name'],
                                'source' => ops_status_source($server),
                                'state' => $server['status'] === 'online' && !$isStale ? 'online' : 'abnormal',
                                'age' => $age,
                                'version' => ops_status_version($server),
                                'cpu' => $cpu,
                                'memory' => $memory,
                                'disk' => $diskPercent,
                                'load' => ops_status_load($server),
                                'download' => ops_status_speed(isset($server['net_download']) ? $server['net_download'] : 0),
                                'upload' => ops_status_speed(isset($server['net_upload']) ? $server['net_upload'] : 0),
                                'memory_text' => format_bytes((float) (isset($server['memory_used']) ? $server['memory_used'] : 0)) . ' / ' . format_bytes((float) (isset($server['memory_total']) ? $server['memory_total'] : 0)),
                                'disk_text' => format_bytes((float) $mainDisk['used']) . ' / ' . format_bytes((float) $mainDisk['total']),
                                'panel' => isset($server['panel_status']) ? $server['panel_status'] : 'unknown',
                                'nginx' => isset($server['nginx_status']) ? $server['nginx_status'] : 'unknown',
                                'mysql' => isset($server['mysql_status']) ? $server['mysql_status'] : 'unknown',
                                'php' => isset($server['php_status']) ? $server['php_status'] : 'unknown',
                                'disks' => array_map(function ($disk) {
                                    $percent = $disk['total'] > 0 ? ops_status_percent($disk['used'] / $disk['total'] * 100) : 0;
                                    return ['path' => $disk['path'], 'used' => format_bytes((float) $disk['used']), 'total' => format_bytes((float) $disk['total']), 'percent' => $percent];
                                }, $disks),
                                'history' => [
                                    'cpu' => ops_status_series($historyRows, 'cpu_usage'),
                                    'memory' => ops_status_series($historyRows, 'memory_usage'),
                                    'disk' => ops_status_series($historyRows, 'disk_usage'),
                                    'load' => ops_status_load_series($historyRows),
                                ],
                            ];
                            ?>
                            <button class="server-row" type="button" data-detail="<?= e(json_encode($detailPayload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>">
                                <div class="server-name">
                                    <b><?= e($server['name']) ?> <span class="server-tag"><?= e(ops_status_source($server)) ?></span></b>
                                    <span><?= e($server['remark'] ?: ($server['group_name'] ?: '平台节点')) ?> · <?= e($age) ?><?= $isStale ? ' · 数据过期' : '' ?></span>
                                </div>
                                <div class="server-metric"><span>CPU</span><b><?= e(number_format($cpu, 1)) ?>%</b><i><u style="width:<?= e($cpu) ?>%"></u></i></div>
                                <div class="server-metric"><span>内存</span><b><?= e(number_format($memory, 1)) ?>%</b><i><u style="width:<?= e($memory) ?>%"></u></i></div>
                                <div class="disk-mini"><b><?= e($mainDisk['path']) ?></b><span><?= e(format_bytes((float) $mainDisk['used'])) ?> / <?= e(format_bytes((float) $mainDisk['total'])) ?></span><span class="disk-bar"><i style="width:<?= e($diskPercent) ?>%"></i></span></div>
                                <div class="net-mini"><span>↓ <?= e(ops_status_speed(isset($server['net_download']) ? $server['net_download'] : 0)) ?></span><span>↑ <?= e(ops_status_speed(isset($server['net_upload']) ? $server['net_upload'] : 0)) ?></span></div>
                                <div class="load-mini"><?= e(ops_status_load($server)) ?></div>
                                <span class="state-pill <?= $server['status'] === 'online' && !$isStale ? 'state-ok' : 'state-bad' ?>"><?= $server['status'] === 'online' && !$isStale ? '在线' : '异常' ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>

            <section class="ops-panel server-detail-card">
                <div class="ops-panel-head">
                    <div>
                        <b id="detailName">服务器详情</b>
                        <span id="detailMeta">请选择左侧服务器节点</span>
                    </div>
                    <span class="state-pill state-muted" id="detailState">等待选择</span>
                </div>
                <div class="ops-panel-body server-detail-body">
                    <div class="metric-cards">
                        <div class="metric-card" id="detailCpuBar"><span>CPU</span><b id="detailCpu">0.0%</b></div>
                        <div class="metric-card" id="detailMemoryBar"><span>内存</span><b id="detailMemory">0.0%</b></div>
                        <div class="metric-card" id="detailDiskBar"><span>硬盘</span><b id="detailDisk">0.0%</b></div>
                        <div class="metric-card" id="detailLoadBar"><span>负载</span><b id="detailLoad">0.00</b></div>
                        <div class="metric-card"><span>下行</span><b id="detailDownload">0 Kbps</b></div>
                        <div class="metric-card"><span>上行</span><b id="detailUpload">0 Kbps</b></div>
                    </div>
                    <div class="charts">
                        <div class="chart-card"><div class="chart-title">CPU 使用率 <small id="detailCpuSub">0.0%</small></div><canvas id="statusCpuChart" height="150"></canvas></div>
                        <div class="chart-card"><div class="chart-title">负载趋势 <small id="detailLoadSub">0.00</small></div><canvas id="statusLoadChart" height="150"></canvas></div>
                        <div class="chart-card"><div class="chart-title">内存使用 <small id="detailMemorySub">0 B</small></div><canvas id="statusMemoryChart" height="150"></canvas></div>
                        <div class="chart-card"><div class="chart-title">硬盘使用 <small id="detailDiskSub">0 B</small></div><canvas id="statusDiskChart" height="150"></canvas></div>
                    </div>
                    <div class="detail-bottom">
                        <div class="service-box"><b>服务状态</b><span>Panel <em id="detailPanel">unknown</em></span><span>Nginx <em id="detailNginx">unknown</em></span><span>MySQL <em id="detailMysql">unknown</em></span><span>PHP <em id="detailPhp">unknown</em></span></div>
                        <div class="disk-box" id="detailDisks"><b>硬盘信息</b></div>
                    </div>
                    <div class="notice-list compact-notice">
                        <p class="notice-row"><span class="notice-mark">01</span><span>数据由后台监控任务自动采集，异常通常表示服务器离线、采集失败或数据过期。</span></p>
                        <p class="notice-row"><span class="notice-mark">02</span><span>建议至少配置两个监控节点，并设置 CPU、内存、硬盘告警阈值。</span></p>
                    </div>
                </div>
            </section>
        </div>
    </section>
</main>
