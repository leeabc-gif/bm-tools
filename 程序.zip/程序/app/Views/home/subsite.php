<?php
$site = isset($subsite) ? $subsite : [];
$data = isset($subsiteData) ? $subsiteData : ['files' => [], 'repositories' => [], 'stats' => []];
$stats = isset($data['stats']) ? $data['stats'] : [];
$files = isset($data['files']) ? $data['files'] : [];
$repositories = isset($data['repositories']) ? $data['repositories'] : [];
$siteTitle = !empty($site['title']) ? $site['title'] : (!empty($site['name']) ? $site['name'] : setting('site_name', app_brand_name()));
$heroTitle = !empty($site['hero_title']) ? $site['hero_title'] : $siteTitle;
$heroDescription = !empty($site['hero_description']) ? $site['hero_description'] : (!empty($site['subtitle']) ? $site['subtitle'] : '这里整理了公开图片、资源仓库和项目资料。');
$themeColor = !empty($site['theme_color']) ? $site['theme_color'] : '#2563EB';
$ownerName = !empty($site['nickname']) ? $site['nickname'] : (!empty($site['username']) ? $site['username'] : 'Owner');
?>

<section class="subsite-public" style="--subsite-accent: <?= e($themeColor) ?>">
    <header class="subsite-public-header">
        <div class="subsite-public-shell">
            <a class="subsite-public-brand" href="<?= e(public_url('/')) ?>">
                <?php if (!empty($site['logo'])): ?>
                    <img src="<?= e($site['logo']) ?>" alt="<?= e($siteTitle) ?>">
                <?php else: ?>
                    <span><?= e(text_initial($siteTitle, 'B')) ?></span>
                <?php endif; ?>
                <b><?= e($siteTitle) ?></b>
            </a>
            <nav>
                <a href="#files">公开文件</a>
                <a href="#repositories">资源仓库</a>
                <?php if (!empty($site['contact_email'])): ?><a href="mailto:<?= e($site['contact_email']) ?>">联系</a><?php endif; ?>
            </nav>
        </div>
    </header>

    <main>
        <section class="subsite-public-hero">
            <div class="subsite-public-shell subsite-public-hero-grid">
                <div>
                    <span class="subsite-kicker">Personal Resource Site</span>
                    <h1><?= e($heroTitle) ?></h1>
                    <p><?= e($heroDescription) ?></p>
                    <div class="subsite-public-actions">
                        <a href="#files">浏览公开文件</a>
                        <a href="#repositories">查看资源仓库</a>
                    </div>
                </div>
                <aside class="subsite-public-panel">
                    <span>由 <?= e($ownerName) ?> 维护</span>
                    <strong><?= e(number_format((int) (isset($stats['files']) ? $stats['files'] : 0))) ?></strong>
                    <p>公开资源文件</p>
                    <div>
                        <em><?= e(number_format((int) (isset($stats['repositories']) ? $stats['repositories'] : 0))) ?> 仓库</em>
                        <em><?= e(number_format((int) (isset($stats['views']) ? $stats['views'] : 0))) ?> 访问</em>
                    </div>
                </aside>
            </div>
        </section>

        <?php if (!empty($site['announcement'])): ?>
            <section class="subsite-public-shell">
                <div class="subsite-announcement">
                    <i data-lucide="megaphone"></i>
                    <span><?= e($site['announcement']) ?></span>
                </div>
            </section>
        <?php endif; ?>

        <section class="subsite-public-shell subsite-stats-strip" aria-label="分站数据">
            <article><b><?= e(number_format((int) (isset($stats['images']) ? $stats['images'] : 0))) ?></b><span>公开图片</span></article>
            <article><b><?= e(number_format((int) (isset($stats['files']) ? $stats['files'] : 0))) ?></b><span>公开文件</span></article>
            <article><b><?= e(number_format((int) (isset($stats['repositories']) ? $stats['repositories'] : 0))) ?></b><span>资源仓库</span></article>
            <article><b><?= e(number_format((int) (isset($stats['servers']) ? $stats['servers'] : 0))) ?></b><span>状态页面</span></article>
        </section>

        <section class="subsite-public-shell subsite-section" id="files">
            <div class="subsite-section-head">
                <span class="subsite-kicker">Files</span>
                <h2>公开文件</h2>
                <p>最近公开的图片和文件资源。</p>
            </div>
            <div class="subsite-file-grid">
                <?php foreach ($files as $file): ?>
                    <a class="subsite-file-card" href="<?= e($file['file_url']) ?>" target="_blank">
                        <figure>
                            <?php if ($file['file_type'] === 'image'): ?>
                                <img src="<?= e($file['thumbnail_url'] ?: $file['file_url']) ?>" alt="<?= e($file['original_name']) ?>">
                            <?php else: ?>
                                <i data-lucide="file"></i>
                            <?php endif; ?>
                        </figure>
                        <b><?= e($file['original_name']) ?></b>
                        <span><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></span>
                    </a>
                <?php endforeach; ?>
                <?php if (!$files): ?>
                    <div class="subsite-empty">暂时没有公开文件。</div>
                <?php endif; ?>
            </div>
        </section>

        <section class="subsite-public-shell subsite-section" id="repositories">
            <div class="subsite-section-head">
                <span class="subsite-kicker">Repositories</span>
                <h2>资源仓库</h2>
                <p>按项目整理的公开资源页。</p>
            </div>
            <div class="subsite-repo-grid">
                <?php foreach ($repositories as $repo): ?>
                    <a class="subsite-repo-card" href="<?= e(public_url('r/' . $repo['slug'])) ?>">
                        <?php if (!empty($repo['cover_image'])): ?><img src="<?= e($repo['cover_image']) ?>" alt="<?= e($repo['title']) ?>"><?php endif; ?>
                        <div>
                            <b><?= e($repo['title']) ?></b>
                            <p><?= e($repo['description'] ?: '公开资源仓库') ?></p>
                            <span><?= e((int) $repo['view_count']) ?> 访问 · <?= e((int) $repo['download_count']) ?> 下载</span>
                        </div>
                    </a>
                <?php endforeach; ?>
                <?php if (!$repositories): ?>
                    <div class="subsite-empty">暂时没有公开资源仓库。</div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <footer class="subsite-public-footer">
        <div class="subsite-public-shell">
            <span><?= e($siteTitle) ?></span>
            <span><?= e(!empty($site['icp_text']) ? $site['icp_text'] : app_copyright_text()) ?></span>
        </div>
    </footer>
</section>
