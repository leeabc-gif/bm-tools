<?php
$homeStats = isset($stats) && is_array($stats) ? $stats : [];
$files = isset($homeStats['files']) ? (int) $homeStats['files'] : 0;
$todayUploads = isset($homeStats['today_uploads']) ? (int) $homeStats['today_uploads'] : 0;
$onlineServers = isset($homeStats['online_servers']) ? (int) $homeStats['online_servers'] : 0;
$offlineServers = isset($homeStats['offline_servers']) ? (int) $homeStats['offline_servers'] : 0;
$totalServers = $onlineServers + $offlineServers;
$storageBytes = isset($homeStats['storage']) ? (float) $homeStats['storage'] : 0;
$siteName = setting('site_name', app_brand_name());
$storageText = function_exists('format_bytes') ? format_bytes($storageBytes) : number_format($storageBytes / 1024 / 1024, 1) . ' MB';
$currentUser = \App\Core\Auth::user();
$isAdminUser = $currentUser && isset($currentUser['role']) && $currentUser['role'] === 'admin';

$workflowCards = [
    ['num' => '01', 'tone' => 'blue', 'title' => '上传资源', 'desc' => '图片、附件和资料进入同一个工作台，按用途放入图床、网盘或仓库。'],
    ['num' => '02', 'tone' => 'pink', 'title' => '生成链接', 'desc' => '复制直链、Markdown、HTML 或分享页地址，不用在多个工具之间来回切换。'],
    ['num' => '03', 'tone' => 'red', 'title' => '持续维护', 'desc' => '查看访问记录、下载记录和服务器状态，后续排查更有依据。'],
];

$featureCards = [
    ['icon' => 'image', 'title' => '图床外链', 'desc' => '上传后生成直链、Markdown、HTML 和 BBCode，适合博客、论坛和文档配图。'],
    ['icon' => 'hard-drive', 'title' => '个人网盘', 'desc' => '把图片、附件、压缩包和项目资料放到一个清晰的目录体系里。'],
    ['icon' => 'library', 'title' => '分享仓库', 'desc' => '一组文件一个公开页面，支持密码、权限、访问日志和下载记录。'],
    ['icon' => 'activity', 'title' => '服务器监控', 'desc' => '集中查看在线状态、CPU、内存、磁盘、网络和异常提醒。'],
];

$metricCards = [
    ['value' => number_format($files), 'unit' => '', 'label' => '资源文件', 'desc' => '平台已托管的图片、附件和仓库文件数量。'],
    ['value' => number_format($todayUploads), 'unit' => '', 'label' => '今日上传', 'desc' => '当天新增资源，方便观察使用活跃度。'],
    ['value' => $storageText, 'unit' => '', 'label' => '已用空间', 'desc' => '当前资源累计占用的存储容量。'],
    ['value' => $totalServers > 0 ? number_format($onlineServers) . '/' . number_format($totalServers) : '0', 'unit' => '', 'label' => '在线监控', 'desc' => '已接入服务器的实时在线状态。'],
];
?>

<section class="cloud-home pro-home space-home">
    <header class="space-header">
        <div class="space-shell space-header-shell">
            <a class="space-brand" href="<?= url('/') ?>" aria-label="<?= e($siteName) ?>">
                <span class="space-brand-mark" aria-hidden="true"><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
                <span><?= e($siteName) ?></span>
            </a>
            <nav class="space-nav" aria-label="主导航">
                <a class="space-nav-link" href="#section-hero">首页</a>
                <a class="space-nav-link" href="#section-workflow">流程</a>
                <a class="space-nav-link" href="#section-features">功能</a>
                <a class="space-nav-link" href="#section-metrics">数据</a>
                <a class="space-nav-link" href="<?= url('announcements') ?>">公告</a>
                <a class="space-nav-link" href="<?= url('status') ?>">服务器状态</a>
            </nav>
            <div class="space-header-actions">
                <?php if ($currentUser): ?>
                    <a class="space-button space-button-ghost" href="<?= url('status') ?>">服务器状态</a>
                    <a class="space-button space-button-dark" href="<?= url('dashboard') ?>">用户中心</a>
                <?php else: ?>
                    <a class="space-button space-button-ghost" href="<?= url('register') ?>">注册</a>
                    <a class="space-button space-button-dark" href="<?= url('login') ?>">登录</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main class="space-main">
        <section class="space-hero-section" id="section-hero">
            <div class="space-shell space-hero-inner">
                <div class="space-hero-top">
                    <div class="space-hero-copy">
                        <p class="space-eyebrow">个人资源工作台</p>
                        <h1>图片外链、文件归档、服务器状态，统一管理。</h1>
                        <p class="space-hero-lead">面向个人站点、博客文档和小型项目，把图床、网盘、分享仓库和监控放在同一套清晰的管理流程里。</p>
                        <div class="space-hero-actions">
                            <?php if ($currentUser): ?>
                                <a class="space-button space-button-dark" href="<?= url('dashboard') ?>">进入用户中心</a>
                                <a class="space-button space-button-ghost" href="<?= url('status') ?>">查看服务器状态</a>
                            <?php else: ?>
                                <a class="space-button space-button-dark" href="<?= url('register') ?>">注册账号</a>
                                <a class="space-button space-button-ghost" href="<?= url('login') ?>">已有账号登录</a>
                            <?php endif; ?>
                        </div>
                        <div class="space-hero-stats" aria-label="平台概览">
                            <span><b><?= e(number_format($files)) ?></b><em>资源文件</em></span>
                            <span><b><?= e(number_format($todayUploads)) ?></b><em>今日上传</em></span>
                            <span><b><?= e($totalServers > 0 ? $onlineServers . '/' . $totalServers : 'Ready') ?></b><em>服务器状态</em></span>
                        </div>
                    </div>

                    <div class="space-hero-visual" aria-hidden="true">
                        <div class="space-flow-panel">
                            <div class="space-flow-head">
                                <span>Live workflow</span>
                                <b>同步中</b>
                            </div>
                            <div class="space-flow-canvas">
                                <span class="space-flow-line line-one"></span>
                                <span class="space-flow-line line-two"></span>
                                <span class="space-flow-pulse pulse-one"></span>
                                <span class="space-flow-pulse pulse-two"></span>
                                <article class="space-flow-node node-upload">
                                    <i data-lucide="upload-cloud"></i>
                                    <span>上传</span>
                                    <b>cover.png</b>
                                </article>
                                <article class="space-flow-node node-link">
                                    <i data-lucide="link-2"></i>
                                    <span>外链</span>
                                    <b>Markdown</b>
                                </article>
                                <article class="space-flow-node node-archive">
                                    <i data-lucide="archive"></i>
                                    <span>归档</span>
                                    <b>Repository</b>
                                </article>
                                <article class="space-flow-node node-status">
                                    <i data-lucide="activity"></i>
                                    <span>监控</span>
                                    <b><?= e($totalServers > 0 ? $onlineServers . '/' . $totalServers : 'Ready') ?></b>
                                </article>
                                <div class="space-flow-terminal">
                                    <p><span></span><span></span><span></span></p>
                                    <code>sync / storage / status</code>
                                    <em></em>
                                    <em></em>
                                    <em></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="space-product-preview" aria-label="资源工作台预览">
                    <div class="space-preview-head">
                        <span>资源工作台</span>
                        <b>实时概览</b>
                    </div>
                    <div class="space-preview-body">
                        <article class="space-preview-main">
                            <small>最近上传</small>
                            <strong>cover.png</strong>
                            <p>已生成直链、Markdown 和 HTML 引用，适合博客文章直接插入。</p>
                            <div class="space-preview-progress" aria-hidden="true">
                                <i style="width: 88%"></i>
                                <i style="width: 62%"></i>
                                <i style="width: 74%"></i>
                            </div>
                            <div>
                                <span>外链可用</span>
                                <span>仓库已同步</span>
                            </div>
                        </article>
                        <aside class="space-preview-side">
                            <p><b><?= e(number_format($files)) ?></b><span>资源文件</span></p>
                            <p><b><?= e(number_format($todayUploads)) ?></b><span>今日上传</span></p>
                            <p><b><?= e($storageText) ?></b><span>已用空间</span></p>
                            <p><b><?= e($totalServers > 0 ? $onlineServers . '/' . $totalServers : '0') ?></b><span>在线监控</span></p>
                        </aside>
                    </div>
                </div>
            </div>
        </section>

        <section class="space-trust-section">
            <div class="space-shell space-trust-inner">
                <p class="space-eyebrow">核心模块</p>
                <div class="space-trust-logos" aria-label="核心模块">
                    <span>图床外链</span>
                    <span>个人网盘</span>
                    <span>分享仓库</span>
                    <span>服务器状态</span>
                    <span>对象存储</span>
                </div>
            </div>
        </section>

        <section class="space-workflow-section" id="section-workflow">
            <div class="space-shell">
                <div class="space-section-head">
                    <p class="space-eyebrow">处理流程</p>
                    <h2>从上传到分发，路径尽量短。</h2>
                </div>
                <div class="space-workflow-pipeline">
                    <?php foreach ($workflowCards as $index => $card): ?>
                        <article class="space-workflow-step <?= e($card['tone']) ?>">
                            <span><?= e($card['num']) ?></span>
                            <h3><?= e($card['title']) ?></h3>
                            <p><?= e($card['desc']) ?></p>
                        </article>
                        <?php if ($index < count($workflowCards) - 1): ?>
                            <div class="space-workflow-connector" aria-hidden="true"></div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="space-features-section" id="section-features">
            <div class="space-shell">
                <div class="space-section-head">
                    <p class="space-eyebrow">核心功能</p>
                    <h2>常用能力放在清楚的位置。</h2>
                </div>
                <div class="space-feature-grid">
                    <?php foreach ($featureCards as $card): ?>
                        <article class="space-feature-card">
                            <i data-lucide="<?= e($card['icon']) ?>"></i>
                            <h3><?= e($card['title']) ?></h3>
                            <p><?= e($card['desc']) ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="space-metrics-section" id="section-metrics">
            <div class="space-shell">
                <div class="space-metrics-grid">
                    <?php foreach ($metricCards as $card): ?>
                        <article class="space-metric-card">
                            <p><strong><?= e($card['value']) ?></strong><span><?= e($card['unit']) ?></span></p>
                            <h3><?= e($card['label']) ?></h3>
                            <small><?= e($card['desc']) ?></small>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="space-cta-section" id="section-cta">
            <div class="space-shell space-cta-inner">
                <p class="space-eyebrow light">开始使用</p>
                <h2>准备好管理你的个人云资源了吗？</h2>
                <p>从一次上传开始，把图床、文件仓库和服务器状态放到同一个工作台中。</p>
                <div class="space-cta-actions">
                    <a class="space-button space-button-white" href="<?= url('register') ?>">注册账号</a>
                    <a class="space-button space-button-outline" href="<?= url('login') ?>">登录使用</a>
                </div>
            </div>
        </section>
    </main>

    <footer class="space-footer">
        <div class="space-shell space-footer-shell">
            <b><?= e($siteName) ?></b>
            <span>个人图床、轻量网盘、分享仓库和服务器监控平台。</span>
            <nav aria-label="页脚导航">
                <a href="<?= url('announcements') ?>">公告</a>
                <a href="<?= url('status') ?>">服务状态</a>
            </nav>
        </div>
    </footer>
</section>
