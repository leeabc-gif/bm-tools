<?php
$logs = isset($logs) && is_array($logs) ? $logs : [];
$stats = isset($stats) && is_array($stats) ? $stats : ['total' => count($logs), 'recharge' => 0, 'consume' => 0, 'refund' => 0, 'adjust' => 0];
$user = isset($user) && is_array($user) ? $user : [];
$typeNames = ['recharge' => '充值入账', 'consume' => '余额消费', 'refund' => '退款返还', 'adjust' => '人工调整'];
$typeIcons = ['recharge' => 'plus-circle', 'consume' => 'shopping-bag', 'refund' => 'rotate-ccw', 'adjust' => 'sliders-horizontal'];
$typeTone = function ($type) {
    if ($type === 'recharge' || $type === 'refund') return 'ok';
    if ($type === 'consume') return 'muted';
    return 'warn';
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>资金流水</span>
            <h1>余额流水</h1>
            <p>当前余额：¥<?= e(number_format((float) (isset($user['balance']) ? $user['balance'] : 0), 2)) ?></p>
        </div>
        <a class="m-pill" href="<?= url('m/recharge') ?>">充值</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            余额流水数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复。</span>
        </section>
    <?php endif; ?>

    <section class="m-action-grid">
        <a href="<?= url('m/orders') ?>"><i data-lucide="receipt-text"></i><span>订单记录</span></a>
        <a href="<?= url('m/recharge') ?>"><i data-lucide="wallet-cards"></i><span>账户充值</span></a>
        <a href="<?= url('m/cards') ?>"><i data-lucide="ticket-check"></i><span>卡密兑换</span></a>
        <a href="<?= url('m/packages') ?>"><i data-lucide="badge-dollar-sign"></i><span>套餐升级</span></a>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="余额流水分区">
        <a href="#balanceSummary">流水概览</a>
        <a href="#balanceDetail">资金明细</a>
        <a href="<?= url('m/recharge') ?>">充值</a>
    </nav>

    <section class="m-card" id="balanceSummary">
        <div class="m-section-head">
            <div><span>流水概览</span><h2>最近 120 条</h2></div>
        </div>
        <div class="m-meta-grid">
            <span class="m-badge muted">流水 <?= e(number_format((int) (isset($stats['total']) ? $stats['total'] : 0))) ?> 条</span>
            <span class="m-badge ok">充值 ¥<?= e(number_format((float) (isset($stats['recharge']) ? $stats['recharge'] : 0), 2)) ?></span>
            <span class="m-badge muted">消费 ¥<?= e(number_format(abs((float) (isset($stats['consume']) ? $stats['consume'] : 0)), 2)) ?></span>
            <span class="m-badge warn">调整 ¥<?= e(number_format((float) (isset($stats['refund']) ? $stats['refund'] : 0) + (float) (isset($stats['adjust']) ? $stats['adjust'] : 0), 2)) ?></span>
        </div>
    </section>

    <section class="m-card" id="balanceDetail">
        <div class="m-section-head"><div><span>资金明细</span><h2>资金明细</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索类型、金额、关联或备注" data-mobile-filter-input="#mobileBalanceLogsList">
        </label>
        <div class="m-list" id="mobileBalanceLogsList">
            <?php foreach ($logs as $row): ?>
                <?php
                $type = isset($typeNames[$row['type']]) ? $row['type'] : 'adjust';
                $amount = (float) (isset($row['amount']) ? $row['amount'] : 0);
                $related = trim((string) (isset($row['related_type']) ? $row['related_type'] : ''));
                if (!empty($row['related_id'])) {
                    $related .= ($related === '' ? '' : ' ') . '#' . $row['related_id'];
                }
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= e($typeIcons[$type]) ?>"></i>
                    <div>
                        <strong><?= e($typeNames[$type]) ?> · <?= $amount >= 0 ? '+' : '-' ?>¥<?= e(number_format(abs($amount), 2)) ?></strong>
                        <span><?= e(isset($row['created_at']) ? $row['created_at'] : '-') ?></span>
                    </div>
                    <span class="m-badge <?= e($typeTone($type)) ?>"><?= e($typeNames[$type]) ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">前 ¥<?= e(number_format((float) (isset($row['balance_before']) ? $row['balance_before'] : 0), 2)) ?></span>
                        <span class="m-badge muted">后 ¥<?= e(number_format((float) (isset($row['balance_after']) ? $row['balance_after'] : 0), 2)) ?></span>
                        <span class="m-badge muted"><?= e($related !== '' ? $related : '无关联') ?></span>
                    </div>
                    <?php if (!empty($row['remark'])): ?><div class="m-note"><?= e($row['remark']) ?></div><?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的流水。</div>
            <?php if (!$logs): ?><div class="m-empty">暂无余额流水。</div><?php endif; ?>
        </div>
    </section>
</section>
