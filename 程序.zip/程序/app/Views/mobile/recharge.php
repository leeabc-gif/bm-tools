<?php
$payments = isset($payments) && is_array($payments) ? $payments : [];
$recharges = isset($recharges) && is_array($recharges) ? $recharges : [];
$user = isset($user) && is_array($user) ? $user : [];
$methodNames = ['manual' => '人工充值审核', 'alipay' => '支付宝当面付'];
$statusNames = ['pending' => '待处理', 'paid' => '已入账', 'rejected' => '已拒绝', 'closed' => '已关闭'];
$quickAmounts = [10, 30, 50, 100, 200, 500];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>账户余额</span>
            <h1>账户充值</h1>
            <p>当前余额：¥<?= e(number_format((float) (isset($user['balance']) ? $user['balance'] : 0), 2)) ?></p>
        </div>
        <a class="m-pill" href="<?= url('m/balance') ?>">流水</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            充值数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复。</span>
        </section>
    <?php endif; ?>

    <section class="m-card">
        <div class="m-section-head">
            <div><span>充值订单</span><h2>创建充值订单</h2></div>
            <a href="<?= url('m/cards') ?>">卡密</a>
        </div>
        <form class="m-mini-form" method="post" action="<?= url('m/recharge') ?>">
            <?= csrf_field() ?>
            <input id="mRechargeAmount" type="number" step="0.01" min="1" max="99999" name="amount" required placeholder="充值金额，例如 50">
            <div class="m-chip-list" aria-label="快捷金额">
                <?php foreach ($quickAmounts as $amount): ?>
                    <button class="m-chip-button" type="button" data-fill-target="#mRechargeAmount" data-fill-value="<?= e($amount) ?>">¥<?= e($amount) ?></button>
                <?php endforeach; ?>
            </div>
            <?php if ($payments): ?>
                <select name="payment_method">
                    <?php foreach ($payments as $payment): ?>
                        <?php $code = isset($payment['code']) ? $payment['code'] : 'manual'; ?>
                        <option value="<?= e($code) ?>"><?= e(isset($methodNames[$code]) ? $methodNames[$code] : $payment['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>
            <button type="submit" <?= $payments ? '' : 'disabled' ?>><?= $payments ? '提交充值订单' : '暂无可用充值方式' ?></button>
        </form>
        <?php if (!$payments): ?>
            <div class="m-note">请管理员在后台支付配置中启用人工充值或支付宝当面付。</div>
        <?php else: ?>
            <div class="m-note">人工充值需要管理员审核；支付宝当面付创建后会进入扫码支付页。</div>
        <?php endif; ?>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>最近记录</span><h2>最近充值</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索金额、方式、状态或备注" data-mobile-filter-input="#mobileRechargeList">
        </label>
        <div class="m-list" id="mobileRechargeList">
            <?php foreach ($recharges as $row): ?>
                <?php
                $method = isset($row['payment_method']) ? $row['payment_method'] : '';
                $status = isset($row['status']) ? $row['status'] : '';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="wallet-cards"></i>
                    <div>
                        <strong>¥<?= e(number_format((float) (isset($row['amount']) ? $row['amount'] : 0), 2)) ?></strong>
                        <span><?= e(isset($methodNames[$method]) ? $methodNames[$method] : $method) ?> · <?= e(isset($row['created_at']) ? $row['created_at'] : '-') ?></span>
                    </div>
                    <span class="m-badge <?= $status === 'paid' ? 'ok' : ($status === 'pending' ? 'warn' : 'bad') ?>"><?= e(isset($statusNames[$status]) ? $statusNames[$status] : $status) ?></span>
                    <?php if (!empty($row['audit_remark'])): ?><div class="m-note"><?= e($row['audit_remark']) ?></div><?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的充值记录。</div>
            <?php if (!$recharges): ?><div class="m-empty">暂无充值记录。</div><?php endif; ?>
        </div>
    </section>
</section>
