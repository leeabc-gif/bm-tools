<?php
$packages = isset($packages) && is_array($packages) ? $packages : [];
$payments = isset($payments) && is_array($payments) ? $payments : [];
$coupons = isset($coupons) && is_array($coupons) ? $coupons : [];
$user = isset($user) && is_array($user) ? $user : [];
$paymentNames = ['balance' => '余额支付', 'alipay' => '支付宝', 'manual' => '人工处理'];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>套餐权益</span>
            <h1>套餐升级</h1>
            <p>选择更合适的空间、流量、API、分享仓库、服务器管家和个人分站权益。</p>
        </div>
        <a class="m-pill" href="<?= url('m/orders') ?>">订单</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            套餐数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复。</span>
        </section>
    <?php endif; ?>

    <section class="m-stat-grid two">
        <article><span>当前余额</span><strong>¥<?= e(number_format((float) (isset($user['balance']) ? $user['balance'] : 0), 2)) ?></strong><small>余额可直接支付</small></article>
        <article><span>当前套餐</span><strong><?= e(!empty($user['package_id']) ? ('#' . (int) $user['package_id']) : '-') ?></strong><small><?= e(!empty($user['package_expire_time']) ? $user['package_expire_time'] : '未开通或永久') ?></small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="套餐页面分区">
        <?php if ($coupons): ?><a href="#mobileCoupons">可用优惠</a><?php endif; ?>
        <a href="#mobilePackageList">套餐列表</a>
        <a href="<?= url('m/recharge') ?>">充值余额</a>
        <a href="<?= url('m/orders') ?>">订单记录</a>
    </nav>

    <?php if ($coupons): ?>
        <section class="m-card" id="mobileCoupons">
            <div class="m-section-head"><div><span>优惠权益</span><h2>可用优惠</h2></div></div>
            <div class="m-chip-list">
                <?php foreach ($coupons as $coupon): ?>
                    <button class="m-chip-button" type="button" data-copy-text="<?= e($coupon['code']) ?>">
                        <?= e($coupon['code']) ?> / <?= $coupon['discount_type'] === 'percent' ? e($coupon['discount_value']) . '% 折扣' : '立减 ¥' . e($coupon['discount_value']) ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="m-card" id="mobilePackageList">
        <div class="m-section-head"><div><span>套餐列表</span><h2>可购买套餐</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索套餐名、权益、价格或时长" data-mobile-filter-input="#mobilePackagesList">
        </label>
        <div class="m-plan-list" id="mobilePackagesList">
            <?php foreach ($packages as $package): ?>
                <article class="m-plan-card <?= !empty($package['is_current']) ? 'is-current' : '' ?>" data-mobile-filter-item>
                    <header>
                        <div>
                            <span><?= !empty($package['is_current']) ? '当前套餐' : '可选套餐' ?></span>
                            <h2><?= e($package['name']) ?></h2>
                            <p><?= e(isset($package['description']) ? $package['description'] : '') ?></p>
                        </div>
                        <strong>¥<?= e(number_format((float) $package['display_price'], 2)) ?></strong>
                    </header>
                    <?php if ((float) $package['display_price'] !== (float) $package['price']): ?>
                        <div class="m-note">已自动抵扣当前套餐剩余价值，原价 ¥<?= e(number_format((float) $package['price'], 2)) ?>。</div>
                    <?php endif; ?>
                    <div class="m-chip-list">
                        <?php foreach ($package['features'] as $feature): ?>
                            <span><?= e($feature) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <form method="post" action="<?= url('m/packages/buy') ?>" class="m-mini-form" data-mobile-confirm="确认提交这个套餐订单吗？">
                        <?= csrf_field() ?>
                        <input type="hidden" name="package_id" value="<?= e($package['id']) ?>">
                        <input name="coupon_code" placeholder="优惠码，可不填">
                        <?php if ($payments): ?>
                            <select name="payment_method">
                                <?php foreach ($payments as $payment): ?>
                                    <?php $code = isset($payment['code']) ? $payment['code'] : 'balance'; ?>
                                    <option value="<?= e($code) ?>"><?= e(isset($paymentNames[$code]) ? $paymentNames[$code] : $payment['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                        <button type="submit" <?= $payments ? '' : 'disabled' ?>><?= $payments ? '提交订单' : '暂无可用支付方式' ?></button>
                    </form>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的套餐。</div>
            <?php if (!$packages): ?><div class="m-empty">暂无可购买套餐，请联系管理员在后台套餐管理中启用套餐。</div><?php endif; ?>
        </div>
    </section>
</section>
