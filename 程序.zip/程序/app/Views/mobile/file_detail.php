<?php
$file = isset($file) ? $file : [];
$fileUrl = isset($fileUrl) ? $fileUrl : '';
$isImage = isset($file['file_type']) && $file['file_type'] === 'image';
$fileId = (int) (isset($file['id']) ? $file['id'] : 0);
$downloadUrl = $fileId > 0 ? url(($isImage ? 'files/download?id=' : 'netdisk/download?id=') . $fileId) : '';
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>文件详情</span>
            <h1>文件详情</h1>
            <p><?= e(isset($file['original_name']) ? $file['original_name'] : '文件') ?></p>
        </div>
        <a class="m-pill" href="<?= url($isImage ? 'm/files' : 'm/netdisk') ?>">返回</a>
    </header>

    <?php if ($isImage && $fileUrl !== ''): ?>
        <section class="m-card m-file-preview-card">
            <a class="m-file-preview" href="<?= e($fileUrl) ?>" target="_blank">
                <img class="m-preview-image" src="<?= e($fileUrl) ?>" alt="<?= e(isset($file['original_name']) ? $file['original_name'] : '图片') ?>">
            </a>
        </section>
    <?php endif; ?>

    <section class="m-card">
        <div class="m-section-head"><div><span>快捷操作</span><h2>快捷操作</h2></div></div>
        <div class="m-inline-actions">
            <?php if ($fileUrl !== ''): ?>
                <a class="m-button" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener">打开外链</a>
                <button class="m-button ghost" type="button" data-copy-text="<?= e($fileUrl) ?>">复制外链</button>
            <?php endif; ?>
            <?php if ($downloadUrl !== ''): ?>
                <a class="m-button ghost" href="<?= e($downloadUrl) ?>">下载文件</a>
            <?php endif; ?>
            <a class="m-button ghost" href="<?= url($isImage ? 'm/files' : 'm/netdisk') ?>">返回列表</a>
        </div>
        <?php if ($fileUrl === ''): ?>
            <div class="m-note">暂未生成可访问外链，请检查文件是否入库成功，或联系管理员检查对象存储域名配置。</div>
        <?php endif; ?>
    </section>

    <section class="m-card">
        <div class="m-list">
            <article class="m-list-item"><i data-lucide="file"></i><div><strong>文件名</strong><span><?= e(isset($file['original_name']) ? $file['original_name'] : '-') ?></span></div></article>
            <article class="m-list-item"><i data-lucide="hard-drive"></i><div><strong>大小</strong><span><?= e(format_bytes(isset($file['file_size']) ? $file['file_size'] : 0)) ?></span></div></article>
            <article class="m-list-item"><i data-lucide="clock"></i><div><strong>上传时间</strong><span><?= e(isset($file['created_at']) ? $file['created_at'] : '-') ?></span></div></article>
            <article class="m-list-item"><i data-lucide="download"></i><div><strong>下载次数</strong><span><?= e((int) (isset($file['download_count']) ? $file['download_count'] : 0)) ?></span></div></article>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>文件外链</span><h2>外链</h2></div></div>
        <?php if ($fileUrl !== ''): ?>
            <div class="m-copy-stack">
                <div class="m-copy-row"><span><?= e($fileUrl) ?></span><button type="button" data-copy-text="<?= e($fileUrl) ?>">复制</button></div>
                <?php if ($isImage): ?>
                    <div class="m-copy-row"><span>![<?= e(isset($file['original_name']) ? $file['original_name'] : 'image') ?>](<?= e($fileUrl) ?>)</span><button type="button" data-copy-text="![<?= e(isset($file['original_name']) ? $file['original_name'] : 'image') ?>](<?= e($fileUrl) ?>)">复制</button></div>
                    <div class="m-copy-row"><span>&lt;img src=&quot;<?= e($fileUrl) ?>&quot; alt=&quot;<?= e(isset($file['original_name']) ? $file['original_name'] : 'image') ?>&quot;&gt;</span><button type="button" data-copy-text="&lt;img src=&quot;<?= e($fileUrl) ?>&quot; alt=&quot;<?= e(isset($file['original_name']) ? $file['original_name'] : 'image') ?>&quot;&gt;">复制</button></div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="m-empty">暂无可复制外链。</div>
        <?php endif; ?>
    </section>
</section>
