<section class="m-page">
    <header class="m-hero">
        <span>移动工作台</span>
        <h1><?= e($user['nickname'] ?: $user['username']) ?>，欢迎回来</h1>
        <p>这里是独立手机端工作台，菜单、列表和操作都不再依赖 PC 侧边栏。</p>
    </header>

    <section class="m-stat-grid">
        <article><span>文件</span><strong><?= e($stats['files']) ?></strong><small>图片 <?= e($stats['images']) ?> / 网盘 <?= e($stats['netdisk']) ?></small></article>
        <article><span>存储</span><strong><?= e($stats['storage_percent']) ?>%</strong><small><?= e(format_bytes($stats['storage_used'])) ?> / <?= e($stats['storage_total'] > 0 ? format_bytes($stats['storage_total']) : '不限') ?></small></article>
        <article><span>服务器</span><strong><?= e($stats['servers']) ?></strong><small>用户自有服务器</small></article>
        <article><span>分站</span><strong><?= e($stats['subsites']) ?></strong><small>独立资源站</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="移动工作台分区">
        <a href="#dashboardActions">常用操作</a>
        <?php if (!empty($notices)): ?><a href="#dashboardNotices">最近通知</a><?php endif; ?>
        <a href="#dashboardRecentFiles">最近文件</a>
        <a href="<?= url('m/menu') ?>">全部功能</a>
    </nav>

    <section class="m-card" id="dashboardActions">
        <div class="m-section-head">
            <div><span>常用操作</span><h2>常用操作</h2></div>
        </div>
        <div class="m-action-grid">
            <a href="<?= url('m/files') ?>"><i data-lucide="upload-cloud"></i><span>上传图片</span></a>
            <a href="<?= url('m/netdisk') ?>"><i data-lucide="hard-drive"></i><span>网盘文件</span></a>
            <a href="<?= url('m/repository') ?>"><i data-lucide="library"></i><span>分享仓库</span></a>
            <a href="<?= url('m/servers') ?>"><i data-lucide="server-cog"></i><span>服务器</span></a>
            <a href="<?= url('m/subsites') ?>"><i data-lucide="globe-2"></i><span>分站</span></a>
            <a href="<?= url('m/orders') ?>"><i data-lucide="receipt-text"></i><span>订单记录</span></a>
            <a href="<?= url('m/balance') ?>"><i data-lucide="coins"></i><span>余额流水</span></a>
            <a href="<?= url('m/teams') ?>"><i data-lucide="users-round"></i><span>团队</span></a>
        </div>
    </section>

    <?php if (!empty($notices)): ?>
        <section class="m-card" id="dashboardNotices">
            <div class="m-section-head">
                <div><span>系统通知</span><h2>最近通知</h2></div>
                <a href="<?= url('m/notifications') ?>">查看</a>
            </div>
            <div class="m-list">
                <?php foreach ($notices as $notice): ?>
                    <article class="m-list-item tall">
                        <i data-lucide="<?= empty($notice['is_read']) ? 'bell-ring' : 'bell' ?>"></i>
                        <div>
                            <strong><?= e(isset($notice['title']) ? $notice['title'] : '系统通知') ?></strong>
                            <span><?= e(text_limit(isset($notice['content']) ? $notice['content'] : '', 80)) ?></span>
                            <span><?= e(isset($notice['created_at']) ? $notice['created_at'] : '-') ?></span>
                        </div>
                        <span class="m-badge <?= empty($notice['is_read']) ? 'warn' : 'muted' ?>"><?= empty($notice['is_read']) ? '未读' : '已读' ?></span>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="m-card" id="dashboardRecentFiles">
        <div class="m-section-head">
            <div><span>最近记录</span><h2>最近文件</h2></div>
            <a href="<?= url('m/files') ?>">查看</a>
        </div>
        <div class="m-list">
            <?php foreach ($recentFiles as $file): ?>
                <article class="m-list-item">
                    <i data-lucide="<?= $file['file_type'] === 'image' ? 'image' : 'file' ?>"></i>
                    <div><strong><?= e($file['original_name']) ?></strong><span><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></span></div>
                </article>
            <?php endforeach; ?>
            <?php if (!$recentFiles): ?><div class="m-empty">还没有文件，先上传一个试试。</div><?php endif; ?>
        </div>
    </section>
</section>
