<?php
$logs = isset($logs) && is_array($logs) ? $logs : [];
$servers = isset($servers) && is_array($servers) ? $servers : [];
$filters = isset($filters) && is_array($filters) ? $filters : ['server_id' => 0, 'keyword' => ''];
$stats = isset($stats) && is_array($stats) ? $stats : ['total' => 0, 'today' => 0];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>命令审计</span>
            <h1>命令记录</h1>
            <p>这里只展示你自己的服务器终端记录，不会混入后台本站服务器监控。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers') ?>">服务器</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>累计命令</span><strong><?= e((int) $stats['total']) ?></strong><small>当前账号</small></article>
        <article><span>今日执行</span><strong><?= e((int) $stats['today']) ?></strong><small>在线终端</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="命令记录分区">
        <a href="#commandFilter">筛选</a>
        <a href="#commandLogs">最近记录</a>
        <a href="<?= url('m/servers') ?>">服务器列表</a>
    </nav>

    <section class="m-card" id="commandFilter">
        <div class="m-section-head"><div><span>筛选条件</span><h2>筛选</h2></div></div>
        <form class="m-mini-form" method="get" action="<?= url('m/servers/commands') ?>">
            <select name="server_id">
                <option value="0">全部服务器</option>
                <?php foreach ($servers as $server): ?>
                    <option value="<?= e($server['id']) ?>" <?= (int) $filters['server_id'] === (int) $server['id'] ? 'selected' : '' ?>>
                        <?= e($server['name']) ?> / <?= e(strtoupper($server['monitor_type'])) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索命令、输出、服务器名或 IP">
            <button type="submit">筛选记录</button>
        </form>
    </section>

    <section class="m-card" id="commandLogs">
        <div class="m-section-head"><div><span>执行记录</span><h2>最近记录</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索服务器、命令、输出或风险级别" data-mobile-filter-input="#mobileCommandLogsList">
        </label>
        <div class="m-list" id="mobileCommandLogsList">
            <?php foreach ($logs as $row): ?>
                <?php
                $risk = isset($row['risk_level']) && $row['risk_level'] !== '' ? $row['risk_level'] : 'normal';
                $host = !empty($row['ssh_host']) ? $row['ssh_host'] : (isset($row['server_ip']) ? $row['server_ip'] : '');
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="terminal"></i>
                    <div>
                        <strong><?= e($row['server_name'] ?: ('服务器 #' . $row['server_id'])) ?></strong>
                        <span><?= e(($row['monitor_type'] === 'agent' ? 'Agent' : 'SSH') . ($host ? ' / ' . $host : '')) ?> · <?= e($row['created_at']) ?></span>
                    </div>
                    <span class="m-badge <?= $risk === 'danger' ? 'bad' : ($risk === 'warning' ? 'warn' : 'muted') ?>"><?= e($risk) ?></span>
                    <div class="m-note"><strong>命令</strong><br><?= e(text_limit($row['command'], 220)) ?></div>
                    <?php if (!empty($row['output_summary'])): ?>
                        <div class="m-note"><strong>输出摘要</strong><br><?= e(text_limit($row['output_summary'], 360)) ?></div>
                    <?php endif; ?>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">IP <?= e($row['ip'] ?: '-') ?></span>
                        <span class="m-badge muted">Exit <?= e($row['exit_status'] === null || $row['exit_status'] === '' ? '-' : $row['exit_status']) ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的命令记录。</div>
            <?php if (!$logs): ?><div class="m-empty">暂无命令记录。打开服务器在线终端执行命令后，这里会显示审计记录。</div><?php endif; ?>
        </div>
    </section>
</section>
