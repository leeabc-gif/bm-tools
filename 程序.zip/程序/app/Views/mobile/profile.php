<section class="m-page">
    <header class="m-hero compact">
        <span>账户中心</span>
        <h1><?= e($user['nickname'] ?: $user['username']) ?></h1>
        <p><?= e($user['email']) ?></p>
    </header>
    <section class="m-card">
        <div class="m-action-list">
            <a href="<?= url('m/profile/edit') ?>"><i data-lucide="user-round-cog"></i><span>资料设置</span></a>
            <a href="<?= url('m/password') ?>"><i data-lucide="lock-keyhole"></i><span>修改密码</span></a>
            <a href="<?= url('m/api') ?>"><i data-lucide="key-round"></i><span>API 管理</span></a>
            <a href="<?= url('m/notifications') ?>"><i data-lucide="bell"></i><span>消息通知</span></a>
            <a href="<?= url('logout') ?>"><i data-lucide="log-out"></i><span>退出登录</span></a>
        </div>
    </section>
</section>
