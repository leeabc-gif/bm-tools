<?php
$user = isset($user) && is_array($user) ? $user : [];
$logs = isset($logs) && is_array($logs) ? $logs : [];
$apiApps = isset($apiApps) && is_array($apiApps) ? $apiApps : [];
$apiScopes = isset($apiScopes) && is_array($apiScopes) ? $apiScopes : [];
$apiAppOneTimeToken = isset($apiAppOneTimeToken) && is_array($apiAppOneTimeToken) ? $apiAppOneTimeToken : null;
$apiUsageSummary = isset($apiUsageSummary) && is_array($apiUsageSummary) ? $apiUsageSummary : ['total' => 0, 'success' => 0, 'failed' => 0, 'today' => 0, 'today_failed' => 0, 'success_rate' => 0, 'app_total' => count($apiApps), 'active_apps' => 0, 'last_error' => null];
$apiAppService = isset($apiAppService) ? $apiAppService : null;
$endpoints = isset($endpoints) && is_array($endpoints) ? $endpoints : [];
$sharexConfig = isset($sharexConfig) && is_array($sharexConfig) ? $sharexConfig : [];
$picgoConfig = isset($picgoConfig) && is_array($picgoConfig) ? $picgoConfig : [];
$token = isset($user['api_token']) ? (string) $user['api_token'] : '';
$allowedIps = !empty($user['api_allowed_ips']) ? str_replace(["\r", "\n"], ' / ', (string) $user['api_allowed_ips']) : '未限制';
$sharexJson = json_encode($sharexConfig, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
$picgoJson = json_encode($picgoConfig, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
$scopeChecked = function ($app, $scope) {
    $value = isset($app['scopes']) ? (string) $app['scopes'] : '';
    $items = array_filter(preg_split('/[\s,;]+/', $value));
    return in_array($scope, $items, true);
};
$stat = function ($stats, $key, $default = 0) {
    return isset($stats[$key]) ? $stats[$key] : $default;
};
$appLogLabel = function ($log) use ($apiAppService) {
    return $apiAppService && method_exists($apiAppService, 'appLabelFromLog') ? $apiAppService->appLabelFromLog($log) : (!empty($log['app_id']) ? '#' . $log['app_id'] : '总 Token');
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>接口接入</span>
            <h1>API 管理</h1>
            <p>管理 PicGo、ShareX、脚本上传和业务系统接入。推荐为每个客户端创建单独应用 Token，方便限制权限和排查失败原因。</p>
        </div>
        <a class="m-pill" href="<?= url('m/profile') ?>">账户</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            API 数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复后再使用接口。</span>
        </section>
    <?php elseif (empty($allowed)): ?>
        <section class="m-alert danger">
            当前套餐未开放 API
            <span>升级支持 API 的套餐后，可使用 PicGo、ShareX 和脚本上传。</span>
            <a href="<?= url('m/packages') ?>">查看套餐</a>
        </section>
    <?php endif; ?>

    <nav class="m-anchor-nav m-chip-list" aria-label="API 管理分区">
        <a href="#apiCredentials">参数</a>
        <a href="#apiApps">应用</a>
        <a href="#apiTools">工具</a>
        <a href="#apiLogs">日志</a>
    </nav>

    <section class="m-stat-grid api-mobile-stats">
        <article><span>今日调用</span><strong><?= e(number_format((int) $stat($apiUsageSummary, 'today'))) ?></strong></article>
        <article><span>今日失败</span><strong><?= e(number_format((int) $stat($apiUsageSummary, 'today_failed'))) ?></strong></article>
        <article><span>成功率</span><strong><?= e($stat($apiUsageSummary, 'success_rate')) ?>%</strong></article>
        <article><span>启用应用</span><strong><?= e(number_format((int) $stat($apiUsageSummary, 'active_apps'))) ?></strong></article>
    </section>

    <?php if (!empty($apiUsageSummary['last_error'])): ?>
        <section class="m-alert danger">
            最近 API 失败：HTTP <?= e($apiUsageSummary['last_error']['status_code']) ?>
            <span><?= e(text_limit($apiUsageSummary['last_error']['message'], 80)) ?></span>
        </section>
    <?php endif; ?>

    <?php if ($apiAppOneTimeToken): ?>
        <section class="m-card">
            <div class="m-section-head">
                <div><span>新凭据</span><h2>立即复制 Token</h2></div>
                <button class="m-link-button" type="button" data-copy-text="<?= e($apiAppOneTimeToken['token']) ?>">复制</button>
            </div>
            <div class="m-copy-row"><span><?= e($apiAppOneTimeToken['token']) ?></span><button type="button" data-copy-text="<?= e($apiAppOneTimeToken['token']) ?>">复制</button></div>
            <div class="m-note">明文只展示一次。离开页面后不能再次查看，只能重置。</div>
        </section>
    <?php endif; ?>

    <section class="m-card" id="apiCredentials">
        <div class="m-section-head">
            <div><span>接入参数</span><h2>接入参数</h2></div>
            <form method="post" action="<?= url('m/api/token/reset') ?>" data-mobile-confirm="确认重置总 API Token 吗？旧配置会立即失效。">
                <?= csrf_field() ?>
                <button class="m-button ghost" type="submit">重置总 Token</button>
            </form>
        </div>
        <div class="m-copy-stack">
            <div class="m-copy-row"><span>总 Token：<?= e($token ?: '未生成') ?></span><button type="button" data-copy-text="<?= e($token) ?>">复制</button></div>
            <div class="m-copy-row"><span>上传接口：<?= e(isset($endpoints['upload']) ? $endpoints['upload'] : '') ?></span><button type="button" data-copy-text="<?= e(isset($endpoints['upload']) ? $endpoints['upload'] : '') ?>">复制</button></div>
            <div class="m-copy-row"><span>文件列表：<?= e(isset($endpoints['files']) ? $endpoints['files'] : '') ?></span><button type="button" data-copy-text="<?= e(isset($endpoints['files']) ? $endpoints['files'] : '') ?>">复制</button></div>
            <div class="m-copy-row"><span>删除接口：<?= e(isset($endpoints['delete']) ? $endpoints['delete'] : '') ?></span><button type="button" data-copy-text="<?= e(isset($endpoints['delete']) ? $endpoints['delete'] : '') ?>">复制</button></div>
            <div class="m-copy-row"><span>容量接口：<?= e(isset($endpoints['quota']) ? $endpoints['quota'] : '') ?></span><button type="button" data-copy-text="<?= e(isset($endpoints['quota']) ? $endpoints['quota'] : '') ?>">复制</button></div>
            <div class="m-note">总 Token IP 白名单：<?= e($allowedIps) ?></div>
        </div>
    </section>

    <section class="m-card" id="apiApps">
        <div class="m-section-head"><div><span>应用凭据</span><h2>应用 Token</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('m/api/apps/create') ?>">
            <?= csrf_field() ?>
            <input name="name" maxlength="80" value="<?= e(old('name')) ?>" placeholder="应用名称，例如 PicGo 手机端">
            <textarea name="allowed_ips" rows="3" placeholder="IP 白名单，每行一个，留空不限制"><?= e(old('allowed_ips')) ?></textarea>
            <?php foreach ($apiScopes as $scope => $label): ?>
                <label class="m-checkline"><input type="checkbox" name="scopes[]" value="<?= e($scope) ?>" checked> <?= e($label) ?></label>
            <?php endforeach; ?>
            <button type="submit">创建应用 Token</button>
        </form>
        <div class="m-list">
            <?php foreach ($apiApps as $app): ?>
                <?php
                $stats = isset($app['stats']) && is_array($app['stats']) ? $app['stats'] : [];
                $health = isset($app['health']) && is_array($app['health']) ? $app['health'] : ['tone' => 'idle', 'label' => '未调用', 'hint' => '等待第一次请求。'];
                $lastError = isset($stats['last_error']) && is_array($stats['last_error']) ? $stats['last_error'] : null;
                ?>
                <article class="m-list-item tall">
                    <i data-lucide="<?= !empty($app['status']) ? 'key-round' : 'pause-circle' ?>"></i>
                    <div>
                        <strong><?= e($app['name']) ?></strong>
                        <span><?= !empty($app['status']) ? '启用' : '停用' ?> / <?= e($health['label']) ?> / 最近：<?= e(!empty($app['last_used_at']) ? $app['last_used_at'] : '未使用') ?></span>
                    </div>
                    <div class="m-api-health-row">
                        <span><b><?= e(number_format((int) $stat($stats, 'today'))) ?></b>今日</span>
                        <span><b><?= e(number_format((int) $stat($stats, 'total'))) ?></b>累计</span>
                        <span><b><?= e($stat($stats, 'success_rate')) ?>%</b>成功率</span>
                    </div>
                    <?php if ($lastError): ?>
                        <div class="m-note">最近失败：<?= e($lastError['endpoint']) ?> / HTTP <?= e($lastError['status_code']) ?> / <?= e(text_limit($lastError['message'], 70)) ?></div>
                    <?php else: ?>
                        <div class="m-note"><?= e($health['hint']) ?></div>
                    <?php endif; ?>
                    <form class="m-mini-form" method="post" action="<?= url('m/api/apps/update') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($app['id']) ?>">
                        <input name="name" maxlength="80" value="<?= e($app['name']) ?>">
                        <textarea name="allowed_ips" rows="3" placeholder="IP 白名单"><?= e(isset($app['allowed_ips']) ? $app['allowed_ips'] : '') ?></textarea>
                        <?php foreach ($apiScopes as $scope => $label): ?>
                            <label class="m-checkline"><input type="checkbox" name="scopes[]" value="<?= e($scope) ?>" <?= $scopeChecked($app, $scope) ? 'checked' : '' ?>> <?= e($label) ?></label>
                        <?php endforeach; ?>
                        <label class="m-checkline"><input type="checkbox" name="status" value="1" <?= !empty($app['status']) ? 'checked' : '' ?>> 启用</label>
                        <button type="submit">保存应用</button>
                    </form>
                    <div class="m-inline-actions">
                        <form method="post" action="<?= url('m/api/apps/rotate') ?>" data-mobile-confirm="确认重置这个应用 Token 吗？旧 Token 会立即失效。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($app['id']) ?>">
                            <button class="m-button ghost" type="submit">重置</button>
                        </form>
                        <form method="post" action="<?= url('m/api/apps/delete') ?>" data-mobile-confirm="确认删除这个应用 Token 吗？删除后无法恢复。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($app['id']) ?>">
                            <button class="m-button danger" type="submit">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <?php if (!$apiApps): ?><div class="m-empty">暂无应用 Token。建议给 PicGo、ShareX 和业务系统分别创建。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="apiTools">
        <div class="m-section-head"><div><span>工具配置</span><h2>工具配置</h2></div></div>
        <div class="m-inline-actions">
            <a class="m-button" href="<?= url('api/sharex-config') ?>">下载 ShareX</a>
            <a class="m-button ghost" href="<?= url('api/picgo-config') ?>">下载 PicGo</a>
            <button class="m-button ghost" type="button" data-copy-text="<?= e($sharexJson) ?>">复制 ShareX</button>
            <button class="m-button ghost" type="button" data-copy-text="<?= e($picgoJson) ?>">复制 PicGo</button>
        </div>
        <div class="m-note">上传字段固定为 <code>file</code>，请求头携带 <code>X-API-Token</code>，成功后读取 <code>data.url</code>。</div>
    </section>

    <section class="m-card">
        <div class="m-section-head">
            <div><span>脚本示例</span><h2>脚本示例</h2></div>
            <button class="m-link-button" type="button" data-copy-text="curl -X POST &quot;<?= e(isset($endpoints['upload']) ? $endpoints['upload'] : '') ?>&quot; -H &quot;X-API-Token: <?= e($token) ?>&quot; -F &quot;type=image&quot; -F &quot;file=@demo.jpg&quot;">复制</button>
        </div>
        <pre class="m-code-block">curl -X POST "<?= e(isset($endpoints['upload']) ? $endpoints['upload'] : '') ?>" \
  -H "X-API-Token: <?= e($token) ?>" \
  -F "type=image" \
  -F "file=@demo.jpg"</pre>
    </section>

    <section class="m-card" id="apiLogs">
        <div class="m-section-head"><div><span>调用记录</span><h2>最近调用</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索接口、方法、状态或提示" data-mobile-filter-input="#mobileApiLogsList">
        </label>
        <div class="m-list" id="mobileApiLogsList">
            <?php foreach ($logs as $log): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= !empty($log['is_success']) ? 'check' : 'x' ?>"></i>
                    <div>
                        <strong><?= e(isset($log['endpoint']) ? $log['endpoint'] : '-') ?></strong>
                        <span><?= e($appLogLabel($log)) ?> / <?= e(isset($log['method']) ? $log['method'] : '-') ?> / HTTP <?= e(isset($log['status_code']) ? $log['status_code'] : '-') ?> / <?= e(isset($log['created_at']) ? $log['created_at'] : '-') ?></span>
                    </div>
                    <span class="m-badge <?= !empty($log['is_success']) ? 'ok' : 'bad' ?>"><?= !empty($log['is_success']) ? '成功' : '失败' ?></span>
                    <?php if (!empty($log['message'])): ?><div class="m-note"><?= e($log['message']) ?></div><?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的 API 日志。</div>
            <?php if (!$logs): ?><div class="m-empty">暂无 API 调用记录。完成一次上传、列表或删除请求后会显示在这里。</div><?php endif; ?>
        </div>
    </section>
</section>
