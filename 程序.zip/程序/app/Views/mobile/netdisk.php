<?php
$folderId = isset($folderId) ? (int) $folderId : 0;
$parentFolderId = isset($parentFolderId) ? (int) $parentFolderId : 0;
$currentFolder = isset($currentFolder) ? $currentFolder : null;
$folderBackUrl = $folderId > 0 ? url('m/netdisk?folder_id=' . $parentFolderId) : url('m');
$uploadLimits = isset($uploadLimits) && is_array($uploadLimits) ? $uploadLimits : ['batch' => 10, 'daily' => 0, 'used_today' => 0, 'remaining_today' => null, 'concurrency' => 2];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>个人网盘</span>
            <h1><?= $currentFolder ? e($currentFolder['name']) : '个人网盘' ?></h1>
            <p><?= $currentFolder ? '当前文件夹内容，可上传、创建子文件夹和整理文件。' : '手机端独立网盘工作区，上传、目录和文件管理都在这里完成。' ?></p>
        </div>
        <a class="m-pill" href="<?= e($folderBackUrl) ?>"><?= $folderId > 0 ? '返回' : '首页' ?></a>
    </header>

    <nav class="m-anchor-nav m-chip-list" aria-label="网盘页面分区">
        <a href="#netdiskUpload">上传文件</a>
        <a href="#netdiskFolderCreate">新建文件夹</a>
        <a href="#netdiskFolders">文件夹</a>
        <a href="#netdiskFiles">当前文件</a>
    </nav>

    <section class="m-card" id="netdiskUpload">
        <form class="m-upload" method="post" action="<?= e($uploadAction) ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="ajax_upload" value="1">
            <input type="hidden" name="folder_id" value="<?= e($folderId) ?>">
            <label>
                <i data-lucide="folder-up"></i>
                <span>选择文件上传</span>
                <input type="file" name="files[]" multiple>
            </label>
            <div class="m-upload-hint">
                支持多选文件，单次最多 <?= e((int) $uploadLimits['batch']) ?> 个，并发 <?= e((int) $uploadLimits['concurrency']) ?> 个。
                <?php if ((int) $uploadLimits['daily'] > 0): ?>今日已上传 <?= e((int) $uploadLimits['used_today']) ?> 个，剩余 <?= e((int) $uploadLimits['remaining_today']) ?> 个。<?php else: ?>今日数量不限。<?php endif; ?>
                <?php if ((int) $uploadLimits['single_file_limit'] > 0): ?>单文件不超过 <?= e(format_bytes((int) $uploadLimits['single_file_limit'])) ?>。<?php endif; ?>
                <?php if ($uploadLimits['storage_remaining'] !== null): ?>剩余空间 <?= e(format_bytes((int) $uploadLimits['storage_remaining'])) ?>。<?php endif; ?>
            </div>
            <button type="submit">上传到当前目录</button>
        </form>
    </section>

    <section class="m-stat-grid two">
        <article><span>文件数量</span><strong><?= e(isset($usage['count']) ? $usage['count'] : 0) ?></strong><small>当前账号全部文件</small></article>
        <article><span>空间占用</span><strong><?= e(format_bytes(isset($usage['size']) ? $usage['size'] : 0)) ?></strong><small>图床与网盘合计</small></article>
    </section>

    <section class="m-card" id="netdiskFolderCreate">
        <div class="m-section-head">
            <div><span>新建目录</span><h2>新建文件夹</h2></div>
        </div>
        <form class="m-mini-form" method="post" action="<?= url('m/netdisk/folder') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="parent_id" value="<?= e($folderId) ?>">
            <input name="name" maxlength="120" placeholder="文件夹名称，例如：项目资料">
            <button type="submit">创建文件夹</button>
        </form>
    </section>

    <section class="m-card" id="netdiskFolders">
        <div class="m-section-head"><div><span>目录列表</span><h2>文件夹</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索文件夹名称或时间" data-mobile-filter-input="#mobileFoldersList">
        </label>
        <div class="m-list" id="mobileFoldersList">
            <?php foreach ($folders as $folder): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="folder"></i>
                    <div>
                        <strong><?= e($folder['name']) ?></strong>
                        <span><?= e(isset($folder['created_at']) ? $folder['created_at'] : '') ?></span>
                    </div>
                    <a href="<?= url('m/netdisk?folder_id=' . (int) $folder['id']) ?>">进入</a>
                    <div class="m-inline-actions">
                        <form method="post" action="<?= url('m/netdisk/folder/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($folder['id']) ?>">
                            <button class="m-button ghost" type="submit" data-mobile-confirm="确认删除这个文件夹吗？文件会移入回收站。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的文件夹。</div>
            <?php if (!$folders): ?><div class="m-empty">当前目录还没有文件夹。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="netdiskFiles">
        <div class="m-section-head">
            <div><span>文件列表</span><h2>当前目录文件</h2></div>
            <?php if ($files): ?>
                <button class="m-link-button" type="button" data-copy-text="<?= e(implode("\n", array_map(function ($file) { return public_url(isset($file['file_url']) ? $file['file_url'] : ''); }, $files))) ?>">复制全部</button>
            <?php endif; ?>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索文件名、格式、大小或时间" data-mobile-filter-input="#mobileNetdiskFilesList">
        </label>
        <div class="m-list" id="mobileNetdiskFilesList">
            <?php foreach ($files as $file): ?>
                <?php
                $fileType = isset($file['file_type']) ? $file['file_type'] : 'file';
                $fileUrl = public_url(isset($file['file_url']) ? $file['file_url'] : '');
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= $fileType === 'image' ? 'image' : 'file' ?>"></i>
                    <div>
                        <strong><?= e($file['original_name']) ?></strong>
                        <span><?= e(format_bytes(isset($file['file_size']) ? $file['file_size'] : 0)) ?> · <?= e(isset($file['created_at']) ? $file['created_at'] : '') ?></span>
                    </div>
                    <a href="<?= e($fileUrl) ?>" target="_blank">打开</a>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e(strtoupper(isset($file['file_ext']) ? $file['file_ext'] : 'FILE')) ?></span>
                        <?php if (!empty($file['download_count'])): ?><span class="m-badge muted">下载 <?= e((int) $file['download_count']) ?></span><?php endif; ?>
                    </div>
                    <div class="m-inline-actions">
                        <button class="m-button ghost" type="button" data-copy-text="<?= e($fileUrl) ?>">复制链接</button>
                        <a class="m-button ghost" href="<?= url('netdisk/download?id=' . (int) $file['id']) ?>">下载</a>
                        <form method="post" action="<?= url('m/netdisk/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                            <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个文件吗？删除后会进入回收站。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的文件。</div>
            <?php if (!$files): ?><div class="m-empty">当前目录暂无文件，先上传一个试试。</div><?php endif; ?>
        </div>
    </section>
</section>
