<?php
$service = isset($service) ? $service : new \App\Services\SubsiteService();
$target = isset($domainConfig['cname_target']) ? $domainConfig['cname_target'] : '';
$suffixes = isset($suffixes) ? $suffixes : $service->suffixes();
$defaultSuffix = isset($defaultSuffix) ? $defaultSuffix : $service->defaultSuffix();
$packageInfo = isset($packageInfo) ? $packageInfo : ['allow' => false, 'limit' => 0, 'name' => '当前套餐'];
$usedCount = isset($usedCount) ? (int) $usedCount : count($subsites);
$limitCount = isset($limitCount) ? (int) $limitCount : 0;
$canCreate = !empty($canCreate);
$customDomainEnabled = !empty($customDomainEnabled);
$domainDiagnostic = flash('subsite_domain_diagnostic', null);
$statusTone = function ($status) {
    if ($status === 'active') return 'ok';
    if ($status === 'pending') return 'warn';
    if ($status === 'suspended' || $status === 'rejected') return 'bad';
    return 'muted';
};
$field = function ($key, $default = '') {
    return old($key, $default);
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>分站管理</span>
            <h1>我的分站</h1>
            <p>创建独立资源站，绑定平台域名或自己的域名，手机端可直接检测接入状态。</p>
        </div>
        <a class="m-pill" href="<?= url('m/menu') ?>">功能</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>已开通</span><strong><?= e($usedCount) ?></strong><small><?= $limitCount > 0 ? '上限 ' . e($limitCount) . ' 个' : '不限数量' ?></small></article>
        <article><span>接入目标</span><strong><?= e($target ?: '-') ?></strong><small>CNAME 指向</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="分站分区">
        <a href="#subsiteCreate">创建分站</a>
        <a href="#subsiteList">分站列表</a>
        <a href="<?= url('m/packages') ?>">套餐权益</a>
    </nav>

    <?php if ($domainDiagnostic): ?>
        <section class="m-card">
            <div class="m-section-head">
                <div>
                    <span>域名检测</span>
                    <h2>检测结果</h2>
                </div>
                <?php if (!empty($domainDiagnostic['public_url'])): ?><a href="<?= e($domainDiagnostic['public_url']) ?>" target="_blank">打开</a><?php endif; ?>
            </div>
            <div class="m-status-row">
                <?php foreach ((array) (isset($domainDiagnostic['checks']) ? $domainDiagnostic['checks'] : []) as $check): ?>
                    <article class="m-check-card <?= e(isset($check['status']) ? $check['status'] : 'soft') ?>">
                        <b><?= e(isset($check['label']) ? $check['label'] : '检测项') ?></b>
                        <span><?= e(isset($check['message']) ? $check['message'] : '') ?></span>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="m-card" id="subsiteCreate">
        <div class="m-section-head">
            <div><span>新建分站</span><h2>创建分站</h2></div>
        </div>
        <?php if (!$service->enabled()): ?>
            <div class="m-empty">主站暂未开放分站功能。</div>
        <?php elseif (empty($packageInfo['allow'])): ?>
            <div class="m-empty">当前套餐未包含分站权益，可以先升级套餐。</div>
            <a class="m-button" href="<?= url('m/packages') ?>">查看套餐</a>
        <?php elseif (!$canCreate): ?>
            <div class="m-empty">分站额度已用完，当前为 <?= e(isset($packageInfo['name']) ? $packageInfo['name'] : '当前套餐') ?>。</div>
        <?php else: ?>
            <form class="m-mini-form" method="post" action="<?= url('m/subsites/save') ?>">
                <?= csrf_field() ?>
                <input name="name" value="<?= e($field('name')) ?>" maxlength="80" required placeholder="分站名称，例如：我的资源站">
                <input name="slug" value="<?= e($field('slug')) ?>" maxlength="40" required placeholder="分站标识，例如：my-space">
                <?php if (count($suffixes) > 1): ?>
                    <select name="platform_suffix">
                        <?php foreach ($suffixes as $suffix): ?>
                            <option value="<?= e($suffix) ?>" <?= $field('platform_suffix', $defaultSuffix) === $suffix ? 'selected' : '' ?>><?= e($suffix) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input readonly value="<?= e($defaultSuffix ?: '请管理员配置域名后缀') ?>">
                    <input type="hidden" name="platform_suffix" value="<?= e($defaultSuffix) ?>">
                <?php endif; ?>
                <input name="title" value="<?= e($field('title')) ?>" maxlength="120" placeholder="站点标题，可留空">
                <input name="subtitle" value="<?= e($field('subtitle')) ?>" maxlength="240" placeholder="一句话介绍这个分站">
                <?php if ($customDomainEnabled): ?>
                    <input name="custom_domain" value="<?= e($field('custom_domain')) ?>" maxlength="180" placeholder="自有域名，可选：site.example.com">
                <?php endif; ?>
                <button type="submit">创建分站</button>
            </form>
        <?php endif; ?>
        <div class="m-note">自有域名建议 CNAME 到 <?= e($target ?: '平台域名') ?>；检测结果会明确提示 DNS、TXT、访问链路哪一步没有通过。</div>
    </section>

    <section class="m-card" id="subsiteList">
        <div class="m-section-head"><div><span>分站列表</span><h2>分站列表</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索分站名、域名、状态或标题" data-mobile-filter-input="#mobileSubsitesList">
        </label>
        <div class="m-list" id="mobileSubsitesList">
            <?php foreach ($subsites as $site): ?>
                <?php
                $publicUrl = $service->publicUrlFor($site);
                $suffix = $service->suffixFromPlatformDomain(isset($site['platform_domain']) ? $site['platform_domain'] : '');
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="globe-2"></i>
                    <div>
                        <strong><?= e($site['name']) ?><?= !empty($site['is_default']) ? ' · 默认' : '' ?></strong>
                        <span><?= e($site['platform_domain']) ?><?= !empty($site['custom_domain']) ? ' · ' . e($site['custom_domain']) : '' ?></span>
                    </div>
                    <a href="<?= e($publicUrl) ?>" target="_blank">访问</a>

                    <div class="m-meta-grid">
                        <span class="m-badge <?= e($statusTone(isset($site['status']) ? $site['status'] : '')) ?>"><?= e($service->statusLabel(isset($site['status']) ? $site['status'] : '')) ?></span>
                        <span class="m-badge muted"><?= e((int) (isset($site['view_count']) ? $site['view_count'] : 0)) ?> 次访问</span>
                        <?php if (!empty($site['custom_domain'])): ?><span class="m-badge muted"><?= e($service->domainStatusLabel($site['custom_domain_status'])) ?></span><?php endif; ?>
                    </div>

                    <div class="m-inline-actions">
                        <details class="m-fold">
                            <summary>编辑分站</summary>
                            <form class="m-mini-form" method="post" action="<?= url('m/subsites/save') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <input type="hidden" name="slug" value="<?= e($site['slug']) ?>">
                                <input type="hidden" name="platform_suffix" value="<?= e($suffix) ?>">
                                <input name="name" value="<?= e($site['name']) ?>" maxlength="80" required placeholder="分站名称">
                                <input name="title" value="<?= e(isset($site['title']) ? $site['title'] : '') ?>" maxlength="120" placeholder="站点标题">
                                <input name="subtitle" value="<?= e(isset($site['subtitle']) ? $site['subtitle'] : '') ?>" maxlength="240" placeholder="副标题">
                                <?php if ($customDomainEnabled): ?>
                                    <input name="custom_domain" value="<?= e(isset($site['custom_domain']) ? $site['custom_domain'] : '') ?>" maxlength="180" placeholder="自有域名">
                                <?php endif; ?>
                                <button class="ghost" type="submit">保存基础信息</button>
                            </form>
                        </details>
                        <form method="post" action="<?= url('m/subsites/check') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                            <button class="m-button ghost" type="submit">检测域名</button>
                        </form>
                        <form method="post" action="<?= url('m/subsites/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个分站吗？访问记录也会删除。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的分站。</div>
            <?php if (!$subsites): ?><div class="m-empty">暂无分站，创建后可展示公开图片和分享仓库。</div><?php endif; ?>
        </div>
    </section>
</section>
