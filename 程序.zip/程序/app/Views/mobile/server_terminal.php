<?php
$server = isset($server) && is_array($server) ? $server : [];
$commands = isset($commands) && is_array($commands) ? $commands : [];
$terminalEnabled = !empty($terminalEnabled);
$commandTimeout = isset($commandTimeout) ? (int) $commandTimeout : 30;
$serverId = (int) (isset($server['id']) ? $server['id'] : 0);
$serverName = isset($server['name']) && $server['name'] !== '' ? $server['name'] : '未命名服务器';
$sshHost = isset($server['ssh_host']) && $server['ssh_host'] !== '' ? $server['ssh_host'] : (isset($server['server_ip']) ? $server['server_ip'] : '-');
$sshUser = isset($server['ssh_username']) && $server['ssh_username'] !== '' ? $server['ssh_username'] : '-';
$sshPort = isset($server['ssh_port']) && $server['ssh_port'] ? (int) $server['ssh_port'] : 22;
$quickCommands = [
    ['label' => '系统概览', 'command' => "uname -a\nuptime\nfree -h\ndf -h"],
    ['label' => '磁盘', 'command' => "df -h\ndu -sh /* 2>/dev/null | sort -h"],
    ['label' => '进程', 'command' => "ps aux --sort=-%mem | head -20\nps aux --sort=-%cpu | head -20"],
    ['label' => '端口', 'command' => "ss -tulpen || netstat -tulpen"],
    ['label' => '失败服务', 'command' => "systemctl --failed"],
    ['label' => 'Docker', 'command' => "docker ps -a\ndocker stats --no-stream"],
];
$terminalSnippet = function ($command) {
    return str_replace(["\r\n", "\r", "\n"], '&#10;', e((string) $command));
};
?>
<section class="m-page m-terminal-tool-page">
    <header class="m-page-head m-terminal-head">
        <div>
            <span>Server terminal</span>
            <h1>服务器终端工具</h1>
            <p><?= e($sshUser) ?>@<?= e($sshHost) ?>:<?= e($sshPort) ?>，单次命令超时 <?= e($commandTimeout) ?> 秒。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers/' . $serverId) ?>">详情</a>
    </header>

    <?php if (!$terminalEnabled): ?>
        <section class="m-alert danger"><strong>在线终端已关闭</strong><span>管理员当前未开启 Web SSH 功能。</span></section>
    <?php endif; ?>

    <section class="m-terminal-summary">
        <article>
            <span>服务器</span>
            <strong><?= e($serverName) ?></strong>
        </article>
        <article>
            <span>模式</span>
            <strong>SSH 命令</strong>
        </article>
        <article>
            <span>审计</span>
            <strong><?= count($commands) ?> 条</strong>
        </article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="终端页面分区">
        <a href="#terminalConsole">终端</a>
        <a href="#terminalQuick">快捷命令</a>
        <a href="#terminalAudit">最近审计</a>
        <a href="<?= url('m/servers/' . $serverId . '/probes') ?>">站点探针</a>
    </nav>

    <section class="m-card m-terminal-console" id="terminalConsole">
        <div class="m-section-head">
            <div><span>Console</span><h2><?= e($serverName) ?></h2></div>
            <div class="m-terminal-actions">
                <button class="m-link-button" type="button" data-copy-output="#mTerminalOutput">复制输出</button>
                <button class="m-link-button" type="button" data-mobile-terminal-clear>清空</button>
            </div>
        </div>
        <pre class="m-code-block m-terminal-output" id="mTerminalOutput">BM ucloud tools mobile terminal
server: <?= e($sshHost) ?>
user: <?= e($sshUser) ?>
mode: ssh command

输入命令后点击执行。</pre>
        <form class="m-mini-form m-terminal-form" method="post" action="<?= url('m/servers/terminal/command') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($serverId) ?>">
            <textarea name="command" rows="5" spellcheck="false" autocomplete="off" placeholder="输入任意 SSH 命令，支持多行脚本" <?= $terminalEnabled ? '' : 'disabled' ?>></textarea>
            <button type="submit" <?= $terminalEnabled ? '' : 'disabled' ?>>执行命令</button>
            <div class="m-note" data-terminal-state>命令不做内容拦截，执行记录会写入审计。</div>
        </form>
    </section>

    <section class="m-card m-terminal-quick" id="terminalQuick">
        <div class="m-section-head"><div><span>Shortcuts</span><h2>快捷巡检</h2></div></div>
        <div class="m-chip-list">
            <?php foreach ($quickCommands as $item): ?>
                <button class="m-chip-button" type="button" data-terminal-snippet="<?= $terminalSnippet($item['command']) ?>"><?= e($item['label']) ?></button>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="m-card" id="terminalAudit">
        <div class="m-section-head">
            <div><span>Audit</span><h2>最近命令</h2></div>
            <a href="<?= url('m/servers/commands?server_id=' . $serverId) ?>">全部</a>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索命令、输出或时间" data-mobile-filter-input="#mobileTerminalCommandList">
            <span data-mobile-filter-count>0</span>
        </label>
        <div class="m-list" id="mobileTerminalCommandList">
            <?php foreach ($commands as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="terminal"></i>
                    <div>
                        <button class="m-command-fill" type="button" data-terminal-snippet="<?= e(isset($row['command']) ? $row['command'] : '') ?>">
                            <strong><?= e(text_limit(isset($row['command']) ? $row['command'] : '', 140)) ?></strong>
                        </button>
                        <span><?= e(isset($row['created_at']) ? $row['created_at'] : '') ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的命令记录。</div>
            <?php if (!$commands): ?><div class="m-empty">暂无命令记录。</div><?php endif; ?>
        </div>
    </section>
</section>
