<?php
$server = isset($server) && is_array($server) ? $server : [];
$page = isset($page) && is_array($page) ? $page : null;
$shareUrl = $page ? public_url('s/' . $page['token']) : '';
$visibility = $page ? $page['visibility'] : 'private';
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>状态分享</span>
            <h1>监控分享页</h1>
            <p>为 <?= e(isset($server['name']) ? $server['name'] : '服务器') ?> 创建只读状态页，访客不能执行命令。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers/' . (int) $server['id']) ?>">详情</a>
    </header>

    <?php if ($page && $visibility !== 'private'): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>公开链接</span><h2>分享链接</h2></div></div>
            <div class="m-copy-row"><span><?= e($shareUrl) ?></span><button type="button" data-copy-text="<?= e($shareUrl) ?>">复制</button></div>
            <a class="m-button ghost" href="<?= e($shareUrl) ?>" target="_blank" rel="noopener">打开页面</a>
        </section>
    <?php endif; ?>

    <section class="m-card">
        <div class="m-section-head"><div><span>页面设置</span><h2>页面配置</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('m/servers/share/save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="server_id" value="<?= e($server['id']) ?>">
            <input name="title" value="<?= e($page ? $page['title'] : ((isset($server['name']) ? $server['name'] : '服务器') . ' 状态页')) ?>" placeholder="页面标题">
            <select name="visibility">
                <option value="private" <?= $visibility === 'private' ? 'selected' : '' ?>>关闭分享</option>
                <option value="public" <?= $visibility === 'public' ? 'selected' : '' ?>>公开只读</option>
                <option value="password" <?= $visibility === 'password' ? 'selected' : '' ?>>密码访问</option>
            </select>
            <input type="password" name="password" placeholder="<?= $page && !empty($page['password_hash']) ? '已设置，留空不修改' : '密码访问时必填' ?>">
            <input type="datetime-local" name="expires_at" value="<?= $page && !empty($page['expires_at']) ? e(date('Y-m-d\TH:i', strtotime($page['expires_at']))) : '' ?>">
            <label class="m-checkline"><input type="checkbox" name="show_metrics" <?= !$page || !empty($page['show_metrics']) ? 'checked' : '' ?>>展示资源指标</label>
            <label class="m-checkline"><input type="checkbox" name="show_services" <?= !$page || !empty($page['show_services']) ? 'checked' : '' ?>>展示服务状态</label>
            <button type="submit">保存配置</button>
        </form>
    </section>
</section>
