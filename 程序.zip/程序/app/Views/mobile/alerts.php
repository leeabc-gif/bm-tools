<?php
$alerts = isset($alerts) && is_array($alerts) ? $alerts : [];
$servers = isset($servers) && is_array($servers) ? $servers : [];
$stats = isset($stats) && is_array($stats) ? $stats : ['total' => 0, 'unread' => 0, 'read' => 0, 'resolved' => 0];
$filters = isset($filters) && is_array($filters) ? $filters : ['status' => '', 'level' => '', 'server_id' => 0];
$levelLabel = function ($level) {
    if (function_exists('alert_level_label')) return alert_level_label($level);
    return ['info' => '信息', 'warning' => '警告', 'danger' => '严重'][$level] ?? $level;
};
$statusLabel = function ($status) {
    if (function_exists('alert_status_label')) return alert_status_label($status);
    return ['unread' => '未读', 'read' => '已读', 'resolved' => '已处理'][$status] ?? $status;
};
$levelTone = function ($level) {
    if ($level === 'danger') return 'bad';
    if ($level === 'warning') return 'warn';
    return 'muted';
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>告警中心</span>
            <h1>监控告警</h1>
            <p>这里只展示你自己添加的 SSH / Agent 服务器告警，不会混入后台运营服务器。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers') ?>">服务器</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            告警数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复。</span>
        </section>
    <?php endif; ?>

    <section class="m-stat-grid two">
        <article><span>全部告警</span><strong><?= e((int) $stats['total']) ?></strong><small>当前账号</small></article>
        <article><span>未读</span><strong><?= e((int) $stats['unread']) ?></strong><small>优先处理</small></article>
        <article><span>已读</span><strong><?= e((int) $stats['read']) ?></strong><small>已查看</small></article>
        <article><span>已处理</span><strong><?= e((int) $stats['resolved']) ?></strong><small>已关闭</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="告警页面分区">
        <a href="#alertFilter">筛选</a>
        <a href="#alertRecords">告警记录</a>
        <a href="<?= url('m/servers') ?>">服务器</a>
    </nav>

    <section class="m-card" id="alertFilter">
        <div class="m-section-head"><div><span>筛选条件</span><h2>筛选</h2></div></div>
        <form class="m-mini-form" method="get" action="<?= url('m/alerts') ?>">
            <select name="status">
                <option value="">全部状态</option>
                <option value="unread" <?= $filters['status'] === 'unread' ? 'selected' : '' ?>>未读</option>
                <option value="read" <?= $filters['status'] === 'read' ? 'selected' : '' ?>>已读</option>
                <option value="resolved" <?= $filters['status'] === 'resolved' ? 'selected' : '' ?>>已处理</option>
            </select>
            <select name="level">
                <option value="">全部级别</option>
                <option value="info" <?= $filters['level'] === 'info' ? 'selected' : '' ?>>信息</option>
                <option value="warning" <?= $filters['level'] === 'warning' ? 'selected' : '' ?>>警告</option>
                <option value="danger" <?= $filters['level'] === 'danger' ? 'selected' : '' ?>>严重</option>
            </select>
            <select name="server_id">
                <option value="0">全部服务器</option>
                <?php foreach ($servers as $server): ?>
                    <option value="<?= e($server['id']) ?>" <?= (int) $filters['server_id'] === (int) $server['id'] ? 'selected' : '' ?>>
                        <?= e($server['name']) ?> / <?= e(strtoupper($server['monitor_type'])) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">筛选告警</button>
        </form>
    </section>

    <section class="m-card" id="alertRecords">
        <div class="m-section-head"><div><span>告警记录</span><h2>告警记录</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索告警标题、服务器、指标或状态" data-mobile-filter-input="#mobileAlertsList">
        </label>
        <div class="m-list" id="mobileAlertsList">
            <?php foreach ($alerts as $alert): ?>
                <?php
                $level = isset($alert['level']) ? $alert['level'] : 'info';
                $status = isset($alert['status']) ? $alert['status'] : 'unread';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="bell-ring"></i>
                    <div>
                        <strong><?= e(isset($alert['title']) ? $alert['title'] : '告警') ?></strong>
                        <span><?= e(isset($alert['server_name']) ? $alert['server_name'] : '-') ?> / <?= e(isset($alert['metric']) ? $alert['metric'] : '-') ?> / <?= e(isset($alert['created_at']) ? $alert['created_at'] : '-') ?></span>
                    </div>
                    <span class="m-badge <?= e($levelTone($level)) ?>"><?= e($levelLabel($level)) ?></span>
                    <div class="m-note"><?= e(isset($alert['content']) ? $alert['content'] : '') ?></div>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e($statusLabel($status)) ?></span>
                        <span class="m-badge muted"><?= e(strtoupper(isset($alert['monitor_type']) ? $alert['monitor_type'] : '')) ?></span>
                    </div>
                    <div class="m-inline-actions">
                        <?php if ($status === 'unread'): ?>
                            <form method="post" action="<?= url('m/alerts/read') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($alert['id']) ?>">
                                <button class="m-button ghost" type="submit">标记已读</button>
                            </form>
                        <?php endif; ?>
                        <?php if ($status !== 'resolved'): ?>
                            <form method="post" action="<?= url('m/alerts/resolve') ?>" data-mobile-confirm="确认将这条告警标记为已处理吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($alert['id']) ?>">
                                <button class="m-button" type="submit">标记处理</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的告警。</div>
            <?php if (!$alerts): ?><div class="m-empty">当前筛选条件下暂无告警。服务器采集正常时，这里会保持干净。</div><?php endif; ?>
        </div>
    </section>
</section>
