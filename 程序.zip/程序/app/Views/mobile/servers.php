<?php
$stats = isset($stats) ? $stats : ['total' => count($servers), 'online' => 0, 'offline' => 0, 'stale' => 0, 'checks' => 0, 'down_checks' => 0];
$fmt = function ($bytes) {
    return function_exists('format_bytes') ? format_bytes((float) $bytes) : number_format((float) $bytes / 1048576, 1) . ' MB';
};
$serverHost = function (array $server) {
    if (!empty($server['ssh_host'])) return $server['ssh_host'];
    if (!empty($server['server_ip'])) return $server['server_ip'];
    if (!empty($server['agent_url'])) return $server['agent_url'];
    if (!empty($server['panel_url'])) return $server['panel_url'];
    return '未配置主机';
};
$statusTone = function ($status) {
    if ($status === 'online') return 'ok';
    if ($status === 'offline') return 'bad';
    return 'muted';
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>服务器管家</span>
            <h1>服务器管家</h1>
            <p>这里展示用户自己的服务器，和后台本站服务器监控完全隔离。手机端可立即采集、打开终端或分享状态页。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers/create') ?>">添加</a>
    </header>

    <section class="m-stat-grid three">
        <article><span>服务器</span><strong><?= e($stats['total']) ?></strong><small>SSH / Agent</small></article>
        <article><span>在线</span><strong><?= e($stats['online']) ?></strong><small>最近正常</small></article>
        <article><span>异常</span><strong><?= e($stats['offline']) ?></strong><small>需排查</small></article>
    </section>
    <section class="m-stat-grid two">
        <article><span>探针</span><strong><?= e($stats['checks']) ?></strong><small>异常 <?= e($stats['down_checks']) ?> 个</small></article>
        <article><span>今日命令</span><strong><?= e($commandsToday) ?></strong><small>终端审计</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="服务器管家分区">
        <a href="#serverList">服务器列表</a>
        <a href="<?= url('m/servers/create') ?>">添加服务器</a>
        <a href="<?= url('m/servers/commands') ?>">命令记录</a>
        <a href="<?= url('m/alerts') ?>">监控告警</a>
    </nav>

    <section class="m-card" id="serverList">
        <div class="m-section-head">
            <div><span>服务器列表</span><h2>服务器列表</h2></div>
            <a href="<?= url('m/servers/commands') ?>">命令记录</a>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索服务器、主机、状态或接入方式" data-mobile-filter-input="#mobileServersList">
        </label>
        <div class="m-list" id="mobileServersList">
            <?php foreach ($servers as $server): ?>
                <?php
                $type = isset($server['monitor_type']) ? $server['monitor_type'] : 'ssh';
                $status = isset($server['status']) && $server['status'] !== '' ? $server['status'] : 'unknown';
                $host = $serverHost($server);
                $metric = isset($server['latest']) ? $server['latest'] : null;
                $cpu = $metric ? (float) (isset($metric['cpu_usage']) ? $metric['cpu_usage'] : 0) : 0;
                $memory = $metric ? (float) (isset($metric['memory_usage']) ? $metric['memory_usage'] : 0) : 0;
                $disk = $metric ? (float) (isset($metric['disk_usage']) ? $metric['disk_usage'] : 0) : 0;
                $probeStats = isset($server['probe_stats']) ? $server['probe_stats'] : ['total' => 0, 'down' => 0];
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= $type === 'agent' ? 'satellite-dish' : 'server-cog' ?>"></i>
                    <div>
                        <strong><?= e($server['name']) ?></strong>
                        <span><?= e(strtoupper($type)) ?> · <?= e($host) ?> · <?= e(isset($server['last_checked_at']) && $server['last_checked_at'] ? $server['last_checked_at'] : '未采集') ?></span>
                    </div>
                    <span class="m-badge <?= e($statusTone($status)) ?>"><?= e(status_label($status)) ?></span>

                    <?php if ($metric): ?>
                        <div class="m-meter-grid">
                            <span><b>CPU</b><em><?= e($cpu) ?>%</em><i><u style="width: <?= e(max(0, min(100, $cpu))) ?>%"></u></i></span>
                            <span><b>内存</b><em><?= e($memory) ?>%</em><i><u style="width: <?= e(max(0, min(100, $memory))) ?>%"></u></i></span>
                            <span><b>磁盘</b><em><?= e($disk) ?>%</em><i><u style="width: <?= e(max(0, min(100, $disk))) ?>%"></u></i></span>
                        </div>
                        <div class="m-meta-grid">
                            <span class="m-badge muted">内存 <?= e($fmt(isset($metric['memory_used']) ? $metric['memory_used'] : 0)) ?></span>
                            <span class="m-badge muted">磁盘 <?= e($fmt(isset($metric['disk_used']) ? $metric['disk_used'] : 0)) ?></span>
                            <span class="m-badge muted">负载 <?= e(isset($metric['load_avg']) && $metric['load_avg'] !== '' ? $metric['load_avg'] : '-') ?></span>
                        </div>
                    <?php else: ?>
                        <div class="m-empty">还没有采集数据，点击“立即采集”刷新状态。</div>
                    <?php endif; ?>

                    <?php if (!empty($server['is_stale'])): ?>
                        <div class="m-note">监控数据已过期，建议检查计划任务或立即采集。</div>
                    <?php endif; ?>
                    <?php if (!empty($server['last_error'])): ?>
                        <div class="m-note">最近错误：<?= e($server['last_error']) ?></div>
                    <?php endif; ?>

                    <div class="m-meta-grid">
                        <span class="m-badge muted">探针 <?= e(isset($probeStats['total']) ? $probeStats['total'] : 0) ?> 个</span>
                        <span class="m-badge <?= !empty($probeStats['down']) ? 'bad' : 'ok' ?>">异常 <?= e(isset($probeStats['down']) ? $probeStats['down'] : 0) ?> 个</span>
                        <span class="m-badge muted"><?= !empty($server['is_enabled']) ? '监控开启' : '监控关闭' ?></span>
                    </div>

                    <div class="m-inline-actions">
                        <?php if ($type === 'ssh'): ?><a class="m-button" href="<?= url('m/servers/' . (int) $server['id'] . '/terminal') ?>">在线终端</a><?php endif; ?>
                        <form method="post" action="<?= url('m/servers/collect') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                            <button class="m-button ghost" type="submit">立即采集</button>
                        </form>
                        <a class="m-button ghost" href="<?= url('m/servers/' . (int) $server['id']) ?>">详情</a>
                        <a class="m-button ghost" href="<?= url('m/servers/' . (int) $server['id'] . '/share') ?>">分享页</a>
                        <a class="m-button ghost" href="<?= url('m/servers/' . (int) $server['id'] . '/probes') ?>">探针</a>
                        <a class="m-button ghost" href="<?= url('m/servers/create?id=' . (int) $server['id']) ?>">编辑</a>
                        <form method="post" action="<?= url('m/servers/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这台服务器及相关监控、终端记录吗？">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的服务器。</div>
            <?php if (!$servers): ?>
                <div class="m-empty">暂无服务器。添加后可以在线终端、状态采集、探针检测和生成公开监控页。</div>
            <?php endif; ?>
        </div>
    </section>
</section>
