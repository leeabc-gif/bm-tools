<?php
$orders = isset($orders) && is_array($orders) ? $orders : [];
$recharges = isset($recharges) && is_array($recharges) ? $recharges : [];
$user = isset($user) && is_array($user) ? $user : [];
$typeNames = ['recharge' => '账户充值', 'package' => '套餐购买'];
$methodNames = ['manual' => '人工处理', 'alipay' => '支付宝', 'balance' => '余额', 'card_code' => '卡密'];
$statusNames = ['pending' => '待处理', 'paid' => '已完成', 'closed' => '已关闭', 'refunded' => '已退款'];
$statusTone = function ($status) {
    if ($status === 'paid') return 'ok';
    if ($status === 'pending') return 'warn';
    if ($status === 'closed' || $status === 'refunded') return 'muted';
    return 'bad';
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>账户订单</span>
            <h1>订单与余额</h1>
            <p>当前余额：¥<?= e(number_format((float) (isset($user['balance']) ? $user['balance'] : 0), 2)) ?></p>
        </div>
        <a class="m-pill" href="<?= url('m/balance') ?>">流水</a>
    </header>

    <section class="m-action-grid">
        <a href="<?= url('m/recharge') ?>"><i data-lucide="wallet-cards"></i><span>账户充值</span></a>
        <a href="<?= url('m/balance') ?>"><i data-lucide="coins"></i><span>余额流水</span></a>
        <a href="<?= url('m/cards') ?>"><i data-lucide="ticket-check"></i><span>卡密兑换</span></a>
        <a href="<?= url('m/packages') ?>"><i data-lucide="badge-dollar-sign"></i><span>套餐升级</span></a>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="订单余额分区">
        <a href="#mobileOrders">最近订单</a>
        <a href="#mobileRecharges">充值记录</a>
        <a href="<?= url('m/recharge') ?>">账户充值</a>
        <a href="<?= url('m/packages') ?>">套餐升级</a>
    </nav>

    <section class="m-card" id="mobileOrders">
        <div class="m-section-head"><div><span>订单记录</span><h2>最近订单</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索订单号、类型、金额或状态" data-mobile-filter-input="#mobileOrdersList">
        </label>
        <div class="m-list" id="mobileOrdersList">
            <?php foreach ($orders as $order): ?>
                <?php
                $status = isset($order['status']) ? $order['status'] : '';
                $method = isset($order['payment_method']) ? $order['payment_method'] : '';
                $type = isset($order['type']) ? $order['type'] : '';
                $isPending = $status === 'pending';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= $type === 'recharge' ? 'wallet-cards' : 'receipt-text' ?>"></i>
                    <div>
                        <strong><?= e(isset($order['order_no']) ? $order['order_no'] : '-') ?></strong>
                        <span><?= e(isset($typeNames[$type]) ? $typeNames[$type] : ($type ?: '订单')) ?> · <?= e(isset($order['created_at']) ? $order['created_at'] : '-') ?></span>
                    </div>
                    <span class="m-badge <?= e($statusTone($status)) ?>"><?= e(isset($statusNames[$status]) ? $statusNames[$status] : ($status ?: '-')) ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">金额 ¥<?= e(number_format((float) (isset($order['pay_amount']) ? $order['pay_amount'] : 0), 2)) ?></span>
                        <span class="m-badge muted"><?= e(isset($methodNames[$method]) ? $methodNames[$method] : ($method ?: '-')) ?></span>
                        <?php if (!empty($order['package_name'])): ?><span class="m-badge muted"><?= e($order['package_name']) ?></span><?php endif; ?>
                    </div>
                    <div class="m-inline-actions">
                        <?php if ($isPending && $method === 'alipay'): ?>
                            <a class="m-button" href="<?= url('pay/alipay/' . $order['order_no']) ?>">继续支付</a>
                        <?php endif; ?>
                        <?php if ($isPending && in_array($method, ['manual', 'alipay'], true)): ?>
                            <form method="post" action="<?= url('m/orders/close') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="order_no" value="<?= e($order['order_no']) ?>">
                                <button class="m-button ghost" type="submit" data-mobile-confirm="确认关闭这个待处理订单吗？">关闭订单</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的订单。</div>
            <?php if (!$orders): ?><div class="m-empty">暂无订单。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="mobileRecharges">
        <div class="m-section-head"><div><span>充值记录</span><h2>充值记录</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索充值金额、方式、状态或备注" data-mobile-filter-input="#mobileOrderRechargesList">
        </label>
        <div class="m-list" id="mobileOrderRechargesList">
            <?php foreach ($recharges as $row): ?>
                <?php $status = isset($row['status']) ? $row['status'] : ''; ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="wallet"></i>
                    <div>
                        <strong>¥<?= e(number_format((float) (isset($row['amount']) ? $row['amount'] : 0), 2)) ?></strong>
                        <span><?= e(isset($methodNames[$row['payment_method']]) ? $methodNames[$row['payment_method']] : $row['payment_method']) ?> · <?= e(isset($row['created_at']) ? $row['created_at'] : '-') ?></span>
                    </div>
                    <span class="m-badge <?= e($statusTone($status)) ?>"><?= e(isset($statusNames[$status]) ? $statusNames[$status] : $status) ?></span>
                    <?php if (!empty($row['audit_remark'])): ?><div class="m-note"><?= e($row['audit_remark']) ?></div><?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的充值记录。</div>
            <?php if (!$recharges): ?><div class="m-empty">暂无充值记录。</div><?php endif; ?>
        </div>
    </section>
</section>
