<?php
$teams = isset($teams) && is_array($teams) ? $teams : [];
$currentTeam = isset($currentTeam) && is_array($currentTeam) ? $currentTeam : null;
$members = isset($members) && is_array($members) ? $members : [];
$pendingInvites = isset($pendingInvites) && is_array($pendingInvites) ? $pendingInvites : [];
$myInvites = isset($myInvites) && is_array($myInvites) ? $myInvites : [];
$summary = isset($summary) && is_array($summary) ? $summary : ['team_count' => 0, 'owned_count' => 0, 'member_count' => 0, 'pending_invites' => 0];
$roleLabels = isset($roleLabels) && is_array($roleLabels) ? $roleLabels : [];
$roleDescriptions = isset($roleDescriptions) && is_array($roleDescriptions) ? $roleDescriptions : [];
$canManage = !empty($canManage);
$schemaReady = !isset($schemaReady) || !empty($schemaReady);
$editableRoles = $roleLabels;
unset($editableRoles['owner']);
$teamName = function ($team) {
    return isset($team['name']) && $team['name'] !== '' ? $team['name'] : '未命名团队';
};
$personName = function ($row) {
    if (!empty($row['nickname'])) return $row['nickname'];
    if (!empty($row['username'])) return $row['username'];
    if (!empty($row['email'])) return $row['email'];
    return '成员';
};
$roleTone = function ($role) {
    if ($role === 'owner') return 'ok';
    if ($role === 'admin') return 'warn';
    if ($role === 'viewer') return 'muted';
    return 'info';
};
?>
<section class="m-page m-team-page">
    <header class="m-page-head">
        <div>
            <span>协作空间</span>
            <h1>团队空间</h1>
            <p>管理团队、成员和邀请。当前版本不改变个人文件归属，先把协作入口独立出来。</p>
        </div>
        <a class="m-pill" href="<?= url('m/menu') ?>">功能</a>
    </header>

    <?php if (!$schemaReady): ?>
        <section class="m-alert danger">团队空间数据表尚未准备完成，请管理员执行数据库修复。</section>
    <?php endif; ?>

    <section class="m-stat-grid two">
        <article><span>团队</span><strong><?= e((int) $summary['team_count']) ?></strong><small>已加入</small></article>
        <article><span>邀请</span><strong><?= e(count($myInvites) + (int) $summary['pending_invites']) ?></strong><small>待处理</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="团队空间分区">
        <a href="#mobileTeamCreate">创建</a>
        <a href="#mobileTeamList">团队</a>
        <?php if ($currentTeam): ?><a href="#mobileTeamMembers">成员</a><?php endif; ?>
        <?php if ($myInvites): ?><a href="#mobileTeamInvites">邀请</a><?php endif; ?>
    </nav>

    <?php if ($myInvites): ?>
        <section class="m-card" id="mobileTeamInvites">
            <div class="m-section-head"><div><span>待处理</span><h2>收到的邀请</h2></div></div>
            <div class="m-list">
                <?php foreach ($myInvites as $invite): ?>
                    <article class="m-list-item tall">
                        <i data-lucide="mail-plus"></i>
                        <div>
                            <strong><?= e(isset($invite['team_name']) ? $invite['team_name'] : '团队邀请') ?></strong>
                            <span><?= e(isset($roleLabels[$invite['role']]) ? $roleLabels[$invite['role']] : $invite['role']) ?> · <?= e($invite['expires_at']) ?></span>
                            <?php if (!empty($invite['message'])): ?><span><?= e($invite['message']) ?></span><?php endif; ?>
                        </div>
                        <div class="m-inline-actions">
                            <form method="post" action="<?= url('m/teams/invites/accept') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($invite['id']) ?>">
                                <button class="m-button" type="submit">接受</button>
                            </form>
                            <form method="post" action="<?= url('m/teams/invites/decline') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($invite['id']) ?>">
                                <button class="m-button ghost" type="submit">拒绝</button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="m-card" id="mobileTeamCreate">
        <div class="m-section-head"><div><span>新建团队</span><h2>创建团队</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('m/teams/save') ?>">
            <?= csrf_field() ?>
            <input name="name" value="<?= e(old('name')) ?>" maxlength="80" required placeholder="团队名称，例如：运营协作组">
            <input name="slug" value="<?= e(old('slug')) ?>" maxlength="40" required placeholder="团队标识，例如：ops-team">
            <textarea name="description" rows="3" maxlength="500" placeholder="团队说明，可选"><?= e(old('description')) ?></textarea>
            <button type="submit">创建团队</button>
        </form>
    </section>

    <section class="m-card" id="mobileTeamList">
        <div class="m-section-head"><div><span>团队列表</span><h2>我的团队</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索团队名称、标识或角色" data-mobile-filter-input="#mobileTeamListPanel">
        </label>
        <div class="m-list" id="mobileTeamListPanel">
            <?php foreach ($teams as $team): ?>
                <article class="m-list-item tall <?= $currentTeam && (int) $currentTeam['id'] === (int) $team['id'] ? 'active' : '' ?>" data-mobile-filter-item>
                    <i data-lucide="users-round"></i>
                    <div>
                        <strong><?= e($teamName($team)) ?></strong>
                        <span><?= e($team['slug']) ?> · <?= e((int) $team['member_count']) ?> 人 · <?= e(isset($roleLabels[$team['my_role']]) ? $roleLabels[$team['my_role']] : $team['my_role']) ?></span>
                    </div>
                    <a href="<?= url('m/teams?id=' . $team['id']) ?>">查看</a>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的团队。</div>
            <?php if (!$teams): ?><div class="m-empty">还没有团队，创建后可以邀请成员协作。</div><?php endif; ?>
        </div>
    </section>

    <?php if ($currentTeam): ?>
        <section class="m-card" id="mobileTeamMembers">
            <div class="m-section-head">
                <div><span>成员管理</span><h2><?= e($teamName($currentTeam)) ?></h2></div>
                <span class="m-badge <?= e($roleTone($currentTeam['my_role'])) ?>"><?= e(isset($roleLabels[$currentTeam['my_role']]) ? $roleLabels[$currentTeam['my_role']] : $currentTeam['my_role']) ?></span>
            </div>
            <?php if (!empty($currentTeam['description'])): ?><div class="m-note"><?= e($currentTeam['description']) ?></div><?php endif; ?>

            <?php if ($canManage): ?>
                <details class="m-fold" open>
                    <summary>邀请成员</summary>
                    <form class="m-mini-form" method="post" action="<?= url('m/teams/invites/create') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                        <input name="username" value="<?= e(old('username')) ?>" maxlength="120" placeholder="用户名或邮箱">
                        <input name="email" value="<?= e(old('email')) ?>" maxlength="160" placeholder="邀请邮箱，可选">
                        <select name="role">
                            <?php foreach ($editableRoles as $role => $label): ?>
                                <option value="<?= e($role) ?>"><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <textarea name="message" rows="2" maxlength="300" placeholder="邀请说明，可选"><?= e(old('message')) ?></textarea>
                        <button type="submit">发送邀请</button>
                    </form>
                </details>
            <?php endif; ?>

            <div class="m-list">
                <?php foreach ($members as $member): ?>
                    <article class="m-list-item tall">
                        <i data-lucide="user-round"></i>
                        <div>
                            <strong><?= e($personName($member)) ?></strong>
                            <span><?= e(isset($member['email']) ? $member['email'] : '') ?></span>
                            <span><?= e(isset($roleLabels[$member['role']]) ? $roleLabels[$member['role']] : $member['role']) ?> · <?= e(isset($member['joined_at']) ? $member['joined_at'] : '-') ?></span>
                        </div>
                        <span class="m-badge <?= e($roleTone($member['role'])) ?>"><?= e(isset($roleLabels[$member['role']]) ? $roleLabels[$member['role']] : $member['role']) ?></span>
                        <?php if ($canManage && $member['role'] !== 'owner'): ?>
                            <details class="m-fold">
                                <summary>调整成员</summary>
                                <form class="m-mini-form" method="post" action="<?= url('m/teams/members/update') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                    <input type="hidden" name="user_id" value="<?= e($member['user_id']) ?>">
                                    <select name="role">
                                        <?php foreach ($editableRoles as $role => $label): ?>
                                            <option value="<?= e($role) ?>" <?= $member['role'] === $role ? 'selected' : '' ?>><?= e($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input name="title" value="<?= e(isset($member['title']) ? $member['title'] : '') ?>" maxlength="80" placeholder="成员备注">
                                    <button class="ghost" type="submit">保存</button>
                                </form>
                                <form method="post" action="<?= url('m/teams/members/remove') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                    <input type="hidden" name="user_id" value="<?= e($member['user_id']) ?>">
                                    <button class="m-button danger" type="submit" data-mobile-confirm="确认移除这个成员吗？">移除成员</button>
                                </form>
                            </details>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>

            <?php if ($canManage): ?>
                <details class="m-fold">
                    <summary>待处理邀请 <?= e(count($pendingInvites)) ?></summary>
                    <div class="m-list">
                        <?php foreach ($pendingInvites as $invite): ?>
                            <article class="m-list-item tall">
                                <i data-lucide="mail"></i>
                                <div>
                                    <strong><?= e(!empty($invite['invited_nickname']) ? $invite['invited_nickname'] : (!empty($invite['invited_username']) ? $invite['invited_username'] : $invite['invited_email'])) ?></strong>
                                    <span><?= e(isset($roleLabels[$invite['role']]) ? $roleLabels[$invite['role']] : $invite['role']) ?> · <?= e($invite['expires_at']) ?></span>
                                </div>
                                <form method="post" action="<?= url('m/teams/invites/cancel') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                    <input type="hidden" name="id" value="<?= e($invite['id']) ?>">
                                    <button class="m-button ghost" type="submit">取消</button>
                                </form>
                            </article>
                        <?php endforeach; ?>
                        <?php if (!$pendingInvites): ?><div class="m-empty">暂无待处理邀请。</div><?php endif; ?>
                    </div>
                </details>
            <?php endif; ?>

            <details class="m-fold">
                <summary>团队设置</summary>
                <?php if ($currentTeam['my_role'] === 'owner' || $currentTeam['my_role'] === 'admin'): ?>
                    <form class="m-mini-form" method="post" action="<?= url('m/teams/save') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($currentTeam['id']) ?>">
                        <input name="name" value="<?= e($currentTeam['name']) ?>" maxlength="80" required>
                        <textarea name="description" rows="3" maxlength="500"><?= e(isset($currentTeam['description']) ? $currentTeam['description'] : '') ?></textarea>
                        <input name="avatar" value="<?= e(isset($currentTeam['avatar']) ? $currentTeam['avatar'] : '') ?>" maxlength="800" placeholder="头像 URL，可选">
                        <button class="ghost" type="submit">保存团队</button>
                    </form>
                <?php endif; ?>
                <div class="m-inline-actions">
                    <?php if ($currentTeam['my_role'] === 'owner'): ?>
                        <form method="post" action="<?= url('m/teams/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($currentTeam['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个团队吗？">删除团队</button>
                        </form>
                    <?php else: ?>
                        <form method="post" action="<?= url('m/teams/leave') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                            <button class="m-button ghost" type="submit" data-mobile-confirm="确认退出这个团队吗？">退出团队</button>
                        </form>
                    <?php endif; ?>
                </div>
            </details>

            <details class="m-fold">
                <summary>角色说明</summary>
                <div class="m-list">
                    <?php foreach ($roleDescriptions as $role => $desc): ?>
                        <article class="m-list-item tall">
                            <i data-lucide="shield-check"></i>
                            <div><strong><?= e(isset($roleLabels[$role]) ? $roleLabels[$role] : $role) ?></strong><span><?= e($desc) ?></span></div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </details>
        </section>
    <?php endif; ?>
</section>
