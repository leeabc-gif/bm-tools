<?php $user = isset($user) && is_array($user) ? $user : []; ?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>账户中心</span>
            <h1>资料设置</h1>
            <p>修改昵称、邮箱、头像地址和 API 访问白名单。安全相关设置会立即生效。</p>
        </div>
        <a class="m-pill" href="<?= url('m/profile') ?>">返回</a>
    </header>

    <section class="m-card">
        <div class="m-section-head"><div><span>资料设置</span><h2>基础资料</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('m/profile') ?>">
            <?= csrf_field() ?>
            <label>
                用户名
                <input value="<?= e(isset($user['username']) ? $user['username'] : '') ?>" disabled>
            </label>
            <label>
                昵称
                <input name="nickname" value="<?= e(isset($user['nickname']) ? $user['nickname'] : '') ?>" required>
            </label>
            <label>
                邮箱
                <input type="email" name="email" value="<?= e(isset($user['email']) ? $user['email'] : '') ?>" required>
            </label>
            <label>
                头像 URL
                <input name="avatar" value="<?= e(isset($user['avatar']) ? $user['avatar'] : '') ?>" placeholder="https://example.com/avatar.png">
            </label>
            <label>
                API 访问 IP 白名单
                <textarea name="api_allowed_ips" rows="5" placeholder="每行一个服务器出口 IP，留空表示不限制"><?= e(isset($user['api_allowed_ips']) ? $user['api_allowed_ips'] : '') ?></textarea>
            </label>
            <div class="m-note">做第三方系统对接时，建议只填写固定服务器出口 IP。留空表示不限制访问来源。</div>
            <button type="submit">保存资料</button>
        </form>
    </section>
</section>
