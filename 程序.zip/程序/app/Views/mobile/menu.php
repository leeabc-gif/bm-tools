<?php
$groups = [
    [
        'title' => '文件资源',
        'items' => [
            ['url' => 'm/files', 'icon' => 'image', 'label' => '图片上传', 'desc' => '图床上传、复制外链、查看图片', 'value' => isset($stats['images']) ? $stats['images'] : 0],
            ['url' => 'm/netdisk', 'icon' => 'hard-drive', 'label' => '个人网盘', 'desc' => '文件、文件夹、下载和删除', 'value' => isset($stats['netdisk']) ? $stats['netdisk'] : 0],
            ['url' => 'm/repository', 'icon' => 'library', 'label' => '分享仓库', 'desc' => '管理公开分享资源', 'value' => isset($stats['repositories']) ? $stats['repositories'] : 0],
            ['url' => 'm/subsites', 'icon' => 'globe-2', 'label' => '我的分站', 'desc' => '绑定域名和展示个人资源', 'value' => isset($stats['subsites']) ? $stats['subsites'] : 0],
            ['url' => 'm/teams', 'icon' => 'users-round', 'label' => '团队空间', 'desc' => '团队、成员和邀请管理', 'value' => isset($stats['teams']) ? $stats['teams'] : 0],
        ],
    ],
    [
        'title' => '服务器运维',
        'items' => [
            ['url' => 'm/servers', 'icon' => 'server-cog', 'label' => '服务器管家', 'desc' => '状态、采集、终端和分享页', 'value' => isset($stats['servers']) ? $stats['servers'] : 0],
            ['url' => 'm/servers/create', 'icon' => 'plus-circle', 'label' => '添加服务器', 'desc' => 'SSH 或 Agent 接入', 'value' => null],
            ['url' => 'm/servers/commands', 'icon' => 'terminal', 'label' => '命令记录', 'desc' => '查看在线终端执行历史', 'value' => null],
            ['url' => 'm/alerts', 'icon' => 'bell-ring', 'label' => '监控告警', 'desc' => '服务器和探针异常通知', 'value' => null],
        ],
    ],
    [
        'title' => '账户与计费',
        'items' => [
            ['url' => 'm/orders', 'icon' => 'receipt-text', 'label' => '订单记录', 'desc' => '购买、充值和支付状态', 'value' => isset($stats['orders']) ? $stats['orders'] : 0],
            ['url' => 'm/balance', 'icon' => 'coins', 'label' => '余额流水', 'desc' => '余额收入、消费和调整记录', 'value' => null],
            ['url' => 'm/recharge', 'icon' => 'wallet-cards', 'label' => '账户充值', 'desc' => '余额充值、人工审核和扫码支付', 'value' => null],
            ['url' => 'm/cards', 'icon' => 'ticket-check', 'label' => '卡密兑换', 'desc' => '兑换余额卡或套餐卡', 'value' => null],
            ['url' => 'm/packages', 'icon' => 'badge-dollar-sign', 'label' => '套餐升级', 'desc' => '购买或续费资源套餐', 'value' => null],
            ['url' => 'm/api', 'icon' => 'key-round', 'label' => 'API 管理', 'desc' => 'Token、安全 IP 和接口信息', 'value' => null],
            ['url' => 'm/profile', 'icon' => 'user', 'label' => '账户资料', 'desc' => '个人资料和登录信息', 'value' => null],
        ],
    ],
];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>功能导航</span>
            <h1>功能中心</h1>
            <p>手机端保留核心操作入口，文件、网盘、服务器和账户都可以从这里进入。</p>
        </div>
        <a class="m-pill" href="<?= url('m') ?>">首页</a>
    </header>

    <label class="m-list-search">
        <i data-lucide="search"></i>
        <input type="search" placeholder="搜索功能、说明或模块" data-mobile-filter-input="#mobileFunctionCenter">
        <span data-mobile-filter-count>0</span>
    </label>

    <div id="mobileFunctionCenter">
    <?php foreach ($groups as $group): ?>
        <section class="m-card" data-mobile-filter-group>
            <div class="m-section-head">
                <div><span>控制区</span><h2><?= e($group['title']) ?></h2></div>
            </div>
            <div class="m-feature-list">
                <?php foreach ($group['items'] as $item): ?>
                    <a href="<?= url($item['url']) ?>" data-mobile-filter-item>
                        <i data-lucide="<?= e($item['icon']) ?>"></i>
                        <span>
                            <strong><?= e($item['label']) ?></strong>
                            <small><?= e($item['desc']) ?></small>
                        </span>
                        <?php if ($item['value'] !== null): ?>
                            <b><?= e($item['value']) ?></b>
                        <?php else: ?>
                            <em data-lucide="chevron-right"></em>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
        <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的功能。</div>
    </div>
</section>
