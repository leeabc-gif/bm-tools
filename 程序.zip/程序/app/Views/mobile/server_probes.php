<?php
$server = isset($server) && is_array($server) ? $server : [];
$checks = isset($checks) && is_array($checks) ? $checks : [];
$editCheck = isset($editCheck) && is_array($editCheck) ? $editCheck : null;
$stats = isset($stats) && is_array($stats) ? $stats : ['total' => 0, 'up' => 0, 'down' => 0, 'expiring_ssl' => 0];
$logs = isset($logs) && is_array($logs) ? $logs : [];
$current = $editCheck ?: [];
$value = function ($key, $default = '') use ($current) {
    return old($key, isset($current[$key]) ? $current[$key] : $default);
};
$isEdit = !empty($current);
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>服务探针</span>
            <h1>站点探针</h1>
            <p>检测网站首页、API、上传接口、TCP 端口和 SSL 证书，异常会进入告警中心。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers/' . (int) $server['id']) ?>">详情</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>探针总数</span><strong><?= e((int) $stats['total']) ?></strong><small><?= $limit > 0 ? '上限 ' . e($limit) . ' 个' : '不限数量' ?></small></article>
        <article><span>正常</span><strong><?= e((int) $stats['up']) ?></strong><small>最近检测通过</small></article>
        <article><span>异常</span><strong><?= e((int) $stats['down']) ?></strong><small>需要排查</small></article>
        <article><span>SSL 临期</span><strong><?= e((int) $stats['expiring_ssl']) ?></strong><small>7 天内到期</small></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span><?= $isEdit ? '编辑探针' : '新增探针' ?></span><h2><?= $isEdit ? '编辑探针' : '新增探针' ?></h2></div><?php if ($isEdit): ?><a href="<?= url('m/servers/' . (int) $server['id'] . '/probes') ?>">新增</a><?php endif; ?></div>
        <form class="m-mini-form m-probe-form" method="post" action="<?= url('m/servers/probes/save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="server_id" value="<?= e($server['id']) ?>">
            <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= e($current['id']) ?>"><?php endif; ?>
            <select name="type" data-m-probe-type>
                <option value="http" <?= $value('type', 'http') === 'http' ? 'selected' : '' ?>>HTTP / HTTPS</option>
                <option value="tcp" <?= $value('type') === 'tcp' ? 'selected' : '' ?>>TCP 端口</option>
                <option value="ssl" <?= $value('type') === 'ssl' ? 'selected' : '' ?>>SSL 证书</option>
            </select>
            <input name="name" required value="<?= e($value('name', '网站首页')) ?>" placeholder="探针名称，例如 网站首页">
            <input name="target" required value="<?= e($value('target', '')) ?>" placeholder="HTTP 填 https://example.com，TCP/SSL 填 host:port">
            <input type="number" min="0" max="65535" name="port" value="<?= e($value('port', '0')) ?>" placeholder="端口，可留空">
            <select name="method" data-m-http-field>
                <option value="HEAD" <?= $value('method', 'HEAD') === 'HEAD' ? 'selected' : '' ?>>HEAD</option>
                <option value="GET" <?= $value('method') === 'GET' ? 'selected' : '' ?>>GET</option>
            </select>
            <input data-m-http-field name="expected_status" value="<?= e($value('expected_status', '200-399')) ?>" placeholder="预期状态码，例如 200-399">
            <input data-m-http-field name="keyword" value="<?= e($value('keyword', '')) ?>" placeholder="页面关键词，可选">
            <input type="number" min="2" max="15" name="timeout_seconds" value="<?= e($value('timeout_seconds', '5')) ?>" placeholder="超时秒数">
            <input type="number" min="60" max="86400" name="frequency" value="<?= e($value('frequency', '300')) ?>" placeholder="检测频率秒">
            <label class="m-checkline"><input type="checkbox" name="is_enabled" <?= !$isEdit || !empty($current['is_enabled']) ? 'checked' : '' ?>>启用探针</label>
            <label class="m-checkline"><input type="checkbox" name="test_after_save" checked>保存后立即检测</label>
            <div class="m-inline-actions">
                <button class="m-button ghost" type="button" data-m-probe-test data-url="<?= url('m/servers/probes/test') ?>">先测试</button>
                <button class="m-button" type="submit"><?= $isEdit ? '保存修改' : '保存探针' ?></button>
            </div>
            <div class="m-note" data-m-probe-result hidden></div>
        </form>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>探针列表</span><h2>探针列表</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索探针、目标、类型或状态" data-mobile-filter-input="#mobileServerProbesList">
        </label>
        <div class="m-list" id="mobileServerProbesList">
            <?php foreach ($checks as $check): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= $check['type'] === 'http' ? 'globe' : ($check['type'] === 'ssl' ? 'shield-check' : 'unplug') ?>"></i>
                    <div><strong><?= e($check['name']) ?></strong><span><?= e(strtoupper($check['type'])) ?> / <?= e($check['target']) ?><?= (int) $check['port'] > 0 ? ':' . e($check['port']) : '' ?></span></div>
                    <span class="m-badge <?= $check['status'] === 'up' ? 'ok' : ($check['status'] === 'down' ? 'bad' : 'muted') ?>"><?= e($check['status'] === 'up' ? '正常' : ($check['status'] === 'down' ? '异常' : '未知')) ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e((int) $check['response_time_ms']) ?>ms</span>
                        <span class="m-badge muted">状态码 <?= e($check['status_code'] ?: '-') ?></span>
                        <span class="m-badge muted"><?= e($check['last_checked_at'] ?: '未检测') ?></span>
                    </div>
                    <?php if (!empty($check['last_error'])): ?><div class="m-note"><?= e($check['last_error']) ?></div><?php endif; ?>
                    <div class="m-inline-actions">
                        <button class="m-button ghost" type="button" data-m-saved-probe-test data-url="<?= url('m/servers/probes/test') ?>" data-id="<?= e($check['id']) ?>" data-server-id="<?= e($server['id']) ?>" data-token="<?= e(csrf_token()) ?>">立即检测</button>
                        <a class="m-button ghost" href="<?= url('m/servers/' . (int) $server['id'] . '/probes?check_id=' . (int) $check['id']) ?>">编辑</a>
                        <form method="post" action="<?= url('m/servers/probes/delete') ?>" data-mobile-confirm="确认删除这个探针和检测记录吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="server_id" value="<?= e($server['id']) ?>">
                            <input type="hidden" name="id" value="<?= e($check['id']) ?>">
                            <button class="m-button danger" type="submit">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的探针。</div>
            <?php if (!$checks): ?><div class="m-empty">暂无探针。建议先添加网站首页、上传接口、API 或关键端口检测。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>检测记录</span><h2>最近检测</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索探针、类型、时间或状态" data-mobile-filter-input="#mobileProbeLogsList">
        </label>
        <div class="m-list" id="mobileProbeLogsList">
            <?php foreach ($logs as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="activity"></i>
                    <div><strong><?= e($row['check_name'] ?: '探针') ?></strong><span><?= e(strtoupper($row['type'])) ?> / <?= e($row['checked_at']) ?></span></div>
                    <span class="m-badge <?= $row['status'] === 'up' ? 'ok' : 'bad' ?>"><?= e($row['status'] === 'up' ? '正常' : '异常') ?></span>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的检测记录。</div>
            <?php if (!$logs): ?><div class="m-empty">暂无检测记录。</div><?php endif; ?>
        </div>
    </section>
</section>
