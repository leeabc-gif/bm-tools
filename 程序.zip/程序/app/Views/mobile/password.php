<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>账户安全</span>
            <h1>修改密码</h1>
            <p>新密码建议至少 8 位，并混合字母、数字或符号。修改后请使用新密码登录。</p>
        </div>
        <a class="m-pill" href="<?= url('m/profile') ?>">账户</a>
    </header>

    <section class="m-card">
        <div class="m-section-head"><div><span>密码设置</span><h2>账户安全</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('m/password') ?>">
            <?= csrf_field() ?>
            <label>
                原密码
                <input type="password" name="old_password" autocomplete="current-password" required>
            </label>
            <label>
                新密码
                <input type="password" name="password" autocomplete="new-password" required>
            </label>
            <label>
                确认新密码
                <input type="password" name="password_confirm" autocomplete="new-password" required>
            </label>
            <button type="submit">更新密码</button>
        </form>
    </section>
</section>
