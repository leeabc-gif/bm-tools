<?php
$notifications = isset($notifications) && is_array($notifications) ? $notifications : [];
$unread = 0;
foreach ($notifications as $item) {
    if (empty($item['is_read'])) $unread++;
}
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>消息中心</span>
            <h1>消息通知</h1>
            <p>系统消息、套餐提醒和业务通知集中展示，手机端保持简单可读。</p>
        </div>
        <a class="m-pill" href="<?= url('m/profile') ?>">账户</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            消息数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复。</span>
        </section>
    <?php endif; ?>

    <section class="m-stat-grid two">
        <article><span>消息总数</span><strong><?= e(count($notifications)) ?></strong><small>最近记录</small></article>
        <article><span>未读消息</span><strong><?= e($unread) ?></strong><small>需要查看</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="消息通知分区">
        <a href="#notificationList">通知列表</a>
        <a href="<?= url('m/profile') ?>">账户</a>
        <a href="<?= url('m/menu') ?>">功能</a>
    </nav>

    <section class="m-card" id="notificationList">
        <div class="m-section-head">
            <div><span>通知收件箱</span><h2>通知列表</h2></div>
            <form method="post" action="<?= url('m/notifications/read-all') ?>">
                <?= csrf_field() ?>
                <button class="m-button ghost" type="submit">全部已读</button>
            </form>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索标题、内容、时间或状态" data-mobile-filter-input="#mobileNotificationsList">
        </label>
        <div class="m-list" id="mobileNotificationsList">
            <?php foreach ($notifications as $item): ?>
                <article class="m-list-item tall <?= empty($item['is_read']) ? 'is-unread' : '' ?>" data-mobile-filter-item>
                    <i data-lucide="<?= empty($item['is_read']) ? 'mail' : 'mail-open' ?>"></i>
                    <div>
                        <strong><?= e(isset($item['title']) ? $item['title'] : '通知') ?></strong>
                        <span><?= e(isset($item['created_at']) ? $item['created_at'] : '') ?></span>
                    </div>
                    <span class="m-badge <?= empty($item['is_read']) ? 'ok' : 'muted' ?>"><?= empty($item['is_read']) ? '未读' : '已读' ?></span>
                    <div class="m-note"><?= e(isset($item['content']) ? $item['content'] : '') ?></div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的通知。</div>
            <?php if (!$notifications): ?><div class="m-empty">暂无通知。系统消息、订单反馈和功能提醒会显示在这里。</div><?php endif; ?>
        </div>
    </section>
</section>
