<?php
$statsByRepo = isset($statsByRepo) && is_array($statsByRepo) ? $statsByRepo : [];
$accessLabels = ['public' => '公开', 'password' => '密码', 'private' => '私密'];
$tone = function ($repo) {
    if (empty($repo['admin_status'])) return 'bad';
    if (empty($repo['status'])) return 'warn';
    return 'ok';
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>分享仓库</span><h1>分享仓库</h1><p>管理对外展示和下载的资源仓库，手机端可新建、编辑、复制链接和停用。</p></div>
        <a class="m-pill" href="<?= url('m/netdisk') ?>">网盘</a>
    </header>

    <nav class="m-anchor-nav m-chip-list" aria-label="分享仓库分区">
        <a href="#repoCreate">新建仓库</a>
        <a href="#repoList">仓库列表</a>
        <a href="<?= url('m/netdisk') ?>">返回网盘</a>
    </nav>

    <details class="m-fold" id="repoCreate">
        <summary>新建分享仓库</summary>
        <form class="m-mini-form" method="post" action="<?= url('m/repository/save') ?>">
            <?= csrf_field() ?>
            <input name="title" value="<?= e(old('title')) ?>" maxlength="120" required placeholder="仓库名称，例如：公开资料库">
            <input name="slug" value="<?= e(old('slug')) ?>" maxlength="80" required placeholder="自定义链接，例如：my-files">
            <textarea name="description" rows="3" maxlength="500" placeholder="仓库简介"><?= e(old('description', '这里收录了我公开分享的网盘资料。')) ?></textarea>
            <select name="access_type">
                <option value="public">公开访问</option>
                <option value="password">密码访问</option>
                <option value="private">私密停用</option>
            </select>
            <input name="password" type="password" autocomplete="new-password" placeholder="密码访问时填写">
            <label class="m-checkline"><input type="checkbox" name="allow_download" checked> 允许下载</label>
            <label class="m-checkline"><input type="checkbox" name="show_owner" checked> 展示拥有者</label>
            <label class="m-checkline"><input type="checkbox" name="status" checked> 启用仓库</label>
            <button type="submit">创建仓库</button>
        </form>
    </details>

    <section class="m-card" id="repoList">
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索仓库名、链接、访问类型或备注" data-mobile-filter-input="#mobileRepositoriesList">
        </label>
        <div class="m-list" id="mobileRepositoriesList">
            <?php foreach ($repositories as $repo): ?>
                <?php
                $repoStats = isset($statsByRepo[$repo['id']]) ? $statsByRepo[$repo['id']] : ['items' => 0, 'public_items' => 0, 'views' => (int) $repo['view_count'], 'downloads' => (int) $repo['download_count']];
                $publicUrl = url('r/' . $repo['slug']);
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="library"></i>
                    <div>
                        <strong><?= e($repo['title']) ?></strong>
                        <span>/r/<?= e($repo['slug']) ?> · <?= e(isset($accessLabels[$repo['access_type']]) ? $accessLabels[$repo['access_type']] : $repo['access_type']) ?></span>
                    </div>
                    <span class="m-badge <?= e($tone($repo)) ?>"><?= empty($repo['admin_status']) ? '平台下架' : (!empty($repo['status']) ? '启用' : '停用') ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">文件 <?= e((int) $repoStats['items']) ?></span>
                        <span class="m-badge muted">公开 <?= e((int) $repoStats['public_items']) ?></span>
                        <span class="m-badge muted">浏览 <?= e((int) $repo['view_count']) ?></span>
                        <span class="m-badge muted">下载 <?= e((int) $repo['download_count']) ?></span>
                    </div>
                    <?php if (!empty($repo['admin_remark'])): ?><div class="m-note"><?= e($repo['admin_remark']) ?></div><?php endif; ?>
                    <details class="m-fold">
                        <summary>编辑仓库</summary>
                        <form class="m-mini-form" method="post" action="<?= url('m/repository/save') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                            <input name="title" value="<?= e($repo['title']) ?>" maxlength="120" required placeholder="仓库名称">
                            <input name="slug" value="<?= e($repo['slug']) ?>" maxlength="80" required placeholder="自定义链接">
                            <textarea name="description" rows="3" maxlength="500" placeholder="仓库简介"><?= e(isset($repo['description']) ? $repo['description'] : '') ?></textarea>
                            <input name="cover_image" value="<?= e(isset($repo['cover_image']) ? $repo['cover_image'] : '') ?>" maxlength="800" placeholder="封面图片 URL，可留空">
                            <input name="tags" value="<?= e(isset($repo['tags']) ? $repo['tags'] : '') ?>" maxlength="255" placeholder="标签，逗号分隔">
                            <select name="access_type">
                                <?php foreach ($accessLabels as $value => $label): ?>
                                    <option value="<?= e($value) ?>" <?= $repo['access_type'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input name="password" type="password" autocomplete="new-password" placeholder="<?= $repo['access_type'] === 'password' ? '已设置密码，留空不改' : '密码访问时填写' ?>">
                            <div class="m-status-row">
                                <input name="max_views" type="number" min="0" value="<?= e(isset($repo['max_views']) ? $repo['max_views'] : 0) ?>" placeholder="最大浏览，0 不限">
                                <input name="max_downloads" type="number" min="0" value="<?= e(isset($repo['max_downloads']) ? $repo['max_downloads'] : 0) ?>" placeholder="最大下载，0 不限">
                            </div>
                            <div class="m-status-row">
                                <input name="ip_daily_view_limit" type="number" min="0" value="<?= e(isset($repo['ip_daily_view_limit']) ? $repo['ip_daily_view_limit'] : 0) ?>" placeholder="单 IP 每日浏览">
                                <input name="ip_daily_download_limit" type="number" min="0" value="<?= e(isset($repo['ip_daily_download_limit']) ? $repo['ip_daily_download_limit'] : 0) ?>" placeholder="单 IP 每日下载">
                            </div>
                            <input name="expire_at" type="datetime-local" value="<?= e(!empty($repo['expire_at']) ? str_replace(' ', 'T', substr($repo['expire_at'], 0, 16)) : '') ?>">
                            <label class="m-checkline"><input type="checkbox" name="allow_download" <?= !empty($repo['allow_download']) ? 'checked' : '' ?>> 允许下载</label>
                            <label class="m-checkline"><input type="checkbox" name="show_owner" <?= !empty($repo['show_owner']) ? 'checked' : '' ?>> 展示拥有者</label>
                            <label class="m-checkline"><input type="checkbox" name="status" <?= !empty($repo['status']) ? 'checked' : '' ?>> 启用仓库</label>
                            <button class="ghost" type="submit">保存设置</button>
                        </form>
                    </details>
                    <div class="m-inline-actions">
                        <a class="m-button ghost" href="<?= e($publicUrl) ?>" target="_blank">访问</a>
                        <button class="m-button ghost" type="button" data-copy-text="<?= e($publicUrl) ?>">复制链接</button>
                        <form method="post" action="<?= url('m/repository/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个分享仓库吗？原网盘文件不会删除。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的分享仓库。</div>
            <?php if (!$repositories): ?><div class="m-empty">暂无分享仓库。</div><?php endif; ?>
        </div>
    </section>
</section>
