<?php
$records = isset($records) && is_array($records) ? $records : [];
$typeNames = ['balance' => '余额充值', 'package' => '套餐兑换'];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>卡密兑换</span>
            <h1>卡密兑换</h1>
            <p>输入平台发放的卡密，可兑换余额或套餐权益。</p>
        </div>
        <a class="m-pill" href="<?= url('m/orders') ?>">订单</a>
    </header>

    <?php if (empty($schemaReady)): ?>
        <section class="m-alert danger">
            卡密数据结构未准备完成
            <span>请管理员进入后台数据库巡检执行一键修复。</span>
        </section>
    <?php endif; ?>

    <nav class="m-anchor-nav m-chip-list" aria-label="卡密兑换分区">
        <a href="#cardRedeem">输入卡密</a>
        <a href="#cardHistory">兑换记录</a>
        <a href="<?= url('m/orders') ?>">订单</a>
    </nav>

    <section class="m-card" id="cardRedeem">
        <div class="m-section-head">
            <div><span>兑换卡密</span><h2>输入卡密</h2></div>
        </div>
        <form class="m-mini-form" method="post" action="<?= url('m/cards/redeem') ?>">
            <?= csrf_field() ?>
            <input name="code" required autocomplete="off" autocapitalize="characters" placeholder="例如 BM-ABCD-2345-EFGH-6789">
            <button type="submit">立即兑换</button>
        </form>
        <div class="m-note">支持带横线或不带横线输入。连续输错过多会临时锁定兑换入口。</div>
    </section>

    <section class="m-card" id="cardHistory">
        <div class="m-section-head"><div><span>兑换记录</span><h2>最近兑换</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索兑换类型、尾号、套餐或订单" data-mobile-filter-input="#mobileCardsList">
        </label>
        <div class="m-list" id="mobileCardsList">
            <?php foreach ($records as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="ticket"></i>
                    <div>
                        <strong><?= e(isset($typeNames[$row['type']]) ? $typeNames[$row['type']] : $row['type']) ?></strong>
                        <span><?= e(isset($row['used_at']) ? $row['used_at'] : '-') ?> · 尾号 <?= e(isset($row['code_preview']) ? $row['code_preview'] : '-') ?></span>
                    </div>
                    <span class="m-badge ok">已兑换</span>
                    <div class="m-meta-grid">
                        <?php if ((isset($row['type']) ? $row['type'] : '') === 'balance'): ?>
                            <span class="m-badge muted">余额 ¥<?= e(number_format((float) (isset($row['amount']) ? $row['amount'] : 0), 2)) ?></span>
                        <?php else: ?>
                            <span class="m-badge muted"><?= e(!empty($row['package_name']) ? $row['package_name'] : '套餐') ?></span>
                            <span class="m-badge muted"><?= (int) (isset($row['duration_days']) ? $row['duration_days'] : 0) > 0 ? e((int) $row['duration_days']) . ' 天' : '套餐原时长' ?></span>
                        <?php endif; ?>
                        <?php if (!empty($row['order_no'])): ?><span class="m-badge muted"><?= e($row['order_no']) ?></span><?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的兑换记录。</div>
            <?php if (!$records): ?><div class="m-empty">暂无兑换记录。</div><?php endif; ?>
        </div>
    </section>
</section>
