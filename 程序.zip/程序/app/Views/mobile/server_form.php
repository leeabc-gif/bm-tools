<?php
$server = isset($server) && is_array($server) ? $server : null;
$isEdit = !empty($server);
$monitorType = isset($server['monitor_type']) && $server['monitor_type'] === 'agent' ? 'agent' : 'ssh';
$authType = isset($server['ssh_auth_type']) && $server['ssh_auth_type'] === 'key' ? 'key' : 'password';
$agentToken = $isEdit && !empty($server['agent_token']) ? $server['agent_token'] : bin2hex(random_bytes(24));
$value = function ($key, $default = '') use ($server) {
    return $server && isset($server[$key]) ? $server[$key] : $default;
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>服务器资产</span>
            <h1><?= $isEdit ? '编辑服务器' : '添加服务器' ?></h1>
            <p>手机端只保留必要字段。SSH 可采集状态和打开终端，Agent 适合不想保存 SSH 密码的服务器。</p>
        </div>
        <a class="m-pill" href="<?= url('m/servers') ?>">返回</a>
    </header>

    <section class="m-card">
        <div class="m-section-head">
            <div><span>可用额度</span><h2>服务器额度</h2></div>
        </div>
        <div class="m-status-row">
            <article class="m-check-card soft"><b>已保存</b><span><?= e((int) $used) ?> 台</span></article>
            <article class="m-check-card soft"><b>套餐上限</b><span><?= (int) $limit > 0 ? e((int) $limit) . ' 台' : '不限' ?></span></article>
        </div>
    </section>

    <section class="m-card">
        <form class="m-mini-form m-server-form" method="post" action="<?= url('m/servers/save') ?>">
            <?= csrf_field() ?>
            <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= e($server['id']) ?>"><?php endif; ?>

            <input name="name" required value="<?= e($value('name')) ?>" placeholder="服务器名称，例如：博客生产机">
            <input name="group_name" value="<?= e($value('group_name', '个人服务器')) ?>" placeholder="分组，例如：生产环境">
            <select name="monitor_type" data-m-server-type>
                <option value="ssh" <?= $monitorType === 'ssh' ? 'selected' : '' ?>>SSH 直连</option>
                <option value="agent" <?= $monitorType === 'agent' ? 'selected' : '' ?>>Agent 主动上报</option>
            </select>

            <div class="m-note" data-m-ssh-field>SSH 模式会加密保存密码或私钥，用于状态采集和在线终端。</div>
            <input data-m-ssh-field name="ssh_host" value="<?= e($value('ssh_host')) ?>" placeholder="SSH 主机，IP 或域名">
            <input data-m-ssh-field type="number" min="1" max="65535" name="ssh_port" value="<?= e($value('ssh_port', 22)) ?>" placeholder="SSH 端口">
            <input data-m-ssh-field name="ssh_username" value="<?= e($value('ssh_username')) ?>" placeholder="SSH 用户名，例如 root">
            <select data-m-ssh-field name="ssh_auth_type" data-m-ssh-auth>
                <option value="password" <?= $authType === 'password' ? 'selected' : '' ?>>密码认证</option>
                <option value="key" <?= $authType === 'key' ? 'selected' : '' ?>>私钥认证</option>
            </select>
            <input data-m-ssh-field data-m-auth-password type="password" name="ssh_password" autocomplete="new-password" placeholder="<?= $isEdit ? '已保存密码，留空不修改' : 'SSH 密码' ?>">
            <textarea data-m-ssh-field data-m-auth-key name="ssh_private_key" rows="5" placeholder="<?= $isEdit ? '已保存私钥，留空不修改' : '粘贴 SSH 私钥' ?>"></textarea>
            <input data-m-ssh-field data-m-auth-key type="password" name="ssh_key_passphrase" autocomplete="new-password" placeholder="私钥密码，没有则留空">

            <div class="m-note" data-m-agent-field>Agent 模式不需要平台保存 SSH 密码。保存后在详情页复制安装脚本到目标服务器执行。</div>
            <input data-m-agent-field name="agent_url" value="<?= e($value('agent_url')) ?>" placeholder="Agent URL，可选">
            <input data-m-agent-field name="agent_token" value="<?= e($agentToken) ?>" placeholder="Agent Token">

            <input name="server_ip" value="<?= e($value('server_ip')) ?>" placeholder="展示 IP，可选">
            <input type="number" min="60" name="frequency" value="<?= e($value('frequency', 300)) ?>" placeholder="采集频率，秒">
            <div class="m-status-row">
                <input type="number" min="1" max="100" name="cpu_threshold" value="90" placeholder="CPU 告警 %">
                <input type="number" min="1" max="100" name="memory_threshold" value="90" placeholder="内存告警 %">
            </div>
            <input type="number" min="1" max="100" name="disk_threshold" value="90" placeholder="磁盘告警 %">
            <label class="m-checkline"><input type="checkbox" name="is_enabled" <?= !$isEdit || !empty($server['is_enabled']) ? 'checked' : '' ?>><span>开启监控采集</span></label>
            <textarea name="remark" rows="3" placeholder="备注：用途、厂商、到期时间等"><?= e($value('remark')) ?></textarea>
            <button type="submit"><?= $isEdit ? '保存修改' : '保存服务器' ?></button>
        </form>
    </section>
</section>
