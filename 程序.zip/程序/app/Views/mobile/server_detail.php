<?php
$server = isset($server) && is_array($server) ? $server : [];
$latest = isset($latest) && is_array($latest) ? $latest : null;
$commands = isset($commands) && is_array($commands) ? $commands : [];
$probeStats = isset($probeStats) && is_array($probeStats) ? $probeStats : ['total' => 0, 'down' => 0, 'expiring_ssl' => 0];
$probeLogs = isset($probeLogs) && is_array($probeLogs) ? $probeLogs : [];
$fmt = function ($bytes) {
    return function_exists('format_bytes') ? format_bytes((float) $bytes) : number_format((float) $bytes / 1048576, 1) . ' MB';
};
$isAgent = isset($server['monitor_type']) && $server['monitor_type'] === 'agent';
$cpu = $latest ? (float) (isset($latest['cpu_usage']) ? $latest['cpu_usage'] : 0) : 0;
$memory = $latest ? (float) (isset($latest['memory_usage']) ? $latest['memory_usage'] : 0) : 0;
$disk = $latest ? (float) (isset($latest['disk_usage']) ? $latest['disk_usage'] : 0) : 0;
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>服务器详情</span>
            <h1><?= e(isset($server['name']) ? $server['name'] : '服务器') ?></h1>
            <p><?= $isAgent ? 'Agent 主动上报' : e((isset($server['ssh_username']) ? $server['ssh_username'] : '-') . '@' . (isset($server['ssh_host']) ? $server['ssh_host'] : '-') . ':' . (isset($server['ssh_port']) ? $server['ssh_port'] : 22)) ?></p>
        </div>
        <a class="m-pill" href="<?= url('m/servers') ?>">返回</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>状态</span><strong><?= e(status_label(isset($server['status']) ? $server['status'] : 'unknown')) ?></strong><small><?= e(!empty($server['last_checked_at']) ? $server['last_checked_at'] : '尚未采集') ?></small></article>
        <article><span>探针</span><strong><?= e((int) $probeStats['total']) ?></strong><small>异常 <?= e((int) $probeStats['down']) ?> / SSL 临期 <?= e((int) (isset($probeStats['expiring_ssl']) ? $probeStats['expiring_ssl'] : 0)) ?></small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="服务器详情分区">
        <a href="#serverMetrics">运行状态</a>
        <a href="#serverProbeLogs">最近探针</a>
        <a href="#serverCommandLogs">最近命令</a>
        <?php if (!$isAgent): ?><a href="<?= url('m/servers/' . (int) $server['id'] . '/terminal') ?>">在线终端</a><?php endif; ?>
    </nav>

    <section class="m-card" id="serverMetrics">
        <div class="m-section-head"><div><span>运行指标</span><h2>运行状态</h2></div></div>
        <?php if ($latest): ?>
            <div class="m-meter-grid">
                <span><b>CPU</b><em><?= e($cpu) ?>%</em><i><u style="width: <?= e(max(0, min(100, $cpu))) ?>%"></u></i></span>
                <span><b>内存</b><em><?= e($memory) ?>%</em><i><u style="width: <?= e(max(0, min(100, $memory))) ?>%"></u></i></span>
                <span><b>磁盘</b><em><?= e($disk) ?>%</em><i><u style="width: <?= e(max(0, min(100, $disk))) ?>%"></u></i></span>
            </div>
            <div class="m-meta-grid">
                <span class="m-badge muted">负载 <?= e(isset($latest['load_avg']) && $latest['load_avg'] !== '' ? $latest['load_avg'] : '-') ?></span>
                <span class="m-badge muted">内存 <?= e($fmt(isset($latest['memory_used']) ? $latest['memory_used'] : 0)) ?></span>
                <span class="m-badge muted">磁盘 <?= e($fmt(isset($latest['disk_used']) ? $latest['disk_used'] : 0)) ?></span>
            </div>
        <?php else: ?>
            <div class="m-empty">暂无采集数据，返回列表点击“立即采集”刷新状态。</div>
        <?php endif; ?>
        <?php if (!empty($server['is_stale'])): ?><div class="m-note">监控数据已过期，请检查计划任务或手动采集。</div><?php endif; ?>
        <?php if (!empty($server['last_error'])): ?><div class="m-note">最近错误：<?= e($server['last_error']) ?></div><?php endif; ?>
        <div class="m-inline-actions">
            <?php if (!$isAgent): ?><a class="m-button" href="<?= url('m/servers/' . (int) $server['id'] . '/terminal') ?>">在线终端</a><?php endif; ?>
            <form method="post" action="<?= url('m/servers/collect') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                <input type="hidden" name="return_to" value="<?= e('m/servers/' . (int) $server['id']) ?>">
                <button class="m-button ghost" type="submit">立即采集</button>
            </form>
            <a class="m-button ghost" href="<?= url('m/servers/' . (int) $server['id'] . '/probes') ?>">站点探针</a>
            <a class="m-button ghost" href="<?= url('m/servers/' . (int) $server['id'] . '/share') ?>">分享页</a>
            <a class="m-button ghost" href="<?= url('m/servers/create?id=' . (int) $server['id']) ?>">编辑</a>
        </div>
    </section>

    <section class="m-card" id="serverProbeLogs">
        <div class="m-section-head"><div><span>探针检测</span><h2>最近探针</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索探针、类型、时间或状态" data-mobile-filter-input="#mobileServerDetailProbesList">
        </label>
        <div class="m-list" id="mobileServerDetailProbesList">
            <?php foreach ($probeLogs as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="radar"></i>
                    <div><strong><?= e(isset($row['check_name']) && $row['check_name'] ? $row['check_name'] : '探针') ?></strong><span><?= e(strtoupper(isset($row['type']) ? $row['type'] : '-')) ?> / <?= e(isset($row['checked_at']) ? $row['checked_at'] : '-') ?></span></div>
                    <span class="m-badge <?= (isset($row['status']) && $row['status'] === 'up') ? 'ok' : 'bad' ?>"><?= e((isset($row['status']) && $row['status'] === 'up') ? '正常' : '异常') ?></span>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的探针记录。</div>
            <?php if (!$probeLogs): ?><div class="m-empty">暂无探针检测记录。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="serverCommandLogs">
        <div class="m-section-head"><div><span>命令记录</span><h2>最近命令</h2></div><a href="<?= url('m/servers/commands?server_id=' . (int) $server['id']) ?>">全部</a></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索命令或时间" data-mobile-filter-input="#mobileServerDetailCommandsList">
        </label>
        <div class="m-list" id="mobileServerDetailCommandsList">
            <?php foreach ($commands as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="terminal"></i>
                    <div><strong><?= e(text_limit(isset($row['command']) ? $row['command'] : '', 120)) ?></strong><span><?= e(isset($row['created_at']) ? $row['created_at'] : '') ?></span></div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的命令记录。</div>
            <?php if (!$commands): ?><div class="m-empty">暂无命令记录。</div><?php endif; ?>
        </div>
    </section>
</section>
