<?php $uploadLimits = isset($uploadLimits) && is_array($uploadLimits) ? $uploadLimits : ['batch' => 20, 'daily' => 0, 'used_today' => 0, 'remaining_today' => null, 'concurrency' => 2]; ?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>图片管理</span><h1>图片与上传</h1><p>上传、复制外链和查看详情都在手机端完成。</p></div>
        <a class="m-pill" href="<?= url('m/menu') ?>">功能</a>
    </header>

    <nav class="m-anchor-nav m-chip-list" aria-label="图片页面分区">
        <a href="#imageUpload">上传图片</a>
        <a href="#imageStats">空间概览</a>
        <a href="#imageList">最近图片</a>
        <a href="<?= url('m/menu') ?>">功能中心</a>
    </nav>

    <section class="m-card" id="imageUpload">
        <form class="m-upload" method="post" action="<?= e($uploadAction) ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="ajax_upload" value="1">
            <label>
                <i data-lucide="upload-cloud"></i>
                <span>选择图片上传</span>
                <input type="file" name="images[]" accept="image/*" multiple>
            </label>
            <div class="m-upload-hint">
                单次最多 <?= e((int) $uploadLimits['batch']) ?> 张，并发 <?= e((int) $uploadLimits['concurrency']) ?> 个。
                <?php if ((int) $uploadLimits['daily'] > 0): ?>今日已上传 <?= e((int) $uploadLimits['used_today']) ?> 张，剩余 <?= e((int) $uploadLimits['remaining_today']) ?> 张。<?php else: ?>今日数量不限。<?php endif; ?>
                <?php if ((int) $uploadLimits['single_file_limit'] > 0): ?>单图不超过 <?= e(format_bytes((int) $uploadLimits['single_file_limit'])) ?>。<?php endif; ?>
                <?php if ($uploadLimits['storage_remaining'] !== null): ?>剩余空间 <?= e(format_bytes((int) $uploadLimits['storage_remaining'])) ?>。<?php endif; ?>
            </div>
            <button type="submit">开始上传</button>
        </form>
    </section>

    <section class="m-stat-grid two" id="imageStats">
        <article><span>图片数量</span><strong><?= e($usage['count']) ?></strong><small>当前账号</small></article>
        <article><span>图片占用</span><strong><?= e(format_bytes($usage['size'])) ?></strong><small>已用空间</small></article>
    </section>

    <section class="m-card" id="imageList">
        <div class="m-section-head">
            <div><span>图片列表</span><h2>最近图片</h2></div>
            <?php if ($files): ?>
                <button class="m-link-button" type="button" data-copy-text="<?= e(implode("\n", array_map(function ($file) { return public_url($file['file_url']); }, $files))) ?>">复制全部</button>
            <?php endif; ?>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索图片名、格式、大小或时间" data-mobile-filter-input="#mobileImagesList">
        </label>
        <div class="m-list" id="mobileImagesList">
            <?php foreach ($files as $file): ?>
                <?php $fileUrl = public_url($file['file_url']); ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="image"></i>
                    <div>
                        <strong><?= e($file['original_name']) ?></strong>
                        <span><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></span>
                    </div>
                    <a href="<?= e($fileUrl) ?>" target="_blank">打开</a>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e(strtoupper(isset($file['file_ext']) ? $file['file_ext'] : 'IMG')) ?></span>
                        <?php if (!empty($file['download_count'])): ?><span class="m-badge muted">下载 <?= e((int) $file['download_count']) ?></span><?php endif; ?>
                    </div>
                    <div class="m-inline-actions">
                        <button class="m-button ghost" type="button" data-copy-text="<?= e($fileUrl) ?>">复制链接</button>
                        <a class="m-button ghost" href="<?= url('m/files/detail?id=' . (int) $file['id']) ?>">详情</a>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的图片。</div>
            <?php if (!$files): ?><div class="m-empty">暂无图片。</div><?php endif; ?>
        </div>
    </section>
</section>
