<?php
$displayName = !empty($user['nickname']) ? $user['nickname'] : $user['username'];
$packageName = $package ? $package['name'] : '未绑定套餐';
$storagePercent = isset($dashboardStats['storage_percent']) ? (float) $dashboardStats['storage_percent'] : 0;
$trafficPercent = isset($dashboardStats['traffic_percent']) ? (float) $dashboardStats['traffic_percent'] : 0;
$recentFiles = isset($dashboardStats['recent']) ? $dashboardStats['recent'] : [];
$tips = isset($dashboardStats['tips']) ? $dashboardStats['tips'] : [];
$counters = isset($dashboardCounters) && is_array($dashboardCounters) ? $dashboardCounters : [];
$balance = isset($user['balance']) ? (float) $user['balance'] : 0;
$storageUsed = isset($user['used_storage']) ? (int) $user['used_storage'] : 0;
$storageTotal = isset($user['total_storage']) ? (int) $user['total_storage'] : 0;
$trafficUsed = isset($user['used_traffic']) ? (int) $user['used_traffic'] : 0;
$trafficTotal = isset($user['total_traffic']) ? (int) $user['total_traffic'] : 0;
$isAdminUser = isset($user['role']) && $user['role'] === 'admin';
$monitorEnabled = !empty($permissions['monitor']);
$counter = function ($key) use ($counters) {
    return isset($counters[$key]) ? (int) $counters[$key] : 0;
};

$quickActions = [
    ['title' => '上传图片', 'icon' => 'upload-cloud', 'url' => url('files'), 'enabled' => !empty($permissions['image']), 'primary' => true],
    ['title' => '打开网盘', 'icon' => 'hard-drive', 'url' => url('netdisk'), 'enabled' => !empty($permissions['netdisk']), 'primary' => false],
    ['title' => '新建仓库', 'icon' => 'folder-plus', 'url' => url('repository/create'), 'enabled' => !empty($permissions['netdisk']), 'primary' => false],
    ['title' => '添加服务器', 'icon' => 'server-cog', 'url' => url('servers/create'), 'enabled' => $monitorEnabled, 'primary' => false],
];
if ($isAdminUser) {
    $quickActions[] = ['title' => '后台管理', 'icon' => 'layout-dashboard', 'url' => url('admin'), 'enabled' => true, 'primary' => false];
}

$controlGroups = [
    [
        'key' => 'resources',
        'title' => '资源管理',
        'desc' => '图片和文件',
        'secondary' => false,
        'items' => [
            ['title' => '图床服务', 'desc' => '上传图片、复制外链', 'icon' => 'image-plus', 'url' => url('files'), 'count' => isset($dashboardStats['image_total']) ? (int) $dashboardStats['image_total'] : 0, 'enabled' => !empty($permissions['image'])],
            ['title' => '个人网盘', 'desc' => '管理文件和文件夹', 'icon' => 'hard-drive', 'url' => url('netdisk'), 'count' => isset($dashboardStats['netdisk_total']) ? (int) $dashboardStats['netdisk_total'] : 0, 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '文件记录', 'desc' => '上传下载操作记录', 'icon' => 'clipboard-list', 'url' => url('files/logs'), 'count' => null, 'enabled' => !empty($permissions['image']) || !empty($permissions['netdisk'])],
            ['title' => '回收站', 'desc' => '恢复或清理已删文件', 'icon' => 'trash-2', 'url' => url('netdisk/recycle'), 'count' => null, 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '团队空间', 'desc' => '成员、邀请和协作角色', 'icon' => 'users-round', 'url' => url('teams'), 'count' => $counter('teams'), 'enabled' => true],
        ],
    ],
    [
        'key' => 'repository',
        'title' => '分享仓库',
        'desc' => '链接、权限、日志',
        'secondary' => false,
        'items' => [
            ['title' => '创建仓库', 'desc' => '新建公开资源页', 'icon' => 'folder-plus', 'url' => url('repository/create'), 'count' => null, 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '仓库文件', 'desc' => '管理仓库文件列表', 'icon' => 'library', 'url' => url('repository/files'), 'count' => $counter('repositories'), 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '链接与权限', 'desc' => '密码、下载、访问限制', 'icon' => 'shield-check', 'url' => url('repository/settings'), 'count' => null, 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '访问日志', 'desc' => '查看访问记录', 'icon' => 'list-checks', 'url' => url('repository/logs/access'), 'count' => null, 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '下载日志', 'desc' => '查看下载记录', 'icon' => 'download', 'url' => url('repository/logs/download'), 'count' => null, 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '普通分享', 'desc' => '网盘外链列表', 'icon' => 'share-2', 'url' => url('shares'), 'count' => $counter('shares'), 'enabled' => !empty($permissions['netdisk'])],
            ['title' => '我的分站', 'desc' => '独立资源站与域名绑定', 'icon' => 'globe-2', 'url' => url('subsites'), 'count' => $counter('subsites'), 'enabled' => true],
        ],
    ],
    [
        'key' => 'servers',
        'title' => '服务器运维',
        'desc' => '服务器、终端、告警',
        'secondary' => false,
        'items' => [
            ['title' => '服务器管家', 'desc' => '查看个人服务器', 'icon' => 'server-cog', 'url' => url('servers'), 'count' => $counter('ssh_servers'), 'enabled' => $monitorEnabled],
            ['title' => '新增服务器', 'desc' => 'SSH 或 Agent 接入', 'icon' => 'plug-zap', 'url' => url('servers/create'), 'count' => null, 'enabled' => $monitorEnabled],
            ['title' => '命令审计', 'desc' => '查看在线终端记录', 'icon' => 'clipboard-list', 'url' => url('servers/commands'), 'count' => null, 'enabled' => $monitorEnabled],
            ['title' => '监控列表', 'desc' => '查看状态和指标', 'icon' => 'activity', 'url' => url('servers'), 'count' => $counter('servers'), 'enabled' => $monitorEnabled],
            ['title' => '告警中心', 'desc' => '处理异常提醒', 'icon' => 'triangle-alert', 'url' => url('alerts'), 'count' => $counter('alerts'), 'enabled' => $monitorEnabled],
        ],
    ],
    [
        'key' => 'billing',
        'title' => '账户与商业',
        'desc' => '套餐、充值、订单',
        'secondary' => true,
        'items' => [
            ['title' => '套餐升级', 'desc' => '扩容和开通权限', 'icon' => 'badge-dollar-sign', 'url' => url('packages'), 'count' => null, 'enabled' => true],
            ['title' => '余额充值', 'desc' => '充值账户余额', 'icon' => 'wallet', 'url' => url('recharge'), 'count' => null, 'enabled' => true],
            ['title' => '卡密兑换', 'desc' => '兑换余额或套餐', 'icon' => 'ticket', 'url' => url('cards'), 'count' => null, 'enabled' => true],
            ['title' => '订单记录', 'desc' => '购买和充值订单', 'icon' => 'receipt-text', 'url' => url('orders'), 'count' => $counter('orders'), 'enabled' => true],
            ['title' => '余额流水', 'desc' => '查看账户变动', 'icon' => 'coins', 'url' => url('balance/logs'), 'count' => null, 'enabled' => true],
        ],
    ],
    [
        'key' => 'account',
        'title' => '账号与接口',
        'desc' => '资料、安全、API',
        'secondary' => true,
        'items' => [
            ['title' => '个人资料', 'desc' => '昵称、邮箱、头像', 'icon' => 'user-round-cog', 'url' => url('profile'), 'count' => null, 'enabled' => true],
            ['title' => '修改密码', 'desc' => '更新登录密码', 'icon' => 'key-round', 'url' => url('password'), 'count' => null, 'enabled' => true],
            ['title' => 'API 控制台', 'desc' => 'Token 与接入说明', 'icon' => 'square-terminal', 'url' => url('api/console'), 'count' => null, 'enabled' => !empty($permissions['api'])],
            ['title' => '消息中心', 'desc' => '系统通知和提醒', 'icon' => 'bell', 'url' => url('notifications'), 'count' => $counter('notifications'), 'enabled' => true],
            ['title' => '公告通知', 'desc' => '查看平台公告', 'icon' => 'megaphone', 'url' => url('announcements'), 'count' => null, 'enabled' => true],
        ],
    ],
];
?>

<section class="bm-workspace user-dashboard-pro">
    <header class="bm-page-hero user-console-hero">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">个人中心</span>
            <h1>你好，<?= e($displayName) ?></h1>
            <p>常用操作、资源状态和功能入口已按使用场景整理。</p>
            <div class="bm-action-row user-quick-actions">
                <?php foreach ($quickActions as $action): ?>
                    <?php if (!empty($action['enabled'])): ?>
                        <a class="bm-btn <?= !empty($action['primary']) ? 'bm-btn-primary' : 'bm-btn-soft' ?>" href="<?= e($action['url']) ?>" data-icon="<?= e($action['icon']) ?>">
                            <span><?= e($action['title']) ?></span>
                        </a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        <aside class="user-account-card">
            <div>
                <span>当前套餐</span>
                <strong><?= e($packageName) ?></strong>
                <p>余额 ¥<?= e(number_format($balance, 2)) ?></p>
            </div>
            <a class="bm-btn bm-btn-soft" href="<?= url('packages') ?>" data-icon="arrow-up-right">查看权益</a>
        </aside>
    </header>

    <?php if (empty($permissions['image']) || empty($permissions['netdisk']) || empty($permissions['api']) || empty($permissions['monitor'])): ?>
        <section class="bm-inline-notice user-permission-notice">
            <i data-lucide="shield-alert"></i>
            <div>
                <strong>部分功能由套餐控制</strong>
                <span>图床 <?= !empty($permissions['image']) ? '可用' : '未开通' ?> · 网盘 <?= !empty($permissions['netdisk']) ? '可用' : '未开通' ?> · 服务器运维 <?= !empty($permissions['monitor']) ? '可用' : '未开通' ?> · API <?= !empty($permissions['api']) ? '可用' : '未开通' ?></span>
            </div>
            <a href="<?= url('packages') ?>">去开通</a>
        </section>
    <?php endif; ?>

    <section class="bm-stat-grid user-console-stats">
        <article class="bm-stat-card <?= $storagePercent >= 80 ? 'is-warn' : '' ?>">
            <span>存储空间</span>
            <strong><?= e($storagePercent) ?>%</strong>
            <small><?= e(format_bytes($storageUsed)) ?> / <?= e(format_bytes($storageTotal)) ?></small>
            <i class="bm-progress"><em style="width: <?= e($storagePercent) ?>%"></em></i>
        </article>
        <article class="bm-stat-card">
            <span>流量使用</span>
            <strong><?= e($trafficPercent) ?>%</strong>
            <small><?= e(format_bytes($trafficUsed)) ?> / <?= e(format_bytes($trafficTotal)) ?></small>
            <i class="bm-progress"><em style="width: <?= e($trafficPercent) ?>%"></em></i>
        </article>
        <article class="bm-stat-card">
            <span>文件资产</span>
            <strong><?= e(isset($dashboardStats['file_total']) ? $dashboardStats['file_total'] : 0) ?></strong>
            <small>图片 <?= e(isset($dashboardStats['image_total']) ? $dashboardStats['image_total'] : 0) ?> · 文件 <?= e(isset($dashboardStats['netdisk_total']) ? $dashboardStats['netdisk_total'] : 0) ?></small>
        </article>
        <article class="bm-stat-card">
            <span>待处理</span>
            <strong><?= e($counter('notifications') + $counter('alerts') + $counter('pending_orders')) ?></strong>
            <small>消息 <?= e($counter('notifications')) ?> · 告警 <?= e($counter('alerts')) ?> · 订单 <?= e($counter('pending_orders')) ?></small>
        </article>
    </section>

    <section class="user-control-board" aria-label="用户中心功能控制面板">
        <?php foreach ($controlGroups as $group): ?>
            <article class="user-control-section user-control-section-<?= e($group['key']) ?> <?= !empty($group['secondary']) ? 'is-secondary' : 'is-primary' ?>">
                <header>
                    <div>
                        <h2><?= e($group['title']) ?></h2>
                        <p><?= e($group['desc']) ?></p>
                    </div>
                </header>
                <div class="user-control-links">
                    <?php foreach ($group['items'] as $item): ?>
                        <?php $enabled = !empty($item['enabled']); ?>
                        <a class="user-control-link <?= $enabled ? '' : 'is-disabled' ?>" href="<?= $enabled ? e($item['url']) : e(url('packages')) ?>">
                            <span class="bm-icon-tile is-small"><i data-lucide="<?= e($item['icon']) ?>"></i></span>
                            <span>
                                <strong><?= e($item['title']) ?></strong>
                                <small><?= e($enabled ? $item['desc'] : '当前套餐未开通') ?></small>
                            </span>
                            <?php if ($item['count'] !== null): ?><em><?= e($item['count']) ?></em><?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="bm-two-column user-dashboard-bottom">
        <article class="bm-card user-recent-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">最近文件</span>
                    <h2>最近文件</h2>
                </div>
                <a class="bm-text-link" href="<?= url('files') ?>">查看全部</a>
            </div>
            <div class="bm-file-list">
                <?php if (!$recentFiles): ?>
                    <div class="bm-empty-state">
                        <i data-lucide="folder-open"></i>
                        <strong>还没有文件</strong>
                        <span>上传第一张图片或一个网盘文件后，这里会显示最近记录。</span>
                        <?php if (!empty($permissions['image'])): ?>
                            <a class="bm-btn bm-btn-primary" href="<?= url('files') ?>" data-icon="upload-cloud">去上传</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php foreach ($recentFiles as $file): ?>
                    <a class="bm-file-row" href="<?= $file['file_type'] === 'image' ? url('files/detail?id=' . $file['id']) : url('netdisk') ?>">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= $file['file_type'] === 'image' ? 'image' : 'file' ?>"></i></span>
                        <span>
                            <strong><?= e($file['original_name']) ?></strong>
                            <small><?= e($file['file_type'] === 'image' ? '图片' : '文件') ?> · <?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></small>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </article>

        <aside class="bm-card user-suggestion-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">建议操作</span>
                    <h2>建议操作</h2>
                </div>
            </div>
            <div class="bm-suggestion-list">
                <?php foreach ($tips as $tip): ?>
                    <a href="<?= e($tip['url']) ?>">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= e($tip['icon']) ?>"></i></span>
                        <span>
                            <strong><?= e($tip['title']) ?></strong>
                            <small><?= e($tip['desc']) ?></small>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </aside>
    </section>
</section>
