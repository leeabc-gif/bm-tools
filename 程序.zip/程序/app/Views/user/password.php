<section class="form-section glass reveal">
    <div class="section-heading"><p class="eyebrow">账号安全</p><h1>修改密码</h1></div>
    <form method="post" action="<?= url('password') ?>" class="form-grid">
        <?= csrf_field() ?>
        <label>原密码<input type="password" name="old_password" required></label>
        <label>新密码<input type="password" name="password" required></label>
        <label>确认新密码<input type="password" name="password_confirm" required></label>
        <button class="btn btn-primary" type="submit">更新密码</button>
    </form>
</section>
