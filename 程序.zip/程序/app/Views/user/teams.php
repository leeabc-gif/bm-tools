<?php
$teams = isset($teams) && is_array($teams) ? $teams : [];
$currentTeam = isset($currentTeam) && is_array($currentTeam) ? $currentTeam : null;
$members = isset($members) && is_array($members) ? $members : [];
$pendingInvites = isset($pendingInvites) && is_array($pendingInvites) ? $pendingInvites : [];
$myInvites = isset($myInvites) && is_array($myInvites) ? $myInvites : [];
$summary = isset($summary) && is_array($summary) ? $summary : ['team_count' => 0, 'owned_count' => 0, 'member_count' => 0, 'pending_invites' => 0];
$roleLabels = isset($roleLabels) && is_array($roleLabels) ? $roleLabels : [];
$roleDescriptions = isset($roleDescriptions) && is_array($roleDescriptions) ? $roleDescriptions : [];
$canManage = !empty($canManage);
$editableRoles = $roleLabels;
unset($editableRoles['owner']);
$editTeam = $currentTeam && (isset($currentTeam['my_role']) && in_array($currentTeam['my_role'], ['owner', 'admin'], true));
$teamName = function ($team) {
    return isset($team['name']) && $team['name'] !== '' ? $team['name'] : '未命名团队';
};
$personName = function ($row) {
    if (!empty($row['nickname'])) return $row['nickname'];
    if (!empty($row['username'])) return $row['username'];
    if (!empty($row['email'])) return $row['email'];
    return '成员';
};
$roleClass = function ($role) {
    if ($role === 'owner') return 'ok';
    if ($role === 'admin') return 'soft';
    if ($role === 'viewer') return 'muted';
    return 'info';
};
$field = function ($key, $default = '') use ($currentTeam) {
    if (old($key, '') !== '') return old($key);
    return $currentTeam && isset($currentTeam[$key]) ? $currentTeam[$key] : $default;
};
?>

<section class="bm-workspace team-console">
    <header class="bm-page-hero bm-page-hero-compact team-hero">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">协作空间</span>
            <h1>团队空间</h1>
            <p>把成员、邀请和角色先整理成独立协作入口。文件归属和个人网盘保持原逻辑，后续可以在这里接入团队文件空间、团队仓库和协作审计。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="#team-editor" data-icon="plus">创建团队</a>
                <?php if ($currentTeam): ?><a class="bm-btn bm-btn-soft" href="#team-members" data-icon="users-round">成员管理</a><?php endif; ?>
                <a class="bm-btn bm-btn-soft" href="<?= url('dashboard') ?>" data-icon="layout-dashboard">返回工作台</a>
            </div>
        </div>
    </header>

    <section class="team-stat-grid">
        <article class="bm-card team-stat-card"><span>加入团队</span><strong><?= e((int) $summary['team_count']) ?></strong><small>我参与的协作空间</small></article>
        <article class="bm-card team-stat-card"><span>我创建的</span><strong><?= e((int) $summary['owned_count']) ?></strong><small>所有者权限团队</small></article>
        <article class="bm-card team-stat-card"><span>成员席位</span><strong><?= e((int) $summary['member_count']) ?></strong><small>当前团队成员合计</small></article>
        <article class="bm-card team-stat-card"><span>待处理邀请</span><strong><?= e(count($myInvites) + (int) $summary['pending_invites']) ?></strong><small>我收到或团队发出的邀请</small></article>
    </section>

    <?php if ($myInvites): ?>
        <section class="bm-card team-inbox-card" id="team-invites">
            <div class="bm-card-head">
                <div><span class="bm-eyebrow">待处理</span><h2>收到的团队邀请</h2></div>
            </div>
            <div class="team-invite-list">
                <?php foreach ($myInvites as $invite): ?>
                    <article class="team-invite-card">
                        <div>
                            <strong><?= e(isset($invite['team_name']) ? $invite['team_name'] : '团队邀请') ?></strong>
                            <span><?= e(isset($invite['message']) && $invite['message'] !== '' ? $invite['message'] : '邀请你加入团队协作') ?></span>
                            <small>角色：<?= e(isset($roleLabels[$invite['role']]) ? $roleLabels[$invite['role']] : $invite['role']) ?> · 有效期至 <?= e($invite['expires_at']) ?></small>
                        </div>
                        <div class="team-action-inline">
                            <form method="post" action="<?= url('teams/invites/accept') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($invite['id']) ?>">
                                <button class="bm-btn bm-btn-primary" type="submit" data-icon="check">接受</button>
                            </form>
                            <form method="post" action="<?= url('teams/invites/decline') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($invite['id']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="x">拒绝</button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="team-layout-grid">
        <article class="bm-card team-list-card">
            <div class="bm-card-head">
                <div><span class="bm-eyebrow">团队列表</span><h2>我的团队</h2></div>
                <a class="bm-text-link" href="<?= url('teams') ?>">刷新</a>
            </div>
            <div class="team-card-list">
                <?php if (!$teams): ?>
                    <div class="bm-empty-state">
                        <i data-lucide="users-round"></i>
                        <strong>还没有团队</strong>
                        <span>先创建一个团队，再邀请成员加入。这个功能暂不改变个人文件和网盘数据。</span>
                    </div>
                <?php endif; ?>
                <?php foreach ($teams as $team): ?>
                    <a class="team-row-card <?= $currentTeam && (int) $currentTeam['id'] === (int) $team['id'] ? 'active' : '' ?>" href="<?= url('teams?id=' . $team['id']) ?>">
                        <span class="team-avatar"><?= e(text_initial($teamName($team), 'T')) ?></span>
                        <span>
                            <strong><?= e($teamName($team)) ?></strong>
                            <small><?= e($team['slug']) ?> · <?= e((int) $team['member_count']) ?> 人 · <?= e(isset($roleLabels[$team['my_role']]) ? $roleLabels[$team['my_role']] : $team['my_role']) ?></small>
                        </span>
                        <?php if (!empty($team['pending_invite_count'])): ?><em><?= e((int) $team['pending_invite_count']) ?> 邀请</em><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="bm-card team-detail-card" id="team-members">
            <?php if (!$currentTeam): ?>
                <div class="bm-empty-state">
                    <i data-lucide="user-plus"></i>
                    <strong>选择或创建团队</strong>
                    <span>团队创建后，可以在这里查看成员、设置角色、取消邀请或退出团队。</span>
                </div>
            <?php else: ?>
                <div class="bm-card-head">
                    <div>
                        <span class="bm-eyebrow">成员管理</span>
                        <h2><?= e($teamName($currentTeam)) ?></h2>
                        <p><?= e(isset($currentTeam['description']) && $currentTeam['description'] !== '' ? $currentTeam['description'] : '暂无团队说明') ?></p>
                    </div>
                    <span class="status-pill <?= e($roleClass($currentTeam['my_role'])) ?>"><?= e(isset($roleLabels[$currentTeam['my_role']]) ? $roleLabels[$currentTeam['my_role']] : $currentTeam['my_role']) ?></span>
                </div>

                <div class="team-member-list">
                    <?php foreach ($members as $member): ?>
                        <article class="team-member-card">
                            <span class="team-avatar"><?= e(text_initial($personName($member), 'U')) ?></span>
                            <div>
                                <strong><?= e($personName($member)) ?></strong>
                                <small><?= e(isset($member['email']) ? $member['email'] : '') ?> · 加入于 <?= e(isset($member['joined_at']) ? $member['joined_at'] : '-') ?></small>
                            </div>
                            <span class="team-role-pill <?= e($roleClass($member['role'])) ?>"><?= e(isset($roleLabels[$member['role']]) ? $roleLabels[$member['role']] : $member['role']) ?></span>
                            <?php if ($canManage && $member['role'] !== 'owner'): ?>
                                <form method="post" action="<?= url('teams/members/update') ?>" class="team-member-form">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                    <input type="hidden" name="user_id" value="<?= e($member['user_id']) ?>">
                                    <select name="role">
                                        <?php foreach ($editableRoles as $role => $label): ?>
                                            <option value="<?= e($role) ?>" <?= $member['role'] === $role ? 'selected' : '' ?>><?= e($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input name="title" value="<?= e(isset($member['title']) ? $member['title'] : '') ?>" maxlength="80" placeholder="成员备注">
                                    <button class="bm-btn bm-btn-soft" type="submit" data-icon="save">保存</button>
                                </form>
                                <form method="post" action="<?= url('teams/members/remove') ?>" class="confirm-form" data-confirm="确认移除这个成员吗？">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                    <input type="hidden" name="user_id" value="<?= e($member['user_id']) ?>">
                                    <button class="bm-btn bm-btn-danger" type="submit" data-icon="user-minus">移除</button>
                                </form>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>

                <?php if ($canManage): ?>
                    <div class="team-pending-block">
                        <div class="bm-card-head">
                            <div><span class="bm-eyebrow">邀请记录</span><h2>待处理邀请</h2></div>
                        </div>
                        <div class="team-invite-list">
                            <?php if (!$pendingInvites): ?><div class="bm-empty-line">暂无待处理邀请。</div><?php endif; ?>
                            <?php foreach ($pendingInvites as $invite): ?>
                                <article class="team-invite-card">
                                    <div>
                                        <strong><?= e(!empty($invite['invited_nickname']) ? $invite['invited_nickname'] : (!empty($invite['invited_username']) ? $invite['invited_username'] : $invite['invited_email'])) ?></strong>
                                        <span><?= e(isset($invite['message']) ? $invite['message'] : '') ?></span>
                                        <small><?= e(isset($roleLabels[$invite['role']]) ? $roleLabels[$invite['role']] : $invite['role']) ?> · 有效期至 <?= e($invite['expires_at']) ?></small>
                                    </div>
                                    <form method="post" action="<?= url('teams/invites/cancel') ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                        <input type="hidden" name="id" value="<?= e($invite['id']) ?>">
                                        <button class="bm-btn bm-btn-soft" type="submit" data-icon="x">取消</button>
                                    </form>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </article>

        <aside class="team-side-stack">
            <section class="bm-card team-editor-card" id="team-editor">
                <div class="bm-card-head">
                    <div><span class="bm-eyebrow">基础信息</span><h2><?= $editTeam ? '编辑团队' : '创建团队' ?></h2></div>
                    <?php if ($currentTeam): ?><a class="bm-text-link" href="<?= url('teams') ?>">新建</a><?php endif; ?>
                </div>
                <form method="post" action="<?= url('teams/save') ?>" class="bm-form-grid team-form">
                    <?= csrf_field() ?>
                    <?php if ($editTeam): ?><input type="hidden" name="id" value="<?= e($currentTeam['id']) ?>"><?php endif; ?>
                    <label>
                        <span>团队名称</span>
                        <input name="name" value="<?= e($editTeam ? $field('name') : old('name')) ?>" maxlength="80" required placeholder="例如：产品运营小组">
                    </label>
                    <?php if (!$editTeam): ?>
                        <label>
                            <span>团队标识</span>
                            <input name="slug" value="<?= e(old('slug')) ?>" maxlength="40" required placeholder="product-team">
                            <small>3-40 位小写字母、数字或中划线。</small>
                        </label>
                    <?php endif; ?>
                    <label class="bm-span-all">
                        <span>团队说明</span>
                        <textarea name="description" rows="4" maxlength="500" placeholder="说明这个团队负责的资源、项目或客户。"><?= e($editTeam ? $field('description') : old('description')) ?></textarea>
                    </label>
                    <label class="bm-span-all">
                        <span>头像 URL</span>
                        <input name="avatar" value="<?= e($editTeam ? $field('avatar') : old('avatar')) ?>" maxlength="800" placeholder="可选，支持 http(s) 或站内路径">
                    </label>
                    <div class="bm-form-actions bm-span-all">
                        <button class="bm-btn bm-btn-primary" type="submit" data-icon="save"><?= $editTeam ? '保存团队' : '创建团队' ?></button>
                    </div>
                </form>
            </section>

            <?php if ($currentTeam && $canManage): ?>
                <section class="bm-card team-editor-card">
                    <div class="bm-card-head">
                        <div><span class="bm-eyebrow">邀请成员</span><h2>邀请成员</h2></div>
                    </div>
                    <form method="post" action="<?= url('teams/invites/create') ?>" class="bm-form-grid team-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                        <label>
                            <span>用户名或邮箱</span>
                            <input name="username" value="<?= e(old('username')) ?>" maxlength="120" placeholder="已注册用户优先填用户名">
                        </label>
                        <label>
                            <span>邀请邮箱</span>
                            <input name="email" value="<?= e(old('email')) ?>" maxlength="160" placeholder="也可以填邮箱">
                        </label>
                        <label>
                            <span>角色</span>
                            <select name="role">
                                <?php foreach ($editableRoles as $role => $label): ?>
                                    <option value="<?= e($role) ?>"><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <label class="bm-span-all">
                            <span>邀请说明</span>
                            <textarea name="message" rows="3" maxlength="300" placeholder="可选，给对方一句说明。"><?= e(old('message')) ?></textarea>
                        </label>
                        <div class="bm-form-actions bm-span-all">
                            <button class="bm-btn bm-btn-primary" type="submit" data-icon="send">发送邀请</button>
                        </div>
                    </form>
                </section>
            <?php endif; ?>

            <?php if ($currentTeam): ?>
                <section class="bm-card team-role-card">
                    <div class="bm-card-head">
                        <div><span class="bm-eyebrow">权限说明</span><h2>角色说明</h2></div>
                    </div>
                    <div class="team-role-list">
                        <?php foreach ($roleDescriptions as $role => $desc): ?>
                            <div><span class="team-role-pill <?= e($roleClass($role)) ?>"><?= e(isset($roleLabels[$role]) ? $roleLabels[$role] : $role) ?></span><p><?= e($desc) ?></p></div>
                        <?php endforeach; ?>
                    </div>
                    <div class="team-danger-actions">
                        <?php if ($currentTeam['my_role'] === 'owner'): ?>
                            <form method="post" action="<?= url('teams/delete') ?>" class="confirm-form" data-confirm="确认删除这个团队吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($currentTeam['id']) ?>">
                                <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除团队</button>
                            </form>
                        <?php else: ?>
                            <form method="post" action="<?= url('teams/leave') ?>" class="confirm-form" data-confirm="确认退出这个团队吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="team_id" value="<?= e($currentTeam['id']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="log-out">退出团队</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>
        </aside>
    </section>
</section>
