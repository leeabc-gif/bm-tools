<section class="bm-workspace profile-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">账户设置</span>
            <h1>个人资料</h1>
            <p>管理基础资料、头像、邮箱和 API Token。Token 用于 PicGo、ShareX、脚本上传等开放接口场景，请妥善保管。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('api/console') ?>" data-icon="terminal">API 管理</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('password') ?>" data-icon="lock-keyhole">修改密码</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('dashboard') ?>" data-icon="layout-dashboard">返回工作台</a>
            </div>
        </div>
    </header>

    <section class="bm-profile-grid">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">基础资料</span>
                    <h2>基础资料</h2>
                </div>
            </div>
            <form method="post" action="<?= url('profile') ?>" class="bm-form-grid">
                <?= csrf_field() ?>
                <label>
                    <span>用户名</span>
                    <input value="<?= e($user['username']) ?>" disabled>
                </label>
                <label>
                    <span>昵称</span>
                    <input name="nickname" value="<?= e($user['nickname']) ?>" required>
                </label>
                <label>
                    <span>邮箱</span>
                    <input type="email" name="email" value="<?= e($user['email']) ?>" required>
                </label>
                <label>
                    <span>头像 URL</span>
                    <input name="avatar" value="<?= e($user['avatar']) ?>" placeholder="https://example.com/avatar.png">
                </label>
                <label class="bm-span-all">
                    <span>API 访问 IP 白名单</span>
                    <textarea name="api_allowed_ips" rows="4" placeholder="每行一个服务器出口 IP，留空表示不限制"><?= e(isset($user['api_allowed_ips']) ? $user['api_allowed_ips'] : '') ?></textarea>
                    <small>做同系统对接时，建议只填写主站服务器出口 IP。填写后，其他 IP 即使拿到 Token 也不能调用 API。</small>
                </label>
                <label>
                    <span>注册时间</span>
                    <input value="<?= e($user['created_at']) ?>" disabled>
                </label>
                <label>
                    <span>上次登录</span>
                    <input value="<?= e($user['last_login_time'] ?: '暂无记录') ?>" disabled>
                </label>
                <div class="bm-form-actions bm-span-all">
                    <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存资料</button>
                </div>
            </form>
        </article>

        <aside class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">接口安全</span>
                    <h2>接口安全</h2>
                </div>
            </div>
            <div class="bm-token-box">
                <span>当前 API Token</span>
                <code><?= e($user['api_token']) ?></code>
            </div>
            <p class="bm-muted">重置后旧 Token 会立即失效。已接入 PicGo、ShareX、自动化脚本的设备，需要同步替换为新的 Token。</p>
            <form method="post" action="<?= url('profile/api-token/reset') ?>" class="confirm-form" data-confirm="确认重置 API Token？旧 Token 将立即失效。">
                <?= csrf_field() ?>
                <button class="bm-btn bm-btn-danger" type="submit" data-icon="refresh-cw">重置 Token</button>
            </form>
        </aside>
    </section>
</section>
