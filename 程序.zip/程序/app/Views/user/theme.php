<?php
$currentStyle = isset($user['frontend_theme_style']) && in_array($user['frontend_theme_style'], ['classic', 'anime'], true)
    ? $user['frontend_theme_style']
    : (in_array($defaultStyle, ['classic', 'anime'], true) ? $defaultStyle : 'classic');
$styles = [
    'classic' => [
        'title' => '&#x539F;&#x7248;&#x4E3B;&#x9898;',
        'desc' => '&#x4FDD;&#x7559;&#x524D;&#x53F0;&#x9ED8;&#x8BA4;&#x98CE;&#x683C;&#xFF0C;&#x53EA;&#x63D0;&#x5347;&#x5706;&#x89D2;&#x3001;&#x95F4;&#x8DDD;&#x548C;&#x57FA;&#x7840;&#x8212;&#x9002;&#x5EA6;&#x3002;',
    ],
    'anime' => [
        'title' => '&#x4E8C;&#x6B21;&#x5143;&#x53EF;&#x7231;&#x6E38;&#x620F;&#x98CE;',
        'desc' => '&#x6D45;&#x7C89;&#x5976;&#x84DD;&#x3001;&#x6DE1;&#x7D2B;&#x67D4;&#x5149;&#x3001;&#x5706;&#x6DA6;&#x5361;&#x7247;&#x548C;&#x53EF;&#x7231;&#x6697;&#x7EB9;&#xFF0C;&#x5168;&#x7AD9;&#x7EDF;&#x4E00;&#x5207;&#x6362;&#x3002;',
    ],
];
?>

<section class="section-heading compact">
    <p class="eyebrow">&#x754C;&#x9762;&#x4E3B;&#x9898;</p>
    <h1>&#x754C;&#x9762;&#x4E3B;&#x9898;&#x8BBE;&#x7F6E;</h1>
    <p>&#x9009;&#x62E9;&#x540E;&#x4F1A;&#x540C;&#x65F6;&#x4FDD;&#x5B58;&#x5230;&#x8D26;&#x53F7;&#x548C;&#x6D4F;&#x89C8;&#x5668;&#x7F13;&#x5B58;&#xFF0C;&#x5237;&#x65B0;&#x9875;&#x9762;&#x3001;&#x91CD;&#x65B0;&#x767B;&#x5F55;&#x548C;&#x6362;&#x8BBE;&#x5907;&#x767B;&#x5F55;&#x90FD;&#x4F1A;&#x81EA;&#x52A8;&#x6CBF;&#x7528;&#x3002;</p>
</section>

<form method="post" action="<?= url('theme') ?>" class="form-section glass theme-save-form" data-theme-saved-message="&#x4E3B;&#x9898;&#x5207;&#x6362;&#x6210;&#x529F;&#xFF5E;">
    <?= csrf_field() ?>
    <input type="hidden" id="front-theme-style" name="frontend_theme_style" value="<?= e($currentStyle) ?>">
    <div class="theme-choice-grid">
        <?php foreach ($styles as $value => $item): ?>
            <button class="theme-style-option theme-preview-card <?= $currentStyle === $value ? 'active' : '' ?>" type="button" data-theme-style="<?= e($value) ?>" data-target-select="#front-theme-style">
                <span class="theme-preview-swatch <?= e($value) ?>"></span>
                <b><?= $item['title'] ?></b>
                <small><?= $item['desc'] ?></small>
            </button>
        <?php endforeach; ?>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit" data-icon="save">&#x4FDD;&#x5B58;&#x6211;&#x7684;&#x4E3B;&#x9898;</button>
        <a class="btn btn-ghost" href="<?= url('dashboard') ?>" data-icon="arrow-left">&#x8FD4;&#x56DE;&#x4E2A;&#x4EBA;&#x4E2D;&#x5FC3;</a>
    </div>
</form>
