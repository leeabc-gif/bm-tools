<?php
$user = isset($user) && is_array($user) ? $user : [];
$logs = isset($logs) && is_array($logs) ? $logs : [];
$apiApps = isset($apiApps) && is_array($apiApps) ? $apiApps : [];
$apiScopes = isset($apiScopes) && is_array($apiScopes) ? $apiScopes : [];
$apiAppOneTimeToken = isset($apiAppOneTimeToken) && is_array($apiAppOneTimeToken) ? $apiAppOneTimeToken : null;
$apiUsageSummary = isset($apiUsageSummary) && is_array($apiUsageSummary) ? $apiUsageSummary : ['total' => 0, 'success' => 0, 'failed' => 0, 'today' => 0, 'today_failed' => 0, 'success_rate' => 0, 'app_total' => count($apiApps), 'active_apps' => 0, 'last_error' => null];
$apiAppService = isset($apiAppService) ? $apiAppService : null;
$endpoints = isset($endpoints) && is_array($endpoints) ? $endpoints : [
    'upload' => public_url('api/upload'),
    'files' => public_url('api/files'),
    'delete' => public_url('api/delete'),
    'quota' => public_url('api/quota'),
];
$sharexConfig = isset($sharexConfig) && is_array($sharexConfig) ? $sharexConfig : [];
$picgoConfig = isset($picgoConfig) && is_array($picgoConfig) ? $picgoConfig : [];
$token = isset($user['api_token']) ? (string) $user['api_token'] : '';
$allowedIps = !empty($user['api_allowed_ips']) ? str_replace(["\r", "\n"], ' / ', (string) $user['api_allowed_ips']) : '未限制';
$sharexJson = json_encode($sharexConfig, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
$picgoJson = json_encode($picgoConfig, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
$scopeChecked = function ($app, $scope) {
    $value = isset($app['scopes']) ? (string) $app['scopes'] : '';
    $items = array_filter(preg_split('/[\s,;]+/', $value));
    return in_array($scope, $items, true);
};
$stat = function ($stats, $key, $default = 0) {
    return isset($stats[$key]) ? $stats[$key] : $default;
};
$appLogLabel = function ($log) use ($apiAppService) {
    return $apiAppService && method_exists($apiAppService, 'appLabelFromLog') ? $apiAppService->appLabelFromLog($log) : (!empty($log['app_id']) ? '#' . $log['app_id'] : '总 Token');
};
?>
<section class="bm-workspace api-console-v2 api-integration-center">
    <header class="bm-page-hero bm-page-hero-compact api-integration-hero">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">接口接入</span>
            <h1>开放接口接入中心</h1>
            <p>为 PicGo、ShareX、脚本上传和第三方业务系统提供独立接入凭据。建议新接入都使用应用 Token，按场景限制权限和 IP，排查问题会更清楚。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('api/sharex-config') ?>" data-icon="download">下载 ShareX 配置</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('api/picgo-config') ?>" data-icon="download-cloud">下载 PicGo 配置</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('profile') ?>" data-icon="shield-check">管理总 Token</a>
            </div>
        </div>
    </header>

    <?php if ($apiAppOneTimeToken): ?>
        <section class="bm-card api-token-box">
            <div class="bm-card-head">
                <div><span class="bm-eyebrow">新凭据</span><h2>请立即复制应用 Token</h2></div>
                <button class="bm-btn bm-btn-primary copy-text-btn" type="button" data-copy-text="<?= e($apiAppOneTimeToken['token']) ?>" data-icon="copy">复制 Token</button>
            </div>
            <div class="bm-token-box">
                <span><?= e(isset($apiAppOneTimeToken['name']) ? $apiAppOneTimeToken['name'] : '应用 Token') ?></span>
                <code><?= e($apiAppOneTimeToken['token']) ?></code>
            </div>
            <p class="bm-muted">明文 Token 只在创建或重置后展示一次。关闭页面后无法再次查看，只能重置生成新的 Token。</p>
        </section>
    <?php endif; ?>

    <section class="api-health-grid">
        <article class="bm-card api-health-card">
            <span>今日调用</span>
            <strong><?= e(number_format((int) $stat($apiUsageSummary, 'today'))) ?></strong>
            <small>失败 <?= e(number_format((int) $stat($apiUsageSummary, 'today_failed'))) ?> 次</small>
        </article>
        <article class="bm-card api-health-card">
            <span>累计成功率</span>
            <strong><?= e($stat($apiUsageSummary, 'success_rate')) ?>%</strong>
            <small><?= e(number_format((int) $stat($apiUsageSummary, 'success'))) ?> 成功 / <?= e(number_format((int) $stat($apiUsageSummary, 'failed'))) ?> 失败</small>
        </article>
        <article class="bm-card api-health-card">
            <span>应用 Token</span>
            <strong><?= e(number_format((int) $stat($apiUsageSummary, 'active_apps'))) ?> / <?= e(number_format((int) $stat($apiUsageSummary, 'app_total'))) ?></strong>
            <small>启用应用 / 全部应用</small>
        </article>
        <article class="bm-card api-health-card <?= !empty($apiUsageSummary['last_error']) ? 'is-warn' : 'is-ok' ?>">
            <span>最近失败</span>
            <strong><?= !empty($apiUsageSummary['last_error']) ? e($apiUsageSummary['last_error']['status_code']) : '无' ?></strong>
            <small><?= !empty($apiUsageSummary['last_error']) ? e(text_limit($apiUsageSummary['last_error']['message'], 44)) : '当前没有失败记录' ?></small>
        </article>
    </section>

    <section class="bm-card api-quick-card">
        <div class="bm-card-head">
            <div><span class="bm-eyebrow">接入参数</span><h2>基础接入参数</h2></div>
            <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-copy-selector="input[readonly]" data-icon="copy">复制本页参数</button>
        </div>
        <div class="bm-api-grid">
            <label>总 API Token<input readonly value="<?= e($token) ?>"></label>
            <label>上传接口<input readonly value="<?= e($endpoints['upload']) ?>"></label>
            <label>文件列表接口<input readonly value="<?= e($endpoints['files']) ?>"></label>
            <label>删除接口<input readonly value="<?= e($endpoints['delete']) ?>"></label>
            <label>容量接口<input readonly value="<?= e($endpoints['quota']) ?>"></label>
            <label>总 Token IP 白名单<input readonly value="<?= e($allowedIps) ?>"></label>
        </div>
        <div class="api-integrate-note">
            <span><i data-lucide="info"></i></span>
            <p>上传使用 <b>POST multipart/form-data</b>，文件字段固定为 <code>file</code>，请求头携带 <code>X-API-Token</code>，成功后读取 <code>data.url</code>。</p>
        </div>
    </section>

    <section class="bm-card api-apps-card" id="apiApps">
        <div class="bm-card-head">
            <div><span class="bm-eyebrow">应用凭据</span><h2>开放平台应用</h2></div>
            <span class="bm-muted-text">每个应用可以独立权限、独立 IP 白名单、独立停用。</span>
        </div>
        <form method="post" action="<?= url('api/apps/create') ?>" class="form-grid two">
            <?= csrf_field() ?>
            <label>应用名称
                <input name="name" maxlength="80" value="<?= e(old('name')) ?>" placeholder="例如：PicGo 桌面端 / 业务系统同步">
            </label>
            <label>IP 白名单
                <textarea name="allowed_ips" rows="3" placeholder="每行一个服务器出口 IP，留空表示不限制"><?= e(old('allowed_ips')) ?></textarea>
            </label>
            <div class="bm-span-all bm-check-row-group">
                <?php foreach ($apiScopes as $scope => $label): ?>
                    <label class="bm-check-row"><input type="checkbox" name="scopes[]" value="<?= e($scope) ?>" checked> <?= e($label) ?></label>
                <?php endforeach; ?>
            </div>
            <div class="bm-form-actions bm-span-all">
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="plus">创建应用 Token</button>
            </div>
        </form>

        <div class="bm-record-list api-app-list">
            <?php if (!$apiApps): ?><div class="bm-empty-line">暂无应用 Token。建议为 PicGo、ShareX、业务系统分别创建，后续排查调用问题更清楚。</div><?php endif; ?>
            <?php foreach ($apiApps as $app): ?>
                <?php
                $stats = isset($app['stats']) && is_array($app['stats']) ? $app['stats'] : [];
                $health = isset($app['health']) && is_array($app['health']) ? $app['health'] : ['tone' => 'idle', 'label' => '未调用', 'hint' => '等待第一次请求。'];
                $lastError = isset($stats['last_error']) && is_array($stats['last_error']) ? $stats['last_error'] : null;
                ?>
                <article class="bm-record-card is-compact api-app-card">
                    <div class="api-app-status-row">
                        <div>
                            <span class="status-pill api-health-<?= e($health['tone']) ?>"><?= e($health['label']) ?></span>
                            <small><?= e($health['hint']) ?></small>
                        </div>
                        <div class="api-app-mini-stats">
                            <span><b><?= e(number_format((int) $stat($stats, 'today'))) ?></b>今日</span>
                            <span><b><?= e(number_format((int) $stat($stats, 'total'))) ?></b>累计</span>
                            <span><b><?= e($stat($stats, 'success_rate')) ?>%</b>成功率</span>
                        </div>
                    </div>
                    <?php if ($lastError): ?>
                        <div class="api-last-error">
                            <b>最近失败</b>
                            <span><?= e($lastError['endpoint']) ?> / HTTP <?= e($lastError['status_code']) ?> / <?= e(text_limit($lastError['message'], 80)) ?></span>
                        </div>
                    <?php endif; ?>
                    <form method="post" action="<?= url('api/apps/update') ?>" class="form-grid two">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($app['id']) ?>">
                        <label>应用名称<input name="name" maxlength="80" value="<?= e($app['name']) ?>"></label>
                        <label>IP 白名单<textarea name="allowed_ips" rows="3"><?= e(isset($app['allowed_ips']) ? $app['allowed_ips'] : '') ?></textarea></label>
                        <div class="bm-span-all bm-check-row-group">
                            <?php foreach ($apiScopes as $scope => $label): ?>
                                <label class="bm-check-row"><input type="checkbox" name="scopes[]" value="<?= e($scope) ?>" <?= $scopeChecked($app, $scope) ? 'checked' : '' ?>> <?= e($label) ?></label>
                            <?php endforeach; ?>
                            <label class="bm-check-row"><input type="checkbox" name="status" value="1" <?= !empty($app['status']) ? 'checked' : '' ?>> 启用</label>
                        </div>
                        <div class="bm-record-meta bm-span-all">
                            <span><b>最近使用</b><?= e(!empty($app['last_used_at']) ? $app['last_used_at'] : '未使用') ?></span>
                            <span><b>创建时间</b><?= e($app['created_at']) ?></span>
                            <span><b>最近调用</b><?= e($stat($stats, 'last_called_at', '未调用') ?: '未调用') ?></span>
                            <span><b>失败次数</b><?= e(number_format((int) $stat($stats, 'failed'))) ?></span>
                        </div>
                        <div class="bm-form-actions bm-span-all"><button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存</button></div>
                    </form>
                    <div class="bm-form-actions bm-span-all">
                            <form method="post" action="<?= url('api/apps/rotate') ?>" class="confirm-form" data-confirm="确认重置这个应用 Token 吗？旧 Token 会立即失效。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($app['id']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="refresh-cw">重置 Token</button>
                            </form>
                            <form method="post" action="<?= url('api/apps/delete') ?>" class="confirm-form" data-confirm="确认删除这个应用 Token 吗？删除后无法恢复。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($app['id']) ?>">
                                <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除</button>
                            </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="api-integration-grid">
        <article class="bm-card api-tool-card">
            <div class="bm-card-head">
                <div><span class="bm-eyebrow">PicGo</span><h2>PicGo 接入</h2></div>
                <button class="bm-btn bm-btn-soft copy-text-btn" type="button" data-copy-text="<?= e($picgoJson) ?>" data-icon="copy">复制配置</button>
            </div>
            <ol class="api-step-list">
                <li>安装 PicGo 的自定义上传插件。</li>
                <li>上传地址填写本页“上传接口”。</li>
                <li>文件字段填写 <code>file</code>，Header 填写 <code>X-API-Token</code>。</li>
                <li>返回链接字段填写 <code>data.url</code>。</li>
            </ol>
            <pre class="bm-code-block"><?= e($picgoJson) ?></pre>
        </article>

        <article class="bm-card api-tool-card">
            <div class="bm-card-head">
                <div><span class="bm-eyebrow">ShareX</span><h2>ShareX 接入</h2></div>
                <button class="bm-btn bm-btn-soft copy-text-btn" type="button" data-copy-text="<?= e($sharexJson) ?>" data-icon="copy">复制配置</button>
            </div>
            <ol class="api-step-list">
                <li>打开 ShareX，进入 Destinations 的自定义上传器。</li>
                <li>导入下载的 <code>bmtools-sharex.sxcu</code>。</li>
                <li>选择图片或文件上传目标为该自定义上传器。</li>
                <li>测试上传后，结果应返回平台外链。</li>
            </ol>
            <pre class="bm-code-block"><?= e($sharexJson) ?></pre>
        </article>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div><span class="bm-eyebrow">脚本示例</span><h2>脚本调用示例</h2></div>
            <button class="bm-btn bm-btn-soft copy-text-btn" type="button" data-copy-text="curl -X POST &quot;<?= e($endpoints['upload']) ?>&quot; -H &quot;X-API-Token: <?= e($token) ?>&quot; -F &quot;type=image&quot; -F &quot;file=@demo.jpg&quot;" data-icon="copy">复制上传命令</button>
        </div>
        <pre class="bm-code-block">curl -X POST "<?= e($endpoints['upload']) ?>" \
  -H "X-API-Token: <?= e($token) ?>" \
  -F "type=image" \
  -F "file=@demo.jpg"

curl -X POST "<?= e($endpoints['files']) ?>" \
  -H "X-API-Token: <?= e($token) ?>" \
  -d "page=1&limit=20&type=image"

curl -X POST "<?= e($endpoints['delete']) ?>" \
  -H "X-API-Token: <?= e($token) ?>" \
  -d "id=文件ID"

curl -X POST "<?= e($endpoints['quota']) ?>" \
  -H "X-API-Token: <?= e($token) ?>"</pre>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div><span class="bm-eyebrow">调用记录</span><h2>最近 API 调用</h2></div>
            <span class="bm-muted-text">保留最近 100 条，失败记录可用于排查 Token、IP 白名单、限流和上传错误。</span>
        </div>
        <div class="bm-record-list">
            <?php if (!$logs): ?><div class="bm-empty-line">暂无 API 调用记录。</div><?php endif; ?>
            <?php foreach ($logs as $log): ?>
                <article class="bm-record-card is-compact">
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= !empty($log['is_success']) ? 'check' : 'x' ?>"></i></span>
                        <div>
                            <strong><?= e($log['endpoint']) ?></strong>
                            <small><?= e($log['method']) ?> / <?= e($log['ip']) ?> / <?= e($log['created_at']) ?></small>
                        </div>
                    </div>
                    <div class="bm-record-meta">
                        <span><b>状态码</b><?= e($log['status_code']) ?></span>
                        <span><b>应用</b><?= e($appLogLabel($log)) ?></span>
                        <span><b>结果</b><?= !empty($log['is_success']) ? '成功' : '失败' ?></span>
                        <span><b>信息</b><?= e($log['message']) ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>
