<?php
$edit = isset($editSubsite) && $editSubsite ? $editSubsite : null;
$service = isset($service) ? $service : new \App\Services\SubsiteService();
$accessLogs = isset($accessLogs) ? $accessLogs : [];
$domainDiagnostic = flash('subsite_domain_diagnostic', null);
$suffixes = isset($suffixes) ? $suffixes : $service->suffixes();
$defaultSuffix = isset($defaultSuffix) ? $defaultSuffix : $service->defaultSuffix();
$domainConfig = isset($domainConfig) ? $domainConfig : $service->domainConfigSummary();
$statusClass = function ($status) {
    if ($status === 'active') return 'ok';
    if ($status === 'pending') return 'soft';
    if ($status === 'suspended' || $status === 'rejected') return 'bad';
    return 'muted';
};
$diagnosticSummary = function (array $site) use ($service) {
    $diagnostic = $service->decodeDomainDiagnostic($site);
    if (!$diagnostic || empty($diagnostic['checks']) || !is_array($diagnostic['checks'])) {
        return null;
    }
    $checks = $diagnostic['checks'];
    $total = count($checks);
    $passed = 0;
    $firstIssue = '';
    foreach ($checks as $check) {
        $status = isset($check['status']) ? (string) $check['status'] : '';
        if ($status === 'ok' || $status === 'soft') {
            $passed++;
        } elseif ($firstIssue === '') {
            $firstIssue = isset($check['message']) ? (string) $check['message'] : '';
        }
    }
    $tone = !empty($diagnostic['ok']) ? 'ok' : ($firstIssue === '' ? 'soft' : 'warn');
    return [
        'tone' => $tone,
        'passed' => $passed,
        'total' => max(1, $total),
        'time' => isset($site['domain_checked_at']) && $site['domain_checked_at'] ? $site['domain_checked_at'] : (isset($diagnostic['checked_at']) ? $diagnostic['checked_at'] : ''),
        'message' => $firstIssue !== '' ? text_limit($firstIssue, 80, '...') : '域名接入状态正常。',
    ];
};
$field = function ($key, $default = '') use ($edit) {
    if (old($key, '') !== '') return old($key);
    return $edit && isset($edit[$key]) ? $edit[$key] : $default;
};
$selectedSuffix = $defaultSuffix;
if ($edit && !empty($edit['platform_domain'])) {
    $selectedSuffix = $service->suffixFromPlatformDomain($edit['platform_domain']);
}
$selectedSuffix = old('platform_suffix', $selectedSuffix);
$previewSlug = $field('slug', $edit ? $edit['slug'] : '');
$previewDomain = $previewSlug ? $service->platformDomain($previewSlug, $selectedSuffix) : ($selectedSuffix ? 'your-name.' . $selectedSuffix : '');
$cnameTarget = isset($domainConfig['cname_target']) ? $domainConfig['cname_target'] : $service->cnameTarget();
$customDomainHint = isset($domainConfig['custom_domain_hint']) && $domainConfig['custom_domain_hint'] !== '' ? $domainConfig['custom_domain_hint'] : ($cnameTarget ? 'CNAME ' . $cnameTarget : 'CNAME 到平台域名');
?>

<section class="bm-workspace subsite-console">
    <header class="bm-page-hero bm-page-hero-compact subsite-hero">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">分站管理</span>
            <h1>我的分站</h1>
            <p>开通一个独立访问入口，把你公开的图片、网盘仓库和个人资源整理成自己的资源站。可使用平台二级域名，也可以绑定自己的域名。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="#subsite-editor" data-icon="<?= $edit ? 'pencil' : 'plus' ?>"><?= $edit ? '编辑当前分站' : '创建分站' ?></a>
                <a class="bm-btn bm-btn-soft" href="<?= url('repository') ?>" data-icon="library">分享仓库</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('files') ?>" data-icon="image">公开资源</a>
            </div>
        </div>
        <aside class="subsite-plan-card">
            <span>当前权益</span>
            <strong><?= e($usedCount) ?> / <?= e($limitCount) ?></strong>
            <p><?= e($packageInfo['name']) ?> · <?= !empty($packageInfo['allow']) ? '已开通分站权益' : '未开通分站权益' ?></p>
        </aside>
    </header>

    <?php if (!$service->enabled()): ?>
        <section class="bm-inline-notice">
            <i data-lucide="lock"></i>
            <div><strong>主站暂未开放分站</strong><span>管理员开启分站功能后，你可以在这里创建自己的资源站。</span></div>
            <a href="<?= url('dashboard') ?>">返回工作台</a>
        </section>
    <?php elseif (empty($packageInfo['allow'])): ?>
        <section class="bm-inline-notice">
            <i data-lucide="badge-dollar-sign"></i>
            <div><strong>当前套餐未包含分站权益</strong><span>升级套餐后可以创建分站并绑定自有域名。</span></div>
            <a href="<?= url('packages') ?>">查看套餐</a>
        </section>
    <?php endif; ?>

    <?php if ($domainDiagnostic): ?>
        <section class="bm-card subsite-diagnostic-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">域名检测</span>
                    <h2>域名接入检测结果</h2>
                    <p>
                        <?= e(isset($domainDiagnostic['site']['name']) ? $domainDiagnostic['site']['name'] : '分站') ?>
                        · <?= e(isset($domainDiagnostic['checked_at']) ? $domainDiagnostic['checked_at'] : now()) ?>
                    </p>
                </div>
                <?php if (!empty($domainDiagnostic['public_url'])): ?>
                    <a class="bm-btn bm-btn-soft" href="<?= e($domainDiagnostic['public_url']) ?>" target="_blank" data-icon="external-link">打开检测地址</a>
                <?php endif; ?>
            </div>
            <div class="subsite-diagnostic-grid">
                <?php foreach ((array) (isset($domainDiagnostic['checks']) ? $domainDiagnostic['checks'] : []) as $check): ?>
                    <article class="subsite-diagnostic-item <?= e(isset($check['status']) ? $check['status'] : 'soft') ?>">
                        <span><?= e(isset($check['label']) ? $check['label'] : '检测项') ?></span>
                        <p><?= e(isset($check['message']) ? $check['message'] : '') ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="subsite-layout-grid">
        <article class="bm-card subsite-list-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">分站列表</span>
                    <h2>分站列表</h2>
                </div>
                <a class="bm-text-link" href="<?= url('subsites') ?>">新建</a>
            </div>

            <div class="subsite-card-list">
                <?php if (!$subsites): ?>
                    <div class="bm-empty-state">
                        <i data-lucide="globe-2"></i>
                        <strong>还没有分站</strong>
                        <span>创建后，你可以把公开资源整理成一个独立访问页面。</span>
                    </div>
                <?php endif; ?>
                <?php foreach ($subsites as $site): ?>
                    <?php $publicUrl = $service->publicUrlFor($site); ?>
                    <?php $checkSummary = $diagnosticSummary($site); ?>
                    <article class="subsite-row-card <?= $edit && (int) $edit['id'] === (int) $site['id'] ? 'editing' : '' ?>">
                        <div>
                            <h3><?= e($site['name']) ?><?= !empty($site['is_default']) ? ' · 默认' : '' ?></h3>
                            <p><?= e($site['subtitle'] ?: $site['platform_domain']) ?></p>
                        </div>
                        <div class="subsite-row-meta">
                            <span class="status-pill <?= e($statusClass($site['status'])) ?>"><?= e($service->statusLabel($site['status'])) ?></span>
                            <span><?= e((int) $site['view_count']) ?> 次访问</span>
                        </div>
                        <div class="subsite-domain-lines">
                            <code><?= e($site['platform_domain']) ?></code>
                            <?php if ($site['custom_domain']): ?><code><?= e($site['custom_domain']) ?> · <?= e($service->domainStatusLabel($site['custom_domain_status'])) ?></code><?php endif; ?>
                        </div>
                        <div class="subsite-dns-guide">
                            <span>平台域名：<code><?= e($site['platform_domain']) ?></code></span>
                            <?php if ($site['custom_domain']): ?>
                                <span>CNAME：<code><?= e($site['custom_domain']) ?></code> 指向 <code><?= e($cnameTarget ?: $site['platform_domain']) ?></code></span>
                                <span>TXT 验证：<code>_bmtools</code> 或 <code>@</code>，记录值 <code><?= e($site['verification_token']) ?></code></span>
                            <?php else: ?>
                                <span>需要品牌域名时，在编辑区填写自有域名，然后按接入提示完成 DNS 配置。</span>
                            <?php endif; ?>
                        </div>
                        <?php if ($checkSummary): ?>
                            <div class="subsite-check-mini <?= e($checkSummary['tone']) ?>">
                                <b>最近检测<?= $checkSummary['time'] ? ' · ' . e($checkSummary['time']) : '' ?></b>
                                <span><?= e($checkSummary['passed']) ?>/<?= e($checkSummary['total']) ?> 步通过 · <?= e($checkSummary['message']) ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="subsite-row-actions">
                            <a class="bm-btn bm-btn-soft" href="<?= url('subsites?id=' . $site['id']) ?>" data-icon="pencil">编辑</a>
                            <?php if ($site['status'] === 'active'): ?><a class="bm-btn bm-btn-soft" href="<?= e($publicUrl) ?>" target="_blank" data-icon="external-link">访问</a><?php endif; ?>
                            <form method="post" action="<?= url('subsites/check') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="radar">检测域名</button>
                            </form>
                            <form method="post" action="<?= url('subsites/delete') ?>" class="confirm-form" data-confirm="确认删除这个分站吗？访问记录也会删除。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="trash-2">删除</button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </article>

        <aside class="bm-card subsite-editor-card" id="subsite-editor">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">基础信息</span>
                    <h2><?= $edit ? '编辑分站' : '创建分站' ?></h2>
                </div>
                <?php if ($edit): ?><a class="bm-text-link" href="<?= url('subsites') ?>">取消编辑</a><?php endif; ?>
            </div>

            <?php if (!$canCreate && !$edit): ?>
                <div class="bm-empty-state">
                    <i data-lucide="circle-alert"></i>
                    <strong>暂时不能创建新的分站</strong>
                    <span>可能是套餐额度已用完，或分站功能尚未开启。</span>
                    <a class="bm-btn bm-btn-primary" href="<?= url('packages') ?>" data-icon="arrow-up-right">查看套餐</a>
                </div>
            <?php else: ?>
                <form method="post" action="<?= url('subsites/save') ?>" class="bm-form-grid subsite-form">
                    <?= csrf_field() ?>
                    <?php if ($edit): ?><input type="hidden" name="id" value="<?= e($edit['id']) ?>"><?php endif; ?>
                    <label>
                        <span>分站名称</span>
                        <input name="name" value="<?= e($field('name')) ?>" maxlength="80" required placeholder="例如：小明的资源站">
                    </label>
                    <label>
                        <span>分站标识</span>
                        <input name="slug" value="<?= e($field('slug')) ?>" maxlength="40" required placeholder="xiaoming">
                        <small>用于生成平台域名：<?= e($previewDomain ?: 'your-name.example.com') ?></small>
                    </label>
                    <?php if (count($suffixes) > 1): ?>
                        <label>
                            <span>平台域名后缀</span>
                            <select name="platform_suffix">
                                <?php foreach ($suffixes as $suffix): ?>
                                    <option value="<?= e($suffix) ?>" <?= $selectedSuffix === $suffix ? 'selected' : '' ?>><?= e($suffix) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small>保存后会生成“分站标识.所选后缀”的访问地址。</small>
                        </label>
                    <?php elseif ($selectedSuffix): ?>
                        <label>
                            <span>平台域名后缀</span>
                            <input value="<?= e($selectedSuffix) ?>" readonly>
                            <input type="hidden" name="platform_suffix" value="<?= e($selectedSuffix) ?>">
                            <small>由主站统一配置。</small>
                        </label>
                    <?php endif; ?>
                    <label>
                        <span>站点标题</span>
                        <input name="title" value="<?= e($field('title')) ?>" maxlength="120" placeholder="展示在分站首页">
                    </label>
                    <label>
                        <span>主题色</span>
                        <input name="theme_color" type="color" value="<?= e($field('theme_color', '#2563EB')) ?>">
                    </label>
                    <label class="bm-span-all">
                        <span>副标题</span>
                        <input name="subtitle" value="<?= e($field('subtitle')) ?>" maxlength="240" placeholder="一句话介绍你的分站">
                    </label>
                    <label class="bm-span-all">
                        <span>首屏标题</span>
                        <input name="hero_title" value="<?= e($field('hero_title')) ?>" maxlength="160" placeholder="例如：我的公开资源与项目归档">
                    </label>
                    <label class="bm-span-all">
                        <span>首屏描述</span>
                        <textarea name="hero_description" rows="3" maxlength="360" placeholder="告诉访客这里可以看到什么内容"><?= e($field('hero_description')) ?></textarea>
                    </label>
                    <label class="bm-span-all">
                        <span>Logo URL</span>
                        <input name="logo" value="<?= e($field('logo')) ?>" maxlength="800" placeholder="https://example.com/logo.png">
                    </label>
                    <?php if ($customDomainEnabled): ?>
                        <label class="bm-span-all">
                            <span>自有域名</span>
                            <input name="custom_domain" value="<?= e($field('custom_domain')) ?>" maxlength="180" placeholder="site.example.com">
                            <small>建议 <?= e($customDomainHint) ?>。保存后后台可检测 DNS、TXT 和访问链路。</small>
                        </label>
                        <div class="subsite-domain-help bm-span-all">
                            <strong>自有域名接入记录</strong>
                            <span>CNAME 目标：<code><?= e($cnameTarget ?: ($previewDomain ?: 'your-name.example.com')) ?></code></span>
                            <span>TXT 验证：主机记录 <code>_bmtools</code> 或 <code>@</code>，记录值保存后会在分站卡片中显示。</span>
                        </div>
                    <?php endif; ?>
                    <label class="bm-span-all">
                        <span>公告</span>
                        <textarea name="announcement" rows="2" maxlength="500" placeholder="可选，显示在分站首页"><?= e($field('announcement')) ?></textarea>
                    </label>
                    <label>
                        <span>联系邮箱</span>
                        <input name="contact_email" type="email" value="<?= e($field('contact_email')) ?>" maxlength="120" placeholder="hello@example.com">
                    </label>
                    <label>
                        <span>备案/页脚文本</span>
                        <input name="icp_text" value="<?= e($field('icp_text')) ?>" maxlength="120" placeholder="可选">
                    </label>
                    <label class="inline-check bm-span-all">
                        <?php $defaultChecked = (string) $field('is_default', '0'); ?>
                        <input type="checkbox" name="is_default" <?= in_array($defaultChecked, ['1', 'on', 'yes'], true) ? 'checked' : '' ?>> 设为默认分站
                    </label>
                    <div class="bm-form-actions bm-span-all">
                        <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存分站</button>
                    </div>
                </form>
            <?php endif; ?>
        </aside>
    </section>

    <section class="bm-card subsite-help-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">DNS</span>
                <h2>域名接入说明</h2>
            </div>
        </div>
        <div class="subsite-help-grid">
            <article>
                <b>平台域名</b>
                <p>管理员配置域名后缀后，用户分站会自动生成 <code>标识.后缀</code> 的访问地址。</p>
            </article>
            <article>
                <b>自有域名</b>
                <p>把自己的域名 <?= e($customDomainHint) ?>，再添加 TXT 所有权记录。后台检测会告诉你 DNS、TXT、HTTP/HTTPS 哪一步未通过。</p>
            </article>
            <article>
                <b>公开内容</b>
                <p>分站首页展示你公开的图床文件和已开放的分享仓库，私密文件不会出现在分站。</p>
            </article>
        </div>
    </section>

    <section class="bm-card subsite-access-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">访问记录</span>
                <h2>最近访问记录</h2>
            </div>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>分站</th>
                    <th>访问域名</th>
                    <th>路径</th>
                    <th>IP</th>
                    <th>时间</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($accessLogs as $log): ?>
                    <tr>
                        <td data-label="分站"><?= e($log['subsite_name'] ?: '-') ?></td>
                        <td data-label="访问域名"><code><?= e($log['host']) ?></code></td>
                        <td data-label="路径"><small><?= e(text_limit($log['path'], 90, '...')) ?></small></td>
                        <td data-label="IP"><?= e($log['ip']) ?></td>
                        <td data-label="时间"><?= e($log['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$accessLogs): ?>
                    <tr><td colspan="5" class="responsive-table-span">暂无访问记录。</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>
