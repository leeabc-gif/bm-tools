<?php
$cpu = $latest ? (float) $latest['cpu_usage'] : 0;
$memory = $latest ? (float) $latest['memory_usage'] : 0;
$disk = $latest ? (float) $latest['disk_usage'] : 0;
$cpuWidth = max(0, min(100, $cpu));
$memoryWidth = max(0, min(100, $memory));
$diskWidth = max(0, min(100, $disk));
$serverTarget = $server['server_ip'] ?: $server['panel_url'];
?>

<section class="bm-workspace bm-monitor-workspace">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Server Detail</span>
            <h1><?= e($server['name']) ?></h1>
            <p><?= e($serverTarget) ?> · <?= e(status_label($server['status'])) ?> · 最后采集 <?= e($server['last_checked_at'] ?: '等待采集') ?></p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-plain" href="<?= url('monitor') ?>" data-icon="arrow-left">返回列表</a>
                <button class="bm-btn bm-btn-primary collect-btn" data-id="<?= e($server['id']) ?>" data-token="<?= e(csrf_token()) ?>" data-icon="refresh-cw">立即采集</button>
                <a class="bm-btn bm-btn-soft" href="<?= url('alerts?server_id=' . $server['id']) ?>" data-icon="bell-ring">查看告警</a>
            </div>
        </div>
    </header>

    <section class="bm-monitor-detail-grid">
        <article class="bm-card bm-monitor-health">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Health</span>
                    <h2>运行状态</h2>
                </div>
                <span class="bm-state-pill is-status-<?= e($server['status']) ?>"><?= e(status_label($server['status'])) ?></span>
            </div>

            <div class="bm-monitor-metrics is-detail">
                <span><b>CPU</b><em><?= e($cpu) ?>%</em><i><u style="width: <?= e($cpuWidth) ?>%"></u></i></span>
                <span><b>内存</b><em><?= e($memory) ?>%</em><i><u style="width: <?= e($memoryWidth) ?>%"></u></i></span>
                <span><b>磁盘</b><em><?= e($disk) ?>%</em><i><u style="width: <?= e($diskWidth) ?>%"></u></i></span>
                <span><b>在线时长</b><em><?= e($latest ? ($latest['uptime'] ?: '-') : '-') ?></em></span>
            </div>

            <?php if ($latest): ?>
                <div class="bm-service-list is-detail">
                    <span>Nginx <?= e(service_label($latest['nginx_status'])) ?></span>
                    <span>MySQL <?= e(service_label($latest['mysql_status'])) ?></span>
                    <span>PHP <?= e(service_label($latest['php_status'])) ?></span>
                    <span>负载 <?= e($latest['load_avg'] ?: '-') ?></span>
                </div>
            <?php else: ?>
                <div class="bm-inline-notice is-warning">
                    <i data-lucide="info"></i>
                    <div><strong>还没有采集数据</strong><span>点击“立即采集”后，这里会展示服务器实时状态。</span></div>
                </div>
            <?php endif; ?>
        </article>

        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Information</span>
                    <h2>服务器信息</h2>
                </div>
            </div>
            <div class="bm-meta-grid bm-monitor-info-grid">
                <span>服务器名称</span><b><?= e($server['name']) ?></b>
                <span>备注</span><b><?= e($server['remark'] ?: '-') ?></b>
                <span>面板地址</span><b><?= e($server['panel_url']) ?></b>
                <span>服务器 IP</span><b><?= e($server['server_ip'] ?: '-') ?></b>
                <span>分组</span><b><?= e($server['group_name'] ?: '-') ?></b>
                <span>采集频率</span><b><?= e($server['frequency']) ?> 秒</b>
                <span>最后采集</span><b><?= e($server['last_checked_at'] ?: '-') ?></b>
                <span>最近错误</span><b><?= e($server['last_error'] ?: '-') ?></b>
            </div>
        </article>
    </section>

    <section class="bm-card bm-monitor-chart-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Trend</span>
                <h2>监控趋势</h2>
            </div>
            <select id="rangeSelect">
                <option value="1h">1 小时</option>
                <option value="24h">24 小时</option>
                <option value="7d">7 天</option>
            </select>
        </div>
        <div id="monitorChart" class="bm-monitor-chart" data-server="<?= e($server['id']) ?>"></div>
    </section>

    <section class="bm-monitor-detail-grid">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">History</span>
                    <h2>最近采集</h2>
                </div>
            </div>
            <div class="bm-monitor-history-list">
                <?php if (!$history): ?>
                    <div class="bm-empty-line">暂无历史采集数据，请先执行一次立即采集。</div>
                <?php endif; ?>
                <?php foreach ($history as $row): ?>
                    <article>
                        <strong><?= e($row['created_at']) ?></strong>
                        <span>CPU <?= e($row['cpu_usage']) ?>%</span>
                        <span>内存 <?= e($row['memory_usage']) ?>%</span>
                        <span>磁盘 <?= e($row['disk_usage']) ?>%</span>
                        <small>负载 <?= e($row['load_avg'] ?: '-') ?> · 在线 <?= e($row['uptime'] ?: '-') ?></small>
                    </article>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Alerts</span>
                    <h2>最近告警</h2>
                </div>
            </div>
            <div class="bm-alert-list is-compact">
                <?php if (!$alerts): ?>
                    <div class="bm-empty-line">暂无告警记录。</div>
                <?php endif; ?>
                <?php foreach ($alerts as $alert): ?>
                    <article class="bm-alert-card">
                        <header>
                            <span class="bm-state-pill is-level-<?= e($alert['level']) ?>"><?= e(alert_level_label($alert['level'])) ?></span>
                            <small><?= e($alert['created_at']) ?></small>
                        </header>
                        <strong><?= e($alert['title']) ?></strong>
                        <p><?= e($alert['content']) ?></p>
                        <footer>
                            <span><?= e($alert['metric']) ?></span>
                            <span><?= e(alert_status_label($alert['status'])) ?></span>
                        </footer>
                    </article>
                <?php endforeach; ?>
            </div>
        </article>
    </section>
</section>
