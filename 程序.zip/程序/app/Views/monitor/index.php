<section class="bm-workspace monitor-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Monitor Center</span>
            <h1>服务器监控</h1>
            <p>以服务器信息和运行状态为主，集中查看 CPU、内存、硬盘、服务状态、采集时间和告警入口。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('monitor/create') ?>" data-icon="server-cog">添加服务器</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('alerts') ?>" data-icon="bell-ring">告警记录</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>服务器总数</span><strong><?= e($stats['total']) ?></strong><small>已纳入运营监控</small></article>
        <article class="bm-stat-card"><span>在线节点</span><strong><?= e($stats['online']) ?></strong><small>最近一次采集正常</small></article>
        <article class="bm-stat-card <?= $stats['offline'] > 0 ? 'is-warn' : '' ?>"><span>离线节点</span><strong><?= e($stats['offline']) ?></strong><small>需要优先排查连接或服务</small></article>
        <article class="bm-stat-card <?= $stats['unread_alerts'] > 0 ? 'is-warn' : '' ?>"><span>未读告警</span><strong><?= e($stats['unread_alerts']) ?></strong><small>今日告警 <?= e($stats['alerts_today']) ?> 条</small></article>
    </section>

    <section class="bm-card">
        <form method="get" action="<?= url('monitor') ?>" class="bm-filter-bar">
            <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索服务器名称、IP、备注或面板地址">
            <select name="group">
                <option value="">全部分组</option>
                <?php foreach ($groups as $item): ?>
                    <option value="<?= e($item['group_name']) ?>" <?= $filters['group'] === $item['group_name'] ? 'selected' : '' ?>>
                        <?= e($item['group_name']) ?>（<?= e($item['total']) ?>）
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="status">
                <option value="">全部状态</option>
                <option value="online" <?= $filters['status'] === 'online' ? 'selected' : '' ?>>在线</option>
                <option value="offline" <?= $filters['status'] === 'offline' ? 'selected' : '' ?>>离线</option>
                <option value="unknown" <?= $filters['status'] === 'unknown' ? 'selected' : '' ?>>未知</option>
            </select>
            <button class="bm-btn bm-btn-soft" type="submit" data-icon="filter">筛选</button>
            <a class="bm-btn bm-btn-plain" href="<?= url('monitor') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <section class="bm-monitor-list">
        <?php if (!$servers): ?>
            <article class="bm-empty-state">
                <i data-lucide="server"></i>
                <strong>暂无服务器</strong>
                <span>添加宝塔面板服务器后，这里会显示实时状态、服务运行情况、采集时间和告警入口。</span>
                <a class="bm-btn bm-btn-primary" href="<?= url('monitor/create') ?>" data-icon="server-cog">添加第一台服务器</a>
            </article>
        <?php endif; ?>

        <?php foreach ($servers as $server): ?>
            <?php
            $m = $server['latest'];
            $cpu = $m ? (float) $m['cpu_usage'] : 0;
            $memory = $m ? (float) $m['memory_usage'] : 0;
            $disk = $m ? (float) $m['disk_usage'] : 0;
            $cpuWidth = max(0, min(100, $cpu));
            $memoryWidth = max(0, min(100, $memory));
            $diskWidth = max(0, min(100, $disk));
            ?>
            <article class="bm-monitor-card is-status-<?= e($server['status']) ?>">
                <header>
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="server"></i></span>
                        <div>
                            <strong><?= e($server['name']) ?></strong>
                            <small><?= e($server['server_ip'] ?: $server['panel_url']) ?><?= $server['group_name'] ? ' · ' . e($server['group_name']) : '' ?></small>
                        </div>
                    </div>
                    <span class="bm-state-pill is-status-<?= e($server['status']) ?>"><?= e(status_label($server['status'])) ?></span>
                </header>

                <div class="bm-monitor-metrics">
                    <span><b>CPU</b><em><?= e($cpu) ?>%</em><i><u style="width: <?= e($cpuWidth) ?>%"></u></i></span>
                    <span><b>内存</b><em><?= e($memory) ?>%</em><i><u style="width: <?= e($memoryWidth) ?>%"></u></i></span>
                    <span><b>硬盘</b><em><?= e($disk) ?>%</em><i><u style="width: <?= e($diskWidth) ?>%"></u></i></span>
                    <span><b>采集时间</b><em><?= e($server['last_checked_at'] ?: '-') ?></em></span>
                </div>

                <?php if ($m): ?>
                    <div class="bm-service-list">
                        <span>Nginx <?= e(service_label($m['nginx_status'])) ?></span>
                        <span>MySQL <?= e(service_label($m['mysql_status'])) ?></span>
                        <span>PHP <?= e(service_label($m['php_status'])) ?></span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($server['last_error'])): ?>
                    <div class="bm-inline-notice is-warning">
                        <i data-lucide="alert-triangle"></i>
                        <div><strong>最近错误</strong><span><?= e($server['last_error']) ?></span></div>
                    </div>
                <?php endif; ?>

                <div class="bm-monitor-actions">
                    <a class="bm-btn bm-btn-soft" href="<?= url('monitor/' . $server['id']) ?>" data-icon="eye">详情</a>
                    <button class="bm-btn bm-btn-primary collect-btn" data-id="<?= e($server['id']) ?>" data-token="<?= e(csrf_token()) ?>" data-icon="refresh-cw">立即采集</button>
                    <form method="post" action="<?= url('monitor/toggle') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                        <button class="bm-btn bm-btn-soft" type="submit" data-icon="<?= $server['is_enabled'] ? 'pause-circle' : 'play-circle' ?>"><?= $server['is_enabled'] ? '暂停' : '启用' ?></button>
                    </form>
                    <form method="post" action="<?= url('monitor/delete') ?>" class="confirm-form" data-confirm="确认删除该监控服务器吗？历史采集数据和告警也会一起删除。">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                        <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
