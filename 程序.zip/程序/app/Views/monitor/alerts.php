<?php $isAdminAlerts = !empty($isAdminAlerts); ?>
<section class="bm-workspace bm-monitor-workspace">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Alerts</span>
            <h1>告警记录</h1>
            <p><?= $isAdminAlerts ? '集中查看平台服务器离线、资源超限和服务异常。未读告警会优先处理，确认排查后可标记为已处理。' : '集中查看你自己添加的服务器告警，平台服务器告警不会混在这里。未读告警可标记为已读或已处理。' ?></p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-plain" href="<?= url($isAdminAlerts ? 'monitor' : 'servers') ?>" data-icon="<?= $isAdminAlerts ? 'activity' : 'server-cog' ?>"><?= $isAdminAlerts ? '返回平台监控' : '返回服务器管家' ?></a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>告警总数</span><strong><?= e($stats['total']) ?></strong><small>历史告警记录</small></article>
        <article class="bm-stat-card <?= $stats['unread'] > 0 ? 'is-warn' : '' ?>"><span>未读告警</span><strong><?= e($stats['unread']) ?></strong><small>需要尽快检查</small></article>
        <article class="bm-stat-card"><span>已读告警</span><strong><?= e($stats['read']) ?></strong><small>已查看但未关闭</small></article>
        <article class="bm-stat-card"><span>已处理</span><strong><?= e($stats['resolved']) ?></strong><small>已确认或处理完成</small></article>
    </section>

    <section class="bm-card">
        <form method="get" action="<?= url('alerts') ?>" class="bm-filter-bar">
            <select name="status">
                <option value="">全部状态</option>
                <option value="unread" <?= $filters['status'] === 'unread' ? 'selected' : '' ?>>未读</option>
                <option value="read" <?= $filters['status'] === 'read' ? 'selected' : '' ?>>已读</option>
                <option value="resolved" <?= $filters['status'] === 'resolved' ? 'selected' : '' ?>>已处理</option>
            </select>
            <select name="level">
                <option value="">全部级别</option>
                <option value="info" <?= $filters['level'] === 'info' ? 'selected' : '' ?>>信息</option>
                <option value="warning" <?= $filters['level'] === 'warning' ? 'selected' : '' ?>>警告</option>
                <option value="danger" <?= $filters['level'] === 'danger' ? 'selected' : '' ?>>严重</option>
            </select>
            <select name="server_id">
                <option value="0">全部服务器</option>
                <?php foreach ($servers as $server): ?>
                    <option value="<?= e($server['id']) ?>" <?= (int) $filters['server_id'] === (int) $server['id'] ? 'selected' : '' ?>><?= e($server['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button class="bm-btn bm-btn-soft" type="submit" data-icon="filter">筛选</button>
            <a class="bm-btn bm-btn-plain" href="<?= url('alerts') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <section class="bm-alert-list">
        <?php if (!$alerts): ?>
            <article class="bm-empty-state">
                <i data-lucide="shield-check"></i>
                <strong>暂无告警记录</strong>
                <span>当前筛选条件下没有告警。服务器采集正常时，这里会保持干净。</span>
            </article>
        <?php endif; ?>

        <?php foreach ($alerts as $alert): ?>
            <article class="bm-alert-card">
                <header>
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="bell-ring"></i></span>
                        <div>
                            <strong><?= e($alert['title']) ?></strong>
                            <small><?= e($alert['server_name'] ?: '-') ?> · <?= e($alert['metric']) ?></small>
                        </div>
                    </div>
                    <div class="bm-alert-badges">
                        <span class="bm-state-pill is-level-<?= e($alert['level']) ?>"><?= e(alert_level_label($alert['level'])) ?></span>
                        <span class="bm-state-pill is-status-<?= e($alert['status']) ?>"><?= e(alert_status_label($alert['status'])) ?></span>
                    </div>
                </header>
                <p><?= e($alert['content']) ?></p>
                <footer>
                    <span><?= e($alert['created_at']) ?></span>
                    <div class="bm-alert-actions">
                        <?php if ($alert['status'] === 'unread'): ?>
                            <form method="post" action="<?= url('alerts/read') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($alert['id']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="mail-open">标记已读</button>
                            </form>
                        <?php endif; ?>
                        <?php if ($alert['status'] !== 'resolved'): ?>
                            <form method="post" action="<?= url('alerts/resolve') ?>" class="confirm-form" data-confirm="确认将该告警标记为已处理吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($alert['id']) ?>">
                                <button class="bm-btn bm-btn-primary" type="submit" data-icon="check-circle-2">标记已处理</button>
                            </form>
                        <?php else: ?>
                            <span class="bm-state-pill is-status-resolved">已处理</span>
                        <?php endif; ?>
                    </div>
                </footer>
            </article>
        <?php endforeach; ?>
    </section>
</section>
