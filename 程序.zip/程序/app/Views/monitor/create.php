<section class="bm-workspace bm-monitor-workspace">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Add Monitor</span>
            <h1>添加服务器</h1>
            <p>填写宝塔面板地址和 API 密钥后，可以先测试连接，再保存到监控列表。保存后建议立即采集一次，确认 CPU、内存、磁盘和服务状态可以正常返回。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-plain" href="<?= url('monitor') ?>" data-icon="arrow-left">返回监控列表</a>
            </div>
        </div>
    </header>

    <section class="bm-monitor-form-layout">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Connection</span>
                    <h2>连接信息</h2>
                </div>
            </div>

            <form method="post" action="<?= url('monitor') ?>" class="bm-form-grid monitor-create-form">
                <?= csrf_field() ?>

                <label>
                    <span>服务器名称</span>
                    <input name="name" required placeholder="例如：主站节点 / 上海轻量云">
                </label>

                <label>
                    <span>分组名称</span>
                    <input name="group_name" placeholder="例如：生产环境">
                </label>

                <label>
                    <span>宝塔面板地址</span>
                    <input name="panel_url" required placeholder="https://1.2.3.4:8888">
                    <small>请填写可访问的完整面板地址，包含 http 或 https。</small>
                </label>

                <label>
                    <span>宝塔 API 密钥</span>
                    <input name="api_key" required placeholder="在宝塔面板 API 设置中复制">
                    <small>测试失败时优先检查 API 白名单、面板端口、防火墙和 SSL 证书。</small>
                </label>

                <label>
                    <span>面板端口</span>
                    <input type="number" name="panel_port" value="8888" min="1">
                </label>

                <label>
                    <span>服务器 IP</span>
                    <input name="server_ip" placeholder="可选，用于列表识别">
                </label>

                <label>
                    <span>采集频率（秒）</span>
                    <input type="number" name="frequency" value="60" min="30">
                    <small>最低 30 秒。计划任务访问采集链接时，会按每台服务器自己的频率判断是否需要采集。</small>
                </label>

                <label>
                    <span>备注</span>
                    <input name="remark" placeholder="机房、用途或维护说明">
                </label>

                <label>
                    <span>CPU 告警阈值（%）</span>
                    <input type="number" name="cpu_threshold" value="90" min="1" max="100">
                </label>

                <label>
                    <span>内存告警阈值（%）</span>
                    <input type="number" name="memory_threshold" value="90" min="1" max="100">
                </label>

                <label>
                    <span>磁盘告警阈值（%）</span>
                    <input type="number" name="disk_threshold" value="90" min="1" max="100">
                </label>

                <div class="bm-form-actions bm-span-all">
                    <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存服务器</button>
                    <button class="bm-btn bm-btn-soft monitor-test-btn" type="button" data-token="<?= e(csrf_token()) ?>" data-icon="plug-zap">测试连接</button>
                    <a class="bm-btn bm-btn-plain" href="<?= url('monitor') ?>" data-icon="x">取消</a>
                </div>
            </form>
        </article>

        <aside class="bm-card bm-monitor-guide">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Checklist</span>
                    <h2>接入检查</h2>
                </div>
            </div>
            <div class="bm-guide-list">
                <p><b>1. 面板 API</b><span>宝塔面板需要开启 API，并把本站服务器 IP 加入白名单。</span></p>
                <p><b>2. 网络端口</b><span>确认面板端口、防火墙、安全组允许本站访问。</span></p>
                <p><b>3. 测试连接</b><span>保存前点击测试连接，可以提前发现地址、密钥或网络问题。</span></p>
                <p><b>4. 计划采集</b><span>保存后到后台监控管理复制计划任务链接，实现定时自动采集。</span></p>
            </div>
        </aside>
    </section>
</section>
