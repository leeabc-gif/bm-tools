<section class="bm-workspace server-ops-page server-command-audit-page">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Command Audit</span>
            <h1>命令审计</h1>
            <p>查看你在个人服务器在线终端中执行过的命令、输出摘要和来源 IP。这里仅展示当前账号自己的 SSH / Agent 服务器记录，不会混入平台后台服务器。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('servers') ?>" data-icon="server-cog">服务器管家</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('alerts') ?>" data-icon="bell-ring">告警中心</a>
            </div>
        </div>
        <aside class="server-ops-privacy-card">
            <strong>审计独立留痕</strong>
            <span>命令内容不做二次拦截，执行记录用于用户自查和安全追溯。</span>
        </aside>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card">
            <span>累计命令</span>
            <strong><?= e($stats['total']) ?></strong>
            <small>当前账号全部记录</small>
        </article>
        <article class="bm-stat-card">
            <span>今日执行</span>
            <strong><?= e($stats['today']) ?></strong>
            <small>当天在线终端命令</small>
        </article>
        <article class="bm-stat-card">
            <span>匹配结果</span>
            <strong><?= e($stats['filtered']) ?></strong>
            <small>最多展示最近 300 条</small>
        </article>
        <article class="bm-stat-card">
            <span>涉及服务器</span>
            <strong><?= e($stats['servers']) ?></strong>
            <small>有命令记录的服务器</small>
        </article>
    </section>

    <section class="bm-card">
        <form class="server-audit-filter server-user-command-filter" method="get" action="<?= url('servers/commands') ?>">
            <label>
                <span>服务器</span>
                <select name="server_id">
                    <option value="0">全部服务器</option>
                    <?php foreach ($servers as $server): ?>
                        <option value="<?= e($server['id']) ?>" <?= (int) $filters['server_id'] === (int) $server['id'] ? 'selected' : '' ?>>
                            <?= e($server['name']) ?><?= $server['monitor_type'] === 'agent' ? ' / Agent' : ' / SSH' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>关键词</span>
                <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="命令、输出摘要、服务器名称或 IP">
            </label>
            <label>
                <span>开始日期</span>
                <input type="date" name="date_start" value="<?= e($filters['date_start']) ?>">
            </label>
            <label>
                <span>结束日期</span>
                <input type="date" name="date_end" value="<?= e($filters['date_end']) ?>">
            </label>
            <button class="bm-btn bm-btn-primary" type="submit" data-icon="search">筛选</button>
            <a class="bm-btn bm-btn-soft" href="<?= url('servers/commands') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Logs</span>
                <h2>命令记录</h2>
            </div>
        </div>
        <div class="bm-responsive-table server-admin-table server-command-audit-table">
            <table>
                <thead>
                <tr>
                    <th>服务器</th>
                    <th>命令</th>
                    <th>状态</th>
                    <th>输出摘要</th>
                    <th>来源 IP</th>
                    <th>时间</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$logs): ?>
                    <tr>
                        <td colspan="6" class="muted responsive-table-span">暂无命令审计记录。</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($logs as $row): ?>
                    <?php
                    $risk = $row['risk_level'] ? $row['risk_level'] : 'normal';
                    $exitStatus = $row['exit_status'] === null || $row['exit_status'] === '' ? '-' : (string) $row['exit_status'];
                    $serverHost = $row['ssh_host'] ? $row['ssh_host'] : $row['server_ip'];
                    ?>
                    <tr>
                        <td data-label="服务器">
                            <strong><?= e($row['server_name'] ?: '服务器 #' . $row['server_id']) ?></strong>
                            <small><?= e(($row['monitor_type'] === 'agent' ? 'Agent' : 'SSH') . ($serverHost ? ' / ' . $serverHost : '')) ?></small>
                        </td>
                        <td data-label="命令"><code><?= e(text_limit($row['command'], 180)) ?></code></td>
                        <td data-label="状态">
                            <span class="bm-state-pill risk-<?= e($risk) ?>"><?= e($risk) ?></span>
                            <small>Exit <?= e($exitStatus) ?></small>
                        </td>
                        <td data-label="输出摘要"><span class="server-output-summary"><?= e(text_limit($row['output_summary'], 240)) ?></span></td>
                        <td data-label="来源 IP"><?= e($row['ip'] ?: '-') ?></td>
                        <td data-label="时间"><?= e($row['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>
