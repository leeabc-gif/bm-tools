<?php
$fmt = function ($bytes) {
    return function_exists('format_bytes') ? format_bytes((float) $bytes) : number_format((float) $bytes / 1048576, 1) . ' MB';
};
?>
<section class="bm-workspace server-ops-page">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Server Ops</span>
            <h1>服务器管家</h1>
            <p>这里管理的是当前用户自己的服务器，和后台站点服务器监控完全隔离。你可以保存 SSH 或 Agent 资料，执行连接测试、在线命令、状态采集，并生成只读分享页面。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('servers/create') ?>" data-icon="server-cog">添加服务器</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/commands') ?>" data-icon="clipboard-list">命令审计</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('alerts') ?>" data-icon="bell-ring">监控告警</a>
            </div>
        </div>
        <aside class="server-ops-privacy-card">
            <strong>个人服务器空间</strong>
            <span>仅当前账号可见；分享页面需要你主动开启公开或密码访问。</span>
        </aside>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>已保存服务器</span><strong><?= e($stats['total']) ?></strong><small><?= $limit > 0 ? '当前上限 ' . e($limit) . ' 台' : '不限数量' ?></small></article>
        <article class="bm-stat-card"><span>在线服务器</span><strong><?= e($stats['online']) ?></strong><small>最近采集正常</small></article>
        <article class="bm-stat-card <?= $stats['offline'] > 0 ? 'is-warn' : '' ?>"><span>异常服务器</span><strong><?= e($stats['offline']) ?></strong><small>需要检查 SSH 或网络</small></article>
        <article class="bm-stat-card <?= $stats['down_checks'] > 0 ? 'is-warn' : '' ?>"><span>站点探针</span><strong><?= e($stats['checks']) ?></strong><small>异常 <?= e($stats['down_checks']) ?> 个</small></article>
        <article class="bm-stat-card"><span>今日命令</span><strong><?= e($stats['commands_today']) ?></strong><small>在线终端执行记录</small></article>
    </section>

    <section class="bm-card bm-copy-scope server-user-cron-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Personal Cron</span>
                <h2>个人服务器自动采集</h2>
            </div>
            <form method="post" action="<?= url('servers/cron-token/reset') ?>" class="confirm-form" data-confirm="重置后旧采集链接会立即失效，确定继续吗？">
                <?= csrf_field() ?>
                <button class="bm-btn bm-btn-soft" type="submit" data-icon="refresh-cw">重置链接</button>
            </form>
        </div>
        <div class="server-cron-grid">
            <label>
                <span>按频率采集</span>
                <div class="bm-input-action">
                    <input readonly value="<?= e($userCronUrl) ?>" data-auto-select>
                    <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                </div>
                <small>建议计划任务每 1 分钟访问一次，系统会按每台服务器自己的频率判断是否需要采集。</small>
            </label>
            <label>
                <span>强制采集</span>
                <div class="bm-input-action">
                    <input readonly value="<?= e($userCronForceUrl) ?>" data-auto-select>
                    <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                </div>
                <small>适合临时刷新或排查，不建议高频访问。该链接只采集当前账号下的服务器。</small>
            </label>
        </div>
    </section>

    <section class="bm-monitor-list server-ops-list">
        <?php if (!$servers): ?>
            <article class="bm-empty-state">
                <i data-lucide="server"></i>
                <strong>还没有添加服务器</strong>
                <span>添加第一台服务器后，可以在这里查看状态、打开在线终端、生成监控页面。</span>
                <a class="bm-btn bm-btn-primary" href="<?= url('servers/create') ?>" data-icon="plus">添加第一台服务器</a>
            </article>
        <?php endif; ?>

        <?php foreach ($servers as $server): ?>
            <?php
            $metric = $server['latest'];
            $cpu = $metric ? (float) $metric['cpu_usage'] : 0;
            $memory = $metric ? (float) $metric['memory_usage'] : 0;
            $disk = $metric ? (float) $metric['disk_usage'] : 0;
            ?>
            <article class="bm-monitor-card server-ops-card is-status-<?= e($server['status']) ?>">
                <header>
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= $server['monitor_type'] === 'agent' ? 'satellite-dish' : 'server' ?>"></i></span>
                        <div>
                            <strong><?= e($server['name']) ?></strong>
                            <?php if ($server['monitor_type'] === 'agent'): ?>
                                <small>Agent 上报<?= $server['agent_url'] ? ' · ' . e($server['agent_url']) : ' · 主动推送模式' ?><?= $server['group_name'] ? ' · ' . e($server['group_name']) : '' ?></small>
                            <?php else: ?>
                                <small><?= e($server['ssh_username']) ?>@<?= e($server['ssh_host'] ?: $server['server_ip']) ?>:<?= e($server['ssh_port']) ?><?= $server['group_name'] ? ' · ' . e($server['group_name']) : '' ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <span class="bm-state-pill is-status-<?= e($server['status']) ?>"><?= e(status_label($server['status'])) ?></span>
                </header>

                <div class="bm-monitor-metrics">
                    <span><b>CPU</b><em><?= e($cpu) ?>%</em><i><u style="width: <?= e(max(0, min(100, $cpu))) ?>%"></u></i></span>
                    <span><b>内存</b><em><?= e($memory) ?>%</em><i><u style="width: <?= e(max(0, min(100, $memory))) ?>%"></u></i></span>
                    <span><b>磁盘</b><em><?= e($disk) ?>%</em><i><u style="width: <?= e(max(0, min(100, $disk))) ?>%"></u></i></span>
                    <span><b>最近采集</b><em><?= e($server['last_checked_at'] ?: '-') ?></em><?php if (!empty($server['is_stale'])): ?><small>数据已过期</small><?php endif; ?></span>
                    <span><b>站点探针</b><em><?= e(isset($server['probe_stats']['total']) ? $server['probe_stats']['total'] : 0) ?> 个</em><small>异常 <?= e(isset($server['probe_stats']['down']) ? $server['probe_stats']['down'] : 0) ?></small></span>
                </div>

                <?php if ($metric): ?>
                    <div class="bm-service-list">
                        <span>已用内存 <?= e($fmt($metric['memory_used'])) ?></span>
                        <span>已用磁盘 <?= e($fmt($metric['disk_used'])) ?></span>
                        <span>负载 <?= e($metric['load_avg'] ?: '-') ?></span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($server['last_error'])): ?>
                    <div class="bm-inline-notice is-warning">
                        <i data-lucide="alert-triangle"></i>
                        <div><strong>最近错误</strong><span><?= e($server['last_error']) ?></span></div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($server['is_stale'])): ?>
                    <div class="bm-inline-notice is-warning">
                        <i data-lucide="clock-alert"></i>
                        <div><strong>监控数据已过期</strong><span>计划任务可能没有执行，建议点击立即采集或检查采集计划。</span></div>
                    </div>
                <?php endif; ?>

                <div class="bm-monitor-actions">
                    <?php if ($server['monitor_type'] === 'ssh'): ?><a class="bm-btn bm-btn-primary" href="<?= url('servers/' . $server['id'] . '/terminal') ?>" data-icon="terminal">在线终端</a><?php endif; ?>
                    <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id']) ?>" data-icon="activity">状态详情</a>
                    <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/probes') ?>" data-icon="radar">站点探针</a>
                    <a class="bm-btn bm-btn-soft" href="<?= url('servers/create?id=' . $server['id']) ?>" data-icon="pencil">编辑</a>
                    <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/share') ?>" data-icon="share-2">监控页面</a>
                    <form method="post" action="<?= url('servers/delete') ?>" class="confirm-form" data-confirm="确定删除这台服务器及相关监控、命令记录吗？">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                        <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
