<?php
$isEdit = !empty($server);
$monitorType = old('monitor_type', $isEdit && isset($server['monitor_type']) ? $server['monitor_type'] : 'ssh');
$agentToken = old('agent_token', $isEdit && isset($server['agent_token']) ? $server['agent_token'] : '');
if ($agentToken === '') {
    $agentToken = bin2hex(random_bytes(24));
}
?>
<section class="bm-workspace server-ops-page">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Server Asset</span>
            <h1><?= $isEdit ? '编辑服务器' : '添加服务器' ?></h1>
            <p>保存 SSH 连接信息后，可以进行连接测试、在线命令、状态采集和监控页面分享。密码和私钥会加密保存。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('servers') ?>" data-icon="arrow-left">返回列表</a>
                <?php if ($isEdit): ?><a class="bm-btn bm-btn-primary" href="<?= url('servers/' . $server['id'] . '/terminal') ?>" data-icon="terminal">打开终端</a><?php endif; ?>
            </div>
        </div>
    </header>

    <section class="bm-card">
        <form method="post" action="<?= url('servers/save') ?>" class="form-grid two server-form" data-test-url="<?= url('servers/test') ?>">
            <?= csrf_field() ?>
            <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= e($server['id']) ?>"><?php endif; ?>

            <label>
                <span>服务器名称</span>
                <input name="name" required value="<?= e(old('name', $isEdit ? $server['name'] : '')) ?>" placeholder="例如：博客生产机">
            </label>
            <label>
                <span>分组</span>
                <input name="group_name" value="<?= e(old('group_name', $isEdit ? $server['group_name'] : '个人服务器')) ?>" placeholder="生产环境 / 测试环境">
            </label>
            <label>
                <span>接入方式</span>
                <select name="monitor_type" data-monitor-type>
                    <option value="ssh" <?= $monitorType === 'ssh' ? 'selected' : '' ?>>SSH 直连</option>
                    <option value="agent" <?= $monitorType === 'agent' ? 'selected' : '' ?>>Agent 主动上报</option>
                </select>
            </label>
            <label data-ssh-field>
                <span>SSH 主机</span>
                <input name="ssh_host" value="<?= e(old('ssh_host', $isEdit ? $server['ssh_host'] : '')) ?>" placeholder="IP 或域名">
            </label>
            <label data-ssh-field>
                <span>SSH 端口</span>
                <input type="number" min="1" max="65535" name="ssh_port" value="<?= e(old('ssh_port', $isEdit ? $server['ssh_port'] : '22')) ?>">
            </label>
            <label data-ssh-field>
                <span>SSH 用户名</span>
                <input name="ssh_username" value="<?= e(old('ssh_username', $isEdit ? $server['ssh_username'] : '')) ?>" placeholder="root / ubuntu / deploy">
            </label>
            <label data-ssh-field>
                <span>认证方式</span>
                <?php $authType = old('ssh_auth_type', $isEdit ? $server['ssh_auth_type'] : 'password'); ?>
                <select name="ssh_auth_type" data-ssh-auth-type>
                    <option value="password" <?= $authType === 'password' ? 'selected' : '' ?>>密码</option>
                    <option value="key" <?= $authType === 'key' ? 'selected' : '' ?>>SSH 私钥</option>
                </select>
            </label>

            <label data-ssh-field data-auth-password>
                <span>SSH 密码</span>
                <input type="password" name="ssh_password" autocomplete="new-password" placeholder="<?= $isEdit ? '已加密保存，留空不修改' : '输入 SSH 密码' ?>">
            </label>
            <label data-ssh-field data-auth-key class="full">
                <span>SSH 私钥</span>
                <textarea name="ssh_private_key" rows="7" placeholder="<?= $isEdit ? '已加密保存，留空不修改' : '粘贴 PEM/OpenSSH 私钥' ?>"></textarea>
            </label>
            <label data-ssh-field data-auth-key>
                <span>私钥密码</span>
                <input type="password" name="ssh_key_passphrase" autocomplete="new-password" placeholder="没有则留空">
            </label>
            <label data-agent-field>
                <span>Agent URL（可选）</span>
                <input name="agent_url" value="<?= e(old('agent_url', $isEdit && isset($server['agent_url']) ? $server['agent_url'] : '')) ?>" placeholder="https://server.com/monitor-agent.php">
                <small>填写后平台可主动测试/拉取；留空则使用目标服务器主动上报。</small>
            </label>
            <label data-agent-field>
                <span>Agent Token</span>
                <div class="bm-input-action">
                    <input name="agent_token" value="<?= e($agentToken) ?>" data-agent-token>
                    <button class="bm-btn bm-btn-soft" type="button" data-generate-agent-token data-icon="key-round">生成</button>
                </div>
            </label>
            <div class="bm-inline-notice full" data-agent-field>
                <i data-lucide="info"></i>
                <div><strong>Agent 主动上报</strong><span>保存后进入详情页复制安装命令到目标服务器执行。它不依赖 phpseclib、ssh2，也不需要平台保存 SSH 密码。</span></div>
            </div>
            <label>
                <span>服务器 IP</span>
                <input name="server_ip" value="<?= e(old('server_ip', $isEdit ? $server['server_ip'] : '')) ?>" placeholder="可选，用于展示">
            </label>
            <label>
                <span>采集频率（秒）</span>
                <input type="number" min="60" name="frequency" value="<?= e(old('frequency', $isEdit ? $server['frequency'] : '300')) ?>">
            </label>
            <label>
                <span>CPU 告警阈值 %</span>
                <input type="number" min="1" max="100" name="cpu_threshold" value="90">
            </label>
            <label>
                <span>内存告警阈值 %</span>
                <input type="number" min="1" max="100" name="memory_threshold" value="90">
            </label>
            <label>
                <span>磁盘告警阈值 %</span>
                <input type="number" min="1" max="100" name="disk_threshold" value="90">
            </label>
            <label class="inline-check">
                <input type="checkbox" name="is_enabled" <?= !$isEdit || $server['is_enabled'] ? 'checked' : '' ?>>
                <span>开启监控采集</span>
            </label>
            <label class="full">
                <span>备注</span>
                <textarea name="remark" rows="3" placeholder="记录用途、厂商、到期时间或维护说明"><?= e(old('remark', $isEdit ? $server['remark'] : '')) ?></textarea>
            </label>

            <div class="bm-form-actions full">
                <button class="bm-btn bm-btn-soft server-test-btn" type="button" data-icon="plug-zap">测试连接</button>
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存服务器</button>
            </div>
            <div class="bm-inline-notice full server-test-result" hidden></div>
        </form>
    </section>
</section>

<script>
(function () {
    var form = document.querySelector('.server-form');
    if (!form) return;
    var auth = form.querySelector('[data-ssh-auth-type]');
    var monitorType = form.querySelector('[data-monitor-type]');
    function syncAuth() {
        var isAgent = monitorType && monitorType.value === 'agent';
        var isKey = auth && auth.value === 'key';
        form.querySelectorAll('[data-ssh-field]').forEach(function (el) { el.style.display = isAgent ? 'none' : 'grid'; });
        form.querySelectorAll('[data-agent-field]').forEach(function (el) { el.style.display = isAgent ? 'grid' : 'none'; });
        form.querySelectorAll('[data-auth-password]').forEach(function (el) { el.style.display = (!isAgent && !isKey) ? 'grid' : 'none'; });
        form.querySelectorAll('[data-auth-key]').forEach(function (el) { el.style.display = (!isAgent && isKey) ? 'grid' : 'none'; });
        var sshHost = form.querySelector('[name="ssh_host"]');
        var sshUser = form.querySelector('[name="ssh_username"]');
        if (sshHost) sshHost.required = !isAgent;
        if (sshUser) sshUser.required = !isAgent;
    }
    if (auth) auth.addEventListener('change', syncAuth);
    if (monitorType) monitorType.addEventListener('change', syncAuth);
    syncAuth();

    var tokenBtn = form.querySelector('[data-generate-agent-token]');
    var tokenInput = form.querySelector('[data-agent-token]');
    if (tokenBtn && tokenInput) {
        tokenBtn.addEventListener('click', function () {
            var bytes = new Uint8Array(24);
            if (window.crypto && window.crypto.getRandomValues) {
                window.crypto.getRandomValues(bytes);
                tokenInput.value = Array.prototype.map.call(bytes, function (n) { return ('0' + n.toString(16)).slice(-2); }).join('');
            } else {
                tokenInput.value = String(Date.now()) + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2);
            }
        });
    }

    var result = form.querySelector('.server-test-result');
    var btn = form.querySelector('.server-test-btn');
    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char];
        });
    }
    function renderTestResult(json) {
        var text = document.createElement('div');
        text.className = 'server-test-summary';
        text.textContent = json.message || (json.success ? '连接成功。' : '连接失败。');
        result.innerHTML = '';
        result.appendChild(text);
        if (Array.isArray(json.steps) && json.steps.length) {
            var list = document.createElement('div');
            list.className = 'server-test-steps';
            json.steps.forEach(function (step, index) {
                var item = document.createElement('p');
                if (typeof step === 'string') {
                    item.className = 'ok';
                    item.innerHTML = '<i>' + (index + 1) + '</i><span>' + escapeHtml(step) + '</span>';
                } else {
                    item.className = step.status || 'pending';
                    item.innerHTML = '<i>' + (index + 1) + '</i><span><b>' + escapeHtml(step.label || ('步骤 ' + (index + 1))) + '</b><em>' + escapeHtml(step.message || '') + '</em></span>';
                }
                list.appendChild(item);
            });
            result.appendChild(list);
        }
    }
    if (btn && result) {
        btn.addEventListener('click', function () {
            btn.disabled = true;
            result.hidden = false;
            result.className = 'bm-inline-notice full server-test-result';
            result.textContent = '正在测试 SSH 连接...';
            fetch(form.dataset.testUrl, { method: 'POST', body: new FormData(form), credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (res) { return window.SKY_PARSE_JSON_RESPONSE ? window.SKY_PARSE_JSON_RESPONSE(res) : res.json(); })
                .then(function (json) {
                    result.className = 'bm-inline-notice full server-test-result ' + (json.success ? 'is-success' : 'is-warning');
                    renderTestResult(json);
                })
                .catch(function (error) {
                    result.className = 'bm-inline-notice full server-test-result is-warning';
                    result.textContent = error && error.message ? error.message : '测试请求失败，请检查网络或稍后重试。';
                })
                .finally(function () { btn.disabled = false; });
        });
    }
})();
</script>
