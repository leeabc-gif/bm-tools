<?php
$fmt = function ($bytes) {
    return function_exists('format_bytes') ? format_bytes((float) $bytes) : number_format((float) $bytes / 1048576, 1) . ' MB';
};
$cpu = $latest ? (float) $latest['cpu_usage'] : 0;
$memory = $latest ? (float) $latest['memory_usage'] : 0;
$disk = $latest ? (float) $latest['disk_usage'] : 0;
$isAgent = isset($server['monitor_type']) && $server['monitor_type'] === 'agent';
$agentInstallUrl = $isAgent && !empty($server['agent_token']) ? public_url('agent/install/' . $server['id'] . '/' . $server['agent_token']) : '';
$agentReportUrl = public_url('agent/report');
?>
<section class="bm-workspace server-ops-page">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Server Detail</span>
            <h1><?= e($server['name']) ?></h1>
            <?php if ($isAgent): ?>
                <p>Agent 主动上报<?= $server['agent_url'] ? ' · ' . e($server['agent_url']) : ' · 等待目标服务器推送' ?> · <?= e($server['group_name'] ?: '未分组') ?></p>
            <?php else: ?>
                <p><?= e($server['ssh_username']) ?>@<?= e($server['ssh_host']) ?>:<?= e($server['ssh_port']) ?> · <?= e($server['group_name'] ?: '未分组') ?></p>
            <?php endif; ?>
            <div class="bm-action-row">
                <?php if (!$isAgent): ?><a class="bm-btn bm-btn-primary" href="<?= url('servers/' . $server['id'] . '/terminal') ?>" data-icon="terminal">在线终端</a><?php endif; ?>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/create?id=' . $server['id']) ?>" data-icon="pencil">编辑</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/probes') ?>" data-icon="radar">站点探针</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/share') ?>" data-icon="share-2">监控页面</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers') ?>" data-icon="arrow-left">返回</a>
                <form method="post" action="<?= url('servers/delete') ?>" class="confirm-form" data-confirm="确定删除这台服务器及相关监控、命令记录吗？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                    <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除</button>
                </form>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card <?= !empty($server['is_stale']) ? 'is-warn' : '' ?>"><span>连接状态</span><strong><?= e(status_label($server['status'])) ?></strong><small><?= e($server['last_checked_at'] ?: '尚未采集') ?><?= !empty($server['is_stale']) ? ' · 数据已过期' : '' ?></small></article>
        <article class="bm-stat-card"><span>CPU</span><strong><?= e($cpu) ?>%</strong><small>当前采集值</small></article>
        <article class="bm-stat-card"><span>内存</span><strong><?= e($memory) ?>%</strong><small><?= $latest ? e($fmt($latest['memory_used'])) . ' / ' . e($fmt($latest['memory_total'])) : '-' ?></small></article>
        <article class="bm-stat-card"><span>磁盘</span><strong><?= e($disk) ?>%</strong><small><?= $latest ? e($fmt($latest['disk_used'])) . ' / ' . e($fmt($latest['disk_total'])) : '-' ?></small></article>
        <article class="bm-stat-card <?= !empty($probeStats['down']) ? 'is-warn' : '' ?>"><span>站点探针</span><strong><?= e(isset($probeStats['total']) ? $probeStats['total'] : 0) ?></strong><small>异常 <?= e(isset($probeStats['down']) ? $probeStats['down'] : 0) ?> · SSL 临期 <?= e(isset($probeStats['expiring_ssl']) ? $probeStats['expiring_ssl'] : 0) ?></small></article>
    </section>

    <?php if ($isAgent): ?>
        <section class="bm-card bm-copy-scope server-agent-install">
            <div class="bm-card-head">
                <div><strong>Agent 安装命令</strong><span>复制到目标 Linux 服务器执行，默认每分钟主动上报一次状态。</span></div>
                <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
            </div>
            <label>
                <span>一键安装</span>
                <input readonly value='curl -fsSL "<?= e($agentInstallUrl) ?>" | sh'>
            </label>
            <div class="server-info-list">
                <p><span>上报接口</span><b><?= e($agentReportUrl) ?></b></p>
                <p><span>Agent Token</span><b><?= e(text_limit($server['agent_token'], 12, '...')) ?></b></p>
            </div>
        </section>
    <?php endif; ?>

    <section class="server-detail-grid">
        <article class="bm-card">
            <div class="bm-card-head">
                <div><strong>运行状态</strong><span>通过 SSH 命令采集 Linux 基础指标</span></div>
                <?php if (!$isAgent || !empty($server['agent_url'])): ?><button class="bm-btn bm-btn-soft server-collect-btn" data-id="<?= e($server['id']) ?>" data-token="<?= e(csrf_token()) ?>" data-icon="refresh-cw">立即采集</button><?php endif; ?>
            </div>
            <div class="bm-monitor-metrics is-detail">
                <span><b>CPU</b><em><?= e($cpu) ?>%</em><i><u style="width:<?= e(max(0, min(100, $cpu))) ?>%"></u></i></span>
                <span><b>内存</b><em><?= e($memory) ?>%</em><i><u style="width:<?= e(max(0, min(100, $memory))) ?>%"></u></i></span>
                <span><b>磁盘</b><em><?= e($disk) ?>%</em><i><u style="width:<?= e(max(0, min(100, $disk))) ?>%"></u></i></span>
            </div>
            <div class="server-info-list">
                <p><span>负载</span><b><?= e($latest ? $latest['load_avg'] : '-') ?></b></p>
                <p><span>运行时间</span><b><?= e($latest ? $latest['uptime'] : '-') ?></b></p>
                <p><span>上行速率</span><b><?= e($latest ? $fmt($latest['net_upload']) . '/s' : '-') ?></b></p>
                <p><span>下行速率</span><b><?= e($latest ? $fmt($latest['net_download']) . '/s' : '-') ?></b></p>
            </div>
        </article>

        <article class="bm-card">
            <div class="bm-card-head">
                <div><strong>最近命令</strong><span>只显示摘要，完整输出请进入终端页查看</span></div>
                <a class="bm-text-link" href="<?= url('servers/commands?server_id=' . $server['id']) ?>">查看全部</a>
            </div>
            <div class="server-command-list">
                <?php if (!$commands): ?><p class="muted">暂无命令记录。</p><?php endif; ?>
                <?php foreach ($commands as $row): ?>
                    <p><code><?= e(text_limit($row['command'], 80)) ?></code><span>已执行 · <?= e($row['created_at']) ?></span></p>
                <?php endforeach; ?>
            </div>
        </article>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div><strong>站点探针</strong><span>监控网站、端口和 SSL 证书，异常时自动进入告警中心</span></div>
            <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/probes') ?>" data-icon="radar">管理探针</a>
        </div>
        <div class="server-probe-log-list">
            <?php if (empty($probeLogs)): ?><p class="muted">暂无探针检测记录。</p><?php endif; ?>
            <?php foreach ($probeLogs as $row): ?>
                <p class="is-<?= e($row['status']) ?>">
                    <span><b><?= e($row['check_name'] ?: '探针') ?></b><small><?= e(strtoupper($row['type'])) ?> · <?= e($row['checked_at']) ?></small></span>
                    <em><?= e($row['status'] === 'up' ? '正常' : '异常') ?> · <?= e((int) $row['response_time_ms']) ?>ms</em>
                </p>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if (!empty($server['is_stale'])): ?>
        <section class="bm-inline-notice is-warning">
            <i data-lucide="clock-alert"></i>
            <div><strong>监控数据已过期</strong><span>最近一次采集已经超过当前频率的安全窗口。请点击“立即采集”，或把计划任务指向系统提供的采集入口。</span></div>
        </section>
    <?php endif; ?>

    <?php if (!empty($server['last_error'])): ?>
        <section class="bm-inline-notice is-warning">
            <i data-lucide="alert-triangle"></i>
            <div><strong>最近采集错误</strong><span><?= e($server['last_error']) ?></span></div>
        </section>
    <?php endif; ?>
</section>
