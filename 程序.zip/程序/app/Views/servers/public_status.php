<?php
$fmt = function ($bytes) {
    return function_exists('format_bytes') ? format_bytes((float) $bytes) : number_format((float) $bytes / 1048576, 1) . ' MB';
};
$cpu = $latest ? (float) $latest['cpu_usage'] : 0;
$memory = $latest ? (float) $latest['memory_usage'] : 0;
$disk = $latest ? (float) $latest['disk_usage'] : 0;
?>
<section class="blog-article-head server-public-status">
    <p class="blog-kicker">Server Status</p>
    <h1><?= e($page['title'] ?: $server['name']) ?></h1>
    <p><?= e($server['name']) ?> 当前状态：<?= e(status_label($server['status'])) ?>。最后采集：<?= e($server['last_checked_at'] ?: '-') ?></p>
</section>

<section class="blog-article-body server-public-status">
    <?php if (!empty($server['is_stale'])): ?>
        <div class="bm-inline-notice is-warning">
            <i data-lucide="clock-alert"></i>
            <div><strong>监控数据可能已过期</strong><span>最近一次采集已超过当前监控频率，页面展示的是最后一次成功记录。</span></div>
        </div>
    <?php endif; ?>

    <div class="bm-stat-grid">
        <article class="bm-stat-card <?= !empty($server['is_stale']) ? 'is-warn' : '' ?>"><span>状态</span><strong><?= e(status_label($server['status'])) ?></strong><small>只读监控页<?= !empty($server['is_stale']) ? ' · 数据过期' : '' ?></small></article>
        <article class="bm-stat-card"><span>CPU</span><strong><?= e($cpu) ?>%</strong><small>当前采集值</small></article>
        <article class="bm-stat-card"><span>内存</span><strong><?= e($memory) ?>%</strong><small><?= $latest ? e($fmt($latest['memory_used'])) . ' / ' . e($fmt($latest['memory_total'])) : '-' ?></small></article>
        <article class="bm-stat-card"><span>磁盘</span><strong><?= e($disk) ?>%</strong><small><?= $latest ? e($fmt($latest['disk_used'])) . ' / ' . e($fmt($latest['disk_total'])) : '-' ?></small></article>
    </div>

    <?php if ($page['show_metrics'] && $latest): ?>
        <div class="server-info-list">
            <p><span>负载</span><b><?= e($latest['load_avg'] ?: '-') ?></b></p>
            <p><span>运行时间</span><b><?= e($latest['uptime'] ?: '-') ?></b></p>
            <p><span>上行速率</span><b><?= e($fmt($latest['net_upload'])) ?>/s</b></p>
            <p><span>下行速率</span><b><?= e($fmt($latest['net_download'])) ?>/s</b></p>
        </div>
    <?php endif; ?>

    <?php if (!empty($server['last_error'])): ?>
        <div class="bm-inline-notice is-warning">
            <i data-lucide="alert-triangle"></i>
            <div><strong>最近错误</strong><span><?= e($server['last_error']) ?></span></div>
        </div>
    <?php endif; ?>

    <?php if ($page['show_services'] && !empty($checks)): ?>
        <div class="server-probe-log-list">
            <?php foreach ($checks as $check): ?>
                <p class="is-<?= e($check['status']) ?>">
                    <span><b><?= e($check['name']) ?></b><small><?= e(strtoupper($check['type'])) ?> · <?= e($check['target']) ?></small></span>
                    <em><?= e($check['status'] === 'up' ? '正常' : ($check['status'] === 'down' ? '异常' : '未知')) ?> · <?= e((int) $check['response_time_ms']) ?>ms</em>
                </p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
