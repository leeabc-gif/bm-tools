<?php $shareUrl = $page ? public_url('s/' . $page['token']) : ''; ?>
<section class="bm-workspace server-ops-page">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Status Page</span>
            <h1>监控页面配置</h1>
            <p>给 <?= e($server['name']) ?> 创建只读状态页。访客只能查看状态，不能打开终端或执行命令。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id']) ?>" data-icon="arrow-left">返回详情</a>
                <?php if ($page && $page['visibility'] !== 'private'): ?><a class="bm-btn bm-btn-primary" href="<?= e($shareUrl) ?>" target="_blank" rel="noopener" data-icon="external-link">打开页面</a><?php endif; ?>
            </div>
        </div>
    </header>

    <section class="bm-card bm-copy-scope">
        <form method="post" action="<?= url('servers/share/save') ?>" class="form-grid two">
            <?= csrf_field() ?>
            <input type="hidden" name="server_id" value="<?= e($server['id']) ?>">
            <label>
                <span>页面标题</span>
                <input name="title" value="<?= e($page ? $page['title'] : $server['name'] . ' 状态页') ?>">
            </label>
            <label>
                <span>访问方式</span>
                <?php $visibility = $page ? $page['visibility'] : 'private'; ?>
                <select name="visibility">
                    <option value="private" <?= $visibility === 'private' ? 'selected' : '' ?>>关闭分享</option>
                    <option value="public" <?= $visibility === 'public' ? 'selected' : '' ?>>公开只读</option>
                    <option value="password" <?= $visibility === 'password' ? 'selected' : '' ?>>密码访问</option>
                </select>
            </label>
            <label>
                <span>访问密码</span>
                <input type="password" name="password" placeholder="<?= $page && $page['password_hash'] ? '已设置，留空不修改' : '密码访问时必填' ?>">
            </label>
            <label>
                <span>过期时间</span>
                <input type="datetime-local" name="expires_at" value="<?= $page && $page['expires_at'] ? e(date('Y-m-d\TH:i', strtotime($page['expires_at']))) : '' ?>">
            </label>
            <label class="inline-check"><input type="checkbox" name="show_metrics" <?= !$page || $page['show_metrics'] ? 'checked' : '' ?>><span>展示资源指标</span></label>
            <label class="inline-check"><input type="checkbox" name="show_services" <?= !$page || $page['show_services'] ? 'checked' : '' ?>><span>展示服务状态</span></label>
            <?php if ($page): ?>
                <label class="full">
                    <span>分享链接</span>
                    <div class="bm-input-action">
                        <input readonly value="<?= e($shareUrl) ?>" data-auto-select>
                        <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                    </div>
                </label>
            <?php endif; ?>
            <div class="bm-form-actions full">
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存配置</button>
            </div>
        </form>
    </section>
</section>
