<?php
$typeLabels = ['http' => 'HTTP', 'tcp' => 'TCP 端口', 'ssl' => 'SSL 证书'];
$statusLabels = ['up' => '正常', 'down' => '异常', 'unknown' => '未知'];
$current = $editCheck ?: [];
$value = function ($key, $default = '') use ($current) {
    return old($key, isset($current[$key]) ? $current[$key] : $default);
};
$isEdit = !empty($current);
?>

<section class="bm-workspace server-ops-page server-probes-page">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Service Probes</span>
            <h1>站点探针</h1>
            <p><?= e($server['name']) ?> 的 HTTP、TCP 端口和 SSL 证书检测。适合监控网站首页、API、图床上传接口、分享仓库和关键端口。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id']) ?>" data-icon="activity">状态详情</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers') ?>" data-icon="arrow-left">返回服务器管家</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>探针总数</span><strong><?= e($stats['total']) ?></strong><small><?= $limit > 0 ? '当前上限 ' . e($limit) . ' 个' : '不限数量' ?></small></article>
        <article class="bm-stat-card"><span>正常探针</span><strong><?= e($stats['up']) ?></strong><small>最近一次检测通过</small></article>
        <article class="bm-stat-card <?= $stats['down'] > 0 ? 'is-warn' : '' ?>"><span>异常探针</span><strong><?= e($stats['down']) ?></strong><small>会进入告警中心</small></article>
        <article class="bm-stat-card <?= $stats['expiring_ssl'] > 0 ? 'is-warn' : '' ?>"><span>SSL 临期</span><strong><?= e($stats['expiring_ssl']) ?></strong><small>7 天内到期</small></article>
    </section>

    <section class="server-probe-grid">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow"><?= $isEdit ? 'Edit Probe' : 'New Probe' ?></span>
                    <h2><?= $isEdit ? '编辑探针' : '新增探针' ?></h2>
                </div>
                <?php if ($isEdit): ?><a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/probes') ?>" data-icon="plus">新增</a><?php endif; ?>
            </div>

            <form method="post" action="<?= url('servers/probes/save') ?>" class="bm-form-grid server-probe-form" data-probe-test-url="<?= url('servers/probes/test') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="server_id" value="<?= e($server['id']) ?>">
                <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= e($current['id']) ?>"><?php endif; ?>

                <label>
                    <span>检测类型</span>
                    <select name="type" data-probe-type>
                        <option value="http" <?= $value('type', 'http') === 'http' ? 'selected' : '' ?>>HTTP/HTTPS</option>
                        <option value="tcp" <?= $value('type') === 'tcp' ? 'selected' : '' ?>>TCP 端口</option>
                        <option value="ssl" <?= $value('type') === 'ssl' ? 'selected' : '' ?>>SSL 证书</option>
                    </select>
                </label>
                <label>
                    <span>探针名称</span>
                    <input name="name" required value="<?= e($value('name', '网站首页')) ?>" placeholder="例如：网站首页 / 上传接口 / SSH 端口">
                </label>
                <label class="full">
                    <span>检测目标</span>
                    <input name="target" required value="<?= e($value('target', '')) ?>" placeholder="HTTP 填 https://example.com；TCP/SSL 填 example.com 或 example.com:443">
                </label>
                <label data-port-field>
                    <span>端口</span>
                    <input type="number" min="0" max="65535" name="port" value="<?= e($value('port', '0')) ?>" placeholder="HTTP 可留空，TCP/SSL 建议填写">
                </label>
                <label data-http-field>
                    <span>请求方式</span>
                    <select name="method">
                        <option value="HEAD" <?= $value('method', 'HEAD') === 'HEAD' ? 'selected' : '' ?>>HEAD</option>
                        <option value="GET" <?= $value('method') === 'GET' ? 'selected' : '' ?>>GET</option>
                    </select>
                </label>
                <label data-http-field>
                    <span>预期状态码</span>
                    <input name="expected_status" value="<?= e($value('expected_status', '200-399')) ?>" placeholder="例如 200、2xx、200-399">
                </label>
                <label data-http-field>
                    <span>页面关键词</span>
                    <input name="keyword" value="<?= e($value('keyword', '')) ?>" placeholder="可选，填写后会使用 GET 检查页面内容">
                </label>
                <label>
                    <span>超时时间</span>
                    <input type="number" min="2" max="15" name="timeout_seconds" value="<?= e($value('timeout_seconds', '5')) ?>">
                </label>
                <label>
                    <span>检测频率（秒）</span>
                    <input type="number" min="60" max="86400" name="frequency" value="<?= e($value('frequency', '300')) ?>">
                </label>
                <label class="inline-check">
                    <input type="checkbox" name="is_enabled" <?= !$isEdit || !empty($current['is_enabled']) ? 'checked' : '' ?>>
                    <span>启用探针</span>
                </label>
                <label class="inline-check">
                    <input type="checkbox" name="test_after_save" checked>
                    <span>保存后立即检测</span>
                </label>

                <div class="bm-form-actions full">
                    <button class="bm-btn bm-btn-soft server-probe-test-btn" type="button" data-icon="plug-zap">先测试</button>
                    <button class="bm-btn bm-btn-primary" type="submit" data-icon="save"><?= $isEdit ? '保存修改' : '保存探针' ?></button>
                </div>
                <div class="bm-inline-notice full server-probe-test-result" hidden></div>
            </form>
        </article>

        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Recent Checks</span>
                    <h2>最近检测</h2>
                </div>
            </div>
            <div class="server-probe-log-list">
                <?php if (!$logs): ?><p class="muted">暂无检测记录。</p><?php endif; ?>
                <?php foreach ($logs as $row): ?>
                    <p class="is-<?= e($row['status']) ?>">
                        <span><b><?= e($row['check_name'] ?: '探针') ?></b><small><?= e(strtoupper($row['type'])) ?> · <?= e($row['checked_at']) ?></small></span>
                        <em><?= e($statusLabels[$row['status']] ?? $row['status']) ?> · <?= e((int) $row['response_time_ms']) ?>ms</em>
                    </p>
                <?php endforeach; ?>
            </div>
        </article>
    </section>

    <section class="bm-monitor-list server-probe-list">
        <?php if (!$checks): ?>
            <article class="bm-empty-state">
                <i data-lucide="radar"></i>
                <strong>还没有站点探针</strong>
                <span>建议先添加网站首页、图床上传接口、API 接口或 SSL 证书检测。</span>
            </article>
        <?php endif; ?>

        <?php foreach ($checks as $check): ?>
            <article class="bm-monitor-card server-probe-card is-<?= e($check['status']) ?>">
                <header>
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= $check['type'] === 'http' ? 'globe' : ($check['type'] === 'ssl' ? 'shield-check' : 'unplug') ?>"></i></span>
                        <div>
                            <strong><?= e($check['name']) ?></strong>
                            <small><?= e($typeLabels[$check['type']] ?? strtoupper($check['type'])) ?> · <?= e($check['target']) ?><?= (int) $check['port'] > 0 ? ':' . e($check['port']) : '' ?></small>
                        </div>
                    </div>
                    <span class="bm-state-pill probe-<?= e($check['status']) ?>"><?= e($statusLabels[$check['status']] ?? $check['status']) ?></span>
                </header>

                <div class="server-probe-meta">
                    <span><b>响应</b><em><?= e((int) $check['response_time_ms']) ?>ms</em></span>
                    <span><b>状态码</b><em><?= e($check['status_code'] ?: '-') ?></em></span>
                    <span><b>SSL 到期</b><em><?= e($check['ssl_expires_at'] ?: '-') ?></em></span>
                    <span><b>最近检测</b><em><?= e($check['last_checked_at'] ?: '-') ?></em></span>
                </div>

                <?php if (!empty($check['last_error'])): ?>
                    <div class="bm-inline-notice is-warning">
                        <i data-lucide="alert-triangle"></i>
                        <div><strong>最近错误</strong><span><?= e($check['last_error']) ?></span></div>
                    </div>
                <?php endif; ?>

                <div class="bm-monitor-actions">
                    <button class="bm-btn bm-btn-soft server-probe-test-saved-btn" type="button" data-server-id="<?= e($server['id']) ?>" data-id="<?= e($check['id']) ?>" data-token="<?= e(csrf_token()) ?>" data-url="<?= url('servers/probes/test') ?>" data-icon="plug-zap">立即检测</button>
                    <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $server['id'] . '/probes?check_id=' . $check['id']) ?>" data-icon="pencil">编辑</a>
                    <form method="post" action="<?= url('servers/probes/delete') ?>" class="confirm-form" data-confirm="确定删除这个站点探针和检测记录吗？">
                        <?= csrf_field() ?>
                        <input type="hidden" name="server_id" value="<?= e($server['id']) ?>">
                        <input type="hidden" name="id" value="<?= e($check['id']) ?>">
                        <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>

<script>
(function () {
    var form = document.querySelector('.server-probe-form');
    if (!form) return;
    var type = form.querySelector('[data-probe-type]');
    var result = form.querySelector('.server-probe-test-result');
    function syncFields() {
        var isHttp = type && type.value === 'http';
        form.querySelectorAll('[data-http-field]').forEach(function (el) { el.style.display = isHttp ? 'grid' : 'none'; });
    }
    if (type) type.addEventListener('change', syncFields);
    syncFields();
    function showResult(ok, message) {
        result.hidden = false;
        result.classList.toggle('is-warning', !ok);
        result.innerHTML = '<i data-lucide="' + (ok ? 'check-circle' : 'alert-triangle') + '"></i><div><strong>' + (ok ? '检测通过' : '检测失败') + '</strong><span>' + String(message || '').replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]; }) + '</span></div>';
        if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
    }
    var testBtn = form.querySelector('.server-probe-test-btn');
    if (testBtn) {
        testBtn.addEventListener('click', function () {
            var old = testBtn.textContent;
            testBtn.disabled = true;
            testBtn.textContent = '测试中';
            var data = new FormData(form);
            data.append('payload_test', '1');
            fetch(form.dataset.probeTestUrl, { method: 'POST', body: data, credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (res) { return window.SKY_PARSE_JSON_RESPONSE ? window.SKY_PARSE_JSON_RESPONSE(res) : res.json(); })
                .then(function (json) { showResult(!!json.success, json.message || '检测完成'); })
                .catch(function (error) { showResult(false, error && error.message ? error.message : '请求失败，请检查网络。'); })
                .finally(function () { testBtn.disabled = false; testBtn.textContent = old; });
        });
    }
    document.querySelectorAll('.server-probe-test-saved-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var data = new FormData();
            var old = btn.textContent;
            data.append('_token', btn.dataset.token || '');
            data.append('server_id', btn.dataset.serverId || '');
            data.append('id', btn.dataset.id || '');
            btn.disabled = true;
            btn.textContent = '检测中';
            fetch(btn.dataset.url, { method: 'POST', body: data, credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (res) { return window.SKY_PARSE_JSON_RESPONSE ? window.SKY_PARSE_JSON_RESPONSE(res) : res.json(); })
                .then(function (json) {
                    if (window.SKY_TOAST) window.SKY_TOAST(json.message || (json.success ? '检测通过。' : '检测失败。'), json.success ? 'success' : 'warning');
                    if (json.success) setTimeout(function () { location.reload(); }, 650);
                })
                .catch(function (error) {
                    if (window.SKY_TOAST) window.SKY_TOAST(error && error.message ? error.message : '请求失败，请检查网络。', 'error');
                })
                .finally(function () { btn.disabled = false; btn.textContent = old; });
        });
    });
})();
</script>
