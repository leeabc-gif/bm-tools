<section class="blog-article-head">
    <p class="blog-kicker">Status Page</p>
    <h1>访问受保护的监控页面</h1>
    <p>请输入页面访问密码，验证后可以查看只读服务器状态。</p>
</section>

<section class="blog-article-body">
    <?php if ($error): ?><div class="auth-alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" action="<?= e(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '') ?>" class="form-grid">
        <?= csrf_field() ?>
        <label>
            <span>访问密码</span>
            <input type="password" name="password" required autofocus>
        </label>
        <button class="btn btn-primary" type="submit" data-icon="lock-keyhole">进入状态页</button>
    </form>
</section>
