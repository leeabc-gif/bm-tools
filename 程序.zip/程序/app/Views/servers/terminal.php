<?php
$server = isset($server) && is_array($server) ? $server : [];
$servers = isset($servers) && is_array($servers) ? $servers : [];
$commands = isset($commands) && is_array($commands) ? $commands : [];
$terminalEnabled = !empty($terminalEnabled);
$gatewayUrl = trim((string) (isset($gatewayUrl) ? $gatewayUrl : ''));
$commandTimeout = isset($commandTimeout) ? (int) $commandTimeout : 30;
$serverId = (int) (isset($server['id']) ? $server['id'] : 0);
$sshHost = isset($server['ssh_host']) && $server['ssh_host'] !== '' ? $server['ssh_host'] : (isset($server['server_ip']) ? $server['server_ip'] : '-');
$sshUser = isset($server['ssh_username']) && $server['ssh_username'] !== '' ? $server['ssh_username'] : '-';
$sshPort = isset($server['ssh_port']) && $server['ssh_port'] ? (int) $server['ssh_port'] : 22;
$serverName = isset($server['name']) && $server['name'] !== '' ? $server['name'] : '未命名服务器';
$groupName = isset($server['group_name']) && $server['group_name'] !== '' ? $server['group_name'] : '默认分组';
$authType = isset($server['ssh_auth_type']) && $server['ssh_auth_type'] === 'key' ? '私钥登录' : '密码登录';
$status = isset($server['status']) && $server['status'] !== '' ? $server['status'] : 'unknown';
$statusText = ['online' => '在线', 'offline' => '离线', 'unknown' => '未知'];
$quickGroups = [
    [
        'title' => '系统巡检',
        'items' => [
            ['label' => '系统概览', 'icon' => 'activity', 'command' => "uname -a\nuptime\nfree -h\ndf -h"],
            ['label' => '登录记录', 'icon' => 'shield-check', 'command' => "who\nlast -n 10"],
            ['label' => '内核与发行版', 'icon' => 'info', 'command' => "cat /etc/os-release 2>/dev/null || lsb_release -a\nuname -r"],
        ],
    ],
    [
        'title' => '资源排查',
        'items' => [
            ['label' => '磁盘占用', 'icon' => 'hard-drive', 'command' => "df -h\ndu -sh /* 2>/dev/null | sort -h"],
            ['label' => 'CPU / 内存排行', 'icon' => 'cpu', 'command' => "ps aux --sort=-%cpu | head -20\nps aux --sort=-%mem | head -20"],
            ['label' => '端口监听', 'icon' => 'radio-tower', 'command' => "ss -tulpen || netstat -tulpen"],
        ],
    ],
    [
        'title' => '服务运维',
        'items' => [
            ['label' => '失败服务', 'icon' => 'circle-alert', 'command' => "systemctl --failed"],
            ['label' => '运行服务', 'icon' => 'list-checks', 'command' => "systemctl list-units --type=service --state=running | head -80"],
            ['label' => 'Docker 状态', 'icon' => 'container', 'command' => "docker ps -a\ndocker stats --no-stream"],
        ],
    ],
    [
        'title' => '网络诊断',
        'items' => [
            ['label' => '路由与地址', 'icon' => 'network', 'command' => "ip addr\nip route"],
            ['label' => 'DNS 检查', 'icon' => 'globe-2', 'command' => "cat /etc/resolv.conf\nnslookup www.baidu.com 2>/dev/null || dig www.baidu.com"],
            ['label' => '防火墙摘要', 'icon' => 'shield', 'command' => "iptables -L -n --line-numbers 2>/dev/null || firewall-cmd --list-all 2>/dev/null || ufw status"],
        ],
    ],
];
$terminalSnippet = function ($command) {
    return str_replace(["\r\n", "\r", "\n"], '&#10;', e((string) $command));
};
?>
<section class="bm-workspace server-ops-page terminal-page server-terminal-tool">
    <header class="bm-page-hero bm-page-hero-compact terminal-tool-hero">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Server terminal</span>
            <h1>在线服务器终端工具</h1>
            <p><?= e($sshUser) ?>@<?= e($sshHost) ?>:<?= e($sshPort) ?>。这里提供 SSH 命令执行、快捷巡检、网关令牌和审计记录，命令内容不做拦截。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $serverId) ?>" data-icon="activity">状态详情</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/' . $serverId . '/probes') ?>" data-icon="radar">站点探针</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('servers/commands?server_id=' . $serverId) ?>" data-icon="history">命令审计</a>
                <?php if ($gatewayUrl !== ''): ?><button class="bm-btn bm-btn-primary terminal-token-btn" type="button" data-icon="key-round">签发网关令牌</button><?php endif; ?>
            </div>
        </div>
        <div class="terminal-hero-status" aria-label="终端连接信息">
            <span class="terminal-live-dot"></span>
            <strong><?= e(isset($statusText[$status]) ? $statusText[$status] : $status) ?></strong>
            <small><?= $terminalEnabled ? '终端功能已开启' : '终端功能已关闭' ?></small>
        </div>
    </header>

    <?php if (!$terminalEnabled): ?>
        <section class="bm-inline-notice is-warning">
            <i data-lucide="lock"></i>
            <div><strong>在线终端已关闭</strong><span>管理员当前未开启 Web SSH 功能，页面仅可查看服务器信息和审计记录。</span></div>
        </section>
    <?php endif; ?>

    <section class="terminal-tool-layout">
        <aside class="terminal-tool-side">
            <section class="terminal-side-card">
                <div class="terminal-side-head">
                    <span>当前连接</span>
                    <strong><?= e($serverName) ?></strong>
                </div>
                <div class="terminal-connection-list">
                    <p><span>SSH 地址</span><b><?= e($sshHost) ?>:<?= e($sshPort) ?></b></p>
                    <p><span>登录用户</span><b><?= e($sshUser) ?></b></p>
                    <p><span>认证方式</span><b><?= e($authType) ?></b></p>
                    <p><span>所属分组</span><b><?= e($groupName) ?></b></p>
                    <p><span>执行超时</span><b><?= e($commandTimeout) ?> 秒</b></p>
                    <p><span>连接模式</span><b><?= $gatewayUrl !== '' ? '网关令牌 / 命令模式' : 'SSH 命令模式' ?></b></p>
                </div>
                <?php if (count($servers) > 1): ?>
                    <label class="terminal-server-switch">
                        <span>切换服务器</span>
                        <select data-terminal-server-switch>
                            <?php foreach ($servers as $item): ?>
                                <?php
                                $itemId = (int) (isset($item['id']) ? $item['id'] : 0);
                                $itemHost = isset($item['ssh_host']) && $item['ssh_host'] !== '' ? $item['ssh_host'] : (isset($item['server_ip']) ? $item['server_ip'] : '-');
                                ?>
                                <option value="<?= url('servers/' . $itemId . '/terminal') ?>" <?= $itemId === $serverId ? 'selected' : '' ?>>
                                    <?= e((isset($item['name']) ? $item['name'] : '服务器') . ' / ' . $itemHost) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                <?php endif; ?>
            </section>

            <section class="terminal-side-card">
                <div class="terminal-side-head">
                    <span>工具状态</span>
                    <strong data-terminal-state><?= $gatewayUrl !== '' ? '网关可用' : '命令模式' ?></strong>
                </div>
                <div class="terminal-state-stack">
                    <p><i data-lucide="square-terminal"></i><span>命令直接发送到你的服务器，平台只负责连接和审计。</span></p>
                    <p><i data-lucide="shield-check"></i><span>执行记录会写入审计，方便你回看排障过程。</span></p>
                    <p><i data-lucide="timer"></i><span>单次命令超时 <?= e($commandTimeout) ?> 秒，长任务建议使用 nohup / screen / tmux。</span></p>
                </div>
            </section>
        </aside>

        <main class="terminal-tool-main">
            <section class="terminal-shell-card terminal-tool-console">
                <div class="terminal-toolbar">
                    <span><?= e($serverName) ?></span>
                    <div class="terminal-toolbar-actions">
                        <b data-terminal-run-state>Ctrl + Enter 执行</b>
                        <button type="button" class="terminal-icon-btn" data-terminal-download title="下载输出" aria-label="下载输出"><i data-lucide="download"></i></button>
                        <button type="button" class="terminal-icon-btn" data-terminal-fullscreen title="专注模式" aria-label="专注模式"><i data-lucide="maximize-2"></i></button>
                        <button type="button" class="terminal-icon-btn" data-terminal-copy title="复制输出" aria-label="复制输出"><i data-lucide="copy"></i></button>
                        <button type="button" class="terminal-icon-btn" data-terminal-clear title="清空输出" aria-label="清空输出"><i data-lucide="trash-2"></i></button>
                    </div>
                </div>
                <pre class="terminal-output" id="terminalOutput">BM ucloud tools server terminal
server: <?= e($sshHost) ?>
user: <?= e($sshUser) ?>
mode: <?= $gatewayUrl !== '' ? 'gateway token available, command mode ready' : 'ssh command mode' ?>
timeout: <?= e($commandTimeout) ?>s

输入命令后按 Ctrl + Enter 或点击执行。</pre>
                <form class="terminal-command-form" data-server-id="<?= e($serverId) ?>" data-command-url="<?= url('servers/terminal/command') ?>" data-token-url="<?= url('servers/terminal/token') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($serverId) ?>">
                    <label>
                        <span>$</span>
                        <textarea name="command" rows="3" autocomplete="off" spellcheck="false" placeholder="输入任意 SSH 命令，支持粘贴多行 shell 脚本" <?= $terminalEnabled ? '' : 'disabled' ?>></textarea>
                    </label>
                    <button class="bm-btn bm-btn-primary" type="submit" data-terminal-submit data-icon="send" <?= $terminalEnabled ? '' : 'disabled' ?>>执行</button>
                    <small class="terminal-run-state">↑ / ↓ 切换历史，Ctrl + L 清屏。命令不限制内容，请确认目标服务器和命令风险。</small>
                </form>
            </section>
        </main>

        <aside class="terminal-tool-panel">
            <section class="terminal-quick-card">
                <div class="terminal-side-head">
                    <span>快捷命令</span>
                    <strong>常用巡检</strong>
                </div>
                <div class="terminal-quick-groups">
                    <?php foreach ($quickGroups as $group): ?>
                        <section>
                            <h2><?= e($group['title']) ?></h2>
                            <div class="terminal-snippet-bar">
                                <?php foreach ($group['items'] as $item): ?>
                                    <button type="button" data-terminal-snippet="<?= $terminalSnippet($item['command']) ?>" data-icon="<?= e($item['icon']) ?>"><?= e($item['label']) ?></button>
                                <?php endforeach; ?>
                            </div>
                        </section>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="terminal-quick-card">
                <div class="terminal-side-head">
                    <span>最近审计</span>
                    <strong>最近 20 条</strong>
                    <a class="bm-text-link" href="<?= url('servers/commands?server_id=' . $serverId) ?>">全部</a>
                </div>
                <div class="server-command-list terminal-audit-list">
                    <?php if (!$commands): ?><p class="muted">暂无命令记录。</p><?php endif; ?>
                    <?php foreach ($commands as $row): ?>
                        <p>
                            <button type="button" data-terminal-fill="<?= e(isset($row['command']) ? $row['command'] : '') ?>"><code><?= e(text_limit(isset($row['command']) ? $row['command'] : '', 120)) ?></code></button>
                            <span><?= e(isset($row['created_at']) ? $row['created_at'] : '') ?></span>
                        </p>
                    <?php endforeach; ?>
                </div>
            </section>
        </aside>
    </section>
</section>

<script>
(function () {
    var form = document.querySelector('.terminal-command-form');
    var output = document.getElementById('terminalOutput');
    var initialOutput = output ? output.textContent : '';
    var storageKey = form ? 'bmtools:ssh-history:' + (form.dataset.serverId || 'default') : '';
    var history = [];
    var historyIndex = 0;
    try {
        history = storageKey ? JSON.parse(localStorage.getItem(storageKey) || '[]') : [];
        if (!Array.isArray(history)) history = [];
    } catch (e) {
        history = [];
    }
    historyIndex = history.length;

    function write(text) {
        if (!output) return;
        output.textContent += "\n" + text;
        output.scrollTop = output.scrollHeight;
    }

    function setState(text) {
        var state = document.querySelector('[data-terminal-run-state]');
        if (state) state.textContent = text;
    }

    function renderSteps(steps) {
        if (!Array.isArray(steps) || !steps.length) return '';
        return '\n\n检查结果：\n' + steps.map(function (step, index) {
            var label = step.label || ('步骤 ' + (index + 1));
            var status = step.status || 'pending';
            var message = step.message || '';
            return '- [' + status + '] ' + label + (message ? '：' + message : '');
        }).join('\n');
    }

    function formatDuration(ms) {
        var value = Number(ms || 0);
        if (!value || value < 0) return '';
        if (value < 1000) return value + 'ms';
        return (value / 1000).toFixed(2) + 's';
    }

    function saveHistory(command) {
        if (!storageKey || !command.trim()) return;
        history = history.filter(function (item) { return item !== command; });
        history.push(command);
        if (history.length > 80) history = history.slice(history.length - 80);
        historyIndex = history.length;
        try { localStorage.setItem(storageKey, JSON.stringify(history)); } catch (e) {}
    }

    function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text);
        }
        var area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', 'readonly');
        area.style.position = 'fixed';
        area.style.left = '-9999px';
        document.body.appendChild(area);
        area.select();
        document.execCommand('copy');
        document.body.removeChild(area);
        return Promise.resolve();
    }

    var switcher = document.querySelector('[data-terminal-server-switch]');
    if (switcher) {
        switcher.addEventListener('change', function () {
            if (switcher.value) window.location.href = switcher.value;
        });
    }

    if (form && output) {
        var commandBox = form.querySelector('[name="command"]');
        var submitBtn = form.querySelector('[data-terminal-submit]');
        if (commandBox) {
            commandBox.addEventListener('keydown', function (event) {
                if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
                    event.preventDefault();
                    form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit'));
                    return;
                }
                if ((event.ctrlKey || event.metaKey) && String(event.key).toLowerCase() === 'l') {
                    event.preventDefault();
                    output.textContent = initialOutput;
                    setState('已清屏');
                    return;
                }
                if (commandBox.value.indexOf("\n") === -1 && event.key === 'ArrowUp' && history.length) {
                    event.preventDefault();
                    historyIndex = Math.max(0, historyIndex - 1);
                    commandBox.value = history[historyIndex] || '';
                    return;
                }
                if (commandBox.value.indexOf("\n") === -1 && event.key === 'ArrowDown' && history.length) {
                    event.preventDefault();
                    historyIndex = Math.min(history.length, historyIndex + 1);
                    commandBox.value = historyIndex >= history.length ? '' : history[historyIndex];
                }
            });
        }

        form.addEventListener('submit', function (event) {
            event.preventDefault();
            var input = form.querySelector('[name="command"]');
            var command = input ? input.value : '';
            if (!command.trim()) {
                setState('请输入命令后再执行');
                return;
            }
            var data = new FormData(form);
            saveHistory(command);
            write('$ ' + command);
            input.value = '';
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.classList.add('is-running');
            }
            setState('正在执行，等待服务器返回...');
            fetch(form.dataset.commandUrl, { method: 'POST', body: data, credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (res) { return window.SKY_PARSE_JSON_RESPONSE ? window.SKY_PARSE_JSON_RESPONSE(res) : res.json(); })
                .then(function (json) {
                    var duration = formatDuration(json.duration_ms);
                    write(json.success ? (json.output || '[无输出]') : ('ERROR: ' + (json.message || '执行失败') + renderSteps(json.steps)));
                    setState(json.success ? ('完成：' + (json.time || '') + (duration ? ' / ' + duration : '')) : ('执行失败' + (duration ? ' / ' + duration : '') + '，请查看输出'));
                })
                .catch(function (error) {
                    write('ERROR: ' + (error && error.message ? error.message : '请求失败，请检查网络。'));
                    setState('请求失败');
                })
                .finally(function () {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.classList.remove('is-running');
                    }
                    if (input) input.focus();
                });
        });
    }

    document.querySelectorAll('[data-terminal-snippet]').forEach(function (button) {
        button.addEventListener('click', function () {
            var box = form && form.querySelector('[name="command"]');
            if (!box) return;
            box.value = button.dataset.terminalSnippet || '';
            box.focus();
            setState('已填入快捷命令，检查后执行');
        });
    });

    document.querySelectorAll('[data-terminal-fill]').forEach(function (button) {
        button.addEventListener('click', function () {
            var box = form && form.querySelector('[name="command"]');
            if (!box) return;
            box.value = button.dataset.terminalFill || '';
            box.focus();
            setState('已回填历史命令');
        });
    });

    var copyBtn = document.querySelector('[data-terminal-copy]');
    if (copyBtn && output) {
        copyBtn.addEventListener('click', function () {
            copyText(output.textContent || '').then(function () {
                setState('输出已复制');
            }).catch(function () {
                setState('复制失败，请手动选择输出');
            });
        });
    }

    var clearBtn = document.querySelector('[data-terminal-clear]');
    if (clearBtn && output) {
        clearBtn.addEventListener('click', function () {
            output.textContent = initialOutput;
            setState('已清屏');
        });
    }

    var downloadBtn = document.querySelector('[data-terminal-download]');
    if (downloadBtn && output) {
        downloadBtn.addEventListener('click', function () {
            var blob = new Blob([output.textContent || ''], { type: 'text/plain;charset=utf-8' });
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'server-terminal-' + (form && form.dataset.serverId ? form.dataset.serverId : 'output') + '-' + Date.now() + '.log';
            document.body.appendChild(link);
            link.click();
            URL.revokeObjectURL(link.href);
            document.body.removeChild(link);
            setState('输出已下载');
        });
    }

    var fullBtn = document.querySelector('[data-terminal-fullscreen]');
    var shellCard = document.querySelector('.terminal-tool-console');
    if (fullBtn && shellCard) {
        fullBtn.addEventListener('click', function () {
            document.body.classList.toggle('terminal-focus-mode');
            shellCard.classList.toggle('is-focus-mode');
            setState(shellCard.classList.contains('is-focus-mode') ? '已进入专注模式，按按钮可退出' : '已退出专注模式');
        });
    }

    var tokenBtn = document.querySelector('.terminal-token-btn');
    if (tokenBtn && form) {
        tokenBtn.addEventListener('click', function () {
            var tokenInput = form.querySelector('[name="_token"]');
            var idInput = form.querySelector('[name="id"]');
            var data = new FormData();
            data.append('_token', tokenInput ? tokenInput.value : '');
            data.append('id', idInput ? idInput.value : '');
            fetch(form.dataset.tokenUrl, { method: 'POST', body: data, credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (res) { return window.SKY_PARSE_JSON_RESPONSE ? window.SKY_PARSE_JSON_RESPONSE(res) : res.json(); })
                .then(function (json) {
                    if (json.success && json.gateway_url) {
                        write('TOKEN: ' + json.token + '\nGATEWAY: ' + json.gateway_url + '\nEXPIRES: ' + json.expires_at);
                    } else {
                        write(json.success ? (json.message || '令牌已签发，但未配置网关。') : ('ERROR: ' + json.message));
                    }
                })
                .catch(function (error) { write('ERROR: ' + (error && error.message ? error.message : '令牌签发请求失败。')); });
        });
    }
})();
</script>
