<?php $fileUrl = public_url($file['file_url']); ?>

<section class="bm-workspace file-detail-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Image Detail</span>
            <h1>图片详情</h1>
            <p><?= e($file['original_name']) ?> · <?= e(format_bytes($file['file_size'])) ?> · 下载 <?= e((int) ($file['download_count'] ?? 0)) ?> 次 · <?= e($file['created_at']) ?></p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('files') ?>" data-icon="arrow-left">返回图片管理</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('files/download?id=' . $file['id']) ?>" data-icon="download">下载图片</a>
                <a class="bm-btn bm-btn-primary" href="<?= e($fileUrl) ?>" target="_blank" data-icon="external-link">查看原图</a>
            </div>
        </div>
    </header>

    <section class="bm-detail-layout">
        <article class="bm-card bm-detail-preview">
            <img src="<?= e($fileUrl) ?>" alt="<?= e($file['original_name']) ?>">
        </article>
        <article class="bm-card detail-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Links</span>
                    <h2>外链格式</h2>
                </div>
            </div>
            <div class="link-box bm-link-box-rich">
                <label>原图直链<input readonly value="<?= e($fileUrl) ?>"></label>
                <label>Markdown<input readonly value="![<?= e($file['original_name']) ?>](<?= e($fileUrl) ?>)"></label>
                <label>HTML<input readonly value="&lt;img src=&quot;<?= e($fileUrl) ?>&quot; alt=&quot;<?= e($file['original_name']) ?>&quot;&gt;"></label>
                <label>BBCode<input readonly value="[img]<?= e($fileUrl) ?>[/img]"></label>
            </div>
            <div class="bm-form-actions">
                <button class="bm-btn bm-btn-primary copy-current-inputs" type="button" data-icon="copy">复制全部链接</button>
            </div>

            <div class="bm-card-head bm-detail-meta-head">
                <div>
                    <span class="bm-eyebrow">Meta</span>
                    <h2>文件信息</h2>
                </div>
            </div>
            <div class="bm-meta-grid">
                <span>文件名</span><b><?= e($file['original_name']) ?></b>
                <span>文件大小</span><b><?= e(format_bytes($file['file_size'])) ?></b>
                <span>图片尺寸</span><b><?= e(($file['width'] ?: '-') . ' x ' . ($file['height'] ?: '-')) ?></b>
                <span>MIME</span><b><?= e($file['mime_type']) ?></b>
                <span>下载次数</span><b><?= e((int) ($file['download_count'] ?? 0)) ?></b>
                <span>MD5</span><b><?= e($file['md5'] ?: '-') ?></b>
                <span>存储路径</span><b><?= e($file['file_path']) ?></b>
            </div>
        </article>
    </section>
</section>
