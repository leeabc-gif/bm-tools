<?php
$storage = isset($usage['storage']) ? $usage['storage'] : null;
$package = isset($usage['package']) ? $usage['package'] : ['name' => '默认套餐', 'single_file_limit' => 0, 'allow_api' => 0];
$singleLimit = (int) $package['single_file_limit'] > 0 ? format_bytes($package['single_file_limit']) : '不限';
$storageTypeNames = [
    'local' => '本地存储',
    'oss' => '阿里云 OSS',
    'cos' => '腾讯云 COS',
    'kodo' => '七牛云 Kodo',
    's3' => 'S3 兼容存储',
    'minio' => 'MinIO 私有云',
    'r2' => 'Cloudflare R2',
    'webdav' => 'WebDAV',
    'bmtools' => '同系统对接',
];
$storageName = $storage ? (isset($storageTypeNames[$storage['type']]) ? $storageTypeNames[$storage['type']] : $storage['type']) : '未配置';
$storageDesc = $storage ? $storage['name'] : '请先在后台配置默认存储源';
$storagePercent = isset($usage['storage_percent']) ? (float) $usage['storage_percent'] : 0;
$imageBatchLimit = (int) setting('upload_image_batch_limit', 20);
$uploadConcurrency = (int) setting('upload_max_concurrency', 2);
$imageDailyLimit = (int) setting('upload_image_daily_limit', 0);
?>

<section class="bm-workspace files-workspace-v2" id="top">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Image Host</span>
            <h1>图床工作台</h1>
            <p>上传、远程拉取、外链复制和图片管理分区处理。页面只保留图床核心能力，减少干扰，电脑和手机都能正常操作。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">升级套餐</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('api/console') ?>" data-icon="terminal">API 上传</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('files/logs') ?>" data-icon="clipboard-list">文件记录</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('netdisk/recycle') ?>" data-icon="rotate-ccw">回收站</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card">
            <span>当前套餐</span>
            <strong><?= e($package['name']) ?></strong>
            <small>单文件限制：<?= e($singleLimit) ?></small>
        </article>
        <article class="bm-stat-card <?= !empty($usage['is_near_limit']) ? 'is-warn' : '' ?>">
            <span>容量使用</span>
            <strong><?= e($storagePercent) ?>%</strong>
            <small><?= e(format_bytes($usage['used_storage'])) ?> / <?= e(format_bytes($usage['total_storage'])) ?></small>
            <i class="bm-progress"><em style="width: <?= e($storagePercent) ?>%"></em></i>
        </article>
        <article class="bm-stat-card">
            <span>图片数量</span>
            <strong><?= e($usage['file_count']) ?></strong>
            <small>累计占用：<?= e(format_bytes($usage['file_size'])) ?></small>
        </article>
        <article class="bm-stat-card">
            <span>默认存储</span>
            <strong><?= e($storageName) ?></strong>
            <small><?= e($storageDesc) ?></small>
        </article>
    </section>

    <?php if (!empty($usage['is_near_limit'])): ?>
        <section class="bm-inline-notice is-warning">
            <i data-lucide="alert-triangle"></i>
            <div>
                <strong>容量即将用满</strong>
                <span>当前空间已使用 <?= e($storagePercent) ?>%，建议清理回收站或升级套餐，避免后续上传失败。</span>
            </div>
            <a href="<?= url('packages') ?>">查看升级方案</a>
        </section>
    <?php endif; ?>

    <?php if (!$storage): ?>
        <section class="bm-inline-notice is-warning">
            <i data-lucide="database-zap"></i>
            <div>
                <strong>当前没有可用存储线路</strong>
                <span>图床上传依赖后台默认对象存储，请先在后台配置并测试存储源。</span>
            </div>
        </section>
    <?php endif; ?>

    <section class="bm-upload-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Upload</span>
                <h2>上传图片</h2>
            </div>
        </div>

        <form method="post" action="<?= url('files/upload') ?>" enctype="multipart/form-data" class="upload-form bm-upload-form">
            <?= csrf_field() ?>
            <div class="drop-zone large bm-drop-zone">
                <input type="file" name="images[]" multiple accept="image/*">
                <i data-lucide="upload-cloud"></i>
                <strong>拖拽图片到这里，或点击选择图片</strong>
                <span>支持 JPG、PNG、GIF、WebP，也可以直接粘贴截图。上传完成后自动生成多格式外链。</span>
            </div>
            <button class="bm-btn bm-btn-primary" type="submit" data-icon="upload-cloud">开始上传</button>
            <div class="upload-limit-note">
                <i data-lucide="info"></i>
                <div>
                    <strong>上传规则</strong>
                    <span>单次最多 <?= e($imageBatchLimit) ?> 张，并发 <?= e($uploadConcurrency) ?> 个；每日图片上限 <?= $imageDailyLimit > 0 ? e($imageDailyLimit . ' 张') : '不限制' ?>。上传时会逐张显示进度和失败原因。</span>
                </div>
            </div>
        </form>

        <form method="post" action="<?= url('files/fetch') ?>" class="bm-url-fetch">
            <?= csrf_field() ?>
            <label>
                <span>远程图片地址</span>
                <input name="remote_url" placeholder="https://example.com/image.jpg">
            </label>
            <button class="bm-btn bm-btn-soft" type="submit" data-icon="link">URL 拉取</button>
        </form>
    </section>

    <section class="bm-section-head">
        <div>
            <span class="bm-eyebrow">Library</span>
            <h2>图片列表</h2>
        </div>
        <form method="get" action="<?= url('files') ?>" class="bm-filter-bar">
            <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索文件名">
            <input type="date" name="date_start" value="<?= e($dateStart) ?>">
            <input type="date" name="date_end" value="<?= e($dateEnd) ?>">
            <button class="bm-btn bm-btn-soft" type="submit" data-icon="filter">筛选</button>
            <a class="bm-btn bm-btn-plain" href="<?= url('files') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <form method="post" action="<?= url('files/delete') ?>" class="confirm-form bm-library-form" data-confirm="确认把选中的图片移入回收站吗？">
        <?= csrf_field() ?>
        <div class="bm-bulk-bar">
            <div>
                <strong>批量操作</strong>
                <span>勾选图片后可复制直链或移入回收站。</span>
            </div>
            <div class="bm-action-row">
                <button class="bm-btn bm-btn-soft copy-selected" type="button" data-icon="copy">复制直链</button>
                <button class="bm-btn bm-btn-danger" type="submit" data-icon="archive-x">移入回收站</button>
            </div>
        </div>

        <div class="bm-image-grid">
            <?php if (!$files): ?>
                <article class="bm-empty-state bm-image-empty">
                    <i data-lucide="image-off"></i>
                    <strong>还没有图片</strong>
                    <span>从上方上传区拖拽图片，或粘贴截图快速上传。上传后会在这里显示缩略图和常用外链。</span>
                    <a class="bm-btn bm-btn-primary" href="#top" data-icon="upload-cloud">去上传</a>
                </article>
            <?php endif; ?>

            <?php foreach ($files as $file): ?>
                <?php
                $fileUrl = public_url($file['file_url']);
                $thumbUrl = public_url($file['thumbnail_url'] ?: $file['file_url']);
                ?>
                <article class="image-card bm-image-card">
                    <label class="bm-check">
                        <input type="checkbox" name="ids[]" value="<?= e($file['id']) ?>" data-url="<?= e($fileUrl) ?>">
                        <span></span>
                    </label>
                    <a class="bm-image-thumb" href="<?= e($fileUrl) ?>" target="_blank">
                        <img src="<?= e($thumbUrl) ?>" alt="<?= e($file['original_name']) ?>" loading="lazy">
                    </a>
                    <div class="bm-image-meta">
                        <strong title="<?= e($file['original_name']) ?>"><?= e($file['original_name']) ?></strong>
                        <span><?= e(format_bytes($file['file_size'])) ?> · 下载 <?= e((int) ($file['download_count'] ?? 0)) ?> 次 · <?= e($file['created_at']) ?></span>
                    </div>
                    <div class="link-box bm-link-box">
                        <label>直链<input readonly value="<?= e($fileUrl) ?>"></label>
                        <label>Markdown<input readonly value="![<?= e($file['original_name']) ?>](<?= e($fileUrl) ?>)"></label>
                        <label>HTML<input readonly value="&lt;img src=&quot;<?= e($fileUrl) ?>&quot; alt=&quot;<?= e($file['original_name']) ?>&quot;&gt;"></label>
                        <label>BBCode<input readonly value="[img]<?= e($fileUrl) ?>[/img]"></label>
                    </div>
                    <div class="card-actions bm-card-actions">
                        <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制链接</button>
                        <a class="bm-btn bm-btn-soft" href="<?= url('files/download?id=' . $file['id']) ?>" data-icon="download">下载</a>
                        <a class="bm-btn bm-btn-plain" href="<?= url('files/detail?id=' . $file['id']) ?>" data-icon="eye">详情</a>
                        <a class="bm-btn bm-btn-plain" href="<?= e($fileUrl) ?>" target="_blank" data-icon="external-link">原图</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </form>
</section>
