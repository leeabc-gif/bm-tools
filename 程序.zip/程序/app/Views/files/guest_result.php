<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Guest Upload</p>
        <h1>游客上传结果</h1>
        <p>这些链接已经可以直接用于文章、论坛、文档或外部页面。游客上传只返回链接，不提供后续文件管理。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url('/') ?>" data-icon="upload-cloud">继续上传</a>
        <a class="btn btn-ghost" href="<?= url('register') ?>" data-icon="user-plus">注册管理图片</a>
    </div>
</section>

<section class="image-grid reveal">
    <?php if (!$items): ?>
        <article class="image-card glass empty-card image-empty-card">
            <b>暂无游客上传结果</b>
            <p>从首页上传图片后，这里会展示直链、Markdown 和 HTML 代码。</p>
            <a class="btn btn-primary" href="<?= url('/') ?>" data-icon="home">返回首页</a>
        </article>
    <?php endif; ?>
    <?php foreach ($items as $item): ?>
        <article class="image-card glass">
            <img src="<?= e($item['url']) ?>" alt="<?= e($item['name']) ?>" loading="lazy">
            <div class="image-meta">
                <b title="<?= e($item['name']) ?>"><?= e($item['name']) ?></b>
                <small><?= e(format_bytes($item['size'])) ?></small>
            </div>
            <div class="link-box">
                <label>直链<input readonly value="<?= e($item['url']) ?>"></label>
                <label>Markdown<input readonly value="<?= e($item['markdown']) ?>"></label>
                <label>HTML<input readonly value="<?= e($item['html']) ?>"></label>
            </div>
            <div class="card-actions">
                <button class="btn btn-ghost copy-current-inputs" type="button" data-icon="copy">复制链接</button>
                <a class="btn btn-ghost" href="<?= e($item['url']) ?>" target="_blank" data-icon="external-link">打开图片</a>
            </div>
        </article>
    <?php endforeach; ?>
</section>
