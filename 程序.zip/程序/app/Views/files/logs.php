<?php
$stats = isset($stats) && is_array($stats) ? $stats : ['total' => 0, 'uploads' => 0, 'downloads' => 0, 'today' => 0];
$actionLabels = isset($actionLabels) && is_array($actionLabels) ? $actionLabels : [];
$scopeOptions = [
    '' => '全部记录',
    'upload' => '上传记录',
    'download' => '下载记录',
    'delete' => '删除记录',
    'restore' => '恢复记录',
];
$exportUrl = 'files/logs/export?' . http_build_query([
    'scope' => $scope,
    'action' => $action,
    'keyword' => $keyword,
    'date_start' => $dateStart,
    'date_end' => $dateEnd,
]);
$actionIcons = [
    'image_upload' => 'image-plus',
    'file_upload' => 'upload-cloud',
    'image_download' => 'download',
    'file_download' => 'download',
    'image_trash' => 'archive-x',
    'file_trash' => 'archive-x',
    'file_restore' => 'rotate-ccw',
    'file_purge' => 'trash-2',
    'api_delete' => 'terminal',
    'folder_delete' => 'folder-x',
];
$actionTone = function ($action) {
    if (strpos($action, 'upload') !== false) {
        return 'ok';
    }
    if (strpos($action, 'download') !== false) {
        return 'soft';
    }
    if (strpos($action, 'trash') !== false || strpos($action, 'delete') !== false || strpos($action, 'purge') !== false) {
        return 'danger';
    }
    return 'muted';
};
$sourceLabel = function ($detail) {
    if (!is_array($detail) || empty($detail['source'])) {
        return '控制台';
    }
    $map = [
        'image_host' => '图床',
        'netdisk' => '网盘',
        'api' => 'API',
    ];
    return isset($map[$detail['source']]) ? $map[$detail['source']] : $detail['source'];
};
?>

<section class="bm-workspace file-log-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">File Activity</span>
            <h1>文件记录</h1>
            <p>集中查看个人图床和个人网盘的上传、下载、删除、恢复记录，方便排查文件操作和下载来源。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('files') ?>" data-icon="image">图床服务</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('netdisk') ?>" data-icon="hard-drive">个人网盘</a>
                <a class="bm-btn bm-btn-soft" href="<?= url($exportUrl) ?>" data-icon="download">导出 CSV</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('netdisk/recycle') ?>" data-icon="archive-restore">回收站</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>全部记录</span><strong><?= e(number_format((int) $stats['total'])) ?></strong><small>上传、下载和文件操作</small></article>
        <article class="bm-stat-card"><span>上传</span><strong><?= e(number_format((int) $stats['uploads'])) ?></strong><small>图片和网盘文件</small></article>
        <article class="bm-stat-card"><span>下载</span><strong><?= e(number_format((int) $stats['downloads'])) ?></strong><small>个人文件下载次数</small></article>
        <article class="bm-stat-card"><span>今日新增</span><strong><?= e(number_format((int) $stats['today'])) ?></strong><small>当天操作记录</small></article>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Filter</span>
                <h2>筛选记录</h2>
            </div>
        </div>
        <form method="get" action="<?= url('files/logs') ?>" class="bm-filter-bar file-log-filter">
            <select name="scope">
                <?php foreach ($scopeOptions as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $scope === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="action">
                <option value="">全部动作</option>
                <?php foreach ($actionLabels as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $action === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索文件名、动作或 IP">
            <input type="date" name="date_start" value="<?= e($dateStart) ?>">
            <input type="date" name="date_end" value="<?= e($dateEnd) ?>">
            <button class="bm-btn bm-btn-soft" type="submit" data-icon="filter">筛选</button>
            <a class="bm-btn bm-btn-plain" href="<?= url('files/logs') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <section class="bm-record-list file-log-list">
        <?php if (!$logs): ?>
            <article class="bm-empty-state">
                <i data-lucide="clipboard-list"></i>
                <strong>暂无文件记录</strong>
                <span>上传、下载、删除或恢复文件后，这里会显示对应记录。</span>
                <a class="bm-btn bm-btn-primary" href="<?= url('files') ?>" data-icon="upload-cloud">去上传</a>
            </article>
        <?php endif; ?>

        <?php foreach ($logs as $row): ?>
            <?php
            $detail = json_decode((string) ($row['detail'] ?? ''), true);
            $detail = is_array($detail) ? $detail : [];
            $rowAction = (string) ($row['action'] ?? '');
            $label = isset($actionLabels[$rowAction]) ? $actionLabels[$rowAction] : $rowAction;
            $icon = isset($actionIcons[$rowAction]) ? $actionIcons[$rowAction] : 'file-clock';
            $fileName = trim((string) ($row['file_name'] ?? ''));
            if ($fileName === '') {
                $fileName = '文件记录 #' . (int) $row['id'];
            }
            ?>
            <article class="bm-record-card file-log-card">
                <div class="bm-record-main">
                    <span class="bm-icon-tile is-small"><i data-lucide="<?= e($icon) ?>"></i></span>
                    <div>
                        <strong><?= e($fileName) ?></strong>
                        <small><?= e($row['created_at']) ?> · <?= e($sourceLabel($detail)) ?></small>
                    </div>
                </div>
                <div class="bm-record-meta">
                    <span><b>动作</b><em class="status-pill <?= e($actionTone($rowAction)) ?>"><?= e($label) ?></em></span>
                    <span><b>大小</b><?= e(format_bytes((int) ($row['file_size'] ?? 0))) ?></span>
                    <span><b>IP</b><?= e($row['ip'] ?: '-') ?></span>
                    <?php if (!empty($detail['folder_id'])): ?>
                        <span><b>文件夹</b>#<?= e((int) $detail['folder_id']) ?></span>
                    <?php endif; ?>
                </div>
                <div class="bm-record-actions">
                    <?php if (!empty($row['file_id']) && !empty($row['file_url'])): ?>
                        <?php if (($row['file_type'] ?? '') === 'image'): ?>
                            <a class="bm-btn bm-btn-soft" href="<?= url('files/detail?id=' . (int) $row['file_id']) ?>" data-icon="eye">详情</a>
                            <a class="bm-btn bm-btn-soft" href="<?= url('files/download?id=' . (int) $row['file_id']) ?>" data-icon="download">下载</a>
                        <?php else: ?>
                            <a class="bm-btn bm-btn-soft" href="<?= url('netdisk/download?id=' . (int) $row['file_id']) ?>" data-icon="download">下载</a>
                            <a class="bm-btn bm-btn-plain" href="<?= url('netdisk') ?>" data-icon="hard-drive">网盘</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="muted">文件可能已清理</span>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
