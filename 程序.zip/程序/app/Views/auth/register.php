<?php $siteName = setting('site_name', app_brand_name()); ?>
<main class="auth-brand-page">
    <section class="auth-brand-copy">
        <a class="auth-logo" href="<?= url('/') ?>">
            <span><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
            <b><?= e($siteName) ?></b>
        </a>
        <p class="auth-kicker">开通个人工作台</p>
        <h1>创建你的图片外链和个人网盘账号</h1>
        <p>注册后即可使用图床上传、文件管理、分享仓库、API 接入等功能，适合个人博客、项目文档和内容发布。</p>
        <div class="auth-points">
            <span><i data-lucide="check"></i> 自动生成 Markdown / HTML 图链</span>
            <span><i data-lucide="check"></i> 统一管理图片、文件和目录</span>
            <span><i data-lucide="check"></i> 支持公开与私密分享</span>
        </div>
    </section>

    <section class="auth-panel" aria-label="注册">
        <form method="post" action="<?= url('register') ?>">
            <?= csrf_field() ?>
            <div class="auth-panel-head">
                <p class="auth-kicker">创建账号</p>
                <h2>注册账号</h2>
            </div>

            <?php if ($msg = flash('success')): ?><div class="auth-alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="auth-alert error"><?= e($msg) ?></div><?php endif; ?>

            <label>
                <span>用户名</span>
                <input name="username" value="<?= e(old('username')) ?>" autocomplete="username" required placeholder="3-32 位字母、数字或下划线">
            </label>

            <label>
                <span>邮箱</span>
                <input type="email" name="email" value="<?= e(old('email')) ?>" autocomplete="email" required placeholder="name@example.com">
            </label>

            <?php if ((string) setting('register_email_code_enabled', '0') === '1'): ?>
                <label>
                    <span>邮箱验证码</span>
                    <div class="auth-input-action">
                        <input name="email_code" required placeholder="输入验证码">
                        <button type="button" class="send-code-btn" data-scene="register" data-token="<?= e(csrf_token()) ?>">发送</button>
                    </div>
                </label>
            <?php endif; ?>

            <label>
                <span>密码</span>
                <input type="password" name="password" autocomplete="new-password" required placeholder="至少 6 位">
            </label>

            <label>
                <span>确认密码</span>
                <input type="password" name="password_confirm" autocomplete="new-password" required placeholder="再次输入密码">
            </label>

            <button class="auth-submit" type="submit">
                <i data-lucide="user-plus"></i>
                创建账号
            </button>

            <div class="auth-switch">
                <span>已有账号？</span>
                <a href="<?= url('login') ?>">立即登录</a>
            </div>
        </form>
    </section>
</main>
