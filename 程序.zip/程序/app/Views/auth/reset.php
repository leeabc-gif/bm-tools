<?php $siteName = setting('site_name', app_brand_name()); ?>
<main class="auth-brand-page">
    <section class="auth-brand-copy">
        <a class="auth-logo" href="<?= url('/') ?>">
            <span><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
            <b><?= e($siteName) ?></b>
        </a>
        <p class="auth-kicker">设置新密码</p>
        <h1>设置新的登录密码</h1>
        <p>验证码已为 <?= e($email) ?> 生成，请在有效期内完成密码重置。</p>
        <div class="auth-points">
            <span><i data-lucide="check"></i> 新密码至少 6 位</span>
            <span><i data-lucide="check"></i> 完成后重新使用新密码登录</span>
            <span><i data-lucide="check"></i> 请不要与其他站点复用弱密码</span>
        </div>
    </section>

    <section class="auth-panel" aria-label="重置密码">
        <form method="post" action="<?= url('reset-password') ?>">
            <?= csrf_field() ?>
            <div class="auth-panel-head">
                <p class="auth-kicker">重置登录密码</p>
                <h2>重置密码</h2>
            </div>

            <?php if ($msg = flash('success')): ?><div class="auth-alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="auth-alert error"><?= e($msg) ?></div><?php endif; ?>

            <label>
                <span>验证码</span>
                <input name="code" required placeholder="输入邮箱验证码">
            </label>

            <label>
                <span>新密码</span>
                <input type="password" name="password" autocomplete="new-password" required placeholder="至少 6 位">
            </label>

            <button class="auth-submit" type="submit">
                <i data-lucide="key-round"></i>
                重置密码
            </button>
        </form>
    </section>
</main>
