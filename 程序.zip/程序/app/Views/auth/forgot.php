<?php $siteName = setting('site_name', app_brand_name()); ?>
<main class="auth-brand-page">
    <section class="auth-brand-copy">
        <a class="auth-logo" href="<?= url('/') ?>">
            <span><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
            <b><?= e($siteName) ?></b>
        </a>
        <p class="auth-kicker">账号找回</p>
        <h1>找回你的账号访问权限</h1>
        <p>输入注册邮箱后，系统会生成验证码，用于继续完成密码重置。</p>
        <div class="auth-points">
            <span><i data-lucide="check"></i> 验证码有时效限制</span>
            <span><i data-lucide="check"></i> 未配置邮件时可在数据库查看测试验证码</span>
            <span><i data-lucide="check"></i> 重置完成后可直接重新登录</span>
        </div>
    </section>

    <section class="auth-panel" aria-label="找回密码">
        <form method="post" action="<?= url('forgot') ?>">
            <?= csrf_field() ?>
            <div class="auth-panel-head">
                <p class="auth-kicker">重置登录密码</p>
                <h2>找回密码</h2>
            </div>

            <?php if ($msg = flash('success')): ?><div class="auth-alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="auth-alert error"><?= e($msg) ?></div><?php endif; ?>

            <label>
                <span>注册邮箱</span>
                <input type="email" name="email" value="<?= e(old('email')) ?>" autocomplete="email" required placeholder="name@example.com">
            </label>

            <button class="auth-submit" type="submit">
                <i data-lucide="mail"></i>
                发送验证码
            </button>

            <div class="auth-switch">
                <span>想起来了？</span>
                <a href="<?= url('login') ?>">返回登录</a>
            </div>
        </form>
    </section>
</main>
