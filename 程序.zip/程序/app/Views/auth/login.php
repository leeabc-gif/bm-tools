<?php $siteName = setting('site_name', app_brand_name()); ?>
<main class="auth-brand-page">
    <section class="auth-brand-copy">
        <a class="auth-logo" href="<?= url('/') ?>">
            <span><img src="<?= asset('icons/logo-mark.svg') ?>" alt="<?= e($siteName) ?> Logo"></span>
            <b><?= e($siteName) ?></b>
        </a>
        <p class="auth-kicker">图床 · 网盘 · 分享仓库</p>
        <h1>登录后继续管理你的图片外链和个人资源库</h1>
        <p>登录后可以上传图片、复制多格式图链、管理网盘目录、维护分享仓库和查看 API 接入信息。</p>
        <div class="auth-points">
            <span><i data-lucide="check"></i> 图床与文件统一管理</span>
            <span><i data-lucide="check"></i> 支持分享仓库和权限配置</span>
            <span><i data-lucide="check"></i> 适配常用上传工具和 API</span>
        </div>
    </section>

    <section class="auth-panel" aria-label="登录">
        <form method="post" action="<?= url('login') ?>">
            <?= csrf_field() ?>
            <div class="auth-panel-head">
                <p class="auth-kicker">继续使用</p>
                <h2>账号登录</h2>
            </div>

            <?php if ($msg = flash('success')): ?><div class="auth-alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="auth-alert error"><?= e($msg) ?></div><?php endif; ?>

            <label>
                <span>邮箱 / 用户名</span>
                <input type="text" name="account" value="<?= e(old('account')) ?>" autocomplete="username" required placeholder="输入邮箱或用户名">
            </label>

            <label>
                <span>密码</span>
                <input type="password" name="password" autocomplete="current-password" required placeholder="输入账号密码">
            </label>

            <div class="auth-row">
                <label class="auth-check">
                    <input type="checkbox" name="remember" value="1" checked>
                    <span>记住登录状态</span>
                </label>
                <a href="<?= url('forgot') ?>">忘记密码？</a>
            </div>

            <button class="auth-submit" type="submit">
                <i data-lucide="log-in"></i>
                登录控制台
            </button>

            <div class="auth-switch">
                <span>还没有账号？</span>
                <a href="<?= url('register') ?>">创建账号</a>
            </div>
        </form>
    </section>
</main>
