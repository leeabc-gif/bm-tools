<?php
$heroMetrics = [
    ['label' => '用户总数', 'value' => $stats['users'], 'sub' => '今日新增 ' . $stats['today_users'], 'icon' => 'users', 'tone' => 'blue'],
    ['label' => '文件总量', 'value' => $stats['files'], 'sub' => '图片 ' . $stats['images'] . ' · 网盘 ' . $stats['netdisk_files'], 'icon' => 'files', 'tone' => 'green'],
    ['label' => '存储占用', 'value' => format_bytes($stats['storage_used']), 'sub' => '全站累计文件体积', 'icon' => 'database', 'tone' => 'purple'],
    ['label' => '服务器状态', 'value' => $stats['online_servers'] . ' / ' . ($stats['online_servers'] + $stats['abnormal_servers']), 'sub' => '异常 ' . $stats['abnormal_servers'], 'icon' => 'activity', 'tone' => $stats['abnormal_servers'] > 0 ? 'orange' : 'green'],
];

$trendMax = 0;
$ordersTotal = 0;
$rechargeTotal = 0;
$ordersCount = 0;
$rechargeCount = 0;
foreach ($revenueTrend as $row) {
    $trendMax = max($trendMax, (float) $row['orders_total'], (float) $row['recharge_total']);
    $ordersTotal += (float) $row['orders_total'];
    $rechargeTotal += (float) $row['recharge_total'];
    $ordersCount += (int) $row['orders_count'];
    $rechargeCount += (int) $row['recharge_count'];
}
$trendMax = $trendMax > 0 ? $trendMax : 1;
$chartTop = 12;
$chartBottom = 88;
$chartRange = $chartBottom - $chartTop;
$pointCount = max(1, count($revenueTrend) - 1);
$ordersPoints = [];
$rechargePoints = [];
$ordersAreaPoints = [];
$rechargeAreaPoints = [];
foreach (array_values($revenueTrend) as $index => $row) {
    $x = count($revenueTrend) > 1 ? round(($index / $pointCount) * 100, 2) : 50;
    $orderY = round($chartBottom - (((float) $row['orders_total'] / $trendMax) * $chartRange), 2);
    $rechargeY = round($chartBottom - (((float) $row['recharge_total'] / $trendMax) * $chartRange), 2);
    $ordersPoints[] = $x . ',' . $orderY;
    $rechargePoints[] = $x . ',' . $rechargeY;
    $ordersAreaPoints[] = $x . ',' . $orderY;
    $rechargeAreaPoints[] = $x . ',' . $rechargeY;
}
$ordersArea = '0,' . $chartBottom . ' ' . implode(' ', $ordersAreaPoints) . ' 100,' . $chartBottom;
$rechargeArea = '0,' . $chartBottom . ' ' . implode(' ', $rechargeAreaPoints) . ' 100,' . $chartBottom;

$todoItems = [
    ['label' => '待审核充值', 'value' => $opsTodos['pending_recharge'], 'url' => 'admin/recharges', 'icon' => 'wallet-cards'],
    ['label' => '待处理订单', 'value' => $opsTodos['pending_orders'], 'url' => 'admin/orders', 'icon' => 'receipt-text'],
    ['label' => '离线服务器', 'value' => $opsTodos['offline_servers'], 'url' => 'admin/monitors', 'icon' => 'activity'],
    ['label' => '默认存储', 'value' => $opsTodos['default_storage'] > 0 ? '已配置' : '未配置', 'url' => 'admin/storages', 'icon' => 'database'],
];
$todoItems[] = ['label' => '套餐即将到期', 'value' => isset($opsTodos['package_expiring']) ? $opsTodos['package_expiring'] : 0, 'url' => 'admin/package-expiry', 'icon' => 'calendar-clock'];
$todoItems[] = ['label' => 'SLA &#39118;&#38505;', 'value' => (isset($opsTodos['sla_below_99']) ? (int) $opsTodos['sla_below_99'] : 0) + (isset($opsTodos['sla_no_data']) ? (int) $opsTodos['sla_no_data'] : 0) + (isset($opsTodos['sla_collect_delayed']) ? (int) $opsTodos['sla_collect_delayed'] : 0), 'url' => 'admin/monitor-sla', 'icon' => 'chart-no-axes-combined'];
$opsAlerts = isset($opsAlerts) && is_array($opsAlerts) ? $opsAlerts : [];
?>

<section class="bm-admin-dashboard">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Operations Console</span>
            <h1>运营控制台</h1>
            <p>围绕用户增长、内容资产、交易收入和服务器状态组织信息，日常巡检不再被杂乱模块打断。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-primary" href="<?= url('admin/orders') ?>" data-icon="receipt-text">订单管理</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/storages') ?>" data-icon="database">存储管理</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/monitors') ?>" data-icon="activity">监控管理</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <?php foreach ($heroMetrics as $item): ?>
            <article class="bm-admin-metric is-<?= e($item['tone']) ?>">
                <span class="bm-icon-tile"><i data-lucide="<?= e($item['icon']) ?>"></i></span>
                <div>
                    <small><?= e($item['label']) ?></small>
                    <strong><?= e($item['value']) ?></strong>
                    <em><?= e($item['sub']) ?></em>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="bm-admin-panel bm-ops-alert-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Health</span>
                <h2>运营告警中心</h2>
            </div>
            <a class="bm-text-link" href="<?= url('admin/feature-audit') ?>">完整巡检</a>
        </div>
        <div class="bm-ops-alert-grid">
            <?php foreach ($opsAlerts as $alert): ?>
                <a class="bm-ops-alert is-<?= e(isset($alert['level']) ? $alert['level'] : 'soft') ?>" href="<?= url(isset($alert['url']) ? $alert['url'] : 'admin') ?>">
                    <span class="bm-icon-tile is-small"><i data-lucide="<?= e(isset($alert['icon']) ? $alert['icon'] : 'bell') ?>"></i></span>
                    <div>
                        <strong><?= e(isset($alert['title']) ? $alert['title'] : '待处理事项') ?></strong>
                        <small><?= e(isset($alert['desc']) ? $alert['desc'] : '') ?></small>
                    </div>
                    <em><?= e(isset($alert['value']) ? $alert['value'] : '') ?></em>
                    <b><?= e(isset($alert['action']) ? $alert['action'] : '查看') ?></b>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="bm-admin-main-grid">
        <article class="bm-admin-panel bm-admin-revenue-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Revenue</span>
                    <h2>最近七天收入走势</h2>
                </div>
                <a class="bm-text-link" href="<?= url('admin/orders') ?>">查看订单</a>
            </div>

            <div class="bm-admin-revenue-summary">
                <div><span>订单收入</span><strong>¥<?= e(number_format($ordersTotal, 2)) ?></strong><small><?= e($ordersCount) ?> 笔订单</small></div>
                <div><span>充值收入</span><strong>¥<?= e(number_format($rechargeTotal, 2)) ?></strong><small><?= e($rechargeCount) ?> 笔充值</small></div>
                <div><span>单日峰值</span><strong>¥<?= e(number_format($trendMax, 2)) ?></strong><small>最近七天最高</small></div>
            </div>

            <div class="bm-admin-line-chart" role="img" aria-label="最近七天订单收入和充值收入折线图">
                <svg viewBox="0 0 100 100" preserveAspectRatio="none">
                    <defs>
                        <linearGradient id="bmOrdersArea" x1="0" x2="0" y1="0" y2="1">
                            <stop offset="0%" stop-color="#1769ff" stop-opacity=".20"></stop>
                            <stop offset="100%" stop-color="#1769ff" stop-opacity="0"></stop>
                        </linearGradient>
                        <linearGradient id="bmRechargeArea" x1="0" x2="0" y1="0" y2="1">
                            <stop offset="0%" stop-color="#12a875" stop-opacity=".18"></stop>
                            <stop offset="100%" stop-color="#12a875" stop-opacity="0"></stop>
                        </linearGradient>
                    </defs>
                    <g class="bm-chart-grid">
                        <line x1="0" y1="12" x2="100" y2="12"></line>
                        <line x1="0" y1="31" x2="100" y2="31"></line>
                        <line x1="0" y1="50" x2="100" y2="50"></line>
                        <line x1="0" y1="69" x2="100" y2="69"></line>
                        <line x1="0" y1="88" x2="100" y2="88"></line>
                    </g>
                    <polygon class="bm-chart-area orders" points="<?= e($ordersArea) ?>"></polygon>
                    <polygon class="bm-chart-area recharge" points="<?= e($rechargeArea) ?>"></polygon>
                    <polyline class="bm-chart-line orders" points="<?= e(implode(' ', $ordersPoints)) ?>"></polyline>
                    <polyline class="bm-chart-line recharge" points="<?= e(implode(' ', $rechargePoints)) ?>"></polyline>
                </svg>
            </div>

            <div class="bm-admin-chart-foot">
                <div>
                    <?php foreach ($revenueTrend as $row): ?>
                        <span><?= e($row['day']) ?></span>
                    <?php endforeach; ?>
                </div>
                <p><i class="orders"></i>订单收入 <i class="recharge"></i>充值收入</p>
            </div>
        </article>

        <aside class="bm-admin-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Todos</span>
                    <h2>今日待办</h2>
                </div>
            </div>
            <div class="bm-admin-todo-list">
                <?php foreach ($todoItems as $item): ?>
                    <a href="<?= url($item['url']) ?>">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= e($item['icon']) ?>"></i></span>
                        <span><?= e($item['label']) ?></span>
                        <strong><?= e($item['value']) ?></strong>
                    </a>
                <?php endforeach; ?>
            </div>
        </aside>
    </section>

    <section class="bm-admin-main-grid">
        <article class="bm-admin-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Orders</span>
                    <h2>最新业务流转</h2>
                </div>
                <a class="bm-text-link" href="<?= url('admin/orders') ?>">全部订单</a>
            </div>
            <div class="bm-admin-table">
                <div class="bm-admin-table-head">
                    <span>订单号</span><span>用户</span><span>类型</span><span>套餐</span><span>金额</span><span>状态</span>
                </div>
                <?php if ($recentOrders): ?>
                    <?php foreach ($recentOrders as $order): ?>
                        <div class="bm-admin-table-row">
                            <span title="<?= e($order['order_no']) ?>"><?= e($order['order_no']) ?></span>
                            <span><?= e($order['nickname'] ?: $order['username'] ?: '-') ?></span>
                            <span><?= e($order['type'] === 'recharge' ? '充值' : '套餐') ?></span>
                            <span><?= e($order['package_name'] ?: '-') ?></span>
                            <span>¥<?= e(number_format((float) $order['pay_amount'], 2)) ?></span>
                            <span><em class="bm-state-pill"><?= e($order['status']) ?></em></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="bm-empty-line">暂无订单记录。</div>
                <?php endif; ?>
            </div>
        </article>

        <article class="bm-admin-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Recharge</span>
                    <h2>待审核充值</h2>
                </div>
                <a class="bm-text-link" href="<?= url('admin/recharges') ?>">进入审核</a>
            </div>
            <div class="bm-admin-table bm-admin-table-compact">
                <div class="bm-admin-table-head">
                    <span>用户</span><span>金额</span><span>方式</span><span>时间</span>
                </div>
                <?php if ($pendingRecharges): ?>
                    <?php foreach ($pendingRecharges as $recharge): ?>
                        <div class="bm-admin-table-row">
                            <span><?= e($recharge['username'] ?: '-') ?></span>
                            <span>¥<?= e(number_format((float) $recharge['amount'], 2)) ?></span>
                            <span><?= e($recharge['payment_method']) ?></span>
                            <span><?= e($recharge['created_at']) ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="bm-empty-line">当前没有待审核充值。</div>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <section class="bm-admin-main-grid">
        <article class="bm-admin-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Server</span>
                    <h2>本机运行信息</h2>
                </div>
            </div>
            <div class="bm-admin-env-grid">
                <div><span>操作系统</span><strong><?= e($serverInfo['os']) ?></strong></div>
                <div><span>运行软件</span><strong><?= e($serverInfo['server_software']) ?></strong></div>
                <div><span>PHP 版本</span><strong><?= e($serverInfo['php_version']) ?></strong></div>
                <div><span>数据库版本</span><strong><?= e($serverInfo['database_version']) ?></strong></div>
                <div><span>内存限制</span><strong><?= e($serverInfo['memory_limit']) ?></strong></div>
                <div><span>上传限制</span><strong><?= e($serverInfo['upload_max_filesize']) ?></strong></div>
                <div><span>POST 限制</span><strong><?= e($serverInfo['post_max_size']) ?></strong></div>
                <div><span>执行时间</span><strong><?= e($serverInfo['max_execution_time']) ?></strong></div>
                <div><span>磁盘总量</span><strong><?= e($serverInfo['disk_total']) ?></strong></div>
                <div><span>磁盘已用</span><strong><?= e($serverInfo['disk_used']) ?></strong></div>
                <div><span>磁盘剩余</span><strong><?= e($serverInfo['disk_free']) ?></strong></div>
                <div><span>当前时间</span><strong><?= e($serverInfo['time']) ?></strong></div>
            </div>
        </article>

        <article class="bm-admin-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Runtime</span>
                    <h2>关键扩展检测</h2>
                </div>
            </div>
            <div class="bm-extension-grid">
                <?php foreach ($serverInfo['extensions'] as $name => $loaded): ?>
                    <span class="<?= $loaded ? 'is-ok' : 'is-bad' ?>">
                        <?= e(strtoupper($name)) ?> <?= $loaded ? '已启用' : '未启用' ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </article>
    </section>
</section>
