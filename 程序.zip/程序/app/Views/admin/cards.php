<?php
$typeNames = ['balance' => '余额卡', 'package' => '套餐卡'];
$statusNames = ['unused' => '未兑换', 'used' => '已兑换', 'disabled' => '已停用'];
$statusClass = ['unused' => 'soft', 'used' => 'ok', 'disabled' => 'muted'];
$filters = isset($filters) ? $filters : ['keyword' => '', 'type' => '', 'status' => ''];
$generatedCards = isset($generatedCards) ? $generatedCards : null;
?>

<section class="admin-cards-page">
<section class="admin-page-head glass cards-page-head">
    <div>
        <p class="eyebrow">商业卡密</p>
        <h1>卡密管理</h1>
        <p>生成余额充值卡和套餐兑换卡，用于代理分销、线下售卖、社群活动和售后补偿。卡密兑换后会自动写入订单、余额流水和用户套餐。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('cards') ?>" target="_blank" data-icon="external-link">用户兑换页</a>
</section>

<section class="ops-metric-grid cards-metric-grid">
    <article class="ops-metric-card glass"><span>卡密总数</span><b><?= e($cardStats['total']) ?></b><small>所有批次累计</small></article>
    <article class="ops-metric-card glass ok"><span>可兑换</span><b><?= e($cardStats['unused']) ?></b><small>当前可发放库存</small></article>
    <article class="ops-metric-card glass"><span>已兑换</span><b><?= e($cardStats['used']) ?></b><small>用户已核销</small></article>
    <article class="ops-metric-card glass"><span>余额核销</span><b>¥<?= e(number_format((float) $cardStats['used_balance_amount'], 2)) ?></b><small>余额卡已入账金额</small></article>
</section>

<?php if ($generatedCards): ?>
    <section class="form-section glass generated-card-panel cards-generated-panel">
        <div class="section-head">
            <div>
                <p class="eyebrow">本次生成</p>
                <h2><?= e($generatedCards['title']) ?> · <?= e($generatedCards['batch_no']) ?></h2>
            </div>
            <span class="status-pill ok"><?= e($generatedCards['count']) ?> 张</span>
        </div>
        <div class="generated-code-box">
            <textarea readonly rows="8"><?= e(implode("\n", $generatedCards['codes'])) ?></textarea>
            <button class="btn btn-primary copy-text-btn" type="button" data-copy-text="<?= e(implode("\n", $generatedCards['codes'])) ?>" data-icon="copy">复制本批卡密</button>
        </div>
        <p class="muted-text">出于安全考虑，卡密明文只在生成后展示一次。离开或刷新页面后，后台只能看到卡密尾号和兑换记录。</p>
    </section>
<?php endif; ?>

<section class="marketing-admin-grid cards-admin-grid">
    <article class="form-section glass cards-form-card">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">生成批次</p>
                <h2>生成卡密</h2>
                <p>按业务场景生成余额卡或套餐卡，生成后仅展示一次明文。</p>
            </div>
        </div>
        <form method="post" action="<?= url('admin/cards/generate') ?>" class="form-grid two card-generate-form" id="cardGenerateForm">
            <?= csrf_field() ?>
            <label>卡密类型
                <select name="type" id="cardTypeSelect">
                    <option value="balance">余额充值卡</option>
                    <option value="package">套餐兑换卡</option>
                </select>
            </label>
            <label>批次名称
                <input name="title" placeholder="例如：代理A 100元充值卡 / 专业版月卡">
            </label>
            <label class="balance-card-field">单张金额
                <input name="amount" type="number" step="0.01" min="0" value="10.00" form="cardGenerateForm">
                <small>余额卡兑换后直接进入用户余额。</small>
            </label>
            <label class="package-card-field soft-hidden">绑定套餐
                <select name="package_id" form="cardGenerateForm">
                    <?php foreach ($packages as $package): ?>
                        <option value="<?= e($package['id']) ?>"><?= e($package['name']) ?> · ¥<?= e($package['price']) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>套餐卡兑换后直接切换用户套餐。</small>
            </label>
            <label class="package-card-field soft-hidden">兑换时长覆盖
                <input name="duration_days" type="number" min="0" value="0" form="cardGenerateForm">
                <small>填 0 使用套餐原时长；可填 7、30、365 做体验卡或年卡。</small>
            </label>
            <label>生成数量
                <input name="count" type="number" min="1" max="200" value="10">
                <small>单次最多 200 张，方便复制和分批运营。</small>
            </label>
            <label>卡号前缀
                <input name="prefix" value="BM" maxlength="8" placeholder="例如 BM、VIP、AGENT">
            </label>
            <label>渠道备注
                <input name="channel" placeholder="例如：代理A、QQ群活动、售后补偿">
            </label>
            <label>过期时间
                <input name="expire_at" type="datetime-local">
            </label>
            <label class="span-all">内部备注
                <textarea name="remark" placeholder="写清楚发放对象、成本、结算方式或注意事项"></textarea>
            </label>
            <div class="form-actions span-all">
                <button class="btn btn-primary" type="submit" data-icon="ticket-plus">生成卡密</button>
            </div>
        </form>
    </article>

    <aside class="table-card glass marketing-guide cards-guide-card">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">运营建议</p>
                <h2>商业用法</h2>
            </div>
        </div>
        <div>
            <span><b>余额卡</b><small>适合代理售卖、线下收款、售后补偿。兑换后自动生成充值订单和余额流水。</small></span>
            <span><b>套餐卡</b><small>适合月卡、体验卡、年卡、课程附赠权益。兑换后自动更新用户套餐和到期时间。</small></span>
            <span><b>风控建议</b><small>正式发放前先生成 1 张测试卡。卡密不要公开贴在网页，已售出批次可按渠道备注追踪。</small></span>
        </div>
    </aside>
</section>

<section class="table-card glass cards-list-card">
    <div class="section-head">
        <div>
            <p class="eyebrow">卡密库存</p>
            <h2>卡密列表</h2>
        </div>
    </div>
    <form method="get" action="<?= url('admin/cards') ?>" class="toolbar">
        <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="批次、名称、尾号、渠道">
        <select name="type">
            <option value="">全部类型</option>
            <option value="balance" <?= $filters['type'] === 'balance' ? 'selected' : '' ?>>余额卡</option>
            <option value="package" <?= $filters['type'] === 'package' ? 'selected' : '' ?>>套餐卡</option>
        </select>
        <select name="status">
            <option value="">全部状态</option>
            <option value="unused" <?= $filters['status'] === 'unused' ? 'selected' : '' ?>>未兑换</option>
            <option value="used" <?= $filters['status'] === 'used' ? 'selected' : '' ?>>已兑换</option>
            <option value="disabled" <?= $filters['status'] === 'disabled' ? 'selected' : '' ?>>已停用</option>
        </select>
        <button class="btn btn-ghost" data-icon="filter">筛选</button>
        <a class="btn btn-ghost" href="<?= url('admin/cards') ?>" data-icon="rotate-ccw">重置</a>
    </form>
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>批次 / 卡密</th><th>类型</th><th>面值 / 套餐</th><th>渠道</th><th>状态</th><th>兑换信息</th><th>操作</th></tr></thead>
            <tbody>
            <?php if (!$cards): ?>
                <tr><td colspan="8" class="empty-table responsive-table-span">暂无卡密。可以先生成一批测试卡。</td></tr>
            <?php endif; ?>
            <?php foreach ($cards as $card): ?>
                <tr>
                    <td data-label="ID"><?= e($card['id']) ?></td>
                    <td data-label="批次 / 卡密">
                        <b><?= e($card['title']) ?></b>
                        <small><?= e($card['batch_no']) ?> · <?= e($card['code_preview']) ?></small>
                    </td>
                    <td data-label="类型"><span class="status-pill soft"><?= e(isset($typeNames[$card['type']]) ? $typeNames[$card['type']] : $card['type']) ?></span></td>
                    <td data-label="面值 / 套餐">
                        <?php if ($card['type'] === 'balance'): ?>
                            <b>¥<?= e(number_format((float) $card['amount'], 2)) ?></b>
                        <?php else: ?>
                            <b><?= e($card['package_name'] ?: '套餐已删除') ?></b>
                            <small><?= (int) $card['duration_days'] > 0 ? e($card['duration_days']) . ' 天' : '使用套餐原时长' ?></small>
                        <?php endif; ?>
                    </td>
                    <td data-label="渠道"><?= e($card['channel'] ?: '-') ?><br><small><?= e($card['remark'] ?: '') ?></small></td>
                    <td data-label="状态">
                        <span class="status-pill <?= e(isset($statusClass[$card['status']]) ? $statusClass[$card['status']] : 'muted') ?>"><?= e(isset($statusNames[$card['status']]) ? $statusNames[$card['status']] : $card['status']) ?></span>
                        <small><?= e($card['expire_at'] ? '到期 ' . $card['expire_at'] : '长期有效') ?></small>
                    </td>
                    <td data-label="兑换信息">
                        <?php if ($card['status'] === 'used'): ?>
                            <b><?= e($card['username'] ?: '-') ?></b>
                            <small><?= e($card['used_at']) ?> · <?= e($card['order_no'] ?: '-') ?></small>
                        <?php else: ?>
                            <span class="muted-text">未兑换</span>
                        <?php endif; ?>
                    </td>
                    <td class="table-actions" data-label="操作">
                        <?php if ($card['status'] !== 'used'): ?>
                            <form method="post" action="<?= url('admin/cards/status') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($card['id']) ?>">
                                <button class="btn btn-ghost" name="action" value="<?= $card['status'] === 'disabled' ? 'restore' : 'disable' ?>" data-icon="<?= $card['status'] === 'disabled' ? 'rotate-ccw' : 'ban' ?>"><?= $card['status'] === 'disabled' ? '恢复' : '停用' ?></button>
                            </form>
                            <form class="confirm-form" method="post" action="<?= url('admin/cards/delete') ?>" data-confirm="确定删除这张未兑换卡密吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($card['id']) ?>">
                                <button class="btn btn-ghost danger" data-icon="trash-2">删除</button>
                            </form>
                        <?php else: ?>
                            <span class="muted-text">已核销留档</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
</section>

<script>
(function () {
    var select = document.getElementById('cardTypeSelect');
    function refreshCardType() {
        var isPackage = select && select.value === 'package';
        document.querySelectorAll('.balance-card-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', isPackage);
        });
        document.querySelectorAll('.package-card-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', !isPackage);
        });
    }
    if (select) {
        select.addEventListener('change', refreshCardType);
        refreshCardType();
    }
})();
</script>
