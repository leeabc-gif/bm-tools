<?php require APP_ROOT . '/app/Views/admin/partials/settings_nav.php'; ?>
<?php
$hasWecom = !empty($settings['alert_wecom_webhook']);
$hasDingTalk = !empty($settings['alert_dingtalk_webhook']);
$hasDingSecret = !empty($settings['alert_dingtalk_secret']);
$hasTelegramToken = !empty($settings['alert_telegram_bot_token']);
?>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">邮件服务</p>
        <h2>邮件服务设置</h2>
        <p>只放 SMTP 参数和测试入口，避免和别的系统设置堆在一起。</p>
    </div>

    <form method="post" action="<?= url('admin/settings/email') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <label>邮件 Host
            <input name="email_host" value="<?= e(isset($settings['email_host']) ? $settings['email_host'] : '') ?>">
        </label>
        <label>邮件端口
            <input name="email_port" type="number" min="1" value="<?= e(isset($settings['email_port']) ? $settings['email_port'] : '465') ?>">
        </label>
        <label>邮件账号
            <input name="email_username" value="<?= e(isset($settings['email_username']) ? $settings['email_username'] : '') ?>">
        </label>
        <label>邮件密码
            <input name="email_password" type="password" value="" autocomplete="new-password" placeholder="<?= !empty($settings['email_password']) ? '已加密保存，留空不修改' : 'SMTP 授权码或密码' ?>">
        </label>
        <label>发件邮箱
            <input name="email_from" value="<?= e(isset($settings['email_from']) ? $settings['email_from'] : '') ?>">
        </label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
        </div>
    </form>
</section>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">Alert Webhook</p>
        <h2>告警通知通道</h2>
        <p>监控异常会先写入站内通知和邮件，再尝试外送到企业微信、钉钉或 Telegram。外送失败只记录日志，不会阻塞采集任务。</p>
    </div>

    <form method="post" action="<?= url('admin/settings/notify') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <label>告警外送
            <select name="alert_webhook_enabled">
                <option value="0" <?= (isset($settings['alert_webhook_enabled']) ? $settings['alert_webhook_enabled'] : '0') === '0' ? 'selected' : '' ?>>关闭</option>
                <option value="1" <?= (isset($settings['alert_webhook_enabled']) ? $settings['alert_webhook_enabled'] : '0') === '1' ? 'selected' : '' ?>>开启</option>
            </select>
        </label>
        <label>企业微信机器人 Webhook
            <input name="alert_wecom_webhook" value="" placeholder="<?= $hasWecom ? '已加密保存，留空不修改' : 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=...' ?>">
        </label>
        <label>钉钉机器人 Webhook
            <input name="alert_dingtalk_webhook" value="" placeholder="<?= $hasDingTalk ? '已加密保存，留空不修改' : 'https://oapi.dingtalk.com/robot/send?access_token=...' ?>">
        </label>
        <label>钉钉加签 Secret
            <input name="alert_dingtalk_secret" type="password" value="" autocomplete="new-password" placeholder="<?= $hasDingSecret ? '已加密保存，留空不修改' : 'SEC 开头的加签密钥，可留空' ?>">
        </label>
        <label>Telegram Bot Token
            <input name="alert_telegram_bot_token" type="password" value="" autocomplete="new-password" placeholder="<?= $hasTelegramToken ? '已加密保存，留空不修改' : '123456789:AA...' ?>">
        </label>
        <label>Telegram Chat ID
            <input name="alert_telegram_chat_id" value="<?= e(isset($settings['alert_telegram_chat_id']) ? $settings['alert_telegram_chat_id'] : '') ?>" placeholder="-1001234567890 或个人 Chat ID">
        </label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存告警通道</button>
        </div>
    </form>
</section>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">Channel Test</p>
        <h2>告警通道测试</h2>
        <p>测试会直接向选中的通道发送一条消息。失败提示会标明是配置、网络、通道返回还是 PHP 扩展问题。</p>
    </div>
    <form method="post" action="<?= url('admin/settings/notify/test') ?>" class="url-fetch">
        <?= csrf_field() ?>
        <select name="channel" required>
            <option value="wecom">企业微信机器人</option>
            <option value="dingtalk">钉钉机器人</option>
            <option value="telegram">Telegram</option>
        </select>
        <button class="btn btn-ghost" type="submit" data-icon="send">发送测试告警</button>
    </form>
</section>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">发送测试</p>
        <h2>邮件测试</h2>
    </div>
    <form method="post" action="<?= url('admin/settings/email/test') ?>" class="url-fetch">
        <?= csrf_field() ?>
        <input type="email" name="email" placeholder="接收测试邮件的邮箱" required>
        <button class="btn btn-ghost" type="submit" data-icon="send">发送测试邮件</button>
    </form>
</section>
