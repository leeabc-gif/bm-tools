<?php
$value = function ($key, $default = '') use ($settings) {
    return isset($settings[$key]) ? $settings[$key] : $default;
};
?>
<section class="bm-admin-dashboard server-ops-admin">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Server Ops Settings</span>
            <h1>运维设置</h1>
            <p>控制前台服务器管家能力：是否允许在线终端、每个用户最多保存多少台服务器、命令超时和 WebSocket 网关地址。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/user-servers') ?>" data-icon="server-cog">用户服务器</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/command-logs') ?>" data-icon="square-terminal">命令审计</a>
        </div>
    </header>

    <section class="bm-admin-panel">
        <form method="post" action="<?= url('admin/server-ops/settings') ?>" class="bm-form-grid server-ops-settings-form">
            <?= csrf_field() ?>
            <label class="bm-check-row bm-span-all">
                <input type="checkbox" name="ssh_terminal_enabled" <?= (string) $value('ssh_terminal_enabled', '1') === '1' ? 'checked' : '' ?>>
                <span>开启前台在线终端</span>
            </label>
            <label>
                <span>每个用户服务器上限</span>
                <input type="number" min="0" max="1000" name="ssh_terminal_user_server_limit" value="<?= e($value('ssh_terminal_user_server_limit', '5')) ?>">
                <small>填 0 表示不限制。</small>
            </label>
            <label>
                <span>会话令牌有效期（秒）</span>
                <input type="number" min="60" max="86400" name="ssh_terminal_session_timeout" value="<?= e($value('ssh_terminal_session_timeout', '600')) ?>">
            </label>
            <label>
                <span>命令执行超时（秒）</span>
                <input type="number" min="3" max="3600" name="ssh_terminal_command_timeout" value="<?= e($value('ssh_terminal_command_timeout', '30')) ?>">
            </label>
            <label class="bm-span-all">
                <span>WebSocket 网关地址</span>
                <input name="ssh_terminal_gateway_url" value="<?= e($value('ssh_terminal_gateway_url', '')) ?>" placeholder="wss://terminal.example.com/ws">
                <small>留空时使用当前 PHP 命令模式；如已部署独立 Node/Go 网关，可填写网关地址。</small>
            </label>
            <div class="bm-inline-notice bm-span-all">
                <i data-lucide="shield-check"></i>
                <div>
                    <strong>安全建议</strong>
                    <span>线上环境建议使用普通运维账号、禁用 root 密码登录、开启 SSH 密钥登录，并把命令审计保留在数据库中。</span>
                </div>
            </div>
            <div class="bm-form-actions bm-span-all">
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存设置</button>
            </div>
        </form>
    </section>
</section>
