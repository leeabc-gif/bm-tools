<?php require APP_ROOT . '/app/Views/admin/partials/settings_nav.php'; ?>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">安全设置</p>
        <h2>安全与注册设置</h2>
        <p>只放注册开关、登录风控和邮箱验证码限制。</p>
    </div>

    <form method="post" action="<?= url('admin/settings/security') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <label>注册开关
            <select name="register_enabled">
                <option value="1" <?= (isset($settings['register_enabled']) ? $settings['register_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['register_enabled']) ? $settings['register_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
        </label>
        <label>注册邮箱验证码
            <select name="register_email_code_enabled">
                <option value="0" <?= (isset($settings['register_email_code_enabled']) ? $settings['register_email_code_enabled'] : '0') === '0' ? 'selected' : '' ?>>关闭</option>
                <option value="1" <?= (isset($settings['register_email_code_enabled']) ? $settings['register_email_code_enabled'] : '0') === '1' ? 'selected' : '' ?>>开启</option>
            </select>
        </label>
        <label>登录失败上限
            <input name="security_login_max_attempts" type="number" min="1" value="<?= e(isset($settings['security_login_max_attempts']) ? $settings['security_login_max_attempts'] : '5') ?>">
        </label>
        <label>登录统计窗口（分钟）
            <input name="security_login_window_minutes" type="number" min="1" value="<?= e(isset($settings['security_login_window_minutes']) ? $settings['security_login_window_minutes'] : '10') ?>">
        </label>
        <label>登录锁定时长（分钟）
            <input name="security_login_lock_minutes" type="number" min="1" value="<?= e(isset($settings['security_login_lock_minutes']) ? $settings['security_login_lock_minutes'] : '15') ?>">
        </label>
        <label>邮箱验证码每小时/邮箱
            <input name="security_email_code_max_per_hour" type="number" min="1" value="<?= e(isset($settings['security_email_code_max_per_hour']) ? $settings['security_email_code_max_per_hour'] : '5') ?>">
        </label>
        <label>邮箱验证码每小时/IP
            <input name="security_email_code_ip_max_per_hour" type="number" min="1" value="<?= e(isset($settings['security_email_code_ip_max_per_hour']) ? $settings['security_email_code_ip_max_per_hour'] : '20') ?>">
        </label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
        </div>
    </form>
</section>
