<?php
$updateResult = flash('update_result');
$updatePackage = flash('update_package');
$updateInstallResult = flash('update_install_result');
$updateManifest = is_array($updateResult) && isset($updateResult['manifest']) && is_array($updateResult['manifest']) ? $updateResult['manifest'] : null;
?>

<section class="admin-page-head maintenance-head glass">
    <div>
        <p class="eyebrow">Online Update</p>
        <h1>在线更新</h1>
        <p>用于检查更新源、下载更新包和安装升级。安装前系统会执行必要备份，禁止覆盖上传目录、数据库配置和运行数据。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/maintenance') ?>" data-icon="arrow-left">返回维护</a>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Source</p>
            <h2>检查更新源</h2>
        </div>
        <span class="status-pill soft">当前版本 <?= e($updateCurrentVersion) ?></span>
    </div>
    <div class="maintenance-grid">
        <article class="form-section glass">
            <form method="post" action="<?= url('admin/maintenance/update-check') ?>" class="maintenance-form">
                <?= csrf_field() ?>
                <label>更新清单地址
                    <input name="manifest_url" value="<?= e($updateManifestUrl) ?>" placeholder="https://example.com/bmtools/update.json">
                </label>
                <div class="form-actions">
                    <button class="btn btn-primary" type="submit" data-icon="refresh-cw">检查更新</button>
                </div>
            </form>
        </article>
        <article class="form-section glass">
            <div class="meta-table">
                <span>压缩格式</span><b>ZIP</b>
                <span>目录结构</span><b>ZIP 根目录对应项目根目录</b>
                <span>允许覆盖</span><b>app / public / database / config/app.php</b>
                <span>禁止覆盖</span><b>storage / public/uploads / config/database.php / .env</b>
                <span>SQL 升级</span><b>在 update.json 的 sql 数组中声明</b>
            </div>
        </article>
    </div>
</section>

<?php if (is_array($updateResult)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Check Result</p>
                <h2>检查结果</h2>
            </div>
            <span class="status-pill <?= !empty($updateResult['update_available']) ? 'bad' : 'ok' ?>">
                <?= !empty($updateResult['update_available']) ? '有新版本' : '已是最新' ?>
            </span>
        </div>
        <div class="meta-table">
            <span>当前版本</span><b><?= e($updateResult['current_version']) ?></b>
            <span>最新版本</span><b><?= e($updateResult['latest_version']) ?></b>
            <span>发布时间</span><b><?= e(isset($updateManifest['released_at']) ? $updateManifest['released_at'] : '-') ?></b>
            <span>更新包地址</span><b><?= e(isset($updateManifest['package_url']) ? $updateManifest['package_url'] : '-') ?></b>
            <span>SHA-256</span><b><?= e(!empty($updateManifest['package_sha256']) ? $updateManifest['package_sha256'] : '未提供，建议补充') ?></b>
        </div>
        <?php if ($updateManifest && !empty($updateManifest['changelog'])): ?>
            <div class="notice-list">
                <?php foreach ($updateManifest['changelog'] as $item): ?>
                    <p><?= e($item) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($updateManifest && !empty($updateManifest['package_url'])): ?>
            <form method="post" action="<?= url('admin/maintenance/update-download') ?>" class="confirm-form" data-confirm="确定下载这个更新包吗？下载完成后仍需手动点击安装。">
                <?= csrf_field() ?>
                <input type="hidden" name="package_url" value="<?= e($updateManifest['package_url']) ?>">
                <input type="hidden" name="package_sha256" value="<?= e(isset($updateManifest['package_sha256']) ? $updateManifest['package_sha256'] : '') ?>">
                <input type="hidden" name="version" value="<?= e($updateResult['latest_version']) ?>">
                <button class="btn btn-primary" type="submit" data-icon="download">下载更新包</button>
            </form>
        <?php endif; ?>
    </section>
<?php endif; ?>

<?php if (is_array($updatePackage)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Downloaded</p>
                <h2>已下载更新包</h2>
            </div>
            <span class="status-pill ok"><?= e(format_bytes($updatePackage['size'])) ?></span>
        </div>
        <div class="meta-table">
            <span>文件名</span><b><?= e($updatePackage['file']) ?></b>
            <span>目标版本</span><b><?= e($updatePackage['version'] ?: '由更新包决定') ?></b>
            <span>SHA-256</span><b><?= e($updatePackage['sha256']) ?></b>
            <span>下载时间</span><b><?= e($updatePackage['downloaded_at']) ?></b>
        </div>
        <form method="post" action="<?= url('admin/maintenance/update-install') ?>" class="confirm-form" data-confirm="安装前会备份数据库和被覆盖文件。确认现在安装更新吗？">
            <?= csrf_field() ?>
            <input type="hidden" name="package_file" value="<?= e($updatePackage['file']) ?>">
            <input type="hidden" name="version" value="<?= e($updatePackage['version']) ?>">
            <button class="btn btn-primary" type="submit" data-icon="package-check">安装更新</button>
        </form>
    </section>
<?php endif; ?>

<?php if (is_array($updateInstallResult)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Installed</p>
                <h2>安装结果</h2>
            </div>
            <span class="status-pill ok">已完成</span>
        </div>
        <div class="meta-table">
            <span>更新版本</span><b><?= e($updateInstallResult['version'] ?: '未写入版本') ?></b>
            <span>覆盖文件</span><b><?= e($updateInstallResult['extracted_count']) ?> 个</b>
            <span>删除文件</span><b><?= e($updateInstallResult['deleted_count']) ?> 个</b>
            <span>SQL 文件</span><b><?= e($updateInstallResult['sql_count']) ?> 个</b>
            <span>文件备份</span><b><?= e($updateInstallResult['file_backup']['file']) ?>，<?= e($updateInstallResult['file_backup']['count']) ?> 个文件</b>
            <span>数据库备份</span><b><?= e($updateInstallResult['database_backup']['file']) ?></b>
            <span>安装时间</span><b><?= e($updateInstallResult['installed_at']) ?></b>
        </div>
    </section>
<?php endif; ?>

<?php if (!empty($updatePackages)): ?>
    <section class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">Local Packages</p>
                <h2>本地更新包</h2>
            </div>
        </div>
        <div class="bm-responsive-table server-admin-table">
            <table>
                <thead>
                    <tr>
                        <th>更新包</th>
                        <th>大小</th>
                        <th>SHA-256</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_slice($updatePackages, 0, 10) as $package): ?>
                        <tr>
                            <td data-label="更新包"><?= e($package['file']) ?></td>
                            <td data-label="大小"><?= e(format_bytes($package['size'])) ?></td>
                            <td data-label="SHA-256"><code><?= e($package['sha256']) ?></code></td>
                            <td data-label="时间"><?= e($package['mtime']) ?></td>
                            <td data-label="操作">
                                <form method="post" action="<?= url('admin/maintenance/update-install') ?>" class="confirm-form" data-confirm="确定安装这个本地更新包吗？安装前会自动备份。">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="package_file" value="<?= e($package['file']) ?>">
                                    <button class="btn btn-ghost" type="submit" data-icon="package-check">安装</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>
