<?php require APP_ROOT . '/app/Views/admin/partials/settings_nav.php'; ?>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">站点信息</p>
        <h2>站点信息设置</h2>
        <p>只放站点名称、域名、Logo、SEO，和安全、上传、邮件分开。</p>
    </div>

    <form method="post" action="<?= url('admin/settings/site') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <label>网站名称
            <input name="site_name" value="<?= e(isset($settings['site_name']) ? $settings['site_name'] : '') ?>">
        </label>
        <label>网站主域名 / 外链域名
            <span class="input-action">
                <input name="site_public_url" value="<?= e(isset($settings['site_public_url']) ? $settings['site_public_url'] : '') ?>" placeholder="https://www.example.com">
                <button class="btn btn-ghost fill-public-url" type="button" data-icon="wand-sparkles">使用当前域名</button>
            </span>
        </label>
        <label>Logo URL
            <input name="site_logo" value="<?= e(isset($settings['site_logo']) ? $settings['site_logo'] : '') ?>">
        </label>
        <label>SEO 关键词
            <input name="seo_keywords" value="<?= e(isset($settings['seo_keywords']) ? $settings['seo_keywords'] : '') ?>">
        </label>
        <label>SEO 描述
            <input name="seo_description" value="<?= e(isset($settings['seo_description']) ? $settings['seo_description'] : '') ?>">
        </label>
        <label>默认主题
            <select name="default_theme">
                <?php $defaultTheme = isset($settings['default_theme']) ? $settings['default_theme'] : 'auto'; ?>
                <option value="auto" <?= $defaultTheme === 'auto' ? 'selected' : '' ?>>自动跟随昼夜</option>
                <option value="light" <?= $defaultTheme === 'light' ? 'selected' : '' ?>>浅色</option>
                <option value="dark" <?= $defaultTheme === 'dark' ? 'selected' : '' ?>>深色</option>
            </select>
        </label>
        <label>文件命名策略
            <select name="file_naming_strategy">
                <?php $strategy = isset($settings['file_naming_strategy']) ? $settings['file_naming_strategy'] : 'random'; ?>
                <option value="random" <?= $strategy === 'random' ? 'selected' : '' ?>>随机字符串</option>
                <option value="timestamp" <?= $strategy === 'timestamp' ? 'selected' : '' ?>>时间戳</option>
                <option value="hash" <?= $strategy === 'hash' ? 'selected' : '' ?>>文件 Hash</option>
                <option value="original" <?= $strategy === 'original' ? 'selected' : '' ?>>原始文件名</option>
            </select>
        </label>
        <label>默认免费套餐
            <select name="default_free_package_id">
                <?php foreach ($packages as $p): ?>
                    <option value="<?= e($p['id']) ?>" <?= (isset($settings['default_free_package_id']) && (int) $settings['default_free_package_id'] === (int) $p['id']) ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
            <a class="btn btn-ghost" href="<?= url('admin/themes') ?>" data-icon="palette">主题设置</a>
        </div>
    </form>
</section>
