<?php
$filters = isset($filters) ? $filters : ['keyword' => '', 'type' => '', 'date_start' => '', 'date_end' => ''];
$stats = isset($stats) ? $stats : ['total' => 0, 'recharge' => 0, 'consume' => 0, 'refund' => 0, 'adjust' => 0, 'filtered_total' => 0, 'filtered_amount' => 0];
$typeLabels = [
    'recharge' => '充值',
    'consume' => '消费',
    'refund' => '退款',
    'adjust' => '调整',
];
$typeClasses = [
    'recharge' => 'ok',
    'consume' => 'soft',
    'refund' => 'warn',
    'adjust' => 'bad',
];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">Finance</p>
        <h1>余额流水</h1>
        <p>记录用户余额的充值、消费、退款和人工调整。用于财务核对、售后排查和订单对账。</p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/recharges') ?>" data-icon="wallet-cards">充值审核</a>
        <a class="btn btn-primary" href="<?= url('admin/orders') ?>" data-icon="receipt-text">订单管理</a>
    </div>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>流水总数</span><b><?= e(number_format($stats['total'])) ?></b><small>当前筛选 <?= e(number_format($stats['filtered_total'])) ?> 条</small></article>
    <article class="ops-metric-card glass ok"><span>充值金额</span><b>￥<?= e(number_format((float) $stats['recharge'], 2)) ?></b><small>余额入账累计</small></article>
    <article class="ops-metric-card glass"><span>消费金额</span><b>￥<?= e(number_format((float) $stats['consume'], 2)) ?></b><small>套餐与资源消费</small></article>
    <article class="ops-metric-card glass warn"><span>筛选合计</span><b>￥<?= e(number_format((float) $stats['filtered_amount'], 2)) ?></b><small>退款 <?= e(number_format((float) $stats['refund'], 2)) ?> / 调整 <?= e(number_format((float) $stats['adjust'], 2)) ?></small></article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Filter</p>
            <h2>流水筛选</h2>
        </div>
    </div>
    <form method="get" action="<?= url('admin/balance-logs') ?>" class="admin-filter-grid">
        <label>
            <span>关键词</span>
            <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="用户名 / 邮箱 / 备注 / 关联单号">
        </label>
        <label>
            <span>流水类型</span>
            <select name="type">
                <option value="">全部类型</option>
                <?php foreach ($typeLabels as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $filters['type'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>
            <span>开始日期</span>
            <input type="date" name="date_start" value="<?= e($filters['date_start']) ?>">
        </label>
        <label>
            <span>结束日期</span>
            <input type="date" name="date_end" value="<?= e($filters['date_end']) ?>">
        </label>
        <div class="filter-actions">
            <button class="btn btn-primary" type="submit" data-icon="search">查询</button>
            <a class="btn btn-ghost" href="<?= url('admin/balance-logs') ?>" data-icon="rotate-ccw">重置</a>
        </div>
    </form>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Ledger</p>
            <h2>流水明细</h2>
            <p>最多展示最新 300 条记录。人工调整类记录建议同时查看管理员日志。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>用户</th>
                <th>类型</th>
                <th>金额</th>
                <th>变动前</th>
                <th>变动后</th>
                <th>关联</th>
                <th>备注</th>
                <th>时间</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <?php $type = isset($typeLabels[$log['type']]) ? $log['type'] : 'adjust'; ?>
                <tr>
                    <td data-label="ID">#<?= e($log['id']) ?></td>
                    <td data-label="用户"><b><?= e($log['username'] ?: '未知用户') ?></b><small><?= e($log['email'] ?: '-') ?></small></td>
                    <td data-label="类型"><span class="status-pill <?= e($typeClasses[$type]) ?>"><?= e(isset($typeLabels[$log['type']]) ? $typeLabels[$log['type']] : $log['type']) ?></span></td>
                    <td data-label="金额"><b>￥<?= e(number_format((float) $log['amount'], 2)) ?></b></td>
                    <td data-label="变动前">￥<?= e(number_format((float) $log['balance_before'], 2)) ?></td>
                    <td data-label="变动后">￥<?= e(number_format((float) $log['balance_after'], 2)) ?></td>
                    <td data-label="关联"><?= e($log['related_type'] ?: '-') ?><?= $log['related_id'] ? ' #' . e($log['related_id']) : '' ?></td>
                    <td data-label="备注"><?= e($log['remark'] ?: '-') ?></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?>
                <tr><td colspan="9" class="empty-table responsive-table-span">暂无符合条件的余额流水。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
