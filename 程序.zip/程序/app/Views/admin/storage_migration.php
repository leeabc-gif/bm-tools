<?php
$storages = isset($storages) && is_array($storages) ? $storages : [];
$filters = isset($filters) && is_array($filters) ? $filters : ['source_storage_id' => 0, 'target_storage_id' => 0, 'file_scope' => ''];
$plan = isset($plan) && is_array($plan) ? $plan : ['total' => 0, 'already_target' => 0, 'ready_backup' => 0, 'local_readable' => 0, 'needs_upload_or_backup' => 0];
$tasks = isset($tasks) && is_array($tasks) ? $tasks : [];
$summary = isset($summary) && is_array($summary) ? $summary : null;
$enabledStorages = array_values(array_filter($storages, function ($storage) {
    return !empty($storage['is_enabled']);
}));
$statusClass = ['success' => 'ok', 'failed' => 'bad', 'pending' => 'warn', 'skipped' => 'muted', 'deleted' => 'muted'];
$scopeLabels = ['' => '全部文件', 'image' => '只迁移图床图片', 'file' => '只迁移网盘文件'];
?>

<section class="admin-page-head glass storage-backup-hero">
    <div>
        <p class="eyebrow">Storage Migration</p>
        <h1>存储迁移</h1>
        <p>把文件从当前存储迁移到新的第三方存储。支持本地可读文件真实上传，也支持把已有成功备份一键切换为主存储，适合更换厂商、迁移区域和成本优化。</p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/storages') ?>" data-icon="database">基础存储源</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
    </div>
</section>

<nav class="storage-backup-tabs glass" aria-label="多存储备份模块">
    <a href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
    <a href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
    <a href="<?= url('admin/storage-backups/backfill') ?>" data-icon="archive-restore">历史补备</a>
    <a class="active" href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
</nav>

<section class="ops-metric-grid storage-backup-metrics">
    <article class="ops-metric-card glass"><span>待评估文件</span><b><?= e(number_format((int) $plan['total'])) ?></b><small>按当前源存储和类型筛选</small></article>
    <article class="ops-metric-card glass ok"><span>可直接切换</span><b><?= e(number_format((int) $plan['ready_backup'])) ?></b><small>目标存储已有成功副本</small></article>
    <article class="ops-metric-card glass"><span>本地可迁移</span><b><?= e(number_format((int) $plan['local_readable'])) ?></b><small>源文件在本地可读，可真实上传</small></article>
    <article class="ops-metric-card glass danger"><span>仍需处理</span><b><?= e(number_format((int) $plan['needs_upload_or_backup'])) ?></b><small>远程源建议先执行历史补备</small></article>
</section>

<?php if ($summary): ?>
    <section class="form-section glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Result</p>
                <h2>上次迁移结果</h2>
                <p>扫描 <?= e((int) $summary['scanned']) ?> 个，上传 <?= e((int) $summary['uploaded']) ?> 个，切换 <?= e((int) $summary['switched']) ?> 个，已有副本 <?= e((int) $summary['backup_ready']) ?> 个，跳过 <?= e((int) $summary['skipped']) ?> 个，失败 <?= e((int) $summary['failed']) ?> 个。</p>
            </div>
        </div>
        <?php if (!empty($summary['errors'])): ?>
            <div class="storage-backup-runbook">
                <?php foreach ($summary['errors'] as $error): ?><p><b>失败原因</b><span><?= e($error) ?></span></p><?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
<?php endif; ?>

<section class="storage-backup-layout">
    <article class="form-section glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">Plan</p>
                <h2>迁移批次设置</h2>
                <p>建议先不勾选“切换主记录”，执行 10 到 20 个文件验证目标存储写入和外链，再开启切换。</p>
            </div>
        </div>
        <form method="get" action="<?= url('admin/storage-migration') ?>" class="form-grid two">
            <label>
                <span>源存储</span>
                <select name="source_storage_id">
                    <option value="0" <?= (int) $filters['source_storage_id'] === 0 ? 'selected' : '' ?>>全部当前存储</option>
                    <?php foreach ($storages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>" <?= (int) $filters['source_storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>目标存储</span>
                <select name="target_storage_id" required>
                    <option value="0">请选择目标存储</option>
                    <?php foreach ($enabledStorages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>" <?= (int) $filters['target_storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>文件范围</span>
                <select name="file_scope">
                    <?php foreach ($scopeLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= (string) $filters['file_scope'] === (string) $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="span-all card-actions">
                <button class="btn btn-ghost" type="submit" data-icon="scan-search">刷新迁移计划</button>
            </div>
        </form>

        <form method="post" action="<?= url('admin/storage-migration/run') ?>" class="form-grid two confirm-form" data-confirm="确认执行本批次存储迁移吗？建议先小批量验证，确认外链正常后再勾选切换主记录。">
            <?= csrf_field() ?>
            <input type="hidden" name="source_storage_id" value="<?= e((int) $filters['source_storage_id']) ?>">
            <input type="hidden" name="target_storage_id" value="<?= e((int) $filters['target_storage_id']) ?>">
            <input type="hidden" name="file_scope" value="<?= e($filters['file_scope']) ?>">
            <label>
                <span>本批处理数量</span>
                <input type="number" name="limit" min="1" max="100" value="20">
            </label>
            <label class="inline-check">
                <input type="checkbox" name="switch_primary">
                <span>成功后切换主文件记录到目标存储</span>
            </label>
            <div class="span-all card-actions">
                <button class="btn btn-primary" type="submit" data-icon="play">执行迁移批次</button>
            </div>
        </form>
    </article>

    <aside class="table-card glass storage-backup-note">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Rules</p>
                <h2>迁移规则</h2>
            </div>
        </div>
        <div class="storage-backup-runbook">
            <p><b>本地源文件</b><span>源存储是本地且文件存在时，会真实上传到目标存储并记录结果。</span></p>
            <p><b>已有备份</b><span>目标存储已有 success 副本时，可不重复上传，直接切换主记录。</span></p>
            <p><b>远程源文件</b><span>当前不做远程拉取，避免厂商签名、私有桶和防盗链导致假成功。请先执行历史补备或重新上传。</span></p>
        </div>
    </aside>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Migration Tasks</p>
            <h2>最近迁移记录</h2>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr><th>ID</th><th>文件</th><th>目标存储</th><th>状态</th><th>尝试</th><th>更新时间</th><th>说明</th></tr>
            </thead>
            <tbody>
            <?php foreach ($tasks as $task): ?>
                <?php $status = isset($task['status']) ? (string) $task['status'] : 'pending'; ?>
                <tr>
                    <td data-label="ID">#<?= e($task['id']) ?></td>
                    <td data-label="文件"><b><?= e(!empty($task['original_name']) ? $task['original_name'] : ('文件 #' . $task['file_id'])) ?></b><small><?= e($task['file_type']) ?> / <?= e(format_bytes((int) $task['file_size'])) ?></small></td>
                    <td data-label="目标存储"><?= e(!empty($task['storage_name']) ? $task['storage_name'] : ('#' . $task['storage_id'])) ?><small><?= e(strtoupper((string) $task['storage_type'])) ?></small></td>
                    <td data-label="状态"><span class="status-pill <?= e(isset($statusClass[$status]) ? $statusClass[$status] : 'muted') ?>"><?= e($status) ?></span></td>
                    <td data-label="尝试"><?= e((int) $task['attempts']) ?></td>
                    <td data-label="更新时间"><?= e(!empty($task['updated_at']) ? $task['updated_at'] : $task['created_at']) ?></td>
                    <td data-label="说明"><?= e(!empty($task['error_message']) ? $task['error_message'] : '迁移记录正常') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$tasks): ?>
                <tr><td colspan="7" class="empty-table responsive-table-span">暂无迁移记录。选择目标存储并执行一个小批次后，这里会显示每个文件的处理结果。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
