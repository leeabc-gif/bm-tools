<?php
$policies = isset($policies) ? $policies : [];
$storages = isset($storages) ? $storages : [];
$stats = isset($stats) ? $stats : ['local_files' => 0, 'success' => 0, 'failed' => 0, 'policies' => 0];
$scopeLabels = ['' => '全部文件', 'image' => '图床图片', 'file' => '网盘文件'];
$enabledStorages = array_values(array_filter($storages, function ($storage) {
    return !empty($storage['is_enabled']);
}));
$localStorages = array_values(array_filter($enabledStorages, function ($storage) {
    return isset($storage['type']) && $storage['type'] === 'local';
}));
?>

<section class="admin-page-head glass storage-backup-hero">
    <div>
        <p class="eyebrow">Backfill</p>
        <h1>历史文件补备</h1>
        <p>为已有文件补齐多存储备份记录。当前版本优先处理本地可读源文件，避免远程源对象无法下载时出现不可控的假成功。</p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
        <a class="btn btn-primary" href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
    </div>
</section>

<nav class="storage-backup-tabs glass" aria-label="多存储备份模块">
    <a href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
    <a href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
    <a class="active" href="<?= url('admin/storage-backups/backfill') ?>" data-icon="archive-restore">历史补备</a>
    <a href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
</nav>

<section class="ops-metric-grid storage-backup-metrics">
    <article class="ops-metric-card glass"><span>本地源文件</span><b><?= e(number_format($stats['local_files'])) ?></b><small>可直接读取并补备</small></article>
    <article class="ops-metric-card glass ok"><span>启用策略</span><b><?= e(number_format($stats['policies'])) ?></b><small>补备会按策略匹配</small></article>
    <article class="ops-metric-card glass"><span>已成功备份</span><b><?= e(number_format($stats['success'])) ?></b><small>不会重复写入成功目标</small></article>
    <article class="ops-metric-card glass danger"><span>失败任务</span><b><?= e(number_format($stats['failed'])) ?></b><small>可到任务页批量重试</small></article>
</section>

<section class="storage-backup-layout storage-backup-layout-equal">
    <article class="form-section glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">Repair</p>
                <h2>执行历史补备</h2>
                <p>适合新增备份策略后，把以前已经上传的本地文件补写到第二、第三个存储厂商。建议先小批量 10 到 20 个验证。</p>
            </div>
        </div>
        <form method="post" action="<?= url('admin/storage-backups/backfill') ?>" class="form-grid two storage-backup-form confirm-form" data-confirm="确认开始历史文件补备吗？建议先小批量验证厂商配置。">
            <?= csrf_field() ?>
            <label>
                <span>每次处理文件数</span>
                <input type="number" name="limit" min="1" max="200" value="20">
                <small class="field-help">为避免请求超时，建议首次使用 10 到 20 个，稳定后再提高。</small>
            </label>
            <label>
                <span>文件范围</span>
                <select name="file_scope">
                    <?php foreach ($scopeLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>"><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>指定策略</span>
                <select name="policy_id">
                    <option value="0">全部启用策略</option>
                    <?php foreach ($policies as $policy): ?>
                        <option value="<?= e($policy['id']) ?>"><?= e($policy['name']) ?> / <?= e(isset($scopeLabels[$policy['file_scope']]) ? $scopeLabels[$policy['file_scope']] : $policy['file_scope']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>主存储来源</span>
                <select name="primary_storage_id">
                    <option value="0">全部本地主存储</option>
                    <?php foreach ($localStorages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>"><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="span-2">
                <span>指定备份目标</span>
                <select name="target_storage_id">
                    <option value="0">策略内全部备份目标</option>
                    <?php foreach ($enabledStorages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>"><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="form-actions span-2">
                <button class="btn btn-primary" type="submit" data-icon="play">开始补备</button>
                <a class="btn btn-ghost" href="<?= url('admin/storage-backups/tasks?status=failed') ?>" data-icon="list-checks">查看失败任务</a>
            </div>
        </form>
    </article>

    <aside class="table-card glass storage-backup-note">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Rules</p>
                <h2>执行边界</h2>
            </div>
        </div>
        <div class="storage-backup-runbook">
            <p><b>只处理本地可读源文件</b><span>远程 OSS/COS/R2 等源文件暂不直接补备，除非后续增加下载到临时文件的安全实现。</span></p>
            <p><b>成功目标不会重复上传</b><span>同一个文件、同一个目标存储、同一条策略已经成功时，会自动跳过，避免多次覆盖和产生额外费用。</span></p>
            <p><b>失败会生成任务记录</b><span>厂商 Key、Bucket、区域、权限、网络错误会写入备份任务页，方便下一步排查。</span></p>
        </div>
    </aside>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Workflow</p>
            <h2>推荐操作流程</h2>
            <p>按这个顺序执行，能把风险和排查成本压低。</p>
        </div>
    </div>
    <div class="storage-backup-steps">
        <article><b>1</b><span><strong>先配置策略</strong><small>确认主存储、目标存储、文件范围和失败策略。</small></span></article>
        <article><b>2</b><span><strong>小批量补备</strong><small>先处理 10 到 20 个文件，看任务页是否有厂商错误。</small></span></article>
        <article><b>3</b><span><strong>扩大批量</strong><small>确认稳定后再调到 50 或 100，避免 PHP 请求超时。</small></span></article>
        <article><b>4</b><span><strong>处理失败</strong><small>到备份任务页按策略或目标存储批量重试。</small></span></article>
    </div>
</section>
