<?php
$payments = isset($payments) && is_array($payments) ? $payments : [];
$paymentStats = isset($paymentStats) ? $paymentStats : ['total' => count($payments), 'enabled' => 0, 'manual' => 0, 'online' => 0, 'configured' => 0];
$paymentMeta = [
    'balance' => [
        'icon' => 'wallet',
        'title' => '余额支付',
        'desc' => '用于用户使用账户余额购买套餐，建议保持启用。',
    ],
    'alipay' => [
        'icon' => 'scan-line',
        'title' => '支付宝当面付',
        'desc' => '适合扫码收款。正式运营前请完成 AppID、应用私钥、支付宝公钥和回调测试。',
    ],
    'wechat' => [
        'icon' => 'message-circle',
        'title' => '微信支付',
        'desc' => '微信商户支付配置入口，适合对接扫码支付或小程序支付。',
    ],
    'epay' => [
        'icon' => 'landmark',
        'title' => '易支付',
        'desc' => '聚合支付通道配置入口，适合快速覆盖多种在线支付方式。',
    ],
    'manual' => [
        'icon' => 'user-check',
        'title' => '人工充值',
        'desc' => '用于线下转账、备用收款和早期运营阶段的人工审核入账。',
    ],
];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">收款通道</p>
        <h1>支付配置</h1>
        <p>统一维护余额支付、支付宝当面付、微信支付、易支付和人工充值。页面不再使用顶部切换条，避免配置项拥挤混乱。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('admin/orders') ?>" data-icon="receipt-text">订单管理</a>
        <a class="btn btn-ghost" href="<?= url('admin/recharges') ?>" data-icon="wallet-cards">充值审核</a>
    </div>
</section>

<section class="bm-admin-metric-grid bm-admin-workbench-metrics">
    <article class="bm-admin-metric is-blue"><span class="bm-icon-tile"><i data-lucide="credit-card"></i></span><div><small>通道总数</small><strong><?= e(number_format((int) $paymentStats['total'])) ?></strong><em>统一收款能力底座</em></div></article>
    <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="badge-check"></i></span><div><small>已启用</small><strong><?= e(number_format((int) $paymentStats['enabled'])) ?></strong><em>当前对外可用通道</em></div></article>
    <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="landmark"></i></span><div><small>在线收款</small><strong><?= e(number_format((int) $paymentStats['online'])) ?></strong><em>不含人工审核通道</em></div></article>
    <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="shield-check"></i></span><div><small>已完成配置</small><strong><?= e(number_format((int) $paymentStats['configured'])) ?></strong><em>关键参数已录入</em></div></article>
</section>

<section class="bm-admin-screen-grid">
    <article class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Commerce Guidance</span>
                <h2>收款策略建议</h2>
            </div>
        </div>
        <div class="bm-admin-screen-summary-grid">
            <div class="bm-admin-screen-summary-item"><span>基础闭环</span><strong><?= $paymentStats['enabled'] > 0 ? '已具备' : '待配置' ?></strong><small>至少启用一个通道，订单链路才完整</small></div>
            <div class="bm-admin-screen-summary-item"><span>人工充值</span><strong><?= $paymentStats['manual'] > 0 ? '可用' : '缺失' ?></strong><small>适合作为早期运营和异常兜底通道</small></div>
            <div class="bm-admin-screen-summary-item"><span>在线支付</span><strong><?= $paymentStats['online'] > 0 ? '已启用' : '未启用' ?></strong><small>更利于自动化成交与降低客服成本</small></div>
        </div>
    </article>

    <article class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Readiness Check</span>
                <h2>上线前检查</h2>
            </div>
        </div>
        <div class="bm-admin-screen-list bm-admin-settings-actions">
            <div><span>回调地址</span><strong>确认通知地址可被公网访问</strong></div>
            <div><span>收款说明</span><strong>人工充值需提供清晰收款与审核说明</strong></div>
            <div><span>排序策略</span><strong>把主推支付方式放在前面提升转化</strong></div>
            <div><span>联动验证</span><strong>保存后去充值页和下单页做链路测试</strong></div>
        </div>
    </article>
</section>

<section class="payment-clean-list">
    <?php foreach ($payments as $p): ?>
        <?php
        $code = $p['code'];
        $meta = isset($paymentMeta[$code]) ? $paymentMeta[$code] : [
            'icon' => 'credit-card',
            'title' => $p['name'],
            'desc' => '扩展支付方式配置。',
        ];
        $config = json_decode((string) $p['config'], true);
        $config = is_array($config) ? $config : [];
        ?>
        <article class="payment-clean-card glass">
            <form method="post" action="<?= url('admin/payments/save') ?>" class="form-grid two">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= e($p['id']) ?>">
                <input type="hidden" name="code" value="<?= e($code) ?>">

                <div class="payment-clean-head span-all">
                    <span class="payment-panel-icon" data-lucide="<?= e($meta['icon']) ?>"></span>
                    <div>
                        <h2><?= e($meta['title']) ?></h2>
                        <p><?= e($meta['desc']) ?></p>
                    </div>
                    <em class="<?= $p['is_enabled'] ? 'enabled' : '' ?>"><?= $p['is_enabled'] ? '已启用' : '已停用' ?></em>
                </div>

                <label>显示名称
                    <input name="name" value="<?= e($p['name']) ?>">
                </label>
                <label>排序值
                    <input type="number" name="sort_order" value="<?= e($p['sort_order']) ?>">
                </label>
                <label>启用状态
                    <select name="is_enabled">
                        <option value="1" <?= $p['is_enabled'] ? 'selected' : '' ?>>启用</option>
                        <option value="0" <?= !$p['is_enabled'] ? 'selected' : '' ?>>停用</option>
                    </select>
                </label>

                <?php if ($code === 'alipay'): ?>
                    <label>支付宝应用编号
                        <input name="app_id" value="<?= e(isset($config['app_id']) ? $config['app_id'] : '') ?>" placeholder="支付宝开放平台 AppID">
                    </label>
                    <label class="span-all">应用私钥
                        <textarea name="private_key" rows="5" placeholder="填写应用私钥，支持完整私钥格式或纯密钥内容"><?= e(isset($config['private_key']) ? $config['private_key'] : '') ?></textarea>
                    </label>
                    <label class="span-all">支付宝公钥
                        <textarea name="alipay_public_key" rows="5" placeholder="填写支付宝开放平台提供的支付宝公钥"><?= e(isset($config['alipay_public_key']) ? $config['alipay_public_key'] : '') ?></textarea>
                    </label>
                    <label>异步通知地址
                        <input name="notify_url" value="<?= e(isset($config['notify_url']) ? $config['notify_url'] : '') ?>" placeholder="<?= e(url('pay/alipay/notify')) ?>">
                    </label>
                    <label>订单有效期
                        <input name="timeout_express" value="<?= e(isset($config['timeout_express']) ? $config['timeout_express'] : '10m') ?>" placeholder="例如：10m">
                    </label>
                    <label class="inline-check span-all">
                        <input type="checkbox" name="sandbox" <?= !empty($config['sandbox']) ? 'checked' : '' ?>> 使用沙箱模式
                    </label>
                <?php elseif ($code === 'manual'): ?>
                    <label class="span-all">人工充值说明
                        <textarea name="instructions" rows="5" placeholder="例如：请转账后备注用户名和订单号，管理员将在工作时间审核。"><?= e(isset($config['instructions']) ? $config['instructions'] : '') ?></textarea>
                    </label>
                    <label class="span-all">联系方式与收款提示
                        <textarea name="contact" rows="4" placeholder="例如：客服 QQ、邮箱、收款账户、审核时间说明。"><?= e(isset($config['contact']) ? $config['contact'] : '') ?></textarea>
                    </label>
                <?php else: ?>
                    <label class="span-all">扩展配置 JSON
                        <textarea name="config_json" rows="6" placeholder='例如：{"merchant_id":"","secret_key":""}'><?= e($p['config'] ?: '{}') ?></textarea>
                    </label>
                <?php endif; ?>

                <div class="payment-clean-actions span-all">
                    <button class="btn btn-primary" type="submit" data-icon="save">保存当前配置</button>
                    <a class="btn btn-ghost" href="<?= url('recharge') ?>" target="_blank" data-icon="external-link">查看充值页</a>
                </div>
            </form>
        </article>
    <?php endforeach; ?>
</section>
