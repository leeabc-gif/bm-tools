<?php $uploadChecks = isset($uploadChecks) ? $uploadChecks : []; ?>

<section class="admin-page-head maintenance-head glass">
    <div>
        <p class="eyebrow">运行环境</p>
        <h1>环境信息</h1>
        <p>这里专门用于检查运行环境和服务器配置，不和在线更新、维护模式混在一起。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/maintenance') ?>" data-icon="arrow-left">返回维护</a>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">环境检查</p>
            <h2>运行环境检查</h2>
        </div>
        <span class="status-pill soft">MySQL <?= e($databaseVersion) ?></span>
    </div>
    <div class="maintenance-check-grid">
        <?php foreach ($checks as $check): ?>
            <article class="<?= $check['ok'] ? 'ok' : 'bad' ?>">
                <b><?= e($check['name']) ?></b>
                <span><?= e($check['value']) ?></span>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="table-card glass" id="upload-runtime-checks">
    <div class="section-head">
        <div>
            <p class="eyebrow">上传链路</p>
            <h2>上传运行诊断</h2>
            <p>上传失败优先看这里：临时目录、POST 限制、扩展、并发锁和默认存储会逐项给出结论。</p>
        </div>
        <div class="admin-head-actions">
            <a class="btn btn-ghost" href="<?= url('admin/upload-limits') ?>" data-icon="gauge">上传限制</a>
            <a class="btn btn-primary" href="<?= url('admin/storages') ?>" data-icon="plug-zap">存储测试</a>
        </div>
    </div>
    <div class="audit-list service-audit-list">
        <?php foreach ($uploadChecks as $check): ?>
            <div class="<?= !empty($check['ok']) ? 'ok' : 'bad' ?>">
                <span>
                    <b><?= e(isset($check['label']) ? $check['label'] : $check['name']) ?></b>
                    <small><?= !empty($check['stage']) ? e($check['stage']) . ' · ' : '' ?><?= e($check['hint']) ?></small>
                </span>
                <code><?= e((string) $check['value']) ?></code>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">本机服务器</p>
            <h2>本机环境信息</h2>
        </div>
    </div>
    <div class="meta-table">
        <span>操作系统</span><b><?= e($serverInfo['os']) ?></b>
        <span>PHP 版本</span><b><?= e($serverInfo['php_version']) ?></b>
        <span>Web 服务</span><b><?= e($serverInfo['server_software']) ?></b>
        <span>数据库版本</span><b><?= e($serverInfo['database_version']) ?></b>
        <span>内存限制</span><b><?= e($serverInfo['memory_limit']) ?></b>
        <span>上传限制</span><b><?= e($serverInfo['upload_max_filesize']) ?> / POST <?= e($serverInfo['post_max_size']) ?></b>
        <span>执行时间</span><b><?= e($serverInfo['max_execution_time']) ?></b>
        <span>磁盘空间</span><b>已用 <?= e($serverInfo['disk_used']) ?>，剩余 <?= e($serverInfo['disk_free']) ?></b>
        <span>检查时间</span><b><?= e($serverInfo['time']) ?></b>
    </div>
</section>
