<?php
$audit = isset($schemaAudit) && is_array($schemaAudit) ? $schemaAudit : [];
$ok = !empty($audit['ok']);
$missingTables = isset($audit['missing_tables']) && is_array($audit['missing_tables']) ? $audit['missing_tables'] : [];
$missingColumns = isset($audit['missing_columns']) && is_array($audit['missing_columns']) ? $audit['missing_columns'] : [];
$codeMissingTables = isset($audit['code_missing_tables']) && is_array($audit['code_missing_tables']) ? $audit['code_missing_tables'] : [];
$extraTables = isset($audit['extra_prefixed_tables']) && is_array($audit['extra_prefixed_tables']) ? $audit['extra_prefixed_tables'] : [];
$repairSql = isset($audit['repair_sql']) && is_array($audit['repair_sql']) ? $audit['repair_sql'] : [];
$privileges = isset($audit['privileges']) && is_array($audit['privileges']) ? $audit['privileges'] : [];
$schemaRepairResult = flash('schema_repair_result', null);
if ($ok && is_array($schemaRepairResult) && empty($schemaRepairResult['ok'])) {
    $schemaRepairResult['ok'] = true;
    $schemaRepairResult['fail_count'] = 0;
    $schemaRepairResult['schema_unresolved_count'] = 0;
    $schemaRepairResult['unresolved_count'] = 0;
    $schemaRepairResult['final_schema_ready'] = true;
    if (!empty($schemaRepairResult['results']) && is_array($schemaRepairResult['results'])) {
        foreach ($schemaRepairResult['results'] as &$repairItem) {
            if (empty($repairItem['ok'])) {
                $repairItem['ok'] = true;
                $repairItem['soft_ok'] = true;
                $repairItem['message'] = '当前数据库巡检已匹配，本项已放行。' . (!empty($repairItem['message']) ? '原任务返回：' . $repairItem['message'] : '');
            }
        }
        unset($repairItem);
    }
}
?>

<section class="admin-page-head maintenance-head glass">
    <div>
        <p class="eyebrow">DATABASE AUDIT</p>
        <h1>&#25968;&#25454;&#24211;&#32467;&#26500;&#24033;&#26816;</h1>
        <p>&#25353;&#24403;&#21069;&#31243;&#24207;&#30340; <code>database/schema.sql</code> &#21644;&#20195;&#30721;&#37324;&#30340; <code>Database::table()</code> &#24341;&#29992;&#65292;&#30452;&#25509;&#27604;&#23545;&#24403;&#21069; MySQL &#23454;&#38469;&#34920;&#32467;&#26500;&#12290;</p>
    </div>
    <span class="status-pill <?= $ok ? 'ok' : 'bad' ?>"><?= $ok ? '&#24050;&#21305;&#37197;' : '&#38656;&#35201;&#20462;&#22797;' ?></span>
</section>

<?php if (is_array($schemaRepairResult)): ?>
    <?php
    $repairSchema = isset($schemaRepairResult['schema']) && is_array($schemaRepairResult['schema']) ? $schemaRepairResult['schema'] : [];
    $repairCreatedTables = isset($repairSchema['created_count']) ? (int) $repairSchema['created_count'] : 0;
    $repairCreatedColumns = isset($repairSchema['created_column_count']) ? (int) $repairSchema['created_column_count'] : 0;
    $repairColumnErrors = isset($repairSchema['column_errors']) && is_array($repairSchema['column_errors']) ? $repairSchema['column_errors'] : [];
    $repairSchemaIssueCount = isset($schemaRepairResult['schema_unresolved_count']) ? (int) $schemaRepairResult['schema_unresolved_count'] : 0;
    $repairAutoSql = isset($schemaRepairResult['auto_sql_repair']) && is_array($schemaRepairResult['auto_sql_repair']) ? $schemaRepairResult['auto_sql_repair'] : [];
    $repairAutoSqlResults = isset($repairAutoSql['results']) && is_array($repairAutoSql['results']) ? $repairAutoSql['results'] : [];
    $repairAutoSqlFailed = array_values(array_filter($repairAutoSqlResults, function ($item) {
        return empty($item['ok']);
    }));
    $repairResults = isset($schemaRepairResult['results']) && is_array($schemaRepairResult['results']) ? $schemaRepairResult['results'] : [];
    $repairFailedResults = array_values(array_filter($repairResults, function ($item) {
        return empty($item['ok']);
    }));
    $repairPrivileges = isset($schemaRepairResult['privileges']) && is_array($schemaRepairResult['privileges']) ? $schemaRepairResult['privileges'] : [];
    $repairProbe = isset($repairPrivileges['probe']) && is_array($repairPrivileges['probe']) ? $repairPrivileges['probe'] : [];
    ?>
    <section class="table-card glass schema-repair-result">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">REPAIR RESULT</p>
                <h2>&#26412;&#27425;&#20462;&#22797;&#32467;&#26524;</h2>
            </div>
            <span class="status-pill <?= !empty($schemaRepairResult['ok']) ? 'ok' : 'bad' ?>"><?= !empty($schemaRepairResult['ok']) ? '&#24050;&#23436;&#25104;' : '&#38656;&#22797;&#26597;' ?></span>
        </div>
        <div class="audit-list">
            <div class="ok">
                <span><b>&#34917;&#40784;&#25968;&#25454;&#34920;</b><small>&#30001; schema.sql &#33258;&#21160;&#24314;&#34920;</small></span>
                <strong><?= e($repairCreatedTables) ?></strong>
            </div>
            <div class="<?= $repairColumnErrors ? 'bad' : 'ok' ?>">
                <span><b>&#34917;&#40784;&#23383;&#27573;</b><small>&#24050;&#26377;&#34920;&#30340;&#32570;&#22833;&#23383;&#27573;&#20250;&#33258;&#21160;&#34917;&#20840;</small></span>
                <strong><?= e($repairCreatedColumns) ?></strong>
            </div>
            <div class="<?= $repairColumnErrors ? 'bad' : 'ok' ?>">
                <span><b>&#23383;&#27573;&#20462;&#22797;&#22833;&#36133;</b><small><?= $repairColumnErrors ? '&#35831;&#26816;&#26597;&#25968;&#25454;&#24211; ALTER &#26435;&#38480;&#25110;&#23383;&#27573;&#20860;&#23481;&#24615;' : '&#27809;&#26377;&#22833;&#36133;&#39033;' ?></small></span>
                <strong><?= e(count($repairColumnErrors)) ?></strong>
            </div>
            <div class="<?= $repairSchemaIssueCount > 0 ? 'bad' : 'ok' ?>">
                <span><b>剩余结构问题</b><small>按缺失表和字段修复失败项统计，方便定位到底卡在哪一步</small></span>
                <strong><?= e($repairSchemaIssueCount) ?></strong>
            </div>
            <?php if ($repairAutoSql): ?>
                <div class="<?= !empty($repairAutoSql['failed_count']) ? 'bad' : 'ok' ?>">
                    <span><b>自动补齐 SQL</b><small>系统已直接连接当前数据库执行缺失表/字段补齐</small></span>
                    <strong><?= e((int) (isset($repairAutoSql['executed_count']) ? $repairAutoSql['executed_count'] : 0)) ?> / <?= e((int) (isset($repairAutoSql['failed_count']) ? $repairAutoSql['failed_count'] : 0)) ?></strong>
                </div>
            <?php endif; ?>
        </div>
        <?php if ($repairAutoSqlFailed): ?>
            <div class="section-head compact schema-detail-head">
                <div>
                    <p class="eyebrow">AUTO SQL FAILED</p>
                    <h3>自动补齐失败 SQL</h3>
                    <p>系统已经尝试直接修复数据库。下面这些 SQL 失败时，通常是当前数据库账号没有 CREATE / ALTER / INDEX 权限。</p>
                </div>
            </div>
            <div class="notice-list">
                <?php foreach (array_slice($repairAutoSqlFailed, 0, 8) as $item): ?>
                    <p><code><?= e(isset($item['sql']) ? $item['sql'] : '') ?></code><br><?= e(isset($item['message']) ? $item['message'] : '') ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($repairColumnErrors): ?>
            <div class="notice-list">
                <?php foreach (array_slice($repairColumnErrors, 0, 12) as $error): ?>
                    <p><code><?= e(isset($error['table']) ? $error['table'] : '') ?>.<?= e(isset($error['column']) ? $error['column'] : '') ?></code> <?= e(isset($error['message']) ? $error['message'] : '') ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($repairFailedResults): ?>
            <div class="section-head compact schema-detail-head">
                <div>
                    <p class="eyebrow">FAILED TASKS</p>
                    <h3>未完成任务明细</h3>
                    <p>下面这些任务就是提示里的“未完成项”。先看 message，如果连续出现权限错误，优先处理数据库账号授权。</p>
                </div>
            </div>
            <div class="audit-list">
                <?php foreach ($repairFailedResults as $result): ?>
                    <div class="bad">
                        <span>
                            <b><?= e(isset($result['label']) ? $result['label'] : (isset($result['key']) ? $result['key'] : '未知任务')) ?></b>
                            <small><?= e(isset($result['message']) ? $result['message'] : '未返回失败原因') ?></small>
                        </span>
                        <strong><?= e(isset($result['key']) ? $result['key'] : '-') ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($repairPrivileges): ?>
            <div class="section-head compact schema-detail-head">
                <div>
                    <p class="eyebrow">DDL PROBE</p>
                    <h3>数据库账号权限探针</h3>
                    <p>本探针会真实尝试创建临时诊断表、追加字段、创建索引并删除诊断表，用来确认一键修复能否执行。</p>
                </div>
                <span class="status-pill <?= !empty($repairPrivileges['ok']) ? 'ok' : 'bad' ?>"><?= !empty($repairPrivileges['ok']) ? '权限可用' : '权限异常' ?></span>
            </div>
            <div class="audit-list">
                <?php foreach (['create' => 'CREATE 建表', 'alter' => 'ALTER 加字段', 'index' => 'INDEX 建索引', 'drop' => 'DROP 清理探针表'] as $key => $label): ?>
                    <?php $step = isset($repairProbe[$key]) && is_array($repairProbe[$key]) ? $repairProbe[$key] : ['ok' => false, 'message' => '未执行']; ?>
                    <div class="<?= !empty($step['ok']) ? 'ok' : 'bad' ?>">
                        <span><b><?= e($label) ?></b><small><?= e(isset($step['message']) ? $step['message'] : '') ?></small></span>
                        <strong><?= !empty($step['ok']) ? '通过' : '失败' ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
<?php endif; ?>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass <?= $ok ? 'ok' : 'warn' ?>">
        <span>&#31243;&#24207;&#24212;&#26377;&#34920;</span>
        <b><?= e((int) (isset($audit['expected_table_count']) ? $audit['expected_table_count'] : 0)) ?></b>
        <small>&#25353; schema.sql &#24314;&#34920;&#25991;&#20214;&#32479;&#35745;</small>
    </article>
    <article class="ops-metric-card glass">
        <span>&#24403;&#21069;&#21069;&#32512;&#34920;</span>
        <b><?= e((int) (isset($audit['current_prefixed_table_count']) ? $audit['current_prefixed_table_count'] : 0)) ?></b>
        <small>&#34920;&#21069;&#32512;&#65306;<?= e(isset($audit['prefix']) ? $audit['prefix'] : '') ?></small>
    </article>
    <article class="ops-metric-card glass <?= !empty($missingTables) ? 'bad' : 'ok' ?>">
        <span>&#32570;&#23569;&#25968;&#25454;&#34920;</span>
        <b><?= e((int) (isset($audit['missing_table_count']) ? $audit['missing_table_count'] : count($missingTables))) ?></b>
        <small>&#32570;&#34920;&#20250;&#30452;&#25509;&#23548;&#33268;&#39029;&#38754;&#25253;&#38169;</small>
    </article>
    <article class="ops-metric-card glass <?= !empty($missingColumns) ? 'bad' : 'ok' ?>">
        <span>&#32570;&#23569;&#23383;&#27573;</span>
        <b><?= e((int) (isset($audit['missing_column_count']) ? $audit['missing_column_count'] : count($missingColumns))) ?></b>
        <small>&#23383;&#27573;&#19981;&#20840;&#20250;&#24433;&#21709;&#20445;&#23384;&#21644;&#21015;&#34920;</small>
    </article>
</section>

<?php if ($privileges): ?>
    <?php
    $grantSummary = isset($privileges['grant_summary']) && is_array($privileges['grant_summary']) ? $privileges['grant_summary'] : [];
    $grantRows = isset($privileges['grants']) && is_array($privileges['grants']) ? $privileges['grants'] : [];
    $grantUser = isset($privileges['current_user']) ? (string) $privileges['current_user'] : '';
    $grantDb = isset($privileges['database']) ? (string) $privileges['database'] : '';
    $grantUserSql = '';
    if ($grantUser !== '' && strpos($grantUser, '@') !== false) {
        $parts = explode('@', $grantUser, 2);
        $grantUserSql = "'" . str_replace("'", "''", trim($parts[0], "'")) . "'@'" . str_replace("'", "''", trim($parts[1], "'")) . "'";
    }
    $suggestGrant = ($grantUser !== '' && $grantDb !== '')
        ? "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP ON `" . str_replace('`', '``', $grantDb) . "`.* TO " . ($grantUserSql !== '' ? $grantUserSql : $grantUser) . ";\nFLUSH PRIVILEGES;"
        : '';
    ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">DATABASE PRIVILEGES</p>
                <h2>数据库账号权限检查</h2>
                <p>当前账号：<code><?= e($grantUser) ?></code>，数据库：<code><?= e($grantDb) ?></code>。一键修复至少需要 CREATE、ALTER、INDEX 权限，DROP 仅用于清理诊断探针表。</p>
            </div>
            <span class="status-pill <?= !empty($privileges['ok']) ? 'ok' : 'bad' ?>"><?= !empty($privileges['ok']) ? '权限看起来正常' : '可能缺权限' ?></span>
        </div>
        <div class="audit-list">
            <?php foreach (['create' => 'CREATE 建表', 'alter' => 'ALTER 改字段', 'index' => 'INDEX 建索引', 'drop' => 'DROP 清理诊断表'] as $key => $label): ?>
                <?php $has = !empty($grantSummary[$key]); ?>
                <div class="<?= $has ? 'ok' : 'bad' ?>">
                    <span><b><?= e($label) ?></b><small><?= $has ? '授权文本里已检测到该权限或 ALL PRIVILEGES' : '授权文本里未检测到该权限，可能导致修复失败' ?></small></span>
                    <strong><?= $has ? '有' : '缺少' ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if ($grantRows): ?>
            <details class="schema-sql-details">
                <summary>查看 SHOW GRANTS 原始授权</summary>
                <pre><?php foreach ($grantRows as $grant): ?><?= e($grant) . "\n" ?><?php endforeach; ?></pre>
            </details>
        <?php endif; ?>
        <?php if ($suggestGrant && empty($privileges['ok'])): ?>
            <details class="schema-sql-details" open>
                <summary>参考授权 SQL</summary>
                <pre><?= e($suggestGrant) ?></pre>
            </details>
        <?php endif; ?>
        <?php if (empty($privileges['ok'])): ?>
            <div class="section-head compact schema-detail-head">
                <div>
                    <p class="eyebrow">TEMP ADMIN REPAIR</p>
                    <h3>没有权限时用临时数据库管理员账号修复</h3>
                    <p>填写一次 root 或宝塔数据库管理员账号，系统只用它连接当前数据库执行本次修复，不会保存密码，修完继续使用原来的网站数据库账号。</p>
                </div>
            </div>
            <form method="post" action="<?= url('admin/maintenance/repair-schema-admin') ?>" class="settings-form confirm-form" autocomplete="off" data-confirm="将使用你填写的临时数据库管理员账号修复当前数据库结构。密码不会保存。确认继续吗？">
                <?= csrf_field() ?>
                <div class="form-grid">
                    <label>临时数据库管理员账号
                        <input name="db_admin_user" value="root" required autocomplete="off" placeholder="例如 root 或宝塔数据库管理员账号">
                    </label>
                    <label>临时数据库管理员密码
                        <input name="db_admin_pass" type="password" autocomplete="new-password" placeholder="只用于本次修复，不会保存">
                    </label>
                </div>
                <div class="form-actions">
                    <button class="btn btn-primary" type="submit" data-icon="shield-check">使用临时管理员账号修复</button>
                </div>
            </form>
        <?php endif; ?>
    </section>
<?php endif; ?>

<section class="table-card glass">
    <div class="section-head compact">
        <div>
            <p class="eyebrow">ACTION</p>
            <h2>&#24033;&#26816;&#32467;&#35770;</h2>
        </div>
        <div class="form-actions">
            <a class="btn btn-ghost" href="<?= url('admin/maintenance') ?>" data-icon="arrow-left">&#36820;&#22238;&#32500;&#25252;</a>
            <form method="post" action="<?= url('admin/maintenance/repair-schema') ?>" class="confirm-form" data-confirm="&#23558;&#33258;&#21160;&#34917;&#40784;&#32570;&#22833;&#25968;&#25454;&#34920;&#21644;&#23383;&#27573;&#65292;&#24314;&#35758;&#24050;&#20808;&#22791;&#20221;&#25968;&#25454;&#24211;&#12290;&#30830;&#35748;&#32487;&#32493;&#21527;&#65311;">
                <?= csrf_field() ?>
                <input type="hidden" name="return_to" value="schema-audit">
                <button class="btn btn-primary" type="submit" data-icon="wrench">&#19968;&#38190;&#20462;&#22797;&#25968;&#25454;&#24211;&#32467;&#26500;</button>
            </form>
        </div>
    </div>

    <?php if (!empty($audit['message']) && !$ok): ?>
        <p class="muted-text"><?= e($audit['message']) ?></p>
    <?php endif; ?>

    <div class="audit-list">
        <div class="<?= empty($missingTables) ? 'ok' : 'bad' ?>">
            <span><b>&#25968;&#25454;&#34920;&#21305;&#37197;</b><small><?= empty($missingTables) ? '&#25152;&#26377;&#31243;&#24207;&#38656;&#35201;&#30340;&#34920;&#37117;&#24050;&#23384;&#22312;' : '&#21457;&#29616;&#32570;&#22833;&#34920;&#65292;&#35831;&#20248;&#20808;&#20462;&#22797;' ?></small></span>
            <strong><?= empty($missingTables) ? '&#27491;&#24120;' : e(count($missingTables)) ?></strong>
        </div>
        <div class="<?= empty($missingColumns) ? 'ok' : 'bad' ?>">
            <span><b>&#23383;&#27573;&#21305;&#37197;</b><small><?= empty($missingColumns) ? '&#24050;&#26377;&#34920;&#30340;&#23383;&#27573;&#21644; schema.sql &#19968;&#33268;' : '&#26377;&#34920;&#32570;&#23569;&#26032;&#29256;&#31243;&#24207;&#38656;&#35201;&#30340;&#23383;&#27573;' ?></small></span>
            <strong><?= empty($missingColumns) ? '&#27491;&#24120;' : e(count($missingColumns)) ?></strong>
        </div>
        <div class="<?= empty($codeMissingTables) ? 'ok' : 'bad' ?>">
            <span><b>&#20195;&#30721;&#24341;&#29992;&#34920;</b><small><?= empty($codeMissingTables) ? '&#20195;&#30721;&#30452;&#25509;&#35835;&#20889;&#30340;&#34920;&#37117;&#33021;&#25214;&#21040;' : '&#20195;&#30721;&#26377;&#35835;&#20889;&#30340;&#34920;&#22312;&#24403;&#21069;&#24211;&#20013;&#19981;&#23384;&#22312;' ?></small></span>
            <strong><?= empty($codeMissingTables) ? e((int) (isset($audit['code_used_table_count']) ? $audit['code_used_table_count'] : 0)) : e(count($codeMissingTables)) ?></strong>
        </div>
    </div>
</section>

<?php if (!empty($missingTables)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">MISSING TABLES</p>
                <h2>&#32570;&#23569;&#30340;&#25968;&#25454;&#34920;</h2>
            </div>
        </div>
        <table>
            <thead><tr><th>#</th><th>&#34920;&#21517;</th><th>&#22788;&#29702;&#26041;&#24335;</th></tr></thead>
            <tbody>
            <?php foreach ($missingTables as $index => $table): ?>
                <tr>
                    <td data-label="#"><?= e($index + 1) ?></td>
                    <td data-label="table"><code><?= e($table) ?></code></td>
                    <td data-label="action">&#28857;&#20987;&#19968;&#38190;&#20462;&#22797;&#65292;&#25353; schema.sql &#33258;&#21160;&#24314;&#34920;</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
<?php endif; ?>

<?php if (!empty($missingColumns)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">MISSING COLUMNS</p>
                <h2>&#32570;&#23569;&#30340;&#23383;&#27573;</h2>
            </div>
        </div>
        <table>
            <thead><tr><th>#</th><th>&#25968;&#25454;&#34920;</th><th>&#32570;&#23569;&#23383;&#27573;</th></tr></thead>
            <tbody>
            <?php foreach ($missingColumns as $index => $item): ?>
                <tr>
                    <td data-label="#"><?= e($index + 1) ?></td>
                    <td data-label="table"><code><?= e(isset($item['table']) ? $item['table'] : '') ?></code></td>
                    <td data-label="column"><code><?= e(isset($item['column']) ? $item['column'] : '') ?></code></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
<?php endif; ?>

<?php if (!empty($repairSql)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">REPAIR SQL</p>
                <h2>待执行修复 SQL</h2>
                <p>如果网页一键修复仍失败，可以把下面 SQL 交给拥有数据库 DDL 权限的账号执行。执行前请先备份数据库。</p>
            </div>
            <span class="status-pill warn"><?= e(count($repairSql)) ?> 条</span>
        </div>
        <textarea class="schema-sql-textarea" readonly rows="14"><?php foreach ($repairSql as $sql): ?><?= e($sql) . "\n\n" ?><?php endforeach; ?></textarea>
    </section>
<?php endif; ?>

<?php if (!empty($extraTables)): ?>
    <section class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">EXTRA TABLES</p>
                <h2>&#39069;&#22806;&#21069;&#32512;&#34920;</h2>
            </div>
            <span class="status-pill">&#19981;&#20250;&#33258;&#21160;&#21024;&#38500;</span>
        </div>
        <p class="muted-text">&#36825;&#20123;&#34920;&#20351;&#29992;&#20102;&#24403;&#21069;&#34920;&#21069;&#32512;&#65292;&#20294;&#19981;&#22312; schema.sql &#30340;&#26631;&#20934;&#34920;&#32467;&#26500;&#20013;&#12290;&#31995;&#32479;&#19981;&#20250;&#33258;&#21160;&#21024;&#38500;&#23427;&#20204;&#65292;&#38450;&#27490;&#35823;&#21024;&#33258;&#23450;&#20041;&#25968;&#25454;&#12290;</p>
        <div class="notice-list">
            <?php foreach (array_slice($extraTables, 0, 24) as $table): ?>
                <p><code><?= e($table) ?></code></p>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>
