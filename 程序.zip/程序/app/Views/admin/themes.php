<?php
$adminStyle = isset($adminThemeStyle) && $adminThemeStyle === 'anime' ? 'anime' : 'anime';
$frontendStyle = isset($frontendThemeStyle) && $frontendThemeStyle === 'anime' ? 'anime' : 'anime';
$frontendHomeStyle = isset($frontendHomeStyle) && in_array($frontendHomeStyle, ['default', 'terminal', 'technology', 'anime', 'business', 'blog'], true) ? $frontendHomeStyle : 'default';
$uiThemes = [
    'anime' => [
        'title' => '现代浅色主题',
        'desc' => '浅灰背景、白色卡片、细边框、轻阴影和蓝紫点缀，适合全站统一使用。',
        'tag' => '现代',
    ],
];

$homeStyles = [
    'default' => '默认工具站风',
    'terminal' => '终端风',
    'technology' => '科技风',
    'anime' => '二次元轻柔风',
    'business' => '极简商务风',
    'blog' => '个人博客风',
];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">系统设置</p>
        <h1>主题设置</h1>
    </div>
    <a class="btn btn-ghost" href="<?= url('/') ?>" target="_blank" data-icon="external-link">预览首页</a>
</section>

<form method="post" action="<?= url('admin/themes') ?>" class="form-section glass theme-save-form" data-theme-saved-message="主题切换成功～">
    <?= csrf_field() ?>
    <input type="hidden" id="admin-theme-style" name="admin_theme_style" value="<?= e($adminStyle) ?>">
    <input type="hidden" id="frontend-theme-style" name="frontend_theme_style" value="<?= e($frontendStyle) ?>">
    <input type="hidden" id="frontend-home-style" name="frontend_home_style" value="<?= e($frontendHomeStyle) ?>">

    <div class="theme-select-settings">
        <label>
            <span>后台管理系统主题</span>
            <select class="theme-select-control" data-theme-value="#admin-theme-style">
                <?php foreach ($uiThemes as $value => $item): ?>
                    <option value="<?= e($value) ?>" <?= $adminStyle === $value ? 'selected' : '' ?>><?= e($item['title']) ?></option>
                <?php endforeach; ?>
            </select>
            <small>按当前管理员账号独立保存，保存后刷新后台生效。</small>
        </label>

        <label>
            <span>前台全站 UI 主题</span>
            <select class="theme-select-control" data-theme-value="#frontend-theme-style">
                <?php foreach ($uiThemes as $value => $item): ?>
                    <option value="<?= e($value) ?>" <?= $frontendStyle === $value ? 'selected' : '' ?>><?= e($item['title']) ?></option>
                <?php endforeach; ?>
            </select>
            <small>控制前台首页、个人中心、网盘、图床、分享仓库、公告页等页面组件样式。</small>
        </label>

        <label>
            <span>前台首页模板</span>
            <select class="theme-select-control" data-home-value="#frontend-home-style">
                <?php foreach ($homeStyles as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $frontendHomeStyle === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <small>只切换首页视觉风格，不改变首页结构、菜单、统计、监控和业务入口。</small>
        </label>
    </div>

    <div class="form-actions">
        <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
        <a class="btn btn-ghost" href="<?= url('admin/settings') ?>" data-icon="settings">返回系统设置</a>
    </div>
</form>
