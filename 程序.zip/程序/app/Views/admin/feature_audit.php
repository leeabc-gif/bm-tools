<?php
$menuAudit = isset($menuAudit) ? $menuAudit : [];
$routeAudit = isset($routeAudit) ? $routeAudit : [];
$formAudit = isset($formAudit) ? $formAudit : [];
$tableAudit = isset($tableAudit) ? $tableAudit : [];
$assetChecks = isset($assetChecks) ? $assetChecks : [];
$schemaAudit = isset($schemaAudit) && is_array($schemaAudit) ? $schemaAudit : [];
$schemaChecks = isset($schemaChecks) ? $schemaChecks : [];
$environmentChecks = isset($environmentChecks) ? $environmentChecks : [];
$uploadChecks = isset($uploadChecks) ? $uploadChecks : [];
$securityChecks = isset($securityChecks) ? $securityChecks : [];
$diagnosticCards = isset($diagnosticCards) ? $diagnosticCards : [];
$tableChecks = isset($tableChecks) ? $tableChecks : [];
$directoryChecks = isset($directoryChecks) ? $directoryChecks : [];
$serviceChecks = isset($serviceChecks) ? $serviceChecks : [];
$schemaRepairResult = flash('schema_repair_result', null);
$allChecks = array_merge($schemaChecks, $environmentChecks, $uploadChecks, $securityChecks, $menuAudit, $routeAudit, $formAudit, $tableAudit, $assetChecks, $tableChecks, $directoryChecks, $serviceChecks);
$okCount = 0;
$badCount = 0;
foreach ($allChecks as $check) {
    if (!empty($check['ok'])) {
        $okCount++;
    } else {
        $badCount++;
    }
}
$missingTableCount = 0;
foreach ($tableChecks as $check) {
    if (empty($check['ok'])) {
        $missingTableCount++;
    }
}
$formatSize = function ($bytes) {
    $bytes = (int) $bytes;
    if ($bytes <= 0) {
        return '-';
    }
    if ($bytes >= 1048576) {
        return round($bytes / 1048576, 2) . ' MB';
    }
    return round($bytes / 1024, 1) . ' KB';
};
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">System Audit</p>
        <h1>功能巡检</h1>
        <p>集中检查菜单、路由、表单提交、移动端表格、静态资源、数据表、目录权限和关键服务。第三方存储、支付、上传或监控不通时，先看这里就能定位是哪一步没有接上。</p>
    </div>
    <div class="admin-head-actions">
        <form method="post" action="<?= url('admin/maintenance/repair-schema') ?>" class="confirm-form admin-inline-repair-form" data-confirm="将自动补齐缺失数据表并执行字段/索引升级，建议已先导出数据库备份。确认继续吗？">
            <?= csrf_field() ?>
            <input type="hidden" name="return_to" value="schema-audit">
            <button class="btn btn-primary" type="submit" data-icon="wrench">一键修复数据表</button>
        </form>
        <a class="btn btn-ghost" href="<?= url('admin/maintenance') ?>" data-icon="wrench">系统维护</a>
        <a class="btn btn-primary" href="<?= url('admin/storages') ?>" data-icon="database">存储配置</a>
    </div>
</section>

<?php if (is_array($schemaRepairResult)): ?>
    <section class="table-card glass schema-repair-result">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Repair Result</p>
                <h2>数据库结构修复结果</h2>
            </div>
            <span class="status-pill <?= !empty($schemaRepairResult['ok']) ? 'ok' : 'bad' ?>"><?= !empty($schemaRepairResult['ok']) ? '已完成' : '需检查' ?></span>
        </div>
        <div class="audit-list">
            <?php foreach (array_slice(isset($schemaRepairResult['results']) ? $schemaRepairResult['results'] : [], 0, 18) as $result): ?>
                <div class="<?= !empty($result['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e(isset($result['label']) ? $result['label'] : $result['key']) ?></b>
                        <small><?= e(isset($result['message']) ? $result['message'] : '') ?></small>
                    </span>
                    <strong><?= !empty($result['ok']) ? '正常' : '需检查' ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass ok"><span>正常项</span><b><?= e(number_format($okCount)) ?></b><small>已通过巡检</small></article>
    <article class="ops-metric-card glass <?= $badCount > 0 ? 'warn' : '' ?>"><span>待处理</span><b><?= e(number_format($badCount)) ?></b><small><?= $badCount > 0 ? '建议优先处理异常项' : '当前无明显阻断' ?></small></article>
    <article class="ops-metric-card glass"><span>数据表</span><b><?= e(number_format(isset($schemaAudit['expected_table_count']) ? (int) $schemaAudit['expected_table_count'] : count($tableChecks))) ?></b><small>标准结构覆盖</small></article>
    <article class="ops-metric-card glass"><span>功能入口</span><b><?= e(number_format(count($menuAudit))) ?></b><small>前台 / 用户 / 后台菜单</small></article>
</section>

<?php if ($diagnosticCards): ?>
    <section class="audit-health-board">
        <?php foreach ($diagnosticCards as $card): ?>
            <?php $status = isset($card['status']) ? $card['status'] : 'ok'; ?>
            <article class="audit-health-card <?= e($status) ?>">
                <span><?= $status === 'ok' ? '正常' : ($status === 'bad' ? '需处理' : '建议检查') ?></span>
                <h2><?= e($card['title']) ?></h2>
                <p><?= e($card['desc']) ?></p>
                <?php if (!empty($card['action_url'])): ?>
                    <a href="<?= url($card['action_url']) ?>" data-icon="arrow-up-right"><?= e($card['action_label']) ?></a>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    </section>
<?php endif; ?>

<section class="table-card glass" id="upload-runtime-checks">
    <div class="section-head">
        <div>
            <p class="eyebrow">Upload Pipeline</p>
            <h2>上传链路检查</h2>
            <p>把浏览器上传、PHP 限制、临时目录、并发锁、默认存储和对象存储基础配置拆开检查。用户再遇到上传失败时，可直接判断是哪一步不通。</p>
        </div>
        <div class="admin-head-actions">
            <a class="btn btn-ghost" href="<?= url('admin/upload-limits') ?>" data-icon="gauge">上传限制</a>
            <a class="btn btn-primary" href="<?= url('admin/storages') ?>" data-icon="plug-zap">存储真实测试</a>
        </div>
    </div>
    <div class="audit-list service-audit-list">
        <?php foreach ($uploadChecks as $item): ?>
            <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                <span>
                    <b><?= e($item['label']) ?></b>
                    <small><?= !empty($item['stage']) ? e($item['stage']) . ' · ' : '' ?><?= e($item['hint']) ?></small>
                </span>
                <code><?= e((string) $item['value']) ?></code>
                <?php if (!empty($item['action_url'])): ?>
                    <a class="btn btn-ghost btn-sm" href="<?= url($item['action_url']) ?>" data-icon="arrow-up-right"><?= e($item['action_label'] ?: '处理') ?></a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="admin-files-layout audit-overview-grid">
    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Schema Health</p>
                <h2>数据库结构健康</h2>
                <p>对比当前数据库和程序标准结构，直接判断缺表、缺字段、代码引用表是否完整。</p>
            </div>
            <a class="btn btn-ghost" href="<?= url('admin/maintenance/schema-audit') ?>" data-icon="database-zap">详细巡检</a>
        </div>
        <div class="audit-list">
            <?php foreach ($schemaChecks as $item): ?>
                <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e($item['label']) ?></b>
                        <small><?= e($item['hint']) ?></small>
                    </span>
                    <strong><?= e((string) $item['value']) ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (!empty($schemaAudit['missing_columns'])): ?>
            <div class="audit-issue-samples">
                <b>缺失字段示例</b>
                <?php foreach (array_slice($schemaAudit['missing_columns'], 0, 8) as $column): ?>
                    <code><?= e($column['table'] . '.' . $column['column']) ?></code>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>

    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Runtime</p>
                <h2>运行环境</h2>
                <p>检查 PHP 扩展、目录权限和基础运行条件，定位上传、在线更新、远程连接异常。</p>
            </div>
            <a class="btn btn-ghost" href="<?= url('admin/maintenance/environment') ?>" data-icon="server">环境信息</a>
        </div>
        <div class="audit-list">
            <?php foreach ($environmentChecks as $item): ?>
                <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e($item['name']) ?></b>
                        <small><?= e(!empty($item['ok']) ? '满足运行条件' : '需要处理，否则对应功能可能不可用') ?></small>
                    </span>
                    <strong><?= e($item['value']) ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Security Baseline</p>
            <h2>安全基线检查</h2>
            <p>检查安装锁、私有目录保护、上传目录脚本执行防护、服务层上传拦截和加密密钥状态。</p>
        </div>
        <a class="btn btn-ghost" href="<?= url('admin/settings/security') ?>" data-icon="shield-check">安全设置</a>
    </div>
    <div class="audit-grid compact">
        <?php foreach ($securityChecks as $item): ?>
            <article class="audit-item <?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                <span><?= e($item['label']) ?></span>
                <b><?= e($item['value']) ?></b>
                <small><?= e($item['hint']) ?></small>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Menu Routes</p>
            <h2>菜单入口检查</h2>
            <p>检查前台、用户中心和后台菜单入口是否都有 GET 路由承接，避免点击后出现 404 或跳错页面。</p>
        </div>
    </div>
    <div class="audit-grid">
        <?php foreach ($menuAudit as $item): ?>
            <article class="audit-item <?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                <span><?= e(isset($item['label']) ? $item['label'] : $item['scope']) ?></span>
                <b><?= e($item['path']) ?></b>
                <small><?= e($item['scope']) ?> · <?= e($item['target']) ?></small>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Route Targets</p>
            <h2>路由目标检查</h2>
            <p>检查 GET/POST 路由是否真的存在控制器方法。上传、保存、删除、第三方接口、支付回调等接口都会在这里被扫描。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr>
                <th>方法</th>
                <th>路径</th>
                <th>目标</th>
                <th>状态</th>
                <th>说明</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($routeAudit as $item): ?>
                <tr>
                    <td data-label="方法"><span class="status-pill soft"><?= e($item['method']) ?></span></td>
                    <td data-label="路径"><code><?= e($item['path']) ?></code></td>
                    <td data-label="目标"><?= e($item['target']) ?></td>
                    <td data-label="状态"><span class="status-pill <?= !empty($item['ok']) ? 'ok' : 'bad' ?>"><?= !empty($item['ok']) ? '正常' : '异常' ?></span></td>
                    <td data-label="说明"><?= e($item['hint']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Form Submit</p>
            <h2>表单提交检查</h2>
            <p>检查页面里的表单 action 是否能命中实际路由。保存配置、上传文件、删除记录、测试第三方存储时，如果按钮点了没反应，优先看这一栏。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr>
                <th>页面文件</th>
                <th>方法</th>
                <th>提交路径</th>
                <th>状态</th>
                <th>提示</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!$formAudit): ?>
                <tr><td class="responsive-table-span" colspan="5">没有扫描到需要检查的固定表单。</td></tr>
            <?php endif; ?>
            <?php foreach ($formAudit as $item): ?>
                <tr>
                    <td data-label="页面文件"><code><?= e($item['file']) ?></code></td>
                    <td data-label="方法"><span class="status-pill soft"><?= e($item['method']) ?></span></td>
                    <td data-label="提交路径"><code><?= e($item['path']) ?></code></td>
                    <td data-label="状态"><span class="status-pill <?= !empty($item['ok']) ? 'ok' : 'bad' ?>"><?= !empty($item['ok']) ? '正常' : '异常' ?></span></td>
                    <td data-label="提示"><?= e($item['hint']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="admin-files-layout">
    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Database</p>
                <h2>数据表检查</h2>
            </div>
        </div>
        <?php if ($missingTableCount > 0): ?>
            <div class="audit-repair-strip">
                <span>发现 <?= e($missingTableCount) ?> 张数据表缺失，可直接执行自动修复。</span>
                <form method="post" action="<?= url('admin/maintenance/repair-schema') ?>" class="confirm-form admin-inline-repair-form" data-confirm="将自动补齐缺失数据表并执行字段/索引升级，建议已先导出数据库备份。确认继续吗？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="return_to" value="schema-audit">
                    <button class="btn btn-primary btn-sm" type="submit" data-icon="wrench">立即修复</button>
                </form>
            </div>
        <?php endif; ?>
        <div class="audit-list">
            <?php foreach ($tableChecks as $item): ?>
                <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e($item['label']) ?></b>
                        <small><?= e($item['table']) ?> · <?= e($item['hint']) ?></small>
                    </span>
                    <strong><?= !empty($item['ok']) ? e(number_format((int) $item['count'])) : '缺失' ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Runtime</p>
                <h2>目录权限</h2>
            </div>
        </div>
        <div class="audit-list">
            <?php foreach ($directoryChecks as $item): ?>
                <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e($item['label']) ?></b>
                        <small><?= e($item['path']) ?></small>
                    </span>
                    <strong><?= e($item['hint']) ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="admin-files-layout">
    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Mobile UI</p>
                <h2>移动端表格检查</h2>
                <p>检查含表格页面是否有响应式表格或卡片容器，减少手机端横向溢出和按钮点不到的问题。</p>
            </div>
        </div>
        <div class="audit-list">
            <?php foreach ($tableAudit as $item): ?>
                <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e($item['file']) ?></b>
                        <small><?= e($item['hint']) ?></small>
                    </span>
                    <strong><?= e((int) $item['tables']) ?> 张表</strong>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Assets</p>
                <h2>前端资源检查</h2>
                <p>检查布局文件引用的 CSS/JS 是否存在。资源缺失会导致图标不显示、菜单点不开或页面样式错乱。</p>
            </div>
        </div>
        <div class="audit-list">
            <?php foreach ($assetChecks as $item): ?>
                <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e($item['asset']) ?></b>
                        <small><?= e($item['file']) ?> · <?= e($item['hint']) ?></small>
                    </span>
                    <strong><?= e($formatSize(isset($item['size']) ? $item['size'] : 0)) ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Services</p>
            <h2>关键服务检查</h2>
            <p>这些配置直接影响上传、第三方存储、支付、邮件通知和服务器监控采集。监控采集链接可直接复制给计划任务定时访问。</p>
        </div>
    </div>
    <div class="audit-list service-audit-list">
        <?php foreach ($serviceChecks as $item): ?>
            <div class="<?= !empty($item['ok']) ? 'ok' : 'bad' ?>">
                <span>
                    <b><?= e($item['label']) ?></b>
                    <small><?= !empty($item['stage']) ? e($item['stage']) . ' · ' : '' ?><?= e($item['hint']) ?></small>
                </span>
                <code><?= e((string) $item['value']) ?></code>
                <?php if (!empty($item['action_url'])): ?>
                    <a class="btn btn-ghost btn-sm" href="<?= url($item['action_url']) ?>" data-icon="arrow-up-right"><?= e($item['action_label']) ?></a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>
