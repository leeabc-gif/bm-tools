<?php
$settings = isset($settings) ? $settings : [];
$filters = isset($filters) ? $filters : ['status' => '', 'keyword' => ''];
$accessLogs = isset($accessLogs) ? $accessLogs : [];
$domainDiagnostic = flash('subsite_domain_diagnostic', null);
$service = isset($service) ? $service : new \App\Services\SubsiteService();
$domainConfig = $service->domainConfigSummary();
$getSetting = function ($key, $default = '') use ($settings) {
    return isset($settings[$key]) ? $settings[$key] : $default;
};
$statusOptions = [
    '' => '全部状态',
    'pending' => '待审核',
    'active' => '已启用',
    'suspended' => '已停用',
    'rejected' => '已拒绝',
];
$statusClass = function ($status) {
    if ($status === 'active') return 'ok';
    if ($status === 'pending') return 'soft';
    if ($status === 'suspended' || $status === 'rejected') return 'bad';
    return 'muted';
};
$diagnosticSummary = function (array $site) use ($service) {
    $diagnostic = $service->decodeDomainDiagnostic($site);
    if (!$diagnostic || empty($diagnostic['checks']) || !is_array($diagnostic['checks'])) {
        return null;
    }
    $checks = $diagnostic['checks'];
    $total = count($checks);
    $passed = 0;
    $firstIssue = '';
    foreach ($checks as $check) {
        $status = isset($check['status']) ? (string) $check['status'] : '';
        if ($status === 'ok' || $status === 'soft') {
            $passed++;
        } elseif ($firstIssue === '') {
            $firstIssue = isset($check['message']) ? (string) $check['message'] : '';
        }
    }
    return [
        'tone' => !empty($diagnostic['ok']) ? 'ok' : ($firstIssue === '' ? 'soft' : 'warn'),
        'passed' => $passed,
        'total' => max(1, $total),
        'time' => isset($site['domain_checked_at']) && $site['domain_checked_at'] ? $site['domain_checked_at'] : (isset($diagnostic['checked_at']) ? $diagnostic['checked_at'] : ''),
        'message' => $firstIssue !== '' ? text_limit($firstIssue, 90, '...') : '域名接入状态正常。',
    ];
};
?>

<section class="admin-page-head glass subsite-admin-head">
    <div>
        <p class="eyebrow">Subsite</p>
        <h1>分站管理</h1>
        <p>管理用户独立资源站、平台域名后缀、自有域名绑定和审核状态。适合做会员权益、代理分发和个人品牌页。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/packages') ?>" data-icon="package">套餐权益</a>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>分站总数</span><b><?= e($stats['total']) ?></b><small>全站累计</small></article>
    <article class="ops-metric-card glass ok"><span>已启用</span><b><?= e($stats['active']) ?></b><small>可公开访问</small></article>
    <article class="ops-metric-card glass"><span>待审核</span><b><?= e($stats['pending']) ?></b><small>需要运营处理</small></article>
    <article class="ops-metric-card glass"><span>累计访问</span><b><?= e($stats['views']) ?></b><small>全部分站访问量</small></article>
</section>

<?php if ($domainDiagnostic): ?>
    <section class="subsite-diagnostic-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Domain Check</p>
                <h2>域名接入检测结果</h2>
                <p>
                    <?= e(isset($domainDiagnostic['site']['name']) ? $domainDiagnostic['site']['name'] : '分站') ?>
                    · <?= e(isset($domainDiagnostic['checked_at']) ? $domainDiagnostic['checked_at'] : now()) ?>
                </p>
            </div>
            <?php if (!empty($domainDiagnostic['public_url'])): ?>
                <a class="btn btn-ghost" href="<?= e($domainDiagnostic['public_url']) ?>" target="_blank" data-icon="external-link">打开分站</a>
            <?php endif; ?>
        </div>
        <div class="subsite-diagnostic-grid">
            <?php foreach ((array) (isset($domainDiagnostic['checks']) ? $domainDiagnostic['checks'] : []) as $check): ?>
                <article class="subsite-diagnostic-item <?= e(isset($check['status']) ? $check['status'] : 'soft') ?>">
                    <span><?= e(isset($check['label']) ? $check['label'] : '检测项') ?></span>
                    <p><?= e(isset($check['message']) ? $check['message'] : '') ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<section class="subsite-admin-grid">
    <article class="form-section glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">运营配置</p>
                <h2>分站设置</h2>
                <p>域名后缀一行一个，例如 users.example.com，用户分站会生成 user.users.example.com。</p>
            </div>
        </div>
        <form method="post" action="<?= url('admin/subsites/settings') ?>" class="admin-package-form">
            <?= csrf_field() ?>
            <div class="package-permission-grid compact">
                <label class="inline-check"><input type="checkbox" name="subsite_enabled" <?= $getSetting('subsite_enabled', '1') === '1' ? 'checked' : '' ?>> 开放分站</label>
                <label class="inline-check"><input type="checkbox" name="subsite_custom_domain_enabled" <?= $getSetting('subsite_custom_domain_enabled', '1') === '1' ? 'checked' : '' ?>> 允许自有域名</label>
                <label class="inline-check"><input type="checkbox" name="subsite_requires_review" <?= $getSetting('subsite_requires_review', '0') === '1' ? 'checked' : '' ?>> 创建后需审核</label>
            </div>
            <label>默认分站数量<input name="subsite_default_limit" type="number" min="0" max="100" value="<?= e($getSetting('subsite_default_limit', '1')) ?>"></label>
            <label>分站域名后缀<textarea name="subsite_domain_suffixes" rows="4" placeholder="users.example.com"><?= e($getSetting('subsite_domain_suffixes', '')) ?></textarea></label>
            <label>分站 CNAME 接入目标<input name="subsite_cname_target" value="<?= e($getSetting('subsite_cname_target', '')) ?>" placeholder="<?= e($domainConfig['default_suffix'] ?: 'subsite.example.com') ?>"><small>自有域名建议 CNAME 到这个目标；留空时默认使用第一个分站域名后缀。</small></label>
            <label>HTTPS 策略<select name="subsite_https_mode">
                <?php foreach (['auto' => '自动识别', 'force' => '强制 HTTPS', 'off' => '不强制'] as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $getSetting('subsite_https_mode', 'auto') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select></label>
            <label>保留标识<textarea name="subsite_reserved_slugs" rows="3" placeholder="admin,api,www"><?= e($getSetting('subsite_reserved_slugs', 'admin,api,www,cdn,static,status,login,register')) ?></textarea></label>
            <div class="form-actions">
                <button class="btn btn-primary full" type="submit" data-icon="save">保存设置</button>
            </div>
        </form>
        <div class="subsite-domain-admin-guide">
            <strong>当前接入指引</strong>
            <span>平台后缀：<?= e($domainConfig['suffixes'] ? implode(' / ', $domainConfig['suffixes']) : '未配置') ?></span>
            <span>泛解析：<?= e($domainConfig['wildcard_hint'] ?: '先填写分站域名后缀和 CNAME 接入目标') ?></span>
            <span>自有域名：<?= e($domainConfig['custom_domain_hint'] ?: '用户自有域名建议 CNAME 到接入目标') ?></span>
            <span>检测顺序：平台域名 DNS → 自有域名解析 → TXT 所有权 → HTTP/HTTPS 访问链路。</span>
        </div>
    </article>

    <article class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">筛选查询</p>
                <h2>分站列表</h2>
            </div>
        </div>
        <form method="get" action="<?= url('admin/subsites') ?>" class="url-fetch admin-repository-filter">
            <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索名称、标识、域名、用户">
            <select name="status">
                <?php foreach ($statusOptions as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $filters['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-ghost" type="submit" data-icon="search">搜索</button>
            <a class="btn btn-ghost" href="<?= url('admin/subsites') ?>" data-icon="rotate-ccw">重置</a>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>分站</th>
                    <th>用户</th>
                    <th>域名</th>
                    <th>访问</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($subsites as $site): ?>
                    <?php $publicUrl = $service->publicUrlFor($site); ?>
                    <?php $checkSummary = $diagnosticSummary($site); ?>
                    <tr>
                        <td data-label="ID"><?= e($site['id']) ?></td>
                        <td data-label="分站">
                            <b><?= e($site['name']) ?></b><br>
                            <small><?= e($site['slug']) ?> · <?= e($site['created_at']) ?></small>
                        </td>
                        <td data-label="用户">
                            <?= e($site['username'] ?: '-') ?><br>
                            <small><?= e($site['email'] ?: '') ?></small>
                        </td>
                        <td data-label="域名">
                            <a href="<?= e($publicUrl) ?>" target="_blank"><code><?= e($site['platform_domain']) ?></code></a>
                            <?php if ($site['custom_domain']): ?><br><code><?= e($site['custom_domain']) ?> · <?= e($service->domainStatusLabel($site['custom_domain_status'])) ?></code><?php endif; ?>
                            <?php if ($site['verification_token']): ?><br><small>TXT: <?= e($site['verification_token']) ?></small><?php endif; ?>
                        </td>
                        <td data-label="访问"><?= e((int) $site['view_count']) ?><br><small><?= e($site['last_viewed_at'] ?: '暂无访问') ?></small></td>
                        <td data-label="状态">
                            <span class="status-pill <?= e($statusClass($site['status'])) ?>"><?= e($service->statusLabel($site['status'])) ?></span>
                            <?php if ($site['admin_remark']): ?><br><small><?= e($site['admin_remark']) ?></small><?php endif; ?>
                            <?php if ($checkSummary): ?>
                                <div class="subsite-check-mini <?= e($checkSummary['tone']) ?>">
                                    <b>检测<?= $checkSummary['time'] ? ' · ' . e($checkSummary['time']) : '' ?></b>
                                    <span><?= e($checkSummary['passed']) ?>/<?= e($checkSummary['total']) ?> 步通过 · <?= e($checkSummary['message']) ?></span>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td data-label="操作">
                            <form method="post" action="<?= url('admin/subsites/status') ?>" class="admin-subsite-action-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <select name="status">
                                    <?php foreach (['pending' => '待审核', 'active' => '启用', 'suspended' => '停用', 'rejected' => '拒绝'] as $value => $label): ?>
                                        <option value="<?= e($value) ?>" <?= $site['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="custom_domain_status">
                                    <?php foreach (['none' => '未绑定', 'pending' => '待验证', 'verified' => '已验证', 'failed' => '验证失败'] as $value => $label): ?>
                                        <option value="<?= e($value) ?>" <?= $site['custom_domain_status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input name="admin_remark" value="<?= e($site['admin_remark']) ?>" placeholder="备注">
                                <button class="btn btn-primary btn-sm" type="submit" data-icon="save">保存</button>
                            </form>
                            <form method="post" action="<?= url('admin/subsites/check') ?>" class="admin-subsite-check-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <button class="btn btn-ghost btn-sm" type="submit" data-icon="radar">检测接入</button>
                            </form>
                            <form method="post" action="<?= url('admin/subsites/delete') ?>" class="confirm-form" data-confirm="确认删除该分站和访问日志吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <button class="btn btn-ghost btn-sm" type="submit" data-icon="trash-2">删除</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$subsites): ?>
                    <tr><td colspan="7" class="responsive-table-span">暂无分站记录。</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </article>
</section>

<section class="table-card glass subsite-access-card">
    <div class="section-head">
        <div>
            <p class="eyebrow">Access Logs</p>
            <h2>最近分站访问</h2>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>分站</th>
                <th>用户</th>
                <th>访问域名</th>
                <th>路径</th>
                <th>IP</th>
                <th>时间</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($accessLogs as $log): ?>
                <tr>
                    <td data-label="分站"><?= e($log['subsite_name'] ?: '-') ?></td>
                    <td data-label="用户"><?= e($log['username'] ?: '-') ?></td>
                    <td data-label="访问域名"><code><?= e($log['host']) ?></code></td>
                    <td data-label="路径"><small><?= e($log['path']) ?></small></td>
                    <td data-label="IP"><?= e($log['ip']) ?></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$accessLogs): ?>
                <tr><td colspan="6" class="responsive-table-span">暂无访问记录。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
