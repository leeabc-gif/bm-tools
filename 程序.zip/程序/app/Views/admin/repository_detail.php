<?php
$accessLabels = [
    'public' => '公开访问',
    'password' => '密码访问',
    'private' => '私密关闭',
];
$logLabels = [
    'view' => '访问',
    'download' => '下载',
    'auth_success' => '密码通过',
    'auth_fail' => '密码错误',
    'blocked' => '限制拦截',
    'expired' => '过期访问',
];
$stateClass = empty($repo['admin_status']) ? 'bad' : (empty($repo['status']) || (!empty($repo['expire_at']) && strtotime($repo['expire_at']) < time()) ? 'muted' : 'ok');
$stateText = empty($repo['admin_status']) ? '平台下架' : (empty($repo['status']) ? '用户关闭' : ((!empty($repo['expire_at']) && strtotime($repo['expire_at']) < time()) ? '已过期' : '正常开放'));
?>

<section class="admin-page-head glass admin-repository-detail-head">
    <div>
        <p class="eyebrow">仓库详情</p>
        <h1><?= e($repo['title']) ?></h1>
        <p><?= e($repo['description'] ?: '这个仓库暂未填写介绍。') ?></p>
    </div>
    <div class="admin-repository-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/repositories') ?>" data-icon="arrow-left">返回列表</a>
        <a class="btn btn-primary" href="<?= e($publicLink) ?>" target="_blank" data-icon="external-link">打开公开页</a>
    </div>
</section>

<section class="ops-metric-grid admin-repository-detail-metrics">
    <article class="ops-metric-card glass"><span>状态</span><b><?= e($stateText) ?></b><small><?= e(isset($accessLabels[$repo['access_type']]) ? $accessLabels[$repo['access_type']] : $repo['access_type']) ?></small></article>
    <article class="ops-metric-card glass ok"><span>公开文件</span><b><?= e($stats['public_items']) ?></b><small>总文件 <?= e($stats['items']) ?> 个</small></article>
    <article class="ops-metric-card glass"><span>访问/下载</span><b><?= e($repo['view_count']) ?> / <?= e($repo['download_count']) ?></b><small>今日 <?= e($stats['today_views']) ?> / <?= e($stats['today_downloads']) ?></small></article>
    <article class="ops-metric-card glass"><span>最近访问</span><b><?= e($repo['latest_log_at'] ? date('m-d H:i', strtotime($repo['latest_log_at'])) : '暂无') ?></b><small><?= e($repo['latest_log_at'] ?: '还没有访客记录') ?></small></article>
</section>

<section class="admin-repository-detail-grid">
    <article class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">发布状态</p>
                <h2>发布检查</h2>
            </div>
            <span class="status-pill <?= !empty($checklist['ready']) ? 'ok' : 'bad' ?>"><?= !empty($checklist['ready']) ? '可访问' : '需处理' ?></span>
        </div>
        <div class="repository-check-grid admin-repository-check-grid">
            <?php foreach ($checklist['items'] as $item): ?>
                <div class="repository-check-item <?= !empty($item['ok']) ? 'ok' : 'warn' ?>">
                    <span><i data-lucide="<?= !empty($item['ok']) ? 'check' : 'alert-triangle' ?>"></i></span>
                    <div>
                        <b><?= e($item['label']) ?></b>
                        <small><?= e($item['detail']) ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">仓库信息</p>
                <h2>基础信息</h2>
            </div>
            <span class="status-pill <?= e($stateClass) ?>"><?= e($stateText) ?></span>
        </div>
        <div class="admin-repository-info-list">
            <div><span>仓库 ID</span><b><?= e($repo['id']) ?></b></div>
            <div><span>创建用户</span><b><?= e(($repo['nickname'] ?: $repo['username']) ?: '-') ?></b><small><?= e($repo['email'] ?: '-') ?></small></div>
            <div><span>公开链接</span><b><?= e($publicLink) ?></b></div>
            <div><span>到期时间</span><b><?= e($repo['expire_at'] ?: '永久') ?></b></div>
            <div><span>限制</span><b>访问 <?= (int) $repo['max_views'] > 0 ? e($repo['max_views']) : '不限' ?> / 下载 <?= (int) $repo['max_downloads'] > 0 ? e($repo['max_downloads']) : '不限' ?></b><small>单 IP 每日访问 <?= (int) $repo['ip_daily_view_limit'] > 0 ? e($repo['ip_daily_view_limit']) : '不限' ?>，下载 <?= (int) $repo['ip_daily_download_limit'] > 0 ? e($repo['ip_daily_download_limit']) : '不限' ?></small></div>
            <?php if (!empty($repo['admin_remark'])): ?>
                <div><span>平台备注</span><b><?= e($repo['admin_remark']) ?></b></div>
            <?php endif; ?>
        </div>
    </article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Files</p>
            <h2>仓库文件</h2>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>文件</th><th>可见性</th><th>大小</th><th>排序</th><th>说明</th><th>加入时间</th></tr>
            </thead>
            <tbody>
            <?php if (!$files): ?>
                <tr><td colspan="6" class="responsive-table-span">这个仓库还没有加入文件。</td></tr>
            <?php endif; ?>
            <?php foreach ($files as $file): ?>
                <tr>
                    <td data-label="文件">
                        <b><?= e($file['original_name'] ?: ('文件 #' . $file['file_id'])) ?></b>
                        <?php if (!empty($file['file_url'])): ?><br><a href="<?= e(public_url($file['file_url'])) ?>" target="_blank"><small>打开文件</small></a><?php endif; ?>
                    </td>
                    <td data-label="可见性"><span class="status-pill <?= $file['visibility'] === 'public' ? 'ok' : 'soft' ?>"><?= $file['visibility'] === 'public' ? '公开' : '私密' ?></span></td>
                    <td data-label="大小"><?= e(format_bytes((float) $file['file_size'])) ?></td>
                    <td data-label="排序"><?= e((int) $file['sort_order']) ?></td>
                    <td data-label="说明"><?= e($file['note'] ?: '-') ?></td>
                    <td data-label="加入时间"><?= e($file['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Logs</p>
            <h2>最近日志</h2>
        </div>
        <form method="post" action="<?= url('admin/repositories/logs/clear') ?>" class="confirm-form admin-repository-log-clear" data-confirm="确认清空这个仓库的全部访问和下载日志吗？">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
            <button class="btn btn-ghost" type="submit" data-icon="eraser">清空日志</button>
        </form>
    </div>
    <form method="get" action="<?= url('admin/repositories/detail') ?>" class="url-fetch repository-log-filter">
        <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
        <input name="keyword" value="<?= e($logFilters['keyword']) ?>" placeholder="搜索文件名、IP 或来源">
        <select name="action">
            <option value="">全部行为</option>
            <?php foreach ($logLabels as $value => $label): ?>
                <option value="<?= e($value) ?>" <?= $logFilters['action'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <input name="date_from" type="date" value="<?= e($logFilters['date_from']) ?>">
        <input name="date_to" type="date" value="<?= e($logFilters['date_to']) ?>">
        <button class="btn btn-ghost" type="submit" data-icon="filter">筛选</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>行为</th><th>文件</th><th>IP</th><th>来源</th><th>User-Agent</th><th>时间</th></tr>
            </thead>
            <tbody>
            <?php if (!$logs): ?>
                <tr><td colspan="6" class="responsive-table-span">暂无符合条件的日志。</td></tr>
            <?php endif; ?>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td data-label="行为"><span class="repository-log-action"><?= e(isset($logLabels[$log['action']]) ? $logLabels[$log['action']] : $log['action']) ?></span></td>
                    <td data-label="文件"><?= e($log['original_name'] ?: '-') ?></td>
                    <td data-label="IP"><?= e($log['ip']) ?></td>
                    <td data-label="来源"><?= e($log['referer'] ?: '-') ?></td>
                    <td data-label="User-Agent"><small><?= e($log['user_agent'] ?: '-') ?></small></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
