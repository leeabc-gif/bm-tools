<?php
$filters = isset($filters) ? $filters : ['keyword' => '', 'method' => '', 'success' => '', 'app_id' => 0, 'date_start' => '', 'date_end' => ''];
$stats = isset($stats) ? $stats : ['total' => 0, 'today' => 0, 'success' => 0, 'failed' => 0, 'filtered_total' => 0];
$endpointStats = isset($endpointStats) ? $endpointStats : [];
$apiApps = isset($apiApps) && is_array($apiApps) ? $apiApps : [];
$appStats = isset($appStats) && is_array($appStats) ? $appStats : [];
$failedAppStats = isset($failedAppStats) && is_array($failedAppStats) ? $failedAppStats : [];
$methods = isset($methods) ? $methods : ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">Open API</p>
        <h1>API 日志</h1>
        <p>用于排查开放接口上传、删除、查询配额等请求是否正常。第三方调用失败时，先看状态码、接口路径、返回信息和请求 IP。</p>
    </div>
    <a class="btn btn-primary" href="<?= url('api/console') ?>" target="_blank" data-icon="terminal">前台 API 控制台</a>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>请求总数</span><b><?= e(number_format($stats['total'])) ?></b><small>开放接口累计记录</small></article>
    <article class="ops-metric-card glass ok"><span>成功请求</span><b><?= e(number_format($stats['success'])) ?></b><small>状态为成功的调用</small></article>
    <article class="ops-metric-card glass warn"><span>失败请求</span><b><?= e(number_format($stats['failed'])) ?></b><small>需要重点排查</small></article>
    <article class="ops-metric-card glass"><span>今日请求</span><b><?= e(number_format($stats['today'])) ?></b><small>当前筛选 <?= e(number_format($stats['filtered_total'])) ?> 条</small></article>
</section>

<section class="admin-files-layout">
    <article class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">Filter</p>
                <h2>日志筛选</h2>
            </div>
        </div>
        <form method="get" action="<?= url('admin/api-logs') ?>" class="admin-filter-grid">
            <label>
                <span>关键词</span>
                <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="接口 / IP / 用户 / 返回信息">
            </label>
            <label>
                <span>请求方法</span>
                <select name="method">
                    <option value="">全部方法</option>
                    <?php foreach ($methods as $method): ?>
                        <option value="<?= e($method) ?>" <?= $filters['method'] === $method ? 'selected' : '' ?>><?= e($method) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>调用结果</span>
                <select name="success">
                    <option value="">全部结果</option>
                    <option value="1" <?= $filters['success'] === '1' ? 'selected' : '' ?>>成功</option>
                    <option value="0" <?= $filters['success'] === '0' ? 'selected' : '' ?>>失败</option>
                </select>
            </label>
            <label>
                <span>应用 Token</span>
                <select name="app_id">
                    <option value="0">全部应用</option>
                    <?php foreach ($apiApps as $app): ?>
                        <option value="<?= e($app['id']) ?>" <?= (int) $filters['app_id'] === (int) $app['id'] ? 'selected' : '' ?>>
                            <?= e($app['name']) ?><?= empty($app['status']) ? '（停用）' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>开始日期</span>
                <input type="date" name="date_start" value="<?= e($filters['date_start']) ?>">
            </label>
            <label>
                <span>结束日期</span>
                <input type="date" name="date_end" value="<?= e($filters['date_end']) ?>">
            </label>
            <div class="filter-actions">
                <button class="btn btn-primary" type="submit" data-icon="search">查询</button>
                <a class="btn btn-ghost" href="<?= url('admin/api-logs') ?>" data-icon="rotate-ccw">重置</a>
            </div>
        </form>
    </article>

    <aside class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Endpoint</p>
                <h2>高频接口</h2>
            </div>
        </div>
        <div class="admin-rank-list">
            <?php foreach ($endpointStats as $item): ?>
                <div>
                    <span>
                        <b><?= e($item['endpoint']) ?></b>
                        <small>失败 <?= e(number_format((int) $item['failed'])) ?> 次</small>
                    </span>
                    <strong><?= e(number_format((int) $item['total'])) ?></strong>
                </div>
            <?php endforeach; ?>
            <?php if (!$endpointStats): ?>
                <p class="empty-table">暂无 API 调用统计。</p>
            <?php endif; ?>
        </div>
    </aside>
</section>

<section class="admin-files-layout api-admin-insight-grid">
    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Applications</p>
                <h2>调用最多应用</h2>
            </div>
        </div>
        <div class="admin-rank-list api-admin-rank">
            <?php foreach ($appStats as $item): ?>
                <?php $total = max(1, (int) $item['total']); $failed = (int) $item['failed']; ?>
                <div>
                    <span>
                        <b><?= e($item['api_app_name']) ?></b>
                        <small>失败 <?= e(number_format($failed)) ?> 次 · 最近 <?= e($item['last_called_at'] ?: '-') ?></small>
                        <i><em style="width:<?= e(max(3, min(100, round((($total - $failed) / $total) * 100)))) ?>%"></em></i>
                    </span>
                    <strong><?= e(number_format($total)) ?></strong>
                </div>
            <?php endforeach; ?>
            <?php if (!$appStats): ?>
                <p class="empty-table">暂无应用级调用统计。</p>
            <?php endif; ?>
        </div>
    </article>

    <article class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Failures</p>
                <h2>失败最多应用</h2>
            </div>
        </div>
        <div class="admin-rank-list api-admin-rank">
            <?php foreach ($failedAppStats as $item): ?>
                <div>
                    <span>
                        <b><?= e($item['api_app_name']) ?></b>
                        <small>最后失败 <?= e($item['last_failed_at'] ?: '-') ?></small>
                    </span>
                    <strong><?= e(number_format((int) $item['failed'])) ?></strong>
                </div>
            <?php endforeach; ?>
            <?php if (!$failedAppStats): ?>
                <p class="empty-table">暂无应用失败记录。</p>
            <?php endif; ?>
        </div>
    </article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Request Log</p>
            <h2>请求明细</h2>
            <p>最多展示最新 300 条记录，失败记录会以醒目的状态展示。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>用户</th>
                <th>应用</th>
                <th>接口</th>
                <th>方法</th>
                <th>IP</th>
                <th>状态码</th>
                <th>结果</th>
                <th>信息</th>
                <th>时间</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td data-label="ID">#<?= e($log['id']) ?></td>
                    <td data-label="用户"><b><?= e($log['username'] ?: '游客/未知') ?></b><small><?= e($log['email'] ?: '-') ?></small></td>
                    <td data-label="应用"><?= !empty($log['api_app_name']) ? e($log['api_app_name']) : '总 Token' ?></td>
                    <td data-label="接口"><code><?= e($log['endpoint']) ?></code></td>
                    <td data-label="方法"><span class="status-pill soft"><?= e($log['method']) ?></span></td>
                    <td data-label="IP"><?= e($log['ip']) ?></td>
                    <td data-label="状态码"><?= e($log['status_code']) ?></td>
                    <td data-label="结果"><span class="status-pill <?= $log['is_success'] ? 'ok' : 'bad' ?>"><?= $log['is_success'] ? '成功' : '失败' ?></span></td>
                    <td data-label="信息"><?= e($log['message'] ?: '-') ?></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?>
                <tr><td colspan="10" class="empty-table responsive-table-span">暂无符合条件的 API 日志。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
