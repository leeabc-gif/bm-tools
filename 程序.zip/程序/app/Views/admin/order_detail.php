<?php
$order = isset($order) && is_array($order) ? $order : ['order_no' => '', 'type' => 'recharge', 'status' => 'pending', 'amount' => 0, 'pay_amount' => 0, 'payment_method' => '', 'trade_no' => '', 'paid_at' => '', 'created_at' => '', 'updated_at' => '', 'remark' => '', 'user_id' => 0, 'username' => '', 'nickname' => '', 'email' => '', 'balance' => '0.00', 'user_created_at' => '', 'package_name' => '', 'package_price' => null];
$recharge = isset($recharge) && is_array($recharge) ? $recharge : null;
$balanceLogs = isset($balanceLogs) && is_array($balanceLogs) ? $balanceLogs : [];
$methodNames = ['manual' => '人工充值', 'alipay' => '支付宝', 'wechat' => '微信支付', 'epay' => '易支付', 'balance' => '余额', 'card_code' => '卡密'];
$statusTips = [
    'pending' => '待支付或待人工处理，通常需要继续支付、人工审核或后台补单。',
    'paid' => '订单已完成，对应权益或余额应该已经到账。',
    'closed' => '订单已关闭，通常为放弃支付或后台取消。',
    'refunded' => '订单已退款，需结合余额流水或人工售后记录核对。',
];
?>
<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">订单详情</p>
        <h1><?= e($order['order_no']) ?></h1>
        <p>查看该订单的用户、套餐、支付、充值和余额流水信息，便于补单、售后和财务核对。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/orders') ?>" data-icon="arrow-left">返回订单</a>
</section>

<section class="order-detail-grid">
    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">订单信息</p>
            <h2>订单信息</h2>
        </div>
        <div class="meta-table">
            <span>订单号</span><b><?= e($order['order_no']) ?></b>
            <span>订单类型</span><b><?= e($order['type'] === 'recharge' ? '余额充值' : '套餐购买') ?></b>
            <span>订单状态</span><b><?= e($order['status']) ?></b>
            <span>状态说明</span><b><?= e(isset($statusTips[$order['status']]) ? $statusTips[$order['status']] : '请结合订单备注与关联记录判断。') ?></b>
            <span>原价金额</span><b>¥<?= e($order['amount']) ?></b>
            <span>实付金额</span><b>¥<?= e($order['pay_amount']) ?></b>
            <span>支付方式</span><b><?= e(isset($methodNames[$order['payment_method']]) ? $methodNames[$order['payment_method']] : ($order['payment_method'] ?: '-')) ?></b>
            <span>交易号</span><b><?= e($order['trade_no'] ?: '-') ?></b>
            <span>支付时间</span><b><?= e($order['paid_at'] ?: '-') ?></b>
            <span>创建时间</span><b><?= e($order['created_at']) ?></b>
            <span>更新时间</span><b><?= e($order['updated_at']) ?></b>
            <span>备注</span><b><?= e($order['remark'] ?: '-') ?></b>
        </div>
    </article>

    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">用户信息</p>
            <h2>用户信息</h2>
        </div>
        <div class="meta-table">
            <span>用户 ID</span><b><?= e($order['user_id']) ?></b>
            <span>用户名</span><b><?= e($order['username'] ?: '-') ?></b>
            <span>昵称</span><b><?= e($order['nickname'] ?: '-') ?></b>
            <span>邮箱</span><b><?= e($order['email'] ?: '-') ?></b>
            <span>账户余额</span><b>¥<?= e($order['balance'] ?: '0.00') ?></b>
            <span>注册时间</span><b><?= e($order['user_created_at'] ?: '-') ?></b>
        </div>
    </article>
</section>

<section class="order-detail-grid">
    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">套餐信息</p>
            <h2>套餐 / 充值信息</h2>
        </div>
        <div class="meta-table">
            <span>套餐名称</span><b><?= e($order['package_name'] ?: '-') ?></b>
            <span>套餐价格</span><b><?= $order['package_price'] !== null ? '¥' . e($order['package_price']) : '-' ?></b>
            <?php if ($order['type'] === 'package'): ?>
                <span>交付结果</span><b><?= $order['status'] === 'paid' ? '套餐应已生效' : '待支付后自动开通' ?></b>
            <?php endif; ?>
            <?php if ($recharge): ?>
                <span>充值状态</span><b><?= e($recharge['status']) ?></b>
                <span>充值金额</span><b>¥<?= e($recharge['amount']) ?></b>
                <span>充值方式</span><b><?= e(isset($methodNames[$recharge['payment_method']]) ? $methodNames[$recharge['payment_method']] : $recharge['payment_method']) ?></b>
                <span>审核备注</span><b><?= e($recharge['audit_remark'] ?: '-') ?></b>
                <span>充值时间</span><b><?= e($recharge['paid_at'] ?: '-') ?></b>
            <?php endif; ?>
        </div>
    </article>

    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">处理记录</p>
            <h2>关联余额流水</h2>
        </div>
        <div class="admin-mini-table order-log-table">
            <div class="admin-mini-table__head"><span>类型</span><span>金额</span><span>变动前</span><span>变动后</span><span>说明</span><span>时间</span></div>
            <?php if (!$balanceLogs): ?>
                <div class="admin-empty">暂无关联余额流水。</div>
            <?php endif; ?>
            <?php foreach ($balanceLogs as $log): ?>
                <div class="admin-mini-table__row">
                    <span><?= e($log['type']) ?></span>
                    <span>¥<?= e($log['amount']) ?></span>
                    <span>¥<?= e($log['balance_before']) ?></span>
                    <span>¥<?= e($log['balance_after']) ?></span>
                    <span><?= e($log['remark'] ?: '-') ?></span>
                    <span><?= e($log['created_at']) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</section>
