<?php
$users = isset($users) && is_array($users) ? $users : [];
$packages = isset($packages) && is_array($packages) ? $packages : [];
$filters = isset($filters) ? $filters : ['keyword' => '', 'role' => '', 'status' => '', 'package_id' => 0];
$userStats = isset($userStats) ? $userStats : ['total' => count($users), 'enabled' => 0, 'disabled' => 0, 'admins' => 0, 'today' => 0, 'storage_used' => 0, 'storage_total' => 0];
$currentAdminId = \App\Core\Auth::id();
$datetimeValue = function ($value) {
    $value = trim((string) $value);
    return $value === '' ? '' : str_replace(' ', 'T', substr($value, 0, 16));
};
$packageName = function ($id) use ($packages) {
    foreach ($packages as $package) {
        if ((int) $package['id'] === (int) $id) {
            return $package['name'];
        }
    }
    return '未绑定套餐';
};
?>

<section class="admin-users-v2">
    <section class="admin-page-head glass">
        <div>
            <p class="eyebrow">User Operations</p>
            <h1>用户管理</h1>
            <p>创建账号、分配角色和套餐、调整容量流量、维护 API 白名单与账号状态。新增和编辑分开处理，避免用户配置挤在一处。</p>
        </div>
        <div class="admin-user-tools">
            <a class="bm-btn bm-btn-primary" href="#create-user" data-icon="user-plus">添加用户</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/users') ?>" data-icon="rotate-ccw">重置筛选</a>
        </div>
    </section>

    <form class="admin-user-filter glass" method="get" action="<?= url('admin/users') ?>">
        <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索用户名 / 昵称 / 邮箱">
        <select name="role">
            <option value="">全部角色</option>
            <option value="user" <?= $filters['role'] === 'user' ? 'selected' : '' ?>>普通用户</option>
            <option value="admin" <?= $filters['role'] === 'admin' ? 'selected' : '' ?>>管理员</option>
        </select>
        <select name="status">
            <option value="">全部状态</option>
            <option value="1" <?= $filters['status'] === '1' ? 'selected' : '' ?>>启用</option>
            <option value="0" <?= $filters['status'] === '0' ? 'selected' : '' ?>>禁用</option>
        </select>
        <select name="package_id">
            <option value="0">全部套餐</option>
            <?php foreach ($packages as $package): ?>
                <option value="<?= e($package['id']) ?>" <?= (int) $filters['package_id'] === (int) $package['id'] ? 'selected' : '' ?>><?= e($package['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="bm-btn bm-btn-primary" type="submit" data-icon="search">筛选</button>
        <a class="bm-btn bm-btn-soft" href="<?= url('admin/users') ?>" data-icon="x">清空</a>
    </form>

    <section class="admin-user-stats">
        <article class="admin-user-stat"><span>用户总数</span><strong><?= e($userStats['total']) ?></strong><small>平台累计账号</small></article>
        <article class="admin-user-stat"><span>今日新增</span><strong><?= e($userStats['today']) ?></strong><small>注册与后台创建</small></article>
        <article class="admin-user-stat"><span>启用账号</span><strong><?= e($userStats['enabled']) ?></strong><small>可正常登录</small></article>
        <article class="admin-user-stat"><span>管理员</span><strong><?= e($userStats['admins']) ?></strong><small>后台权限账号</small></article>
        <article class="admin-user-stat"><span>空间使用</span><strong><?= e(format_bytes($userStats['storage_used'])) ?></strong><small><?= e(format_bytes($userStats['storage_total'])) ?> 配额</small></article>
    </section>

    <section class="admin-user-workbench">
        <aside class="admin-user-create" id="create-user">
            <div class="section-head compact">
                <div>
                    <p class="eyebrow">Create User</p>
                    <h2>添加用户</h2>
                    <p>后台直接开通账号，可指定套餐、角色、状态和 API 白名单。</p>
                </div>
            </div>

            <form method="post" action="<?= url('admin/users/create') ?>" class="admin-user-form-grid">
                <?= csrf_field() ?>
                <label>用户名<input name="username" value="<?= e(old('username')) ?>" required placeholder="3-32 位字母数字下划线"></label>
                <label>昵称<input name="nickname" value="<?= e(old('nickname')) ?>" placeholder="留空默认同用户名"></label>
                <label class="bm-span-all">邮箱<input type="email" name="email" value="<?= e(old('email')) ?>" required placeholder="name@example.com"></label>
                <label>登录密码<input type="password" name="password" required minlength="6" placeholder="至少 6 位"></label>
                <label>初始余额<input type="number" step="0.01" name="balance" value="<?= e(old('balance', '0.00')) ?>"></label>
                <label>角色<select name="role">
                    <option value="user" <?= old('role', 'user') === 'user' ? 'selected' : '' ?>>普通用户</option>
                    <option value="admin" <?= old('role') === 'admin' ? 'selected' : '' ?>>管理员</option>
                </select></label>
                <label>账号状态<select name="status">
                    <option value="1" <?= old('status', '1') !== '0' ? 'selected' : '' ?>>启用</option>
                    <option value="0" <?= old('status') === '0' ? 'selected' : '' ?>>禁用</option>
                </select></label>
                <label class="bm-span-all">套餐<select name="package_id">
                    <option value="0">不绑定套餐</option>
                    <?php foreach ($packages as $package): ?>
                        <option value="<?= e($package['id']) ?>" <?= (int) old('package_id', 0) === (int) $package['id'] ? 'selected' : '' ?>><?= e($package['name']) ?> · <?= e(format_bytes($package['storage_limit'])) ?></option>
                    <?php endforeach; ?>
                </select></label>
                <label>空间配额（字节）<input type="number" name="total_storage" value="<?= e(old('total_storage', '0')) ?>"></label>
                <label>流量配额（字节）<input type="number" name="total_traffic" value="<?= e(old('total_traffic', '0')) ?>"></label>
                <label class="bm-span-all">到期时间<input type="datetime-local" name="package_expire_time" value="<?= e(old('package_expire_time')) ?>"></label>
                <label>图床权限<select name="allow_image_override">
                    <option value="-1" <?= old('allow_image_override', '-1') === '-1' ? 'selected' : '' ?>>继承套餐</option>
                    <option value="1" <?= old('allow_image_override') === '1' ? 'selected' : '' ?>>强制允许</option>
                    <option value="0" <?= old('allow_image_override') === '0' ? 'selected' : '' ?>>强制禁止</option>
                </select></label>
                <label>网盘权限<select name="allow_netdisk_override">
                    <option value="-1" <?= old('allow_netdisk_override', '-1') === '-1' ? 'selected' : '' ?>>继承套餐</option>
                    <option value="1" <?= old('allow_netdisk_override') === '1' ? 'selected' : '' ?>>强制允许</option>
                    <option value="0" <?= old('allow_netdisk_override') === '0' ? 'selected' : '' ?>>强制禁止</option>
                </select></label>
                <label class="bm-check-row bm-span-all"><input type="checkbox" name="sync_package_limits" checked> 同步套餐容量和默认到期时间</label>
                <label class="bm-check-row bm-span-all"><input type="checkbox" name="email_verified" <?= old('email_verified') ? 'checked' : '' ?>> 标记邮箱已验证</label>
                <label class="bm-span-all">API 白名单<textarea name="api_allowed_ips" placeholder="每行一个服务器出口 IP，留空不限制"><?= e(old('api_allowed_ips')) ?></textarea></label>
                <div class="bm-form-actions bm-span-all">
                    <button class="bm-btn bm-btn-primary" type="submit" data-icon="user-plus">创建用户</button>
                </div>
            </form>
        </aside>

        <section class="bm-admin-user-list">
            <?php if (!$users): ?>
                <article class="admin-user-empty">
                    <span class="bm-icon-tile"><i data-lucide="users"></i></span>
                    <h2>没有找到用户</h2>
                    <p>换一个关键词或清空筛选后再试。</p>
                </article>
            <?php endif; ?>

            <?php foreach ($users as $u): ?>
                <?php
                $roleLabel = $u['role'] === 'admin' ? '管理员' : '普通用户';
                $statusLabel = !empty($u['status']) ? '启用' : '禁用';
                $storageTotal = isset($u['total_storage']) ? (int) $u['total_storage'] : 0;
                $storageUsed = isset($u['used_storage']) ? (int) $u['used_storage'] : 0;
                $trafficTotal = isset($u['total_traffic']) ? (int) $u['total_traffic'] : 0;
                $trafficUsed = isset($u['used_traffic']) ? (int) $u['used_traffic'] : 0;
                ?>
                <article class="bm-admin-user-card">
                    <header>
                        <div class="bm-admin-user-title">
                            <span class="bm-icon-tile"><i data-lucide="<?= $u['role'] === 'admin' ? 'shield-check' : 'user' ?>"></i></span>
                            <div>
                                <h2><?= e($u['username']) ?><?= (int) $u['id'] === (int) $currentAdminId ? ' · 当前账号' : '' ?></h2>
                                <p><?= e($u['nickname'] ?: '未设置昵称') ?> · <?= e($u['email']) ?></p>
                            </div>
                        </div>
                        <div class="bm-admin-user-badges">
                            <span class="bm-state-pill"><?= e($roleLabel) ?></span>
                            <span class="bm-state-pill"><?= e($statusLabel) ?></span>
                            <span class="bm-state-pill">ID <?= e($u['id']) ?></span>
                        </div>
                    </header>

                    <div class="bm-admin-user-meta">
                        <span><small>余额</small><b>¥<?= e(number_format((float) $u['balance'], 2)) ?></b></span>
                        <span><small>套餐</small><b><?= e($u['package_name'] ?: $packageName($u['package_id'])) ?></b></span>
                        <span><small>到期</small><b><?= e(!empty($u['package_expire_time']) ? $u['package_expire_time'] : '长期') ?></b></span>
                        <span><small>空间</small><b><?= e(format_bytes($storageUsed)) ?> / <?= e($storageTotal > 0 ? format_bytes($storageTotal) : '不限') ?></b></span>
                        <span><small>流量</small><b><?= e(format_bytes($trafficUsed)) ?> / <?= e($trafficTotal > 0 ? format_bytes($trafficTotal) : '不限') ?></b></span>
                        <span><small>最近登录</small><b><?= e(!empty($u['last_login_time']) ? $u['last_login_time'] : '暂无') ?></b></span>
                    </div>

                    <form method="post" action="<?= url('admin/users/update') ?>" class="bm-admin-user-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($u['id']) ?>">
                        <label>用户名<input name="username" value="<?= e($u['username']) ?>" required></label>
                        <label>昵称<input name="nickname" value="<?= e($u['nickname']) ?>"></label>
                        <label class="bm-span-all">邮箱<input type="email" name="email" value="<?= e($u['email']) ?>" required></label>
                        <label>角色<select name="role">
                            <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>普通用户</option>
                            <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>管理员</option>
                        </select></label>
                        <label>状态<select name="status">
                            <option value="1" <?= $u['status'] ? 'selected' : '' ?>>启用</option>
                            <option value="0" <?= !$u['status'] ? 'selected' : '' ?>>禁用</option>
                        </select></label>
                        <label>余额<input name="balance" type="number" step="0.01" value="<?= e($u['balance']) ?>"></label>
                        <label>套餐<select name="package_id">
                            <option value="0">不绑定套餐</option>
                            <?php foreach ($packages as $p): ?>
                                <option value="<?= e($p['id']) ?>" <?= (int) $u['package_id'] === (int) $p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                            <?php endforeach; ?>
                        </select></label>
                        <label>到期时间<input type="datetime-local" name="package_expire_time" value="<?= e($datetimeValue(isset($u['package_expire_time']) ? $u['package_expire_time'] : '')) ?>"></label>
                        <label>空间配额（字节）<input type="number" name="total_storage" value="<?= e($storageTotal) ?>"></label>
                        <label>流量配额（字节）<input type="number" name="total_traffic" value="<?= e($trafficTotal) ?>"></label>
                        <label>重置密码<input name="password" type="password" placeholder="留空不修改"></label>
                        <label>图床权限<select name="allow_image_override">
                            <option value="-1" <?= (int) (isset($u['allow_image_override']) ? $u['allow_image_override'] : -1) === -1 ? 'selected' : '' ?>>继承套餐</option>
                            <option value="1" <?= (int) (isset($u['allow_image_override']) ? $u['allow_image_override'] : -1) === 1 ? 'selected' : '' ?>>强制允许</option>
                            <option value="0" <?= (int) (isset($u['allow_image_override']) ? $u['allow_image_override'] : -1) === 0 ? 'selected' : '' ?>>强制禁止</option>
                        </select></label>
                        <label>网盘权限<select name="allow_netdisk_override">
                            <option value="-1" <?= (int) (isset($u['allow_netdisk_override']) ? $u['allow_netdisk_override'] : -1) === -1 ? 'selected' : '' ?>>继承套餐</option>
                            <option value="1" <?= (int) (isset($u['allow_netdisk_override']) ? $u['allow_netdisk_override'] : -1) === 1 ? 'selected' : '' ?>>强制允许</option>
                            <option value="0" <?= (int) (isset($u['allow_netdisk_override']) ? $u['allow_netdisk_override'] : -1) === 0 ? 'selected' : '' ?>>强制禁止</option>
                        </select></label>
                        <label class="bm-check-row"><input type="checkbox" name="sync_package_limits"> 同步套餐容量</label>
                        <label class="bm-check-row"><input type="checkbox" name="email_verified" <?= !empty($u['email_verified_at']) ? 'checked' : '' ?>> 邮箱已验证</label>
                        <label class="bm-check-row"><input type="checkbox" name="reset_api_token"> 重置 API Token</label>
                        <label class="bm-span-all">API 白名单<textarea name="api_allowed_ips" placeholder="每行一个 IP，留空不限制"><?= e(isset($u['api_allowed_ips']) ? $u['api_allowed_ips'] : '') ?></textarea></label>
                        <div class="bm-form-actions bm-span-all">
                            <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存用户</button>
                        </div>
                    </form>
                </article>
            <?php endforeach; ?>
        </section>
    </section>
</section>
