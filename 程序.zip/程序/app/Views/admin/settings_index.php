<?php require APP_ROOT . '/app/Views/admin/partials/settings_nav.php'; ?>
<?php
$settingsOverview = isset($settingsOverview) ? $settingsOverview : [];
$packages = isset($packages) && is_array($packages) ? $packages : [];
$settingSections = isset($settingSections) && is_array($settingSections) ? $settingSections : [];
$defaultPackageName = '未设置';
if (!empty($settingsOverview['default_package_id']) && !empty($packages)) {
    foreach ($packages as $package) {
        if ((int) $package['id'] === (int) $settingsOverview['default_package_id']) {
            $defaultPackageName = $package['name'];
            break;
        }
    }
}
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">设置中心</p>
        <h1>系统设置总览</h1>
        <p>把站点、注册、安全、上传、API 与邮件配置统一收束到一个控制台里，方便管理者快速判断平台当前是否具备对外运营条件。</p>
    </div>
    <div class="card-actions">
        <a class="btn btn-ghost" href="<?= url('admin/themes') ?>" data-icon="palette">主题设置</a>
        <a class="btn btn-ghost" href="<?= url('admin/maintenance') ?>" data-icon="wrench">系统维护</a>
    </div>
</section>

<section class="bm-admin-metric-grid bm-admin-workbench-metrics">
    <article class="bm-admin-metric is-blue"><span class="bm-icon-tile"><i data-lucide="globe"></i></span><div><small>站点名称</small><strong><?= e(isset($settingsOverview['site_name']) ? $settingsOverview['site_name'] : '-') ?></strong><em><?= e(!empty($settingsOverview['site_public_url']) ? $settingsOverview['site_public_url'] : '未设置公开域名') ?></em></div></article>
    <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="user-round-plus"></i></span><div><small>注册策略</small><strong><?= !empty($settingsOverview['register_enabled']) ? '已开放' : '已关闭' ?></strong><em><?= !empty($settingsOverview['email_code_enabled']) ? '启用邮箱验证码' : '未启用邮箱验证码' ?></em></div></article>
    <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="upload-cloud"></i></span><div><small>访客上传</small><strong><?= !empty($settingsOverview['guest_upload_enabled']) ? '已开启' : '已关闭' ?></strong><em>默认套餐 <?= e($defaultPackageName) ?></em></div></article>
    <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="mail"></i></span><div><small>通知服务</small><strong><?= !empty($settingsOverview['email_host']) ? '邮件已配置' : '邮件未配置' ?></strong><em><?= !empty($settingsOverview['alert_webhook_enabled']) ? '告警外送已开启' : '告警外送未开启' ?></em></div></article>
</section>

<section class="bm-admin-screen-grid">
    <article class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Business Readiness</span>
                <h2>运营准备度</h2>
            </div>
        </div>
        <div class="bm-admin-screen-summary-grid">
            <div class="bm-admin-screen-summary-item"><span>默认免费套餐</span><strong><?= e($defaultPackageName) ?></strong><small>影响新用户开通与转化起点</small></div>
            <div class="bm-admin-screen-summary-item"><span>上传大小上限</span><strong><?= e(!empty($settingsOverview['upload_max_size']) ? format_bytes((int) $settingsOverview['upload_max_size']) : '未设置') ?></strong><small>控制访客上传体验与成本</small></div>
            <div class="bm-admin-screen-summary-item"><span>套餐数量</span><strong><?= e(number_format((int) $settingsOverview['package_count'])) ?></strong><small>套餐过少会影响付费转化策略</small></div>
        </div>
    </article>

    <article class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Action Entry</span>
                <h2>高频设置入口</h2>
            </div>
        </div>
        <div class="bm-admin-screen-list bm-admin-settings-actions">
            <div><span>站点品牌与域名</span><strong><a href="<?= url('admin/settings/site') ?>">进入站点信息</a></strong></div>
            <div><span>注册与风控</span><strong><a href="<?= url('admin/settings/security') ?>">进入安全与注册</a></strong></div>
            <div><span>上传与访客权限</span><strong><a href="<?= url('admin/settings/upload') ?>">进入上传权限</a></strong></div>
            <div><span>接口限流与对外能力</span><strong><a href="<?= url('admin/settings/api') ?>">进入 API 设置</a></strong></div>
            <div><span>通知送达、邮件与告警外送</span><strong><a href="<?= url('admin/settings/email') ?>">进入通知服务</a></strong></div>
        </div>
    </article>
</section>

<section class="workspace-summary-grid">
    <?php foreach ($settingSections as $section): ?>
        <article class="workspace-summary-card glass">
            <span><?= e($section['label']) ?></span>
            <b>配置分组</b>
            <small>面向实际运营动作拆分，减少跨页面来回查找成本</small>
            <div class="card-actions">
                <a class="btn btn-ghost" href="<?= url($section['path']) ?>" data-icon="arrow-right">进入</a>
            </div>
        </article>
    <?php endforeach; ?>
</section>
