<?php
$es = isset($editStorage) && $editStorage ? $editStorage : null;
$pageMode = isset($storagePageMode) && $storagePageMode === 'integration' ? 'integration' : 'storage';
$isIntegrationPage = $pageMode === 'integration';
$stats = isset($storageStats) ? $storageStats : ['total' => 0, 'enabled' => 0, 'cloud' => 0, 'default_name' => '未设置'];
$storageTypes = [
    'local' => ['name' => '本地测试存储', 'icon' => 'hard-drive', 'badge' => 'Local'],
    'oss' => ['name' => '阿里云 OSS', 'icon' => 'cloud', 'badge' => 'OSS'],
    'cos' => ['name' => '腾讯云 COS', 'icon' => 'cloud-sun', 'badge' => 'COS'],
    'kodo' => ['name' => '七牛云 Kodo', 'icon' => 'cloud-upload', 'badge' => 'Kodo'],
    's3' => ['name' => 'S3 兼容存储', 'icon' => 'cloud-cog', 'badge' => 'S3'],
    'minio' => ['name' => 'MinIO 私有云', 'icon' => 'server', 'badge' => 'MinIO'],
    'r2' => ['name' => 'Cloudflare R2', 'icon' => 'cloud-lightning', 'badge' => 'R2'],
    'webdav' => ['name' => 'WebDAV', 'icon' => 'folder-sync', 'badge' => 'DAV'],
];
$integrationTypes = [
    'bmtools' => ['name' => '同系统对接', 'icon' => 'network', 'badge' => '对接'],
];
$types = $isIntegrationPage ? $integrationTypes : $storageTypes;
$isIntegrationEdit = $es && isset($es['type']) && $es['type'] === 'bmtools';
$isIntegrationForm = $isIntegrationPage || $isIntegrationEdit;
$secretPlaceholder = $es ? '留空表示不修改原 SecretKey' : '云厂商 SecretKey';
$integrationSecretPlaceholder = $es ? '留空表示不修改原对接 Token' : '远端用户 API Token';
$guides = [
    'oss' => [
        'title' => '阿里云 OSS 怎么填写',
        'items' => [
            ['AccessKey / SecretKey', '按官方 OSS REST API 签名方式使用。建议在 RAM 里创建子账号，只授权当前 Bucket 的 oss:PutObject、oss:DeleteObject、oss:GetObject。'],
            ['Bucket', '填写空间名称，例如 bmtools-img，不要填写域名。'],
            ['Endpoint', '只填写官方地域节点，例如 oss-cn-hangzhou.aliyuncs.com。不要写 https://，不要写 bucket.oss-cn-hangzhou.aliyuncs.com，不要写自定义域名。'],
            ['访问域名', '可填写绑定的 CDN 或自定义域名，例如 https://img.example.com。没有就留空，系统会用 Bucket 默认域名。'],
        ],
    ],
    'cos' => [
        'title' => '腾讯云 COS 怎么填写',
        'items' => [
            ['SecretId / SecretKey', '按官方 COS XML API Authorization 签名方式使用。在腾讯云访问管理 CAM 获取，注意不是 AppID。'],
            ['Bucket', '填写完整 Bucket 名称，通常类似 bmtools-1250000000。'],
            ['Region', '填写地域代码，例如 ap-guangzhou、ap-shanghai。Endpoint 建议留空，系统会生成 bucket.cos.region.myqcloud.com。'],
            ['访问域名', '如果有 CDN 或自定义域名就填写；没有时系统会使用 COS 默认访问地址。'],
        ],
    ],
    'kodo' => [
        'title' => '七牛云 Kodo 怎么填写',
        'items' => [
            ['AccessKey / SecretKey', '按官方 Kodo 上传凭证和管理凭证生成方式使用，在七牛云密钥管理里获取。'],
            ['Bucket', '填写空间名称，不是域名。'],
            ['Region', '请选择空间所在区域：华东浙江 z0、华东浙江2 cn-east-2、华北 z1、华南 z2、北美 na0、亚太新加坡 as0；存量空间还可选亚太河内 ap-southeast-2、亚太胡志明 ap-southeast-3。不确定可选自动识别。'],
            ['Endpoint / 上传域名', '一般可留空，系统会按 Region 尝试官方上传域名。需要手动指定时可填写 up-z1.qiniup.com、up-z2.qiniup.com 等七牛上传域名。'],
            ['访问域名', '必须填写空间绑定域名，例如 https://cdn.example.com，否则上传成功后无法生成可访问外链。'],
        ],
    ],
    'bmtools' => [
        'title' => '同系统对接怎么配置',
        'items' => [
            ['远端站点地址', '填写另一套 BM TOOLS 的 HTTPS 根地址，例如 https://store.example.com，不要填写 /api/upload。'],
            ['对接 Token', '登录远端站点的普通用户账号，进入个人资料或 API 管理，复制 API Token，填到本页“对接 Token”。'],
            ['远端权限', '远端用户套餐必须开启 API 和图床；如果要接收网盘文件，也要开启网盘。'],
            ['安全建议', '远端用户的 API 白名单只填写当前主站服务器出口 IP，不要使用管理员日常账号的 Token。'],
        ],
    ],
    's3' => [
        'title' => 'S3 兼容存储怎么填写',
        'items' => [
            ['Access Key / Secret Key', '填写厂商提供的 S3 API 凭据。AWS、MinIO、Wasabi、Backblaze B2 S3 兼容模式都使用这一组字段。'],
            ['Bucket', '填写存储桶名称，不要填写域名。'],
            ['Region', 'AWS S3 必须填写真实 Region，例如 us-east-1、ap-northeast-1；MinIO/部分兼容厂商可按厂商要求填写 us-east-1。'],
            ['Endpoint', '填写 S3 API Endpoint，例如 https://s3.us-west-004.backblazeb2.com 或 https://s3.amazonaws.com；自定义访问域名请填到“自定义访问域名”。'],
        ],
    ],
    'minio' => [
        'title' => 'MinIO 私有云怎么填写',
        'items' => [
            ['Access Key / Secret Key', '填写 MinIO Console 或 mc admin user svcacct 创建的访问密钥，建议只授权当前 Bucket。'],
            ['Bucket', '填写 MinIO Bucket 名称，必须提前创建好。'],
            ['Region', 'MinIO 常用 us-east-1；如果服务端配置了 region，请按 MinIO 实际配置填写。'],
            ['Endpoint', '填写 MinIO S3 API 地址，例如 https://minio.example.com 或 http://10.0.0.8:9000，不要填写 Console 控制台地址。'],
            ['访问域名', '公网访问建议配置 HTTPS 反向代理或 CDN 域名；内网 Endpoint 只适合内网下载。'],
        ],
    ],
    'r2' => [
        'title' => 'Cloudflare R2 怎么填写',
        'items' => [
            ['Access Key / Secret Key', '在 Cloudflare R2 API Token 页面创建 S3 兼容访问密钥，授权到目标 Bucket。'],
            ['Bucket', '填写 R2 Bucket 名称。'],
            ['Endpoint', '填写账号级 S3 API 地址，例如 https://<ACCOUNT_ID>.r2.cloudflarestorage.com。不要填写 r2.dev 或自定义公开域名。'],
            ['访问域名', '公开访问建议绑定 R2 自定义域名或 r2.dev 域名，并填写到“自定义访问域名”，否则真实测试会提示访问链接不可公开打开。'],
        ],
    ],
    'webdav' => [
        'title' => 'WebDAV 怎么填写',
        'items' => [
            ['用户名 / 密码', '填写 WebDAV 用户名和密码，Nextcloud、Alist、坚果云等建议使用应用专用密码或访问 Token。'],
            ['远程目录', 'Bucket 字段在 WebDAV 中作为远程根目录使用，可留空，也可填写 uploads/files。'],
            ['Endpoint', '填写 WebDAV 根地址，例如 https://dav.example.com/remote.php/dav/files/user，系统会自动创建子目录并 PUT 文件。'],
            ['访问域名', '如果 WebDAV 地址本身需要登录，请配置一个可公开访问的域名；否则上传能成功，但外链检测会提示 401/403。'],
        ],
    ],
];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow"><?= $isIntegrationPage ? '对接功能' : '资源内容' ?></p>
        <h1><?= $isIntegrationPage ? '同系统对接' : '资源功能管理' ?></h1>
        <p><?= $isIntegrationPage ? '把另一套 BM TOOLS 作为远端仓储站，通过安全 API 写入图床和网盘文件。' : '管理本地、OSS、COS、Kodo、S3、MinIO、R2、WebDAV 等基础资源存储源。同系统对接已拆分为独立页面。' ?></p>
    </div>
    <a class="btn btn-primary" href="#storage-form" data-icon="plus"><?= $isIntegrationPage ? '新增同系统对接' : '添加基础存储' ?></a>
</section>

<section class="workspace-summary-grid reveal">
    <article class="workspace-summary-card glass"><span><?= $isIntegrationPage ? '对接线路' : '存储源' ?></span><b><?= e($stats['total']) ?></b><small><?= $isIntegrationPage ? '已创建的远端对接' : '已创建的上传线路' ?></small></article>
    <article class="workspace-summary-card glass"><span>启用</span><b><?= e($stats['enabled']) ?></b><small>可被上传服务调用</small></article>
    <article class="workspace-summary-card glass"><span><?= $isIntegrationPage ? '远端线路' : '云存储' ?></span><b><?= e($stats['cloud']) ?></b><small><?= $isIntegrationPage ? '同系统 API 对接' : 'OSS / COS / Kodo / S3 / MinIO / R2 / WebDAV' ?></small></article>
    <article class="workspace-summary-card glass"><span>默认线路</span><b><?= e($stats['default_name']) ?></b><small>新文件默认写入这里</small></article>
</section>

<?php if (!$isIntegrationPage): ?>
<section class="storage-help-card glass reveal">
    <div>
        <p class="eyebrow">基础存储</p>
        <h2>对象存储配置</h2>
        <p>本地、OSS、COS、Kodo、S3、MinIO、R2、WebDAV 用作基础存储源。不同厂商字段名称不一样，先看说明再填写表单。</p>
    </div>
    <div class="storage-help-actions">
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="oss" data-icon="cloud">阿里云 OSS</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="cos" data-icon="cloud-sun">腾讯云 COS</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="kodo" data-icon="cloud-upload">七牛云 Kodo</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="s3" data-icon="cloud-cog">S3 兼容</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="minio" data-icon="server">MinIO</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="r2" data-icon="cloud-lightning">Cloudflare R2</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="webdav" data-icon="folder-sync">WebDAV</button>
    </div>
</section>
<?php endif; ?>

<?php if ($isIntegrationPage): ?>
<section class="integration-connect-card glass reveal">
    <div class="integration-connect-copy">
        <p class="eyebrow">对接功能</p>
        <h2>同系统对接</h2>
        <p>把另一套 BM TOOLS 当作远端仓储站，主站通过安全 API 把图床和网盘文件写入远端。适合没有对象存储预算的新手站长，也适合多站点分仓。</p>
        <div class="integration-flow" aria-label="同系统对接流程">
            <span>主站上传</span>
            <i></i>
            <span>Token 鉴权</span>
            <i></i>
            <span>仓储站保存</span>
        </div>
        <div class="integration-connect-points">
            <span>HTTPS 站点地址</span>
            <span>远端用户 Token</span>
            <span>服务器 IP 白名单</span>
        </div>
    </div>
    <div class="integration-connect-actions">
        <button type="button" class="btn btn-primary storage-type-pick" data-storage-type="bmtools" data-icon="network">配置同系统对接</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="bmtools" data-icon="info">查看对接说明</button>
    </div>
</section>
<?php endif; ?>

<section class="form-section glass reveal<?= $isIntegrationForm ? ' is-integration' : '' ?>" id="storage-form">
    <div class="section-head">
        <div>
            <p class="eyebrow"><?= $es ? ($isIntegrationForm ? '编辑对接' : '编辑存储') : '新增配置' ?></p>
            <h2><?= $es ? (($isIntegrationForm ? '编辑同系统对接 #' : '编辑存储源 #') . e($es['id'])) : ($isIntegrationPage ? '添加同系统对接' : '添加基础存储源') ?></h2>
        </div>
        <?php if ($es): ?><a class="btn btn-ghost" href="<?= url($isIntegrationPage ? 'admin/storage-integrations' : 'admin/storages') ?>" data-icon="x">取消编辑</a><?php endif; ?>
    </div>

    <form method="post" action="<?= url('admin/storages/save') ?>" class="form-grid three storage-config-form<?= $isIntegrationForm ? ' is-integration' : '' ?>">
        <?= csrf_field() ?>
        <?php if ($es): ?><input type="hidden" name="id" value="<?= e($es['id']) ?>"><?php endif; ?>

        <label><span data-default-text="存储名称" data-integration-text="对接名称"><?= $isIntegrationForm ? '对接名称' : '存储名称' ?></span>
            <input name="name" value="<?= e($es ? $es['name'] : '') ?>" placeholder="例如：阿里云杭州主线路" data-default-placeholder="例如：阿里云杭州主线路" data-integration-placeholder="例如：B站远程仓储" required>
            <small class="field-help" data-default-text="只给后台识别使用，建议写清楚云厂商和地域。" data-integration-text="只给后台识别使用，建议写清楚远端站点用途和归属。"><?= $isIntegrationForm ? '只给后台识别使用，建议写清楚远端站点用途和归属。' : '只给后台识别使用，建议写清楚云厂商和地域。' ?></small>
        </label>
        <label>类型 / 对接方式
            <select name="type" id="storageType">
                <?php if (!$isIntegrationPage): ?>
                <optgroup label="基础存储">
                    <?php foreach ($storageTypes as $k => $v): ?>
                        <option value="<?= e($k) ?>" <?= $es && $es['type'] === $k ? 'selected' : '' ?>><?= e($v['name']) ?></option>
                    <?php endforeach; ?>
                </optgroup>
                <?php else: ?>
                <optgroup label="同系统对接">
                    <?php foreach ($integrationTypes as $k => $v): ?>
                        <option value="<?= e($k) ?>" <?= (!$es || $es['type'] === $k) ? 'selected' : '' ?>><?= e($v['name']) ?></option>
                    <?php endforeach; ?>
                </optgroup>
                <?php endif; ?>
            </select>
            <small class="field-help"><?= $isIntegrationPage ? '此页面只管理同系统对接线路。' : '这里只管理基础资源存储；同系统对接请到独立页面配置。' ?></small>
        </label>
        <label>状态
            <select name="is_enabled">
                <option value="1" <?= !$es || $es['is_enabled'] ? 'selected' : '' ?>>启用</option>
                <option value="0" <?= $es && !$es['is_enabled'] ? 'selected' : '' ?>>停用</option>
            </select>
        </label>

        <label class="storage-field cloud-field access-field"><span data-default-text="AccessKey / SecretId" data-integration-text="对接备注" data-field-label="access">AccessKey / SecretId</span>
            <input name="access_key" value="<?= e($es ? $es['access_key'] : '') ?>" autocomplete="off" placeholder="阿里云/七牛填 AccessKey，腾讯云填 SecretId" data-default-placeholder="阿里云/七牛填 AccessKey，腾讯云填 SecretId" data-integration-placeholder="可留空，或填写远端账号备注">
            <small class="field-help" data-default-text="云厂商填写 AccessKey/SecretId。" data-integration-text="同系统对接通常不用填，可记录远端用户名或用途备注。">云厂商填写 AccessKey/SecretId。</small>
        </label>
        <label class="storage-field cloud-field secret-field"><span data-default-text="SecretKey" data-integration-text="对接 Token" data-field-label="secret"><?= $isIntegrationForm ? '对接 Token' : 'SecretKey' ?></span>
            <input name="secret_key" type="password" value="" autocomplete="new-password" placeholder="<?= e($isIntegrationForm ? $integrationSecretPlaceholder : $secretPlaceholder) ?>" data-default-placeholder="<?= e($secretPlaceholder) ?>" data-integration-placeholder="<?= e($integrationSecretPlaceholder) ?>">
            <small class="field-help" data-default-text="云厂商填写 SecretKey。编辑时留空表示不修改。" data-integration-text="填写远端普通用户的 API Token。编辑时留空表示不修改。"><?= $isIntegrationForm ? '填写远端普通用户的 API Token。编辑时留空表示不修改。' : '云厂商填写 SecretKey。编辑时留空表示不修改。' ?></small>
            <?php if ($es && !empty($es['secret_key'])): ?><small class="field-help">当前密钥已保存，页面不会回显明文。</small><?php endif; ?>
        </label>
        <label class="storage-field cloud-field bucket-field"><span data-default-text="Bucket" data-integration-text="远端 Bucket" data-field-label="bucket">Bucket</span>
            <input name="bucket" value="<?= e($es ? $es['bucket'] : '') ?>" placeholder="空间或桶名称，例如 bmtools-img" data-default-placeholder="空间或桶名称，例如 bmtools-img" data-integration-placeholder="同系统对接不用填写">
            <small class="field-help" data-default-text="云厂商填写对象存储 Bucket。" data-integration-text="同系统对接由远端站点自行决定存储源，本页不用填写 Bucket。">云厂商填写对象存储 Bucket。</small>
        </label>

        <label class="storage-field region-field"><span data-field-label="region">Region</span>
            <input type="hidden" name="region" id="storageRegionValue" value="<?= e($es ? $es['region'] : '') ?>">
            <select id="storageRegionSelect" class="storage-region-select" data-region-select>
                <option value="">自动识别 / Endpoint 手动填写</option>
                <option value="z0">华东-浙江 z0（up.qiniup.com）</option>
                <option value="cn-east-2">华东-浙江2 cn-east-2（up-cn-east-2.qiniup.com）</option>
                <option value="z1">华北-河北 z1（up-z1.qiniup.com）</option>
                <option value="z2">华南-广东 z2（up-z2.qiniup.com）</option>
                <option value="na0">北美 na0（up-na0.qiniup.com）</option>
                <option value="as0">亚太-新加坡 as0（up-as0.qiniup.com）</option>
                <option value="ap-southeast-2">亚太-河内 ap-southeast-2（up-ap-southeast-2.qiniup.com）</option>
                <option value="ap-southeast-3">亚太-胡志明 ap-southeast-3（up-ap-southeast-3.qiniup.com）</option>
            </select>
            <input id="storageRegionInput" class="storage-region-input" value="<?= e($es ? $es['region'] : '') ?>" placeholder="腾讯云例如 ap-guangzhou">
            <small class="field-help" data-region-help>腾讯云建议必填；阿里云通常由 Endpoint 表示地域。</small>
        </label>
        <label class="storage-field endpoint-field"><span data-default-text="Endpoint / 上传域名" data-integration-text="远端站点地址" data-field-label="endpoint"><?= $isIntegrationForm ? '远端站点地址' : 'Endpoint / 上传域名' ?></span>
            <input name="endpoint" value="<?= e($es ? $es['endpoint'] : '') ?>" placeholder="<?= e($isIntegrationForm ? 'https://store.example.com' : '例如 oss-cn-hangzhou.aliyuncs.com') ?>" data-default-placeholder="例如 oss-cn-hangzhou.aliyuncs.com" data-integration-placeholder="https://store.example.com">
            <small class="field-help" data-default-text="云厂商填写上传节点，七牛云特殊区域可填写上传域名。" data-integration-text="填写远端 BM TOOLS 的 HTTPS 根地址，只填域名，不写 /api/upload。"><?= $isIntegrationForm ? '填写远端 BM TOOLS 的 HTTPS 根地址，只填域名，不写 /api/upload。' : '云厂商填写上传节点，七牛云特殊区域可填写上传域名。' ?></small>
        </label>
        <label class="storage-field domain-field"><span data-default-text="自定义访问域名" data-integration-text="远端返回域名" data-field-label="domain">自定义访问域名</span>
            <input name="domain" value="<?= e($es ? $es['domain'] : '') ?>" placeholder="例如 https://img.example.com" data-default-placeholder="例如 https://img.example.com" data-integration-placeholder="同系统对接通常留空">
            <small class="field-help" data-default-text="用户最终打开图片或文件的域名；七牛云必须填写。" data-integration-text="同系统对接通常留空，文件外链以远端 API 返回地址为准。">用户最终打开图片或文件的域名；七牛云必须填写。</small>
        </label>

        <label><span data-default-text="目录前缀" data-integration-text="远端目录前缀"><?= $isIntegrationForm ? '远端目录前缀' : '目录前缀' ?></span>
            <input name="prefix" value="<?= e($es ? $es['prefix'] : '') ?>" placeholder="例如 bmtools/uploads">
            <small class="field-help" data-default-text="可理解为云存储里的文件夹，留空表示上传到 Bucket 根目录。" data-integration-text="可选。用于给转发到远端的文件路径增加前缀，留空即可。"><?= $isIntegrationForm ? '可选。用于给转发到远端的文件路径增加前缀，留空即可。' : '可理解为云存储里的文件夹，留空表示上传到 Bucket 根目录。' ?></small>
        </label>
        <label class="inline-check storage-check"><input type="checkbox" name="is_default" <?= $es && $es['is_default'] ? 'checked' : '' ?>> <span data-default-text="设为默认存储" data-integration-text="设为默认对接"><?= $isIntegrationForm ? '设为默认对接' : '设为默认存储' ?></span></label>
        <label class="inline-check storage-check"><input type="checkbox" name="is_public" <?= !$es || $es['is_public'] ? 'checked' : '' ?>> <span data-default-text="公开读访问" data-integration-text="远端返回公开链接"><?= $isIntegrationForm ? '远端返回公开链接' : '公开读访问' ?></span></label>

        <div class="form-actions span-3">
            <button class="btn btn-primary" type="submit" data-icon="save"><span data-default-text="保存存储源" data-integration-text="保存同系统对接"><?= $isIntegrationForm ? '保存同系统对接' : '保存存储源' ?></span></button>
            <span class="form-help" data-default-text="保存后点击列表中的“真实测试”，系统会上传并删除一个极小测试文件。" data-integration-text="保存后点击列表中的“真实测试”，系统会调用远端容量接口，上传 1px 测试图，再删除测试图。"><?= $isIntegrationForm ? '保存后点击列表中的“真实测试”，系统会调用远端容量接口，上传 1px 测试图，再删除测试图。' : '保存后点击列表中的“真实测试”，系统会上传并删除一个极小测试文件。' ?></span>
        </div>
    </form>
</section>

<section class="table-card glass reveal">
    <div class="section-head">
        <div>
            <p class="eyebrow"><?= $isIntegrationPage ? '对接线路' : '存储线路' ?></p>
            <h2><?= $isIntegrationPage ? '同系统对接列表' : '基础存储源列表' ?></h2>
        </div>
        <span class="storage-test-hint">密钥加密保存；每次修改 Key、Token、Bucket、Endpoint 后都建议执行真实测试。</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>ID</th><th>名称</th><th>类型</th><th>Bucket / 前缀</th><th>访问域名</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$storages): ?>
                <tr><td colspan="7" class="empty-table responsive-table-span"><?= $isIntegrationPage ? '还没有同系统对接，请先新增一条远端仓储站。' : '还没有基础存储源，请先添加本地测试或第三方对象存储。' ?></td></tr>
            <?php endif; ?>
            <?php foreach ($storages as $s): ?>
                <?php $meta = isset($types[$s['type']]) ? $types[$s['type']] : ['name' => $s['type'], 'icon' => 'database', 'badge' => $s['type']]; ?>
                <tr>
                    <td data-label="ID"><?= e($s['id']) ?></td>
                    <td data-label="名称"><b><?= e($s['name']) ?></b><?php if ($s['is_default']): ?> <span class="status-pill ok">默认</span><?php endif; ?></td>
                    <td data-label="类型"><span class="status-pill soft"><?= e($meta['badge']) ?></span></td>
                    <td data-label="Bucket / 前缀"><div><?= e($s['bucket'] ?: '-') ?></div><small><?= e($s['prefix'] ?: '未设置前缀') ?></small></td>
                    <td class="storage-domain-cell" data-label="访问域名"><?= e($s['domain'] ?: $s['endpoint'] ?: '-') ?></td>
                    <td data-label="状态">
                        <span class="status-pill <?= $s['is_enabled'] ? 'ok' : 'muted' ?>"><?= $s['is_enabled'] ? '启用' : '停用' ?></span>
                        <span class="status-pill <?= $s['is_public'] ? 'soft' : 'muted' ?>"><?= $s['is_public'] ? '公开读' : '私有' ?></span>
                    </td>
                    <td class="table-actions storage-actions" data-label="操作">
                        <a class="btn btn-ghost" href="<?= url(($isIntegrationPage ? 'admin/storage-integrations' : 'admin/storages') . '?id=' . $s['id']) ?>" data-icon="pencil">编辑</a>
                        <button class="btn btn-ghost storage-test-btn" data-id="<?= e($s['id']) ?>" data-token="<?= e(csrf_token()) ?>" type="button" data-icon="plug-zap">真实测试</button>
                        <?php if (!$s['is_default']): ?>
                            <form method="post" action="<?= url('admin/storages/default') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                                <button class="btn btn-ghost" data-icon="check">设为默认</button>
                            </form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('admin/storages/delete') ?>" class="confirm-form" data-confirm="确定删除该存储源吗？已有文件记录的存储源不能删除。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="btn btn-ghost danger" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
                <tr class="storage-test-result-row" id="storage-test-result-<?= e($s['id']) ?>">
                    <td colspan="7" class="responsive-table-span"><div class="storage-test-result muted">尚未执行本次页面测试。</div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<div class="storage-guide-modal" id="storageGuideModal" aria-hidden="true">
    <div class="storage-guide-backdrop" data-close-storage-guide></div>
    <section class="storage-guide-dialog glass" role="dialog" aria-modal="true" aria-labelledby="storageGuideTitle">
        <button type="button" class="icon-btn storage-guide-close" data-close-storage-guide data-icon="x" aria-label="关闭"></button>
        <div class="storage-guide-dialog-head">
            <span data-lucide="info"></span>
            <div>
                <p class="eyebrow">填写说明</p>
                <h2 id="storageGuideTitle">存储与对接填写说明</h2>
            </div>
        </div>
        <div class="storage-guide-dialog-body" id="storageGuideBody"></div>
    </section>
</div>

<script>
window.BM_STORAGE_GUIDES = <?= json_encode($guides, JSON_UNESCAPED_UNICODE) ?>;
(function () {
    var modal = document.getElementById('storageGuideModal');
    var title = document.getElementById('storageGuideTitle');
    var body = document.getElementById('storageGuideBody');
    var guides = window.BM_STORAGE_GUIDES || {};
    var storageSection = document.getElementById('storage-form');
    var storageForm = document.querySelector('.storage-config-form');
    var regionValue = document.getElementById('storageRegionValue');
    var regionSelect = document.getElementById('storageRegionSelect');
    var regionInput = document.getElementById('storageRegionInput');
    var regionHelp = document.querySelector('[data-region-help]');

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[char];
        });
    }

    function openGuide(key) {
        var guide = guides[key];
        if (!guide || !modal) return;
        title.textContent = guide.title;
        body.innerHTML = '<div class="storage-guide-lines">' + guide.items.map(function (item) {
            return '<p><b>' + escapeHtml(item[0]) + '</b><span>' + escapeHtml(item[1]) + '</span></p>';
        }).join('') + '</div>';
        modal.classList.add('open');
        modal.setAttribute('aria-hidden', 'false');
        if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
    }

    function closeGuide() {
        if (!modal) return;
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden', 'true');
    }

    document.querySelectorAll('.storage-guide-open').forEach(function (button) {
        button.addEventListener('click', function () {
            openGuide(button.getAttribute('data-guide'));
        });
    });
    document.querySelectorAll('[data-close-storage-guide]').forEach(function (button) {
        button.addEventListener('click', closeGuide);
    });
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeGuide();
    });

    function applyDynamicCopy(isIntegration) {
        document.querySelectorAll('[data-default-text]').forEach(function (el) {
            var value = isIntegration ? el.getAttribute('data-integration-text') : el.getAttribute('data-default-text');
            if (value) el.textContent = value;
        });
        document.querySelectorAll('[data-default-placeholder]').forEach(function (el) {
            var value = isIntegration ? el.getAttribute('data-integration-placeholder') : el.getAttribute('data-default-placeholder');
            if (value) el.setAttribute('placeholder', value);
        });
    }

    var providerCopy = {
        s3: {
            access: 'Access Key ID',
            secret: 'Secret Access Key',
            bucket: 'Bucket',
            region: 'Region',
            endpoint: 'S3 Endpoint',
            domain: '公开访问域名 / CDN',
            accessPlaceholder: '例如 AKIA... 或兼容厂商 Access Key',
            bucketPlaceholder: '例如 my-bucket',
            regionPlaceholder: '例如 us-east-1',
            endpointPlaceholder: '例如 https://s3.amazonaws.com',
            domainPlaceholder: '例如 https://cdn.example.com',
            secretPlaceholder: 'S3 Secret Access Key'
        },
        minio: {
            access: 'MinIO Access Key',
            secret: 'MinIO Secret Key',
            bucket: 'MinIO Bucket',
            region: 'Region',
            endpoint: 'MinIO S3 API Endpoint',
            domain: 'MinIO 公开访问域名',
            accessPlaceholder: 'MinIO Access Key',
            bucketPlaceholder: '例如 images',
            regionPlaceholder: '通常填写 us-east-1',
            endpointPlaceholder: 'https://minio.example.com 或 http://10.0.0.8:9000',
            domainPlaceholder: '例如 https://files.example.com',
            secretPlaceholder: 'MinIO Secret Key'
        },
        r2: {
            access: 'R2 Access Key ID',
            secret: 'R2 Secret Access Key',
            bucket: 'R2 Bucket',
            region: 'Region（默认 auto）',
            endpoint: 'R2 S3 API Endpoint',
            domain: 'R2 公开访问域名',
            accessPlaceholder: 'Cloudflare R2 Access Key ID',
            bucketPlaceholder: '例如 images',
            regionPlaceholder: '可留空，系统默认 auto',
            endpointPlaceholder: 'https://<ACCOUNT_ID>.r2.cloudflarestorage.com',
            domainPlaceholder: '例如 https://pub-xxx.r2.dev 或自定义域名',
            secretPlaceholder: 'Cloudflare R2 Secret Access Key'
        },
        webdav: {
            access: 'WebDAV 用户名',
            secret: '密码 / 应用 Token',
            bucket: '远程根目录',
            region: 'Region',
            endpoint: 'WebDAV 服务地址',
            domain: '公开访问域名',
            accessPlaceholder: 'WebDAV 用户名',
            bucketPlaceholder: '可留空，或填写 uploads/files',
            regionPlaceholder: 'WebDAV 不需要填写',
            endpointPlaceholder: 'https://dav.example.com/remote.php/dav/files/user',
            domainPlaceholder: '可公开访问文件的域名，可留空',
            secretPlaceholder: 'WebDAV 密码或应用专用 Token'
        },
        kodo: {
            access: '七牛 AccessKey',
            secret: '七牛 SecretKey',
            bucket: '七牛空间 Bucket',
            region: '七牛存储区域',
            endpoint: '七牛上传域名（可选）',
            domain: '七牛访问域名',
            accessPlaceholder: '七牛云密钥管理里的 AccessKey',
            bucketPlaceholder: '空间名称，不是域名',
            regionPlaceholder: '请选择空间所在区域',
            endpointPlaceholder: '可留空；或填 up-z1.qiniup.com',
            domainPlaceholder: '空间绑定域名，例如 https://cdn.example.com',
            secretPlaceholder: '七牛云密钥管理里的 SecretKey'
        }
    };

    function applyProviderCopy(value) {
        var copy = providerCopy[value];
        if (!copy) return;
        Object.keys(copy).forEach(function (key) {
            if (key.indexOf('Placeholder') !== -1) return;
            var el = document.querySelector('[data-field-label="' + key + '"]');
            if (el) el.textContent = copy[key];
        });
        var access = document.querySelector('[name="access_key"]');
        var bucket = document.querySelector('[name="bucket"]');
        var region = regionInput || document.querySelector('[name="region"]');
        var endpoint = document.querySelector('[name="endpoint"]');
        var domain = document.querySelector('[name="domain"]');
        var secret = document.querySelector('[name="secret_key"]');
        if (access && copy.accessPlaceholder) access.setAttribute('placeholder', copy.accessPlaceholder);
        if (bucket && copy.bucketPlaceholder) bucket.setAttribute('placeholder', copy.bucketPlaceholder);
        if (region && copy.regionPlaceholder) region.setAttribute('placeholder', copy.regionPlaceholder);
        if (endpoint && copy.endpointPlaceholder) endpoint.setAttribute('placeholder', copy.endpointPlaceholder);
        if (domain && copy.domainPlaceholder) domain.setAttribute('placeholder', copy.domainPlaceholder);
        if (secret && copy.secretPlaceholder) secret.setAttribute('placeholder', copy.secretPlaceholder);
    }

    function syncRegionValue(value) {
        if (!regionValue) return;
        regionValue.value = value || '';
    }

    function knownKodoRegions() {
        return ['', 'z0', 'cn-east-2', 'z1', 'z2', 'na0', 'as0', 'ap-southeast-2', 'ap-southeast-3'];
    }

    function normalizeKodoRegion(value) {
        value = String(value || '').toLowerCase().trim();
        value = value.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
        var aliases = {
            huadong: 'z0',
            east: 'z0',
            'cn-east-1': 'z0',
            '华东': 'z0',
            '华东-浙江': 'z0',
            zhejiang: 'z0',
            huabei: 'z1',
            north: 'z1',
            'cn-north-1': 'z1',
            '华北': 'z1',
            '华北-河北': 'z1',
            hebei: 'z1',
            huanan: 'z2',
            south: 'z2',
            'cn-south-1': 'z2',
            '华南': 'z2',
            '华南-广东': 'z2',
            guangdong: 'z2',
            beimei: 'na0',
            america: 'na0',
            'north-america': 'na0',
            'us-north-1': 'na0',
            '北美': 'na0',
            '亚太': 'as0',
            '亚太-新加坡': 'as0',
            singapore: 'as0',
            'ap-southeast': 'as0',
            'ap-southeast-1': 'as0',
            '华东-浙江2': 'cn-east-2',
            zhejiang2: 'cn-east-2',
            '亚太-河内': 'ap-southeast-2',
            hanoi: 'ap-southeast-2',
            vietnam: 'ap-southeast-2',
            '亚太-胡志明': 'ap-southeast-3',
            'ho-chi-minh': 'ap-southeast-3',
            hcm: 'ap-southeast-3',
            'up.qiniup.com': 'z0',
            'upload.qiniup.com': 'z0',
            'up-z0.qiniup.com': 'z0',
            'upload-z0.qiniup.com': 'z0',
            'up-cn-east-2.qiniup.com': 'cn-east-2',
            'upload-cn-east-2.qiniup.com': 'cn-east-2',
            'up-z1.qiniup.com': 'z1',
            'upload-z1.qiniup.com': 'z1',
            'up-z2.qiniup.com': 'z2',
            'upload-z2.qiniup.com': 'z2',
            'up-na0.qiniup.com': 'na0',
            'upload-na0.qiniup.com': 'na0',
            'up-as0.qiniup.com': 'as0',
            'upload-as0.qiniup.com': 'as0',
            'up-ap-southeast-2.qiniup.com': 'ap-southeast-2',
            'upload-ap-southeast-2.qiniup.com': 'ap-southeast-2',
            'up-ap-southeast-3.qiniup.com': 'ap-southeast-3',
            'upload-ap-southeast-3.qiniup.com': 'ap-southeast-3'
        };
        return aliases[value] || value;
    }

    function setRegionUi(value) {
        value = normalizeKodoRegion(value || '');
        if (regionSelect) {
            regionSelect.value = knownKodoRegions().indexOf(value) !== -1 ? value : '';
        }
        if (regionInput) regionInput.value = value;
        syncRegionValue(value);
    }

    function refreshRegionMode(type) {
        var current = regionValue ? regionValue.value : (regionInput ? regionInput.value : '');
        var useSelect = type === 'kodo';
        if (useSelect) current = normalizeKodoRegion(current);
        if (regionSelect) {
            regionSelect.hidden = false;
            regionSelect.disabled = !useSelect;
        }
        if (regionInput) {
            regionInput.hidden = useSelect;
            regionInput.disabled = useSelect;
        }
        if (regionHelp) {
            if (type === 'kodo') {
                regionHelp.textContent = '请选择七牛空间所在区域；不确定可选“自动识别”，也可以在上传域名里直接填写官方 up-* 域名。';
            } else if (type === 'cos') {
                regionHelp.textContent = '腾讯云 COS 必填，例如 ap-guangzhou、ap-shanghai。';
            } else if (type === 's3') {
                regionHelp.textContent = 'AWS S3 填真实 Region；兼容厂商按官方要求填写。';
            } else if (type === 'minio') {
                regionHelp.textContent = 'MinIO 通常填写 us-east-1；如果服务端配置了 region，请按服务端配置填写。';
            } else if (type === 'r2') {
                regionHelp.textContent = 'Cloudflare R2 可留空，系统默认按 auto 处理。';
            } else {
                regionHelp.textContent = '腾讯云建议必填；阿里云通常由 Endpoint 表示地域。';
            }
        }
        if (useSelect && regionSelect) {
            regionSelect.value = knownKodoRegions().indexOf(current) !== -1 ? current : '';
            syncRegionValue(regionSelect.value || '');
        } else if (regionInput) {
            regionInput.value = current;
            syncRegionValue(regionInput.value);
        }
    }

    function refreshStorageFields() {
        var type = document.getElementById('storageType');
        if (!type) return;
        var value = type.value || 'local';
        var isIntegration = value === 'bmtools';
        if (storageSection) storageSection.classList.toggle('is-integration', isIntegration);
        if (storageForm) storageForm.classList.toggle('is-integration', isIntegration);
        applyDynamicCopy(isIntegration);
        applyProviderCopy(value);
        refreshRegionMode(value);
        document.querySelectorAll('.cloud-field,.region-field,.endpoint-field,.domain-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', value === 'local');
        });
        document.querySelectorAll('.region-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', value === 'local' || value === 'webdav' || isIntegration);
        });
        document.querySelectorAll('.access-field,.bucket-field,.domain-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', value === 'local' || isIntegration);
        });
    }

    var typeSelect = document.getElementById('storageType');
    if (regionSelect) {
        regionSelect.addEventListener('change', function () {
            syncRegionValue(regionSelect.value);
        });
    }
    if (regionInput) {
        regionInput.addEventListener('input', function () {
            syncRegionValue(regionInput.value);
        });
    }
    if (regionValue) {
        setRegionUi(regionValue.value);
    }
    if (typeSelect) {
        if (<?= $isIntegrationPage ? 'true' : 'false' ?>) {
            typeSelect.value = 'bmtools';
        }
        typeSelect.addEventListener('change', refreshStorageFields);
        refreshStorageFields();
    }

    document.querySelectorAll('.storage-type-pick').forEach(function (button) {
        button.addEventListener('click', function () {
            if (!typeSelect) return;
            typeSelect.value = button.getAttribute('data-storage-type') || 'bmtools';
            typeSelect.dispatchEvent(new Event('change', { bubbles: true }));
            if (storageSection) {
                storageSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
})();
</script>
