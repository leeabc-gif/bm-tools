<?php
$filters = isset($filters) ? $filters : ['keyword' => '', 'status' => ''];
$filters['access_type'] = isset($filters['access_type']) ? $filters['access_type'] : '';
$statusOptions = [
    '' => '全部状态',
    'enabled' => '正常开放',
    'user_disabled' => '用户关闭',
    'admin_disabled' => '平台下架',
    'expired' => '已过期',
];
$accessLabels = [
    'public' => '公开',
    'password' => '密码',
    'private' => '私密',
];
$accessOptions = ['' => '全部权限'] + $accessLabels;
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">仓库审核</p>
        <h1>分享仓库管理</h1>
        <p>查看全站用户创建的专属分享仓库，支持搜索、状态筛选、下架恢复和无效仓库清理。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/files') ?>" data-icon="files">文件管理</a>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>仓库总数</span><b><?= e($stats['total']) ?></b><small>全站累计创建</small></article>
    <article class="ops-metric-card glass ok"><span>正常开放</span><b><?= e($stats['enabled']) ?></b><small>用户可访问</small></article>
    <article class="ops-metric-card glass"><span>关闭/下架</span><b><?= e($stats['disabled']) ?></b><small>含用户关闭和平台下架</small></article>
    <article class="ops-metric-card glass"><span>今日访问/下载</span><b><?= e($stats['today_views']) ?> / <?= e($stats['today_downloads']) ?></b><small>用于观察分享活跃度</small></article>
    <article class="ops-metric-card glass warn"><span>今日拦截</span><b><?= e($stats['blocked_today']) ?></b><small>密码错误、过期或限制触发</small></article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">筛选查询</p>
            <h2>仓库列表</h2>
        </div>
    </div>
    <form method="get" action="<?= url('admin/repositories') ?>" class="url-fetch admin-repository-filter">
        <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索仓库名称、链接、用户名">
        <select name="status">
            <?php foreach ($statusOptions as $value => $label): ?>
                <option value="<?= e($value) ?>" <?= $filters['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="access_type">
            <?php foreach ($accessOptions as $value => $label): ?>
                <option value="<?= e($value) ?>" <?= $filters['access_type'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-ghost" type="submit" data-icon="search">搜索</button>
        <a class="btn btn-ghost" href="<?= url('admin/repositories') ?>" data-icon="rotate-ccw">重置</a>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>ID</th>
                <th>仓库</th>
                <th>用户</th>
                <th>权限</th>
                <th>文件</th>
                <th>访问/下载</th>
                <th>日志</th>
                <th>限制</th>
                <th>状态</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($repositories as $repo): ?>
                <?php
                $isExpired = !empty($repo['expire_at']) && strtotime($repo['expire_at']) < time();
                $stateClass = empty($repo['admin_status']) ? 'bad' : (empty($repo['status']) || $isExpired ? 'muted' : 'ok');
                $stateText = empty($repo['admin_status']) ? '平台下架' : (empty($repo['status']) ? '用户关闭' : ($isExpired ? '已过期' : '正常'));
                ?>
                <tr>
                    <td data-label="ID"><?= e($repo['id']) ?></td>
                    <td data-label="仓库">
                        <b><?= e($repo['title']) ?></b><br>
                        <a href="<?= e(public_url('r/' . $repo['slug'])) ?>" target="_blank"><small><?= e(public_url('r/' . $repo['slug'])) ?></small></a>
                    </td>
                    <td data-label="用户"><?= e($repo['username'] ?: '-') ?><br><small><?= e($repo['nickname'] ?: '') ?></small></td>
                    <td data-label="权限"><span class="status-pill soft"><?= e(isset($accessLabels[$repo['access_type']]) ? $accessLabels[$repo['access_type']] : $repo['access_type']) ?></span></td>
                    <td data-label="文件">
                        <?= e((int) $repo['item_count']) ?>
                        <br><small>公开 <?= e((int) $repo['public_item_count']) ?></small>
                    </td>
                    <td data-label="访问/下载"><?= e((int) $repo['view_count']) ?> / <?= e((int) $repo['download_count']) ?></td>
                    <td data-label="日志">
                        <?= e((int) $repo['log_count']) ?>
                        <br><small><?= e($repo['latest_log_at'] ?: '暂无访问') ?></small>
                    </td>
                    <td data-label="限制">
                        <small>
                            到期：<?= e($repo['expire_at'] ?: '永久') ?><br>
                            总访问：<?= (int) $repo['max_views'] > 0 ? e($repo['max_views']) : '不限' ?>，
                            总下载：<?= (int) $repo['max_downloads'] > 0 ? e($repo['max_downloads']) : '不限' ?><br>
                            IP日访问：<?= (int) $repo['ip_daily_view_limit'] > 0 ? e($repo['ip_daily_view_limit']) : '不限' ?>，
                            IP日下载：<?= (int) $repo['ip_daily_download_limit'] > 0 ? e($repo['ip_daily_download_limit']) : '不限' ?>
                        </small>
                    </td>
                    <td data-label="状态">
                        <span class="status-pill <?= e($stateClass) ?>"><?= e($stateText) ?></span>
                        <?php if (!empty($repo['admin_remark'])): ?><br><small><?= e($repo['admin_remark']) ?></small><?php endif; ?>
                    </td>
                    <td data-label="操作">
                        <div class="admin-repository-actions">
                            <a class="btn btn-ghost" href="<?= url('admin/repositories/detail?id=' . $repo['id']) ?>" data-icon="panel-top-open">详情</a>
                            <a class="btn btn-ghost" href="<?= e(public_url('r/' . $repo['slug'])) ?>" target="_blank" data-icon="external-link">打开</a>
                            <?php if (!empty($repo['admin_status'])): ?>
                                <form method="post" action="<?= url('admin/repositories/status') ?>" class="confirm-form admin-repository-status-form" data-confirm="确认下架这个分享仓库吗？访客将无法访问。">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                                    <input type="hidden" name="admin_status" value="0">
                                    <input name="admin_remark" placeholder="下架原因">
                                    <button class="btn btn-ghost" type="submit" data-icon="ban">下架</button>
                                </form>
                            <?php else: ?>
                                <form method="post" action="<?= url('admin/repositories/status') ?>" class="confirm-form admin-repository-status-form" data-confirm="确认恢复这个分享仓库吗？">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                                    <input type="hidden" name="admin_status" value="1">
                                    <input type="hidden" name="admin_remark" value="">
                                    <button class="btn btn-primary" type="submit" data-icon="rotate-ccw">恢复</button>
                                </form>
                            <?php endif; ?>
                            <form method="post" action="<?= url('admin/repositories/delete') ?>" class="confirm-form admin-repository-delete-form" data-confirm="确认删除这个分享仓库吗？只删除仓库、关联和日志，不删除用户原始文件。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                                <button class="btn btn-ghost" type="submit" data-icon="trash-2">删除</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($repositories)): ?>
                <tr><td colspan="10" class="responsive-table-span">暂无符合条件的分享仓库。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
