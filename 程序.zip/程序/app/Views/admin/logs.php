<?php
$filters = isset($filters) ? $filters : ['keyword' => '', 'date_start' => '', 'date_end' => ''];
$stats = isset($stats) ? $stats : ['total' => 0, 'today' => 0, 'admins' => 0, 'filtered_total' => 0];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">Audit Trail</p>
        <h1>管理员日志</h1>
        <p>记录后台关键操作，适合排查删改配置、人工补单、用户资料调整和资源管理行为。</p>
    </div>
    <a class="btn btn-primary" href="<?= url('admin/feature-audit') ?>" data-icon="radar">功能巡检</a>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>日志总数</span><b><?= e(number_format($stats['total'])) ?></b><small>后台操作累计</small></article>
    <article class="ops-metric-card glass ok"><span>今日操作</span><b><?= e(number_format($stats['today'])) ?></b><small>当日变更记录</small></article>
    <article class="ops-metric-card glass"><span>操作管理员</span><b><?= e(number_format($stats['admins'])) ?></b><small>产生过后台日志的账号</small></article>
    <article class="ops-metric-card glass warn"><span>筛选命中</span><b><?= e(number_format($stats['filtered_total'])) ?></b><small>当前条件结果</small></article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Filter</p>
            <h2>日志筛选</h2>
        </div>
    </div>
    <form method="get" action="<?= url('admin/logs') ?>" class="admin-filter-grid">
        <label>
            <span>关键词</span>
            <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="管理员 / 动作 / 对象 / IP">
        </label>
        <label>
            <span>开始日期</span>
            <input type="date" name="date_start" value="<?= e($filters['date_start']) ?>">
        </label>
        <label>
            <span>结束日期</span>
            <input type="date" name="date_end" value="<?= e($filters['date_end']) ?>">
        </label>
        <div class="filter-actions">
            <button class="btn btn-primary" type="submit" data-icon="search">查询</button>
            <a class="btn btn-ghost" href="<?= url('admin/logs') ?>" data-icon="rotate-ccw">重置</a>
        </div>
    </form>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Records</p>
            <h2>操作记录</h2>
            <p>最多展示最新 300 条记录。涉及密码、密钥、Token 的字段会在写入日志时脱敏。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>管理员</th>
                <th>动作</th>
                <th>对象</th>
                <th>IP 地址</th>
                <th>时间</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td data-label="ID">#<?= e($log['id']) ?></td>
                    <td data-label="管理员"><b><?= e($log['username'] ?: '未知管理员') ?></b><small><?= e($log['email'] ?: '-') ?></small></td>
                    <td data-label="动作"><?= e($log['action']) ?></td>
                    <td data-label="对象"><span class="status-pill soft"><?= e($log['target_type'] ?: '-') ?><?= $log['target_id'] ? ' #' . e($log['target_id']) : '' ?></span></td>
                    <td data-label="IP 地址"><?= e($log['ip']) ?></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?>
                <tr><td colspan="6" class="empty-table responsive-table-span">暂无符合条件的管理员日志。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
