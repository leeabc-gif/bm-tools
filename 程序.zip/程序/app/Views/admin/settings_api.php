<?php require APP_ROOT . '/app/Views/admin/partials/settings_nav.php'; ?>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">API</p>
        <h2>API 限制设置</h2>
        <p>这里只放 API 限流，不和别的系统设置混在一起。</p>
    </div>

    <form method="post" action="<?= url('admin/settings/api') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <label>API 每分钟限制
            <input name="api_rate_limit_per_minute" type="number" min="1" value="<?= e(isset($settings['api_rate_limit_per_minute']) ? $settings['api_rate_limit_per_minute'] : '60') ?>">
        </label>
        <label>API 每日限制
            <input name="api_rate_limit_per_day" type="number" min="1" value="<?= e(isset($settings['api_rate_limit_per_day']) ? $settings['api_rate_limit_per_day'] : '1000') ?>">
        </label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
        </div>
    </form>
</section>
