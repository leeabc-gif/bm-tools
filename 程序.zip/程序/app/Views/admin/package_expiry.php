<?php
$summary = isset($summary) && is_array($summary) ? $summary : ['expired' => 0, 'today' => 0, 'three_days' => 0, 'seven_days' => 0];
$expiringUsers = isset($expiringUsers) && is_array($expiringUsers) ? $expiringUsers : [];
$expiredUsers = isset($expiredUsers) && is_array($expiredUsers) ? $expiredUsers : [];
$days = isset($days) ? (int) $days : 7;
$daysLeft = function ($time) {
    $seconds = strtotime((string) $time) - time();
    return max(0, (int) ceil($seconds / 86400));
};
?>

<section class="bm-admin-dashboard package-expiry-page">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Retention</span>
            <h1>套餐到期提醒</h1>
            <p>集中查看即将到期和已经到期的用户，支持手动发送站内续费提醒，减少权益突然中断导致的流失。</p>
        </div>
        <div class="bm-action-row">
            <form method="post" action="<?= url('admin/package-expiry/remind') ?>" class="package-expiry-action-form">
                <?= csrf_field() ?>
                <input type="hidden" name="days" value="<?= e($days) ?>">
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="send">发送提醒</button>
            </form>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/users') ?>" data-icon="users">用户管理</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/packages') ?>" data-icon="package">套餐管理</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric is-red"><span class="bm-icon-tile"><i data-lucide="calendar-x"></i></span><div><small>已到期</small><strong><?= e(number_format((int) $summary['expired'])) ?></strong><em>需要续费或降级处理</em></div></article>
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="clock-3"></i></span><div><small>今日到期</small><strong><?= e(number_format((int) $summary['today'])) ?></strong><em>建议立即提醒</em></div></article>
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="calendar-clock"></i></span><div><small>3 天内</small><strong><?= e(number_format((int) $summary['three_days'])) ?></strong><em>高优先级续费</em></div></article>
        <article class="bm-admin-metric is-blue"><span class="bm-icon-tile"><i data-lucide="calendar-days"></i></span><div><small>7 天内</small><strong><?= e(number_format((int) $summary['seven_days'])) ?></strong><em>提前运营触达</em></div></article>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Filter</span>
                <h2>提醒范围</h2>
            </div>
        </div>
        <div class="package-expiry-range">
            <?php foreach ([3, 7, 15, 30] as $option): ?>
                <a class="<?= $days === $option ? 'active' : '' ?>" href="<?= url('admin/package-expiry?days=' . $option) ?>"><?= e($option) ?> 天内</a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Upcoming</span>
                <h2>即将到期用户</h2>
            </div>
            <span class="bm-muted-text">当前展示 <?= e($days) ?> 天内即将到期的用户</span>
        </div>
        <div class="package-expiry-list">
            <?php foreach ($expiringUsers as $user): ?>
                <article class="package-expiry-user">
                    <div class="package-expiry-user-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="user"></i></span>
                        <div>
                            <strong><?= e($user['nickname'] ?: $user['username']) ?></strong>
                            <small><?= e($user['email']) ?> · <?= e($user['package_name'] ?: '未绑定套餐') ?></small>
                        </div>
                    </div>
                    <div class="package-expiry-user-meta">
                        <span><b><?= e($daysLeft($user['package_expire_time'])) ?></b><small>剩余天数</small></span>
                        <span><b><?= e($user['package_expire_time']) ?></b><small>到期时间</small></span>
                        <span><b>￥<?= e(number_format((float) $user['balance'], 2)) ?></b><small>余额</small></span>
                    </div>
                    <a class="bm-btn bm-btn-soft" href="<?= url('admin/users?keyword=' . urlencode($user['username'])) ?>" data-icon="external-link">查看用户</a>
                </article>
            <?php endforeach; ?>
            <?php if (!$expiringUsers): ?>
                <div class="bm-empty-line">当前范围内没有即将到期的用户。</div>
            <?php endif; ?>
        </div>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Expired</span>
                <h2>已到期用户</h2>
            </div>
            <span class="bm-muted-text">建议检查是否需要降级、续费或人工跟进</span>
        </div>
        <div class="package-expiry-list is-expired">
            <?php foreach ($expiredUsers as $user): ?>
                <article class="package-expiry-user is-expired">
                    <div class="package-expiry-user-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="calendar-x"></i></span>
                        <div>
                            <strong><?= e($user['nickname'] ?: $user['username']) ?></strong>
                            <small><?= e($user['email']) ?> · <?= e($user['package_name'] ?: '未绑定套餐') ?></small>
                        </div>
                    </div>
                    <div class="package-expiry-user-meta">
                        <span><b><?= e($user['package_expire_time']) ?></b><small>到期时间</small></span>
                        <span><b>￥<?= e(number_format((float) $user['balance'], 2)) ?></b><small>余额</small></span>
                    </div>
                    <a class="bm-btn bm-btn-soft" href="<?= url('admin/users?keyword=' . urlencode($user['username'])) ?>" data-icon="external-link">查看用户</a>
                </article>
            <?php endforeach; ?>
            <?php if (!$expiredUsers): ?>
                <div class="bm-empty-line">暂无已到期用户。</div>
            <?php endif; ?>
        </div>
    </section>
</section>
