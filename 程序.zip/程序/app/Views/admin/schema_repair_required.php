<?php
$featureLabel = isset($featureLabel) ? $featureLabel : '当前功能';
$detail = isset($detail) ? $detail : '当前功能依赖的数据表或字段没有准备完成。';
$repairUrl = isset($repairUrl) ? $repairUrl : 'admin/maintenance/schema-audit';
$maintenanceUrl = isset($maintenanceUrl) ? $maintenanceUrl : 'admin/maintenance';
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">Database Repair</p>
        <h1><?= e($featureLabel) ?>需要数据库修复</h1>
        <p><?= e($detail) ?></p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-primary" href="<?= url($repairUrl) ?>" data-icon="database-zap">进入数据库巡检</a>
        <a class="btn btn-ghost" href="<?= url($maintenanceUrl) ?>" data-icon="wrench">系统维护</a>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Next Step</p>
            <h2>处理方式</h2>
            <p>点击“进入数据库巡检”，执行数据库一键修复。修复完成后刷新当前菜单即可继续使用。</p>
        </div>
    </div>
    <div class="storage-backup-steps">
        <article><b>1</b><span><strong>先执行巡检</strong><small>系统会检测缺失的数据表、字段和索引。</small></span></article>
        <article><b>2</b><span><strong>点击一键修复</strong><small>自动补齐当前版本需要的数据库结构。</small></span></article>
        <article><b>3</b><span><strong>回到功能页面</strong><small>刷新后台菜单页面，功能会继续加载。</small></span></article>
    </div>
</section>
