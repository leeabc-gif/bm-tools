<?php
$report = isset($report) && is_array($report) ? $report : [];
$summary = isset($report['summary']) && is_array($report['summary']) ? $report['summary'] : [];
$servers = isset($report['servers']) && is_array($report['servers']) ? $report['servers'] : [];
$worst = isset($report['worst']) && is_array($report['worst']) ? $report['worst'] : [];
$recentAlerts = isset($report['recent_alerts']) && is_array($report['recent_alerts']) ? $report['recent_alerts'] : [];
$days = isset($report['days']) ? (int) $report['days'] : 7;
$since = isset($report['since']) ? $report['since'] : '';

$slaLabel = function ($value) {
    return $value === null ? '暂无样本' : number_format((float) $value, 2) . '%';
};
$meterWidth = function ($value) {
    if ($value === null) {
        return 0;
    }
    return max(0, min(100, (float) $value));
};
$metricLabel = function ($value) {
    return $value === null ? '-' : number_format((float) $value, 1) . '%';
};
$timeLabel = function ($value) {
    return $value ? date('m-d H:i', strtotime((string) $value)) : '-';
};
$statusText = [
    'online' => '在线',
    'offline' => '离线',
    'unknown' => '未知',
];
$levelText = [
    'good' => '稳定',
    'warning' => '关注',
    'danger' => '异常',
    'muted' => '待采集',
];
$collectText = [
    'normal' => '采集正常',
    'delayed' => '采集超时',
    'disabled' => '已停用',
];
?>

<section class="bm-admin-dashboard monitor-sla-page">
    <header class="bm-admin-hero monitor-sla-hero">
        <div>
            <span class="bm-eyebrow">Service Reliability</span>
            <h1>监控 SLA 统计</h1>
            <p>独立统计后台添加的本站运营服务器，不混入用户自建 SSH/Agent 服务器。统计口径基于成功采集样本和连接失败告警，适合快速判断节点稳定性和采集任务是否正常。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-primary" href="<?= url('admin/monitors') ?>" data-icon="server">服务器管理</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/monitor-sla/export?days=' . $days) ?>" data-icon="download">导出 CSV</a>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/screen') ?>" data-icon="monitor-smartphone">数据大屏</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric is-green">
            <span class="bm-icon-tile"><i data-lucide="shield-check"></i></span>
            <div>
                <small>平均 SLA</small>
                <strong><?= e($slaLabel(isset($summary['average_sla']) ? $summary['average_sla'] : null)) ?></strong>
                <em><?= e($days) ?> 天节点平均可用率</em>
            </div>
        </article>
        <article class="bm-admin-metric is-blue">
            <span class="bm-icon-tile"><i data-lucide="activity"></i></span>
            <div>
                <small>成功采集</small>
                <strong><?= e(number_format((int) (isset($summary['success_samples']) ? $summary['success_samples'] : 0))) ?></strong>
                <em>总样本 <?= e(number_format((int) (isset($summary['sample_count']) ? $summary['sample_count'] : 0))) ?></em>
            </div>
        </article>
        <article class="bm-admin-metric is-orange">
            <span class="bm-icon-tile"><i data-lucide="bell-ring"></i></span>
            <div>
                <small>告警事件</small>
                <strong><?= e(number_format((int) (isset($summary['alert_count']) ? $summary['alert_count'] : 0))) ?></strong>
                <em>连接失败 <?= e(number_format((int) (isset($summary['failure_samples']) ? $summary['failure_samples'] : 0))) ?></em>
            </div>
        </article>
        <article class="bm-admin-metric is-red">
            <span class="bm-icon-tile"><i data-lucide="triangle-alert"></i></span>
            <div>
                <small>采集风险</small>
                <strong><?= e(number_format((int) (isset($summary['below_99']) ? $summary['below_99'] : 0))) ?></strong>
                <em>超时 <?= e(number_format((int) (isset($summary['collect_delayed']) ? $summary['collect_delayed'] : 0))) ?> 台 / 无样本 <?= e(number_format((int) (isset($summary['no_data']) ? $summary['no_data'] : 0))) ?> 台</em>
            </div>
        </article>
    </section>

    <section class="bm-admin-panel monitor-sla-filter">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Range</span>
                <h2>统计范围</h2>
            </div>
            <span class="bm-muted-text">起始时间：<?= e($since ?: '-') ?></span>
        </div>
        <div class="monitor-sla-range">
            <?php foreach ([7, 30, 90] as $option): ?>
                <a class="<?= $days === $option ? 'active' : '' ?>" href="<?= url('admin/monitor-sla?days=' . $option) ?>">
                    <i data-lucide="<?= $option === 7 ? 'calendar-days' : ($option === 30 ? 'calendar-range' : 'history') ?>"></i>
                    <span><?= e($option) ?> 天</span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php if ((int) (isset($summary['no_data']) ? $summary['no_data'] : 0) > 0 || (int) (isset($summary['collect_delayed']) ? $summary['collect_delayed'] : 0) > 0): ?>
            <div class="monitor-sla-inline-alert">
                <span><i data-lucide="timer-reset"></i></span>
                <div>
                    <strong>有 <?= e((int) (isset($summary['collect_delayed']) ? $summary['collect_delayed'] : 0)) ?> 台节点采集超时，<?= e((int) (isset($summary['no_data']) ? $summary['no_data'] : 0)) ?> 台节点暂无 SLA 样本</strong>
                    <small>请检查“服务器管理”里的采集链接是否已经加入计划任务，或手动执行一次强制采集。采集超时会影响 SLA 判断和告警可信度。</small>
                </div>
                <a class="bm-btn bm-btn-soft" href="<?= url('admin/monitors') ?>" data-icon="external-link">去检查</a>
            </div>
        <?php endif; ?>
    </section>

    <section class="bm-admin-main-grid monitor-sla-layout">
        <article class="bm-admin-panel monitor-sla-list-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Nodes</span>
                    <h2>节点明细</h2>
                </div>
                <span class="bm-muted-text">共 <?= e(number_format((int) (isset($summary['total']) ? $summary['total'] : count($servers)))) ?> 台</span>
            </div>

            <div class="monitor-sla-list">
                <?php foreach ($servers as $server): ?>
                    <?php
                    $sla = isset($server['sla_percent']) ? $server['sla_percent'] : null;
                    $level = isset($server['health_level']) ? $server['health_level'] : 'muted';
                    $status = isset($server['status']) ? $server['status'] : 'unknown';
                    $collectStatus = isset($server['collect_status']) ? $server['collect_status'] : 'normal';
                    ?>
                    <article class="monitor-sla-row is-<?= e($level) ?>">
                        <div class="monitor-sla-node">
                            <span class="bm-icon-tile is-small"><i data-lucide="server"></i></span>
                            <div>
                                <strong><?= e($server['name']) ?></strong>
                                <small><?= e($server['server_ip'] ?: parse_url((string) $server['panel_url'], PHP_URL_HOST) ?: '未填写 IP') ?></small>
                            </div>
                        </div>
                        <div class="monitor-sla-score">
                            <div>
                                <strong><?= e($slaLabel($sla)) ?></strong>
                                <span><?= e(isset($levelText[$level]) ? $levelText[$level] : '待采集') ?></span>
                            </div>
                            <em class="monitor-sla-bar"><i style="width: <?= e($meterWidth($sla)) ?>%"></i></em>
                        </div>
                        <div class="monitor-sla-stats">
                            <span><b><?= e(number_format((int) $server['success_samples'])) ?></b><small>成功</small></span>
                            <span><b><?= e(number_format((int) $server['failure_samples'])) ?></b><small>失败</small></span>
                            <span><b><?= e(number_format((int) $server['alert_count'])) ?></b><small>告警</small></span>
                        </div>
                        <div class="monitor-sla-load">
                            <span>CPU <?= e($metricLabel($server['avg_cpu'])) ?></span>
                            <span>内存 <?= e($metricLabel($server['avg_memory'])) ?></span>
                            <span>磁盘 <?= e($metricLabel($server['avg_disk'])) ?></span>
                        </div>
                        <div class="monitor-sla-meta">
                            <em class="bm-state-pill is-<?= e($status) ?>"><?= e(isset($statusText[$status]) ? $statusText[$status] : $status) ?></em>
                            <small>最近采集 <?= e($timeLabel($server['last_sample_at'])) ?></small>
                            <small class="monitor-sla-collect is-<?= e($collectStatus) ?>"><?= e(isset($collectText[$collectStatus]) ? $collectText[$collectStatus] : $collectStatus) ?><?= $collectStatus === 'delayed' && $server['collect_delay_minutes'] !== null ? ' · ' . e((int) $server['collect_delay_minutes']) . ' 分钟未更新' : '' ?></small>
                        </div>
                    </article>
                <?php endforeach; ?>
                <?php if (!$servers): ?>
                    <div class="bm-empty-line">还没有添加本站运营服务器。请先进入服务器管理添加节点并执行一次采集。</div>
                <?php endif; ?>
            </div>
        </article>

        <aside class="bm-admin-panel monitor-sla-side">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Risk</span>
                    <h2>风险排行</h2>
                </div>
            </div>
            <div class="monitor-sla-risk-list">
                <?php foreach ($worst as $index => $server): ?>
                    <?php
                    $sla = isset($server['sla_percent']) ? $server['sla_percent'] : null;
                    $level = isset($server['health_level']) ? $server['health_level'] : 'muted';
                    ?>
                    <a href="<?= url('admin/monitors?id=' . (int) $server['id']) ?>" class="monitor-sla-risk is-<?= e($level) ?>">
                        <span><?= e($index + 1) ?></span>
                        <div>
                            <strong><?= e($server['name']) ?></strong>
                            <small><?= e(number_format((int) $server['alert_count'])) ?> 次告警 / <?= e(number_format((int) $server['sample_count'])) ?> 个样本</small>
                        </div>
                        <b><?= e($slaLabel($sla)) ?></b>
                    </a>
                <?php endforeach; ?>
                <?php if (!$worst): ?>
                    <div class="bm-empty-line">暂无可排序节点。</div>
                <?php endif; ?>
            </div>

            <div class="monitor-sla-note">
                <span><i data-lucide="info"></i></span>
                <p>失败采集通常只会生成告警，不会写入指标表；因此本页用“成功指标样本 + 连接失败告警”估算采样可用率。若采集任务长期未访问，节点会显示为暂无样本。</p>
            </div>
        </aside>
    </section>

    <section class="bm-admin-panel monitor-sla-alert-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Timeline</span>
                <h2>最近告警时间线</h2>
            </div>
            <span class="bm-muted-text">展示当前统计范围内最近 10 条告警</span>
        </div>
        <div class="monitor-sla-alert-list">
            <?php foreach ($recentAlerts as $alert): ?>
                <article class="monitor-sla-alert is-<?= e(isset($alert['level']) ? $alert['level'] : 'warning') ?>">
                    <span class="monitor-sla-alert-dot"><i data-lucide="<?= (isset($alert['level']) && $alert['level'] === 'danger') ? 'triangle-alert' : 'bell' ?>"></i></span>
                    <div>
                        <strong><?= e($alert['server_name'] ?: '未知节点') ?></strong>
                        <p><?= e($alert['title'] ?: $alert['metric']) ?></p>
                        <?php if (!empty($alert['content'])): ?><small><?= e(text_limit((string) $alert['content'], 120)) ?></small><?php endif; ?>
                    </div>
                    <em><?= e($timeLabel($alert['created_at'])) ?></em>
                </article>
            <?php endforeach; ?>
            <?php if (!$recentAlerts): ?>
                <div class="bm-empty-line">当前统计范围内没有告警记录。</div>
            <?php endif; ?>
        </div>
    </section>
</section>
