<?php
$files = isset($files) && is_array($files) ? $files : [];
$filters = isset($filters) ? $filters : ['keyword' => '', 'type' => '', 'storage_id' => 0, 'user' => '', 'date_start' => '', 'date_end' => ''];
$stats = isset($stats) ? $stats : ['total' => 0, 'images' => 0, 'files' => 0, 'today' => 0, 'size' => 0, 'filtered_total' => 0, 'filtered_size' => 0];
$storages = isset($storages) ? $storages : [];
$storageStats = isset($storageStats) ? $storageStats : [];
$typeLabels = ['image' => '图片', 'file' => '文件'];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">Resource Center</p>
        <h1>文件管理</h1>
        <p>统一查看图床、网盘、分享仓库使用到的文件资产。支持按用户、类型、存储源和时间筛选，便于排查异常上传、存储占用和链接访问问题。</p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/storages') ?>" data-icon="database">存储配置</a>
        <a class="btn btn-primary" href="<?= url('admin/repositories') ?>" data-icon="library">分享仓库</a>
    </div>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>文件总数</span><b><?= e(number_format($stats['total'])) ?></b><small>全站托管资产</small></article>
    <article class="ops-metric-card glass ok"><span>图片资源</span><b><?= e(number_format($stats['images'])) ?></b><small>图床与预览类内容</small></article>
    <article class="ops-metric-card glass"><span>普通文件</span><b><?= e(number_format($stats['files'])) ?></b><small>网盘与附件内容</small></article>
    <article class="ops-metric-card glass"><span>总占用</span><b><?= e(format_bytes($stats['size'])) ?></b><small>今日新增 <?= e(number_format($stats['today'])) ?> 个</small></article>
</section>

<section class="bm-admin-screen-grid">
    <article class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Asset Summary</span>
                <h2>内容资产摘要</h2>
            </div>
        </div>
        <div class="bm-admin-screen-summary-grid">
            <div class="bm-admin-screen-summary-item"><span>筛选结果</span><strong><?= e(number_format((int) $stats['filtered_total'])) ?></strong><small>当前条件下命中的文件记录</small></div>
            <div class="bm-admin-screen-summary-item"><span>筛选占用</span><strong><?= e(format_bytes((int) $stats['filtered_size'])) ?></strong><small>适合排查异常空间占用</small></div>
            <div class="bm-admin-screen-summary-item"><span>当日新增</span><strong><?= e(number_format((int) $stats['today'])) ?></strong><small>用于观察上传活跃度与热点内容</small></div>
        </div>
    </article>

    <article class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Ops Advice</span>
                <h2>运营建议</h2>
            </div>
        </div>
        <div class="bm-admin-screen-list bm-admin-settings-actions">
            <div><span>大文件巡查</span><strong>优先筛选近 7 天高体积上传</strong></div>
            <div><span>异常来源</span><strong>结合用户筛选快速定位滥用账号</strong></div>
            <div><span>存储优化</span><strong>观察默认存储和高占用存储的分布差异</strong></div>
            <div><span>内容治理</span><strong>结合仓库与分站模块做联动排查</strong></div>
        </div>
    </article>
</section>

<section class="admin-files-layout">
    <article class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">Filter</p>
                <h2>筛选文件</h2>
                <p>当前条件命中 <?= e(number_format($stats['filtered_total'])) ?> 个文件，占用 <?= e(format_bytes($stats['filtered_size'])) ?>。</p>
            </div>
        </div>
        <form method="get" action="<?= url('admin/files') ?>" class="admin-filter-grid">
            <label>
                <span>文件关键词</span>
                <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="文件名 / 扩展名 / MIME / MD5">
            </label>
            <label>
                <span>用户</span>
                <input name="user" value="<?= e($filters['user']) ?>" placeholder="用户名 / 邮箱 / 用户ID">
            </label>
            <label>
                <span>文件类型</span>
                <select name="type">
                    <option value="">全部类型</option>
                    <?php foreach ($typeLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $filters['type'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>存储源</span>
                <select name="storage_id">
                    <option value="0">全部存储</option>
                    <?php foreach ($storages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>" <?= (int) $filters['storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>>
                            <?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>开始日期</span>
                <input type="date" name="date_start" value="<?= e($filters['date_start']) ?>">
            </label>
            <label>
                <span>结束日期</span>
                <input type="date" name="date_end" value="<?= e($filters['date_end']) ?>">
            </label>
            <div class="filter-actions">
                <button class="btn btn-primary" type="submit" data-icon="search">查询</button>
                <a class="btn btn-ghost" href="<?= url('admin/files') ?>" data-icon="rotate-ccw">重置</a>
            </div>
        </form>
    </article>

    <aside class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Storage</p>
                <h2>存储分布</h2>
            </div>
        </div>
        <div class="admin-rank-list">
            <?php foreach ($storageStats as $item): ?>
                <div>
                    <span>
                        <b><?= e($item['name']) ?></b>
                        <small><?= e(strtoupper($item['type'])) ?> · <?= e(number_format($item['total'])) ?> 个</small>
                    </span>
                    <strong><?= e(format_bytes($item['size'])) ?></strong>
                </div>
            <?php endforeach; ?>
            <?php if (!$storageStats): ?>
                <p class="empty-table">暂无文件占用数据。</p>
            <?php endif; ?>
        </div>
    </aside>
</section>

<section class="table-card glass admin-file-list-card">
    <div class="section-head">
        <div>
            <p class="eyebrow">Assets</p>
            <h2>文件列表</h2>
            <p>最多展示最新 300 条记录。删除会同步尝试删除远端对象，请先确认用户与文件归属。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>文件</th>
                <th>用户</th>
                <th>类型</th>
                <th>大小</th>
                <th>存储</th>
                <th>访问</th>
                <th>时间</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($files as $file): ?>
                <?php
                $fileUrl = public_url($file['file_url']);
                $isImage = $file['file_type'] === 'image';
                ?>
                <tr>
                    <td data-label="ID">#<?= e($file['id']) ?></td>
                    <td data-label="文件">
                        <div class="admin-file-cell">
                            <span class="admin-file-thumb <?= $isImage ? 'is-image' : '' ?>">
                                <?php if ($isImage): ?>
                                    <img src="<?= e(public_url($file['thumbnail_url'] ?: $file['file_url'])) ?>" alt="<?= e($file['original_name']) ?>" loading="lazy">
                                <?php else: ?>
                                    <i data-lucide="file"></i>
                                <?php endif; ?>
                            </span>
                            <span>
                                <b title="<?= e($file['original_name']) ?>"><?= e($file['original_name']) ?></b>
                                <small><?= e($file['file_ext'] ?: '-') ?> · <?= e($file['mime_type'] ?: '-') ?></small>
                                <?php if (!empty($file['md5'])): ?><small>MD5 <?= e($file['md5']) ?></small><?php endif; ?>
                            </span>
                        </div>
                    </td>
                    <td data-label="用户">
                        <b><?= e($file['username'] ?: '游客/未知') ?></b>
                        <small><?= e($file['email'] ?: ('UID ' . $file['user_id'])) ?></small>
                    </td>
                    <td data-label="类型"><span class="status-pill soft"><?= e(isset($typeLabels[$file['file_type']]) ? $typeLabels[$file['file_type']] : $file['file_type']) ?></span></td>
                    <td data-label="大小"><?= e(format_bytes($file['file_size'])) ?></td>
                    <td data-label="存储">
                        <b><?= e($file['storage_name'] ?: '未绑定') ?></b>
                        <small><?= e(strtoupper($file['storage_type'] ?: 'unknown')) ?></small>
                    </td>
                    <td data-label="访问">
                        <a class="btn btn-ghost btn-sm" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener" data-icon="external-link">打开</a>
                    </td>
                    <td data-label="时间"><?= e($file['created_at']) ?></td>
                    <td data-label="操作">
                        <form method="post" action="<?= url('admin/files/delete') ?>" class="confirm-form" data-confirm="确认删除这个文件记录吗？如果远端对象存在，系统也会尝试同步删除。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                            <button class="btn btn-ghost danger" type="submit" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$files): ?>
                <tr><td colspan="9" class="empty-table responsive-table-span">没有找到符合条件的文件。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
