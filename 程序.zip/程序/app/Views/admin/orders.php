<?php
$methodNames = ['manual' => '人工充值', 'alipay' => '支付宝', 'wechat' => '微信支付', 'epay' => '易支付', 'balance' => '余额', 'card_code' => '卡密'];
$orders = isset($orders) && is_array($orders) ? $orders : [];
$filters = isset($filters) ? $filters : ['keyword' => '', 'status' => '', 'type' => '', 'payment_method' => ''];
$orderStats = isset($orderStats) ? $orderStats : ['total' => 0, 'pending' => 0, 'paid' => 0, 'today' => 0, 'revenue' => 0];
$filteredStats = isset($filteredStats) ? $filteredStats : ['total' => count($orders), 'pending' => 0, 'paid' => 0, 'recharge' => 0, 'package' => 0, 'amount' => 0];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">订单运营</p>
        <h1>订单管理</h1>
        <p>围绕支付状态、订单来源和人工补单场景做集中运营，方便快速发现待处理订单与收入异常。</p>
    </div>
    <a class="bm-btn bm-btn-soft" href="<?= url('admin/orders/export') ?>" data-icon="download">导出订单</a>
</section>

<section class="bm-admin-metric-grid bm-admin-workbench-metrics">
    <article class="bm-admin-metric is-blue"><span class="bm-icon-tile"><i data-lucide="receipt-text"></i></span><div><small>订单总数</small><strong><?= e(number_format((int) $orderStats['total'])) ?></strong><em>当前筛选 <?= e(number_format((int) $filteredStats['total'])) ?></em></div></article>
    <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="loader-circle"></i></span><div><small>待处理</small><strong><?= e(number_format((int) $orderStats['pending'])) ?></strong><em>当前筛选 <?= e(number_format((int) $filteredStats['pending'])) ?></em></div></article>
    <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="badge-check"></i></span><div><small>已支付</small><strong><?= e(number_format((int) $orderStats['paid'])) ?></strong><em>今日新增 <?= e(number_format((int) $orderStats['today'])) ?></em></div></article>
    <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="badge-yen-sign"></i></span><div><small>累计成交</small><strong>¥<?= e(number_format((float) $orderStats['revenue'], 2)) ?></strong><em>当前筛选 ¥<?= e(number_format((float) $filteredStats['amount'], 2)) ?></em></div></article>
</section>

<form class="bm-admin-filter-bar glass" method="get" action="<?= url('admin/orders') ?>">
    <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索订单号 / 用户 / 交易号">
    <select name="status">
        <option value="">全部状态</option>
        <option value="pending" <?= $filters['status'] === 'pending' ? 'selected' : '' ?>>待处理</option>
        <option value="paid" <?= $filters['status'] === 'paid' ? 'selected' : '' ?>>已支付</option>
        <option value="rejected" <?= $filters['status'] === 'rejected' ? 'selected' : '' ?>>已拒绝</option>
    </select>
    <select name="type">
        <option value="">全部类型</option>
        <option value="recharge" <?= $filters['type'] === 'recharge' ? 'selected' : '' ?>>充值订单</option>
        <option value="package" <?= $filters['type'] === 'package' ? 'selected' : '' ?>>套餐订单</option>
    </select>
    <select name="payment_method">
        <option value="">全部支付方式</option>
        <?php foreach ($methodNames as $value => $label): ?>
            <option value="<?= e($value) ?>" <?= $filters['payment_method'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="bm-btn bm-btn-primary" type="submit" data-icon="search">筛选</button>
    <a class="bm-btn bm-btn-soft" href="<?= url('admin/orders') ?>" data-icon="rotate-ccw">重置</a>
</form>

<section class="bm-admin-order-tools">
    <article class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Manual Fix</span>
                <h2>手动补单</h2>
            </div>
        </div>
        <form method="post" action="<?= url('admin/orders/manual-paid') ?>" class="bm-inline-form">
            <?= csrf_field() ?>
            <input name="order_no" placeholder="输入充值订单号，例如 R202605110001" required>
            <button class="bm-btn bm-btn-primary" data-icon="badge-check">补单入账</button>
        </form>
    </article>
    <article class="bm-card bm-card-soft">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Business Summary</span>
                <h2>运营摘要</h2>
            </div>
        </div>
        <div class="bm-record-meta bm-record-meta-summary">
            <span><b>充值订单</b><?= e(number_format((int) $filteredStats['recharge'])) ?></span>
            <span><b>套餐订单</b><?= e(number_format((int) $filteredStats['package'])) ?></span>
            <span><b>待处理占比</b><?= e($filteredStats['total'] > 0 ? number_format(((int) $filteredStats['pending'] / (int) $filteredStats['total']) * 100, 1) : '0.0') ?>%</span>
            <span><b>支付完成率</b><?= e($filteredStats['total'] > 0 ? number_format(((int) $filteredStats['paid'] / (int) $filteredStats['total']) * 100, 1) : '0.0') ?>%</span>
        </div>
    </article>
</section>

<section class="bm-admin-record-list">
    <?php if (!$orders): ?>
        <article class="bm-empty-state">
            <i data-lucide="receipt-text"></i>
            <strong>暂无订单记录</strong>
            <span>用户充值或购买套餐后，订单会显示在这里。</span>
        </article>
    <?php endif; ?>

    <?php foreach ($orders as $o): ?>
        <article class="bm-admin-record-card">
            <header>
                <div class="bm-record-main">
                    <span class="bm-icon-tile is-small"><i data-lucide="<?= $o['type'] === 'recharge' ? 'wallet-cards' : 'package' ?>"></i></span>
                    <div>
                        <strong><?= e($o['order_no']) ?></strong>
                        <small><?= e($o['username'] ?: '-') ?> · <?= e($o['created_at']) ?></small>
                    </div>
                </div>
                <a class="bm-btn bm-btn-soft" href="<?= url('admin/orders/' . $o['id']) ?>" data-icon="search">详情</a>
            </header>
            <div class="bm-record-meta">
                <span><b>类型</b><?= e($o['type'] === 'recharge' ? '充值' : '套餐') ?></span>
                <span><b>套餐</b><?= e($o['package_name'] ?: '-') ?></span>
                <span><b>金额</b>¥<?= e($o['pay_amount']) ?></span>
                <span><b>支付方式</b><?= e(isset($methodNames[$o['payment_method']]) ? $methodNames[$o['payment_method']] : ($o['payment_method'] ?: '-')) ?></span>
                <span><b>状态</b><em class="bm-state-pill"><?= e($o['status']) ?></em></span>
                <span><b>交易号</b><?= e($o['trade_no'] ?: '-') ?></span>
            </div>
        </article>
    <?php endforeach; ?>
</section>
