<?php
$methodNames = ['manual' => '人工充值', 'alipay' => '支付宝', 'wechat' => '微信支付', 'epay' => '易支付', 'card_code' => '卡密'];
$recharges = isset($recharges) && is_array($recharges) ? $recharges : [];
$filters = isset($filters) ? $filters : ['keyword' => '', 'status' => '', 'payment_method' => ''];
$rechargeStats = isset($rechargeStats) ? $rechargeStats : ['total' => 0, 'pending' => 0, 'paid' => 0, 'rejected' => 0, 'amount_paid' => 0];
$filteredStats = isset($filteredStats) ? $filteredStats : ['total' => count($recharges), 'pending' => 0, 'paid' => 0, 'rejected' => 0, 'amount' => 0];
$auditScene = function (array $row) {
    $remark = isset($row['audit_remark']) ? (string) $row['audit_remark'] : '';
    $hasCreateFailure = $remark !== '' && (function_exists('mb_strpos') ? mb_strpos($remark, '支付创建失败') !== false : strpos($remark, '支付创建失败') !== false);
    if ($hasCreateFailure) {
        return '支付创建异常';
    }
    if ($row['payment_method'] === 'manual') {
        return '人工审核待处理';
    }
    return '系统待确认';
};
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">充值审核</p>
        <h1>充值管理</h1>
        <p>优先处理待审核充值，减少人工到账等待时间，并持续观察人工收款链路的通过率与异常原因。</p>
    </div>
    <a class="bm-btn bm-btn-soft" href="<?= url('admin/payments') ?>" data-icon="credit-card">支付配置</a>
</section>

<section class="bm-admin-metric-grid bm-admin-workbench-metrics">
    <article class="bm-admin-metric is-blue"><span class="bm-icon-tile"><i data-lucide="wallet-cards"></i></span><div><small>充值总数</small><strong><?= e(number_format((int) $rechargeStats['total'])) ?></strong><em>当前筛选 <?= e(number_format((int) $filteredStats['total'])) ?></em></div></article>
    <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="clock-3"></i></span><div><small>待审核</small><strong><?= e(number_format((int) $rechargeStats['pending'])) ?></strong><em>当前筛选 <?= e(number_format((int) $filteredStats['pending'])) ?></em></div></article>
    <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="badge-check"></i></span><div><small>已到账</small><strong><?= e(number_format((int) $rechargeStats['paid'])) ?></strong><em>已拒绝 <?= e(number_format((int) $rechargeStats['rejected'])) ?></em></div></article>
    <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="coins"></i></span><div><small>累计到账</small><strong>¥<?= e(number_format((float) $rechargeStats['amount_paid'], 2)) ?></strong><em>当前筛选 ¥<?= e(number_format((float) $filteredStats['amount'], 2)) ?></em></div></article>
</section>

<form class="bm-admin-filter-bar glass" method="get" action="<?= url('admin/recharges') ?>">
    <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索用户 / 订单号 / 记录ID">
    <select name="status">
        <option value="">全部状态</option>
        <option value="pending" <?= $filters['status'] === 'pending' ? 'selected' : '' ?>>待审核</option>
        <option value="paid" <?= $filters['status'] === 'paid' ? 'selected' : '' ?>>已到账</option>
        <option value="rejected" <?= $filters['status'] === 'rejected' ? 'selected' : '' ?>>已拒绝</option>
    </select>
    <select name="payment_method">
        <option value="">全部方式</option>
        <?php foreach ($methodNames as $value => $label): ?>
            <option value="<?= e($value) ?>" <?= $filters['payment_method'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="bm-btn bm-btn-primary" type="submit" data-icon="search">筛选</button>
    <a class="bm-btn bm-btn-soft" href="<?= url('admin/recharges') ?>" data-icon="rotate-ccw">重置</a>
</form>

<section class="bm-admin-record-list">
    <?php if (!$recharges): ?>
        <article class="bm-empty-state">
            <i data-lucide="wallet-cards"></i>
            <strong>暂无充值记录</strong>
            <span>用户提交充值后会显示在这里。</span>
        </article>
    <?php endif; ?>

    <?php foreach ($recharges as $r): ?>
        <article class="bm-admin-record-card">
            <header>
                <div class="bm-record-main">
                    <span class="bm-icon-tile is-small"><i data-lucide="wallet-cards"></i></span>
                    <div>
                        <strong>¥<?= e($r['amount']) ?></strong>
                        <small><?= e($r['username'] ?: '-') ?> · <?= e($r['created_at']) ?></small>
                    </div>
                </div>
                <em class="bm-state-pill"><?= e($r['status']) ?></em>
            </header>
            <div class="bm-record-meta">
                <span><b>ID</b><?= e($r['id']) ?></span>
                <span><b>订单号</b><?= e($r['order_no']) ?></span>
                <span><b>支付方式</b><?= e(isset($methodNames[$r['payment_method']]) ? $methodNames[$r['payment_method']] : $r['payment_method']) ?></span>
                <span><b>状态</b><em class="bm-state-pill"><?= e($r['status']) ?></em></span>
                <span><b>场景</b><?= e($auditScene($r)) ?></span>
                <?php if (!empty($r['audit_remark'])): ?>
                    <span><b>备注</b><?= e($r['audit_remark']) ?></span>
                <?php endif; ?>
            </div>
            <?php if ($r['status'] === 'pending'): ?>
                <form method="post" action="<?= url('admin/recharges/audit') ?>" class="bm-admin-audit-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($r['id']) ?>">
                    <input name="remark" placeholder="审核备注，可留空">
                    <button class="bm-btn bm-btn-primary" name="action" value="approve" data-icon="check">通过</button>
                    <button class="bm-btn bm-btn-danger" name="action" value="reject" data-icon="x">拒绝</button>
                </form>
            <?php else: ?>
                <p class="bm-muted">该充值记录已处理。</p>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>
</section>
