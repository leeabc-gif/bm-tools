<?php
$fmt = function ($bytes) {
    return function_exists('format_bytes') ? format_bytes((float) $bytes) : number_format((float) $bytes / 1048576, 1) . ' MB';
};
$filters = isset($filters) ? $filters : ['keyword' => '', 'type' => '', 'status' => ''];
?>
<section class="bm-admin-dashboard server-ops-admin">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Server Ops</span>
            <h1>用户服务器</h1>
            <p>查看用户保存的 SSH / Agent 服务器、最近采集状态、公开监控页和今日命令量。这里不展示 SSH 密码和私钥，只做资产、风险和使用情况管理。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/command-logs') ?>" data-icon="square-terminal">命令审计</a>
            <a class="bm-btn bm-btn-primary" href="<?= url('admin/server-ops/settings') ?>" data-icon="sliders-horizontal">运维设置</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric"><span class="bm-icon-tile"><i data-lucide="server-cog"></i></span><div><small>用户服务器</small><strong><?= e($stats['total']) ?></strong><em>已保存 SSH / Agent 资产</em></div></article>
        <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="wifi"></i></span><div><small>在线</small><strong><?= e($stats['online']) ?></strong><em>最近采集正常</em></div></article>
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="triangle-alert"></i></span><div><small>离线</small><strong><?= e($stats['offline']) ?></strong><em>需要用户检查 SSH 或 Agent</em></div></article>
        <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="terminal"></i></span><div><small>今日命令</small><strong><?= e($stats['commands_today']) ?></strong><em>全站终端执行次数</em></div></article>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Assets</span>
                <h2>服务器资产列表</h2>
            </div>
        </div>
        <form method="get" action="<?= url('admin/user-servers') ?>" class="admin-filter-grid server-ops-filter">
            <label>
                <span>关键词</span>
                <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="用户、邮箱、服务器、IP、Agent URL">
            </label>
            <label>
                <span>接入方式</span>
                <select name="type">
                    <option value="">全部</option>
                    <option value="ssh" <?= $filters['type'] === 'ssh' ? 'selected' : '' ?>>SSH</option>
                    <option value="agent" <?= $filters['type'] === 'agent' ? 'selected' : '' ?>>Agent</option>
                </select>
            </label>
            <label>
                <span>状态</span>
                <select name="status">
                    <option value="">全部</option>
                    <option value="online" <?= $filters['status'] === 'online' ? 'selected' : '' ?>>在线</option>
                    <option value="offline" <?= $filters['status'] === 'offline' ? 'selected' : '' ?>>离线</option>
                    <option value="unknown" <?= $filters['status'] === 'unknown' ? 'selected' : '' ?>>未知</option>
                </select>
            </label>
            <div class="filter-actions">
                <button class="btn btn-primary" type="submit" data-icon="search">筛选</button>
                <a class="btn btn-ghost" href="<?= url('admin/user-servers') ?>" data-icon="rotate-ccw">重置</a>
            </div>
        </form>
        <div class="bm-responsive-table server-admin-table">
            <table>
                <thead>
                    <tr>
                        <th>用户</th>
                        <th>服务器</th>
                        <th>接入方式</th>
                        <th>状态</th>
                        <th>资源</th>
                        <th>监控页</th>
                        <th>今日命令</th>
                        <th>最近采集</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$servers): ?>
                    <tr><td colspan="8" class="muted responsive-table-span">暂无用户服务器。</td></tr>
                <?php endif; ?>
                <?php foreach ($servers as $server): ?>
                    <?php
                    $metric = $server['latest'];
                    $host = $server['monitor_type'] === 'agent' ? ($server['agent_url'] ?: $server['server_ip']) : ($server['ssh_host'] ?: $server['server_ip']);
                    ?>
                    <tr>
                        <td data-label="用户">
                            <strong><?= e($server['username'] ?: '用户 #' . $server['user_id']) ?></strong>
                            <small><?= e($server['email'] ?: '-') ?></small>
                        </td>
                        <td data-label="服务器">
                            <strong><?= e($server['name']) ?></strong>
                            <?php if ($server['monitor_type'] === 'agent'): ?>
                                <small><?= e($host ?: '主动上报模式') ?></small>
                            <?php else: ?>
                                <small><?= e($server['ssh_username'] ?: '-') ?>@<?= e($host ?: '-') ?>:<?= e($server['ssh_port']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td data-label="接入方式"><span class="bm-state-pill"><?= e($server['monitor_type'] === 'agent' ? 'Agent' : 'SSH') ?></span></td>
                        <td data-label="状态"><span class="bm-state-pill is-status-<?= e($server['status']) ?>"><?= e(status_label($server['status'])) ?></span></td>
                        <td data-label="资源">
                            <?php if ($metric): ?>
                                <span class="server-mini-metrics">CPU <?= e((float) $metric['cpu_usage']) ?>% / 内存 <?= e((float) $metric['memory_usage']) ?>% / 磁盘 <?= e((float) $metric['disk_usage']) ?>%</span>
                                <small><?= e($fmt($metric['memory_used'])) ?> 内存已用</small>
                            <?php else: ?>
                                <span class="muted">暂无采集数据</span>
                            <?php endif; ?>
                        </td>
                        <td data-label="监控页">
                            <?php if (!empty($server['visibility']) && $server['visibility'] !== 'private'): ?>
                                <a href="<?= url('s/' . $server['token']) ?>" target="_blank" rel="noopener"><?= e($server['visibility']) ?></a>
                                <small><?= e((int) $server['view_count']) ?> 次访问</small>
                            <?php else: ?>
                                <span class="muted">未公开</span>
                            <?php endif; ?>
                        </td>
                        <td data-label="今日命令"><strong><?= e($server['commands_today']) ?></strong></td>
                        <td data-label="最近采集"><span><?= e($server['last_checked_at'] ?: '-') ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>
