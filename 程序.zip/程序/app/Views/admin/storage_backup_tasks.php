<?php
$tasks = isset($tasks) ? $tasks : [];
$policies = isset($policies) ? $policies : [];
$storages = isset($storages) ? $storages : [];
$filters = isset($filters) ? $filters : ['status' => '', 'policy_id' => 0, 'storage_id' => 0, 'file_scope' => ''];
$stats = isset($stats) ? $stats : ['total' => 0, 'success' => 0, 'failed' => 0, 'pending' => 0];
$scopeLabels = ['' => '全部文件', 'image' => '图床图片', 'file' => '网盘文件'];
$statusLabels = ['' => '全部状态', 'pending' => '执行中', 'success' => '成功', 'failed' => '失败', 'skipped' => '跳过', 'deleted' => '已清理'];
?>

<section class="admin-page-head glass storage-backup-hero">
    <div>
        <p class="eyebrow">Backup Tasks</p>
        <h1>备份任务</h1>
        <p>集中查看多存储备份执行结果。失败任务保留厂商返回的错误信息，可单条重试，也可按策略、目标存储和文件类型批量重试。</p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
        <a class="btn btn-primary" href="<?= url('admin/storage-backups/backfill') ?>" data-icon="archive-restore">历史补备</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
    </div>
</section>

<nav class="storage-backup-tabs glass" aria-label="多存储备份模块">
    <a href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
    <a class="active" href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
    <a href="<?= url('admin/storage-backups/backfill') ?>" data-icon="archive-restore">历史补备</a>
    <a href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
</nav>

<section class="ops-metric-grid storage-backup-metrics">
    <article class="ops-metric-card glass"><span>任务总数</span><b><?= e(number_format($stats['total'])) ?></b><small>全部备份写入记录</small></article>
    <article class="ops-metric-card glass ok"><span>成功任务</span><b><?= e(number_format($stats['success'])) ?></b><small>已写入备份目标</small></article>
    <article class="ops-metric-card glass danger"><span>失败任务</span><b><?= e(number_format($stats['failed'])) ?></b><small>建议优先处理</small></article>
    <article class="ops-metric-card glass warn"><span>执行中</span><b><?= e(number_format($stats['pending'])) ?></b><small>上传中或等待结果</small></article>
</section>

<section class="storage-backup-layout storage-backup-layout-equal">
    <article class="table-card glass">
        <div class="section-head">
            <div>
                <p class="eyebrow">Filter</p>
                <h2>筛选任务</h2>
                <p>用于定位某个厂商、某条策略或某类文件的备份链路问题。</p>
            </div>
        </div>
        <form method="get" action="<?= url('admin/storage-backups/tasks') ?>" class="admin-filter-grid storage-backup-filter-grid">
            <label>
                <span>任务状态</span>
                <select name="status">
                    <?php foreach ($statusLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $filters['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>备份策略</span>
                <select name="policy_id">
                    <option value="0">全部策略</option>
                    <?php foreach ($policies as $policy): ?>
                        <option value="<?= e($policy['id']) ?>" <?= (int) $filters['policy_id'] === (int) $policy['id'] ? 'selected' : '' ?>><?= e($policy['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>目标存储</span>
                <select name="storage_id">
                    <option value="0">全部目标</option>
                    <?php foreach ($storages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>" <?= (int) $filters['storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>文件范围</span>
                <select name="file_scope">
                    <?php foreach ($scopeLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $filters['file_scope'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="filter-actions">
                <button class="btn btn-primary" type="submit" data-icon="search">查询</button>
                <a class="btn btn-ghost" href="<?= url('admin/storage-backups/tasks') ?>" data-icon="rotate-ccw">重置</a>
            </div>
        </form>
    </article>

    <aside class="table-card glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Repair</p>
                <h2>批量重试失败任务</h2>
                <p>只会处理失败状态的任务。源文件必须仍在本地可读，否则任务会保留失败原因。</p>
            </div>
        </div>
        <form method="post" action="<?= url('admin/storage-backups/retry-failed') ?>" class="storage-backup-action-form confirm-form" data-confirm="确认按当前条件批量重试失败备份任务吗？">
            <?= csrf_field() ?>
            <label>
                <span>每次处理数量</span>
                <input type="number" name="limit" min="1" max="100" value="20">
            </label>
            <label>
                <span>策略</span>
                <select name="policy_id">
                    <option value="0">全部策略</option>
                    <?php foreach ($policies as $policy): ?>
                        <option value="<?= e($policy['id']) ?>" <?= (int) $filters['policy_id'] === (int) $policy['id'] ? 'selected' : '' ?>><?= e($policy['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>目标存储</span>
                <select name="storage_id">
                    <option value="0">全部目标</option>
                    <?php foreach ($storages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>" <?= (int) $filters['storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>文件范围</span>
                <select name="file_scope">
                    <?php foreach ($scopeLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $filters['file_scope'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button class="btn btn-primary" type="submit" data-icon="rotate-ccw">开始重试</button>
        </form>
    </aside>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Tasks</p>
            <h2>任务列表</h2>
            <p>最多展示最新 120 条记录。错误信息会保留关键返回内容，方便定位厂商 Key、权限、区域或网络问题。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr><th>ID</th><th>文件</th><th>策略</th><th>目标存储</th><th>状态</th><th>路径</th><th>错误</th><th>时间</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php foreach ($tasks as $row): ?>
                <?php $status = isset($row['status']) ? $row['status'] : 'pending'; ?>
                <tr>
                    <td data-label="ID">#<?= e($row['id']) ?></td>
                    <td data-label="文件"><b><?= e($row['original_name'] ?: ('File #' . $row['file_id'])) ?></b><small><?= e($row['file_type'] ?: '-') ?> / <?= !empty($row['file_size']) ? e(format_bytes($row['file_size'])) : '-' ?></small></td>
                    <td data-label="策略"><?= e($row['policy_name'] ?: ('#' . $row['policy_id'])) ?></td>
                    <td data-label="目标存储"><b><?= e($row['storage_name'] ?: ('#' . $row['storage_id'])) ?></b><small><?= e(strtoupper($row['storage_type'] ?: 'unknown')) ?></small></td>
                    <td data-label="状态"><span class="status-pill <?= $status === 'success' ? 'ok' : ($status === 'failed' ? 'danger' : ($status === 'deleted' ? 'muted' : 'soft')) ?>"><?= e(isset($statusLabels[$status]) ? $statusLabels[$status] : $status) ?></span><small>尝试 <?= e((int) $row['attempts']) ?> 次</small></td>
                    <td data-label="路径"><small class="storage-backup-path"><?= e($row['object_key'] ?: '-') ?></small><?php if (!empty($row['file_url'])): ?><a href="<?= e($row['file_url']) ?>" target="_blank" rel="noopener">打开备份链接</a><?php endif; ?></td>
                    <td data-label="错误"><small class="storage-backup-error"><?= e($row['error_message'] ?: '-') ?></small></td>
                    <td data-label="时间"><small><?= e($row['updated_at']) ?></small></td>
                    <td data-label="操作">
                        <?php if ($status === 'failed'): ?>
                            <form method="post" action="<?= url('admin/storage-backups/retry') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($row['id']) ?>">
                                <button class="btn btn-ghost" type="submit" data-icon="rotate-ccw">重试</button>
                            </form>
                        <?php else: ?>
                            <span class="status-pill muted">无需处理</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$tasks): ?>
                <tr><td colspan="9" class="empty-table responsive-table-span">当前条件下没有备份任务。策略启用后，新上传文件会在这里产生记录。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
