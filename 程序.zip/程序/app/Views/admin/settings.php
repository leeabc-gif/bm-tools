<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">设置</p>
        <h2>系统设置</h2>
        <p>维护站点信息、注册策略、上传权限、API 限制和邮件服务。</p>
    </div>

    <div class="card-actions">
        <a class="btn btn-ghost" href="<?= url('admin/themes') ?>" data-icon="palette">主题设置</a>
        <a class="btn btn-ghost" href="<?= url('admin/maintenance') ?>" data-icon="wrench">系统维护</a>
    </div>

    <form method="post" action="<?= url('admin/settings') ?>" class="form-grid two">
        <?= csrf_field() ?>

        <label>网站名称
            <input name="site_name" value="<?= e(isset($settings['site_name']) ? $settings['site_name'] : '') ?>">
        </label>
        <label>网站主域名 / 外链域名
            <span class="input-action">
                <input name="site_public_url" value="<?= e(isset($settings['site_public_url']) ? $settings['site_public_url'] : '') ?>" placeholder="https://www.example.com">
                <button class="btn btn-ghost fill-public-url" type="button" data-icon="wand-sparkles">使用当前域名</button>
            </span>
            <small>用于图床、网盘分享、个人仓库和 API 返回完整外链。留空时自动使用当前访问域名。</small>
        </label>
        <label>Logo URL
            <input name="site_logo" value="<?= e(isset($settings['site_logo']) ? $settings['site_logo'] : '') ?>">
        </label>
        <label>SEO 关键词
            <input name="seo_keywords" value="<?= e(isset($settings['seo_keywords']) ? $settings['seo_keywords'] : '') ?>">
        </label>
        <label>SEO 描述
            <input name="seo_description" value="<?= e(isset($settings['seo_description']) ? $settings['seo_description'] : '') ?>">
        </label>

        <label>注册开关
            <select name="register_enabled">
                <option value="1" <?= (isset($settings['register_enabled']) ? $settings['register_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['register_enabled']) ? $settings['register_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
        </label>
        <label>注册邮箱验证码
            <select name="register_email_code_enabled">
                <option value="0" <?= (isset($settings['register_email_code_enabled']) ? $settings['register_email_code_enabled'] : '0') === '0' ? 'selected' : '' ?>>关闭</option>
                <option value="1" <?= (isset($settings['register_email_code_enabled']) ? $settings['register_email_code_enabled'] : '0') === '1' ? 'selected' : '' ?>>开启</option>
            </select>
        </label>

        <label>登录失败上限
            <input name="security_login_max_attempts" type="number" min="1" value="<?= e(isset($settings['security_login_max_attempts']) ? $settings['security_login_max_attempts'] : '5') ?>">
            <small>同一 IP 或账号在窗口期内连续失败达到上限后会临时锁定。</small>
        </label>
        <label>登录统计窗口（分钟）
            <input name="security_login_window_minutes" type="number" min="1" value="<?= e(isset($settings['security_login_window_minutes']) ? $settings['security_login_window_minutes'] : '10') ?>">
        </label>
        <label>登录锁定时长（分钟）
            <input name="security_login_lock_minutes" type="number" min="1" value="<?= e(isset($settings['security_login_lock_minutes']) ? $settings['security_login_lock_minutes'] : '15') ?>">
        </label>
        <label>邮箱验证码每小时/邮箱
            <input name="security_email_code_max_per_hour" type="number" min="1" value="<?= e(isset($settings['security_email_code_max_per_hour']) ? $settings['security_email_code_max_per_hour'] : '5') ?>">
        </label>
        <label>邮箱验证码每小时/IP
            <input name="security_email_code_ip_max_per_hour" type="number" min="1" value="<?= e(isset($settings['security_email_code_ip_max_per_hour']) ? $settings['security_email_code_ip_max_per_hour'] : '20') ?>">
        </label>

        <label>会员图床总开关
            <select name="user_image_upload_enabled">
                <option value="1" <?= (isset($settings['user_image_upload_enabled']) ? $settings['user_image_upload_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['user_image_upload_enabled']) ? $settings['user_image_upload_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
            <small>关闭后，普通用户即使套餐允许也不能进入图床上传。</small>
        </label>
        <label>会员网盘总开关
            <select name="user_netdisk_enabled">
                <option value="1" <?= (isset($settings['user_netdisk_enabled']) ? $settings['user_netdisk_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['user_netdisk_enabled']) ? $settings['user_netdisk_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
            <small>关闭后，普通用户不能进入个人网盘、分享管理和个人仓库管理。</small>
        </label>
        <label>游客图床上传
            <select name="guest_image_upload_enabled">
                <option value="0" <?= (isset($settings['guest_image_upload_enabled']) ? $settings['guest_image_upload_enabled'] : '0') === '0' ? 'selected' : '' ?>>关闭</option>
                <option value="1" <?= (isset($settings['guest_image_upload_enabled']) ? $settings['guest_image_upload_enabled'] : '0') === '1' ? 'selected' : '' ?>>开启</option>
            </select>
            <small>公开站点建议保持关闭；开启后未登录访客可以在首页上传图片。</small>
        </label>
        <label>游客上传归属用户 ID
            <input name="guest_image_upload_user_id" type="number" min="0" value="<?= e(isset($settings['guest_image_upload_user_id']) ? $settings['guest_image_upload_user_id'] : '0') ?>">
            <small>留 0 时自动使用第一个启用的管理员账号，游客文件会计入该账号容量。</small>
        </label>
        <label>游客单图大小（字节）
            <input name="guest_image_upload_max_size" type="number" min="1" value="<?= e(isset($settings['guest_image_upload_max_size']) ? $settings['guest_image_upload_max_size'] : '5242880') ?>">
        </label>
        <label>游客每日/IP 上传数
            <input name="guest_image_upload_daily_ip_limit" type="number" min="0" value="<?= e(isset($settings['guest_image_upload_daily_ip_limit']) ? $settings['guest_image_upload_daily_ip_limit'] : '20') ?>">
            <small>填 0 表示不限，不建议公开站点这样设置。</small>
        </label>

        <label>默认主题
            <select name="default_theme">
                <?php $defaultTheme = isset($settings['default_theme']) ? $settings['default_theme'] : 'auto'; ?>
                <option value="auto" <?= $defaultTheme === 'auto' ? 'selected' : '' ?>>自动跟随昼夜</option>
                <option value="light" <?= $defaultTheme === 'light' ? 'selected' : '' ?>>浅色</option>
                <option value="dark" <?= (isset($settings['default_theme']) ? $settings['default_theme'] : '') === 'dark' ? 'selected' : '' ?>>深色</option>
            </select>
        </label>
        <label>文件命名策略
            <select name="file_naming_strategy">
                <?php $strategy = isset($settings['file_naming_strategy']) ? $settings['file_naming_strategy'] : 'random'; ?>
                <option value="random" <?= $strategy === 'random' ? 'selected' : '' ?>>随机字符串</option>
                <option value="timestamp" <?= $strategy === 'timestamp' ? 'selected' : '' ?>>时间戳</option>
                <option value="hash" <?= $strategy === 'hash' ? 'selected' : '' ?>>文件 Hash</option>
                <option value="original" <?= $strategy === 'original' ? 'selected' : '' ?>>原始文件名</option>
            </select>
        </label>
        <label>默认免费套餐
            <select name="default_free_package_id">
                <?php foreach ($packages as $p): ?>
                    <option value="<?= e($p['id']) ?>" <?= (isset($settings['default_free_package_id']) && (int) $settings['default_free_package_id'] === (int) $p['id']) ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>API 每分钟限制
            <input name="api_rate_limit_per_minute" value="<?= e(isset($settings['api_rate_limit_per_minute']) ? $settings['api_rate_limit_per_minute'] : '60') ?>">
        </label>
        <label>API 每日限制
            <input name="api_rate_limit_per_day" value="<?= e(isset($settings['api_rate_limit_per_day']) ? $settings['api_rate_limit_per_day'] : '1000') ?>">
        </label>

        <label>邮件 Host
            <input name="email_host" value="<?= e(isset($settings['email_host']) ? $settings['email_host'] : '') ?>">
        </label>
        <label>邮件端口
            <input name="email_port" value="<?= e(isset($settings['email_port']) ? $settings['email_port'] : '465') ?>">
        </label>
        <label>邮件账号
            <input name="email_username" value="<?= e(isset($settings['email_username']) ? $settings['email_username'] : '') ?>">
        </label>
        <label>邮件密码
            <input name="email_password" type="password" value="" autocomplete="new-password" placeholder="<?= !empty($settings['email_password']) ? '已加密保存，留空不修改' : 'SMTP 授权码或密码' ?>">
            <small>保存后会加密写入数据库，页面不会回显明文。</small>
        </label>
        <label>发件邮箱
            <input name="email_from" value="<?= e(isset($settings['email_from']) ? $settings['email_from'] : '') ?>">
        </label>

        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
            <a class="btn btn-ghost" href="<?= url('/') ?>" target="_blank" data-icon="external-link">预览首页</a>
        </div>
    </form>
</section>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">邮件测试</p>
        <h2>邮件测试</h2>
    </div>
    <form method="post" action="<?= url('admin/email/test') ?>" class="url-fetch">
        <?= csrf_field() ?>
        <input type="email" name="email" placeholder="接收测试邮件的邮箱" required>
        <button class="btn btn-ghost" type="submit" data-icon="send">发送测试邮件</button>
    </form>
</section>
