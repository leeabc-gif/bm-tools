<?php require APP_ROOT . '/app/Views/admin/partials/settings_nav.php'; ?>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">上传权限</p>
        <h2>上传权限设置</h2>
        <p>只放图床、网盘和游客上传相关的开关与限制。</p>
    </div>

    <form method="post" action="<?= url('admin/settings/upload') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <label>会员图床总开关
            <select name="user_image_upload_enabled">
                <option value="1" <?= (isset($settings['user_image_upload_enabled']) ? $settings['user_image_upload_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['user_image_upload_enabled']) ? $settings['user_image_upload_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
        </label>
        <label>会员网盘总开关
            <select name="user_netdisk_enabled">
                <option value="1" <?= (isset($settings['user_netdisk_enabled']) ? $settings['user_netdisk_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['user_netdisk_enabled']) ? $settings['user_netdisk_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
        </label>
        <label>游客图床上传
            <select name="guest_image_upload_enabled">
                <option value="0" <?= (isset($settings['guest_image_upload_enabled']) ? $settings['guest_image_upload_enabled'] : '0') === '0' ? 'selected' : '' ?>>关闭</option>
                <option value="1" <?= (isset($settings['guest_image_upload_enabled']) ? $settings['guest_image_upload_enabled'] : '0') === '1' ? 'selected' : '' ?>>开启</option>
            </select>
        </label>
        <label>游客上传归属用户 ID
            <input name="guest_image_upload_user_id" type="number" min="0" value="<?= e(isset($settings['guest_image_upload_user_id']) ? $settings['guest_image_upload_user_id'] : '0') ?>">
        </label>
        <label>游客单图大小（字节）
            <input name="guest_image_upload_max_size" type="number" min="1" value="<?= e(isset($settings['guest_image_upload_max_size']) ? $settings['guest_image_upload_max_size'] : '5242880') ?>">
        </label>
        <label>游客每日/IP 上传数
            <input name="guest_image_upload_daily_ip_limit" type="number" min="0" value="<?= e(isset($settings['guest_image_upload_daily_ip_limit']) ? $settings['guest_image_upload_daily_ip_limit'] : '20') ?>">
        </label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
        </div>
    </form>
</section>
