<?php
$filters = isset($filters) ? $filters : ['scope' => '', 'date_start' => '', 'date_end' => ''];
$stats = isset($stats) ? $stats : ['api_failed_today' => 0, 'backup_failed' => 0, 'command_risky_today' => 0, 'upload_today' => 0, 'upload_failed_today' => 0];
$incidents = isset($incidents) && is_array($incidents) ? $incidents : [];
$scopeLabels = [
    '' => '全部事件',
    'api' => 'API 失败',
    'backup' => '备份失败',
    'command' => '命令审计',
    'upload_failure' => '上传失败',
    'upload' => '上传记录',
    'admin' => '后台操作',
];
$levelLabels = [
    'danger' => '高',
    'warning' => '中',
    'soft' => '低',
    'ok' => '正常',
];
?>

<section class="bm-admin-dashboard">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Incident Center</span>
            <h1>异常事件中心</h1>
            <p>集中查看上传失败、API 异常、存储备份、SSH 命令和后台关键操作。遇到系统繁忙、对象存储不通或上传失败时，先从这里定位最近发生的异常。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/feature-audit') ?>" data-icon="radar">功能巡检</a>
            <a class="bm-btn bm-btn-primary" href="<?= url('admin/storages') ?>" data-icon="database">存储测试</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="terminal"></i></span><div><small>今日 API 失败</small><strong><?= e(number_format((int) $stats['api_failed_today'])) ?></strong><em>开放接口异常</em></div></article>
        <article class="bm-admin-metric is-red"><span class="bm-icon-tile"><i data-lucide="database-backup"></i></span><div><small>备份失败</small><strong><?= e(number_format((int) $stats['backup_failed'])) ?></strong><em>多存储任务</em></div></article>
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="square-terminal"></i></span><div><small>今日命令标记</small><strong><?= e(number_format((int) $stats['command_risky_today'])) ?></strong><em>警告/危险记录</em></div></article>
        <article class="bm-admin-metric is-red"><span class="bm-icon-tile"><i data-lucide="cloud-alert"></i></span><div><small>今日上传失败</small><strong><?= e(number_format((int) $stats['upload_failed_today'])) ?></strong><em>图床/网盘失败记录</em></div></article>
    </section>

    <section class="bm-admin-panel">
        <form method="get" action="<?= url('admin/incident-center') ?>" class="bm-incident-filter">
            <label>
                <span>事件范围</span>
                <select name="scope">
                    <?php foreach ($scopeLabels as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $filters['scope'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>开始日期</span>
                <input type="date" name="date_start" value="<?= e($filters['date_start']) ?>">
            </label>
            <label>
                <span>结束日期</span>
                <input type="date" name="date_end" value="<?= e($filters['date_end']) ?>">
            </label>
            <button class="bm-btn bm-btn-primary" type="submit" data-icon="search">筛选</button>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/incident-center') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Timeline</span>
                <h2>最近事件流</h2>
            </div>
            <span class="bm-muted-text">最多展示 80 条，按时间倒序排列</span>
        </div>
        <div class="bm-incident-list">
            <?php foreach ($incidents as $item): ?>
                <?php $level = isset($item['level']) ? $item['level'] : 'soft'; ?>
                <a class="bm-incident-item is-<?= e($level) ?>" href="<?= url(isset($item['url']) ? $item['url'] : 'admin/incident-center') ?>">
                    <span class="bm-icon-tile is-small"><i data-lucide="<?= e(isset($item['icon']) ? $item['icon'] : 'bell') ?>"></i></span>
                    <div>
                        <strong><?= e(isset($item['title']) ? $item['title'] : '事件') ?></strong>
                        <small><?= e(isset($item['desc']) ? $item['desc'] : '') ?></small>
                        <em><?= e(isset($item['user']) ? $item['user'] : '-') ?> · <?= e(isset($item['time']) ? $item['time'] : '-') ?></em>
                    </div>
                    <b><?= e(isset($levelLabels[$level]) ? $levelLabels[$level] : $level) ?></b>
                </a>
            <?php endforeach; ?>
            <?php if (!$incidents): ?>
                <div class="bm-empty-line">当前条件下暂无异常事件。可以放宽日期范围，或进入功能巡检查看环境状态。</div>
            <?php endif; ?>
        </div>
    </section>
</section>
