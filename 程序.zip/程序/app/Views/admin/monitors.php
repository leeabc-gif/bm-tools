<?php
$edit = null;
if (!empty($_GET['id'])) {
    foreach ($servers as $item) {
        if ((int) $item['id'] === (int) $_GET['id']) {
            $edit = $item;
            break;
        }
    }
}

$threshold = ['cpu' => 90, 'memory' => 90, 'disk' => 90];
if ($edit && !empty($edit['threshold_config'])) {
    $decoded = json_decode($edit['threshold_config'], true);
    if (is_array($decoded)) {
        $threshold = array_merge($threshold, $decoded);
    }
}

$monitorStats = ['total' => 0, 'online' => 0, 'offline' => 0, 'unknown' => 0, 'bt' => 0, 'ssh' => 0, 'agent' => 0, 'enabled' => 0, 'disabled' => 0];
foreach ($servers as $item) {
    $monitorStats['total']++;
    $status = isset($item['status']) && isset($monitorStats[$item['status']]) ? $item['status'] : 'unknown';
    $monitorStats[$status]++;
    $type = isset($item['monitor_type']) && isset($monitorStats[$item['monitor_type']]) ? $item['monitor_type'] : 'bt';
    $monitorStats[$type]++;
    if (!empty($item['is_enabled'])) {
        $monitorStats['enabled']++;
    } else {
        $monitorStats['disabled']++;
    }
}

$unresolvedAlerts = 0;
foreach ($alerts as $alert) {
    if (isset($alert['status']) && $alert['status'] !== 'resolved') {
        $unresolvedAlerts++;
    }
}
$monitorStats['agent'] = $monitorStats['enabled'];

$monitorTypeLabel = function ($type) {
    return 'Baota API';
    if ($type === 'ssh') {
        return 'SSH 直连';
    }
    if ($type === 'agent') {
        return 'HTTP 探针';
    }
    return '宝塔 API';
};
?>

<section class="bm-admin-dashboard bm-admin-monitor-page">
    <style>
        .bm-admin-monitor-page [data-monitor-type] option[value="ssh"],
        .bm-admin-monitor-page [data-monitor-type] option[value="agent"],
        .bm-admin-monitor-page [data-ssh-field],
        .bm-admin-monitor-page [data-agent-field] { display: none !important; }
    </style>
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Operations Monitor</span>
            <h1>监控管理</h1>
            <p>统一维护平台运营服务器、采集计划和告警记录。页面以服务器信息展示为主，采集、测试、启停和删除都保留原业务接口。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-soft" href="<?= url('monitor') ?>" target="_blank" data-icon="external-link">打开监控前台</a>
            <a class="bm-btn bm-btn-plain" href="<?= url('status') ?>" target="_blank" data-icon="activity">公开状态页</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric">
            <span class="bm-icon-tile"><i data-lucide="server"></i></span>
            <div><small>服务器总数</small><strong><?= e($monitorStats['total']) ?></strong><em>已接入运营监控</em></div>
        </article>
        <article class="bm-admin-metric is-green">
            <span class="bm-icon-tile"><i data-lucide="wifi"></i></span>
            <div><small>在线节点</small><strong><?= e($monitorStats['online']) ?></strong><em>最近采集正常</em></div>
        </article>
        <article class="bm-admin-metric is-orange">
            <span class="bm-icon-tile"><i data-lucide="triangle-alert"></i></span>
            <div><small>异常节点</small><strong><?= e($monitorStats['offline']) ?></strong><em>优先排查网络或服务</em></div>
        </article>
        <article class="bm-admin-metric is-purple">
            <span class="bm-icon-tile"><i data-lucide="power"></i></span>
            <div><small>探针接入</small><strong><?= e($monitorStats['agent']) ?></strong><em>免 SSH 依赖方案</em></div>
        </article>
    </section>

    <?php if (!empty($monitorCronUrl)): ?>
        <section class="bm-admin-panel bm-copy-scope">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Cron Collect</span>
                    <h2>自动采集链接</h2>
                </div>
            </div>
            <div class="bm-monitor-cron-grid">
                <label>
                    <span>按频率采集</span>
                    <div class="bm-input-action">
                        <input readonly value="<?= e($monitorCronUrl) ?>">
                        <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                    </div>
                    <small>推荐每 1 分钟访问一次。系统会按每台服务器的监控频率判断是否采集。</small>
                </label>
                <label>
                    <span>强制采集</span>
                    <div class="bm-input-action">
                        <input readonly value="<?= e($monitorCronForceUrl) ?>">
                        <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                    </div>
                    <small>会忽略频率限制，适合临时排查，不建议高频访问。</small>
                </label>
                <?php if (!empty($serverOpsCronUrl)): ?>
                    <label>
                        <span>用户服务器管家</span>
                        <div class="bm-input-action">
                            <input readonly value="<?= e($serverOpsCronUrl) ?>">
                            <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                        </div>
                        <small>仅采集用户自己添加的 SSH/Agent 服务器和站点探针，不会混入本站运营服务器。</small>
                    </label>
                <?php endif; ?>
                <?php if (!empty($serverOpsCronForceUrl)): ?>
                    <label>
                        <span>用户服务器强制采集</span>
                        <div class="bm-input-action">
                            <input readonly value="<?= e($serverOpsCronForceUrl) ?>">
                            <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                        </div>
                        <small>用于临时刷新用户侧服务器状态，支持增加 limit 参数控制每次处理数量。</small>
                    </label>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="bm-admin-main-grid bm-monitor-admin-grid">
        <article class="bm-admin-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Server Access</span>
                    <h2><?= $edit ? '编辑运营服务器' : '新增运营服务器' ?></h2>
                </div>
                <?php if ($edit): ?><a class="bm-btn bm-btn-plain" href="<?= url('admin/monitors') ?>" data-icon="plus">新增</a><?php endif; ?>
            </div>

            <form method="post" action="<?= url('admin/monitors/save') ?>" class="bm-form-grid bm-admin-monitor-form monitor-create-form">
                <?= csrf_field() ?>
                <?php if ($edit): ?><input type="hidden" name="id" value="<?= e($edit['id']) ?>"><?php endif; ?>

                <label>
                    <span>监控方式</span>
                    <select name="monitor_type" data-monitor-type>
                        <option value="bt" <?= !$edit || (isset($edit['monitor_type']) ? $edit['monitor_type'] : 'bt') === 'bt' ? 'selected' : '' ?>>宝塔 API</option>
                        <option value="ssh" <?= $edit && (isset($edit['monitor_type']) ? $edit['monitor_type'] : 'bt') === 'ssh' ? 'selected' : '' ?>>SSH 直连</option>
                        <option value="agent" <?= $edit && (isset($edit['monitor_type']) ? $edit['monitor_type'] : 'bt') === 'agent' ? 'selected' : '' ?>>HTTP 探针（免 SSH 依赖）</option>
                    </select>
                </label>

                <label>
                    <span>服务器名称</span>
                    <input name="name" value="<?= e($edit ? $edit['name'] : '') ?>" required placeholder="例如：主站节点">
                </label>

                <label>
                    <span>分组名称</span>
                    <input name="group_name" value="<?= e($edit ? $edit['group_name'] : '平台节点') ?>">
                </label>

                <label>
                    <span>服务器 IP</span>
                    <input name="server_ip" value="<?= e($edit ? $edit['server_ip'] : '') ?>" placeholder="1.2.3.4">
                </label>

                <label data-bt-field>
                    <span>宝塔面板地址</span>
                    <input name="panel_url" placeholder="https://1.2.3.4:8888" value="<?= e($edit ? $edit['panel_url'] : '') ?>">
                </label>

                <label data-bt-field>
                    <span>宝塔 API 密钥</span>
                    <input name="api_key" value="<?= e($edit ? $edit['api_key'] : '') ?>">
                </label>

                <label data-bt-field>
                    <span>面板端口</span>
                    <input type="number" name="panel_port" value="<?= e($edit ? $edit['panel_port'] : '8888') ?>">
                </label>

                <label data-ssh-field>
                    <span>SSH 主机/IP</span>
                    <input name="ssh_host" placeholder="1.2.3.4" value="<?= e($edit && isset($edit['ssh_host']) ? $edit['ssh_host'] : '') ?>">
                </label>

                <label data-ssh-field>
                    <span>SSH 端口</span>
                    <input type="number" name="ssh_port" value="<?= e($edit && isset($edit['ssh_port']) ? $edit['ssh_port'] : '22') ?>">
                </label>

                <label data-ssh-field>
                    <span>SSH 用户名</span>
                    <input name="ssh_username" placeholder="root 或监控专用用户" value="<?= e($edit && isset($edit['ssh_username']) ? $edit['ssh_username'] : '') ?>">
                </label>

                <label data-ssh-field>
                    <span>认证方式</span>
                    <select name="ssh_auth_type">
                        <option value="password" <?= !$edit || (isset($edit['ssh_auth_type']) ? $edit['ssh_auth_type'] : 'password') === 'password' ? 'selected' : '' ?>>密码</option>
                        <option value="key" <?= $edit && (isset($edit['ssh_auth_type']) ? $edit['ssh_auth_type'] : 'password') === 'key' ? 'selected' : '' ?>>私钥</option>
                    </select>
                </label>

                <label data-ssh-field>
                    <span>SSH 密码</span>
                    <input type="password" name="ssh_password" placeholder="<?= $edit ? '留空表示不修改' : '请输入 SSH 密码' ?>">
                </label>

                <label class="bm-span-all" data-ssh-field>
                    <span>SSH 私钥</span>
                    <textarea name="ssh_private_key" placeholder="<?= $edit ? '留空表示不修改，支持 RSA/OPENSSH 私钥' : '使用私钥登录时填写' ?>"></textarea>
                </label>

                <label data-ssh-field>
                    <span>私钥口令</span>
                    <input type="password" name="ssh_key_passphrase" placeholder="<?= $edit ? '留空表示不修改' : '无口令可留空' ?>">
                </label>

                <label class="bm-span-all" data-agent-field>
                    <span>HTTP 探针地址</span>
                    <input name="agent_url" placeholder="https://server.com/monitor-agent.php" value="<?= e($edit && isset($edit['agent_url']) ? $edit['agent_url'] : '') ?>">
                </label>

                <label data-agent-field>
                    <span>探针 Token</span>
                    <div class="bm-input-action">
                        <input name="agent_token" placeholder="和探针文件中的 Token 保持一致" value="<?= e($edit && isset($edit['agent_token']) ? $edit['agent_token'] : '') ?>">
                        <button class="bm-btn bm-btn-soft" type="button" data-generate-agent-token data-icon="key-round">生成</button>
                    </div>
                </label>

                <div class="bm-span-all bm-inline-notice" data-agent-field>
                    <i data-lucide="info"></i>
                    <div><strong>HTTP 探针接入</strong><span>把 public/monitor-agent.php 上传到被监控服务器，修改文件顶部 Token，再填写探针 URL 和 Token。主站无需安装 phpseclib 或 ssh2 扩展。</span></div>
                </div>

                <div class="bm-span-all bm-agent-helper" data-agent-field>
                    <header>
                        <div>
                            <strong>探针部署助手</strong>
                            <span>复制后按步骤部署到被监控服务器。</span>
                        </div>
                        <button class="bm-btn bm-btn-soft" type="button" data-copy-agent-guide data-icon="copy">复制部署说明</button>
                    </header>
                    <div class="bm-agent-helper-grid">
                        <div><span>1. 上传探针文件</span><code>public/monitor-agent.php</code></div>
                        <div><span>2. 修改探针 Token</span><code data-agent-token-preview><?= e($edit && isset($edit['agent_token']) && $edit['agent_token'] ? $edit['agent_token'] : '点击生成 Token') ?></code></div>
                        <div><span>3. 测试访问地址</span><code data-agent-test-url><?= e($edit && !empty($edit['agent_url']) && !empty($edit['agent_token']) ? $edit['agent_url'] . '?token=' . $edit['agent_token'] : '填写探针地址和 Token 后自动生成') ?></code></div>
                    </div>
                    <textarea class="agent-guide-source" readonly data-agent-guide-source>HTTP 探针部署：
1. 将 BM TOOLS 项目 public/monitor-agent.php 上传到被监控服务器网站目录。
2. 打开 monitor-agent.php，把 $token = 'CHANGE_THIS_TOKEN'; 改成后台生成的 Token。
3. 在浏览器访问：{AGENT_TEST_URL}
4. 返回 JSON 且 success=true 后，回到后台点击“测试连接”。
</textarea>
                </div>

                <label>
                    <span>监控频率（秒）</span>
                    <input type="number" name="frequency" value="<?= e($edit ? $edit['frequency'] : '60') ?>" min="30">
                </label>

                <label>
                    <span>CPU 告警阈值 %</span>
                    <input type="number" name="cpu_threshold" value="<?= e($threshold['cpu']) ?>" min="1" max="100">
                </label>

                <label>
                    <span>内存告警阈值 %</span>
                    <input type="number" name="memory_threshold" value="<?= e($threshold['memory']) ?>" min="1" max="100">
                </label>

                <label>
                    <span>磁盘告警阈值 %</span>
                    <input type="number" name="disk_threshold" value="<?= e($threshold['disk']) ?>" min="1" max="100">
                </label>

                <label class="bm-span-all">
                    <span>备注</span>
                    <input name="remark" value="<?= e($edit ? $edit['remark'] : '') ?>" placeholder="机房、用途或维护说明">
                </label>

                <label class="bm-check-row">
                    <input type="checkbox" name="is_enabled" <?= !$edit || $edit['is_enabled'] ? 'checked' : '' ?>>
                    <span>启用公开状态监控</span>
                </label>

                <label class="bm-check-row">
                    <input type="checkbox" name="test_after_save" checked>
                    <span>保存后立即测试采集</span>
                </label>

                <div class="bm-form-actions bm-span-all">
                    <button class="bm-btn bm-btn-primary" type="submit" data-icon="save">保存服务器</button>
                    <button class="bm-btn bm-btn-soft monitor-test-btn" type="button" data-token="<?= e(csrf_token()) ?>" data-icon="plug-zap">测试连接</button>
                    <a class="bm-btn bm-btn-plain" href="<?= url('admin/monitors') ?>" data-icon="rotate-ccw">重置表单</a>
                </div>
            </form>
        </article>

        <aside class="bm-admin-panel bm-monitor-admin-side">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Overview</span>
                    <h2>接入概览</h2>
                </div>
            </div>
            <div class="bm-guide-list">
                <p><b>宝塔 API</b><span><?= e($monitorStats['bt']) ?> 台。适合已有宝塔面板的服务器，重点检查 API 白名单和面板端口。</span></p>
                <p><b>SSH 直连</b><span><?= e($monitorStats['ssh']) ?> 台。适合内网节点或不方便暴露面板 API 的环境。</span></p>
                <p><b>HTTP 探针</b><span><?= e($monitorStats['agent']) ?> 台。适合没有 SSH 扩展或希望低依赖接入的服务器。</span></p>
                <p><b>待处理告警</b><span><?= e($unresolvedAlerts) ?> 条。优先处理离线、资源超限和服务异常。</span></p>
            </div>
        </aside>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Servers</span>
                <h2>运营服务器</h2>
            </div>
        </div>

        <div class="bm-monitor-list bm-admin-monitor-list">
            <?php if (!$servers): ?>
                <article class="bm-empty-state">
                    <i data-lucide="server"></i>
                    <strong>暂无监控服务器</strong>
                    <span>先在上方新增服务器，测试连接成功后即可开始采集。</span>
                </article>
            <?php endif; ?>

            <?php foreach ($servers as $s): ?>
                <?php
                $type = isset($s['monitor_type']) ? $s['monitor_type'] : 'bt';
                $target = $s['server_ip'] ?: ($type === 'agent' && !empty($s['agent_url']) ? $s['agent_url'] : $s['panel_url']);
                ?>
                <article class="bm-monitor-card is-status-<?= e($s['status']) ?>">
                    <header>
                        <div class="bm-record-main">
                            <span class="bm-icon-tile is-small"><i data-lucide="server"></i></span>
                            <div>
                                <strong><?= e($s['name']) ?></strong>
                                <small><?= e($target ?: '-') ?> · <?= e($s['group_name'] ?: '未分组') ?></small>
                            </div>
                        </div>
                        <div class="bm-alert-badges">
                            <span class="bm-state-pill is-level-info"><?= e($monitorTypeLabel($type)) ?></span>
                            <span class="bm-state-pill is-status-<?= e($s['status']) ?>"><?= e(status_label($s['status'])) ?></span>
                            <span class="bm-state-pill <?= $s['is_enabled'] ? 'is-status-online' : 'is-status-unknown' ?>"><?= $s['is_enabled'] ? '已启用' : '已停用' ?></span>
                        </div>
                    </header>

                    <div class="bm-record-meta bm-admin-monitor-meta">
                        <span><b>ID</b><?= e($s['id']) ?></span>
                        <span><b>端口</b><?= e($s['panel_port'] ?: '-') ?></span>
                        <span><b>频率</b><?= e($s['frequency']) ?> 秒</span>
                        <span><b>最近采集</b><?= e($s['last_checked_at'] ?: '等待采集') ?></span>
                    </div>

                    <?php if (!empty($s['last_error'])): ?>
                        <div class="bm-inline-notice is-warning">
                            <i data-lucide="alert-triangle"></i>
                            <div><strong>最近错误</strong><span><?= e($s['last_error']) ?></span></div>
                        </div>
                    <?php endif; ?>

                    <div class="bm-monitor-actions">
                        <a class="bm-btn bm-btn-soft" href="<?= url('admin/monitors?id=' . $s['id']) ?>" data-icon="pencil">编辑</a>
                        <form method="post" action="<?= url('admin/monitors/collect') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="bm-btn bm-btn-primary" type="submit" data-icon="activity">立即采集</button>
                        </form>
                        <form method="post" action="<?= url('admin/monitors/toggle') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="bm-btn bm-btn-soft" type="submit" data-icon="<?= $s['is_enabled'] ? 'pause-circle' : 'play-circle' ?>"><?= $s['is_enabled'] ? '暂停监控' : '启用监控' ?></button>
                        </form>
                        <form method="post" action="<?= url('admin/monitors/delete') ?>" class="confirm-form" data-confirm="确定删除该服务器及监控历史吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Alerts</span>
                <h2>最近告警</h2>
            </div>
        </div>

        <div class="bm-alert-list">
            <?php if (!$alerts): ?>
                <article class="bm-empty-state">
                    <i data-lucide="shield-check"></i>
                    <strong>暂无告警</strong>
                    <span>服务器运行稳定时，这里会保持空白。</span>
                </article>
            <?php endif; ?>

            <?php foreach ($alerts as $a): ?>
                <article class="bm-alert-card">
                    <header>
                        <div class="bm-record-main">
                            <span class="bm-icon-tile is-small"><i data-lucide="bell-ring"></i></span>
                            <div>
                                <strong><?= e($a['title']) ?></strong>
                                <small><?= e($a['server_name'] ?: '-') ?> · <?= e($a['created_at']) ?></small>
                            </div>
                        </div>
                        <div class="bm-alert-badges">
                            <span class="bm-state-pill is-level-<?= e($a['level']) ?>"><?= e(alert_level_label($a['level'])) ?></span>
                            <span class="bm-state-pill is-status-<?= e($a['status']) ?>"><?= e(alert_status_label($a['status'])) ?></span>
                        </div>
                    </header>
                    <p><?= e($a['content']) ?></p>
                    <footer>
                        <span><?= e(isset($a['metric']) ? $a['metric'] : '-') ?></span>
                        <div class="bm-alert-actions">
                            <?php if ($a['status'] !== 'resolved'): ?>
                                <form method="post" action="<?= url('admin/alerts/resolve') ?>" class="confirm-form" data-confirm="确认将该告警标记为已解决吗？">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= e($a['id']) ?>">
                                    <button class="bm-btn bm-btn-soft" type="submit" data-icon="check-circle">标记解决</button>
                                </form>
                            <?php else: ?>
                                <span class="bm-state-pill is-status-resolved">已解决</span>
                            <?php endif; ?>
                        </div>
                    </footer>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>

<script>
(function () {
    document.querySelectorAll('[data-monitor-type] option[value="ssh"], [data-monitor-type] option[value="agent"]').forEach(function (option) {
        option.remove();
    });
    function syncMonitorFields() {
        var type = document.querySelector('[data-monitor-type]');
        if (!type) return;
        type.value = 'bt';
        var isSsh = type.value === 'ssh';
        var isAgent = type.value === 'agent';
        document.querySelectorAll('[data-bt-field]').forEach(function (el) { el.style.display = (!isSsh && !isAgent) ? 'grid' : 'none'; });
        document.querySelectorAll('[data-ssh-field]').forEach(function (el) { el.style.display = isSsh ? 'grid' : 'none'; });
        document.querySelectorAll('[data-agent-field]').forEach(function (el) { el.style.display = isAgent ? 'grid' : 'none'; });
        updateAgentGuide();
    }
    function agentTestUrl() {
        var url = document.querySelector('input[name="agent_url"]');
        var token = document.querySelector('input[name="agent_token"]');
        var u = url && url.value ? url.value.trim() : '';
        var t = token && token.value ? token.value.trim() : '';
        if (!u || !t) return '';
        return u + (u.indexOf('?') === -1 ? '?' : '&') + 'token=' + encodeURIComponent(t);
    }
    function updateAgentGuide() {
        var token = document.querySelector('input[name="agent_token"]');
        var preview = document.querySelector('[data-agent-token-preview]');
        var testUrl = document.querySelector('[data-agent-test-url]');
        var guide = document.querySelector('[data-agent-guide-source]');
        var tokenText = token && token.value ? token.value.trim() : '点击生成 Token';
        var urlText = agentTestUrl() || '填写探针地址和 Token 后自动生成';
        if (preview) preview.textContent = tokenText;
        if (testUrl) testUrl.textContent = urlText;
        if (guide) {
            guide.value = 'HTTP 探针部署：\n' +
                '1. 将 BM TOOLS 项目 public/monitor-agent.php 上传到被监控服务器网站目录。\n' +
                "2. 打开 monitor-agent.php，把 $token = 'CHANGE_THIS_TOKEN'; 改成：" + tokenText + '\n' +
                '3. 在浏览器访问：' + urlText + '\n' +
                '4. 返回 JSON 且 success=true 后，回到后台点击“测试连接”。';
        }
    }
    function copyText(text) {
        if (!text) return;
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
                if (window.SKY_TOAST) window.SKY_TOAST('已复制。', 'success');
            });
            return;
        }
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        if (window.SKY_TOAST) window.SKY_TOAST('已复制。', 'success');
    }
    document.addEventListener('change', function (e) {
        if (e.target && e.target.matches('[data-monitor-type]')) {
            syncMonitorFields();
        }
    });
    document.addEventListener('input', function (e) {
        if (e.target && (e.target.name === 'agent_url' || e.target.name === 'agent_token')) {
            updateAgentGuide();
        }
    });
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-generate-agent-token]');
        if (btn) {
            var input = document.querySelector('input[name="agent_token"]');
            if (!input) return;
            var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
            var token = 'BM_';
            var values = new Uint32Array(24);
            if (window.crypto && window.crypto.getRandomValues) {
                window.crypto.getRandomValues(values);
                for (var i = 0; i < values.length; i++) token += chars[values[i] % chars.length];
            } else {
                for (var j = 0; j < 24; j++) token += chars[Math.floor(Math.random() * chars.length)];
            }
            input.value = token;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            return;
        }
        var copyBtn = e.target.closest('[data-copy-agent-guide]');
        if (copyBtn) {
            var guide = document.querySelector('[data-agent-guide-source]');
            copyText(guide ? guide.value : '');
        }
    });
    syncMonitorFields();
})();
</script>
