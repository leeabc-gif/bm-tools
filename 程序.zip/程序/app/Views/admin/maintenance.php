<?php
$maintenanceOn = isset($settings['site_maintenance']) && (string) $settings['site_maintenance'] === '1';
$message = isset($settings['maintenance_message']) ? $settings['maintenance_message'] : '系统正在维护升级，请稍后再访问。';
$schemaRepairResult = flash('schema_repair_result', null);
$schemaAudit = isset($schemaAudit) && is_array($schemaAudit) ? $schemaAudit : [];
?>

<section class="admin-page-head maintenance-head glass">
    <div>
        <p class="eyebrow">系统维护</p>
        <h1>系统维护</h1>
        <p>维护模式、数据库备份、在线更新和环境信息已拆成独立页面，避免一个页面塞太多操作。</p>
    </div>
    <span class="status-pill <?= $maintenanceOn ? 'bad' : 'ok' ?>"><?= $maintenanceOn ? '维护中' : '正常运行' ?></span>
</section>

<section class="bm-admin-metric-grid bm-admin-workbench-metrics">
    <article class="bm-admin-metric is-blue"><span class="bm-icon-tile"><i data-lucide="database"></i></span><div><small>标准数据表</small><strong><?= e(number_format((int) (isset($schemaAudit['expected_table_count']) ? $schemaAudit['expected_table_count'] : 0))) ?></strong><em>当前库表总数 <?= e(number_format((int) (isset($schemaAudit['current_prefixed_table_count']) ? $schemaAudit['current_prefixed_table_count'] : 0))) ?></em></div></article>
    <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="table-properties"></i></span><div><small>缺失数据表</small><strong><?= e(number_format((int) (isset($schemaAudit['missing_table_count']) ? $schemaAudit['missing_table_count'] : 0))) ?></strong><em>安装基线与当前数据库对比</em></div></article>
    <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="columns-3"></i></span><div><small>缺失字段</small><strong><?= e(number_format((int) (isset($schemaAudit['missing_column_count']) ? $schemaAudit['missing_column_count'] : 0))) ?></strong><em>表存在但列未补齐</em></div></article>
    <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="scan-search"></i></span><div><small>代码缺表引用</small><strong><?= e(number_format((int) (isset($schemaAudit['code_missing_table_count']) ? $schemaAudit['code_missing_table_count'] : 0))) ?></strong><em>控制器/服务层引用但数据库不存在</em></div></article>
</section>

<?php if (!empty($schemaAudit)): ?>
    <section class="bm-admin-screen-grid">
        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Schema Health</span>
                    <h2>数据库健康摘要</h2>
                </div>
                <span class="status-pill <?= !empty($schemaAudit['ok']) ? 'ok' : 'bad' ?>"><?= !empty($schemaAudit['ok']) ? '结构一致' : '存在缺口' ?></span>
            </div>
            <div class="bm-admin-screen-summary-grid">
                <div class="bm-admin-screen-summary-item"><span>当前前缀表数量</span><strong><?= e(number_format((int) (isset($schemaAudit['current_prefixed_table_count']) ? $schemaAudit['current_prefixed_table_count'] : 0))) ?></strong><small>与标准安装结构对比后的前缀表数量</small></div>
                <div class="bm-admin-screen-summary-item"><span>代码引用表数量</span><strong><?= e(number_format((int) (isset($schemaAudit['code_used_table_count']) ? $schemaAudit['code_used_table_count'] : 0))) ?></strong><small>控制器和服务层静态扫描到的表引用数</small></div>
                <div class="bm-admin-screen-summary-item"><span>额外前缀表</span><strong><?= e(number_format(count(isset($schemaAudit['extra_prefixed_tables']) ? $schemaAudit['extra_prefixed_tables'] : []))) ?></strong><small>可能是旧版本遗留、实验表或扩展表</small></div>
            </div>
        </article>

        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Immediate Risk</span>
                    <h2>优先处理建议</h2>
                </div>
            </div>
            <div class="bm-admin-screen-list bm-admin-settings-actions">
                <div><span>缺失数据表</span><strong><?= !empty($schemaAudit['missing_table_count']) ? '优先执行结构修复' : '当前未发现缺表' ?></strong></div>
                <div><span>缺失字段</span><strong><?= !empty($schemaAudit['missing_column_count']) ? '建议先修字段再测功能' : '当前未发现缺字段' ?></strong></div>
                <div><span>代码缺表引用</span><strong><?= !empty($schemaAudit['code_missing_table_count']) ? '存在运行时高风险' : '当前未发现代码缺表引用' ?></strong></div>
                <div><span>下一步动作</span><strong><a href="<?= url('admin/maintenance/schema-audit') ?>">进入详细数据库巡检</a></strong></div>
            </div>
        </article>
    </section>
<?php endif; ?>

<section class="quick-grid maintenance-subnav">
    <a class="quick-card glass" href="<?= url('admin/maintenance/update') ?>" data-icon="refresh-cw">
        <b>在线更新</b>
        <span>检查更新源、下载更新包、安装本地更新包。</span>
    </a>
    <a class="quick-card glass" href="<?= url('admin/maintenance/environment') ?>" data-icon="server">
        <b>环境信息</b>
        <span>查看 PHP 扩展、目录权限、数据库版本和服务器配置。</span>
    </a>
    <a class="quick-card glass" href="<?= url('admin/maintenance/schema-audit') ?>" data-icon="database-zap">
        <b>&#25968;&#25454;&#24211;&#24033;&#26816;</b>
        <span>&#23545;&#27604;&#24403;&#21069;&#25968;&#25454;&#24211;&#21644;&#31243;&#24207;&#26631;&#20934;&#34920;&#32467;&#26500;&#65292;&#30475;&#32570;&#22810;&#23569;&#34920;&#21644;&#23383;&#27573;&#12290;</span>
    </a>
    <a class="quick-card glass" href="<?= url('admin/themes') ?>" data-icon="palette">
        <b>主题设置</b>
        <span>切换后台和前台的原版 / 二次元风格。</span>
    </a>
</section>

<?php if (is_array($schemaRepairResult)): ?>
    <section class="table-card glass schema-repair-result">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Repair Result</p>
                <h2>数据库结构修复结果</h2>
            </div>
            <span class="status-pill <?= !empty($schemaRepairResult['ok']) ? 'ok' : 'bad' ?>"><?= !empty($schemaRepairResult['ok']) ? '已完成' : '需检查' ?></span>
        </div>
        <div class="audit-list">
            <?php foreach (array_slice(isset($schemaRepairResult['results']) ? $schemaRepairResult['results'] : [], 0, 18) as $result): ?>
                <div class="<?= !empty($result['ok']) ? 'ok' : 'bad' ?>">
                    <span>
                        <b><?= e(isset($result['label']) ? $result['label'] : $result['key']) ?></b>
                        <small><?= e(isset($result['message']) ? $result['message'] : '') ?></small>
                    </span>
                    <strong><?= !empty($result['ok']) ? '正常' : '需检查' ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<section class="maintenance-grid">
    <article class="form-section glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">维护模式</p>
                <h2>维护模式</h2>
            </div>
        </div>
        <form method="post" action="<?= url('admin/maintenance') ?>" class="maintenance-form">
            <?= csrf_field() ?>
            <label class="inline-check maintenance-switch">
                <input type="checkbox" name="site_maintenance" value="1" <?= $maintenanceOn ? 'checked' : '' ?>>
                <span>开启前台维护模式</span>
            </label>
            <label>维护提示文案
                <textarea name="maintenance_message" rows="4" placeholder="例如：系统正在维护升级，请稍后再访问。"><?= e($message) ?></textarea>
            </label>
            <div class="form-actions">
                <button class="btn btn-primary" type="submit" data-icon="save">保存维护设置</button>
            </div>
        </form>
    </article>

    <article class="form-section glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">数据库备份</p>
                <h2>数据库备份</h2>
            </div>
        </div>
        <p class="muted-text">导出当前项目表前缀下的完整 SQL 备份文件。建议在升级、迁移、批量维护前先导出备份。</p>
        <form method="post" action="<?= url('admin/maintenance/export-db') ?>" class="confirm-form" data-confirm="确定导出数据库备份吗？文件会通过浏览器下载。">
            <?= csrf_field() ?>
            <button class="btn btn-primary" type="submit" data-icon="download">导出数据库 SQL</button>
        </form>
    </article>

    <article class="form-section glass schema-repair-card">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">数据库结构</p>
                <h2>一键修复数据表</h2>
            </div>
        </div>
        <p class="muted-text">自动补齐缺失数据表，并执行字段、索引、存储类型、主题偏好、监控和分享仓库等升级任务。建议先导出备份。</p>
        <form method="post" action="<?= url('admin/maintenance/repair-schema') ?>" class="confirm-form maintenance-form" data-confirm="将自动补齐缺失数据表并执行字段/索引升级，建议已先导出数据库备份。确认继续吗？">
            <?= csrf_field() ?>
            <input type="hidden" name="return_to" value="schema-audit">
            <div class="form-actions">
                <button class="btn btn-primary" type="submit" data-icon="wrench">一键修复数据库结构</button>
                <a class="btn btn-ghost" href="<?= url('admin/feature-audit') ?>" data-icon="activity">查看功能巡检</a>
            </div>
        </form>
    </article>
</section>
