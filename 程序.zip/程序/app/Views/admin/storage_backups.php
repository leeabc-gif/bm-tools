<?php
$stats = isset($stats) ? $stats : ['policies' => 0, 'enabled_policies' => 0, 'success' => 0, 'failed' => 0];
$storages = isset($storages) ? $storages : [];
$policies = isset($policies) ? $policies : [];
$editPolicy = isset($editPolicy) && is_array($editPolicy) ? $editPolicy : null;
$editBackupIds = $editPolicy && !empty($editPolicy['backup_storage_id_list']) ? array_map('intval', $editPolicy['backup_storage_id_list']) : [];
$scopeLabels = ['all' => '全部文件', 'image' => '图床图片', 'file' => '网盘文件'];
$strategyLabels = ['ignore' => '忽略失败', 'warn' => '记录告警', 'strict' => '严格失败'];
$enabledStorages = array_values(array_filter($storages, function ($item) {
    return !empty($item['is_enabled']);
}));
?>

<section class="admin-page-head glass storage-backup-hero">
    <div>
        <p class="eyebrow">Storage Safety</p>
        <h1>多存储备份</h1>
        <p>把用户上传的文件同时写入多个存储厂商。主存储负责正常访问，备份存储负责容灾保底；每次备份都会记录成功、失败和可重试状态。</p>
    </div>
    <div class="admin-head-actions">
        <a class="btn btn-ghost" href="<?= url('admin/storages') ?>" data-icon="database">基础存储源</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-backups/backfill') ?>" data-icon="archive-restore">历史补备</a>
        <a class="btn btn-ghost" href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
        <a class="btn btn-primary" href="<?= url('admin/storage-backups') ?>#storage-backup-policy-form" data-icon="plus">新增策略</a>
    </div>
</section>

<nav class="storage-backup-tabs glass" aria-label="多存储备份模块">
    <a class="active" href="<?= url('admin/storage-backups') ?>" data-icon="database-backup">备份策略</a>
    <a href="<?= url('admin/storage-backups/tasks') ?>" data-icon="list-checks">备份任务</a>
    <a href="<?= url('admin/storage-backups/backfill') ?>" data-icon="archive-restore">历史补备</a>
    <a href="<?= url('admin/storage-migration') ?>" data-icon="replace-all">存储迁移</a>
</nav>

<section class="ops-metric-grid storage-backup-metrics">
    <article class="ops-metric-card glass"><span>策略总数</span><b><?= e(number_format($stats['policies'])) ?></b><small>可按主存储和文件类型分流</small></article>
    <article class="ops-metric-card glass ok"><span>启用策略</span><b><?= e(number_format($stats['enabled_policies'])) ?></b><small>上传时自动执行</small></article>
    <article class="ops-metric-card glass"><span>备份成功</span><b><?= e(number_format($stats['success'])) ?></b><small>已写入备份存储</small></article>
    <article class="ops-metric-card glass danger"><span>备份失败</span><b><?= e(number_format($stats['failed'])) ?></b><small>需要检查厂商 Key 或网络</small></article>
</section>

<section class="storage-backup-layout">
    <article class="form-section glass" id="storage-backup-policy-form">
        <div class="section-head">
            <div>
                <p class="eyebrow">Policy</p>
                <h2><?= $editPolicy ? '编辑备份策略 #' . e($editPolicy['id']) : '新建备份策略' ?></h2>
                <p>推荐先使用“记录告警”。确认两个厂商稳定后，再对关键文件开启严格模式。</p>
            </div>
            <?php if ($editPolicy): ?><a class="btn btn-ghost" href="<?= url('admin/storage-backups') ?>" data-icon="x">取消编辑</a><?php endif; ?>
        </div>
        <form method="post" action="<?= url('admin/storage-backups/save') ?>" class="form-grid two storage-backup-form">
            <?= csrf_field() ?>
            <?php if ($editPolicy): ?><input type="hidden" name="id" value="<?= e($editPolicy['id']) ?>"><?php endif; ?>
            <label>
                <span>策略名称</span>
                <input name="name" value="<?= e($editPolicy ? $editPolicy['name'] : '') ?>" placeholder="例如：默认上传双厂商备份" required>
            </label>
            <label>
                <span>适用主存储</span>
                <select name="primary_storage_id">
                    <option value="0" <?= !$editPolicy || (int) $editPolicy['primary_storage_id'] === 0 ? 'selected' : '' ?>>任意主存储</option>
                    <?php foreach ($storages as $storage): ?>
                        <option value="<?= e($storage['id']) ?>" <?= $editPolicy && (int) $editPolicy['primary_storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                <span>文件范围</span>
                <select name="file_scope">
                    <option value="all" <?= !$editPolicy || $editPolicy['file_scope'] === 'all' ? 'selected' : '' ?>>全部文件</option>
                    <option value="image" <?= $editPolicy && $editPolicy['file_scope'] === 'image' ? 'selected' : '' ?>>只备份图床图片</option>
                    <option value="file" <?= $editPolicy && $editPolicy['file_scope'] === 'file' ? 'selected' : '' ?>>只备份网盘文件</option>
                </select>
            </label>
            <label>
                <span>失败策略</span>
                <select name="failure_strategy">
                    <option value="warn" <?= !$editPolicy || $editPolicy['failure_strategy'] === 'warn' ? 'selected' : '' ?>>记录告警，主上传继续</option>
                    <option value="ignore" <?= $editPolicy && $editPolicy['failure_strategy'] === 'ignore' ? 'selected' : '' ?>>忽略失败，仅写日志</option>
                    <option value="strict" <?= $editPolicy && $editPolicy['failure_strategy'] === 'strict' ? 'selected' : '' ?>>严格失败，备份失败则上传失败</option>
                </select>
            </label>
            <label>
                <span>执行方式</span>
                <select name="mode">
                    <option value="sync" <?= !$editPolicy || $editPolicy['mode'] === 'sync' ? 'selected' : '' ?>>同步备份，上传时立即写入</option>
                </select>
                <small class="field-help">上传成功后立即写入备份目标，适合双厂商容灾；如需更高吞吐，可通过计划任务接口分批补备历史文件。</small>
            </label>
            <label>
                <span>排序</span>
                <input type="number" name="sort_order" value="<?= e($editPolicy ? $editPolicy['sort_order'] : 0) ?>">
            </label>
            <div class="storage-backup-targets span-2">
                <span>备份目标存储</span>
                <div class="storage-backup-target-grid">
                    <?php foreach ($enabledStorages as $storage): ?>
                        <label>
                            <input type="checkbox" name="backup_storage_ids[]" value="<?= e($storage['id']) ?>" <?= in_array((int) $storage['id'], $editBackupIds, true) ? 'checked' : '' ?>>
                            <b><?= e($storage['name']) ?></b>
                            <small><?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认主线' : '' ?></small>
                        </label>
                    <?php endforeach; ?>
                    <?php if (!$enabledStorages): ?>
                        <p class="empty-table">还没有可用存储源，请先在资源功能管理里新增并启用至少两个存储源。</p>
                    <?php endif; ?>
                </div>
            </div>
            <label class="inline-check span-2">
                <input type="checkbox" name="is_enabled" <?= !$editPolicy || !empty($editPolicy['is_enabled']) ? 'checked' : '' ?>>
                <span>启用该备份策略</span>
            </label>
            <div class="form-actions span-2">
                <button class="btn btn-primary" type="submit" data-icon="save"><?= $editPolicy ? '更新策略' : '保存策略' ?></button>
                <span class="form-help">同一个目标不能既是主存储又是备份存储。建议至少准备两个不同厂商或不同区域的存储源。</span>
            </div>
        </form>
    </article>

    <aside class="table-card glass storage-backup-note">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Runbook</p>
                <h2>推荐方案</h2>
            </div>
        </div>
        <div class="storage-backup-runbook">
            <p><b>标准商业方案</b><span>主存储用 OSS/COS/R2，备份目标选择另一家厂商，失败策略用“记录告警”。</span></p>
            <p><b>高可靠方案</b><span>关键业务开启严格失败，保证主备都成功后才算上传完成。</span></p>
            <p><b>低成本方案</b><span>主存储走云厂商，备份存储走本地或同系统对接，适合早期站点降成本。</span></p>
        </div>
    </aside>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Policies</p>
            <h2>备份策略列表</h2>
        </div>
    </div>
    <div class="table-wrap">
        <table class="admin-responsive-table">
            <thead>
            <tr><th>ID</th><th>策略</th><th>主存储</th><th>备份目标</th><th>范围</th><th>失败策略</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php foreach ($policies as $policy): ?>
                <tr>
                    <td data-label="ID">#<?= e($policy['id']) ?></td>
                    <td data-label="策略"><b><?= e($policy['name']) ?></b><small>排序 <?= e($policy['sort_order']) ?> / <?= e($policy['mode'] === 'sync' ? '同步' : '异步') ?></small></td>
                    <td data-label="主存储"><?= (int) $policy['primary_storage_id'] === 0 ? '任意主存储' : ('#' . e($policy['primary_storage_id'])) ?></td>
                    <td data-label="备份目标">
                        <?php foreach ($policy['backup_names'] as $name): ?><span class="status-pill soft"><?= e($name) ?></span><?php endforeach; ?>
                    </td>
                    <td data-label="范围"><?= e(isset($scopeLabels[$policy['file_scope']]) ? $scopeLabels[$policy['file_scope']] : $policy['file_scope']) ?></td>
                    <td data-label="失败策略"><?= e(isset($strategyLabels[$policy['failure_strategy']]) ? $strategyLabels[$policy['failure_strategy']] : $policy['failure_strategy']) ?></td>
                    <td data-label="状态"><span class="status-pill <?= !empty($policy['is_enabled']) ? 'ok' : 'muted' ?>"><?= !empty($policy['is_enabled']) ? '启用' : '停用' ?></span></td>
                    <td data-label="操作">
                        <a class="btn btn-ghost" href="<?= url('admin/storage-backups?id=' . $policy['id']) ?>#storage-backup-policy-form" data-icon="pencil">编辑</a>
                        <form method="post" action="<?= url('admin/storage-backups/delete') ?>" class="confirm-form" data-confirm="确认删除该备份策略吗？历史备份记录会保留。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($policy['id']) ?>">
                            <button class="btn btn-ghost danger" type="submit" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$policies): ?>
                <tr><td colspan="8" class="empty-table responsive-table-span">还没有备份策略。先创建一个策略，后续上传会自动写入备份目标。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
