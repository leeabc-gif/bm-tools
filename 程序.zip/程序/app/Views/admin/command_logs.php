<section class="bm-admin-dashboard server-ops-admin">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Command Audit</span>
            <h1>命令审计</h1>
            <p>集中查看用户在线终端命令、执行摘要和来源 IP。SSH 终端按完整运维工具处理，不对命令内容做二次确认或拦截。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/user-servers') ?>" data-icon="server-cog">用户服务器</a>
            <a class="bm-btn bm-btn-primary" href="<?= url('admin/server-ops/settings') ?>" data-icon="sliders-horizontal">运维设置</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric"><span class="bm-icon-tile"><i data-lucide="terminal"></i></span><div><small>总命令</small><strong><?= e($stats['total']) ?></strong><em>已记录审计</em></div></article>
        <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="calendar-clock"></i></span><div><small>今日</small><strong><?= e($stats['today']) ?></strong><em>当日执行次数</em></div></article>
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="triangle-alert"></i></span><div><small>历史警告</small><strong><?= e($stats['warning']) ?></strong><em>旧版本标记记录</em></div></article>
        <article class="bm-admin-metric is-red"><span class="bm-icon-tile"><i data-lucide="shield-alert"></i></span><div><small>历史危险</small><strong><?= e($stats['danger']) ?></strong><em>旧版本标记记录</em></div></article>
    </section>

    <section class="bm-admin-panel">
        <form class="server-audit-filter" method="get" action="<?= url('admin/command-logs') ?>">
            <label>
                <span>关键词</span>
                <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="命令、用户、服务器">
            </label>
            <label>
                <span>执行标记</span>
                <select name="risk">
                    <option value="">全部</option>
                    <option value="normal" <?= $filters['risk'] === 'normal' ? 'selected' : '' ?>>普通</option>
                    <option value="warning" <?= $filters['risk'] === 'warning' ? 'selected' : '' ?>>警告</option>
                    <option value="danger" <?= $filters['risk'] === 'danger' ? 'selected' : '' ?>>危险</option>
                </select>
            </label>
            <button class="bm-btn bm-btn-primary" type="submit" data-icon="search">筛选</button>
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/command-logs') ?>" data-icon="rotate-ccw">重置</a>
        </form>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head"><div><span class="bm-eyebrow">Logs</span><h2>命令记录</h2></div></div>
        <div class="bm-responsive-table server-admin-table">
            <table>
                <thead><tr><th>用户</th><th>服务器</th><th>命令</th><th>标记</th><th>输出摘要</th><th>IP</th><th>时间</th></tr></thead>
                <tbody>
                <?php if (!$logs): ?><tr><td colspan="7" class="muted responsive-table-span">暂无命令记录。</td></tr><?php endif; ?>
                <?php foreach ($logs as $row): ?>
                    <tr>
                        <td data-label="用户"><?= e($row['username'] ?: '用户 #' . $row['user_id']) ?></td>
                        <td data-label="服务器"><strong><?= e($row['server_name'] ?: '-') ?></strong><small><?= e($row['ssh_host'] ?: '-') ?></small></td>
                        <td data-label="命令"><code><?= e(text_limit($row['command'], 160)) ?></code></td>
                        <td data-label="标记"><span class="bm-state-pill risk-<?= e($row['risk_level']) ?>"><?= e($row['risk_level']) ?></span></td>
                        <td data-label="输出摘要"><span class="server-output-summary"><?= e(text_limit($row['output_summary'], 220)) ?></span></td>
                        <td data-label="IP"><?= e($row['ip'] ?: '-') ?></td>
                        <td data-label="时间"><?= e($row['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>
