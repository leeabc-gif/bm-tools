<?php
$ep = isset($editPackage) && $editPackage ? $editPackage : null;
$enabledCount = 0;
$disabledCount = 0;
foreach ($packages as $item) {
    if (!empty($item['status'])) {
        $enabledCount++;
    } else {
        $disabledCount++;
    }
}
?>

<section class="admin-package-overview glass">
    <div class="admin-package-title">
        <p class="eyebrow">套餐运营</p>
        <h1>套餐管理</h1>
        <span>配置图床、网盘、API、容量、流量和单文件限制，用于套餐售卖和用户权益控制。</span>
    </div>
    <div class="admin-package-stats">
        <div><b><?= e(count($packages)) ?></b><span>套餐总数</span></div>
        <div><b><?= e($enabledCount) ?></b><span>已启用</span></div>
        <div><b><?= e($disabledCount) ?></b><span>已停用</span></div>
    </div>
</section>

<section class="admin-package-workbench">
    <article class="table-card glass admin-package-list">
        <div class="section-head">
            <div>
                <p class="eyebrow">套餐列表</p>
                <h2>套餐列表</h2>
                <p>建议保留一个免费套餐，并将主推套餐保持启用状态。</p>
            </div>
        </div>
        <div class="package-card-list">
            <?php if (!$packages): ?>
                <div class="empty-table">暂无套餐，请先在右侧创建一个免费套餐或基础套餐。</div>
            <?php endif; ?>
            <?php foreach ($packages as $p): ?>
                <article class="package-row-card <?= $ep && (int) $ep['id'] === (int) $p['id'] ? 'editing' : '' ?>">
                    <div class="package-row-main">
                        <div>
                            <h3><?= e($p['name']) ?></h3>
                            <p><?= e($p['description'] ?: '暂无套餐说明') ?></p>
                        </div>
                        <strong>￥<?= e($p['price']) ?></strong>
                    </div>
                    <div class="package-row-meta">
                        <span>空间 <?= e(format_bytes($p['storage_limit'])) ?></span>
                        <span>流量 <?= e(format_bytes($p['traffic_limit'])) ?></span>
                        <span>单文件 <?= e(format_bytes($p['single_file_limit'])) ?></span>
                        <span>分站 <?= !empty($p['allow_subsite']) ? e((int) $p['subsite_limit']) . ' 个' : '未开通' ?></span>
                        <span class="<?= $p['status'] ? 'ok' : 'muted' ?>"><?= $p['status'] ? '启用' : '停用' ?></span>
                    </div>
                    <div class="package-row-actions">
                        <a class="btn btn-ghost btn-sm" href="<?= url('admin/packages?id=' . $p['id']) ?>" data-icon="pencil">编辑</a>
                        <form class="confirm-form" method="post" action="<?= url('admin/packages/delete') ?>" data-confirm="确定删除这个套餐吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($p['id']) ?>">
                            <button class="btn btn-ghost btn-sm" data-icon="trash-2">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </article>

    <aside class="form-section glass admin-package-editor" id="packageEditor">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">套餐表单</p>
                <h2><?= $ep ? '编辑套餐 #' . e($ep['id']) : '新增套餐' ?></h2>
            </div>
            <?php if ($ep): ?><a class="btn btn-ghost btn-sm" href="<?= url('admin/packages') ?>" data-icon="rotate-ccw">取消</a><?php endif; ?>
        </div>

        <form method="post" action="<?= url('admin/packages/save') ?>" class="admin-package-form">
            <?= csrf_field() ?>
            <?php if ($ep): ?><input type="hidden" name="id" value="<?= e($ep['id']) ?>"><?php endif; ?>

            <label>套餐名称<input name="name" value="<?= e($ep ? $ep['name'] : '') ?>" required placeholder="例如：专业版"></label>
            <div class="admin-form-two">
                <label>售价（元）<input name="price" type="number" step="0.01" value="<?= e($ep ? $ep['price'] : '0') ?>"></label>
                <label>排序<input name="sort_order" type="number" value="<?= e($ep ? $ep['sort_order'] : '0') ?>"></label>
            </div>
            <div class="admin-form-two">
                <label>时长类型<select name="duration_type">
                    <?php foreach (['month'=>'月付','quarter'=>'季付','year'=>'年付','forever'=>'永久'] as $k=>$v): ?>
                        <option value="<?= e($k) ?>" <?= $ep && $ep['duration_type']===$k?'selected':'' ?>><?= e($v) ?></option>
                    <?php endforeach; ?>
                </select></label>
                <label>有效天数<input name="duration_days" type="number" value="<?= e($ep ? $ep['duration_days'] : '30') ?>"></label>
            </div>
            <label>空间上限（字节）<input name="storage_limit" type="number" value="<?= e($ep ? $ep['storage_limit'] : '1073741824') ?>"></label>
            <label>月流量（字节）<input name="traffic_limit" type="number" value="<?= e($ep ? $ep['traffic_limit'] : '5368709120') ?>"></label>
            <label>单文件上限（字节）<input name="single_file_limit" type="number" value="<?= e($ep ? $ep['single_file_limit'] : '10485760') ?>"></label>
            <label>状态<select name="status">
                <option value="1" <?= !$ep || $ep['status']?'selected':'' ?>>启用</option>
                <option value="0" <?= $ep && !$ep['status']?'selected':'' ?>>停用</option>
            </select></label>
            <label>套餐说明<textarea name="description" placeholder="写清楚适合人群、容量、权益和使用限制"><?= e($ep ? $ep['description'] : '') ?></textarea></label>

            <div class="package-permission-grid compact">
                <label class="inline-check"><input type="checkbox" name="allow_image" <?= !$ep || $ep['allow_image']?'checked':'' ?>> 图床</label>
                <label class="inline-check"><input type="checkbox" name="allow_netdisk" <?= !$ep || $ep['allow_netdisk']?'checked':'' ?>> 网盘</label>
                <label class="inline-check"><input type="checkbox" name="allow_api" <?= $ep && $ep['allow_api']?'checked':'' ?>> API</label>
                <label class="inline-check"><input type="checkbox" name="allow_multi_storage" <?= $ep && $ep['allow_multi_storage']?'checked':'' ?>> 多存储</label>
                <label class="inline-check"><input type="checkbox" name="allow_share" <?= !$ep || $ep['allow_share']?'checked':'' ?>> 分享</label>
                <label class="inline-check"><input type="checkbox" name="allow_subsite" <?= $ep && !empty($ep['allow_subsite'])?'checked':'' ?>> 分站</label>
                <label class="inline-check"><input type="checkbox" name="allow_video_preview" <?= $ep && $ep['allow_video_preview']?'checked':'' ?>> 视频预览</label>
                <label class="inline-check"><input type="checkbox" name="allow_external_link" <?= !$ep || $ep['allow_external_link']?'checked':'' ?>> 外链</label>
                <label class="inline-check"><input type="checkbox" name="allow_monitor" <?= $ep && $ep['allow_monitor']?'checked':'' ?>> 服务器运维</label>
            </div>
            <label>分站数量上限<input name="subsite_limit" type="number" min="0" value="<?= e($ep && isset($ep['subsite_limit']) ? $ep['subsite_limit'] : '1') ?>" placeholder="例如：3"></label>

            <div class="form-actions">
                <button class="btn btn-primary full" data-icon="save">保存套餐</button>
            </div>
        </form>
    </aside>
</section>
