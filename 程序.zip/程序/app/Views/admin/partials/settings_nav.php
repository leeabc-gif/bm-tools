<?php
// Settings navigation is handled by the left sidebar.
?>
