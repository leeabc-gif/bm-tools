<?php
$settings = isset($settings) ? $settings : [];
$serverUploadLimits = isset($serverUploadLimits) && is_array($serverUploadLimits) ? $serverUploadLimits : [];
$uploadChecks = isset($uploadChecks) ? $uploadChecks : [];
$value = function ($key, $default) use ($settings) {
    return e(isset($settings[$key]) ? $settings[$key] : $default);
};
$limitCards = [
    ['label' => '前端并发', 'value' => $value('upload_max_concurrency', '2'), 'hint' => '同一用户页面同时上传的文件数'],
    ['label' => '图片批量', 'value' => $value('upload_image_batch_limit', '20'), 'hint' => '图床一次最多选择图片数量'],
    ['label' => '文件批量', 'value' => $value('upload_file_batch_limit', '10'), 'hint' => '网盘一次最多选择文件数量'],
    ['label' => '图片日上限', 'value' => $value('upload_image_daily_limit', '0'), 'hint' => '0 表示不限'],
    ['label' => '文件日上限', 'value' => $value('upload_file_daily_limit', '0'), 'hint' => '0 表示不限'],
];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">Upload Policy</p>
        <h1>上传限制</h1>
        <p>单独管理批量上传数量、前端并发和每日上传上限。图床与网盘会在上传前提示，服务端也会再次校验。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/settings/upload') ?>" data-icon="toggle-left">上传权限</a>
</section>

<section class="table-card glass upload-runtime-panel" id="upload-runtime-checks">
    <div class="section-head">
        <div>
            <p class="eyebrow">Runtime Check</p>
            <h2>上传链路状态</h2>
            <p>这里不是限制配置，而是服务器实际运行条件。若用户上传提示失败，先按异常项处理。</p>
        </div>
        <a class="btn btn-primary" href="<?= url('admin/storages') ?>" data-icon="plug-zap">存储真实测试</a>
    </div>
    <div class="audit-list service-audit-list">
        <?php foreach ($uploadChecks as $check): ?>
            <div class="<?= !empty($check['ok']) ? 'ok' : 'bad' ?>">
                <span>
                    <b><?= e($check['label']) ?></b>
                    <small><?= !empty($check['stage']) ? e($check['stage']) . ' · ' : '' ?><?= e($check['hint']) ?></small>
                </span>
                <code><?= e((string) $check['value']) ?></code>
                <?php if (!empty($check['action_url']) && $check['action_url'] !== 'admin/upload-limits'): ?>
                    <a class="btn btn-ghost btn-sm" href="<?= url($check['action_url']) ?>" data-icon="arrow-up-right"><?= e($check['action_label'] ?: '处理') ?></a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="workspace-summary-grid reveal upload-limit-summary">
    <?php foreach ($limitCards as $card): ?>
        <article class="workspace-summary-card glass">
            <span><?= e($card['label']) ?></span>
            <b><?= $card['value'] ?></b>
            <small><?= e($card['hint']) ?></small>
        </article>
    <?php endforeach; ?>
</section>

<section class="workspace-summary-grid reveal upload-runtime-summary">
    <article class="workspace-summary-card glass"><span>PHP 单文件</span><b><?= e(isset($serverUploadLimits['upload_max_filesize']) ? $serverUploadLimits['upload_max_filesize'] : '-') ?></b><small>upload_max_filesize</small></article>
    <article class="workspace-summary-card glass"><span>POST 总量</span><b><?= e(isset($serverUploadLimits['post_max_size']) ? $serverUploadLimits['post_max_size'] : '-') ?></b><small>post_max_size，批量上传会受它影响</small></article>
    <article class="workspace-summary-card glass"><span>表单文件数</span><b><?= e(isset($serverUploadLimits['max_file_uploads']) ? $serverUploadLimits['max_file_uploads'] : '-') ?></b><small>max_file_uploads</small></article>
    <article class="workspace-summary-card glass"><span>执行时间</span><b><?= e(isset($serverUploadLimits['max_execution_time']) ? $serverUploadLimits['max_execution_time'] : '-') ?>s</b><small>max_execution_time</small></article>
</section>

<section class="form-section glass upload-limit-panel">
    <div class="section-heading compact">
        <p class="eyebrow">Policy</p>
        <h2>上传队列规则</h2>
        <p>建议个人站点并发 2-3，大文件较多时保持 1-2 更稳。每日上限填 0 表示不限制。</p>
    </div>

    <form method="post" action="<?= url('admin/upload-limits') ?>" class="form-grid two upload-limit-form">
        <?= csrf_field() ?>
        <label>用户前端并发上传数
            <input name="upload_max_concurrency" type="number" min="1" max="8" value="<?= $value('upload_max_concurrency', '2') ?>">
            <small class="field-help">控制浏览器同时发送几个上传请求。过大容易触发 PHP-FPM、对象存储或服务器带宽瓶颈。</small>
        </label>

        <label>图床单次选择图片数
            <input name="upload_image_batch_limit" type="number" min="1" max="500" value="<?= $value('upload_image_batch_limit', '20') ?>">
            <small class="field-help">用户在图床页面一次最多可以选择多少张图片。</small>
        </label>

        <label>网盘单次选择文件数
            <input name="upload_file_batch_limit" type="number" min="1" max="300" value="<?= $value('upload_file_batch_limit', '10') ?>">
            <small class="field-help">用户在网盘页面一次最多可以选择多少个文件。</small>
        </label>

        <label>用户每日图片上传上限
            <input name="upload_image_daily_limit" type="number" min="0" max="1000000" value="<?= $value('upload_image_daily_limit', '0') ?>">
            <small class="field-help">按用户账号统计当天上传到 files 表的 image 记录，0 为不限。</small>
        </label>

        <label>用户每日文件上传上限
            <input name="upload_file_daily_limit" type="number" min="0" max="1000000" value="<?= $value('upload_file_daily_limit', '0') ?>">
            <small class="field-help">按用户账号统计当天上传到 files 表的 file 记录，0 为不限。</small>
        </label>

        <div class="span-all upload-limit-note">
            <i data-lucide="info"></i>
            <div>
                <strong>说明</strong>
                <span>前端会逐文件显示进度和错误原因；服务端仍会按套餐容量、单文件大小、文件类型、对象存储状态和本页限制做最终判断。若仍提示超过服务器限制，请调大 PHP 的 upload_max_filesize 和 post_max_size。</span>
            </div>
        </div>

        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存限制</button>
        </div>
    </form>
</section>
