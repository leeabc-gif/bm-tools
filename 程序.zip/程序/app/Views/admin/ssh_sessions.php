<section class="bm-admin-dashboard server-ops-admin">
    <header class="bm-admin-hero">
        <div>
            <span class="bm-eyebrow">Gateway Sessions</span>
            <h1>SSH 会话</h1>
            <p>记录 Web SSH 网关令牌的签发、连接、关闭和过期状态。命令模式也会签发一次性令牌，后续可平滑接入独立 WebSocket 网关。</p>
        </div>
        <div class="bm-action-row">
            <a class="bm-btn bm-btn-soft" href="<?= url('admin/user-servers') ?>" data-icon="server-cog">用户服务器</a>
            <a class="bm-btn bm-btn-primary" href="<?= url('admin/server-ops/settings') ?>" data-icon="sliders-horizontal">运维设置</a>
        </div>
    </header>

    <section class="bm-admin-metric-grid">
        <article class="bm-admin-metric"><span class="bm-icon-tile"><i data-lucide="key-round"></i></span><div><small>已签发</small><strong><?= e($stats['issued']) ?></strong><em>等待连接或命令模式使用</em></div></article>
        <article class="bm-admin-metric is-green"><span class="bm-icon-tile"><i data-lucide="screen-share"></i></span><div><small>已连接</small><strong><?= e($stats['connected']) ?></strong><em>网关实时会话</em></div></article>
        <article class="bm-admin-metric is-purple"><span class="bm-icon-tile"><i data-lucide="check-circle-2"></i></span><div><small>已结束</small><strong><?= e($stats['closed']) ?></strong><em>关闭或过期</em></div></article>
        <article class="bm-admin-metric is-orange"><span class="bm-icon-tile"><i data-lucide="circle-alert"></i></span><div><small>失败</small><strong><?= e($stats['failed']) ?></strong><em>连接异常</em></div></article>
    </section>

    <section class="bm-admin-panel">
        <div class="bm-card-head"><div><span class="bm-eyebrow">Audit</span><h2>最近会话</h2></div></div>
        <div class="bm-responsive-table server-admin-table">
            <table>
                <thead><tr><th>ID</th><th>用户</th><th>服务器</th><th>状态</th><th>网关</th><th>IP</th><th>过期时间</th><th>创建时间</th></tr></thead>
                <tbody>
                <?php if (!$sessions): ?><tr><td colspan="8" class="muted responsive-table-span">暂无 SSH 会话。</td></tr><?php endif; ?>
                <?php foreach ($sessions as $row): ?>
                    <tr>
                        <td data-label="ID"><?= e($row['id']) ?></td>
                        <td data-label="用户"><?= e($row['username'] ?: '用户 #' . $row['user_id']) ?></td>
                        <td data-label="服务器"><strong><?= e($row['server_name'] ?: '-') ?></strong><small><?= e($row['ssh_host'] ?: '-') ?></small></td>
                        <td data-label="状态"><span class="bm-state-pill"><?= e($row['status']) ?></span></td>
                        <td data-label="网关"><?= e($row['gateway_url'] ?: '命令模式') ?></td>
                        <td data-label="IP"><?= e($row['ip'] ?: '-') ?></td>
                        <td data-label="过期时间"><?= e($row['expires_at']) ?></td>
                        <td data-label="创建时间"><?= e($row['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>
