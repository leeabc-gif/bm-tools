<?php
$screenData = isset($screenData) && is_array($screenData) ? $screenData : [];
$overview = isset($screenData['overview']) ? $screenData['overview'] : [];
$business = isset($screenData['business']) ? $screenData['business'] : [];
$assets = isset($screenData['assets']) ? $screenData['assets'] : [];
$service = isset($screenData['service']) ? $screenData['service'] : [];
$revenueTrend = isset($screenData['revenueTrend']) ? $screenData['revenueTrend'] : [];
$growthTrend = isset($screenData['growthTrend']) ? $screenData['growthTrend'] : [];
$topUsers = isset($screenData['topUsers']) ? $screenData['topUsers'] : [];
$latestFiles = isset($screenData['latestFiles']) ? $screenData['latestFiles'] : [];
$recentOrders = isset($screenData['recentOrders']) ? $screenData['recentOrders'] : [];
$alerts = isset($screenData['alerts']) ? $screenData['alerts'] : [];
$conversionCards = isset($screenData['conversionCards']) ? $screenData['conversionCards'] : [];
$distribution = isset($screenData['distribution']) ? $screenData['distribution'] : [];
$opsSummary = isset($screenData['opsSummary']) ? $screenData['opsSummary'] : [];
$meta = isset($screenData['meta']) ? $screenData['meta'] : [];
$currentRange = isset($meta['range']) ? $meta['range'] : '7d';
$currentRangeLabel = isset($meta['range_label']) ? $meta['range_label'] : '近7天';
$rangeOptions = isset($meta['range_options']) && is_array($meta['range_options']) ? $meta['range_options'] : [];

$revenueMax = 1.0;
foreach ($revenueTrend as $row) {
    $revenueMax = max($revenueMax, (float) $row['orders_total'], (float) $row['recharge_total']);
}
$growthMax = 1;
foreach ($growthTrend as $row) {
    $growthMax = max($growthMax, (int) $row['users'], (int) $row['files']);
}
$buildPolyline = function (array $rows, $key, $maxValue, $top = 12, $bottom = 88) {
    $points = [];
    $count = count($rows);
    $range = $bottom - $top;
    $last = max(1, $count - 1);
    foreach (array_values($rows) as $index => $row) {
        $x = $count > 1 ? round(($index / $last) * 100, 2) : 50;
        $value = isset($row[$key]) ? (float) $row[$key] : 0;
        $y = round($bottom - (($value / max(1, (float) $maxValue)) * $range), 2);
        $points[] = $x . ',' . $y;
    }
    return implode(' ', $points);
};
$ordersLine = $buildPolyline($revenueTrend, 'orders_total', $revenueMax);
$rechargeLine = $buildPolyline($revenueTrend, 'recharge_total', $revenueMax);
$usersLine = $buildPolyline($growthTrend, 'users', $growthMax);
$filesLine = $buildPolyline($growthTrend, 'files', $growthMax);
$storagePercent = !empty($assets['user_storage_total']) ? min(100, round(((float) $assets['user_storage_used'] / (float) $assets['user_storage_total']) * 100, 1)) : 0;
$monitorPercent = !empty($service['monitor_total']) ? min(100, round(((float) $service['monitor_online'] / (float) $service['monitor_total']) * 100, 1)) : 0;
$apiSuccessPercent = !empty($service['api_today_total']) ? min(100, round(((float) $service['api_today_success'] / (float) $service['api_today_total']) * 100, 1)) : 0;
$generatedAt = isset($meta['generated_at']) ? $meta['generated_at'] : now();
$refreshSeconds = isset($meta['refresh_seconds']) ? max(15, (int) $meta['refresh_seconds']) : 60;
?>

<section class="bm-admin-dashboard bm-admin-screen">
    <header class="bm-admin-hero bm-admin-screen-hero">
        <div class="bm-admin-screen-copy">
            <span class="bm-eyebrow">数据大屏</span>
            <h1>后台数据大屏</h1>
            <p>将站点经营、内容资产、交易转化与服务稳定性汇总到一张页面，适合运营巡检、管理汇报和日常看盘。</p>
        </div>
        <div class="bm-action-row bm-admin-screen-actions">
            <div class="bm-admin-screen-action-main">
                <span class="bm-admin-screen-stamp">刷新于 <?= e($generatedAt) ?></span>
                <div class="bm-admin-screen-range-switch">
                    <?php foreach ($rangeOptions as $key => $option): ?>
                        <a class="bm-btn bm-btn-soft <?= $currentRange === $key ? 'is-active' : '' ?>" href="<?= url('admin/screen?range=' . $key) ?>"><?= e($option['label']) ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="bm-admin-screen-action-links">
                <button class="bm-btn bm-btn-soft" type="button" data-screen-refresh data-icon="refresh-cw">立即刷新</button>
                <button class="bm-btn bm-btn-soft" type="button" data-screen-fullscreen data-icon="expand">全屏展示</button>
                <button class="bm-btn bm-btn-soft is-active" type="button" data-screen-autorefresh data-refresh-seconds="<?= e($refreshSeconds) ?>" data-icon="timer-reset">自动刷新 <?= e($refreshSeconds) ?> 秒</button>
                <a class="bm-btn bm-btn-primary" href="<?= url('admin/orders') ?>" data-icon="receipt-text">查看订单</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('admin/files') ?>" data-icon="files">查看资产</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('admin/monitors') ?>" data-icon="activity">服务监控</a>
            </div>
        </div>
    </header>

    <section class="bm-admin-panel bm-admin-screen-panel bm-admin-screen-alert-panel">
        <div class="bm-card-head">
            <div>
                    <span class="bm-eyebrow">运营告警</span>
                <h2>运营告警与待处理事项</h2>
            </div>
                <strong class="bm-screen-accent"><?= e(count($alerts)) ?> 项待关注</strong>
        </div>
        <div class="bm-admin-screen-alert-grid">
            <?php foreach ($alerts as $alert): ?>
                <a class="bm-admin-screen-alert is-<?= e($alert['level']) ?>" href="<?= url($alert['url']) ?>">
                    <span class="bm-icon-tile"><i data-lucide="<?= e($alert['icon']) ?>"></i></span>
                    <div>
                        <small><?= e($alert['title']) ?></small>
                        <strong><?= e($alert['value']) ?></strong>
                        <em><?= e($alert['detail']) ?></em>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="bm-admin-metric-grid bm-admin-screen-metrics">
        <?php foreach ($overview as $item): ?>
            <article class="bm-admin-metric is-<?= e($item['tone']) ?>">
                <span class="bm-icon-tile"><i data-lucide="<?= e($item['icon']) ?>"></i></span>
                <div>
                    <small><?= e($item['label']) ?></small>
                    <strong><?= e($item['value']) ?></strong>
                    <em><?= e($item['delta']) ?></em>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="bm-admin-screen-conversion-grid">
        <?php foreach ($conversionCards as $card): ?>
            <article class="bm-admin-panel bm-admin-screen-panel bm-admin-screen-conversion-card is-<?= e($card['tone']) ?>">
                <small><?= e($card['label']) ?></small>
                <strong><?= e($card['value']) ?><em><?= e($card['suffix']) ?></em></strong>
                <p><?= e($card['detail']) ?></p>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="bm-admin-screen-grid-wide">
        <article class="bm-admin-panel bm-admin-screen-panel bm-admin-screen-chart-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">交易走势</span>
                    <h2><?= e($currentRangeLabel) ?>交易与充值走势</h2>
                </div>
                <strong class="bm-screen-accent"><?= e($currentRangeLabel) ?>成交额 ¥<?= e(number_format((float) $business['month_income'], 2)) ?></strong>
            </div>
            <div class="bm-admin-screen-kpi-grid">
                <div><span><?= e($currentRangeLabel) ?>订单</span><strong>¥<?= e(number_format((float) $business['today_income'], 2)) ?></strong><small><?= e((int) $business['today_income_count']) ?> 笔支付成功</small></div>
                <div><span><?= e($currentRangeLabel) ?>充值</span><strong>¥<?= e(number_format((float) $business['today_recharge'], 2)) ?></strong><small><?= e((int) $business['today_recharge_count']) ?> 笔到账</small></div>
                <div><span>待处理</span><strong><?= e((int) $business['pending_orders'] + (int) $business['pending_recharges']) ?></strong><small>订单 <?= e((int) $business['pending_orders']) ?> / 充值 <?= e((int) $business['pending_recharges']) ?></small></div>
            </div>
            <div class="bm-admin-line-chart bm-admin-screen-chart" role="img" aria-label="时间范围内订单收入和充值收入趋势图">
                <svg viewBox="0 0 100 100" preserveAspectRatio="none">
                    <g class="bm-chart-grid">
                        <line x1="0" y1="12" x2="100" y2="12"></line>
                        <line x1="0" y1="31" x2="100" y2="31"></line>
                        <line x1="0" y1="50" x2="100" y2="50"></line>
                        <line x1="0" y1="69" x2="100" y2="69"></line>
                        <line x1="0" y1="88" x2="100" y2="88"></line>
                    </g>
                    <polyline class="bm-chart-line orders" points="<?= e($ordersLine) ?>"></polyline>
                    <polyline class="bm-chart-line recharge" points="<?= e($rechargeLine) ?>"></polyline>
                </svg>
            </div>
            <div class="bm-admin-chart-foot">
                <div>
                    <?php foreach ($revenueTrend as $row): ?>
                        <span><?= e($row['day']) ?></span>
                    <?php endforeach; ?>
                </div>
                <p><i class="orders"></i>订单收入 <i class="recharge"></i>充值收入</p>
            </div>
        </article>

        <aside class="bm-admin-panel bm-admin-screen-panel bm-admin-screen-side-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">经营概览</span>
                    <h2>核心经营快照</h2>
                </div>
            </div>
            <div class="bm-admin-screen-list">
                <div><span>本月成交订单</span><strong><?= e((int) $business['month_income_count']) ?> 笔</strong></div>
                <div><span>用户余额池</span><strong>¥<?= e(number_format((float) $business['total_balance'], 2)) ?></strong></div>
                <div><span>默认存储</span><strong><?= !empty($service['storage_default']) ? '已配置' : '未配置' ?></strong></div>
                <div><span>监控离线</span><strong><?= e((int) $service['monitor_offline']) ?> 台</strong></div>
            </div>
            <div class="bm-admin-screen-progress-stack">
                <div><span>监控在线率</span><b><?= e($monitorPercent) ?>%</b><i><em style="width:<?= e($monitorPercent) ?>%"></em></i></div>
                <div><span>API 成功率</span><b><?= e($apiSuccessPercent) ?>%</b><i><em style="width:<?= e($apiSuccessPercent) ?>%"></em></i></div>
                <div><span>用户存储使用率</span><b><?= e($storagePercent) ?>%</b><i><em style="width:<?= e($storagePercent) ?>%"></em></i></div>
            </div>
        </aside>
    </section>

    <section class="bm-admin-screen-grid">
        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">增长趋势</span>
                    <h2><?= e($currentRangeLabel) ?>新增用户与内容走势</h2>
                </div>
            </div>
            <div class="bm-admin-line-chart bm-admin-screen-chart bm-admin-screen-chart-alt" role="img" aria-label="时间范围内新增用户和新增内容趋势图">
                <svg viewBox="0 0 100 100" preserveAspectRatio="none">
                    <g class="bm-chart-grid">
                        <line x1="0" y1="12" x2="100" y2="12"></line>
                        <line x1="0" y1="31" x2="100" y2="31"></line>
                        <line x1="0" y1="50" x2="100" y2="50"></line>
                        <line x1="0" y1="69" x2="100" y2="69"></line>
                        <line x1="0" y1="88" x2="100" y2="88"></line>
                    </g>
                    <polyline class="bm-chart-line orders" points="<?= e($usersLine) ?>"></polyline>
                    <polyline class="bm-chart-line recharge" points="<?= e($filesLine) ?>"></polyline>
                </svg>
            </div>
            <div class="bm-admin-chart-foot">
                <div>
                    <?php foreach ($growthTrend as $row): ?>
                        <span><?= e($row['day']) ?></span>
                    <?php endforeach; ?>
                </div>
                <p><i class="orders"></i>新增用户 <i class="recharge"></i>新增内容</p>
            </div>
        </article>

        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">资产总览</span>
                    <h2>内容与服务资产概览</h2>
                </div>
            </div>
            <div class="bm-admin-screen-stat-grid">
                <div><span>图片资源</span><strong><?= e(number_format((int) $assets['images'])) ?></strong><small>图床与预览内容</small></div>
                <div><span>普通文件</span><strong><?= e(number_format((int) $assets['files'])) ?></strong><small>网盘与附件</small></div>
                <div><span>内容占用</span><strong><?= e(format_bytes((float) $assets['storage_used'])) ?></strong><small>全站托管体积</small></div>
                <div><span>仓库数量</span><strong><?= e(number_format((int) $assets['repository_total'])) ?></strong><small>待处理 <?= e((int) $assets['repository_pending']) ?></small></div>
                <div><span>分站数量</span><strong><?= e(number_format((int) $assets['subsite_total'])) ?></strong><small>启用 <?= e((int) $assets['subsite_active']) ?></small></div>
                <div><span>存储线路</span><strong><?= e(number_format((int) $service['storage_total'])) ?></strong><small>启用 <?= e((int) $service['storage_enabled']) ?></small></div>
            </div>
        </article>
    </section>

    <section class="bm-admin-screen-grid">
        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">订单分布</span>
                    <h2>订单状态结构</h2>
                </div>
            </div>
            <div class="bm-admin-screen-bars">
                <?php foreach ((isset($distribution['orders']) ? $distribution['orders'] : []) as $row): ?>
                    <div class="bm-admin-screen-bar-item">
                        <div><span><?= e($row['label']) ?></span><b><?= e(number_format((int) $row['value'])) ?></b></div>
                        <i><em style="width:<?= e(max(6, min(100, (($row['value'] / max(1, array_sum(array_column(isset($distribution['orders']) ? $distribution['orders'] : [], 'value')))) * 100)))) ?>%"></em></i>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">内容结构</span>
                    <h2>文件类型结构</h2>
                </div>
            </div>
            <div class="bm-admin-screen-bars">
                <?php foreach ((isset($distribution['files']) ? $distribution['files'] : []) as $row): ?>
                    <div class="bm-admin-screen-bar-item">
                        <div><span><?= e($row['label']) ?></span><b><?= e(number_format((int) $row['value'])) ?></b></div>
                        <i><em style="width:<?= e(max(6, min(100, (($row['value'] / max(1, array_sum(array_column(isset($distribution['files']) ? $distribution['files'] : [], 'value')))) * 100)))) ?>%"></em></i>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>
    </section>

    <section class="bm-admin-screen-grid">
        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">运营摘要</span>
                    <h2>运营摘要</h2>
                </div>
            </div>
            <div class="bm-admin-screen-summary-grid">
                <?php foreach ($opsSummary as $item): ?>
                    <div class="bm-admin-screen-summary-item">
                        <span><?= e($item['label']) ?></span>
                        <strong><?= e(number_format((int) $item['value'])) ?></strong>
                        <small><?= e($item['detail']) ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">待办矩阵</span>
                    <h2>待处理事项矩阵</h2>
                </div>
            </div>
            <div class="bm-admin-screen-stat-grid bm-admin-screen-stat-grid-compact">
                <?php foreach ((isset($distribution['todos']) ? $distribution['todos'] : []) as $row): ?>
                    <div><span><?= e($row['label']) ?></span><strong><?= e(number_format((int) $row['value'])) ?></strong><small>建议纳入今日巡检</small></div>
                <?php endforeach; ?>
            </div>
        </article>
    </section>

    <section class="bm-admin-screen-grid">
        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">高占用用户</span>
                    <h2>高占用用户排行</h2>
                </div>
                <a class="bm-text-link" href="<?= url('admin/users') ?>">用户管理</a>
            </div>
            <div class="bm-admin-screen-ranking">
                <?php if ($topUsers): ?>
                    <?php foreach ($topUsers as $index => $user): ?>
                        <?php $userTotalStorage = isset($user['total_storage']) ? (float) $user['total_storage'] : 0; ?>
                        <?php $userUsedStorage = isset($user['used_storage']) ? (float) $user['used_storage'] : 0; ?>
                        <?php $userPercent = $userTotalStorage > 0 ? min(100, round(($userUsedStorage / $userTotalStorage) * 100, 1)) : 0; ?>
                        <div class="bm-admin-screen-ranking-item">
                            <span class="bm-admin-screen-rank-no"><?= e($index + 1) ?></span>
                            <div>
                                <strong><?= e($user['nickname'] ?: $user['username'] ?: ('用户 #' . $user['id'])) ?></strong>
                                <small>已用 <?= e(format_bytes($userUsedStorage)) ?> / <?= e($userTotalStorage > 0 ? format_bytes($userTotalStorage) : '不限') ?></small>
                                <i><em style="width:<?= e($userPercent) ?>%"></em></i>
                            </div>
                            <b><?= e($userPercent) ?>%</b>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="bm-empty-line">暂无用户数据。</div>
                <?php endif; ?>
            </div>
        </article>

        <article class="bm-admin-panel bm-admin-screen-panel">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">最新动态</span>
                    <h2>最新内容更新</h2>
                </div>
                <a class="bm-text-link" href="<?= url('admin/files') ?>">全部文件</a>
            </div>
            <div class="bm-admin-screen-feed">
                <?php if ($latestFiles): ?>
                    <?php foreach ($latestFiles as $file): ?>
                        <div class="bm-admin-screen-feed-item">
                            <span class="bm-icon-tile is-small"><i data-lucide="<?= e($file['file_type'] === 'image' ? 'image' : 'file') ?>"></i></span>
                            <div>
                                <strong><?= e($file['original_name'] ?: '-') ?></strong>
                                <small><?= e($file['nickname'] ?: $file['username'] ?: '-') ?> · <?= e(format_bytes((float) $file['file_size'])) ?> · <?= e($file['created_at']) ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="bm-empty-line">暂无最新文件动态。</div>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <section class="bm-admin-panel bm-admin-screen-panel">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">订单动态</span>
                <h2>最近订单变化</h2>
            </div>
            <a class="bm-text-link" href="<?= url('admin/orders') ?>">查看全部</a>
        </div>
        <div class="bm-admin-table">
            <div class="bm-admin-table-head">
                <span>订单号</span><span>用户</span><span>类型</span><span>套餐</span><span>金额</span><span>状态</span>
            </div>
            <?php if ($recentOrders): ?>
                <?php foreach ($recentOrders as $order): ?>
                    <div class="bm-admin-table-row">
                        <span title="<?= e($order['order_no']) ?>"><?= e($order['order_no']) ?></span>
                        <span><?= e($order['nickname'] ?: $order['username'] ?: '-') ?></span>
                        <span><?= e($order['type'] === 'recharge' ? '充值' : '套餐') ?></span>
                        <span><?= e($order['package_name'] ?: '-') ?></span>
                        <span>¥<?= e(number_format((float) $order['pay_amount'], 2)) ?></span>
                        <span><em class="bm-state-pill"><?= e($order['status']) ?></em></span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="bm-empty-line">暂无订单记录。</div>
            <?php endif; ?>
        </div>
    </section>
</section>

<script>
(function () {
    var refreshButton = document.querySelector('[data-screen-refresh]');
    var fullscreenButton = document.querySelector('[data-screen-fullscreen]');
    var autoButton = document.querySelector('[data-screen-autorefresh]');
    var refreshTimer = null;
    var refreshSeconds = autoButton ? parseInt(autoButton.getAttribute('data-refresh-seconds') || '60', 10) : 60;
    var autoEnabled = !!autoButton;

    function triggerRefresh() {
        window.location.reload();
    }

    function startAutoRefresh() {
        if (!autoButton || !autoEnabled) {
            return;
        }
        clearAutoRefreshTimer();
        refreshTimer = window.setTimeout(triggerRefresh, Math.max(15, refreshSeconds) * 1000);
        autoButton.classList.add('is-active');
        autoButton.setAttribute('aria-pressed', 'true');
    }

    function clearAutoRefreshTimer() {
        if (refreshTimer) {
            window.clearTimeout(refreshTimer);
            refreshTimer = null;
        }
    }

    function stopAutoRefresh() {
        autoEnabled = false;
        clearAutoRefreshTimer();
        if (autoButton) {
            autoButton.classList.remove('is-active');
            autoButton.setAttribute('aria-pressed', 'false');
        }
    }

    function pauseAutoRefresh() {
        clearAutoRefreshTimer();
    }

    if (refreshButton) {
        refreshButton.addEventListener('click', triggerRefresh);
    }

    if (fullscreenButton) {
        fullscreenButton.addEventListener('click', function () {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen();
                return;
            }
            document.exitFullscreen();
        });
    }

    if (autoButton) {
        autoButton.addEventListener('click', function () {
            if (refreshTimer) {
                stopAutoRefresh();
            } else {
                autoEnabled = true;
                startAutoRefresh();
            }
        });
        startAutoRefresh();
    }

    document.addEventListener('visibilitychange', function () {
        if (!autoButton) {
            return;
        }
        if (document.hidden) {
            pauseAutoRefresh();
        } else if (autoEnabled) {
            startAutoRefresh();
        }
    });
})();
</script>
