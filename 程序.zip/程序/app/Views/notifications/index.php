<section class="bm-workspace notifications-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Messages</span>
            <h1>通知中心</h1>
            <p>系统消息、套餐提醒和业务通知集中展示。已读消息会弱化显示，重要信息保留清晰层级。</p>
            <form method="post" action="<?= url('notifications/read-all') ?>">
                <?= csrf_field() ?>
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="check-check">一键已读</button>
            </form>
        </div>
    </header>

    <section class="bm-notice-list">
        <?php if (!$notifications): ?>
            <div class="bm-empty-state">
                <i data-lucide="bell-off"></i>
                <strong>暂无通知</strong>
                <span>系统消息、套餐提醒和业务反馈会统一显示在这里。</span>
            </div>
        <?php endif; ?>
        <?php foreach ($notifications as $item): ?>
            <article class="bm-notice-card <?= $item['is_read'] ? 'is-read' : '' ?>">
                <span class="bm-icon-tile is-small"><i data-lucide="<?= $item['is_read'] ? 'mail-open' : 'mail' ?>"></i></span>
                <div>
                    <h2><?= e($item['title']) ?></h2>
                    <p><?= e($item['content']) ?></p>
                    <time><?= e($item['created_at']) ?></time>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
