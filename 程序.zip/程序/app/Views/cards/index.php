<?php
$user = \App\Core\Auth::user();
$typeNames = ['balance' => '余额充值', 'package' => '套餐兑换'];
?>

<section class="bm-workspace cards-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Redeem Card</span>
            <h1>卡密兑换</h1>
            <p>输入平台发放的卡密，可自动充值余额或兑换套餐权益。卡密一经兑换会绑定当前账号，请确认登录的是自己的账号。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('recharge') ?>" data-icon="wallet">账户充值</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('packages') ?>" data-icon="package">套餐价格</a>
            </div>
        </div>
    </header>

    <section class="bm-recharge-grid">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Redeem</span>
                    <h2>输入卡密</h2>
                </div>
                <span class="bm-state-pill"><?= e($user ? $user['username'] : '') ?></span>
            </div>
            <form method="post" action="<?= url('cards/redeem') ?>" class="bm-recharge-form">
                <?= csrf_field() ?>
                <label>
                    <span>卡密</span>
                    <input name="code" required autocomplete="off" placeholder="例如 BM-ABCD-2345-EFGH-6789">
                    <small>支持带横线或不带横线输入。连续输错过多会临时锁定兑换入口。</small>
                </label>
                <button class="bm-btn bm-btn-primary" type="submit" data-icon="ticket-check">立即兑换</button>
            </form>
        </article>

        <aside class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Guide</span>
                    <h2>兑换说明</h2>
                </div>
            </div>
            <div class="bm-guide-list">
                <div><strong>余额卡</strong><span>兑换成功后余额立即到账，可用于购买套餐、续费或后续增值服务。</span></div>
                <div><strong>套餐卡</strong><span>兑换成功后会直接切换套餐。相同套餐未到期时会自动顺延有效期。</span></div>
                <div><strong>安全提醒</strong><span>卡密只认首次兑换账号。请不要把未兑换卡密发给陌生人或公开贴在网页上。</span></div>
            </div>
        </aside>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Redeem Logs</span>
                <h2>最近兑换记录</h2>
            </div>
            <a class="bm-btn bm-btn-soft" href="<?= url('orders') ?>" data-icon="receipt-text">订单记录</a>
        </div>
        <div class="bm-record-list">
            <?php if (!$records): ?>
                <div class="bm-empty-line">暂无兑换记录。</div>
            <?php endif; ?>
            <?php foreach ($records as $row): ?>
                <article class="bm-record-card is-compact">
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="ticket"></i></span>
                        <div>
                            <strong><?= e(isset($typeNames[$row['type']]) ? $typeNames[$row['type']] : $row['type']) ?></strong>
                            <small><?= e($row['used_at']) ?> · 尾号 <?= e($row['code_preview']) ?></small>
                        </div>
                    </div>
                    <div class="bm-record-meta">
                        <span><b>内容</b>
                            <?php if ($row['type'] === 'balance'): ?>
                                余额 ¥<?= e(number_format((float) $row['amount'], 2)) ?>
                            <?php else: ?>
                                <?= e($row['package_name'] ?: '套餐') ?> <?= (int) $row['duration_days'] > 0 ? e($row['duration_days']) . ' 天' : '套餐原时长' ?>
                            <?php endif; ?>
                        </span>
                        <span><b>订单</b><?= e($row['order_no'] ?: '-') ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>
