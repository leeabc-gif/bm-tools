<?php
$files = isset($files) && is_array($files) ? $files : [];
$downloadLinks = array_map(function ($file) {
    return !empty($file['can_download']) && isset($file['download_url']) ? $file['download_url'] : '';
}, $files);
$downloadLinks = array_values(array_filter($downloadLinks));
$imageCount = 0;
$fileCount = 0;
$unavailableCount = 0;
foreach ($files as $file) {
    if (($file['file_type'] ?? '') === 'image') {
        $imageCount++;
    } else {
        $fileCount++;
    }
    if (empty($file['can_download'])) {
        $unavailableCount++;
    }
}
?>

<section class="bm-workspace netdisk-batch-download-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Batch Download</span>
            <h1>批量下载队列</h1>
            <p>已为你整理选中的文件。可以逐个下载，也可以按顺序触发下载；每次下载都会走个人网盘下载记录和次数统计。</p>
            <div class="bm-action-row">
                <button class="bm-btn bm-btn-primary batch-download-start" type="button" data-icon="download">开始下载全部</button>
                <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-copy-selector="textarea" data-icon="copy">复制全部链接</button>
                <a class="bm-btn bm-btn-soft" href="<?= url('netdisk?folder_id=' . (int) $currentFolderId) ?>" data-icon="arrow-left">返回网盘</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>选中文件</span><strong><?= e(number_format(count($files))) ?></strong><small>批量队列</small></article>
        <article class="bm-stat-card"><span>图片</span><strong><?= e(number_format($imageCount)) ?></strong><small>图床或图片文件</small></article>
        <article class="bm-stat-card"><span>普通文件</span><strong><?= e(number_format($fileCount)) ?></strong><small>网盘文件</small></article>
        <article class="bm-stat-card <?= $unavailableCount > 0 ? 'is-warn' : '' ?>"><span>总大小</span><strong><?= e(format_bytes((int) $totalSize)) ?></strong><small><?= $unavailableCount > 0 ? e($unavailableCount . ' 个链接需检查') : '实际下载速度取决于存储源' ?></small></article>
    </section>

    <section class="bm-card batch-download-links">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Links</span>
                <h2>下载链接</h2>
            </div>
        </div>
        <textarea readonly rows="5"><?= e(implode("\n", $downloadLinks)) ?></textarea>
        <div class="upload-limit-note">
            <i data-lucide="info"></i>
            <div>
                <strong>说明</strong>
                <span>批量触发会按顺序打开下载链接。若浏览器拦截多文件下载，请复制全部链接，或在下方逐个点击下载。</span>
            </div>
        </div>
    </section>

    <section class="bm-record-list batch-download-list">
        <?php if (!$files): ?>
            <article class="bm-empty-state">
                <i data-lucide="file-x"></i>
                <strong>没有可下载文件</strong>
                <span>请返回网盘重新选择文件。</span>
                <a class="bm-btn bm-btn-primary" href="<?= url('netdisk') ?>" data-icon="hard-drive">返回网盘</a>
            </article>
        <?php endif; ?>

        <?php foreach ($files as $file): ?>
            <?php $canDownload = !empty($file['can_download']); ?>
            <article class="bm-record-card batch-download-item <?= $canDownload ? '' : 'is-disabled' ?>" <?= $canDownload ? 'data-download-url="' . e($file['download_url']) . '"' : '' ?>>
                <div class="bm-record-main">
                    <span class="bm-icon-tile is-small"><i data-lucide="<?= ($file['file_type'] ?? '') === 'image' ? 'image' : 'file' ?>"></i></span>
                    <div>
                        <strong><?= e($file['original_name']) ?></strong>
                        <small><?= e(format_bytes((int) $file['file_size'])) ?> · 下载 <?= e((int) ($file['download_count'] ?? 0)) ?> 次 · <?= e($file['created_at']) ?></small>
                    </div>
                </div>
                <div class="bm-record-meta">
                    <span><b>类型</b><?= e(($file['file_type'] ?? '') === 'image' ? '图片' : '文件') ?></span>
                    <span><b>扩展名</b><?= e($file['file_ext'] ?: '-') ?></span>
                    <span><b>状态</b><em class="status-pill <?= $canDownload ? 'muted' : 'danger' ?> batch-download-state"><?= $canDownload ? '等待' : '链接异常' ?></em></span>
                </div>
                <div class="bm-record-actions">
                    <?php if ($canDownload): ?>
                        <a class="bm-btn bm-btn-primary" href="<?= e($file['download_url']) ?>" data-icon="download">下载</a>
                    <?php else: ?>
                        <button class="bm-btn bm-btn-plain" type="button" disabled data-icon="circle-off">不可下载</button>
                    <?php endif; ?>
                    <?php if (($file['file_type'] ?? '') === 'image'): ?>
                        <a class="bm-btn bm-btn-soft" href="<?= url('files/detail?id=' . (int) $file['id']) ?>" data-icon="eye">详情</a>
                    <?php endif; ?>
                    <?php if ($canDownload): ?>
                        <button class="bm-btn bm-btn-soft copy-text-btn" type="button" data-copy-text="<?= e($file['download_url']) ?>" data-icon="copy">复制</button>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
