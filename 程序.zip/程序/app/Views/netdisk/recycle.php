<?php
$totalSize = 0;
$imageCount = 0;
$fileCount = 0;
foreach ($items as $item) {
    $file = isset($item['file']) && is_array($item['file']) ? $item['file'] : [];
    $totalSize += isset($file['file_size']) ? (int) $file['file_size'] : 0;
    if (($file['file_type'] ?? '') === 'image') {
        $imageCount++;
    } else {
        $fileCount++;
    }
}
?>

<section class="bm-workspace recycle-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Recycle Bin</span>
            <h1>回收站</h1>
            <p>误删的图片和网盘文件会先保存在这里。你可以恢复文件，也可以彻底删除远端对象。彻底删除后无法恢复。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('netdisk') ?>" data-icon="hard-drive">返回网盘</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('files') ?>" data-icon="image">返回图床</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>待处理文件</span><strong><?= e(number_format(count($items))) ?></strong><small>可恢复或彻底删除</small></article>
        <article class="bm-stat-card"><span>图片</span><strong><?= e(number_format($imageCount)) ?></strong><small>图床类资源</small></article>
        <article class="bm-stat-card"><span>普通文件</span><strong><?= e(number_format($fileCount)) ?></strong><small>网盘类资源</small></article>
        <article class="bm-stat-card <?= $totalSize > 0 ? 'is-warn' : '' ?>"><span>占用空间</span><strong><?= e(format_bytes($totalSize)) ?></strong><small>彻底删除后释放</small></article>
    </section>

    <section class="bm-record-list">
        <?php if (!$items): ?>
            <article class="bm-empty-state">
                <i data-lucide="shield-check"></i>
                <strong>回收站为空</strong>
                <span>当前没有待恢复或待清理的文件。</span>
            </article>
        <?php endif; ?>

        <?php foreach ($items as $item): ?>
            <?php
            $file = isset($item['file']) && is_array($item['file']) ? $item['file'] : [];
            $isImage = isset($file['file_type']) && $file['file_type'] === 'image';
            ?>
            <article class="bm-record-card recycle-record-card">
                <div class="bm-record-main">
                    <span class="bm-icon-tile is-small"><i data-lucide="<?= $isImage ? 'image' : 'file' ?>"></i></span>
                    <div>
                        <strong><?= e($file['original_name'] ?? '未知文件') ?></strong>
                        <small><?= e($item['deleted_at']) ?> · <?= e($isImage ? '图片' : '文件') ?></small>
                    </div>
                </div>
                <div class="bm-record-meta">
                    <span><b>大小</b><?= e(isset($file['file_size']) ? format_bytes($file['file_size']) : '-') ?></span>
                    <span><b>原路径</b><?= e($file['file_path'] ?? '-') ?></span>
                    <span><b>文件类型</b><?= e($isImage ? '图片' : '文件') ?></span>
                </div>
                <div class="bm-record-actions">
                    <form method="post" action="<?= url('netdisk/restore') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($item['id']) ?>">
                        <button class="bm-btn bm-btn-primary" type="submit" data-icon="rotate-ccw">恢复</button>
                    </form>
                    <form method="post" action="<?= url('netdisk/purge') ?>" class="confirm-form" data-confirm="彻底删除后无法恢复，并且会删除远端对象，确认继续吗？">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($item['id']) ?>">
                        <button class="bm-btn bm-btn-danger" type="submit" data-icon="trash-2">彻底删除</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
