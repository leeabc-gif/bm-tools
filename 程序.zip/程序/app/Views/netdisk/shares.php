<?php
$shareStats = isset($shareStats) ? $shareStats : ['total' => count($shares), 'enabled' => 0, 'views' => 0, 'downloads' => 0];
?>

<section class="bm-workspace shares-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Shares</span>
            <h1>分享记录</h1>
            <p>管理从网盘文件生成的外链，支持复制链接、查看访问下载次数、启用或关闭分享。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('netdisk') ?>" data-icon="hard-drive">返回网盘</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('repository/files') ?>" data-icon="library">分享仓库</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>分享总数</span><strong><?= e(number_format($shareStats['total'])) ?></strong><small>当前账号创建的外链</small></article>
        <article class="bm-stat-card"><span>启用中</span><strong><?= e(number_format($shareStats['enabled'])) ?></strong><small>访客可访问</small></article>
        <article class="bm-stat-card"><span>访问次数</span><strong><?= e(number_format($shareStats['views'])) ?></strong><small>分享页打开记录</small></article>
        <article class="bm-stat-card"><span>下载次数</span><strong><?= e(number_format($shareStats['downloads'])) ?></strong><small>文件下载记录</small></article>
    </section>

    <section class="bm-record-list">
        <?php if (!$shares): ?>
            <article class="bm-empty-state">
                <i data-lucide="share-2"></i>
                <strong>暂无分享记录</strong>
                <span>在网盘文件列表中创建分享后，链接会集中显示在这里。</span>
                <a class="bm-btn bm-btn-primary" href="<?= url('netdisk') ?>" data-icon="plus">去创建分享</a>
            </article>
        <?php endif; ?>

        <?php foreach ($shares as $row): ?>
            <?php
            $shareLink = public_url('share/' . $row['share_code']);
            $expired = !empty($row['expire_at']) && strtotime($row['expire_at']) < time();
            $enabled = !empty($row['status']) && !$expired;
            ?>
            <article class="bm-record-card share-record-card">
                <div class="bm-record-main">
                    <span class="bm-icon-tile is-small"><i data-lucide="link-2"></i></span>
                    <div>
                        <strong><?= e($row['original_name'] ?: '文件已不存在') ?></strong>
                        <small><?= e($row['created_at']) ?> · <?= $expired ? '已过期' : ($row['status'] ? '启用中' : '已关闭') ?></small>
                    </div>
                </div>
                <div class="share-link-cell">
                    <input readonly value="<?= e($shareLink) ?>" data-auto-select>
                    <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制</button>
                    <a class="bm-btn bm-btn-soft" href="<?= e($shareLink) ?>" target="_blank" rel="noopener" data-icon="external-link">打开</a>
                </div>
                <div class="bm-record-meta">
                    <span><b>提取码</b><?= e($row['extract_code'] ?: '-') ?></span>
                    <span><b>有效期</b><?= e($row['expire_at'] ?: '永久') ?></span>
                    <span><b>访问</b><?= e(number_format((int) ($row['view_count'] ?? 0))) ?></span>
                    <span><b>下载</b><?= e(number_format((int) ($row['download_log_count'] ?? $row['download_count']))) ?><?= (int) $row['download_limit'] > 0 ? ' / ' . e($row['download_limit']) : '' ?></span>
                    <span><b>状态</b><em class="bm-state-pill <?= $enabled ? 'is-ok' : 'is-muted' ?>"><?= $enabled ? '可访问' : ($expired ? '已过期' : '已关闭') ?></em></span>
                </div>
                <div class="bm-record-actions">
                    <form method="post" action="<?= url('netdisk/share/status') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= e($row['id']) ?>">
                        <input type="hidden" name="status" value="<?= $row['status'] ? 0 : 1 ?>">
                        <button class="bm-btn <?= $row['status'] ? 'bm-btn-soft' : 'bm-btn-primary' ?>" type="submit" data-icon="<?= $row['status'] ? 'pause-circle' : 'play-circle' ?>"><?= $row['status'] ? '关闭分享' : '启用分享' ?></button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</section>
