<?php require APP_ROOT . '/app/Views/netdisk/partials/repository_nav.php'; ?>

<section class="file-list glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Files</p>
        <h2>仓库文件管理</h2>
        <p>选择网盘文件加入仓库，控制公开状态、说明文案和展示排序。</p>
    </div>

    <form method="get" action="<?= url('repository/files') ?>" class="url-fetch">
        <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
        <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索你的网盘文件">
        <button class="btn btn-ghost" type="submit" data-icon="search">搜索</button>
        <a class="btn btn-ghost" href="<?= url('repository/files?id=' . $repo['id']) ?>" data-icon="rotate-ccw">重置</a>
    </form>

    <form id="repositoryBatchForm" method="post" action="<?= url('repository/files/batch') ?>" class="confirm-form repository-batch-toolbar" data-confirm="确认执行批量操作吗？">
        <?= csrf_field() ?>
        <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
        <label class="inline-check"><input type="checkbox" class="select-all" data-target="repository-file"> 全选文件</label>
        <select name="batch_action" required>
            <option value="">选择批量操作</option>
            <option value="add_public">加入仓库并公开</option>
            <option value="add_private">加入仓库并私密</option>
            <option value="remove">从仓库移除</option>
        </select>
        <button class="btn btn-primary" type="submit" data-icon="check-square">执行</button>
    </form>

    <div class="repository-file-list">
        <?php if (!$files): ?>
            <div class="file-row empty-row">
                <div class="file-main">
                    <span class="file-badge">FILE</span>
                    <b>暂无可管理文件</b>
                    <small>先到网盘上传文件，再回到这里把它们加入分享仓库。</small>
                </div>
            </div>
        <?php endif; ?>

        <?php foreach ($files as $file): ?>
            <?php $inRepo = !empty($file['repo_item_id']); ?>
            <div class="file-row repository-manage-row">
                <div class="file-main">
                    <input form="repositoryBatchForm" type="checkbox" name="file_ids[]" value="<?= e($file['id']) ?>" data-group="repository-file">
                    <span class="file-badge"><?= $file['file_type'] === 'image' ? 'IMG' : 'FILE' ?></span>
                    <b><?= e($file['original_name']) ?></b>
                    <small><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?><?= $inRepo ? ' · 已加入仓库' : '' ?></small>
                </div>
                <details class="mobile-action-panel repository-action-panel" open>
                    <summary><span>仓库操作</span><b>展开</b></summary>
                    <div class="mobile-action-content">
                        <form method="post" action="<?= url('repository/file') ?>" class="repository-item-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
                            <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                            <select name="visibility">
                                <option value="public" <?= (!$inRepo || $file['repo_visibility'] === 'public') ? 'selected' : '' ?>>公开</option>
                                <option value="private" <?= ($inRepo && $file['repo_visibility'] === 'private') ? 'selected' : '' ?>>私密</option>
                            </select>
                            <input name="note" value="<?= e($inRepo ? $file['repo_note'] : '') ?>" placeholder="给访客看的说明">
                            <input class="sort-input" type="number" name="sort_order" value="<?= e($inRepo ? (int) $file['repo_sort_order'] : 0) ?>" placeholder="排序">
                            <button class="btn <?= $inRepo ? 'btn-ghost' : 'btn-primary' ?>" type="submit" data-icon="<?= $inRepo ? 'save' : 'plus' ?>"><?= $inRepo ? '保存' : '加入仓库' ?></button>
                        </form>
                        <?php if ($inRepo): ?>
                            <form method="post" action="<?= url('repository/file/delete') ?>" class="confirm-form" data-confirm="确认把这个文件从个人仓库移除吗？原网盘文件不会删除。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
                                <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                                <button class="btn btn-ghost" type="submit" data-icon="x">移除</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </details>
            </div>
        <?php endforeach; ?>
    </div>
</section>
