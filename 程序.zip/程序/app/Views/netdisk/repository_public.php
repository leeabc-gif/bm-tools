<?php
$ownerName = !empty($repo['nickname']) ? $repo['nickname'] : (isset($repo['username']) ? $repo['username'] : '');
$downloadEnabled = !empty($repo['allow_download']);
$repoTags = [];
if (!empty($repo['tags'])) {
    foreach (explode(',', $repo['tags']) as $tag) {
        $tag = trim($tag);
        if ($tag !== '') {
            $repoTags[] = $tag;
        }
    }
}
$coverUrl = !empty($repo['cover_image']) ? public_url($repo['cover_image']) : '';
$publicFileCount = isset($stats['public_items']) ? (int) $stats['public_items'] : count($files);
$latestUpdate = '';
foreach ($files as $file) {
    $time = !empty($file['updated_at']) ? $file['updated_at'] : (isset($file['created_at']) ? $file['created_at'] : '');
    if ($time !== '' && ($latestUpdate === '' || strtotime($time) > strtotime($latestUpdate))) {
        $latestUpdate = $time;
    }
}
$accessText = $repo['access_type'] === 'password' ? '密码访问' : '公开浏览';
$emptyTitle = trim((string) $keyword) !== '' ? '没有找到匹配资料' : '资料正在整理';
$emptyText = trim((string) $keyword) !== '' ? '当前搜索没有结果，请换个关键词试试。' : '仓库主人正在更新公开资料，请稍后再来看看。';
$shareText = $repo['title'] . "\n" . $publicLink;
if (!empty($repo['description'])) {
    $shareText .= "\n" . $repo['description'];
}
?>

<section class="dashboard-hero glass reveal repository-public-hero">
    <div>
        <p class="eyebrow">共享仓库</p>
        <h1><?= e($repo['title']) ?></h1>
        <?php if (!empty($repo['description'])): ?>
            <p><?= e($repo['description']) ?></p>
        <?php else: ?>
            <p>这里收录了仓库主人公开分享的网盘资料。</p>
        <?php endif; ?>
        <?php if (!empty($repo['show_owner']) && $ownerName !== ''): ?>
            <small>仓库主人：<?= e($ownerName) ?></small>
        <?php endif; ?>
        <?php if ($repoTags): ?>
            <div class="repository-tags">
                <?php foreach ($repoTags as $tag): ?><span><?= e($tag) ?></span><?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php if ($coverUrl): ?>
        <div class="repository-public-cover">
            <img src="<?= e($coverUrl) ?>" alt="<?= e($repo['title']) ?>">
        </div>
    <?php endif; ?>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= e($publicLink) ?>" data-icon="refresh-cw">刷新</a>
        <button class="btn btn-ghost copy-text-btn" type="button" data-copy-text="<?= e($publicLink) ?>" data-icon="copy">复制链接</button>
        <button class="btn btn-primary native-share-btn" type="button" data-share-title="<?= e($repo['title']) ?>" data-share-text="<?= e($shareText) ?>" data-share-url="<?= e($publicLink) ?>" data-icon="share-2">分享仓库</button>
    </div>
</section>

<?php if ($locked): ?>
    <section class="auth-shell reveal">
        <div class="auth-card glass">
            <p class="eyebrow">Password</p>
            <h2>请输入访问密码</h2>
            <p>这个个人仓库已开启密码访问，输入正确密码后才能查看资料。</p>
            <form method="post" action="<?= url('r/' . $repo['slug'] . '/auth') ?>" class="form-grid">
                <?= csrf_field() ?>
                <label>访问密码
                    <input name="password" type="password" required autofocus autocomplete="current-password" placeholder="请输入仓库访问密码">
                </label>
                <button class="btn btn-primary full" type="submit" data-icon="unlock">进入仓库</button>
            </form>
        </div>
    </section>
<?php else: ?>
    <section class="workspace-summary-grid reveal">
        <article class="workspace-summary-card glass">
            <span>资料状态</span>
            <b><?= $publicFileCount > 0 ? '已上架' : '整理中' ?></b>
            <small><?= $publicFileCount > 0 ? e($publicFileCount) . ' 个公开资料可浏览' : '仓库主人正在更新内容' ?></small>
        </article>
        <article class="workspace-summary-card glass">
            <span>最近更新</span>
            <b><?= $latestUpdate !== '' ? e(date('m-d', strtotime($latestUpdate))) : '待更新' ?></b>
            <small><?= $latestUpdate !== '' ? e(date('Y-m-d H:i', strtotime($latestUpdate))) : '有新资料会显示在这里' ?></small>
        </article>
        <article class="workspace-summary-card glass">
            <span>访问方式</span>
            <b><?= e($accessText) ?></b>
            <small><?= $repo['access_type'] === 'password' ? '通过密码后查看公开资料' : '打开链接即可浏览公开资料' ?></small>
        </article>
        <article class="workspace-summary-card glass <?= $downloadEnabled ? '' : 'warn' ?>">
            <span>下载状态</span>
            <b><?= $downloadEnabled ? '可下载' : '仅浏览' ?></b>
            <small><?= $downloadEnabled ? '公开资料支持下载保存' : '仓库主人暂未开放下载' ?></small>
        </article>
    </section>

    <section class="file-list glass reveal">
        <div class="section-heading compact">
            <p class="eyebrow">Files</p>
            <h2>公开资料</h2>
            <small class="repository-public-subtitle"><?= count($files) > 0 ? '共 ' . e(count($files)) . ' 个资料，可按名称搜索' : '公开资料会显示在这里' ?></small>
            <?php if ($downloadEnabled && count($files) > 0): ?>
                <a class="btn btn-ghost" href="<?= url('r/' . $repo['slug'] . '/download-zip') ?>" data-icon="archive">打包下载</a>
            <?php endif; ?>
        </div>
        <form method="get" action="<?= url('r/' . $repo['slug']) ?>" class="url-fetch">
            <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索资料">
            <button class="btn btn-ghost" type="submit" data-icon="search">搜索</button>
            <a class="btn btn-ghost" href="<?= url('r/' . $repo['slug']) ?>" data-icon="rotate-ccw">重置</a>
        </form>

        <div class="repository-public-grid">
            <?php if (!$files): ?>
                <div class="file-row empty-row">
                    <div class="file-main">
                        <span class="file-badge">FILE</span>
                        <b><?= e($emptyTitle) ?></b>
                        <small><?= e($emptyText) ?></small>
                    </div>
                </div>
            <?php endif; ?>

            <?php foreach ($files as $file): ?>
                <?php $fileUrl = public_url($file['file_url']); ?>
                <article class="repository-file-card repository-public-file">
                    <?php if ($file['file_type'] === 'image'): ?>
                        <a class="repository-file-preview" href="<?= e($fileUrl) ?>" target="_blank">
                            <img src="<?= e($fileUrl) ?>" alt="<?= e($file['original_name']) ?>">
                        </a>
                    <?php endif; ?>
                    <div class="repository-file-main">
                        <span class="file-badge"><?= $file['file_type'] === 'image' ? 'IMG' : 'FILE' ?></span>
                        <div>
                            <b><?= e($file['original_name']) ?></b>
                            <small><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></small>
                        </div>
                    </div>
                    <?php if (!empty($file['repo_note'])): ?>
                        <p><?= e($file['repo_note']) ?></p>
                    <?php endif; ?>
                    <div class="repository-file-actions">
                        <a class="btn btn-ghost" href="<?= e($fileUrl) ?>" target="_blank" data-icon="eye">预览</a>
                        <?php if ($downloadEnabled): ?>
                            <a class="btn btn-primary" href="<?= url('r/' . $repo['slug'] . '/download/' . $file['id']) ?>" data-icon="download">下载</a>
                        <?php else: ?>
                            <span class="muted-text">下载已关闭</span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>
