<?php $exportUrl = 'repository/logs/export?id=' . $repo['id'] . '&log_action=download&log_keyword=' . urlencode($logFilters['keyword']) . '&date_from=' . urlencode($logFilters['date_from']) . '&date_to=' . urlencode($logFilters['date_to']); ?>
<?php require APP_ROOT . '/app/Views/netdisk/partials/repository_nav.php'; ?>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Download Logs</p>
        <h2>下载日志</h2>
        <p>记录访客下载文件的时间、来源和 IP，便于排查异常下载。</p>
    </div>
    <div class="repository-log-actions">
        <form method="post" action="<?= url('repository/logs/clear') ?>" class="confirm-form" data-confirm="确认清空当前仓库的全部访问和下载日志吗？">
            <?= csrf_field() ?>
            <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
            <button class="btn btn-ghost" type="submit" data-icon="eraser">清空日志</button>
        </form>
    </div>
    <form method="get" action="<?= url('repository/logs/download') ?>" class="url-fetch repository-log-filter">
        <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
        <input name="log_keyword" value="<?= e($logFilters['keyword']) ?>" placeholder="搜索文件名、IP 或来源">
        <input name="date_from" type="date" value="<?= e($logFilters['date_from']) ?>">
        <input name="date_to" type="date" value="<?= e($logFilters['date_to']) ?>">
        <button class="btn btn-ghost" type="submit" data-icon="filter">筛选</button>
        <a class="btn btn-ghost" href="<?= url($exportUrl) ?>" data-icon="download">导出 CSV</a>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>行为</th><th>文件</th><th>IP</th><th>来源</th><th>时间</th></tr>
            </thead>
            <tbody>
            <?php if (!$logs): ?>
                <tr><td colspan="5" class="responsive-table-span">暂无下载日志。</td></tr>
            <?php endif; ?>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td data-label="行为"><span class="repository-log-action">下载</span></td>
                    <td data-label="文件"><?= e($log['original_name'] ?: '-') ?></td>
                    <td data-label="IP"><?= e($log['ip']) ?></td>
                    <td data-label="来源"><?= e($log['referer'] ?: '-') ?></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
