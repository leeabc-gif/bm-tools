<?php
$accessLabels = [
    'public' => '公开访问',
    'password' => '密码访问',
    'private' => '私密关闭',
];
$logLabels = [
    'view' => '访问',
    'download' => '下载',
    'auth_success' => '密码正确',
    'auth_fail' => '密码错误',
    'blocked' => '风控拦截',
    'expired' => '链接过期',
];
$repositories = isset($repositories) ? $repositories : [$repo];
$logFilters = isset($logFilters) ? $logFilters : ['action' => '', 'keyword' => '', 'date_from' => '', 'date_to' => ''];
$repoTags = [];
if (!empty($repo['tags'])) {
    foreach (explode(',', $repo['tags']) as $tag) {
        $tag = trim($tag);
        if ($tag !== '') {
            $repoTags[] = $tag;
        }
    }
}
$coverUrl = !empty($repo['cover_image']) ? public_url($repo['cover_image']) : '';
$shareText = $repo['title'] . "\n" . $publicLink;
if (!empty($repo['description'])) {
    $shareText .= "\n" . $repo['description'];
}
?>

<section class="dashboard-hero glass reveal repository-hero">
    <div>
        <p class="eyebrow">Repository</p>
        <h1>个人仓库</h1>
        <p>把个人网盘里的资料整理成一个可分享的仓库链接，可设置公开、密码访问或私密关闭，并记录访问与下载行为。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= e($publicLink) ?>" target="_blank" data-icon="external-link">打开仓库</a>
        <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="hard-drive">返回网盘</a>
    </div>
</section>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">My Repositories</p>
        <h2>我的仓库</h2>
    </div>
    <form method="post" action="<?= url('repository/create') ?>" class="url-fetch repository-create-form">
        <?= csrf_field() ?>
        <input name="title" placeholder="新仓库名称，例如：课程资料">
        <input name="slug" placeholder="自定义链接，可留空自动生成">
        <button class="btn btn-primary" type="submit" data-icon="plus">新建仓库</button>
    </form>
    <div class="repository-tabs">
        <?php foreach ($repositories as $item): ?>
            <a class="<?= (int) $item['id'] === (int) $repo['id'] ? 'active' : '' ?>" href="<?= url('repository?id=' . $item['id']) ?>">
                <b><?= e($item['title']) ?></b>
                <small><?= e(public_url('r/' . $item['slug'])) ?></small>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<section class="workspace-summary-grid reveal">
    <article class="workspace-summary-card glass">
        <span>公开文件</span>
        <b><?= e($stats['public_items']) ?></b>
        <small>访客可看到的文件数量</small>
    </article>
    <article class="workspace-summary-card glass">
        <span>私密文件</span>
        <b><?= e($stats['private_items']) ?></b>
        <small>只在管理台保留，不对外显示</small>
    </article>
    <article class="workspace-summary-card glass">
        <span>访问 / 今日</span>
        <b><?= e($stats['views']) ?></b>
        <small>今日 <?= e($stats['today_views']) ?> 次访问</small>
    </article>
    <article class="workspace-summary-card glass">
        <span>下载 / 今日</span>
        <b><?= e($stats['downloads']) ?></b>
        <small>今日 <?= e($stats['today_downloads']) ?> 次下载</small>
    </article>
</section>

<section class="form-section glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Settings</p>
        <h2>仓库设置</h2>
    </div>

    <div class="repository-link-box">
        <span>当前公开链接</span>
        <input readonly value="<?= e($publicLink) ?>" data-auto-select>
        <textarea readonly rows="4" data-auto-select><?= e($shareText) ?></textarea>
        <button class="btn btn-ghost copy-current-inputs" type="button" data-icon="copy" data-copy-selector="textarea[readonly]">复制分享文案</button>
        <div class="repository-qr-card">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=<?= urlencode($publicLink) ?>" alt="仓库二维码">
            <small>扫码访问仓库，适合发到社群、朋友圈和课程资料页。</small>
        </div>
    </div>

    <form method="post" action="<?= url('repository/save') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
        <label>仓库名称
            <input name="title" value="<?= e($repo['title']) ?>" maxlength="120" required>
        </label>
        <label>自定义链接
            <input name="slug" value="<?= e($repo['slug']) ?>" maxlength="80" pattern="[A-Za-z0-9_-]+" required>
            <small>只能使用英文、数字、中横线和下划线，例如 my-files。</small>
        </label>
        <label>访问方式
            <select name="access_type">
                <option value="public" <?= $repo['access_type'] === 'public' ? 'selected' : '' ?>>公开访问</option>
                <option value="password" <?= $repo['access_type'] === 'password' ? 'selected' : '' ?>>密码访问</option>
                <option value="private" <?= $repo['access_type'] === 'private' ? 'selected' : '' ?>>私密关闭</option>
            </select>
        </label>
        <label>访问密码
            <input name="password" type="password" placeholder="<?= $repo['access_type'] === 'password' ? '留空表示不修改旧密码' : '切换到密码访问时填写' ?>">
        </label>
        <label class="full">仓库介绍
            <textarea name="description" rows="4" maxlength="500"><?= e($repo['description']) ?></textarea>
        </label>
        <label>仓库封面图 URL
            <input name="cover_image" value="<?= e(isset($repo['cover_image']) ? $repo['cover_image'] : '') ?>" maxlength="800" placeholder="https://example.com/cover.jpg">
            <small>用于公开页顶部展示，可填图床图片直链。</small>
        </label>
        <label>标签
            <input name="tags" value="<?= e(isset($repo['tags']) ? $repo['tags'] : '') ?>" maxlength="255" placeholder="课程,资料,设计">
            <small>多个标签用逗号或空格分隔，最多保留 12 个。</small>
        </label>
        <?php if ($coverUrl || $repoTags): ?>
            <div class="repository-preview-card full">
                <?php if ($coverUrl): ?><img src="<?= e($coverUrl) ?>" alt="仓库封面预览"><?php endif; ?>
                <?php if ($repoTags): ?>
                    <div class="repository-tags">
                        <?php foreach ($repoTags as $tag): ?><span><?= e($tag) ?></span><?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <label>到期时间
            <input name="expire_at" type="datetime-local" value="<?= e(!empty($repo['expire_at']) ? str_replace(' ', 'T', substr($repo['expire_at'], 0, 16)) : '') ?>">
            <small>留空表示长期有效。</small>
        </label>
        <label>总访问上限
            <input name="max_views" type="number" min="0" value="<?= e((int) $repo['max_views']) ?>">
            <small>填 0 表示不限。</small>
        </label>
        <label>总下载上限
            <input name="max_downloads" type="number" min="0" value="<?= e((int) $repo['max_downloads']) ?>">
            <small>填 0 表示不限。</small>
        </label>
        <label>单 IP 每日访问上限
            <input name="ip_daily_view_limit" type="number" min="0" value="<?= e((int) $repo['ip_daily_view_limit']) ?>">
        </label>
        <label>单 IP 每日下载上限
            <input name="ip_daily_download_limit" type="number" min="0" value="<?= e((int) $repo['ip_daily_download_limit']) ?>">
        </label>
        <div class="repository-switches full">
            <label class="inline-check"><input type="checkbox" name="status" value="1" <?= !empty($repo['status']) ? 'checked' : '' ?>> 启用仓库</label>
            <label class="inline-check"><input type="checkbox" name="allow_download" value="1" <?= !empty($repo['allow_download']) ? 'checked' : '' ?>> 允许访客下载</label>
            <label class="inline-check"><input type="checkbox" name="show_owner" value="1" <?= !empty($repo['show_owner']) ? 'checked' : '' ?>> 显示仓库主人</label>
        </div>
        <div class="full toolbar">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
            <span class="muted-text">当前状态：<?= e(isset($accessLabels[$repo['access_type']]) ? $accessLabels[$repo['access_type']] : $repo['access_type']) ?><?= empty($repo['status']) ? '，已停用' : '' ?></span>
            <?php if (empty($repo['admin_status'])): ?><span class="status-pill bad">平台已下架：<?= e($repo['admin_remark']) ?></span><?php endif; ?>
        </div>
    </form>
</section>

<section class="file-list glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Files</p>
        <h2>仓库文件</h2>
    </div>

    <form method="get" action="<?= url('repository') ?>" class="url-fetch">
        <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
        <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索你的网盘文件">
        <button class="btn btn-ghost" type="submit" data-icon="search">搜索</button>
        <a class="btn btn-ghost" href="<?= url('repository?id=' . $repo['id']) ?>" data-icon="rotate-ccw">重置</a>
    </form>

    <form id="repositoryBatchForm" method="post" action="<?= url('repository/files/batch') ?>" class="confirm-form repository-batch-toolbar" data-confirm="确认执行批量操作吗？">
        <?= csrf_field() ?>
        <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
        <label class="inline-check"><input type="checkbox" class="select-all" data-target="repository-file"> 全选文件</label>
        <select name="batch_action" required>
            <option value="">选择批量操作</option>
            <option value="add_public">加入仓库并公开</option>
            <option value="add_private">加入仓库并私密</option>
            <option value="remove">从仓库移除</option>
        </select>
        <button class="btn btn-primary" type="submit" data-icon="check-square">执行</button>
    </form>

    <div class="repository-file-list">
        <?php if (!$files): ?>
            <div class="file-row empty-row">
                <div class="file-main">
                    <span class="file-badge">FILE</span>
                    <b>暂无可加入仓库的文件</b>
                    <small>先到个人网盘上传文件，再回到这里挑选要公开的资料。</small>
                </div>
            </div>
        <?php endif; ?>

        <?php foreach ($files as $file): ?>
            <?php $inRepo = !empty($file['repo_item_id']); ?>
            <div class="file-row repository-manage-row">
                <div class="file-main">
                    <input form="repositoryBatchForm" type="checkbox" name="file_ids[]" value="<?= e($file['id']) ?>" data-group="repository-file">
                    <span class="file-badge"><?= $file['file_type'] === 'image' ? 'IMG' : 'FILE' ?></span>
                    <b><?= e($file['original_name']) ?></b>
                    <small><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?><?= $inRepo ? ' · 已加入仓库' : '' ?></small>
                </div>

                <details class="mobile-action-panel repository-action-panel" open>
                    <summary><span>仓库操作</span><b>展开</b></summary>
                    <div class="mobile-action-content">
                        <form method="post" action="<?= url('repository/file') ?>" class="repository-item-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
                            <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                            <select name="visibility">
                                <option value="public" <?= (!$inRepo || $file['repo_visibility'] === 'public') ? 'selected' : '' ?>>公开</option>
                                <option value="private" <?= ($inRepo && $file['repo_visibility'] === 'private') ? 'selected' : '' ?>>私密</option>
                            </select>
                            <input name="note" value="<?= e($inRepo ? $file['repo_note'] : '') ?>" placeholder="给访客看的说明">
                            <input class="sort-input" type="number" name="sort_order" value="<?= e($inRepo ? (int) $file['repo_sort_order'] : 0) ?>" placeholder="排序">
                            <button class="btn <?= $inRepo ? 'btn-ghost' : 'btn-primary' ?>" type="submit" data-icon="<?= $inRepo ? 'save' : 'plus' ?>"><?= $inRepo ? '保存' : '加入仓库' ?></button>
                        </form>

                        <?php if ($inRepo): ?>
                            <form method="post" action="<?= url('repository/file/delete') ?>" class="confirm-form" data-confirm="确认把这个文件从个人仓库移除吗？原网盘文件不会删除。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
                                <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                                <button class="btn btn-ghost" type="submit" data-icon="x">移除</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </details>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Logs</p>
        <h2>访问与下载日志</h2>
    </div>
    <form method="get" action="<?= url('repository') ?>" class="url-fetch repository-log-filter">
        <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
        <select name="log_action">
            <option value="">全部行为</option>
            <?php foreach ($logLabels as $key => $label): ?>
                <option value="<?= e($key) ?>" <?= $logFilters['action'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
        <input name="log_keyword" value="<?= e($logFilters['keyword']) ?>" placeholder="搜索文件名、IP 或来源">
        <input name="date_from" type="date" value="<?= e($logFilters['date_from']) ?>">
        <input name="date_to" type="date" value="<?= e($logFilters['date_to']) ?>">
        <button class="btn btn-ghost" type="submit" data-icon="filter">筛选</button>
        <a class="btn btn-ghost" href="<?= url('repository/logs/export?id=' . $repo['id'] . '&log_action=' . urlencode($logFilters['action']) . '&log_keyword=' . urlencode($logFilters['keyword']) . '&date_from=' . urlencode($logFilters['date_from']) . '&date_to=' . urlencode($logFilters['date_to'])) ?>" data-icon="download">导出 CSV</a>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>行为</th><th>文件</th><th>IP</th><th>来源</th><th>时间</th></tr>
            </thead>
            <tbody>
            <?php if (!$logs): ?>
                <tr><td colspan="5" class="responsive-table-span">暂无日志。仓库被访问、输错密码或下载文件后会记录在这里。</td></tr>
            <?php endif; ?>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td data-label="行为"><span class="repository-log-action"><?= e(isset($logLabels[$log['action']]) ? $logLabels[$log['action']] : $log['action']) ?></span></td>
                    <td data-label="文件"><?= e($log['original_name'] ?: '-') ?></td>
                    <td data-label="IP"><?= e($log['ip']) ?></td>
                    <td data-label="来源"><?= e($log['referer'] ?: '-') ?></td>
                    <td data-label="时间"><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
