<?php
$repoTags = [];
if (!empty($repo['tags'])) {
    foreach (explode(',', $repo['tags']) as $tag) {
        $tag = trim($tag);
        if ($tag !== '') {
            $repoTags[] = $tag;
        }
    }
}
$coverUrl = !empty($repo['cover_image']) ? public_url($repo['cover_image']) : '';
$shareText = $repo['title'] . "\n" . $publicLink;
if (!empty($repo['description'])) {
    $shareText .= "\n" . $repo['description'];
}
?>
<?php require APP_ROOT . '/app/Views/netdisk/partials/repository_nav.php'; ?>

<?php if (!empty($checklist)): ?>
    <section class="repository-check-panel glass reveal">
        <div class="section-heading compact">
            <p class="eyebrow">Publish Check</p>
            <h2>发布检查</h2>
            <p><?= !empty($checklist['ready']) ? '当前仓库已经具备公开访问条件。' : '下面这些项会影响公开链接访问，按提示处理后再打开仓库。' ?></p>
        </div>
        <div class="repository-check-grid">
            <?php foreach ($checklist['items'] as $item): ?>
                <div class="repository-check-item <?= !empty($item['ok']) ? 'ok' : 'warn' ?>">
                    <span><i data-lucide="<?= !empty($item['ok']) ? 'check' : 'alert-triangle' ?>"></i></span>
                    <div>
                        <b><?= e($item['label']) ?></b>
                        <small><?= e($item['detail']) ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<section class="form-section glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Settings</p>
        <h2>链接与权限设置</h2>
        <p>配置公开链接、访问方式、下载开关和访问限制。</p>
    </div>

    <div class="repository-link-box">
        <span>当前公开链接</span>
        <input readonly value="<?= e($publicLink) ?>" data-auto-select>
        <textarea readonly rows="4" data-auto-select><?= e($shareText) ?></textarea>
        <button class="btn btn-ghost copy-current-inputs" type="button" data-icon="copy" data-copy-selector="textarea[readonly]">复制分享文案</button>
    </div>

    <form method="post" action="<?= url('repository/save') ?>" class="form-grid two">
        <?= csrf_field() ?>
        <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
        <label>仓库名称
            <input name="title" value="<?= e($repo['title']) ?>" maxlength="120" required>
        </label>
        <label>自定义链接
            <input name="slug" value="<?= e($repo['slug']) ?>" maxlength="80" pattern="[A-Za-z0-9_-]+" required>
            <small>只能使用英文、数字、中横线和下划线。</small>
        </label>
        <label>访问方式
            <select name="access_type">
                <option value="public" <?= $repo['access_type'] === 'public' ? 'selected' : '' ?>>公开访问</option>
                <option value="password" <?= $repo['access_type'] === 'password' ? 'selected' : '' ?>>密码访问</option>
                <option value="private" <?= $repo['access_type'] === 'private' ? 'selected' : '' ?>>私密关闭</option>
            </select>
        </label>
        <label>访问密码
            <input name="password" type="password" placeholder="<?= $repo['access_type'] === 'password' ? '留空表示不修改旧密码' : '切换到密码访问时填写' ?>">
        </label>
        <label class="full">仓库介绍
            <textarea name="description" rows="4" maxlength="500"><?= e($repo['description']) ?></textarea>
        </label>
        <label>仓库封面图 URL
            <input name="cover_image" value="<?= e(isset($repo['cover_image']) ? $repo['cover_image'] : '') ?>" maxlength="800" placeholder="https://example.com/cover.jpg">
        </label>
        <label>标签
            <input name="tags" value="<?= e(isset($repo['tags']) ? $repo['tags'] : '') ?>" maxlength="255" placeholder="课程,资料,设计">
        </label>
        <?php if ($coverUrl || $repoTags): ?>
            <div class="repository-preview-card full">
                <?php if ($coverUrl): ?><img src="<?= e($coverUrl) ?>" alt="仓库封面预览"><?php endif; ?>
                <?php if ($repoTags): ?>
                    <div class="repository-tags">
                        <?php foreach ($repoTags as $tag): ?><span><?= e($tag) ?></span><?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <label>到期时间
            <input name="expire_at" type="datetime-local" value="<?= e(!empty($repo['expire_at']) ? str_replace(' ', 'T', substr($repo['expire_at'], 0, 16)) : '') ?>">
        </label>
        <label>总访问上限
            <input name="max_views" type="number" min="0" value="<?= e((int) $repo['max_views']) ?>">
        </label>
        <label>总下载上限
            <input name="max_downloads" type="number" min="0" value="<?= e((int) $repo['max_downloads']) ?>">
        </label>
        <label>单 IP 每日访问上限
            <input name="ip_daily_view_limit" type="number" min="0" value="<?= e((int) $repo['ip_daily_view_limit']) ?>">
        </label>
        <label>单 IP 每日下载上限
            <input name="ip_daily_download_limit" type="number" min="0" value="<?= e((int) $repo['ip_daily_download_limit']) ?>">
        </label>
        <div class="repository-switches full">
            <label class="inline-check"><input type="checkbox" name="status" value="1" <?= !empty($repo['status']) ? 'checked' : '' ?>> 启用仓库</label>
            <label class="inline-check"><input type="checkbox" name="allow_download" value="1" <?= !empty($repo['allow_download']) ? 'checked' : '' ?>> 允许访客下载</label>
            <label class="inline-check"><input type="checkbox" name="show_owner" value="1" <?= !empty($repo['show_owner']) ? 'checked' : '' ?>> 显示仓库主人</label>
        </div>
        <div class="full toolbar">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
            <?php if (empty($repo['admin_status'])): ?><span class="status-pill bad">平台已下架：<?= e($repo['admin_remark']) ?></span><?php endif; ?>
        </div>
    </form>
</section>

<section class="form-section glass reveal repository-danger-zone">
    <div class="section-heading compact">
        <p class="eyebrow">Danger Zone</p>
        <h2>删除仓库</h2>
        <p>删除后会清空这个仓库的配置、文件关联和访问日志，原网盘文件不会被删除。</p>
    </div>
    <form method="post" action="<?= url('repository/delete') ?>" class="confirm-form repository-delete-form" data-confirm="确认删除这个分享仓库吗？原网盘文件会保留，但仓库链接和日志会删除。">
        <?= csrf_field() ?>
        <input type="hidden" name="repository_id" value="<?= e($repo['id']) ?>">
        <button class="btn btn-ghost" type="submit" data-icon="trash-2">删除这个仓库</button>
    </form>
</section>
