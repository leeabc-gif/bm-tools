<?php require APP_ROOT . '/app/Views/netdisk/partials/repository_nav.php'; ?>

<section class="form-section glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Create</p>
        <h2>创建分享仓库</h2>
        <p>建立一个独立公开页，把网盘文件整理成可分享的资料集合。</p>
    </div>

    <form method="post" action="<?= url('repository/create') ?>" class="form-grid two repository-create-panel">
        <?= csrf_field() ?>
        <label>仓库名称
            <input name="title" placeholder="例如：课程资料、项目交付件" maxlength="120">
        </label>
        <label>自定义链接
            <input name="slug" placeholder="可留空自动生成，例如 design-files" maxlength="80">
        </label>
        <div class="full form-actions">
            <button class="btn btn-primary" type="submit" data-icon="plus">创建仓库</button>
        </div>
    </form>

    <?php if (!$repositories): ?>
        <div class="empty-state-card anime-empty-state">
            <div class="anime-empty-art" aria-hidden="true">
                <span class="anime-cloud"></span>
                <span class="anime-star"></span>
                <span class="anime-heart"></span>
            </div>
            <b>还没有分享仓库</b>
            <small>先创建一个仓库，后面再分别去文件管理、权限配置和日志页面继续处理。</small>
        </div>
    <?php else: ?>
        <div class="repository-admin-list">
            <?php foreach ($repositories as $item): ?>
                <article class="repository-admin-card">
                    <div>
                        <b><?= e($item['title']) ?></b>
                        <small><?= e(public_url('r/' . $item['slug'])) ?></small>
                    </div>
                    <div class="repository-admin-actions">
                        <a class="btn btn-ghost" href="<?= url('repository/files?id=' . $item['id']) ?>" data-icon="library">文件</a>
                        <a class="btn btn-ghost" href="<?= url('repository/settings?id=' . $item['id']) ?>" data-icon="settings">设置</a>
                        <a class="btn btn-primary" href="<?= e(public_url('r/' . $item['slug'])) ?>" target="_blank" data-icon="external-link">打开</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
