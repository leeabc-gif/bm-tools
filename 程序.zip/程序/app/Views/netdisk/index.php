<?php
$singleLimit = (int) $usage['package']['single_file_limit'] > 0 ? format_bytes($usage['package']['single_file_limit']) : '不限';
$categoryOptions = [
    '' => '全部类型',
    'image' => '图片',
    'document' => '文档',
    'archive' => '压缩包',
    'video' => '视频',
    'audio' => '音频',
    'other' => '其他',
];
$fileBatchLimit = (int) setting('upload_file_batch_limit', 10);
$uploadConcurrency = (int) setting('upload_max_concurrency', 2);
$fileDailyLimit = (int) setting('upload_file_daily_limit', 0);
?>

<section class="bm-workspace netdisk-v2" id="top">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Netdisk</span>
            <h1>轻量网盘</h1>
            <p>网盘主页只保留目录、上传和新建文件夹。分享仓库、链接权限、访问日志、下载日志拆到独立页面，避免功能堆在一屏。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-soft" href="<?= url('shares') ?>" data-icon="share-2">我的分享仓库</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('repository/create') ?>" data-icon="library">创建分享仓库</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('files/logs') ?>" data-icon="clipboard-list">文件记录</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('netdisk/recycle') ?>" data-icon="archive-restore">回收站</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">扩容</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card">
            <span>当前套餐</span>
            <strong><?= e($usage['package']['name']) ?></strong>
            <small>分享 <?= !empty($usage['package']['allow_share']) ? '已开启' : '未开启' ?> · 视频预览 <?= !empty($usage['package']['allow_video_preview']) ? '已开启' : '未开启' ?></small>
        </article>
        <article class="bm-stat-card <?= $usage['is_near_limit'] ? 'is-warn' : '' ?>">
            <span>容量使用</span>
            <strong><?= e($usage['storage_percent']) ?>%</strong>
            <small><?= e(format_bytes($usage['used_storage'])) ?> / <?= e(format_bytes($usage['total_storage'])) ?></small>
            <i class="bm-progress"><em style="width: <?= e($usage['storage_percent']) ?>%"></em></i>
        </article>
        <article class="bm-stat-card">
            <span>文件 / 文件夹</span>
            <strong><?= e($usage['file_count']) ?> / <?= e($usage['folder_count']) ?></strong>
            <small>总占用：<?= e(format_bytes($usage['file_size'])) ?></small>
        </article>
        <article class="bm-stat-card">
            <span>单文件限制</span>
            <strong><?= e($singleLimit) ?></strong>
            <small><?= $usage['is_near_limit'] ? '容量偏紧，建议扩容' : '可继续上传文件' ?></small>
        </article>
    </section>

    <?php if ($usage['is_near_limit']): ?>
        <section class="bm-inline-notice is-warning">
            <i data-lucide="alert-triangle"></i>
            <div>
                <strong>网盘容量接近上限</strong>
                <span>当前空间已使用 <?= e($usage['storage_percent']) ?>%，建议清理回收站或升级套餐，避免大文件上传失败。</span>
            </div>
            <a href="<?= url('packages') ?>">立即扩容</a>
        </section>
    <?php endif; ?>

    <section class="bm-netdisk-tools">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Search</span>
                    <h2>搜索当前目录</h2>
                </div>
            </div>
            <form method="get" action="<?= url('netdisk') ?>" class="bm-inline-form">
                <input type="hidden" name="folder_id" value="<?= e($folderId) ?>">
                <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索当前文件夹文件">
                <select name="category">
                    <?php foreach ($categoryOptions as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $category === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="bm-btn bm-btn-soft" type="submit" data-icon="search">搜索</button>
                <a class="bm-btn bm-btn-plain" href="<?= url('netdisk?folder_id=' . $folderId) ?>" data-icon="rotate-ccw">重置</a>
            </form>
        </article>

        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Folder</span>
                    <h2>新建文件夹</h2>
                </div>
            </div>
            <form method="post" action="<?= url('netdisk/folder') ?>" class="bm-inline-form">
                <?= csrf_field() ?>
                <input type="hidden" name="parent_id" value="<?= e($folderId) ?>">
                <input name="name" placeholder="文件夹名称">
                <button class="bm-btn bm-btn-soft" type="submit" data-icon="folder-plus">新建</button>
            </form>
        </article>
    </section>

    <section class="bm-upload-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Upload</span>
                <h2>上传文件</h2>
            </div>
        </div>
        <form method="post" action="<?= url('netdisk/upload') ?>" enctype="multipart/form-data" class="upload-form bm-upload-form">
            <?= csrf_field() ?>
            <input type="hidden" name="folder_id" value="<?= e($folderId) ?>">
            <div class="drop-zone bm-drop-zone">
                <input type="file" name="files[]" multiple>
                <i data-lucide="upload-cloud"></i>
                <strong>拖拽文件到这里，或点击选择文件</strong>
                <span>建议按项目建立文件夹。需要公开访问时，到分享仓库页面单独配置。</span>
            </div>
            <button class="bm-btn bm-btn-primary" type="submit" data-icon="upload-cloud">上传文件</button>
            <div class="upload-limit-note">
                <i data-lucide="info"></i>
                <div>
                    <strong>上传规则</strong>
                    <span>单次最多 <?= e($fileBatchLimit) ?> 个文件，并发 <?= e($uploadConcurrency) ?> 个；每日文件上限 <?= $fileDailyLimit > 0 ? e($fileDailyLimit . ' 个') : '不限制' ?>。大文件建议分批上传，失败文件会单独提示原因。</span>
                </div>
            </div>
        </form>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Folders</span>
                <h2>文件夹</h2>
            </div>
        </div>
        <div class="bm-file-manager-list">
            <?php if (!$folders): ?>
                <div class="bm-empty-line">暂无文件夹。先创建一个项目文件夹，后续管理会更清晰。</div>
            <?php endif; ?>
            <?php foreach ($folders as $folder): ?>
                <article class="bm-netdisk-row">
                    <a class="bm-netdisk-main" href="<?= url('netdisk?folder_id=' . $folder['id']) ?>">
                        <span class="bm-icon-tile is-small"><i data-lucide="folder"></i></span>
                        <span>
                            <strong><?= e($folder['name']) ?></strong>
                            <small><?= e($folder['created_at']) ?></small>
                        </span>
                    </a>
                    <details class="mobile-action-panel bm-row-actions" open>
                        <summary><span>文件夹操作</span><b>展开</b></summary>
                        <div>
                            <form method="post" action="<?= url('netdisk/rename') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($folder['id']) ?>">
                                <input type="hidden" name="type" value="folder">
                                <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                                <input name="name" value="<?= e($folder['name']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="pencil">重命名</button>
                            </form>
                            <form method="post" action="<?= url('netdisk/folder/delete') ?>" class="confirm-form" data-confirm="确认删除该文件夹吗？文件夹内文件会移入回收站。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($folder['id']) ?>">
                                <button class="bm-btn bm-btn-danger" type="submit" data-icon="archive-x">删除</button>
                            </form>
                        </div>
                    </details>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Files</span>
                <h2>文件</h2>
            </div>
            <form id="batchDeleteForm" method="post" action="<?= url('netdisk/batch-delete') ?>" class="confirm-form bm-file-bulk-form" data-confirm="确认把选中文件移入回收站吗？" data-require-selection="netdisk-file" data-selection-message="请选择要删除的文件">
                <?= csrf_field() ?>
                <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                <label class="bm-inline-check"><input type="checkbox" class="select-all" data-target="netdisk-file"> 全选</label>
                <button class="bm-btn bm-btn-soft netdisk-batch-download-btn" type="button" data-download-form="#batchDownloadForm" data-icon="download">批量下载</button>
                <button class="bm-btn bm-btn-danger" type="submit" data-icon="archive-x">批量删除</button>
            </form>
            <form id="batchDownloadForm" method="post" action="<?= url('netdisk/batch-download') ?>" hidden>
                <?= csrf_field() ?>
                <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
            </form>
        </div>

        <div class="bm-file-manager-list">
            <?php if (!$files): ?>
                <div class="bm-empty-line">当前文件夹暂无文件。上传文件后会在这里统一展示。</div>
            <?php endif; ?>
            <?php foreach ($files as $file): ?>
                <?php $fileUrl = public_url($file['file_url']); ?>
                <article class="bm-netdisk-row file-row">
                    <div class="bm-netdisk-main">
                        <input form="batchDeleteForm" type="checkbox" name="ids[]" value="<?= e($file['id']) ?>" data-group="netdisk-file">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= $file['file_type'] === 'image' ? 'image' : 'file' ?>"></i></span>
                        <span>
                            <strong><?= e($file['original_name']) ?></strong>
                            <small><?= e(format_bytes($file['file_size'])) ?> · 下载 <?= e((int) ($file['download_count'] ?? 0)) ?> 次 · <?= e($file['created_at']) ?></small>
                        </span>
                    </div>
                    <details class="mobile-action-panel bm-row-actions" open>
                        <summary><span>文件操作</span><b>展开</b></summary>
                        <div>
                            <a class="bm-btn bm-btn-plain" href="<?= e($fileUrl) ?>" target="_blank" data-icon="eye">预览</a>
                            <a class="bm-btn bm-btn-soft" href="<?= url('netdisk/download?id=' . $file['id']) ?>" data-icon="download">下载</a>
                            <div class="link-box bm-netdisk-link-box">
                                <label>完整直链<input readonly value="<?= e($fileUrl) ?>"></label>
                                <button class="bm-btn bm-btn-soft copy-current-inputs" type="button" data-icon="copy">复制直链</button>
                            </div>
                            <form method="post" action="<?= url('netdisk/rename') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                                <input type="hidden" name="type" value="file">
                                <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                                <input name="name" value="<?= e($file['original_name']) ?>">
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="pencil">重命名</button>
                            </form>
                            <form method="post" action="<?= url('netdisk/move') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                                <select name="folder_id">
                                    <option value="0">根目录</option>
                                    <?php foreach ($allFolders as $folder): ?>
                                        <option value="<?= e($folder['id']) ?>"><?= e($folder['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button class="bm-btn bm-btn-soft" type="submit" data-icon="folder-input">移动</button>
                            </form>
                            <a class="bm-btn bm-btn-soft" href="<?= url('shares') ?>" data-icon="share-2">去分享页配置</a>
                            <form method="post" action="<?= url('netdisk/delete') ?>" class="confirm-form" data-confirm="确认把该文件移入回收站吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                                <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                                <button class="bm-btn bm-btn-danger" type="submit" data-icon="archive-x">删除</button>
                            </form>
                        </div>
                    </details>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>
