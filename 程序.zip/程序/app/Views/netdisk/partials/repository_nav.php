<?php
$repoList = isset($repositories) ? $repositories : [];
$currentRepo = isset($repo) ? $repo : null;
$currentRepoId = $currentRepo ? (int) $currentRepo['id'] : 0;
$currentPath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/repository/create', PHP_URL_PATH);
$repoQuery = $currentRepoId > 0 ? '?id=' . $currentRepoId : '';
$repoStats = isset($stats) && is_array($stats) ? $stats : null;
$repoExpired = $currentRepo && !empty($currentRepo['expire_at']) && strtotime($currentRepo['expire_at']) < time();
$repoStateClass = !$currentRepo ? 'muted' : (empty($currentRepo['admin_status']) ? 'bad' : (empty($currentRepo['status']) || $repoExpired ? 'warn' : 'ok'));
$repoStateText = !$currentRepo ? '未创建' : (empty($currentRepo['admin_status']) ? '平台下架' : (empty($currentRepo['status']) ? '用户关闭' : ($repoExpired ? '链接过期' : '正常开放')));
$repoAccessText = !$currentRepo ? '-' : ($currentRepo['access_type'] === 'password' ? '密码访问' : ($currentRepo['access_type'] === 'private' ? '私密关闭' : '公开访问'));
$navItems = [
    ['path' => '/repository/create', 'url' => 'repository/create' . $repoQuery, 'label' => '创建仓库'],
    ['path' => '/repository/files', 'url' => 'repository/files' . $repoQuery, 'label' => '文件管理'],
    ['path' => '/repository/settings', 'url' => 'repository/settings' . $repoQuery, 'label' => '链接权限'],
    ['path' => '/repository/logs/access', 'url' => 'repository/logs/access' . $repoQuery, 'label' => '访问日志'],
    ['path' => '/repository/logs/download', 'url' => 'repository/logs/download' . $repoQuery, 'label' => '下载日志'],
];
?>

<section class="dashboard-hero glass reveal repository-hero">
    <div>
        <p class="eyebrow">Repository</p>
        <h1>分享仓库</h1>
        <p>把网盘文件整理成一个独立资料页，支持公开链接、密码访问、下载控制和访问记录。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="hard-drive">返回网盘</a>
        <?php if ($currentRepo): ?>
            <a class="btn btn-primary" href="<?= e(public_url('r/' . $currentRepo['slug'])) ?>" target="_blank" data-icon="external-link">打开仓库</a>
        <?php endif; ?>
    </div>
</section>

<?php if ($currentRepo): ?>
    <section class="repository-status-strip glass reveal">
        <div>
            <span>当前仓库</span>
            <b><?= e($currentRepo['title']) ?></b>
            <small><?= e(public_url('r/' . $currentRepo['slug'])) ?></small>
        </div>
        <div>
            <span>访问状态</span>
            <b class="repository-state <?= e($repoStateClass) ?>"><?= e($repoStateText) ?></b>
            <small><?= e($repoAccessText) ?></small>
        </div>
        <div>
            <span>公开文件</span>
            <b><?= e($repoStats ? (int) $repoStats['public_items'] : 0) ?></b>
            <small>总文件 <?= e($repoStats ? (int) $repoStats['items'] : 0) ?> 个</small>
        </div>
        <div class="repository-status-actions">
            <button class="btn btn-ghost copy-text-btn" type="button" data-copy-text="<?= e(public_url('r/' . $currentRepo['slug'])) ?>" data-icon="copy">复制链接</button>
            <a class="btn btn-primary" href="<?= url('repository/settings?id=' . $currentRepo['id']) ?>" data-icon="shield-check">检查设置</a>
        </div>
    </section>
<?php endif; ?>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Sub Pages</p>
        <h2>功能导航</h2>
    </div>
    <div class="repository-tabs repository-subnav">
        <?php foreach ($navItems as $item): ?>
            <a class="<?= $currentPath === $item['path'] ? 'active' : '' ?>" href="<?= url($item['url']) ?>">
                <b><?= e($item['label']) ?></b>
                <small><?= $currentPath === $item['path'] ? '当前页面' : '进入页面' ?></small>
            </a>
        <?php endforeach; ?>
    </div>
    <?php if ($repoList): ?>
        <div class="repository-tabs repository-tabs-list">
            <?php foreach ($repoList as $item): ?>
                <a class="<?= (int) $item['id'] === $currentRepoId ? 'active' : '' ?>" href="<?= url(trim($currentPath, '/') . '?id=' . $item['id']) ?>">
                    <b><?= e($item['title']) ?></b>
                    <small><?= e(public_url('r/' . $item['slug'])) ?></small>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php if (!empty($stats)): ?>
    <section class="workspace-summary-grid reveal">
        <article class="workspace-summary-card glass">
            <span>公开文件</span>
            <b><?= e($stats['public_items']) ?></b>
            <small>已对外展示的文件</small>
        </article>
        <article class="workspace-summary-card glass">
            <span>私密文件</span>
            <b><?= e($stats['private_items']) ?></b>
            <small>仅后台可见</small>
        </article>
        <article class="workspace-summary-card glass">
            <span>访问数</span>
            <b><?= e($stats['views']) ?></b>
            <small>今日 <?= e($stats['today_views']) ?> 次</small>
        </article>
        <article class="workspace-summary-card glass">
            <span>下载数</span>
            <b><?= e($stats['downloads']) ?></b>
            <small>今日 <?= e($stats['today_downloads']) ?> 次</small>
        </article>
    </section>
<?php endif; ?>
