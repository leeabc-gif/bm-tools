<?php
$order = isset($order) && is_array($order) ? $order : ['type' => 'recharge', 'status' => 'pending', 'order_no' => '', 'pay_amount' => 0, 'created_at' => ''];
$qrCode = isset($qrCode) ? $qrCode : '';
$isPackageOrder = isset($order['type']) && $order['type'] === 'package';
?>
<section class="pay-checkout-shell reveal">
    <div class="glass pay-checkout-card">
        <div class="pay-checkout-head">
            <div>
                <p class="eyebrow">支付宝支付</p>
                <h1><?= $isPackageOrder ? '套餐订单支付宝支付' : '支付宝扫码支付' ?></h1>
            </div>
            <span class="status-pill <?= $order['status'] === 'paid' ? 'ok' : 'soft' ?>"><?= $order['status'] === 'paid' ? '已支付' : '待支付' ?></span>
        </div>

        <div class="pay-order-summary">
            <span>订单号</span><b><?= e($order['order_no']) ?></b>
            <span>订单类型</span><b><?= $isPackageOrder ? '套餐购买' : '账户充值' ?></b>
            <span>支付金额</span><strong>¥<?= e(number_format((float) $order['pay_amount'], 2)) ?></strong>
            <span>创建时间</span><b><?= e($order['created_at']) ?></b>
        </div>

        <?php if ($order['status'] === 'paid'): ?>
            <div class="alert success"><?= $isPackageOrder ? '订单已支付，套餐权益已开通。' : '订单已支付，余额已入账。' ?></div>
            <a class="btn btn-primary full" href="<?= url($isPackageOrder ? 'packages' : 'recharge') ?>" data-icon="arrow-left"><?= $isPackageOrder ? '返回套餐中心' : '返回充值中心' ?></a>
        <?php elseif ($qrCode): ?>
            <div class="qr-box pay-qr-box">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=280x280&data=<?= urlencode($qrCode) ?>" alt="支付宝支付二维码">
            </div>
            <div class="pay-countdown" data-seconds="600">
                <b><?= $isPackageOrder ? '请使用支付宝扫码开通套餐' : '请使用支付宝扫码完成支付' ?></b>
                <span>二维码建议在 <em id="payCountdownText">10:00</em> 内完成支付。<?= $isPackageOrder ? '套餐订单支付成功后会自动开通权益。' : '支付成功后可点击刷新状态。' ?></span>
            </div>
            <form method="post" action="<?= url('pay/alipay/query') ?>" class="pay-query-form">
                <?= csrf_field() ?>
                <input type="hidden" name="order_no" value="<?= e($order['order_no']) ?>">
                <button class="btn btn-primary full" type="submit" data-icon="refresh-cw"><?= $isPackageOrder ? '我已支付，检查套餐状态' : '我已支付，刷新状态' ?></button>
                <a class="btn btn-ghost full" href="<?= url('orders') ?>" data-icon="receipt-text">查看订单记录</a>
                <a class="btn btn-ghost full" href="<?= url($isPackageOrder ? 'packages' : 'recharge') ?>" data-icon="arrow-left"><?= $isPackageOrder ? '返回套餐中心' : '返回充值中心' ?></a>
            </form>
        <?php else: ?>
            <div class="alert error">二维码不存在或已过期，请重新创建充值订单。</div>
            <a class="btn btn-primary full" href="<?= url($isPackageOrder ? 'packages' : 'recharge') ?>" data-icon="rotate-ccw"><?= $isPackageOrder ? '重新下单' : '重新充值' ?></a>
        <?php endif; ?>
    </div>
</section>
