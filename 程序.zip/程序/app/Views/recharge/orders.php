<?php
$orders = isset($orders) && is_array($orders) ? $orders : [];
$stats = isset($stats) ? $stats : ['total' => count($orders), 'paid' => 0, 'pending' => 0, 'amount' => 0];
$typeNames = ['recharge' => '账户充值', 'package' => '套餐购买'];
$methodNames = ['manual' => '人工处理', 'alipay' => '支付宝', 'wechat' => '微信支付', 'epay' => '易支付', 'balance' => '余额', 'card_code' => '卡密'];
$statusNames = ['pending' => '待支付 / 待处理', 'paid' => '已支付', 'closed' => '已关闭', 'refunded' => '已退款'];
$statusClasses = ['pending' => 'is-warn', 'paid' => 'is-ok', 'closed' => 'is-muted', 'refunded' => 'is-muted'];
$statusHint = function (array $row) {
    if ((isset($row['status']) ? $row['status'] : '') === 'paid') {
        return (isset($row['type']) && $row['type'] === 'package') ? '套餐权益已生效。' : '充值余额已到账。';
    }
    if ((isset($row['status']) ? $row['status'] : '') === 'closed') {
        return '订单已结束，如仍需使用请重新创建。';
    }
    if ((isset($row['payment_method']) ? $row['payment_method'] : '') === 'manual') {
        return (isset($row['type']) && $row['type'] === 'package') ? '等待管理员人工开通套餐。' : '等待管理员人工审核充值。';
    }
    return (isset($row['type']) && $row['type'] === 'package') ? '等待完成支付后自动开通套餐。' : '等待完成支付后自动入账。';
};
?>

<section class="bm-workspace orders-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Orders</span>
            <h1>订单记录</h1>
            <p>查看充值、套餐购买、支付状态和交易号。支付后未到账时，把订单号提供给管理员即可快速核查。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('recharge') ?>" data-icon="plus-circle">发起充值</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('cards') ?>" data-icon="ticket">卡密兑换</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('balance/logs') ?>" data-icon="coins">余额流水</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>订单总数</span><strong><?= e(number_format($stats['total'])) ?></strong><small>当前账号累计订单</small></article>
        <article class="bm-stat-card"><span>已支付</span><strong><?= e(number_format($stats['paid'])) ?></strong><small>已完成入账或开通</small></article>
        <article class="bm-stat-card <?= $stats['pending'] > 0 ? 'is-warn' : '' ?>"><span>待支付</span><strong><?= e(number_format($stats['pending'])) ?></strong><small>可继续支付或等待关闭</small></article>
        <article class="bm-stat-card"><span>已支付金额</span><strong>￥<?= e(number_format((float) $stats['amount'], 2)) ?></strong><small>不含待支付订单</small></article>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">History</span>
                <h2>全部订单</h2>
            </div>
        </div>

        <div class="bm-record-list">
            <?php if (!$orders): ?>
                <div class="bm-empty-state">
                    <i data-lucide="receipt-text"></i>
                    <strong>暂无订单记录</strong>
                    <span>充值或购买套餐后，订单会显示在这里。</span>
                </div>
            <?php endif; ?>
            <?php foreach ($orders as $row): ?>
                <?php
                $statusClass = isset($statusClasses[$row['status']]) ? $statusClasses[$row['status']] : 'is-muted';
                $typeText = isset($typeNames[$row['type']]) ? $typeNames[$row['type']] : $row['type'];
                $actionText = '无需操作';
                if ($row['status'] === 'pending' && $row['payment_method'] === 'alipay') {
                    $actionText = $row['type'] === 'package' ? '继续支付开通套餐' : '继续支付充值';
                } elseif ($row['status'] === 'pending' && $row['payment_method'] === 'manual') {
                    $actionText = $row['type'] === 'package' ? '等待人工处理开通套餐' : '等待人工审核入账';
                } elseif ($row['status'] === 'paid') {
                    $actionText = $row['type'] === 'package' ? '套餐已生效' : '余额已到账';
                } elseif ($row['status'] === 'closed') {
                    $actionText = '订单已关闭，如仍需购买请重新创建订单';
                }
                ?>
                <article class="bm-record-card">
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= $row['type'] === 'recharge' ? 'wallet-cards' : 'package' ?>"></i></span>
                        <div>
                            <strong><?= e($row['order_no']) ?></strong>
                            <small><?= e($typeText) ?> · <?= e($row['created_at']) ?></small>
                        </div>
                    </div>
                    <div class="bm-record-meta">
                        <span><b>套餐</b><?= e($row['package_name'] ?: '-') ?></span>
                        <span><b>金额</b>￥<?= e(number_format((float) $row['pay_amount'], 2)) ?></span>
                        <span><b>方式</b><?= e(isset($methodNames[$row['payment_method']]) ? $methodNames[$row['payment_method']] : ($row['payment_method'] ?: '-')) ?></span>
                        <span><b>状态</b><em class="bm-state-pill <?= e($statusClass) ?>"><?= e(isset($statusNames[$row['status']]) ? $statusNames[$row['status']] : $row['status']) ?></em></span>
                        <span><b>交易号</b><?= e($row['trade_no'] ?: '-') ?></span>
                        <span><b>说明</b><?= e($statusHint($row)) ?></span>
                    </div>
                    <div class="bm-record-actions">
                        <?php if (in_array($row['type'], ['recharge', 'package'], true) && $row['payment_method'] === 'alipay' && $row['status'] === 'pending'): ?>
                            <a class="bm-btn bm-btn-soft" href="<?= url('pay/alipay/' . $row['order_no']) ?>" data-icon="scan-line"><?= $row['type'] === 'package' ? '继续支付开通套餐' : '继续支付' ?></a>
                            <form method="post" action="<?= url('orders/close') ?>" class="inline-confirm-form" data-confirm="确认关闭该待支付订单吗？关闭后需重新创建。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="order_no" value="<?= e($row['order_no']) ?>">
                                <button class="bm-btn bm-btn-plain" type="submit" data-icon="x-circle">关闭订单</button>
                            </form>
                        <?php elseif ($row['status'] === 'pending' && $row['payment_method'] === 'manual'): ?>
                            <form method="post" action="<?= url('orders/close') ?>" class="inline-confirm-form" data-confirm="确认关闭该人工处理订单吗？关闭后将不再等待审核。">
                                <?= csrf_field() ?>
                                <input type="hidden" name="order_no" value="<?= e($row['order_no']) ?>">
                                <button class="bm-btn bm-btn-plain" type="submit" data-icon="x-circle">关闭订单</button>
                            </form>
                        <?php else: ?>
                            <span class="bm-muted"><?= e($actionText) ?></span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>
