<?php
$stats = isset($stats) ? $stats : ['total' => count($logs), 'recharge' => 0, 'consume' => 0, 'refund' => 0, 'adjust' => 0];
$typeNames = ['recharge' => '充值', 'consume' => '消费', 'refund' => '退款', 'adjust' => '调整'];
$typeIcons = ['recharge' => 'plus-circle', 'consume' => 'shopping-bag', 'refund' => 'rotate-ccw', 'adjust' => 'sliders-horizontal'];
$typeClasses = ['recharge' => 'is-ok', 'consume' => 'is-muted', 'refund' => 'is-warn', 'adjust' => 'is-warn'];
?>

<section class="bm-workspace balance-logs-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Balance</span>
            <h1>余额流水</h1>
            <p>记录充值、消费、管理员调整、卡密兑换等余额变化，便于核对账户资金。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('recharge') ?>" data-icon="plus-circle">账户充值</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('orders') ?>" data-icon="receipt-text">订单记录</a>
            </div>
        </div>
    </header>

    <section class="bm-stat-grid">
        <article class="bm-stat-card"><span>流水条数</span><strong><?= e(number_format($stats['total'])) ?></strong><small>最近 200 条记录</small></article>
        <article class="bm-stat-card"><span>累计充值</span><strong>￥<?= e(number_format((float) $stats['recharge'], 2)) ?></strong><small>余额入账</small></article>
        <article class="bm-stat-card"><span>累计消费</span><strong>￥<?= e(number_format((float) $stats['consume'], 2)) ?></strong><small>套餐和资源消费</small></article>
        <article class="bm-stat-card <?= ((float) $stats['refund'] + (float) $stats['adjust']) > 0 ? 'is-warn' : '' ?>"><span>退款/调整</span><strong>￥<?= e(number_format((float) $stats['refund'] + (float) $stats['adjust'], 2)) ?></strong><small>售后或人工修正</small></article>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Ledger</span>
                <h2>资金明细</h2>
            </div>
        </div>
        <div class="bm-record-list">
            <?php if (!$logs): ?>
                <div class="bm-empty-state">
                    <i data-lucide="coins"></i>
                    <strong>暂无余额流水</strong>
                    <span>充值、购买套餐或兑换卡密后会出现记录。</span>
                </div>
            <?php endif; ?>
            <?php foreach ($logs as $row): ?>
                <?php
                $type = isset($typeNames[$row['type']]) ? $row['type'] : 'adjust';
                $related = trim((string) ($row['related_type'] ?: ''));
                if (!empty($row['related_id'])) {
                    $related .= ($related === '' ? '' : ' ') . '#' . $row['related_id'];
                }
                ?>
                <article class="bm-record-card">
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="<?= e($typeIcons[$type]) ?>"></i></span>
                        <div>
                            <strong><?= e($typeNames[$type]) ?> · ￥<?= e(number_format((float) $row['amount'], 2)) ?></strong>
                            <small><?= e($row['created_at']) ?></small>
                        </div>
                    </div>
                    <div class="bm-record-meta">
                        <span><b>变动前</b>￥<?= e(number_format((float) $row['balance_before'], 2)) ?></span>
                        <span><b>变动后</b>￥<?= e(number_format((float) $row['balance_after'], 2)) ?></span>
                        <span><b>关联</b><?= e($related !== '' ? $related : '-') ?></span>
                        <span><b>备注</b><?= e($row['remark'] ?: '-') ?></span>
                        <span><b>类型</b><em class="bm-state-pill <?= e($typeClasses[$type]) ?>"><?= e($typeNames[$type]) ?></em></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>
