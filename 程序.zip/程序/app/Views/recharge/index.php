<?php
$payments = isset($payments) && is_array($payments) ? $payments : [];
$recharges = isset($recharges) && is_array($recharges) ? $recharges : [];
$methodNames = ['manual' => '人工充值审核', 'alipay' => '支付宝当面付', 'wechat' => '微信支付', 'epay' => '易支付', 'balance' => '余额支付'];
$statusNames = ['pending' => '待支付 / 待审核', 'paid' => '已入账', 'rejected' => '已拒绝', 'closed' => '已关闭'];
$quickAmounts = [10, 30, 50, 100, 200, 500];
$statusHint = function (array $row) {
    $remark = isset($row['audit_remark']) ? (string) $row['audit_remark'] : '';
    if ((isset($row['status']) ? $row['status'] : '') === 'paid') {
        return '资金已到账，可用于购买套餐和后续服务。';
    }
    if ((isset($row['status']) ? $row['status'] : '') === 'rejected') {
        return $remark !== '' ? $remark : '管理员已拒绝该充值申请。';
    }
    if ((isset($row['status']) ? $row['status'] : '') === 'closed') {
        return $remark !== '' ? $remark : '订单已关闭，如仍需充值请重新创建订单。';
    }
    if ((isset($row['payment_method']) ? $row['payment_method'] : '') === 'manual') {
        return '已提交人工审核，请联系管理员并等待处理。';
    }
    return $remark !== '' ? $remark : '等待继续支付或等待系统确认。';
};
?>

<section class="bm-workspace recharge-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Wallet</span>
            <h1>账户充值</h1>
            <p>充值余额可用于购买套餐、续费套餐和后续增值服务。在线支付成功后自动入账，人工充值需要管理员审核。</p>
            <div class="bm-action-row">
                <a class="bm-btn bm-btn-primary" href="<?= url('cards') ?>" data-icon="ticket">卡密兑换</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('orders') ?>" data-icon="receipt-text">订单记录</a>
                <a class="bm-btn bm-btn-soft" href="<?= url('balance/logs') ?>" data-icon="coins">余额流水</a>
            </div>
        </div>
    </header>

    <section class="bm-recharge-grid">
        <article class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Create Order</span>
                    <h2>创建充值订单</h2>
                </div>
                <span class="bm-state-pill">人民币 CNY</span>
            </div>

            <form method="post" action="<?= url('recharge') ?>" class="bm-recharge-form">
                <?= csrf_field() ?>
                <label>
                    <span>充值金额</span>
                    <input id="rechargeAmount" type="number" step="0.01" min="1" max="99999" name="amount" required placeholder="请输入充值金额">
                </label>
                <div class="bm-quick-amounts" aria-label="快捷金额">
                    <?php foreach ($quickAmounts as $amount): ?>
                        <button class="bm-btn bm-btn-soft quick-amount" type="button" data-amount="<?= e($amount) ?>">￥<?= e($amount) ?></button>
                    <?php endforeach; ?>
                </div>

                <div class="bm-payment-grid">
                    <?php foreach ($payments as $index => $payment): ?>
                        <?php $code = $payment['code']; ?>
                        <label class="bm-payment-card <?= $index === 0 ? 'active' : '' ?>">
                            <input type="radio" name="payment_method" value="<?= e($code) ?>" <?= $index === 0 ? 'checked' : '' ?>>
                            <span class="bm-icon-tile"><i data-lucide="<?= $code === 'alipay' ? 'scan-line' : 'badge-check' ?>"></i></span>
                            <strong><?= e($payment['name']) ?></strong>
                            <small>
                                <?php if ($code === 'alipay'): ?>
                                    扫码支付，成功后自动入账
                                <?php elseif ($code === 'manual'): ?>
                                    提交订单后由管理员审核
                                <?php else: ?>
                                    当前支付通道已启用
                                <?php endif; ?>
                            </small>
                        </label>
                    <?php endforeach; ?>
                </div>

                <button class="bm-btn bm-btn-primary" type="submit" <?= empty($payments) ? 'disabled' : '' ?> data-icon="plus-circle">创建充值订单</button>
            </form>

            <?php if (empty($payments)): ?>
                <div class="bm-inline-notice is-warning">
                    <i data-lucide="alert-triangle"></i>
                    <div>
                        <strong>暂无可用充值方式</strong>
                        <span>请管理员先在后台启用人工充值或配置支付宝当面付。</span>
                    </div>
                </div>
            <?php endif; ?>
        </article>

        <aside class="bm-card">
            <div class="bm-card-head">
                <div>
                    <span class="bm-eyebrow">Guide</span>
                    <h2>充值说明</h2>
                </div>
            </div>
            <div class="bm-guide-list">
                <div><strong>快捷金额</strong><span>点击金额按钮会自动填入充值金额，也可以手动输入任意合法金额。</span></div>
                <div><strong>自动入账</strong><span>支付宝当面付支付成功后会自动回调入账，也可以在扫码页手动刷新订单状态。</span></div>
                <div><strong>卡密充值</strong><span>如果你购买了余额卡或收到平台发放的兑换码，可以进入卡密兑换页自动入账。</span></div>
                <div><strong>人工审核</strong><span>人工充值订单创建后请联系管理员，审核通过后余额会进入账户。</span></div>
            </div>
        </aside>
    </section>

    <section class="bm-card">
        <div class="bm-card-head">
            <div>
                <span class="bm-eyebrow">Recharge Logs</span>
                <h2>充值记录</h2>
            </div>
            <a class="bm-btn bm-btn-soft" href="<?= url('orders') ?>" data-icon="external-link">查看全部订单</a>
        </div>
        <div class="bm-record-list">
            <?php if (!$recharges): ?>
                <div class="bm-empty-line">暂无充值记录。</div>
            <?php endif; ?>
            <?php foreach ($recharges as $row): ?>
                <article class="bm-record-card is-compact">
                    <div class="bm-record-main">
                        <span class="bm-icon-tile is-small"><i data-lucide="wallet-cards"></i></span>
                        <div>
                            <strong>￥<?= e(number_format((float) $row['amount'], 2)) ?></strong>
                            <small><?= e($row['created_at']) ?></small>
                        </div>
                    </div>
                    <div class="bm-record-meta">
                        <span><b>方式</b><?= e(isset($methodNames[$row['payment_method']]) ? $methodNames[$row['payment_method']] : $row['payment_method']) ?></span>
                        <span><b>状态</b><em class="bm-state-pill"><?= e(isset($statusNames[$row['status']]) ? $statusNames[$row['status']] : $row['status']) ?></em></span>
                        <span><b>说明</b><?= e($statusHint($row)) ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</section>
