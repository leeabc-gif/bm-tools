<?php
$isLogin = \App\Core\Auth::check();
$packages = isset($packages) && is_array($packages) ? $packages : [];
$payments = isset($payments) && is_array($payments) ? $payments : [];
$packageMethodNames = ['balance' => '余额支付', 'alipay' => '支付宝当面付', 'manual' => '人工处理'];
?>

<section class="bm-workspace packages-v2">
    <header class="bm-page-hero bm-page-hero-compact">
        <div class="bm-hero-copy">
            <span class="bm-eyebrow">Plans</span>
            <h1>选择适合你的套餐</h1>
            <p>套餐决定图床、个人网盘、API 上传、分享能力、容量、流量和单文件大小。权益清晰展示，购买前可以直接对比。</p>
            <div class="bm-action-row">
                <?php if ($isLogin): ?>
                    <a class="bm-btn bm-btn-soft" href="<?= url('cards') ?>" data-icon="ticket">兑换卡密</a>
                    <a class="bm-btn bm-btn-soft" href="<?= url('orders') ?>" data-icon="receipt-text">订单记录</a>
                <?php else: ?>
                    <a class="bm-btn bm-btn-primary" href="<?= url('register') ?>" data-icon="user-plus">创建账号</a>
                    <a class="bm-btn bm-btn-soft" href="<?= url('login') ?>" data-icon="log-in">登录购买</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <?php if ($isLogin): ?>
        <section class="bm-inline-notice">
            <i data-lucide="ticket"></i>
            <div>
                <strong>已有套餐卡？</strong>
                <span>套餐兑换卡可直接开通或续期会员权益，适合活动赠送、代理售卖和线下购买。</span>
            </div>
            <a href="<?= url('cards') ?>">去兑换</a>
        </section>
    <?php endif; ?>

    <?php if (!empty($coupons)): ?>
        <section class="bm-coupon-strip">
            <div>
                <span class="bm-eyebrow">Coupons</span>
                <h2>当前可用活动</h2>
                <p>购买套餐时输入优惠码即可抵扣，实际可用规则以提交订单时校验为准。</p>
            </div>
            <div class="bm-coupon-list">
                <?php foreach ($coupons as $coupon): ?>
                    <span>
                        <strong><?= e($coupon['code']) ?></strong>
                        <?= $coupon['discount_type'] === 'percent' ? e($coupon['discount_value']) . '% 折扣' : '立减 ¥' . e($coupon['discount_value']) ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="bm-pricing-grid">
        <?php foreach ($packages as $package): ?>
            <?php
            $displayPrice = (float) $package['price'];
            if ($isLogin) {
                $u = \App\Core\Auth::user();
                if (!empty($u['package_id']) && (int) $u['package_id'] !== (int) $package['id'] && !empty($u['package_expire_time']) && strtotime($u['package_expire_time']) > time()) {
                    $old = \App\Core\Database::fetch('SELECT * FROM ' . \App\Core\Database::table('packages') . ' WHERE id = ? LIMIT 1', [$u['package_id']]);
                    if ($old && (float) $old['price'] > 0) {
                        $remainingDays = max(0, (strtotime($u['package_expire_time']) - time()) / 86400);
                        $credit = ((float) $old['price']) * min(1, $remainingDays / max(1, (int) $old['duration_days']));
                        $displayPrice = round(max(0, (float) $package['price'] - $credit), 2);
                    }
                }
            }
            $features = [
                '时长：' . ($package['duration_type'] === 'forever' ? '永久' : $package['duration_days'] . ' 天'),
                '空间：' . format_bytes($package['storage_limit']),
                '月流量：' . format_bytes($package['traffic_limit']),
                '单文件：' . ((int) $package['single_file_limit'] > 0 ? format_bytes($package['single_file_limit']) : '不限'),
                $package['allow_image'] ? '支持图床服务' : '不支持图床服务',
                $package['allow_netdisk'] ? '支持个人网盘' : '不支持个人网盘',
                $package['allow_api'] ? '支持 API 上传' : '不支持 API 上传',
                !empty($package['allow_monitor']) ? '支持服务器运维与监控' : '不支持服务器运维',
                $package['allow_share'] ? '支持文件分享' : '不支持文件分享',
                !empty($package['allow_subsite']) ? '支持个人分站：' . (int) $package['subsite_limit'] . ' 个' : '不支持个人分站',
            ];
            ?>
            <article class="bm-price-card">
                <div class="bm-price-head">
                    <span class="bm-icon-tile"><i data-lucide="package"></i></span>
                    <div>
                        <h2><?= e($package['name']) ?></h2>
                        <p><?= e($package['description']) ?></p>
                    </div>
                </div>
                <div class="bm-price">
                    <strong>¥<?= e(number_format($displayPrice, 2)) ?></strong>
                    <?php if ($displayPrice != (float) $package['price']): ?>
                        <span>已抵扣当前套餐剩余价值，原价 ¥<?= e($package['price']) ?></span>
                    <?php else: ?>
                        <span><?= $package['duration_type'] === 'forever' ? '一次购买长期有效' : e($package['duration_days']) . ' 天权益' ?></span>
                    <?php endif; ?>
                </div>
                <ul class="bm-feature-list">
                    <?php foreach ($features as $feature): ?>
                        <li><i data-lucide="check"></i><span><?= e($feature) ?></span></li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($isLogin): ?>
                    <form method="post" action="<?= url('packages/buy') ?>" class="package-buy-form bm-plan-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="package_id" value="<?= e($package['id']) ?>">
                        <label>
                            <span>优惠码（可选）</span>
                            <input name="coupon_code" placeholder="有活动码时填写">
                        </label>
                        <?php if ($payments): ?>
                            <div class="bm-payment-grid">
                                <?php foreach ($payments as $index => $payment): ?>
                                    <?php $code = $payment['code']; ?>
                                    <label class="bm-payment-card <?= $index === 0 ? 'active' : '' ?>">
                                        <input type="radio" name="payment_method" value="<?= e($code) ?>" <?= $index === 0 ? 'checked' : '' ?>>
                                        <span class="bm-icon-tile"><i data-lucide="<?= $code === 'alipay' ? 'scan-line' : ($code === 'manual' ? 'hand-coins' : 'wallet') ?>"></i></span>
                                        <strong><?= e(isset($packageMethodNames[$code]) ? $packageMethodNames[$code] : $payment['name']) ?></strong>
                                        <small><?= $code === 'balance' ? '立即扣减账户余额并开通套餐' : ($code === 'alipay' ? '扫码支付成功后自动开通套餐' : '提交订单后等待管理员处理') ?></small>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <button class="bm-btn bm-btn-primary" type="submit" data-icon="shopping-cart"><?= $payments ? '提交套餐订单' : '当前暂无可用支付方式' ?></button>
                    </form>
                <?php else: ?>
                    <a class="bm-btn bm-btn-primary" href="<?= url('login') ?>" data-icon="log-in">登录后购买</a>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    </section>
</section>
