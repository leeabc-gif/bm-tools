<?php
$payments = isset($payments) && is_array($payments) ? $payments : [];
$paymentStats = isset($paymentStats) ? $paymentStats : ['total' => count($payments), 'enabled' => 0, 'manual' => 0, 'online' => 0, 'configured' => 0];
$paymentMeta = [
    'balance' => ['icon' => 'wallet', 'title' => '余额支付', 'desc' => '用户使用账户余额购买套餐，建议保持启用。'],
    'alipay' => ['icon' => 'scan-line', 'title' => '支付宝当面付', 'desc' => '配置 AppID、应用私钥、支付宝公钥和回调地址。'],
    'wechat' => ['icon' => 'message-circle', 'title' => '微信支付', 'desc' => '微信商户通道配置，适合后续扩展扫码或小程序支付。'],
    'epay' => ['icon' => 'landmark', 'title' => '易支付', 'desc' => '聚合支付扩展通道，配置项使用 JSON 保存。'],
    'manual' => ['icon' => 'user-check', 'title' => '人工充值', 'desc' => '线下转账和人工审核兜底通道。'],
];
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Payments</span><h1>支付配置</h1><p>收款通道核心参数、启停和排序集中管理，保存后建议用前台充值页做一笔小额测试。</p></div>
        <a class="m-pill" href="<?= url('admin/m/orders') ?>">订单</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>通道总数</span><strong><?= e($paymentStats['total']) ?></strong><small>余额、在线和人工</small></article>
        <article><span>已启用</span><strong><?= e($paymentStats['enabled']) ?></strong><small>当前可用收款</small></article>
        <article><span>在线通道</span><strong><?= e($paymentStats['online']) ?></strong><small>不含人工充值</small></article>
        <article><span>已配置</span><strong><?= e($paymentStats['configured']) ?></strong><small>关键参数已填写</small></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Check</span><h2>上线检查</h2></div></div>
        <div class="m-status-row">
            <article class="m-check-card ok"><b>回调地址</b><span>确认公网可访问，再去充值页下单测试。</span></article>
            <article class="m-check-card"><b>人工兜底</b><span>建议保留人工充值，处理支付异常和早期运营。</span></article>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Methods</span><h2>收款通道</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索支付方式、通道代码或状态" data-mobile-filter-input="#adminMobilePaymentsList">
        </label>
        <div class="m-list" id="adminMobilePaymentsList">
            <?php foreach ($payments as $payment): ?>
                <?php
                $code = isset($payment['code']) ? (string) $payment['code'] : '';
                $meta = isset($paymentMeta[$code]) ? $paymentMeta[$code] : ['icon' => 'credit-card', 'title' => (string) $payment['name'], 'desc' => '扩展支付方式配置。'];
                $config = json_decode((string) (isset($payment['config']) ? $payment['config'] : ''), true);
                $config = is_array($config) ? $config : [];
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= e($meta['icon']) ?>"></i>
                    <div>
                        <strong><?= e($meta['title']) ?></strong>
                        <span><?= e($meta['desc']) ?></span>
                    </div>
                    <span class="m-badge <?= !empty($payment['is_enabled']) ? 'ok' : 'bad' ?>"><?= !empty($payment['is_enabled']) ? '启用' : '停用' ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e($code) ?></span>
                        <span class="m-badge muted">排序 <?= e(isset($payment['sort_order']) ? $payment['sort_order'] : 0) ?></span>
                    </div>
                    <details class="m-fold">
                        <summary>编辑配置</summary>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/payments/save') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($payment['id']) ?>">
                            <input type="hidden" name="code" value="<?= e($code) ?>">
                            <input name="name" value="<?= e($payment['name']) ?>" placeholder="显示名称">
                            <div class="m-status-row">
                                <select name="is_enabled">
                                    <option value="1" <?= !empty($payment['is_enabled']) ? 'selected' : '' ?>>启用</option>
                                    <option value="0" <?= empty($payment['is_enabled']) ? 'selected' : '' ?>>停用</option>
                                </select>
                                <input type="number" name="sort_order" value="<?= e(isset($payment['sort_order']) ? $payment['sort_order'] : 0) ?>" placeholder="排序">
                            </div>

                            <?php if ($code === 'alipay'): ?>
                                <input name="app_id" value="<?= e(isset($config['app_id']) ? $config['app_id'] : '') ?>" placeholder="支付宝 AppID">
                                <textarea name="private_key" rows="5" placeholder="应用私钥"><?= e(isset($config['private_key']) ? $config['private_key'] : '') ?></textarea>
                                <textarea name="alipay_public_key" rows="5" placeholder="支付宝公钥"><?= e(isset($config['alipay_public_key']) ? $config['alipay_public_key'] : '') ?></textarea>
                                <input name="notify_url" value="<?= e(isset($config['notify_url']) ? $config['notify_url'] : '') ?>" placeholder="<?= e(url('pay/alipay/notify')) ?>">
                                <input name="timeout_express" value="<?= e(isset($config['timeout_express']) ? $config['timeout_express'] : '10m') ?>" placeholder="订单有效期，例如 10m">
                                <label class="m-checkline"><input type="checkbox" name="sandbox" <?= !empty($config['sandbox']) ? 'checked' : '' ?>> 使用沙箱模式</label>
                            <?php elseif ($code === 'manual'): ?>
                                <textarea name="instructions" rows="5" placeholder="人工充值说明"><?= e(isset($config['instructions']) ? $config['instructions'] : '') ?></textarea>
                                <textarea name="contact" rows="4" placeholder="联系方式、收款账户或审核时间"><?= e(isset($config['contact']) ? $config['contact'] : '') ?></textarea>
                            <?php elseif ($code !== 'balance'): ?>
                                <textarea name="config_json" rows="6" placeholder='{"merchant_id":"","secret_key":""}'><?= e(!empty($payment['config']) ? $payment['config'] : '{}') ?></textarea>
                            <?php else: ?>
                                <div class="m-note">余额支付无需密钥，只需要控制是否启用和排序。</div>
                            <?php endif; ?>

                            <button type="submit">保存当前通道</button>
                        </form>
                    </details>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的支付通道。</div>
            <?php if (!$payments): ?><div class="m-empty">暂无支付配置。请先进入系统维护执行数据库修复或重新导入初始化数据。</div><?php endif; ?>
        </div>
    </section>
</section>
