<?php
$stats = isset($stats) ? $stats : ['policies' => 0, 'enabled_policies' => 0, 'success' => 0, 'failed' => 0, 'pending' => 0];
$storages = isset($storages) && is_array($storages) ? $storages : [];
$policies = isset($policies) && is_array($policies) ? $policies : [];
$tasks = isset($tasks) && is_array($tasks) ? $tasks : [];
$migrationPlan = isset($migrationPlan) && is_array($migrationPlan) ? $migrationPlan : ['total' => 0, 'ready_backup' => 0, 'local_readable' => 0, 'needs_upload_or_backup' => 0];
$migrationTasks = isset($migrationTasks) && is_array($migrationTasks) ? $migrationTasks : [];
$scopeLabels = ['all' => '全部文件', 'image' => '图床图片', 'file' => '网盘文件'];
$strategyLabels = ['ignore' => '忽略失败', 'warn' => '记录告警', 'strict' => '严格失败'];
$statusClass = ['success' => 'ok', 'failed' => 'bad', 'pending' => 'warn', 'skipped' => 'muted', 'deleted' => 'muted'];
$enabledStorages = array_values(array_filter($storages, function ($item) {
    return !empty($item['is_enabled']);
}));
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Backup</span><h1>存储备份</h1><p>把上传文件同步写入多个存储厂商，主存储负责访问，备份存储负责容灾。</p></div>
        <a class="m-pill" href="<?= url('admin/m/storages') ?>">存储</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>策略</span><strong><?= e($stats['policies']) ?></strong><small>已启用 <?= e($stats['enabled_policies']) ?></small></article>
        <article><span>成功</span><strong><?= e($stats['success']) ?></strong><small>备份已完成</small></article>
        <article><span>失败</span><strong><?= e($stats['failed']) ?></strong><small>需要检查 Key 或网络</small></article>
        <article><span>等待</span><strong><?= e($stats['pending']) ?></strong><small>待处理任务</small></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="存储备份分区">
        <a href="#backupCreate">新增策略</a>
        <a href="#backupPolicies">策略列表</a>
        <a href="#backupTasks">备份任务</a>
        <a href="#backupMigration">存储迁移</a>
        <a href="<?= url('admin/m/storages') ?>">存储配置</a>
    </nav>

    <details class="m-fold" id="backupCreate">
        <summary>新增备份策略</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/storage-backups/save') ?>">
            <?= csrf_field() ?>
            <input name="name" value="<?= e(old('name')) ?>" placeholder="策略名称，例如：默认双厂商备份" required>
            <select name="primary_storage_id">
                <option value="0">任意主存储</option>
                <?php foreach ($storages as $storage): ?>
                    <option value="<?= e($storage['id']) ?>"><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?></option>
                <?php endforeach; ?>
            </select>
            <div class="m-status-row">
                <select name="file_scope">
                    <option value="all">全部文件</option>
                    <option value="image">只备份图床图片</option>
                    <option value="file">只备份网盘文件</option>
                </select>
                <select name="failure_strategy">
                    <option value="warn">记录告警，主上传继续</option>
                    <option value="ignore">忽略失败，仅写日志</option>
                    <option value="strict">严格失败，备份失败则上传失败</option>
                </select>
            </div>
            <input type="number" name="sort_order" value="<?= e(old('sort_order', '0')) ?>" placeholder="排序">
            <div class="m-note">备份目标只能选择已启用存储源，且不能等于当前主存储。</div>
            <?php foreach ($enabledStorages as $storage): ?>
                <label class="m-checkline"><input type="checkbox" name="backup_storage_ids[]" value="<?= e($storage['id']) ?>"> <?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></label>
            <?php endforeach; ?>
            <?php if (!$enabledStorages): ?><div class="m-empty">还没有可用存储源，请先在存储状态中启用至少两个存储。</div><?php endif; ?>
            <label class="m-checkline"><input type="checkbox" name="is_enabled" checked> 启用该策略</label>
            <button type="submit">保存备份策略</button>
        </form>
    </details>

    <?php if ((int) $stats['failed'] > 0): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Retry</span><h2>失败任务处理</h2></div></div>
            <form class="m-mini-form" method="post" action="<?= url('admin/m/storage-backups/retry-failed') ?>">
                <?= csrf_field() ?>
                <input type="number" name="limit" min="1" max="100" value="20" placeholder="本次最多重试数量">
                <button type="submit" data-mobile-confirm="确认批量重试失败备份任务吗？">批量重试失败任务</button>
            </form>
        </section>
    <?php endif; ?>

    <section class="m-card" id="backupPolicies">
        <div class="m-section-head"><div><span>Policies</span><h2>备份策略</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索策略、范围、厂商或状态" data-mobile-filter-input="#adminMobileBackupPoliciesList">
        </label>
        <div class="m-list" id="adminMobileBackupPoliciesList">
            <?php foreach ($policies as $policy): ?>
                <?php
                $backupIds = !empty($policy['backup_storage_id_list']) && is_array($policy['backup_storage_id_list']) ? array_map('intval', $policy['backup_storage_id_list']) : [];
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="database-backup"></i>
                    <div>
                        <strong><?= e($policy['name']) ?></strong>
                        <span><?= e(isset($scopeLabels[$policy['file_scope']]) ? $scopeLabels[$policy['file_scope']] : $policy['file_scope']) ?> · <?= e(isset($strategyLabels[$policy['failure_strategy']]) ? $strategyLabels[$policy['failure_strategy']] : $policy['failure_strategy']) ?></span>
                    </div>
                    <span class="m-badge <?= !empty($policy['is_enabled']) ? 'ok' : 'bad' ?>"><?= !empty($policy['is_enabled']) ? '启用' : '停用' ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= (int) $policy['primary_storage_id'] === 0 ? '任意主存储' : ('主存储 #' . e($policy['primary_storage_id'])) ?></span>
                        <span class="m-badge muted">排序 <?= e($policy['sort_order']) ?></span>
                        <?php foreach ((array) $policy['backup_names'] as $name): ?><span class="m-badge muted"><?= e($name) ?></span><?php endforeach; ?>
                    </div>
                    <details class="m-fold">
                        <summary>编辑策略</summary>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/storage-backups/save') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($policy['id']) ?>">
                            <input name="name" value="<?= e($policy['name']) ?>" required>
                            <select name="primary_storage_id">
                                <option value="0" <?= (int) $policy['primary_storage_id'] === 0 ? 'selected' : '' ?>>任意主存储</option>
                                <?php foreach ($storages as $storage): ?>
                                    <option value="<?= e($storage['id']) ?>" <?= (int) $policy['primary_storage_id'] === (int) $storage['id'] ? 'selected' : '' ?>><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="m-status-row">
                                <select name="file_scope">
                                    <?php foreach ($scopeLabels as $value => $label): ?>
                                        <option value="<?= e($value) ?>" <?= $policy['file_scope'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="failure_strategy">
                                    <?php foreach ($strategyLabels as $value => $label): ?>
                                        <option value="<?= e($value) ?>" <?= $policy['failure_strategy'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <input type="number" name="sort_order" value="<?= e($policy['sort_order']) ?>">
                            <?php foreach ($enabledStorages as $storage): ?>
                                <label class="m-checkline"><input type="checkbox" name="backup_storage_ids[]" value="<?= e($storage['id']) ?>" <?= in_array((int) $storage['id'], $backupIds, true) ? 'checked' : '' ?>> <?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></label>
                            <?php endforeach; ?>
                            <label class="m-checkline"><input type="checkbox" name="is_enabled" <?= !empty($policy['is_enabled']) ? 'checked' : '' ?>> 启用该策略</label>
                            <button class="ghost" type="submit">保存调整</button>
                        </form>
                    </details>
                    <div class="m-inline-actions">
                        <form method="post" action="<?= url('admin/m/storage-backups/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($policy['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个备份策略吗？历史任务记录会保留。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的备份策略。</div>
            <?php if (!$policies): ?><div class="m-empty">暂无备份策略。先启用至少两个存储源，再创建双厂商备份策略。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="backupTasks">
        <div class="m-section-head"><div><span>Tasks</span><h2>最近备份任务</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索文件、策略、存储或状态" data-mobile-filter-input="#adminMobileBackupTasksList">
        </label>
        <div class="m-list" id="adminMobileBackupTasksList">
            <?php foreach ($tasks as $task): ?>
                <?php $status = isset($task['status']) ? (string) $task['status'] : 'pending'; ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="list-checks"></i>
                    <div>
                        <strong><?= e(!empty($task['original_name']) ? $task['original_name'] : ('文件 #' . $task['file_id'])) ?></strong>
                        <span><?= e(!empty($task['policy_name']) ? $task['policy_name'] : '未命名策略') ?> · <?= e(!empty($task['storage_name']) ? $task['storage_name'] : ('存储 #' . $task['storage_id'])) ?></span>
                    </div>
                    <span class="m-badge <?= e(isset($statusClass[$status]) ? $statusClass[$status] : 'muted') ?>"><?= e($status) ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">尝试 <?= e(isset($task['attempts']) ? $task['attempts'] : 0) ?></span>
                        <span class="m-badge muted"><?= e(!empty($task['updated_at']) ? $task['updated_at'] : $task['created_at']) ?></span>
                    </div>
                    <?php if (!empty($task['error_message'])): ?><div class="m-note"><?= e($task['error_message']) ?></div><?php endif; ?>
                    <?php if ($status === 'failed'): ?>
                        <div class="m-inline-actions">
                            <form method="post" action="<?= url('admin/m/storage-backups/retry') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($task['id']) ?>">
                                <button class="m-button" type="submit" data-mobile-confirm="确认重试这个备份任务吗？">重试</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的备份任务。</div>
            <?php if (!$tasks): ?><div class="m-empty">暂无备份任务。上传文件命中策略后会自动生成任务记录。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="backupMigration">
        <div class="m-section-head"><div><span>Migration</span><h2>存储迁移</h2></div></div>
        <div class="m-status-row">
            <article class="m-check-card soft"><b>待评估</b><span><?= e((int) $migrationPlan['total']) ?></span></article>
            <article class="m-check-card ok"><b>可切换</b><span><?= e((int) $migrationPlan['ready_backup']) ?></span></article>
            <article class="m-check-card soft"><b>本地可迁</b><span><?= e((int) $migrationPlan['local_readable']) ?></span></article>
            <article class="m-check-card warn"><b>仍需处理</b><span><?= e((int) $migrationPlan['needs_upload_or_backup']) ?></span></article>
        </div>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/storage-migration/run') ?>" data-mobile-confirm="确认执行本批次存储迁移吗？建议先小批量验证。">
            <?= csrf_field() ?>
            <select name="source_storage_id">
                <option value="0">全部当前存储</option>
                <?php foreach ($storages as $storage): ?>
                    <option value="<?= e($storage['id']) ?>"><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?><?= !empty($storage['is_default']) ? ' / 默认' : '' ?></option>
                <?php endforeach; ?>
            </select>
            <select name="target_storage_id" required>
                <option value="0">请选择目标存储</option>
                <?php foreach ($enabledStorages as $storage): ?>
                    <option value="<?= e($storage['id']) ?>"><?= e($storage['name']) ?> / <?= e(strtoupper($storage['type'])) ?></option>
                <?php endforeach; ?>
            </select>
            <div class="m-status-row">
                <select name="file_scope">
                    <option value="">全部文件</option>
                    <option value="image">只迁移图床图片</option>
                    <option value="file">只迁移网盘文件</option>
                </select>
                <input type="number" name="limit" min="1" max="100" value="10" placeholder="本批数量">
            </div>
            <label class="m-checkline"><input type="checkbox" name="switch_primary"> 成功后切换主文件记录到目标存储</label>
            <div class="m-note">本地可读文件会真实上传；目标已有成功备份时可直接切换。远程源文件不可读时会跳过并写明原因。</div>
            <button type="submit">执行迁移批次</button>
        </form>
        <?php if ($migrationTasks): ?>
            <div class="m-list">
                <?php foreach ($migrationTasks as $task): ?>
                    <?php $status = isset($task['status']) ? (string) $task['status'] : 'pending'; ?>
                    <article class="m-list-item tall">
                        <i data-lucide="replace-all"></i>
                        <div>
                            <strong><?= e(!empty($task['original_name']) ? $task['original_name'] : ('文件 #' . $task['file_id'])) ?></strong>
                            <span><?= e(!empty($task['storage_name']) ? $task['storage_name'] : ('存储 #' . $task['storage_id'])) ?> · 尝试 <?= e(isset($task['attempts']) ? $task['attempts'] : 0) ?></span>
                        </div>
                        <span class="m-badge <?= e(isset($statusClass[$status]) ? $statusClass[$status] : 'muted') ?>"><?= e($status) ?></span>
                        <?php if (!empty($task['error_message'])): ?><div class="m-note"><?= e($task['error_message']) ?></div><?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</section>
