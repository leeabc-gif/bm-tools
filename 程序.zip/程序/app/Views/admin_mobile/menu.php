<?php
$groups = [
    [
        'title' => '日常运营',
        'items' => [
            ['url' => 'admin/m/dashboard', 'icon' => 'layout-dashboard', 'label' => '运营首页', 'desc' => '待处理事项和关键数据', 'value' => isset($stats['orders_pending']) ? $stats['orders_pending'] : 0],
            ['url' => 'admin/m/users', 'icon' => 'users', 'label' => '用户管理', 'desc' => '新增用户、调整套餐和状态', 'value' => isset($stats['users']) ? $stats['users'] : 0],
            ['url' => 'admin/m/packages', 'icon' => 'badge-dollar-sign', 'label' => '套餐权益', 'desc' => '价格、空间、功能权限', 'value' => null],
            ['url' => 'admin/m/coupons', 'icon' => 'percent', 'label' => '营销活动', 'desc' => '优惠码、折扣和使用记录', 'value' => null],
            ['url' => 'admin/m/orders', 'icon' => 'receipt-text', 'label' => '订单充值', 'desc' => '补单、充值审核、支付状态', 'value' => isset($stats['recharges_pending']) ? $stats['recharges_pending'] : 0],
            ['url' => 'admin/m/payments', 'icon' => 'credit-card', 'label' => '支付配置', 'desc' => '收款通道、人工充值和回调参数', 'value' => null],
            ['url' => 'admin/m/cards', 'icon' => 'ticket', 'label' => '卡密管理', 'desc' => '生成、停用、删除卡密', 'value' => null],
        ],
    ],
    [
        'title' => '资源能力',
        'items' => [
            ['url' => 'admin/m/files', 'icon' => 'files', 'label' => '文件管理', 'desc' => '查看和删除异常文件记录', 'value' => isset($stats['files']) ? $stats['files'] : 0],
            ['url' => 'admin/m/storages', 'icon' => 'database', 'label' => '存储状态', 'desc' => '测试线路、默认源和启停', 'value' => null],
            ['url' => 'admin/m/storage-backups', 'icon' => 'database-backup', 'label' => '存储备份', 'desc' => '多厂商备份策略和失败重试', 'value' => isset($stats['backup_failed']) ? $stats['backup_failed'] : 0],
            ['url' => 'admin/m/repositories', 'icon' => 'library', 'label' => '分享仓库', 'desc' => '审核、下架、删除仓库', 'value' => null],
            ['url' => 'admin/m/subsites', 'icon' => 'globe-2', 'label' => '分站管理', 'desc' => '审核分站、检测域名接入', 'value' => isset($stats['subsites_pending']) ? $stats['subsites_pending'] : 0],
            ['url' => 'admin/m/servers', 'icon' => 'activity', 'label' => '服务器监控', 'desc' => '采集、启停、查看异常', 'value' => isset($stats['offline_servers']) ? $stats['offline_servers'] : 0],
        ],
    ],
    [
        'title' => '系统维护',
        'items' => [
            ['url' => 'admin/m/settings', 'icon' => 'settings', 'label' => '系统设置', 'desc' => '站点、安全、上传、主题配置', 'value' => null],
            ['url' => 'admin/m/upload-limits', 'icon' => 'gauge', 'label' => '上传限制', 'desc' => '并发、批量、每日数量', 'value' => null],
            ['url' => 'admin/m/announcements', 'icon' => 'megaphone', 'label' => '公告管理', 'desc' => '发布、置顶、首页展示', 'value' => null],
            ['url' => 'admin/m/incidents', 'icon' => 'shield-alert', 'label' => '异常事件', 'desc' => 'API、备份和命令异常', 'value' => null],
            ['url' => 'admin/m/logs', 'icon' => 'file-search', 'label' => '审计日志', 'desc' => '管理员、API、余额、命令', 'value' => null],
            ['url' => 'admin/m/schema-audit', 'icon' => 'database-zap', 'label' => '数据库巡检', 'desc' => '缺失表、字段、SQL、权限诊断', 'value' => null],
            ['url' => 'admin/m/settings', 'icon' => 'palette', 'label' => '主题设置', 'desc' => '后台主题、前台主题、首页风格', 'value' => null],
        ],
    ],
];
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>Menu</span>
            <h1>功能中心</h1>
            <p>手机后台独立入口，常用操作都在这里，底部导航和右上角按钮都能进入。</p>
        </div>
        <a class="m-pill" href="<?= url('admin/m') ?>">首页</a>
    </header>

    <label class="m-list-search">
        <i data-lucide="search"></i>
        <input type="search" placeholder="搜索后台功能、说明或模块" data-mobile-filter-input="#adminMobileFunctionCenter">
        <span data-mobile-filter-count>0</span>
    </label>

    <div id="adminMobileFunctionCenter">
    <?php foreach ($groups as $group): ?>
        <section class="m-card" data-mobile-filter-group>
            <div class="m-section-head">
                <div><span>Admin</span><h2><?= e($group['title']) ?></h2></div>
            </div>
            <div class="m-feature-list">
                <?php foreach ($group['items'] as $item): ?>
                    <a href="<?= url($item['url']) ?>" data-mobile-filter-item>
                        <i data-lucide="<?= e($item['icon']) ?>"></i>
                        <span>
                            <strong><?= e($item['label']) ?></strong>
                            <small><?= e($item['desc']) ?></small>
                        </span>
                        <?php if ($item['value'] !== null): ?>
                            <b><?= e($item['value']) ?></b>
                        <?php else: ?>
                            <em data-lucide="chevron-right"></em>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
        <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的后台功能。</div>
    </div>
</section>
