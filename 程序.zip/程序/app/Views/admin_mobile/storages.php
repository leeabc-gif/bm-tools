<?php
$testResult = isset($testResult) ? $testResult : null;
$editStorage = isset($editStorage) && $editStorage ? $editStorage : null;
$storageTypes = [
    'local' => '本地存储',
    'oss' => '阿里云 OSS',
    'cos' => '腾讯云 COS',
    'kodo' => '七牛云 Kodo',
    's3' => 'S3 兼容',
    'minio' => 'MinIO 私有云',
    'r2' => 'Cloudflare R2',
    'webdav' => 'WebDAV',
    'bmtools' => '同系统对接',
];
$regionOptions = [
    '' => '自动识别 / 手动 Endpoint',
    'z0' => '七牛华东 z0',
    'cn-east-2' => '七牛华东浙江2',
    'z1' => '七牛华北 z1',
    'z2' => '七牛华南 z2',
    'na0' => '七牛北美 na0',
    'as0' => '七牛亚太新加坡 as0',
    'ap-southeast-2' => '七牛亚太河内',
    'ap-southeast-3' => '七牛亚太胡志明',
];
$typeLabel = function ($type) use ($storageTypes) {
    return isset($storageTypes[$type]) ? $storageTypes[$type] : strtoupper((string) $type);
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Storage</span><h1>存储配置</h1><p>新增、编辑、测试和启停第三方存储源，配置后请立即执行真实测试。</p></div>
        <a class="m-pill" href="<?= url('admin/m/storage-backups') ?>">备份</a>
    </header>
    <section class="m-stat-grid two">
        <article><span>存储驱动</span><strong><?= e(count($storages)) ?></strong></article>
        <article><span>失败备份</span><strong><?= e($failedBackups) ?></strong></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="存储配置分区">
        <a href="#storageForm"><?= $editStorage ? '编辑存储' : '新增存储' ?></a>
        <a href="#storageList">存储列表</a>
        <a href="<?= url('admin/m/storage-backups') ?>">备份策略</a>
    </nav>

    <?php if ($testResult): ?>
        <section class="m-card">
            <div class="m-section-head">
                <div><span>Test Result</span><h2>最近一次存储测试</h2></div>
                <?php if (!empty($testResult['docs_url'])): ?><a href="<?= e($testResult['docs_url']) ?>" target="_blank">文档</a><?php endif; ?>
            </div>
            <div class="m-note"><?= e(isset($testResult['message']) ? $testResult['message'] : '测试已执行。') ?></div>
            <?php if (empty($testResult['success'])): ?>
                <div class="m-alert danger">
                    <strong>不通步骤：<?= e(isset($testResult['failed_stage_label']) ? $testResult['failed_stage_label'] : (isset($testResult['failed_stage']) ? $testResult['failed_stage'] : '未知')) ?></strong>
                    <?php if (!empty($testResult['failed_stage_hint'])): ?><span><?= e($testResult['failed_stage_hint']) ?></span><?php endif; ?>
                    <?php if (!empty($testResult['technical_message'])): ?><code><?= e($testResult['technical_message']) ?></code><?php endif; ?>
                    <?php if (!empty($testResult['repair_url'])): ?><a href="<?= e($testResult['repair_url']) ?>">进入修复页面</a><?php endif; ?>
                </div>
            <?php elseif (!empty($testResult['next_action'])): ?>
                <div class="m-alert ok">
                    <strong>测试通过</strong>
                    <span><?= e($testResult['next_action']) ?></span>
                </div>
            <?php endif; ?>
            <?php if (!empty($testResult['checks']) && is_array($testResult['checks'])): ?>
                <div class="m-status-row m-storage-test-steps">
                    <?php foreach ($testResult['checks'] as $check): ?>
                        <article class="m-check-card <?= e(isset($check['status']) ? $check['status'] : 'soft') ?>">
                            <b><?= e(isset($check['label']) ? $check['label'] : '检测项') ?></b>
                            <span><?= e(isset($check['message']) ? $check['message'] : '') ?></span>
                            <?php if (!empty($check['hint'])): ?><small><?= e($check['hint']) ?></small><?php endif; ?>
                            <?php if (!empty($check['technical_message'])): ?><code><?= e($check['technical_message']) ?></code><?php endif; ?>
                            <?php if (!empty($check['url'])): ?><a href="<?= e($check['url']) ?>" target="_blank">测试链接</a><?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <details class="m-fold" id="storageForm" <?= $editStorage ? 'open' : '' ?>>
        <summary><?= $editStorage ? '编辑存储源' : '新增存储源' ?></summary>
        <form class="m-mini-form m-storage-form" method="post" action="<?= url('admin/m/storages/save') ?>">
            <?= csrf_field() ?>
            <?php if ($editStorage): ?><input type="hidden" name="id" value="<?= e($editStorage['id']) ?>"><?php endif; ?>
            <input name="name" value="<?= e($editStorage ? $editStorage['name'] : old('name')) ?>" required maxlength="120" placeholder="存储名称，例如：七牛华东主线路">
            <div class="m-status-row">
                <select name="type" data-m-storage-type>
                    <?php foreach ($storageTypes as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= ($editStorage ? $editStorage['type'] : old('type', 'local')) === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="is_enabled">
                    <option value="1" <?= !$editStorage || !empty($editStorage['is_enabled']) ? 'selected' : '' ?>>启用</option>
                    <option value="0" <?= $editStorage && empty($editStorage['is_enabled']) ? 'selected' : '' ?>>停用</option>
                </select>
            </div>

            <div class="m-storage-fields" data-m-storage-cloud>
                <input name="access_key" value="<?= e($editStorage ? $editStorage['access_key'] : old('access_key')) ?>" autocomplete="off" placeholder="AccessKey / SecretId / WebDAV 用户名">
                <input name="secret_key" type="password" value="" autocomplete="new-password" placeholder="<?= $editStorage ? '密钥已保存，留空不修改' : 'SecretKey / Token / WebDAV 密码' ?>">
                <input name="bucket" value="<?= e($editStorage ? $editStorage['bucket'] : old('bucket')) ?>" placeholder="Bucket / 远程目录">
            </div>

            <div class="m-storage-fields" data-m-storage-region>
                <select name="region" data-m-storage-region-select>
                    <?php foreach ($regionOptions as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= ($editStorage ? $editStorage['region'] : old('region')) === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <input name="endpoint" value="<?= e($editStorage ? $editStorage['endpoint'] : old('endpoint')) ?>" placeholder="Endpoint / 上传域名 / 远端站点地址">
            </div>

            <input name="domain" value="<?= e($editStorage ? $editStorage['domain'] : old('domain')) ?>" placeholder="公开访问域名，例如 https://cdn.example.com" data-m-storage-domain>
            <input name="prefix" value="<?= e($editStorage ? $editStorage['prefix'] : old('prefix')) ?>" placeholder="目录前缀，例如 uploads/files">
            <label class="m-checkline"><input type="checkbox" name="is_default" <?= $editStorage && !empty($editStorage['is_default']) ? 'checked' : '' ?>> 设为默认存储</label>
            <label class="m-checkline"><input type="checkbox" name="is_public" <?= !$editStorage || !empty($editStorage['is_public']) ? 'checked' : '' ?>> 文件外链公开访问</label>
            <div class="m-note" data-m-storage-help>本地存储只需要名称和目录前缀。云存储请填写 Key、Bucket、Endpoint/Region 和访问域名。</div>
            <button type="submit"><?= $editStorage ? '保存修改' : '新增存储源' ?></button>
            <?php if ($editStorage): ?><a class="m-button ghost" href="<?= url('admin/m/storages') ?>">取消编辑</a><?php endif; ?>
        </form>
    </details>

    <section class="m-card" id="storageList">
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索存储名称、类型、域名或 Bucket" data-mobile-filter-input="#adminMobileStoragesList">
        </label>
        <div class="m-list" id="adminMobileStoragesList">
            <?php foreach ($storages as $storage): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="database"></i>
                    <div>
                        <strong><?= e($storage['name']) ?><?= !empty($storage['is_default']) ? ' · 默认' : '' ?></strong>
                        <span><?= e($typeLabel($storage['type'])) ?> · <?= !empty($storage['is_enabled']) ? '启用' : '停用' ?></span>
                    </div>
                    <span class="m-badge <?= !empty($storage['is_enabled']) ? 'ok' : 'bad' ?>"><?= !empty($storage['is_enabled']) ? '启用' : '停用' ?></span>
                    <div class="m-meta-grid">
                        <?php if (!empty($storage['is_default'])): ?><span class="m-badge ok">默认</span><?php endif; ?>
                        <?php if (!empty($storage['bucket'])): ?><span class="m-badge muted"><?= e($storage['bucket']) ?></span><?php endif; ?>
                        <?php if (!empty($storage['region'])): ?><span class="m-badge muted"><?= e($storage['region']) ?></span><?php endif; ?>
                    </div>
                    <div class="m-note">
                        <?= e($storage['domain'] ?: ($storage['endpoint'] ?: '本地或未配置访问域名')) ?>
                    </div>
                    <div class="m-inline-actions">
                        <a class="m-button ghost" href="<?= url('admin/m/storages?id=' . (int) $storage['id']) ?>">编辑</a>
                        <form method="post" action="<?= url('admin/m/storages/test') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($storage['id']) ?>">
                            <button class="m-button ghost" type="submit">测试</button>
                        </form>
                        <?php if (empty($storage['is_default'])): ?>
                            <form method="post" action="<?= url('admin/m/storages/default') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($storage['id']) ?>">
                                <button class="m-button ghost" type="submit">设为默认</button>
                            </form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('admin/m/storages/toggle') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($storage['id']) ?>">
                            <button class="m-button <?= !empty($storage['is_enabled']) ? 'danger' : 'ghost' ?>" type="submit" data-mobile-confirm="<?= !empty($storage['is_enabled']) ? '确认停用这个存储源吗？' : '确认启用这个存储源吗？' ?>"><?= !empty($storage['is_enabled']) ? '停用' : '启用' ?></button>
                        </form>
                        <?php if (empty($storage['is_default'])): ?>
                            <form method="post" action="<?= url('admin/m/storages/delete') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($storage['id']) ?>">
                                <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个存储源吗？已有文件使用时会被系统阻止。">删除</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的存储源。</div>
            <?php if (!$storages): ?><div class="m-empty">暂无存储配置。</div><?php endif; ?>
        </div>
    </section>
</section>
