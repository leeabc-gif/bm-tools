<?php
$packages = isset($packages) ? $packages : [];
$packageName = function ($id) use ($packages) {
    foreach ($packages as $package) {
        if ((int) $package['id'] === (int) $id) {
            return $package['name'];
        }
    }
    return '无套餐';
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Users</span><h1>用户管理</h1><p>手机端可新增用户、调整余额、套餐、角色和状态，日常运营直接在这里处理。</p></div>
        <a class="m-pill" href="<?= url('admin/m/orders') ?>">订单</a>
    </header>
    <section class="m-stat-grid three">
        <article><span>总用户</span><strong><?= e($stats['total']) ?></strong></article>
        <article><span>今日新增</span><strong><?= e($stats['today']) ?></strong></article>
        <article><span>禁用</span><strong><?= e($stats['disabled']) ?></strong></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="用户管理分区">
        <a href="#adminUserCreate">新增用户</a>
        <a href="#adminUserList">最近用户</a>
        <a href="<?= url('admin/m/orders') ?>">订单充值</a>
    </nav>

    <details class="m-fold" id="adminUserCreate">
        <summary>新增用户</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/users/create') ?>">
            <?= csrf_field() ?>
            <input name="username" value="<?= e(old('username')) ?>" maxlength="32" required placeholder="用户名">
            <input name="nickname" value="<?= e(old('nickname')) ?>" maxlength="64" placeholder="昵称，可留空">
            <input name="email" value="<?= e(old('email')) ?>" type="email" maxlength="120" required placeholder="邮箱">
            <input name="password" type="password" minlength="6" required placeholder="初始密码">
            <select name="package_id">
                <option value="0">不绑定套餐</option>
                <?php foreach ($packages as $package): ?>
                    <option value="<?= e($package['id']) ?>"><?= e($package['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="role">
                <option value="user">普通用户</option>
                <option value="admin">管理员</option>
            </select>
            <select name="status">
                <option value="1">启用</option>
                <option value="0">禁用</option>
            </select>
            <input name="balance" type="number" step="0.01" min="-999999" value="<?= e(old('balance', '0')) ?>" placeholder="初始余额">
            <label class="m-checkline"><input type="checkbox" name="email_verified" checked> 邮箱标记为已验证</label>
            <button type="submit">创建用户</button>
        </form>
    </details>

    <section class="m-card" id="adminUserList">
        <div class="m-section-head"><div><span>List</span><h2>最近用户</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索用户名、邮箱、套餐或角色" data-mobile-filter-input="#adminMobileUsersList">
        </label>
        <div class="m-list" id="adminMobileUsersList">
            <?php foreach ($users as $user): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="user"></i>
                    <div>
                        <strong><?= e($user['nickname'] ?: $user['username']) ?></strong>
                        <span><?= e($user['email']) ?> · <?= e($user['role']) ?> · <?= e($user['package_name'] ?: '无套餐') ?></span>
                    </div>
                    <span class="m-badge <?= !empty($user['status']) ? 'ok' : 'bad' ?>"><?= !empty($user['status']) ? '启用' : '禁用' ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">余额 <?= e(number_format((float) $user['balance'], 2)) ?></span>
                        <span class="m-badge muted">空间 <?= e(format_bytes(isset($user['total_storage']) ? $user['total_storage'] : 0)) ?></span>
                        <span class="m-badge muted">注册 <?= e(isset($user['created_at']) ? $user['created_at'] : '-') ?></span>
                    </div>
                    <div class="m-inline-actions">
                        <details class="m-fold">
                            <summary>调整用户</summary>
                            <form class="m-mini-form" method="post" action="<?= url('admin/m/users/update') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($user['id']) ?>">
                                <select name="package_id" aria-label="套餐">
                                    <option value="0">不绑定套餐</option>
                                    <?php foreach ($packages as $package): ?>
                                        <option value="<?= e($package['id']) ?>" <?= (int) $user['package_id'] === (int) $package['id'] ? 'selected' : '' ?>><?= e($package['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="role" aria-label="角色">
                                    <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>普通用户</option>
                                    <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>管理员</option>
                                </select>
                                <select name="status" aria-label="状态">
                                    <option value="1" <?= (int) $user['status'] === 1 ? 'selected' : '' ?>>启用</option>
                                    <option value="0" <?= (int) $user['status'] === 0 ? 'selected' : '' ?>>禁用</option>
                                </select>
                                <input name="balance" type="number" step="0.01" value="<?= e($user['balance']) ?>" placeholder="余额">
                                <input name="password" type="password" minlength="6" placeholder="新密码，留空不改">
                                <button class="ghost" type="submit">保存调整</button>
                            </form>
                        </details>
                        <button class="m-button ghost" type="button" data-copy-text="<?= e($user['email']) ?>">复制邮箱</button>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的用户。</div>
            <?php if (!$users): ?><div class="m-empty">暂无用户。</div><?php endif; ?>
        </div>
    </section>
</section>
