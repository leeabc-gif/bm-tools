<?php
$cards = isset($cards) ? $cards : [];
$packages = isset($packages) ? $packages : [];
$generatedCards = isset($generatedCards) ? $generatedCards : null;
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Cards</span><h1>卡密管理</h1><p>手机端可生成余额卡、套餐卡，并停用或删除未兑换卡密。</p></div>
        <a class="m-pill" href="<?= url('admin/m/packages') ?>">套餐</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>总卡密</span><strong><?= e($stats['total']) ?></strong><small>未用 <?= e($stats['unused']) ?></small></article>
        <article><span>已兑换</span><strong><?= e($stats['used']) ?></strong><small>停用 <?= e($stats['disabled']) ?></small></article>
    </section>

    <?php if ($generatedCards && !empty($generatedCards['codes'])): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Generated</span><h2>本次生成卡密</h2></div></div>
            <div class="m-note">明文只在本次页面展示，请立即复制保存。批次：<?= e($generatedCards['batch_no']) ?></div>
            <div class="m-list">
                <?php foreach ($generatedCards['codes'] as $code): ?>
                    <article class="m-list-item">
                        <i data-lucide="ticket"></i>
                        <div><strong><?= e($code) ?></strong><span><?= e($generatedCards['title']) ?></span></div>
                        <button class="m-button ghost" type="button" data-copy-text="<?= e($code) ?>">复制</button>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <details class="m-fold">
        <summary>生成卡密</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/cards/generate') ?>">
            <?= csrf_field() ?>
            <select name="type">
                <option value="balance">余额卡</option>
                <option value="package">套餐卡</option>
            </select>
            <input name="title" value="<?= e(old('title')) ?>" maxlength="120" placeholder="卡密标题">
            <input name="amount" type="number" step="0.01" min="0" value="<?= e(old('amount', '10')) ?>" placeholder="余额金额">
            <select name="package_id">
                <option value="0">套餐卡选择套餐</option>
                <?php foreach ($packages as $package): ?><option value="<?= e($package['id']) ?>"><?= e($package['name']) ?></option><?php endforeach; ?>
            </select>
            <input name="duration_days" type="number" min="0" value="<?= e(old('duration_days', '0')) ?>" placeholder="套餐卡有效天数，0 跟随套餐">
            <input name="count" type="number" min="1" max="200" value="<?= e(old('count', '1')) ?>" placeholder="生成数量">
            <input name="prefix" maxlength="8" value="<?= e(old('prefix', 'BM')) ?>" placeholder="前缀">
            <input name="channel" maxlength="80" value="<?= e(old('channel')) ?>" placeholder="渠道备注">
            <input name="expire_at" type="datetime-local" value="<?= e(old('expire_at')) ?>" placeholder="过期时间">
            <textarea name="remark" maxlength="255" placeholder="内部备注"><?= e(old('remark')) ?></textarea>
            <button type="submit">生成卡密</button>
        </form>
    </details>

    <section class="m-card">
        <div class="m-section-head"><div><span>List</span><h2>最近卡密</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索标题、批次、尾号、类型或状态" data-mobile-filter-input="#adminMobileCardsList">
        </label>
        <div class="m-list" id="adminMobileCardsList">
            <?php foreach ($cards as $card): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="ticket"></i>
                    <div>
                        <strong><?= e($card['title']) ?></strong>
                        <span><?= e($card['code_preview']) ?> · <?= e($card['type']) ?> · <?= e($card['status']) ?></span>
                    </div>
                    <span class="m-badge <?= $card['status'] === 'unused' ? 'ok' : ($card['status'] === 'used' ? 'warn' : 'bad') ?>"><?= e($card['status']) ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= $card['type'] === 'balance' ? '¥' . e(number_format((float) $card['amount'], 2)) : e($card['package_name'] ?: '套餐') ?></span>
                        <span class="m-badge muted">批次 <?= e($card['batch_no']) ?></span>
                        <?php if (!empty($card['username'])): ?><span class="m-badge muted">用户 <?= e($card['username']) ?></span><?php endif; ?>
                    </div>
                    <?php if ($card['status'] !== 'used'): ?>
                        <div class="m-inline-actions">
                            <form method="post" action="<?= url('admin/m/cards/status') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($card['id']) ?>">
                                <button class="m-button ghost" name="action" value="<?= $card['status'] === 'disabled' ? 'restore' : 'disable' ?>" type="submit"><?= $card['status'] === 'disabled' ? '恢复' : '停用' ?></button>
                            </form>
                            <form method="post" action="<?= url('admin/m/cards/delete') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($card['id']) ?>">
                                <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这张未兑换卡密吗？">删除</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的卡密。</div>
            <?php if (!$cards): ?><div class="m-empty">暂无卡密。</div><?php endif; ?>
        </div>
    </section>
</section>
