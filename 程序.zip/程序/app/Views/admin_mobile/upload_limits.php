<?php
$limits = isset($limits) ? $limits : ['concurrency' => 2, 'imageBatch' => 20, 'fileBatch' => 10, 'imageDaily' => 0, 'fileDaily' => 0];
$serverUploadLimits = isset($serverUploadLimits) ? $serverUploadLimits : [];
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Upload</span><h1>上传限制</h1><p>控制用户批量上传、并发处理和每日上传数量，减少服务器压力。</p></div>
        <a class="m-pill" href="<?= url('admin/m/settings') ?>">系统</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>并发</span><strong><?= e($limits['concurrency']) ?></strong><small>每用户同时处理</small></article>
        <article><span>PHP 限制</span><strong><?= e(isset($serverUploadLimits['upload_max_filesize']) ? $serverUploadLimits['upload_max_filesize'] : '-') ?></strong><small>upload_max_filesize</small></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Rules</span><h2>上传规则</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/upload-limits') ?>">
            <?= csrf_field() ?>
            <input name="upload_max_concurrency" type="number" min="1" max="8" value="<?= e($limits['concurrency']) ?>" placeholder="每用户并发上传数">
            <input name="upload_image_batch_limit" type="number" min="1" max="500" value="<?= e($limits['imageBatch']) ?>" placeholder="图片单次批量数量">
            <input name="upload_file_batch_limit" type="number" min="1" max="300" value="<?= e($limits['fileBatch']) ?>" placeholder="文件单次批量数量">
            <input name="upload_image_daily_limit" type="number" min="0" max="1000000" value="<?= e($limits['imageDaily']) ?>" placeholder="图片每日数量，0 不限">
            <input name="upload_file_daily_limit" type="number" min="0" max="1000000" value="<?= e($limits['fileDaily']) ?>" placeholder="文件每日数量，0 不限">
            <button type="submit">保存上传限制</button>
        </form>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Runtime</span><h2>服务器上传参数</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索 php.ini 参数或当前值" data-mobile-filter-input="#adminMobileUploadRuntimeList">
            <span data-mobile-filter-count>0</span>
        </label>
        <div class="m-list" id="adminMobileUploadRuntimeList">
            <?php foreach ($serverUploadLimits as $key => $value): ?>
                <article class="m-list-item" data-mobile-filter-item>
                    <i data-lucide="server"></i>
                    <div><strong><?= e($key) ?></strong><span><?= e($value) ?></span></div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的上传参数。</div>
            <?php if (!$serverUploadLimits): ?><div class="m-empty">暂无服务器上传参数。</div><?php endif; ?>
        </div>
    </section>
</section>
