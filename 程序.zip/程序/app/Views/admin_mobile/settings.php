<?php
$schemaRepairResult = isset($schemaRepairResult) ? $schemaRepairResult : null;
$settings = isset($settings) && is_array($settings) ? $settings : [];
$packages = isset($packages) && is_array($packages) ? $packages : [];
$theme = isset($theme) && is_array($theme) ? $theme : ['admin' => 'anime', 'frontend' => 'anime', 'home' => 'default'];
$maintenanceOn = !empty($health['maintenance']);
$get = function ($key, $default = '') use ($settings) {
    return array_key_exists($key, $settings) ? $settings[$key] : $default;
};
$homeStyles = [
    'default' => '默认工具站风',
    'terminal' => '终端风',
    'technology' => '科技风',
    'anime' => '二次元轻柔风',
    'business' => '极简商务风',
    'blog' => '个人博客风',
];
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>System</span><h1>系统设置</h1><p>站点、注册、上传、API、邮件、主题与维护分区保存，手机端也能完成日常配置。</p></div>
        <a class="m-pill" href="<?= url('admin/m/schema-audit') ?>">巡检</a>
    </header>

    <section class="m-card">
        <div class="m-list">
            <article class="m-list-item">
                <i data-lucide="database-zap"></i>
                <div><strong>数据库结构</strong><span><?= $health['schema'] ? '已通过' : '需要巡检修复' ?></span></div>
                <span class="m-badge <?= $health['schema'] ? 'ok' : 'bad' ?>"><?= $health['schema'] ? 'OK' : '待修复' ?></span>
            </article>
            <article class="m-list-item"><i data-lucide="code-2"></i><div><strong>PHP 版本</strong><span><?= e($health['php']) ?></span></div></article>
            <article class="m-list-item"><i data-lucide="upload-cloud"></i><div><strong>上传限制</strong><span><?= e($health['upload']) ?></span></div></article>
            <article class="m-list-item"><i data-lucide="clock"></i><div><strong>服务器时间</strong><span><?= e($health['time']) ?></span></div></article>
            <article class="m-list-item">
                <i data-lucide="traffic-cone"></i>
                <div><strong>维护模式</strong><span><?= $maintenanceOn ? '前台访问显示维护页' : '前台正常访问' ?></span></div>
                <span class="m-badge <?= $maintenanceOn ? 'warn' : 'ok' ?>"><?= $maintenanceOn ? '开启' : '关闭' ?></span>
            </article>
        </div>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="系统设置分区">
        <a href="#settingSite">站点</a>
        <a href="#settingSecurity">安全</a>
        <a href="#settingUpload">上传</a>
        <a href="#settingApiEmail">API/邮件</a>
        <a href="#settingNotify">告警</a>
        <a href="#settingTheme">主题</a>
        <a href="#settingMaintenance">维护</a>
    </nav>

    <?php if ($schemaRepairResult): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Repair</span><h2>数据库修复结果</h2></div></div>
            <div class="m-status-row">
                <article class="m-check-card <?= !empty($schemaRepairResult['ok']) ? 'ok' : 'bad' ?>">
                    <b>总体状态</b>
                    <span><?= !empty($schemaRepairResult['ok']) ? '已完成' : '仍有未完成项目' ?></span>
                </article>
                <article class="m-check-card soft">
                    <b>成功 / 失败</b>
                    <span><?= e((int) (isset($schemaRepairResult['success_count']) ? $schemaRepairResult['success_count'] : 0)) ?> / <?= e((int) (isset($schemaRepairResult['fail_count']) ? $schemaRepairResult['fail_count'] : 0)) ?></span>
                </article>
            </div>
            <?php if (empty($schemaRepairResult['ok'])): ?>
                <div class="m-note">如果仍有未完成项目，通常是数据库账号缺少 CREATE / ALTER / INDEX 权限。请进入移动数据库巡检查看待执行 SQL 和权限探针。</div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <details class="m-fold" id="settingSite" open>
        <summary>站点信息</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/site') ?>">
            <?= csrf_field() ?>
            <input name="site_name" value="<?= e($get('site_name', app_brand_name())) ?>" placeholder="网站名称">
            <input name="site_public_url" value="<?= e($get('site_public_url')) ?>" placeholder="网站主域名，例如 https://www.example.com">
            <input name="site_logo" value="<?= e($get('site_logo')) ?>" placeholder="Logo URL">
            <input name="seo_keywords" value="<?= e($get('seo_keywords')) ?>" placeholder="SEO 关键词">
            <textarea name="seo_description" rows="3" placeholder="SEO 描述"><?= e($get('seo_description')) ?></textarea>
            <select name="file_naming_strategy">
                <?php foreach (['random' => '随机字符串', 'timestamp' => '时间戳', 'hash' => '文件 Hash', 'original' => '原始文件名'] as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $get('file_naming_strategy', 'random') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="default_free_package_id">
                <option value="0">不指定默认套餐</option>
                <?php foreach ($packages as $package): ?>
                    <option value="<?= e($package['id']) ?>" <?= (int) $get('default_free_package_id', 0) === (int) $package['id'] ? 'selected' : '' ?>><?= e($package['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="default_theme">
                <?php foreach (['auto' => '自动跟随昼夜', 'light' => '浅色', 'dark' => '深色'] as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $get('default_theme', 'auto') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">保存站点信息</button>
        </form>
    </details>

    <details class="m-fold" id="settingSecurity">
        <summary>注册与安全</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/security') ?>">
            <?= csrf_field() ?>
            <div class="m-status-row">
                <select name="register_enabled">
                    <option value="1" <?= $get('register_enabled', '1') === '1' ? 'selected' : '' ?>>允许注册</option>
                    <option value="0" <?= $get('register_enabled', '1') === '0' ? 'selected' : '' ?>>关闭注册</option>
                </select>
                <select name="register_email_code_enabled">
                    <option value="0" <?= $get('register_email_code_enabled', '0') === '0' ? 'selected' : '' ?>>邮箱验证码关闭</option>
                    <option value="1" <?= $get('register_email_code_enabled', '0') === '1' ? 'selected' : '' ?>>邮箱验证码开启</option>
                </select>
            </div>
            <input type="number" name="security_login_max_attempts" min="1" value="<?= e($get('security_login_max_attempts', '5')) ?>" placeholder="登录失败上限">
            <input type="number" name="security_login_window_minutes" min="1" value="<?= e($get('security_login_window_minutes', '10')) ?>" placeholder="登录统计窗口，分钟">
            <input type="number" name="security_login_lock_minutes" min="1" value="<?= e($get('security_login_lock_minutes', '15')) ?>" placeholder="登录锁定时长，分钟">
            <input type="number" name="security_email_code_max_per_hour" min="1" value="<?= e($get('security_email_code_max_per_hour', '5')) ?>" placeholder="每邮箱每小时验证码">
            <input type="number" name="security_email_code_ip_max_per_hour" min="1" value="<?= e($get('security_email_code_ip_max_per_hour', '20')) ?>" placeholder="每 IP 每小时验证码">
            <button type="submit">保存安全设置</button>
        </form>
    </details>

    <details class="m-fold" id="settingUpload">
        <summary>上传权限</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/upload') ?>">
            <?= csrf_field() ?>
            <div class="m-status-row">
                <select name="user_image_upload_enabled">
                    <option value="1" <?= $get('user_image_upload_enabled', '1') === '1' ? 'selected' : '' ?>>会员图床开启</option>
                    <option value="0" <?= $get('user_image_upload_enabled', '1') === '0' ? 'selected' : '' ?>>会员图床关闭</option>
                </select>
                <select name="user_netdisk_enabled">
                    <option value="1" <?= $get('user_netdisk_enabled', '1') === '1' ? 'selected' : '' ?>>会员网盘开启</option>
                    <option value="0" <?= $get('user_netdisk_enabled', '1') === '0' ? 'selected' : '' ?>>会员网盘关闭</option>
                </select>
            </div>
            <select name="guest_image_upload_enabled">
                <option value="0" <?= $get('guest_image_upload_enabled', '0') === '0' ? 'selected' : '' ?>>游客图床关闭</option>
                <option value="1" <?= $get('guest_image_upload_enabled', '0') === '1' ? 'selected' : '' ?>>游客图床开启</option>
            </select>
            <input type="number" name="guest_image_upload_user_id" min="0" value="<?= e($get('guest_image_upload_user_id', '0')) ?>" placeholder="游客上传归属用户 ID">
            <input type="number" name="guest_image_upload_max_size" min="1" value="<?= e($get('guest_image_upload_max_size', '5242880')) ?>" placeholder="游客单图大小，字节">
            <input type="number" name="guest_image_upload_daily_ip_limit" min="0" value="<?= e($get('guest_image_upload_daily_ip_limit', '20')) ?>" placeholder="游客每日/IP 上传数">
            <button type="submit">保存上传权限</button>
        </form>
    </details>

    <details class="m-fold" id="settingApiEmail">
        <summary>API 与邮件</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/api') ?>">
            <?= csrf_field() ?>
            <div class="m-status-row">
                <input type="number" name="api_rate_limit_per_minute" min="1" value="<?= e($get('api_rate_limit_per_minute', '60')) ?>" placeholder="API 每分钟限制">
                <input type="number" name="api_rate_limit_per_day" min="1" value="<?= e($get('api_rate_limit_per_day', '1000')) ?>" placeholder="API 每日限制">
            </div>
            <button type="submit">保存 API 限制</button>
        </form>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/email') ?>">
            <?= csrf_field() ?>
            <input name="email_host" value="<?= e($get('email_host')) ?>" placeholder="SMTP Host">
            <div class="m-status-row">
                <input type="number" name="email_port" min="1" value="<?= e($get('email_port', '465')) ?>" placeholder="端口">
                <input name="email_username" value="<?= e($get('email_username')) ?>" placeholder="邮件账号">
            </div>
            <input type="password" name="email_password" value="" autocomplete="new-password" placeholder="<?= $get('email_password') !== '' ? '已保存，留空不修改' : 'SMTP 授权码或密码' ?>">
            <input name="email_from" value="<?= e($get('email_from')) ?>" placeholder="发件邮箱">
            <button class="ghost" type="submit">保存邮件服务</button>
        </form>
    </details>

    <details class="m-fold" id="settingNotify">
        <summary>告警通知</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/notify') ?>">
            <?= csrf_field() ?>
            <select name="alert_webhook_enabled">
                <option value="0" <?= $get('alert_webhook_enabled', '0') === '0' ? 'selected' : '' ?>>告警外送关闭</option>
                <option value="1" <?= $get('alert_webhook_enabled', '0') === '1' ? 'selected' : '' ?>>告警外送开启</option>
            </select>
            <input name="alert_wecom_webhook" value="" placeholder="<?= $get('alert_wecom_webhook') !== '' ? '企业微信 Webhook 已保存，留空不修改' : '企业微信 Webhook' ?>">
            <input name="alert_dingtalk_webhook" value="" placeholder="<?= $get('alert_dingtalk_webhook') !== '' ? '钉钉 Webhook 已保存，留空不修改' : '钉钉 Webhook' ?>">
            <input type="password" name="alert_dingtalk_secret" value="" autocomplete="new-password" placeholder="<?= $get('alert_dingtalk_secret') !== '' ? '钉钉 Secret 已保存，留空不修改' : '钉钉加签 Secret，可留空' ?>">
            <input type="password" name="alert_telegram_bot_token" value="" autocomplete="new-password" placeholder="<?= $get('alert_telegram_bot_token') !== '' ? 'Telegram Token 已保存，留空不修改' : 'Telegram Bot Token' ?>">
            <input name="alert_telegram_chat_id" value="<?= e($get('alert_telegram_chat_id')) ?>" placeholder="Telegram Chat ID">
            <div class="m-note">监控异常会先写入站内通知和邮件，再外送到已配置通道。失败会写入日志，不影响采集任务。</div>
            <button type="submit">保存告警通知</button>
        </form>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/notify/test') ?>">
            <?= csrf_field() ?>
            <select name="channel">
                <option value="wecom">测试企业微信</option>
                <option value="dingtalk">测试钉钉</option>
                <option value="telegram">测试 Telegram</option>
            </select>
            <button class="ghost" type="submit">发送测试告警</button>
        </form>
    </details>

    <details class="m-fold" id="settingTheme">
        <summary>主题与首页模板</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/settings/themes') ?>">
            <?= csrf_field() ?>
            <select name="admin_theme_style">
                <option value="anime" <?= $theme['admin'] === 'anime' ? 'selected' : '' ?>>现代浅色主题</option>
            </select>
            <select name="frontend_theme_style">
                <option value="anime" <?= $theme['frontend'] === 'anime' ? 'selected' : '' ?>>前台现代浅色主题</option>
            </select>
            <select name="frontend_home_style">
                <?php foreach ($homeStyles as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $theme['home'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">保存主题设置</button>
        </form>
    </details>

    <section class="m-card" id="settingMaintenance">
        <div class="m-section-head"><div><span>Maintenance</span><h2>维护与修复</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/maintenance/toggle') ?>">
            <?= csrf_field() ?>
            <label class="m-checkline"><input type="checkbox" name="site_maintenance" <?= $maintenanceOn ? 'checked' : '' ?>> 开启维护模式</label>
            <textarea name="maintenance_message" maxlength="500" placeholder="维护提示语"><?= e(isset($health['maintenance_message']) ? $health['maintenance_message'] : '') ?></textarea>
            <button type="submit"><?= $maintenanceOn ? '保存维护设置' : '保存设置' ?></button>
        </form>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/maintenance/repair-schema') ?>">
            <?= csrf_field() ?>
            <div class="m-note">页面提示缺少数据表或结构未准备完成时，可先执行一键修复。</div>
            <button class="ghost" type="submit" data-mobile-confirm="确认执行数据库结构一键修复吗？">一键修复数据库结构</button>
        </form>
    </section>

    <section class="m-card">
        <div class="m-action-list">
            <a href="<?= url('admin/m/schema-audit') ?>"><i data-lucide="database-zap"></i><span>数据库巡检详情</span></a>
            <a href="<?= url('admin/m/upload-limits') ?>"><i data-lucide="gauge"></i><span>上传限制</span></a>
            <a href="<?= url('admin/m/menu') ?>"><i data-lucide="grid-3x3"></i><span>全部功能</span></a>
        </div>
    </section>
</section>
