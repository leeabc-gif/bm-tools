<?php
$announcements = isset($announcements) ? $announcements : [];
$categories = isset($categories) ? $categories : [];
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Announcements</span><h1>公告管理</h1><p>手机端可发布公告、控制首页展示和置顶状态。</p></div>
        <a class="m-pill" href="<?= url('admin/m/settings') ?>">设置</a>
    </header>

    <section class="m-stat-grid three">
        <article><span>公告</span><strong><?= e($stats['total']) ?></strong></article>
        <article><span>可见</span><strong><?= e($stats['visible']) ?></strong></article>
        <article><span>首页</span><strong><?= e($stats['home']) ?></strong></article>
    </section>

    <details class="m-fold">
        <summary>发布公告</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/announcements/save') ?>">
            <?= csrf_field() ?>
            <input name="title" value="<?= e(old('title')) ?>" maxlength="150" required placeholder="公告标题">
            <select name="category">
                <?php foreach ($categories as $key => $item): ?>
                    <option value="<?= e($key) ?>"><?= e(isset($item['name']) ? $item['name'] : $key) ?></option>
                <?php endforeach; ?>
            </select>
            <input name="summary" value="<?= e(old('summary')) ?>" maxlength="300" placeholder="摘要">
            <textarea name="content" required placeholder="公告内容"><?= e(old('content')) ?></textarea>
            <input name="tags" value="<?= e(old('tags')) ?>" maxlength="255" placeholder="标签，逗号分隔">
            <input name="published_at" type="datetime-local" value="<?= e(old('published_at')) ?>">
            <select name="content_format"><option value="plain">纯文本</option><option value="html">HTML</option></select>
            <select name="status"><option value="1">发布</option><option value="0">草稿</option></select>
            <label class="m-checkline"><input type="checkbox" name="show_home" checked> 首页展示</label>
            <label class="m-checkline"><input type="checkbox" name="is_top"> 置顶</label>
            <button type="submit">保存公告</button>
        </form>
    </details>

    <section class="m-card">
        <div class="m-section-head"><div><span>List</span><h2>公告列表</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索标题、分类、摘要或状态" data-mobile-filter-input="#adminMobileAnnouncementsList">
        </label>
        <div class="m-list" id="adminMobileAnnouncementsList">
            <?php foreach ($announcements as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="megaphone"></i>
                    <div>
                        <strong><?= e($row['title']) ?></strong>
                        <span><?= e($row['category']) ?> · <?= !empty($row['published_at']) ? e($row['published_at']) : '未发布' ?></span>
                    </div>
                    <span class="m-badge <?= !empty($row['status']) ? 'ok' : 'muted' ?>"><?= !empty($row['status']) ? '发布' : '草稿' ?></span>
                    <div class="m-meta-grid">
                        <?php if (!empty($row['is_top'])): ?><span class="m-badge warn">置顶</span><?php endif; ?>
                        <?php if (!empty($row['show_home'])): ?><span class="m-badge ok">首页</span><?php endif; ?>
                        <span class="m-badge muted">浏览 <?= e((int) (isset($row['view_count']) ? $row['view_count'] : 0)) ?></span>
                    </div>
                    <?php if (!empty($row['summary'])): ?><div class="m-note"><?= e($row['summary']) ?></div><?php endif; ?>
                    <details class="m-fold">
                        <summary>编辑公告</summary>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/announcements/save') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($row['id']) ?>">
                            <input name="title" value="<?= e($row['title']) ?>" maxlength="150" required>
                            <select name="category">
                                <?php foreach ($categories as $key => $item): ?>
                                    <option value="<?= e($key) ?>" <?= $row['category'] === $key ? 'selected' : '' ?>><?= e(isset($item['name']) ? $item['name'] : $key) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input name="summary" value="<?= e(isset($row['summary']) ? $row['summary'] : '') ?>" maxlength="300">
                            <textarea name="content" required><?= e($row['content']) ?></textarea>
                            <input name="tags" value="<?= e(isset($row['tags']) ? $row['tags'] : '') ?>" maxlength="255">
                            <input name="published_at" value="<?= e($row['published_at']) ?>" placeholder="发布时间">
                            <select name="content_format"><option value="plain" <?= $row['content_format'] === 'plain' ? 'selected' : '' ?>>纯文本</option><option value="html" <?= $row['content_format'] === 'html' ? 'selected' : '' ?>>HTML</option></select>
                            <select name="status"><option value="1" <?= !empty($row['status']) ? 'selected' : '' ?>>发布</option><option value="0" <?= empty($row['status']) ? 'selected' : '' ?>>草稿</option></select>
                            <label class="m-checkline"><input type="checkbox" name="show_home" <?= !empty($row['show_home']) ? 'checked' : '' ?>> 首页展示</label>
                            <label class="m-checkline"><input type="checkbox" name="is_top" <?= !empty($row['is_top']) ? 'checked' : '' ?>> 置顶</label>
                            <button class="ghost" type="submit">保存调整</button>
                        </form>
                    </details>
                    <div class="m-inline-actions">
                        <a class="m-button ghost" href="<?= url('announcements/' . (int) $row['id']) ?>" target="_blank">预览</a>
                        <form method="post" action="<?= url('admin/m/announcements/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($row['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这条公告吗？">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的公告。</div>
            <?php if (!$announcements): ?><div class="m-empty">暂无公告。</div><?php endif; ?>
        </div>
    </section>
</section>
