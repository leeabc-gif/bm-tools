<section class="m-page">
    <header class="m-page-head">
        <div><span>Orders</span><h1>订单充值</h1><p>处理待支付订单、人工补单和充值审核。</p></div>
        <a class="m-pill" href="<?= url('admin/m/payments') ?>">支付</a>
    </header>
    <section class="m-stat-grid three">
        <article><span>待支付</span><strong><?= e($stats['pending_orders']) ?></strong></article>
        <article><span>已支付</span><strong><?= e($stats['paid_orders']) ?></strong></article>
        <article><span>待审核</span><strong><?= e($stats['pending_recharges']) ?></strong></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="订单充值分区">
        <a href="#adminManualOrder">手动补单</a>
        <a href="#adminOrderList">订单</a>
        <a href="#adminRechargeList">充值</a>
        <a href="<?= url('admin/m/payments') ?>">支付配置</a>
    </nav>

    <section class="m-card" id="adminManualOrder">
        <div class="m-section-head"><div><span>Manual</span><h2>手动补单</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/orders/manual-paid') ?>">
            <?= csrf_field() ?>
            <input name="order_no" placeholder="输入待支付订单号">
            <button type="submit" data-mobile-confirm="确认将该订单标记为已支付吗？">确认补单</button>
        </form>
    </section>

    <section class="m-card" id="adminOrderList">
        <div class="m-section-head"><div><span>Orders</span><h2>订单</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索订单号、用户、套餐或状态" data-mobile-filter-input="#adminMobileOrdersList">
        </label>
        <div class="m-list" id="adminMobileOrdersList">
            <?php foreach ($orders as $order): ?>
                <?php
                $orderNo = isset($order['order_no']) ? $order['order_no'] : '';
                $orderStatus = isset($order['status']) ? $order['status'] : 'unknown';
                $orderType = isset($order['type']) ? $order['type'] : '';
                $orderUser = !empty($order['username']) ? $order['username'] : '-';
                $orderTitle = !empty($order['package_name']) ? $order['package_name'] : ($orderType !== '' ? $orderType : '-');
                $orderAmount = isset($order['pay_amount']) ? (float) $order['pay_amount'] : 0;
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="receipt-text"></i>
                    <div>
                        <strong><?= e($orderNo !== '' ? $orderNo : '-') ?></strong>
                        <span><?= e($orderUser) ?> · <?= e($orderTitle) ?> · ¥<?= e(number_format($orderAmount, 2)) ?> · <?= e($orderStatus) ?></span>
                    </div>
                    <?php if ($orderStatus === 'pending' && in_array($orderType, ['recharge', 'package'], true)): ?>
                        <form class="m-inline-actions" method="post" action="<?= url('admin/m/orders/manual-paid') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="order_no" value="<?= e($orderNo) ?>">
                            <button class="m-button" type="submit" data-mobile-confirm="确认补单并开通对应权益吗？">补单</button>
                        </form>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的订单。</div>
            <?php if (!$orders): ?><div class="m-empty">暂无订单。</div><?php endif; ?>
        </div>
    </section>
    <section class="m-card" id="adminRechargeList">
        <div class="m-section-head"><div><span>Recharge</span><h2>充值</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索充值用户、金额或状态" data-mobile-filter-input="#adminMobileRechargesList">
        </label>
        <div class="m-list" id="adminMobileRechargesList">
            <?php foreach ($recharges as $row): ?>
                <?php
                $rechargeId = isset($row['id']) ? (int) $row['id'] : 0;
                $rechargeAmount = isset($row['amount']) ? (float) $row['amount'] : 0;
                $rechargeUser = !empty($row['username']) ? $row['username'] : '-';
                $rechargeStatus = isset($row['status']) ? $row['status'] : 'unknown';
                $rechargeTime = isset($row['created_at']) ? $row['created_at'] : '-';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="wallet"></i>
                    <div>
                        <strong>¥<?= e(number_format($rechargeAmount, 2)) ?></strong>
                        <span><?= e($rechargeUser) ?> · <?= e($rechargeStatus) ?> · <?= e($rechargeTime) ?></span>
                    </div>
                    <?php if ($rechargeStatus === 'pending' && $rechargeId > 0): ?>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/recharges/audit') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($rechargeId) ?>">
                            <input name="remark" placeholder="审核备注，可留空">
                            <div class="m-inline-actions">
                                <button type="submit" name="action" value="approve" data-mobile-confirm="确认通过这笔充值吗？">通过</button>
                                <button class="danger" type="submit" name="action" value="reject" data-mobile-confirm="确认拒绝这笔充值吗？">拒绝</button>
                            </div>
                        </form>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的充值记录。</div>
            <?php if (!$recharges): ?><div class="m-empty">暂无充值记录。</div><?php endif; ?>
        </div>
    </section>
</section>
