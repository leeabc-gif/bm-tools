<section class="m-page">
    <header class="m-hero admin">
        <span>Admin Mobile</span>
        <h1>移动运营台</h1>
        <p>独立手机后台，不加载桌面后台侧边栏，避免菜单闪退和页面遮挡。</p>
    </header>

    <section class="m-stat-grid">
        <article><span>用户</span><strong><?= e($stats['users']) ?></strong><small>今日 <?= e($stats['today_users']) ?></small></article>
        <article><span>文件</span><strong><?= e($stats['files']) ?></strong><small><?= e(format_bytes($stats['storage'])) ?></small></article>
        <article><span>待订单</span><strong><?= e($stats['orders_pending']) ?></strong><small>待处理</small></article>
        <article><span>异常</span><strong><?= e($stats['offline_servers']) ?></strong><small>离线服务器</small></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Todo</span><h2>待处理</h2></div></div>
        <div class="m-action-grid">
            <?php foreach ($todos as $todo): ?>
                <a href="<?= url($todo['url']) ?>"><i data-lucide="<?= e($todo['icon']) ?>"></i><span><?= e($todo['label']) ?></span><b><?= e($todo['value']) ?></b></a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Health</span><h2>运营告警</h2></div><a href="<?= url('admin/m/settings') ?>">巡检</a></div>
        <div class="m-alert-list">
            <?php foreach ((isset($opsAlerts) && is_array($opsAlerts)) ? $opsAlerts : [] as $alert): ?>
                <a class="m-alert-card <?= e(isset($alert['level']) ? $alert['level'] : 'soft') ?>" href="<?= url(isset($alert['url']) ? $alert['url'] : 'admin/m/menu') ?>">
                    <i data-lucide="<?= e(isset($alert['icon']) ? $alert['icon'] : 'bell') ?>"></i>
                    <span>
                        <strong><?= e(isset($alert['title']) ? $alert['title'] : '待处理事项') ?></strong>
                        <small><?= e(isset($alert['desc']) ? $alert['desc'] : '') ?></small>
                    </span>
                    <b><?= e(isset($alert['value']) ? $alert['value'] : '') ?></b>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Repair</span><h2>排错快捷入口</h2></div><a href="<?= url('admin/m/incidents') ?>">异常</a></div>
        <div class="m-action-grid">
            <a href="<?= url('admin/m/logs#uploadFailureSection') ?>"><i data-lucide="cloud-alert"></i><span>上传失败</span></a>
            <a href="<?= url('admin/m/storages') ?>"><i data-lucide="database"></i><span>存储测试</span></a>
            <a href="<?= url('admin/m/schema-audit') ?>"><i data-lucide="database-zap"></i><span>数据库巡检</span></a>
            <a href="<?= url('admin/m/upload-limits') ?>"><i data-lucide="gauge"></i><span>上传限制</span></a>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Menu</span><h2>常用功能</h2></div><a href="<?= url('admin/m/menu') ?>">全部</a></div>
        <div class="m-feature-list compact">
            <a href="<?= url('admin/m/users') ?>"><i data-lucide="users"></i><span><strong>用户管理</strong><small>新增、套餐、余额、状态</small></span><em data-lucide="chevron-right"></em></a>
            <a href="<?= url('admin/m/files') ?>"><i data-lucide="files"></i><span><strong>文件管理</strong><small>打开、定位、删除异常文件</small></span><em data-lucide="chevron-right"></em></a>
            <a href="<?= url('admin/m/storages') ?>"><i data-lucide="database"></i><span><strong>存储状态</strong><small>测试、启停、默认源</small></span><em data-lucide="chevron-right"></em></a>
            <a href="<?= url('admin/m/packages') ?>"><i data-lucide="badge-dollar-sign"></i><span><strong>套餐权益</strong><small>价格、空间、功能权限</small></span><em data-lucide="chevron-right"></em></a>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Orders</span><h2>最近订单</h2></div><a href="<?= url('admin/m/orders') ?>">查看</a></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索订单号、用户、金额或状态" data-mobile-filter-input="#adminMobileDashboardOrdersList">
        </label>
        <div class="m-list" id="adminMobileDashboardOrdersList">
            <?php foreach ($recentOrders as $order): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="receipt-text"></i>
                    <div><strong><?= e($order['order_no']) ?></strong><span><?= e($order['username'] ?: '-') ?> · ¥<?= e(number_format((float) $order['pay_amount'], 2)) ?> · <?= e($order['status']) ?></span></div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的订单。</div>
            <?php if (!$recentOrders): ?><div class="m-empty">暂无订单。</div><?php endif; ?>
        </div>
    </section>
</section>
