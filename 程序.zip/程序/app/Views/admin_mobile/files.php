<section class="m-page">
    <header class="m-page-head">
        <div><span>Files</span><h1>文件管理</h1><p>全站文件移动端卡片视图，可快速打开或删除异常文件记录。</p></div>
        <a class="m-pill" href="<?= url('admin/m/menu') ?>">功能</a>
    </header>
    <section class="m-stat-grid">
        <article><span>总文件</span><strong><?= e($stats['total']) ?></strong></article>
        <article><span>图片</span><strong><?= e($stats['images']) ?></strong></article>
        <article><span>网盘</span><strong><?= e($stats['netdisk']) ?></strong></article>
        <article><span>占用</span><strong><?= e(format_bytes($stats['size'])) ?></strong></article>
    </section>
    <nav class="m-anchor-nav m-chip-list" aria-label="文件管理分区">
        <a href="#adminFilesList">文件列表</a>
        <a href="<?= url('admin/m/storages') ?>">存储测试</a>
        <a href="<?= url('admin/m/logs#uploadFailureSection') ?>">上传失败</a>
    </nav>
    <section class="m-card" id="adminFilesList">
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索文件名、用户、类型或 ID" data-mobile-filter-input="#adminMobileFilesList">
        </label>
        <div class="m-list" id="adminMobileFilesList">
            <?php foreach ($files as $file): ?>
                <?php $fileType = isset($file['file_type']) ? $file['file_type'] : 'file'; ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="<?= $fileType === 'image' ? 'image' : 'file' ?>"></i>
                    <div>
                        <strong><?= e($file['original_name']) ?></strong>
                        <span><?= e($file['username'] ?: '-') ?> · <?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></span>
                    </div>
                    <a href="<?= e(public_url($file['file_url'])) ?>" target="_blank">打开</a>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e(strtoupper($fileType)) ?></span>
                        <span class="m-badge muted">下载 <?= e((int) (isset($file['download_count']) ? $file['download_count'] : 0)) ?></span>
                        <span class="m-badge muted">ID <?= e($file['id']) ?></span>
                    </div>
                    <div class="m-inline-actions">
                        <button class="m-button ghost" type="button" data-copy-text="<?= e(public_url($file['file_url'])) ?>">复制链接</button>
                        <form method="post" action="<?= url('admin/m/files/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个文件记录吗？会尝试同步删除远程对象。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的文件。</div>
            <?php if (!$files): ?><div class="m-empty">暂无文件。</div><?php endif; ?>
        </div>
    </section>
</section>
