<?php
$adminLogs = isset($adminLogs) ? $adminLogs : [];
$apiLogs = isset($apiLogs) ? $apiLogs : [];
$balanceLogs = isset($balanceLogs) ? $balanceLogs : [];
$commandLogs = isset($commandLogs) ? $commandLogs : [];
$uploadFailures = isset($uploadFailures) ? $uploadFailures : [];
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Audit</span><h1>审计日志</h1><p>集中查看管理员操作、API 调用、上传失败、余额流水和服务器命令审计。</p></div>
        <a class="m-pill" href="<?= url('admin/m/incidents') ?>">异常</a>
    </header>

    <section class="m-stat-grid">
        <article><span>今日后台操作</span><strong><?= e($stats['admin_today']) ?></strong></article>
        <article><span>API 失败</span><strong><?= e($stats['api_failed']) ?></strong></article>
        <article><span>今日上传失败</span><strong><?= e(isset($stats['upload_failed_today']) ? $stats['upload_failed_today'] : 0) ?></strong></article>
        <article><span>今日余额流水</span><strong><?= e($stats['balance_today']) ?></strong></article>
        <article><span>危险命令</span><strong><?= e($stats['commands_danger']) ?></strong></article>
    </section>

    <nav class="m-chip-list m-anchor-nav" aria-label="日志分类">
        <a href="#adminLogSection">管理员</a>
        <a href="#apiLogSection">API</a>
        <a href="#uploadFailureSection">上传失败</a>
        <a href="#balanceLogSection">余额</a>
        <a href="#commandLogSection">命令</a>
    </nav>

    <section class="m-card" id="adminLogSection">
        <div class="m-section-head"><div><span>Admin</span><h2>管理员操作</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索操作、用户、对象或 IP" data-mobile-filter-input="#adminMobileAdminLogsList">
        </label>
        <div class="m-list" id="adminMobileAdminLogsList">
            <?php foreach ($adminLogs as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="shield-check"></i>
                    <div>
                        <strong><?= e($row['action']) ?></strong>
                        <span><?= e($row['username'] ?: '-') ?> · <?= e($row['target_type'] ?: '-') ?>#<?= e($row['target_id'] ?: '-') ?> · <?= e($row['created_at']) ?></span>
                        <?php if (!empty($row['ip'])): ?><span><?= e($row['ip']) ?></span><?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的管理员日志。</div>
            <?php if (!$adminLogs): ?><div class="m-empty">暂无管理员日志。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="apiLogSection">
        <div class="m-section-head"><div><span>API</span><h2>API 调用</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索接口、用户、状态或提示" data-mobile-filter-input="#adminMobileApiLogsList">
        </label>
        <div class="m-list" id="adminMobileApiLogsList">
            <?php foreach ($apiLogs as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="plug-zap"></i>
                    <div>
                        <strong><?= e($row['method'] . ' ' . $row['endpoint']) ?></strong>
                        <span><?= e($row['username'] ?: '-') ?> · <?= e(!empty($row['api_app_name']) ? $row['api_app_name'] : '总 Token') ?> · HTTP <?= e(isset($row['status_code']) ? $row['status_code'] : '-') ?> · <?= e($row['created_at']) ?></span>
                        <span><?= !empty($row['is_success']) ? '成功' : '失败' ?> · <?= e(isset($row['ip']) ? $row['ip'] : '-') ?></span>
                        <?php if (!empty($row['message'])): ?><span><?= e($row['message']) ?></span><?php endif; ?>
                    </div>
                    <span class="m-badge <?= !empty($row['is_success']) ? 'ok' : 'bad' ?>"><?= !empty($row['is_success']) ? 'OK' : 'FAIL' ?></span>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的 API 日志。</div>
            <?php if (!$apiLogs): ?><div class="m-empty">暂无 API 日志。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="uploadFailureSection">
        <div class="m-section-head"><div><span>Upload</span><h2>上传失败记录</h2></div><a href="<?= url('admin/m/storages') ?>">存储</a></div>
        <div class="m-note">按“PHP 上传环境、套餐或权限、存储配置、对象写入、数据库入库”分类定位失败原因。存储类失败先点“测试存储”，数据库类失败先点“数据库巡检”。</div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索文件、用户、存储、错误类型或建议" data-mobile-filter-input="#adminMobileUploadFailureList">
        </label>
        <div class="m-list" id="adminMobileUploadFailureList">
            <?php foreach ($uploadFailures as $row): ?>
                <?php
                $errorType = isset($row['error_type']) ? (string) $row['error_type'] : 'upload';
                $isStorage = in_array($errorType, ['storage', 'storage_config', 'storage_upload', 'storage_url', 'storage_delete', 'storage_db'], true);
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="cloud-alert"></i>
                    <div>
                        <strong><?= e($row['file_name'] ?: '未进入文件处理') ?></strong>
                        <span><?= e($row['username'] ?: '-') ?> · <?= e($row['scope'] ?: '-') ?> · <?= e($row['created_at']) ?></span>
                        <span><?= e($row['storage_name'] ?: ($row['storage_type'] ?: '未定位存储')) ?> · <?= e(format_bytes((int) $row['file_size'])) ?></span>
                        <?php if (!empty($row['message'])): ?><span><?= e(text_limit($row['message'], 180)) ?></span><?php endif; ?>
                        <?php if (!empty($row['suggestion'])): ?><span><?= e(text_limit($row['suggestion'], 180)) ?></span><?php endif; ?>
                    </div>
                    <span class="m-badge <?= $isStorage ? 'bad' : ($errorType === 'schema' ? 'warn' : 'muted') ?>"><?= e($errorType) ?></span>
                    <?php if ($isStorage): ?>
                        <div class="m-inline-actions">
                            <a class="m-button ghost" href="<?= url('admin/m/storages') ?>">测试存储</a>
                            <a class="m-button ghost" href="<?= url('admin/m/incidents') ?>">异常中心</a>
                        </div>
                    <?php elseif ($errorType === 'schema' || $errorType === 'storage_db'): ?>
                        <div class="m-inline-actions">
                            <a class="m-button ghost" href="<?= url('admin/m/schema-audit') ?>">数据库巡检</a>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的上传失败记录。</div>
            <?php if (!$uploadFailures): ?><div class="m-empty">暂无上传失败记录。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="balanceLogSection">
        <div class="m-section-head"><div><span>Balance</span><h2>余额流水</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索用户、类型、金额或备注" data-mobile-filter-input="#adminMobileBalanceLogsList">
        </label>
        <div class="m-list" id="adminMobileBalanceLogsList">
            <?php foreach ($balanceLogs as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="wallet-cards"></i>
                    <div>
                        <strong><?= e($row['type']) ?> · ¥<?= e(number_format((float) $row['amount'], 2)) ?></strong>
                        <span><?= e($row['username'] ?: '-') ?> · <?= e($row['created_at']) ?></span>
                        <?php if (!empty($row['remark'])): ?><span><?= e($row['remark']) ?></span><?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的余额流水。</div>
            <?php if (!$balanceLogs): ?><div class="m-empty">暂无余额流水。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="commandLogSection">
        <div class="m-section-head"><div><span>Commands</span><h2>命令审计</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索命令、用户、服务器或风险级别" data-mobile-filter-input="#adminMobileCommandLogsList">
        </label>
        <div class="m-list" id="adminMobileCommandLogsList">
            <?php foreach ($commandLogs as $row): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="terminal"></i>
                    <div>
                        <strong><?= e(text_limit($row['command'], 80)) ?></strong>
                        <span><?= e($row['username'] ?: '-') ?> · <?= e($row['server_name'] ?: '-') ?> · <?= e($row['created_at']) ?></span>
                    </div>
                    <span class="m-badge <?= $row['risk_level'] === 'danger' ? 'bad' : ($row['risk_level'] === 'warning' ? 'warn' : 'muted') ?>"><?= e($row['risk_level']) ?></span>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的命令审计。</div>
            <?php if (!$commandLogs): ?><div class="m-empty">暂无命令审计。</div><?php endif; ?>
        </div>
    </section>
</section>
