<?php
$audit = isset($schemaAudit) && is_array($schemaAudit) ? $schemaAudit : [];
$ok = !empty($audit['ok']);
$missingTables = isset($audit['missing_tables']) && is_array($audit['missing_tables']) ? $audit['missing_tables'] : [];
$missingColumns = isset($audit['missing_columns']) && is_array($audit['missing_columns']) ? $audit['missing_columns'] : [];
$codeMissingTables = isset($audit['code_missing_tables']) && is_array($audit['code_missing_tables']) ? $audit['code_missing_tables'] : [];
$repairSql = isset($audit['repair_sql']) && is_array($audit['repair_sql']) ? $audit['repair_sql'] : [];
$privileges = isset($audit['privileges']) && is_array($audit['privileges']) ? $audit['privileges'] : [];
$grantSummary = isset($privileges['grant_summary']) && is_array($privileges['grant_summary']) ? $privileges['grant_summary'] : [];
$grantRows = isset($privileges['grants']) && is_array($privileges['grants']) ? $privileges['grants'] : [];
$grantUser = isset($privileges['current_user']) ? (string) $privileges['current_user'] : '';
$grantDb = isset($privileges['database']) ? (string) $privileges['database'] : '';
$schemaRepairResult = isset($schemaRepairResult) && is_array($schemaRepairResult) ? $schemaRepairResult : null;

if ($ok && is_array($schemaRepairResult) && empty($schemaRepairResult['ok'])) {
    $schemaRepairResult['ok'] = true;
    $schemaRepairResult['fail_count'] = 0;
    $schemaRepairResult['schema_unresolved_count'] = 0;
    $schemaRepairResult['unresolved_count'] = 0;
    $schemaRepairResult['final_schema_ready'] = true;
}

$repairFailedResults = [];
$repairAutoSqlFailed = [];
$repairProbe = [];
if ($schemaRepairResult) {
    $repairResults = isset($schemaRepairResult['results']) && is_array($schemaRepairResult['results']) ? $schemaRepairResult['results'] : [];
    $repairFailedResults = array_values(array_filter($repairResults, function ($item) {
        return empty($item['ok']);
    }));
    $repairAutoSql = isset($schemaRepairResult['auto_sql_repair']) && is_array($schemaRepairResult['auto_sql_repair']) ? $schemaRepairResult['auto_sql_repair'] : [];
    $repairAutoSqlResults = isset($repairAutoSql['results']) && is_array($repairAutoSql['results']) ? $repairAutoSql['results'] : [];
    $repairAutoSqlFailed = array_values(array_filter($repairAutoSqlResults, function ($item) {
        return empty($item['ok']);
    }));
    $repairPrivileges = isset($schemaRepairResult['privileges']) && is_array($schemaRepairResult['privileges']) ? $schemaRepairResult['privileges'] : [];
    $repairProbe = isset($repairPrivileges['probe']) && is_array($repairPrivileges['probe']) ? $repairPrivileges['probe'] : [];
}

$grantUserSql = '';
if ($grantUser !== '' && strpos($grantUser, '@') !== false) {
    $parts = explode('@', $grantUser, 2);
    $grantUserSql = "'" . str_replace("'", "''", trim($parts[0], "'")) . "'@'" . str_replace("'", "''", trim($parts[1], "'")) . "'";
}
$suggestGrant = ($grantUser !== '' && $grantDb !== '')
    ? "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP ON `" . str_replace('`', '``', $grantDb) . "`.* TO " . ($grantUserSql !== '' ? $grantUserSql : $grantUser) . ";\nFLUSH PRIVILEGES;"
    : '';
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>Database</span>
            <h1>数据库巡检</h1>
            <p>手机端直接检查表、字段、代码引用表和数据库权限，修复失败时会展示具体卡住的位置。</p>
        </div>
        <span class="m-badge <?= $ok ? 'ok' : 'bad' ?>"><?= $ok ? '已匹配' : '需修复' ?></span>
    </header>

    <section class="m-stat-grid two">
        <article><span>应有表</span><strong><?= e((int) (isset($audit['expected_table_count']) ? $audit['expected_table_count'] : 0)) ?></strong><small>来自 schema.sql</small></article>
        <article><span>当前表</span><strong><?= e((int) (isset($audit['current_prefixed_table_count']) ? $audit['current_prefixed_table_count'] : 0)) ?></strong><small>前缀 <?= e(isset($audit['prefix']) ? $audit['prefix'] : '') ?></small></article>
        <article><span>缺失表</span><strong><?= e((int) (isset($audit['missing_table_count']) ? $audit['missing_table_count'] : count($missingTables))) ?></strong><small>缺表会导致页面报错</small></article>
        <article><span>缺失字段</span><strong><?= e((int) (isset($audit['missing_column_count']) ? $audit['missing_column_count'] : count($missingColumns))) ?></strong><small>缺字段会影响保存</small></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Action</span><h2>修复操作</h2></div></div>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/maintenance/repair-schema') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="return_to" value="schema-audit">
            <div class="m-note">优先执行一键修复。若仍有未完成项，继续在本页查看失败 SQL、权限探针，或使用临时数据库管理员账号修复。</div>
            <button type="submit" data-mobile-confirm="确认执行数据库结构一键修复吗？建议已备份数据库。">一键修复数据库结构</button>
        </form>
    </section>

    <?php if ($schemaRepairResult): ?>
        <section class="m-card">
            <div class="m-section-head">
                <div><span>Repair</span><h2>上次修复结果</h2></div>
                <span class="m-badge <?= !empty($schemaRepairResult['ok']) ? 'ok' : 'bad' ?>"><?= !empty($schemaRepairResult['ok']) ? '已完成' : '有失败项' ?></span>
            </div>
            <div class="m-status-row">
                <article class="m-check-card <?= !empty($schemaRepairResult['ok']) ? 'ok' : 'bad' ?>">
                    <b>成功 / 失败</b>
                    <span><?= e((int) (isset($schemaRepairResult['success_count']) ? $schemaRepairResult['success_count'] : 0)) ?> / <?= e((int) (isset($schemaRepairResult['fail_count']) ? $schemaRepairResult['fail_count'] : 0)) ?></span>
                </article>
                <article class="m-check-card <?= !empty($schemaRepairResult['unresolved_count']) ? 'bad' : 'ok' ?>">
                    <b>剩余问题</b>
                    <span><?= e((int) (isset($schemaRepairResult['unresolved_count']) ? $schemaRepairResult['unresolved_count'] : 0)) ?> 项</span>
                </article>
            </div>
            <?php if ($repairFailedResults): ?>
                <div class="m-list">
                    <?php foreach (array_slice($repairFailedResults, 0, 8) as $result): ?>
                        <article class="m-list-item tall">
                            <i data-lucide="circle-alert"></i>
                            <div>
                                <strong><?= e(isset($result['label']) ? $result['label'] : (isset($result['key']) ? $result['key'] : '未完成任务')) ?></strong>
                                <span><?= e(isset($result['message']) ? $result['message'] : '没有返回失败原因') ?></span>
                            </div>
                            <span class="m-badge bad"><?= e(isset($result['key']) ? $result['key'] : 'fail') ?></span>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($repairAutoSqlFailed): ?>
                <details class="m-fold">
                    <summary>自动 SQL 失败明细</summary>
                    <div class="m-copy-stack">
                        <?php foreach (array_slice($repairAutoSqlFailed, 0, 8) as $item): ?>
                            <pre class="m-code-block"><?= e((isset($item['sql']) ? $item['sql'] : '') . "\n" . (isset($item['message']) ? $item['message'] : '')) ?></pre>
                        <?php endforeach; ?>
                    </div>
                </details>
            <?php endif; ?>
            <?php if ($repairProbe): ?>
                <div class="m-status-row">
                    <?php foreach (['create' => 'CREATE 建表', 'alter' => 'ALTER 字段', 'index' => 'INDEX 索引', 'drop' => 'DROP 清理'] as $key => $label): ?>
                        <?php $step = isset($repairProbe[$key]) && is_array($repairProbe[$key]) ? $repairProbe[$key] : ['ok' => false, 'message' => '未执行']; ?>
                        <article class="m-check-card <?= !empty($step['ok']) ? 'ok' : 'bad' ?>">
                            <b><?= e($label) ?></b>
                            <span><?= e(isset($step['message']) ? $step['message'] : '') ?></span>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <section class="m-card">
        <div class="m-section-head">
            <div><span>Privileges</span><h2>数据库账号权限</h2></div>
            <span class="m-badge <?= !empty($privileges['ok']) ? 'ok' : 'bad' ?>"><?= !empty($privileges['ok']) ? '可用' : '可能缺权限' ?></span>
        </div>
        <div class="m-note">当前账号：<?= e($grantUser ?: '-') ?>；数据库：<?= e($grantDb ?: '-') ?>。一键修复至少需要 CREATE / ALTER / INDEX 权限。</div>
        <div class="m-status-row">
            <?php foreach (['create' => 'CREATE', 'alter' => 'ALTER', 'index' => 'INDEX', 'drop' => 'DROP'] as $key => $label): ?>
                <?php $has = !empty($grantSummary[$key]); ?>
                <article class="m-check-card <?= $has ? 'ok' : 'bad' ?>">
                    <b><?= e($label) ?></b>
                    <span><?= $has ? '授权文本检测通过' : '授权文本未检测到' ?></span>
                </article>
            <?php endforeach; ?>
        </div>
        <?php if ($grantRows): ?>
            <details class="m-fold">
                <summary>查看 SHOW GRANTS</summary>
                <pre class="m-code-block"><?php foreach ($grantRows as $grant): ?><?= e($grant) . "\n" ?><?php endforeach; ?></pre>
            </details>
        <?php endif; ?>
        <?php if ($suggestGrant && empty($privileges['ok'])): ?>
            <details class="m-fold" open>
                <summary>参考授权 SQL</summary>
                <pre class="m-code-block"><?= e($suggestGrant) ?></pre>
            </details>
        <?php endif; ?>
    </section>

    <?php if (empty($privileges['ok']) || !$ok): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Admin Repair</span><h2>临时高权限修复</h2></div></div>
            <form class="m-mini-form" method="post" action="<?= url('admin/m/maintenance/repair-schema-admin') ?>" autocomplete="off">
                <?= csrf_field() ?>
                <div class="m-note">填写一次 root 或主机面板数据库管理员账号，只用于本次连接当前数据库执行修复，不会保存密码。</div>
                <input name="db_admin_user" value="root" required autocomplete="off" placeholder="临时数据库管理员账号">
                <input name="db_admin_pass" type="password" autocomplete="new-password" placeholder="临时数据库管理员密码">
                <button class="ghost" type="submit" data-mobile-confirm="将使用临时数据库管理员账号修复当前数据库结构，密码不会保存。确认继续吗？">使用临时账号修复</button>
            </form>
        </section>
    <?php endif; ?>

    <?php if (!$ok): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Issues</span><h2>巡检结论</h2></div></div>
            <div class="m-list">
                <article class="m-list-item tall">
                    <i data-lucide="table"></i>
                    <div><strong>数据表匹配</strong><span><?= $missingTables ? '发现缺失表，请先一键修复。' : '所有 schema.sql 表已存在。' ?></span></div>
                    <span class="m-badge <?= $missingTables ? 'bad' : 'ok' ?>"><?= e(count($missingTables)) ?></span>
                </article>
                <article class="m-list-item tall">
                    <i data-lucide="columns-3"></i>
                    <div><strong>字段匹配</strong><span><?= $missingColumns ? '有表缺少新版程序字段。' : '字段结构已匹配。' ?></span></div>
                    <span class="m-badge <?= $missingColumns ? 'bad' : 'ok' ?>"><?= e(count($missingColumns)) ?></span>
                </article>
                <article class="m-list-item tall">
                    <i data-lucide="code-2"></i>
                    <div><strong>代码引用表</strong><span><?= $codeMissingTables ? '代码中有表在当前库不存在。' : '代码引用表均可找到。' ?></span></div>
                    <span class="m-badge <?= $codeMissingTables ? 'bad' : 'ok' ?>"><?= e(count($codeMissingTables)) ?></span>
                </article>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($missingTables): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Missing Tables</span><h2>缺失数据表</h2></div></div>
            <label class="m-list-search">
                <i data-lucide="search"></i>
                <input type="search" placeholder="搜索缺失表名" data-mobile-filter-input="#adminMobileMissingTablesList">
                <span data-mobile-filter-count>0</span>
            </label>
            <div class="m-list" id="adminMobileMissingTablesList">
                <?php foreach (array_slice($missingTables, 0, 30) as $index => $table): ?>
                    <article class="m-list-item" data-mobile-filter-item>
                        <i data-lucide="table"></i>
                        <div><strong><?= e($table) ?></strong><span>第 <?= e($index + 1) ?> 项，点击一键修复会按 schema.sql 建表。</span></div>
                    </article>
                <?php endforeach; ?>
                <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的缺失表。</div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($missingColumns): ?>
        <section class="m-card">
            <div class="m-section-head"><div><span>Missing Columns</span><h2>缺失字段</h2></div></div>
            <label class="m-list-search">
                <i data-lucide="search"></i>
                <input type="search" placeholder="搜索表名或字段名" data-mobile-filter-input="#adminMobileMissingColumnsList">
                <span data-mobile-filter-count>0</span>
            </label>
            <div class="m-list" id="adminMobileMissingColumnsList">
                <?php foreach (array_slice($missingColumns, 0, 40) as $item): ?>
                    <article class="m-list-item" data-mobile-filter-item>
                        <i data-lucide="columns-3"></i>
                        <div><strong><?= e(isset($item['table']) ? $item['table'] : '') ?></strong><span><?= e(isset($item['column']) ? $item['column'] : '') ?></span></div>
                    </article>
                <?php endforeach; ?>
                <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的缺失字段。</div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($repairSql): ?>
        <section class="m-card">
            <div class="m-section-head">
                <div><span>Repair SQL</span><h2>待执行 SQL</h2></div>
                <span class="m-badge warn"><?= e(count($repairSql)) ?> 条</span>
            </div>
            <div class="m-note">如果网页修复仍失败，可把下面 SQL 交给拥有数据库 DDL 权限的账号执行。执行前请先备份数据库。</div>
            <textarea class="m-code-textarea" readonly rows="14"><?php foreach ($repairSql as $sql): ?><?= e($sql) . "\n\n" ?><?php endforeach; ?></textarea>
        </section>
    <?php endif; ?>
</section>
