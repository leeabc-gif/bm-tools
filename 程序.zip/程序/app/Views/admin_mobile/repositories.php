<?php $repositories = isset($repositories) ? $repositories : []; ?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Repositories</span><h1>分享仓库</h1><p>审核和处理用户公开仓库，异常仓库可在手机端快速下架。</p></div>
        <a class="m-pill" href="<?= url('admin/m/storage-backups') ?>">备份</a>
    </header>

    <section class="m-stat-grid three">
        <article><span>仓库</span><strong><?= e($stats['total']) ?></strong></article>
        <article><span>启用</span><strong><?= e($stats['enabled']) ?></strong></article>
        <article><span>异常</span><strong><?= e($stats['disabled']) ?></strong></article>
    </section>
    <section class="m-stat-grid three">
        <article><span>今日浏览</span><strong><?= e($stats['today_views']) ?></strong></article>
        <article><span>今日下载</span><strong><?= e($stats['today_downloads']) ?></strong></article>
        <article><span>拦截</span><strong><?= e($stats['blocked_today']) ?></strong></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>List</span><h2>仓库列表</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索仓库、用户、链接或访问类型" data-mobile-filter-input="#adminMobileRepositoriesList">
        </label>
        <div class="m-list" id="adminMobileRepositoriesList">
            <?php foreach ($repositories as $repo): ?>
                <?php $enabled = !empty($repo['status']) && !empty($repo['admin_status']); ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="library"></i>
                    <div>
                        <strong><?= e($repo['title']) ?></strong>
                        <span><?= e($repo['username'] ?: '-') ?> · /r/<?= e($repo['slug']) ?> · <?= e($repo['access_type']) ?></span>
                    </div>
                    <span class="m-badge <?= $enabled ? 'ok' : 'bad' ?>"><?= $enabled ? '启用' : '受限' ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">文件 <?= e((int) (isset($repo['item_count']) ? $repo['item_count'] : 0)) ?></span>
                        <span class="m-badge muted">公开 <?= e((int) (isset($repo['public_item_count']) ? $repo['public_item_count'] : 0)) ?></span>
                        <span class="m-badge muted">日志 <?= e((int) (isset($repo['log_count']) ? $repo['log_count'] : 0)) ?></span>
                    </div>
                    <?php if (!empty($repo['admin_remark'])): ?><div class="m-note"><?= e($repo['admin_remark']) ?></div><?php endif; ?>
                    <details class="m-fold">
                        <summary>平台审核</summary>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/repositories/status') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                            <select name="admin_status">
                                <option value="1" <?= !empty($repo['admin_status']) ? 'selected' : '' ?>>恢复展示</option>
                                <option value="0" <?= empty($repo['admin_status']) ? 'selected' : '' ?>>平台下架</option>
                            </select>
                            <input name="admin_remark" value="<?= e(isset($repo['admin_remark']) ? $repo['admin_remark'] : '') ?>" maxlength="255" placeholder="审核备注">
                            <button class="ghost" type="submit">保存状态</button>
                        </form>
                    </details>
                    <div class="m-inline-actions">
                        <a class="m-button ghost" href="<?= url('r/' . $repo['slug']) ?>" target="_blank">访问</a>
                        <button class="m-button ghost" type="button" data-copy-text="<?= e(url('r/' . $repo['slug'])) ?>">复制链接</button>
                        <form method="post" action="<?= url('admin/m/repositories/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($repo['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个分享仓库吗？仓库文件关系和访问日志会清理。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的分享仓库。</div>
            <?php if (!$repositories): ?><div class="m-empty">暂无分享仓库。</div><?php endif; ?>
        </div>
    </section>
</section>
