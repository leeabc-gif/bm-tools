<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>Servers</span>
            <h1>服务器监控</h1>
            <p>本站监控与用户服务器分开展示，手机端可直接采集和启停。</p>
        </div>
        <a class="m-pill" href="<?= url('admin/m/logs') ?>">日志</a>
    </header>

    <section class="m-stat-grid">
        <article><span>本站在线</span><strong><?= e($stats['bt_online']) ?></strong></article>
        <article><span>本站离线</span><strong><?= e($stats['bt_offline']) ?></strong></article>
        <article><span>用户服务器</span><strong><?= e($stats['user_servers']) ?></strong></article>
        <article><span>告警</span><strong><?= e($stats['alerts']) ?></strong></article>
    </section>

    <nav class="m-anchor-nav m-chip-list" aria-label="服务器监控分区">
        <a href="#adminMainServers">本站服务器</a>
        <a href="#adminUserServers">用户服务器</a>
        <a href="<?= url('admin/m/logs') ?>">日志审计</a>
        <a href="<?= url('admin/m/settings') ?>">采集设置</a>
    </nav>

    <section class="m-card" id="adminMainServers">
        <div class="m-section-head">
            <div><span>Main Site</span><h2>本站服务器</h2></div>
            <a href="<?= url('admin/m/settings') ?>">采集</a>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索本站服务器、IP、状态或错误" data-mobile-filter-input="#adminMobileMainServersList">
        </label>
        <div class="m-list" id="adminMobileMainServersList">
            <?php $hasMainServers = false; ?>
            <?php foreach ($servers as $server): ?>
                <?php
                $monitorType = isset($server['monitor_type']) ? $server['monitor_type'] : 'bt';
                if ($monitorType !== 'bt') {
                    continue;
                }
                $hasMainServers = true;
                $serverName = isset($server['name']) ? $server['name'] : '服务器';
                $serverHost = !empty($server['host']) ? $server['host'] : (!empty($server['server_ip']) ? $server['server_ip'] : (!empty($server['panel_url']) ? $server['panel_url'] : '-'));
                $serverStatus = !empty($server['status']) ? $server['status'] : 'unknown';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="server"></i>
                    <div>
                        <strong><?= e($serverName) ?></strong>
                        <span><?= e($serverHost) ?> · <?= e($serverStatus) ?> · <?= !empty($server['is_enabled']) ? '监控中' : '已暂停' ?></span>
                        <?php if (!empty($server['last_checked_at'])): ?><span>最近采集：<?= e($server['last_checked_at']) ?></span><?php endif; ?>
                        <?php if (!empty($server['last_error'])): ?><span>错误：<?= e($server['last_error']) ?></span><?php endif; ?>
                    </div>
                    <span class="m-badge <?= $serverStatus === 'online' ? 'ok' : ($serverStatus === 'offline' ? 'bad' : 'muted') ?>"><?= e($serverStatus) ?></span>
                    <div class="m-inline-actions">
                        <form method="post" action="<?= url('admin/m/monitors/collect') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                            <button class="m-button" type="submit">立即采集</button>
                        </form>
                        <form method="post" action="<?= url('admin/m/monitors/toggle') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                            <button class="m-button ghost" type="submit"><?= !empty($server['is_enabled']) ? '暂停监控' : '启用监控' ?></button>
                        </form>
                        <form method="post" action="<?= url('admin/m/monitors/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这台本站监控服务器吗？历史指标和告警也会清理。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的本站服务器。</div>
            <?php if (!$hasMainServers): ?><div class="m-empty">暂无本站监控服务器。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card" id="adminUserServers">
        <div class="m-section-head">
            <div><span>User Servers</span><h2>用户服务器</h2></div>
            <a href="<?= url('admin/m/logs') ?>">审计</a>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索用户服务器、主机、接入方式或状态" data-mobile-filter-input="#adminMobileUserServersList">
        </label>
        <div class="m-list" id="adminMobileUserServersList">
            <?php $hasUserServers = false; ?>
            <?php foreach ($servers as $server): ?>
                <?php
                $monitorType = isset($server['monitor_type']) ? $server['monitor_type'] : '';
                if (!in_array($monitorType, ['ssh', 'agent'], true)) {
                    continue;
                }
                $hasUserServers = true;
                $serverName = isset($server['name']) ? $server['name'] : '用户服务器';
                $serverHost = !empty($server['host']) ? $server['host'] : (!empty($server['ssh_host']) ? $server['ssh_host'] : (!empty($server['agent_url']) ? $server['agent_url'] : '-'));
                $serverStatus = !empty($server['status']) ? $server['status'] : 'unknown';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="server-cog"></i>
                    <div>
                        <strong><?= e($serverName) ?></strong>
                        <span><?= e($monitorType) ?> · <?= e($serverHost) ?> · <?= e($serverStatus) ?></span>
                        <?php if (!empty($server['last_checked_at'])): ?><span>最近采集：<?= e($server['last_checked_at']) ?></span><?php endif; ?>
                    </div>
                    <span class="m-badge muted"><?= e($monitorType) ?></span>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的用户服务器。</div>
            <?php if (!$hasUserServers): ?><div class="m-empty">暂无用户服务器。</div><?php endif; ?>
        </div>
    </section>
</section>
