<?php $packages = isset($packages) ? $packages : []; ?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Packages</span><h1>套餐权益</h1><p>快速新增、调整和停用套餐，图床、网盘、API、服务器管家和分站权益分开控制。</p></div>
        <a class="m-pill" href="<?= url('admin/m/coupons') ?>">营销</a>
    </header>

    <section class="m-stat-grid three">
        <article><span>套餐</span><strong><?= e($stats['total']) ?></strong></article>
        <article><span>启用</span><strong><?= e($stats['enabled']) ?></strong></article>
        <article><span>付费</span><strong><?= e($stats['paid']) ?></strong></article>
    </section>

    <details class="m-fold">
        <summary>新增套餐</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/packages/save') ?>">
            <?= csrf_field() ?>
            <input name="name" value="<?= e(old('name')) ?>" maxlength="80" required placeholder="套餐名称">
            <input name="price" type="number" step="0.01" min="0" value="<?= e(old('price', '0')) ?>" placeholder="价格">
            <div class="m-status-row">
                <select name="duration_type">
                    <option value="month">月付</option>
                    <option value="quarter">季度</option>
                    <option value="year">年付</option>
                    <option value="forever">永久</option>
                </select>
                <input name="duration_days" type="number" min="0" value="<?= e(old('duration_days', '30')) ?>" placeholder="有效天数">
            </div>
            <input name="storage_limit" type="number" min="0" value="<?= e(old('storage_limit', '1073741824')) ?>" placeholder="空间字节，1GB=1073741824">
            <input name="traffic_limit" type="number" min="0" value="<?= e(old('traffic_limit', '10737418240')) ?>" placeholder="流量字节，0 表示不限">
            <input name="single_file_limit" type="number" min="0" value="<?= e(old('single_file_limit', '104857600')) ?>" placeholder="单文件限制字节">
            <input name="subsite_limit" type="number" min="0" value="<?= e(old('subsite_limit', '1')) ?>" placeholder="分站数量">
            <div class="m-status-row">
                <select name="status"><option value="1">启用</option><option value="0">停用</option></select>
                <input name="sort_order" type="number" value="<?= e(old('sort_order', '0')) ?>" placeholder="排序">
            </div>
            <label class="m-checkline"><input type="checkbox" name="allow_image" checked> 图片上传</label>
            <label class="m-checkline"><input type="checkbox" name="allow_netdisk" checked> 个人网盘</label>
            <label class="m-checkline"><input type="checkbox" name="allow_share" checked> 分享仓库</label>
            <label class="m-checkline"><input type="checkbox" name="allow_api"> API</label>
            <label class="m-checkline"><input type="checkbox" name="allow_monitor"> 服务器管家</label>
            <label class="m-checkline"><input type="checkbox" name="allow_subsite"> 分站</label>
            <textarea name="description" maxlength="1000" placeholder="套餐说明"><?= e(old('description')) ?></textarea>
            <button type="submit">保存套餐</button>
        </form>
    </details>

    <section class="m-card">
        <div class="m-section-head"><div><span>List</span><h2>套餐列表</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索套餐名称、周期、价格或权益" data-mobile-filter-input="#adminMobilePackagesList">
        </label>
        <div class="m-list" id="adminMobilePackagesList">
            <?php foreach ($packages as $package): ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="badge-dollar-sign"></i>
                    <div>
                        <strong><?= e($package['name']) ?></strong>
                        <span>¥<?= e(number_format((float) $package['price'], 2)) ?> · <?= e($package['duration_type']) ?> · <?= e((int) $package['duration_days']) ?> 天</span>
                    </div>
                    <span class="m-badge <?= !empty($package['status']) ? 'ok' : 'bad' ?>"><?= !empty($package['status']) ? '启用' : '停用' ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted">空间 <?= e(format_bytes((int) $package['storage_limit'])) ?></span>
                        <span class="m-badge muted">流量 <?= e((int) $package['traffic_limit'] > 0 ? format_bytes((int) $package['traffic_limit']) : '不限') ?></span>
                        <span class="m-badge muted">单文件 <?= e(format_bytes((int) $package['single_file_limit'])) ?></span>
                    </div>
                    <details class="m-fold">
                        <summary>编辑套餐</summary>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/packages/save') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($package['id']) ?>">
                            <input name="name" value="<?= e($package['name']) ?>" maxlength="80" required>
                            <input name="price" type="number" step="0.01" min="0" value="<?= e($package['price']) ?>">
                            <div class="m-status-row">
                                <select name="duration_type">
                                    <?php foreach (['month' => '月付', 'quarter' => '季度', 'year' => '年付', 'forever' => '永久'] as $value => $label): ?>
                                        <option value="<?= e($value) ?>" <?= $package['duration_type'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input name="duration_days" type="number" min="0" value="<?= e($package['duration_days']) ?>">
                            </div>
                            <input name="storage_limit" type="number" min="0" value="<?= e($package['storage_limit']) ?>">
                            <input name="traffic_limit" type="number" min="0" value="<?= e($package['traffic_limit']) ?>">
                            <input name="single_file_limit" type="number" min="0" value="<?= e($package['single_file_limit']) ?>">
                            <input name="subsite_limit" type="number" min="0" value="<?= e(isset($package['subsite_limit']) ? $package['subsite_limit'] : 0) ?>">
                            <div class="m-status-row">
                                <select name="status"><option value="1" <?= !empty($package['status']) ? 'selected' : '' ?>>启用</option><option value="0" <?= empty($package['status']) ? 'selected' : '' ?>>停用</option></select>
                                <input name="sort_order" type="number" value="<?= e($package['sort_order']) ?>">
                            </div>
                            <?php foreach (['allow_image' => '图片上传', 'allow_netdisk' => '个人网盘', 'allow_share' => '分享仓库', 'allow_api' => 'API', 'allow_monitor' => '服务器管家', 'allow_subsite' => '分站'] as $key => $label): ?>
                                <label class="m-checkline"><input type="checkbox" name="<?= e($key) ?>" <?= !empty($package[$key]) ? 'checked' : '' ?>> <?= e($label) ?></label>
                            <?php endforeach; ?>
                            <textarea name="description" maxlength="1000"><?= e(isset($package['description']) ? $package['description'] : '') ?></textarea>
                            <button class="ghost" type="submit">保存调整</button>
                        </form>
                    </details>
                    <div class="m-inline-actions">
                        <form method="post" action="<?= url('admin/m/packages/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($package['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个套餐吗？已有用户仍会保留原套餐 ID，请谨慎操作。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的套餐。</div>
            <?php if (!$packages): ?><div class="m-empty">暂无套餐。</div><?php endif; ?>
        </div>
    </section>
</section>
