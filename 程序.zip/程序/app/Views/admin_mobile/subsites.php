<?php
$target = isset($domainConfig['cname_target']) ? $domainConfig['cname_target'] : '';
$diagnostic = flash('subsite_domain_diagnostic');
?>
<section class="m-page">
    <header class="m-page-head">
        <div>
            <span>Subsites</span>
            <h1>分站管理</h1>
            <p>CNAME 接入目标：<?= e($target ?: '未配置') ?></p>
        </div>
        <a class="m-pill" href="<?= url('admin/m/settings') ?>">设置</a>
    </header>

    <?php if (is_array($diagnostic)): ?>
        <section class="m-card">
            <div class="m-section-head">
                <div>
                    <span>Domain Check</span>
                    <h2>域名检测结果</h2>
                </div>
            </div>
            <div class="m-note">
                <?= !empty($diagnostic['ok']) ? '检测通过，域名接入正常。' : '检测完成，仍有步骤未通过。' ?>
                <?php if (!empty($diagnostic['host'])): ?>当前检测域名：<?= e($diagnostic['host']) ?><?php endif; ?>
            </div>
            <?php if (!empty($diagnostic['checks']) && is_array($diagnostic['checks'])): ?>
                <div class="m-list">
                    <?php foreach ($diagnostic['checks'] as $check): ?>
                        <article class="m-list-item tall">
                            <i data-lucide="<?= !empty($check['status']) && $check['status'] === 'ok' ? 'check-circle-2' : 'alert-circle' ?>"></i>
                            <div>
                                <strong><?= e(isset($check['label']) ? $check['label'] : '检测项') ?></strong>
                                <span><?= e(isset($check['message']) ? $check['message'] : '') ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <nav class="m-anchor-nav m-chip-list" aria-label="分站管理分区">
        <a href="#adminSubsiteList">分站列表</a>
        <a href="<?= url('admin/m/settings') ?>">域名配置</a>
        <a href="<?= url('admin/m/menu') ?>">全部功能</a>
    </nav>

    <section class="m-card" id="adminSubsiteList">
        <div class="m-section-head">
            <div><span>Review</span><h2>分站列表</h2></div>
            <a href="<?= url('admin/m/settings') ?>">域名配置</a>
        </div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索分站名、用户、域名或状态" data-mobile-filter-input="#adminMobileSubsitesList">
        </label>
        <div class="m-list" id="adminMobileSubsitesList">
            <?php foreach ($subsites as $site): ?>
                <?php
                $publicUrl = $service->publicUrlFor($site);
                $customDomainStatus = isset($site['custom_domain_status']) ? $site['custom_domain_status'] : 'none';
                ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="globe-2"></i>
                    <div>
                        <strong><?= e($site['name']) ?></strong>
                        <span><?= e($site['username'] ?: '-') ?> · <?= e($site['status']) ?> · <?= e($site['platform_domain']) ?></span>
                        <?php if (!empty($site['custom_domain'])): ?>
                            <span>自有域名：<?= e($site['custom_domain']) ?> · <?= e($customDomainStatus) ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ($publicUrl !== ''): ?><a href="<?= e($publicUrl) ?>" target="_blank">访问</a><?php endif; ?>

                    <div class="m-inline-actions">
                        <details class="m-fold">
                            <summary>审核设置</summary>
                            <form class="m-mini-form" method="post" action="<?= url('admin/m/subsites/status') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                                <div class="m-status-row">
                                    <select name="status" aria-label="分站状态">
                                        <?php foreach (['pending' => '待审核', 'active' => '启用', 'suspended' => '停用', 'rejected' => '拒绝'] as $value => $label): ?>
                                            <option value="<?= e($value) ?>" <?= $site['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <select name="custom_domain_status" aria-label="域名状态">
                                        <?php foreach (['none' => '未绑定', 'pending' => '待验证', 'verified' => '已验证', 'failed' => '验证失败'] as $value => $label): ?>
                                            <option value="<?= e($value) ?>" <?= $customDomainStatus === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <input name="admin_remark" value="<?= e(isset($site['admin_remark']) ? $site['admin_remark'] : '') ?>" placeholder="审核备注">
                                <button type="submit">保存状态</button>
                            </form>
                        </details>
                        <form method="post" action="<?= url('admin/m/subsites/check') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                            <button class="m-button ghost" type="submit">检测域名</button>
                        </form>
                        <?php if ($publicUrl !== ''): ?><button class="m-button ghost" type="button" data-copy-text="<?= e($publicUrl) ?>">复制访问地址</button><?php endif; ?>
                        <form method="post" action="<?= url('admin/m/subsites/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($site['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除这个分站吗？访问日志也会同步清理。">删除</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的分站。</div>
            <?php if (!$subsites): ?><div class="m-empty">暂无分站。</div><?php endif; ?>
        </div>
    </section>
</section>
