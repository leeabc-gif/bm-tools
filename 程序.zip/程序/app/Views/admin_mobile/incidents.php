<?php
$items = isset($items) && is_array($items) ? $items : [];
$stats = isset($stats) ? $stats : ['api_failed_today' => 0, 'backup_failed' => 0, 'command_risky_today' => 0, 'upload_failed_today' => 0];
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Incident</span><h1>异常事件</h1><p>手机端集中排查上传失败、API、备份和命令审计异常。</p></div>
        <a class="m-pill" href="<?= url('admin/m/logs') ?>">日志</a>
    </header>

    <section class="m-stat-grid">
        <article><span>今日 API 失败</span><strong><?= e($stats['api_failed_today']) ?></strong></article>
        <article><span>备份失败</span><strong><?= e($stats['backup_failed']) ?></strong></article>
        <article><span>命令标记</span><strong><?= e($stats['command_risky_today']) ?></strong></article>
        <article><span>上传失败</span><strong><?= e($stats['upload_failed_today']) ?></strong></article>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Timeline</span><h2>最近事件</h2></div><a href="<?= url('admin/m/logs') ?>">日志</a></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索事件、原因、时间或级别" data-mobile-filter-input="#adminMobileIncidentsList">
        </label>
        <div class="m-alert-list" id="adminMobileIncidentsList">
            <?php foreach ($items as $item): ?>
                <a class="m-alert-card <?= e(isset($item['level']) ? $item['level'] : 'soft') ?>" href="<?= url(isset($item['url']) ? $item['url'] : 'admin/m/incidents') ?>" data-mobile-filter-item>
                    <i data-lucide="<?= e(isset($item['icon']) ? $item['icon'] : 'bell') ?>"></i>
                    <span>
                        <strong><?= e(isset($item['title']) ? $item['title'] : '事件') ?></strong>
                        <small><?= e(isset($item['desc']) ? $item['desc'] : '') ?></small>
                        <small><?= e(isset($item['time']) ? $item['time'] : '-') ?></small>
                    </span>
                    <b><?= e(isset($item['level']) ? $item['level'] : '') ?></b>
                </a>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的异常事件。</div>
            <?php if (!$items): ?><div class="m-empty">暂无异常事件。</div><?php endif; ?>
        </div>
    </section>
</section>
