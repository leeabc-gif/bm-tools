<?php
$coupons = isset($coupons) ? $coupons : [];
$packages = isset($packages) ? $packages : [];
$redemptions = isset($redemptions) ? $redemptions : [];
$selectedPackageIds = function ($coupon) {
    $raw = isset($coupon['package_ids']) ? trim((string) $coupon['package_ids']) : '';
    if ($raw === '') return [];
    return array_filter(array_map('intval', explode(',', $raw)));
};
?>
<section class="m-page">
    <header class="m-page-head">
        <div><span>Marketing</span><h1>营销活动</h1><p>手机端可配置优惠码、折扣力度、有效期和套餐范围。</p></div>
        <a class="m-pill" href="<?= url('admin/m/packages') ?>">套餐</a>
    </header>

    <section class="m-stat-grid two">
        <article><span>活动</span><strong><?= e($stats['total']) ?></strong><small>启用 <?= e($stats['enabled']) ?></small></article>
        <article><span>已使用</span><strong><?= e($stats['used']) ?></strong><small>优惠 ¥<?= e(number_format((float) $stats['discount'], 2)) ?></small></article>
    </section>

    <details class="m-fold">
        <summary>新增优惠码</summary>
        <form class="m-mini-form" method="post" action="<?= url('admin/m/coupons/save') ?>">
            <?= csrf_field() ?>
            <input name="title" value="<?= e(old('title')) ?>" maxlength="120" required placeholder="活动名称">
            <input name="code" value="<?= e(old('code')) ?>" maxlength="40" required placeholder="优惠码，例如 NEWUSER">
            <div class="m-status-row">
                <select name="discount_type"><option value="fixed">立减金额</option><option value="percent">折扣比例</option></select>
                <input name="discount_value" type="number" step="0.01" min="0" value="<?= e(old('discount_value', '5')) ?>" placeholder="优惠力度">
            </div>
            <input name="min_amount" type="number" step="0.01" min="0" value="<?= e(old('min_amount', '0')) ?>" placeholder="最低订单金额">
            <select name="package_scope">
                <option value="all">全部套餐</option>
                <option value="include">仅指定套餐</option>
                <option value="exclude">排除指定套餐</option>
            </select>
            <select name="package_ids[]" multiple>
                <?php foreach ($packages as $package): ?><option value="<?= e($package['id']) ?>"><?= e($package['name']) ?></option><?php endforeach; ?>
            </select>
            <div class="m-status-row">
                <input name="start_at" type="datetime-local" value="<?= e(old('start_at')) ?>">
                <input name="end_at" type="datetime-local" value="<?= e(old('end_at')) ?>">
            </div>
            <div class="m-status-row">
                <input name="total_limit" type="number" min="0" value="<?= e(old('total_limit', '0')) ?>" placeholder="总次数，0 不限">
                <input name="user_limit" type="number" min="0" value="<?= e(old('user_limit', '1')) ?>" placeholder="每用户次数">
            </div>
            <div class="m-status-row">
                <select name="status"><option value="1">启用</option><option value="0">停用</option></select>
                <input name="sort_order" type="number" value="<?= e(old('sort_order', '0')) ?>" placeholder="排序">
            </div>
            <label class="m-checkline"><input type="checkbox" name="first_order_only"> 仅首单可用</label>
            <textarea name="description" maxlength="500" placeholder="活动说明"><?= e(old('description')) ?></textarea>
            <button type="submit">保存活动</button>
        </form>
    </details>

    <section class="m-card">
        <div class="m-section-head"><div><span>Coupons</span><h2>活动列表</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索活动名、优惠码、范围或状态" data-mobile-filter-input="#adminMobileCouponsList">
        </label>
        <div class="m-list" id="adminMobileCouponsList">
            <?php foreach ($coupons as $coupon): ?>
                <?php $ids = $selectedPackageIds($coupon); ?>
                <article class="m-list-item tall" data-mobile-filter-item>
                    <i data-lucide="percent"></i>
                    <div>
                        <strong><?= e($coupon['title']) ?></strong>
                        <span><?= e($coupon['code']) ?> · <?= e($coupon['discount_type'] === 'percent' ? $coupon['discount_value'] . '%' : '¥' . number_format((float) $coupon['discount_value'], 2)) ?> · 满 ¥<?= e(number_format((float) $coupon['min_amount'], 2)) ?></span>
                    </div>
                    <span class="m-badge <?= !empty($coupon['status']) ? 'ok' : 'bad' ?>"><?= !empty($coupon['status']) ? '启用' : '停用' ?></span>
                    <div class="m-meta-grid">
                        <span class="m-badge muted"><?= e($coupon['package_scope']) ?></span>
                        <span class="m-badge muted">总限 <?= e((int) $coupon['total_limit']) ?></span>
                        <span class="m-badge muted">用户限 <?= e((int) $coupon['user_limit']) ?></span>
                        <?php if (!empty($coupon['first_order_only'])): ?><span class="m-badge warn">首单</span><?php endif; ?>
                    </div>
                    <details class="m-fold">
                        <summary>编辑活动</summary>
                        <form class="m-mini-form" method="post" action="<?= url('admin/m/coupons/save') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($coupon['id']) ?>">
                            <input name="title" value="<?= e($coupon['title']) ?>" maxlength="120" required>
                            <input name="code" value="<?= e($coupon['code']) ?>" maxlength="40" required>
                            <div class="m-status-row">
                                <select name="discount_type"><option value="fixed" <?= $coupon['discount_type'] === 'fixed' ? 'selected' : '' ?>>立减金额</option><option value="percent" <?= $coupon['discount_type'] === 'percent' ? 'selected' : '' ?>>折扣比例</option></select>
                                <input name="discount_value" type="number" step="0.01" min="0" value="<?= e($coupon['discount_value']) ?>">
                            </div>
                            <input name="min_amount" type="number" step="0.01" min="0" value="<?= e($coupon['min_amount']) ?>">
                            <select name="package_scope">
                                <?php foreach (['all' => '全部套餐', 'include' => '仅指定套餐', 'exclude' => '排除指定套餐'] as $value => $label): ?>
                                    <option value="<?= e($value) ?>" <?= $coupon['package_scope'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select name="package_ids[]" multiple>
                                <?php foreach ($packages as $package): ?><option value="<?= e($package['id']) ?>" <?= in_array((int) $package['id'], $ids, true) ? 'selected' : '' ?>><?= e($package['name']) ?></option><?php endforeach; ?>
                            </select>
                            <div class="m-status-row">
                                <input name="start_at" value="<?= e($coupon['start_at']) ?>" placeholder="开始时间">
                                <input name="end_at" value="<?= e($coupon['end_at']) ?>" placeholder="结束时间">
                            </div>
                            <div class="m-status-row">
                                <input name="total_limit" type="number" min="0" value="<?= e($coupon['total_limit']) ?>">
                                <input name="user_limit" type="number" min="0" value="<?= e($coupon['user_limit']) ?>">
                            </div>
                            <div class="m-status-row">
                                <select name="status"><option value="1" <?= !empty($coupon['status']) ? 'selected' : '' ?>>启用</option><option value="0" <?= empty($coupon['status']) ? 'selected' : '' ?>>停用</option></select>
                                <input name="sort_order" type="number" value="<?= e($coupon['sort_order']) ?>">
                            </div>
                            <label class="m-checkline"><input type="checkbox" name="first_order_only" <?= !empty($coupon['first_order_only']) ? 'checked' : '' ?>> 仅首单可用</label>
                            <textarea name="description" maxlength="500"><?= e(isset($coupon['description']) ? $coupon['description'] : '') ?></textarea>
                            <button class="ghost" type="submit">保存调整</button>
                        </form>
                    </details>
                    <div class="m-inline-actions">
                        <form method="post" action="<?= url('admin/m/coupons/delete') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($coupon['id']) ?>">
                            <button class="m-button danger" type="submit" data-mobile-confirm="确认删除或停用这个营销活动吗？已有使用记录会自动改为停用。">删除/停用</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的营销活动。</div>
            <?php if (!$coupons): ?><div class="m-empty">暂无营销活动。</div><?php endif; ?>
        </div>
    </section>

    <section class="m-card">
        <div class="m-section-head"><div><span>Redemptions</span><h2>最近使用</h2></div></div>
        <label class="m-list-search">
            <i data-lucide="search"></i>
            <input type="search" placeholder="搜索优惠码、用户或订单" data-mobile-filter-input="#adminMobileCouponRedemptionsList">
        </label>
        <div class="m-list" id="adminMobileCouponRedemptionsList">
            <?php foreach ($redemptions as $row): ?>
                <article class="m-list-item" data-mobile-filter-item>
                    <i data-lucide="receipt-text"></i>
                    <div><strong><?= e($row['coupon_code'] ?: '-') ?></strong><span><?= e($row['username'] ?: '-') ?> · 优惠 ¥<?= e(number_format((float) $row['discount_amount'], 2)) ?> · <?= e($row['used_at']) ?></span></div>
                </article>
            <?php endforeach; ?>
            <div class="m-empty" data-mobile-filter-empty hidden>没有匹配的使用记录。</div>
            <?php if (!$redemptions): ?><div class="m-empty">暂无使用记录。</div><?php endif; ?>
        </div>
    </section>
</section>
