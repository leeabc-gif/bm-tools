<?php
$catKey = isset($item['category']) && isset($categories[$item['category']]) ? $item['category'] : 'platform';
$cat = $categories[$catKey];
$tags = array_filter(array_map('trim', explode(',', isset($item['tags']) ? $item['tags'] : '')));
$content = (string) $item['content'];
$documents = isset($siteDocuments) && is_array($siteDocuments) ? $siteDocuments : [];
if ((isset($item['content_format']) ? $item['content_format'] : 'html') !== 'html') {
    $content = nl2br(e($content));
}
?>

<section class="notice-space-page notice-space-detail">
    <section class="notice-space-detail-hero">
        <div class="space-shell">
            <a class="notice-space-back" href="<?= url('announcements') ?>">
                <i data-lucide="arrow-left"></i>
                <span>返回公告中心</span>
            </a>

            <header class="notice-space-article-head">
                <div class="notice-space-meta">
                    <span><?= e($cat['name']) ?></span>
                    <?php if (!empty($item['is_top'])): ?><span>置顶</span><?php endif; ?>
                    <time><?= e($item['published_at'] ?: $item['created_at']) ?></time>
                    <span><?= e((int) $item['view_count']) ?> 次阅读</span>
                </div>
                <h1><?= e($item['title']) ?></h1>
                <?php if (!empty($item['summary'])): ?><p><?= e($item['summary']) ?></p><?php endif; ?>
                <?php if ($tags): ?>
                    <div class="notice-space-tags">
                        <?php foreach ($tags as $tag): ?><span>#<?= e($tag) ?></span><?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </header>
        </div>
    </section>

    <section class="space-shell notice-space-detail-layout">
        <article class="notice-space-article">
            <?php if (!empty($item['cover_image'])): ?>
                <figure class="notice-space-article-cover">
                    <img src="<?= e($item['cover_image']) ?>" alt="<?= e($item['title']) ?>">
                </figure>
            <?php endif; ?>

            <section class="notice-space-article-body">
                <?= $content ?>
            </section>
        </article>

        <aside class="notice-space-sidebar notice-space-detail-sidebar">
            <section class="notice-space-card">
                <p class="space-eyebrow">文章信息</p>
                <div class="notice-space-info-list">
                    <p><span>分类</span><b><?= e($cat['name']) ?></b></p>
                    <p><span>发布时间</span><b><?= e($item['published_at'] ?: $item['created_at']) ?></b></p>
                    <p><span>阅读次数</span><b><?= e((int) $item['view_count']) ?></b></p>
                </div>
            </section>

            <?php if ($documents): ?>
            <section class="notice-space-card">
                <p class="space-eyebrow">相关文档</p>
                <div class="notice-space-docs">
                    <?php foreach ($documents as $doc): ?>
                        <a href="<?= e($doc['url']) ?>">
                            <i data-lucide="<?= e(isset($doc['icon']) ? $doc['icon'] : 'file-text') ?>"></i>
                            <span><?= e($doc['title']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <section class="notice-space-card">
                <p class="space-eyebrow">继续浏览</p>
                <a class="space-button space-button-dark notice-space-wide-button" href="<?= url('announcements') ?>">查看全部公告</a>
            </section>
        </aside>
    </section>
</section>
