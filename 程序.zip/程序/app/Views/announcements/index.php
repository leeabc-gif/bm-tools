<?php
$currentCategory = isset($currentCategory) ? $currentCategory : '';
$keyword = isset($keyword) ? $keyword : '';
$categoryName = $currentCategory && isset($categories[$currentCategory]) ? $categories[$currentCategory]['name'] : '全部公告';
$featured = $announcements ? $announcements[0] : null;
$documents = isset($siteDocuments) && is_array($siteDocuments) ? $siteDocuments : [];
$currentUser = \App\Core\Auth::user();
$totalCount = isset($counts['all']) ? (int) $counts['all'] : count($announcements);
$currentCount = count($announcements);
$latestDate = $announcements ? ($announcements[0]['published_at'] ?: $announcements[0]['created_at']) : '-';
if (!function_exists('announcement_excerpt')) {
function announcement_excerpt($item)
{
    $summary = isset($item['summary']) ? trim($item['summary']) : '';
    if ($summary !== '') {
        return $summary;
    }
    return text_limit(trim(strip_tags($item['content'])), 140);
}
}
?>

<section class="notice-space-page notice-space-index">
    <section class="notice-space-hero">
        <div class="space-shell notice-space-hero-inner">
            <div class="notice-space-copy">
                <p class="space-eyebrow">公告中心</p>
                <h1>平台更新、使用教程和维护记录。</h1>
                <p>围绕图床、个人网盘、分享仓库、对象存储和服务器状态整理关键说明。重要变更、维护计划、使用方法都放在这里，方便随时查阅。</p>
                <div class="notice-space-actions">
                    <?php if ($currentUser): ?>
                        <a class="space-button space-button-dark" href="<?= url('dashboard') ?>">进入个人中心</a>
                    <?php else: ?>
                        <a class="space-button space-button-dark" href="<?= url('login') ?>">登录查看</a>
                    <?php endif; ?>
                    <a class="space-button space-button-ghost" href="<?= url('status') ?>">查看服务器状态</a>
                </div>
            </div>
            <aside class="notice-space-summary" aria-label="公告概览">
                <span>当前分类</span>
                <strong><?= e($categoryName) ?></strong>
                <div>
                    <p><b><?= e($totalCount) ?></b><small>全部公告</small></p>
                    <p><b><?= e($currentCount) ?></b><small>当前结果</small></p>
                    <p><b><?= e($latestDate) ?></b><small>最近更新</small></p>
                </div>
            </aside>
        </div>
    </section>

    <section class="notice-space-tools">
        <div class="space-shell notice-space-tools-inner">
            <form method="get" action="<?= url('announcements') ?>" class="notice-space-search">
                <?php if ($currentCategory): ?><input type="hidden" name="category" value="<?= e($currentCategory) ?>"><?php endif; ?>
                <label>
                    <i data-lucide="search"></i>
                    <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索公告、标签或正文">
                </label>
                <button class="space-button space-button-dark" type="submit">搜索</button>
                <?php if ($keyword || $currentCategory): ?><a class="space-button space-button-ghost" href="<?= url('announcements') ?>">清除</a><?php endif; ?>
            </form>

            <nav class="notice-space-categories" aria-label="公告分类">
                <a class="<?= $currentCategory === '' ? 'active' : '' ?>" href="<?= url('announcements') ?>">
                    <span>全部公告</span><b><?= e(isset($counts['all']) ? $counts['all'] : 0) ?></b>
                </a>
                <?php foreach ($categories as $key => $meta): ?>
                    <a class="<?= $currentCategory === $key ? 'active' : '' ?>" href="<?= url('announcements?category=' . $key) ?>">
                        <span><?= e($meta['name']) ?></span><b><?= e(isset($counts[$key]) ? $counts[$key] : 0) ?></b>
                    </a>
                <?php endforeach; ?>
            </nav>
        </div>
    </section>

    <section class="space-shell notice-space-layout">
        <main class="notice-space-main">
        <?php if ($featured): ?>
            <?php
            $featuredCat = isset($featured['category']) && isset($categories[$featured['category']]) ? $categories[$featured['category']] : $categories['platform'];
            ?>
            <article class="notice-space-featured">
                <div class="notice-space-meta">
                    <span><?= e($featuredCat['name']) ?></span>
                    <?php if (!empty($featured['is_top'])): ?><span>置顶</span><?php endif; ?>
                    <time><?= e($featured['published_at'] ?: $featured['created_at']) ?></time>
                </div>
                <h2><a href="<?= url('announcements/' . $featured['id']) ?>"><?= e($featured['title']) ?></a></h2>
                <p><?= e(announcement_excerpt($featured)) ?></p>
                <a class="space-button space-button-ghost" href="<?= url('announcements/' . $featured['id']) ?>">阅读全文</a>
            </article>
        <?php endif; ?>

        <section class="notice-space-section-head">
            <div>
                <p class="space-eyebrow">公告列表</p>
                <h2><?= e($categoryName) ?></h2>
            </div>
            <span><?= e($currentCount) ?> 条内容</span>
        </section>

        <section class="notice-space-feed">
            <?php if (!$announcements): ?>
                <article class="notice-space-empty">
                    <i data-lucide="inbox"></i>
                    <b>暂时没有公告</b>
                    <p>换一个关键词，或切换到其他分类看看。</p>
                </article>
            <?php endif; ?>

            <?php foreach ($announcements as $item): ?>
                <?php
                $cat = isset($item['category']) && isset($categories[$item['category']]) ? $categories[$item['category']] : $categories['platform'];
                $tags = array_filter(array_map('trim', explode(',', isset($item['tags']) ? $item['tags'] : '')));
                ?>
                <article class="notice-space-post <?= !empty($item['is_top']) ? 'pinned' : '' ?> <?= empty($item['cover_image']) ? 'no-cover' : '' ?>">
                    <?php if (!empty($item['cover_image'])): ?>
                        <a class="notice-space-cover" href="<?= url('announcements/' . $item['id']) ?>">
                            <img src="<?= e($item['cover_image']) ?>" alt="<?= e($item['title']) ?>">
                        </a>
                    <?php endif; ?>
                    <div class="notice-space-post-body">
                        <div class="notice-space-meta">
                            <span><?= e($cat['name']) ?></span>
                            <?php if (!empty($item['is_top'])): ?><span>置顶</span><?php endif; ?>
                            <time><?= e($item['published_at'] ?: $item['created_at']) ?></time>
                        </div>
                        <h3><a href="<?= url('announcements/' . $item['id']) ?>"><?= e($item['title']) ?></a></h3>
                        <p><?= e(announcement_excerpt($item)) ?></p>
                        <div class="notice-space-post-foot">
                            <div class="notice-space-tags">
                                <?php foreach (array_slice($tags, 0, 3) as $tag): ?><span>#<?= e($tag) ?></span><?php endforeach; ?>
                            </div>
                            <a href="<?= url('announcements/' . $item['id']) ?>">继续阅读</a>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    </main>

    <aside class="notice-space-sidebar">
        <section class="notice-space-card">
            <p class="space-eyebrow">关于本站</p>
            <h3><?= e(setting('site_name', app_brand_name())) ?></h3>
            <p>这里集中展示平台公告、教程、维护记录和产品说明。内容会按照分类持续整理，便于用户快速找到需要的信息。</p>
            <small><?= e($totalCount) ?> 条公告</small>
        </section>

        <section class="notice-space-card">
            <p class="space-eyebrow">快速分类</p>
            <div class="notice-space-side-links">
                <a class="<?= $currentCategory === '' ? 'active' : '' ?>" href="<?= url('announcements') ?>">
                    <span>全部公告</span><b><?= e(isset($counts['all']) ? $counts['all'] : 0) ?></b>
                </a>
                <?php foreach ($categories as $key => $meta): ?>
                    <a class="<?= $currentCategory === $key ? 'active' : '' ?>" href="<?= url('announcements?category=' . $key) ?>">
                        <span><?= e($meta['name']) ?></span><b><?= e(isset($counts[$key]) ? $counts[$key] : 0) ?></b>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>

        <?php if ($documents): ?>
            <section class="notice-space-card">
                <p class="space-eyebrow">相关文档</p>
                <div class="notice-space-docs">
                    <?php foreach ($documents as $doc): ?>
                        <a href="<?= e($doc['url']) ?>">
                            <i data-lucide="<?= e(isset($doc['icon']) ? $doc['icon'] : 'file-text') ?>"></i>
                            <span><?= e($doc['title']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($announcements): ?>
            <section class="notice-space-card">
                <p class="space-eyebrow">最近更新</p>
                <div class="notice-space-recent">
                    <?php foreach (array_slice($announcements, 0, 5) as $item): ?>
                        <a href="<?= url('announcements/' . $item['id']) ?>">
                            <b><?= e($item['title']) ?></b>
                            <span><?= e($item['published_at'] ?: $item['created_at']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
    </aside>
    </section>
</section>
