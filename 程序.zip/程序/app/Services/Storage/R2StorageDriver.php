<?php
namespace App\Services\Storage;

class R2StorageDriver extends S3StorageDriver
{
    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || empty($this->config['endpoint'])) {
            return ['success' => false, 'message' => 'Cloudflare R2 需要填写 Access Key ID、Secret Access Key、Bucket 和账号级 Endpoint，例如 https://<ACCOUNT_ID>.r2.cloudflarestorage.com。'];
        }
        $host = $this->normalizedHost($this->config['endpoint']);
        if ($host === '' || stripos($host, 'r2.cloudflarestorage.com') === false) {
            return ['success' => false, 'message' => 'Cloudflare R2 Endpoint 应填写账号级 S3 API 地址，例如 https://<ACCOUNT_ID>.r2.cloudflarestorage.com，不要填写公开访问域名。'];
        }
        return ['success' => true, 'message' => 'Cloudflare R2 基础配置完整，Region 将按官方 S3 兼容要求使用 auto。'];
    }

    protected function defaultRegion()
    {
        return 'auto';
    }

    protected function driverName()
    {
        return 'r2';
    }

    protected function useVirtualHostedStyle($host, $bucket)
    {
        return false;
    }
}
