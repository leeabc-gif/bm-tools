<?php
namespace App\Services\Storage;

class KodoStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!function_exists('curl_init') || !class_exists('\CURLFile')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl/CURLFile 能力，无法连接七牛云 Kodo。');
        }
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket'])) {
            throw new \RuntimeException('七牛上传失败：AccessKey、SecretKey 或 Bucket 未填写完整。');
        }
        $objectKey = $this->objectKey($objectKey);
        $policy = [
            'scope' => $this->config['bucket'] . ':' . $objectKey,
            'deadline' => time() + 3600,
            'returnBody' => '{"key":"$(key)","hash":"$(etag)","size":$(fsize)}',
        ];
        $encodedPolicy = $this->base64Url(json_encode($policy, JSON_UNESCAPED_SLASHES));
        $sign = hash_hmac('sha1', $encodedPolicy, $this->config['secret_key'], true);
        $token = $this->config['access_key'] . ':' . $this->base64Url($sign) . ':' . $encodedPolicy;

        $errors = [];
        $hosts = $this->uploadHosts();
        foreach ($hosts as $uploadHost) {
            try {
                $this->postUpload($uploadHost, $token, $objectKey, $localPath, isset($options['mime']) ? $options['mime'] : 'application/octet-stream');
                return [
                    'path' => $objectKey,
                    'url' => $this->url($objectKey),
                    'driver' => 'kodo',
                ];
            } catch (\RuntimeException $e) {
                $message = $e->getMessage();
                $errors[] = $message;
                if (!$this->shouldTryNextHost($message)) {
                    break;
                }
            }
        }

        $last = $errors ? end($errors) : '未知错误。';
        $hint = '请确认空间所属 Region 与上传域名匹配；可在 Region 填 z0/cn-east-2/z1/z2/na0/as0/ap-southeast-2/ap-southeast-3，或在 Endpoint 直接填写七牛官方上传域名。';
        throw new \RuntimeException('七牛上传失败：' . $last . ' 已尝试上传域名：' . implode('，', $hosts) . '。' . $hint);
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $entry = $this->base64Url($this->config['bucket'] . ':' . $objectKey);
        $path = '/delete/' . $entry;
        $host = $this->rsHost();
        $sign = hash_hmac('sha1', $path . "\n", $this->config['secret_key'], true);
        $token = 'QBox ' . $this->config['access_key'] . ':' . $this->base64Url($sign);
        $this->curl('POST', $host . $path, ['Authorization: ' . $token, 'Content-Type: application/x-www-form-urlencoded'], '');
        return true;
    }

    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || empty($this->config['domain'])) {
            return ['success' => false, 'message' => '七牛云 Kodo 需要填写 AccessKey、SecretKey、Bucket 和访问域名。访问域名是绑定到空间的外链域名，不是上传域名。'];
        }
        if (!function_exists('curl_init') || !class_exists('\CURLFile')) {
            return ['success' => false, 'message' => '当前 PHP 环境缺少 curl/CURLFile，七牛云服务端上传无法执行。请先安装或启用 PHP curl 扩展。'];
        }
        if (!empty($this->config['region']) && !$this->regionKnown($this->config['region'])) {
            return ['success' => false, 'message' => '七牛 Region 建议填写 z0、cn-east-2、z1、z2、na0、as0、ap-southeast-2 或 ap-southeast-3。也可以留空，然后在 Endpoint 直接填写官方上传域名。'];
        }
        if (!empty($this->config['endpoint'])) {
            $host = $this->normalizedHost($this->config['endpoint']);
            if ($host && strpos($host, 'qiniup') === false && strpos($host, 'qbox') === false && strpos($host, 'kodo-accelerate') === false) {
                return ['success' => false, 'message' => '七牛 Endpoint 必须是上传域名，例如 up.qiniup.com、up-z1.qiniup.com、upload-z2.qiniup.com；访问域名请填写到“自定义访问域名”。'];
            }
        }
        $hosts = $this->uploadHosts();
        return ['success' => true, 'message' => 'Kodo 基础配置完整。真实测试将按顺序尝试上传域名：' . implode('，', $hosts) . '。'];
    }

    protected function postUpload($uploadHost, $token, $objectKey, $localPath, $mime)
    {
        $uploadHost = rtrim($uploadHost, '/');
        $ch = curl_init($uploadHost);
        $post = [
            'token' => $token,
            'key' => $objectKey,
            'file' => new \CURLFile($localPath, $mime ?: 'application/octet-stream', basename($objectKey)),
        ];
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $post,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CONNECTTIMEOUT => 12,
            CURLOPT_TIMEOUT => 90,
            CURLOPT_USERAGENT => 'BMTOOLS-KodoStorage/1.1',
        ]);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $error) {
            throw new \RuntimeException($uploadHost . ' 网络请求失败：' . $error);
        }
        $decoded = json_decode((string) $body, true);
        if ($code < 200 || $code >= 300) {
            throw new \RuntimeException($uploadHost . ' 返回 HTTP ' . $code . '：' . $this->describeQiniuError($body, $decoded));
        }
        if (!is_array($decoded) || empty($decoded['key'])) {
            throw new \RuntimeException($uploadHost . ' 上传返回异常：' . text_limit((string) $body, 500));
        }
    }

    protected function uploadHosts()
    {
        $hosts = [];
        $endpoint = $this->endpoint(true);
        if ($endpoint !== '') {
            $hosts[] = $endpoint;
        }

        $region = $this->normalizeRegion(isset($this->config['region']) ? $this->config['region'] : '');
        foreach ($this->regionUploadHosts($region) as $host) {
            $hosts[] = $host;
        }

        if ($endpoint === '' && $region === '') {
            foreach (['https://up.qiniup.com', 'https://upload.qiniup.com'] as $host) {
                $hosts[] = $host;
            }
        }

        $unique = [];
        foreach ($hosts as $host) {
            $host = rtrim((string) $host, '/');
            if ($host === '') {
                continue;
            }
            if (!preg_match('#^https?://#i', $host)) {
                $host = 'https://' . $host;
            }
            $key = strtolower($host);
            $unique[$key] = $host;
        }
        return array_values($unique);
    }

    protected function regionUploadHosts($region)
    {
        $map = [
            'z0' => ['https://up.qiniup.com', 'https://upload.qiniup.com', 'https://up-z0.qiniup.com', 'https://upload-z0.qiniup.com'],
            'cn-east-2' => ['https://up-cn-east-2.qiniup.com', 'https://upload-cn-east-2.qiniup.com'],
            'z1' => ['https://up-z1.qiniup.com', 'https://upload-z1.qiniup.com'],
            'z2' => ['https://up-z2.qiniup.com', 'https://upload-z2.qiniup.com'],
            'na0' => ['https://up-na0.qiniup.com', 'https://upload-na0.qiniup.com'],
            'as0' => ['https://up-as0.qiniup.com', 'https://upload-as0.qiniup.com'],
            'ap-southeast-2' => ['https://up-ap-southeast-2.qiniup.com', 'https://upload-ap-southeast-2.qiniup.com'],
            'ap-southeast-3' => ['https://up-ap-southeast-3.qiniup.com', 'https://upload-ap-southeast-3.qiniup.com'],
        ];
        return $region !== '' && isset($map[$region]) ? $map[$region] : [];
    }

    protected function rsHost()
    {
        $region = $this->normalizeRegion(isset($this->config['region']) ? $this->config['region'] : '');
        $map = [
            'z0' => 'https://rs.qiniuapi.com',
            'cn-east-2' => 'https://rs-cn-east-2.qiniuapi.com',
            'z1' => 'https://rs-z1.qiniuapi.com',
            'z2' => 'https://rs-z2.qiniuapi.com',
            'na0' => 'https://rs-na0.qiniuapi.com',
            'as0' => 'https://rs-as0.qiniuapi.com',
            'ap-southeast-2' => 'https://rs-ap-southeast-2.qiniuapi.com',
            'ap-southeast-3' => 'https://rs-ap-southeast-3.qiniuapi.com',
        ];
        return isset($map[$region]) ? $map[$region] : 'https://rs.qiniuapi.com';
    }

    protected function normalizeRegion($region)
    {
        $region = strtolower(trim((string) $region));
        $aliases = [
            'huadong' => 'z0',
            'east' => 'z0',
            'cn-east-1' => 'z0',
            '华东' => 'z0',
            '华东-浙江' => 'z0',
            'huabei' => 'z1',
            'north' => 'z1',
            'cn-north-1' => 'z1',
            '华北' => 'z1',
            '华北-河北' => 'z1',
            'huanan' => 'z2',
            'south' => 'z2',
            'cn-south-1' => 'z2',
            '华南' => 'z2',
            '华南-广东' => 'z2',
            'beimei' => 'na0',
            'north-america' => 'na0',
            'us-north-1' => 'na0',
            '北美' => 'na0',
            '亚太' => 'as0',
            '亚太-新加坡' => 'as0',
            'singapore' => 'as0',
            'ap-southeast' => 'as0',
            'ap-southeast-1' => 'as0',
            '华东-浙江2' => 'cn-east-2',
            'zhejiang2' => 'cn-east-2',
            '亚太-河内' => 'ap-southeast-2',
            'hanoi' => 'ap-southeast-2',
            'vietnam' => 'ap-southeast-2',
            '亚太-胡志明' => 'ap-southeast-3',
            'ho-chi-minh' => 'ap-southeast-3',
            'hcm' => 'ap-southeast-3',
            'up.qiniup.com' => 'z0',
            'upload.qiniup.com' => 'z0',
            'up-z0.qiniup.com' => 'z0',
            'upload-z0.qiniup.com' => 'z0',
            'up-cn-east-2.qiniup.com' => 'cn-east-2',
            'upload-cn-east-2.qiniup.com' => 'cn-east-2',
            'up-z1.qiniup.com' => 'z1',
            'upload-z1.qiniup.com' => 'z1',
            'up-z2.qiniup.com' => 'z2',
            'upload-z2.qiniup.com' => 'z2',
            'up-na0.qiniup.com' => 'na0',
            'upload-na0.qiniup.com' => 'na0',
            'up-as0.qiniup.com' => 'as0',
            'upload-as0.qiniup.com' => 'as0',
            'up-ap-southeast-2.qiniup.com' => 'ap-southeast-2',
            'upload-ap-southeast-2.qiniup.com' => 'ap-southeast-2',
            'up-ap-southeast-3.qiniup.com' => 'ap-southeast-3',
            'upload-ap-southeast-3.qiniup.com' => 'ap-southeast-3',
        ];
        return isset($aliases[$region]) ? $aliases[$region] : $region;
    }

    protected function regionKnown($region)
    {
        $region = $this->normalizeRegion($region);
        return $region === '' || in_array($region, ['z0', 'z1', 'z2', 'na0', 'as0', 'cn-east-2', 'ap-southeast-2', 'ap-southeast-3'], true);
    }

    protected function shouldTryNextHost($message)
    {
        $lower = strtolower((string) $message);
        foreach (['incorrect region', 'please use', 'region', 'qiniup', 'resolve', 'timed out', 'timeout', 'could not connect', 'failed to connect', 'network'] as $needle) {
            if (strpos($lower, $needle) !== false) {
                return true;
            }
        }
        return false;
    }

    protected function describeQiniuError($body, $decoded)
    {
        $message = '';
        if (is_array($decoded)) {
            foreach (['error', 'message', 'error_code', 'code'] as $key) {
                if (isset($decoded[$key]) && $decoded[$key] !== '') {
                    $message .= ($message === '' ? '' : '；') . $key . '=' . (is_scalar($decoded[$key]) ? $decoded[$key] : json_encode($decoded[$key], JSON_UNESCAPED_UNICODE));
                }
            }
        }
        if ($message === '') {
            $message = text_limit((string) $body, 600);
        }
        $lower = strtolower($message);
        if (strpos($lower, 'incorrect region') !== false || strpos($lower, 'please use') !== false) {
            $message .= '。判断：上传域名与空间所属区域不匹配，请按七牛提示修改 Region 或 Endpoint。';
        } elseif (strpos($lower, 'bad token') !== false || strpos($lower, 'invalid token') !== false || strpos($lower, 'invalid putpolicy') !== false) {
            $message .= '。判断：上传凭证无效，通常是 AK/SK 填错、服务器时间异常，或 Bucket 名称不一致。';
        } elseif (strpos($lower, 'bucket') !== false && (strpos($lower, 'not') !== false || strpos($lower, 'no such') !== false)) {
            $message .= '。判断：Bucket/空间名称不存在或不属于当前 AK。';
        }
        return $message;
    }
}
