<?php
namespace App\Services\Storage;

class BmtoolsStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }
        if (!function_exists('curl_init') || !class_exists('\CURLFile')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl/CURLFile，无法使用同系统对接。');
        }

        $objectKey = $this->objectKey($objectKey);
        $mime = isset($options['mime']) && $options['mime'] ? $options['mime'] : 'application/octet-stream';
        $type = $this->uploadType($objectKey, $mime);
        $name = basename($objectKey);

        $response = $this->request('api/upload', [
            'type' => $type,
        ], [
            'file' => new \CURLFile($localPath, $mime, $name),
        ]);

        $data = isset($response['data']) && is_array($response['data']) ? $response['data'] : [];
        if (empty($data['id']) || empty($data['url'])) {
            throw new \RuntimeException('同系统对接上传成功但返回数据不完整，请检查远端版本。');
        }

        return [
            'path' => 'bmtools:' . (int) $data['id'],
            'url' => $data['url'],
            'driver' => 'bmtools',
        ];
    }

    public function delete($objectKey)
    {
        $id = $this->remoteId($objectKey);
        if ($id <= 0) {
            return true;
        }
        $this->request('api/delete', ['id' => $id]);
        return true;
    }

    public function test()
    {
        if ($this->endpoint(true) === '') {
            return ['success' => false, 'message' => '同系统对接需要填写远端站点地址，例如 https://store.example.com。'];
        }
        if (empty($this->config['secret_key'])) {
            return ['success' => false, 'message' => '同系统对接需要填写远端用户的对接 Token。'];
        }
        $quota = $this->request('api/quota', []);
        $data = isset($quota['data']) && is_array($quota['data']) ? $quota['data'] : [];
        $used = isset($data['used_storage']) ? (int) $data['used_storage'] : 0;
        $total = isset($data['total_storage']) ? (int) $data['total_storage'] : 0;
        return [
            'success' => true,
            'message' => '同系统对接连接成功，Token 可用。远端空间：' . format_bytes($used) . ' / ' . ($total > 0 ? format_bytes($total) : '不限') . '。可以继续进行真实上传测试。',
        ];
    }

    public function url($objectKey)
    {
        return '';
    }

    protected function request($path, array $fields, array $files = [])
    {
        $target = $this->apiTarget($path);
        $url = $target['url'];
        $ch = curl_init($url);
        $headers = [
            'X-API-Token: ' . $this->config['secret_key'],
            'X-BMTOOLS-Storage-Hop: ' . $this->nextHop(),
            'User-Agent: BMTOOLS-RemoteStorage/1.0',
        ];
        $postFields = $files ? array_merge($fields, $files) : http_build_query($fields);
        $options = [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postFields,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_CONNECTTIMEOUT => 10,
        ];
        if (!empty($target['resolve'])) {
            if (!defined('CURLOPT_RESOLVE')) {
                throw new \RuntimeException('当前 PHP cURL 版本过低，无法固定远端解析 IP，请升级 cURL 后再使用同系统对接。');
            }
            $options[CURLOPT_RESOLVE] = $target['resolve'];
        }
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTPS;
        }
        if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_REDIR_PROTOCOLS] = CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        if ($response === false || $error) {
            throw new \RuntimeException('同系统对接请求失败：' . ($error ?: '未知网络错误'));
        }
        $body = substr($response, $headerSize);
        $responseHeaders = substr($response, 0, $headerSize);
        $json = json_decode($body, true);
        if ($code < 200 || $code >= 300) {
            $location = '';
            if (preg_match('/^Location:\s*(.+)$/im', $responseHeaders, $m)) {
                $location = ' Location=' . trim($m[1]);
            }
            $message = is_array($json) && isset($json['message']) ? $json['message'] : text_limit(strip_tags($body), 180);
            throw new \RuntimeException('同系统对接返回异常 HTTP ' . $code . $location . '：' . ($message ?: '远端没有返回可读错误。'));
        }
        if (!is_array($json)) {
            throw new \RuntimeException('同系统对接返回不是 JSON，请检查远端地址是否填写到站点根地址。HTTP ' . $code . '：' . text_limit(strip_tags($body), 180));
        }
        if (empty($json['success'])) {
            $message = isset($json['message']) ? $json['message'] : ('HTTP ' . $code);
            throw new \RuntimeException('同系统对接返回失败：' . $message);
        }
        return $json;
    }

    protected function apiTarget($path)
    {
        $endpoint = $this->endpoint(true);
        $safe = $this->assertRemoteEndpointSafe($endpoint);
        return [
            'url' => rtrim($endpoint, '/') . '/' . ltrim($path, '/'),
            'resolve' => $safe['resolve'],
        ];
    }

    protected function assertRemoteEndpointSafe($endpoint)
    {
        $parts = parse_url($endpoint);
        if (!$parts || empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https' || empty($parts['host'])) {
            throw new \RuntimeException('同系统对接只允许填写 HTTPS 站点地址。');
        }
        if (!empty($parts['user']) || !empty($parts['pass']) || !empty($parts['query']) || !empty($parts['fragment'])) {
            throw new \RuntimeException('同系统对接地址只允许填写站点根地址，不能包含账号密码、查询参数或锚点。');
        }
        $host = $parts['host'];
        if (!empty($_SERVER['HTTP_HOST']) && strtolower($host) === strtolower(parse_url('https://' . $_SERVER['HTTP_HOST'], PHP_URL_HOST))) {
            throw new \RuntimeException('不能把当前站点配置为自己的同系统对接，避免循环上传。');
        }
        $hostForIpCheck = trim($host, '[]');
        if (filter_var($hostForIpCheck, FILTER_VALIDATE_IP)) {
            $ips = [$hostForIpCheck];
            $resolve = [];
        } else {
            $ips = gethostbynamel($host);
            if (!$ips) {
                throw new \RuntimeException('同系统对接远端域名无法解析。');
            }
            $port = isset($parts['port']) ? (int) $parts['port'] : 443;
            $resolve = [$host . ':' . $port . ':' . $ips[0]];
        }
        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                throw new \RuntimeException('同系统对接不允许指向内网、本机或保留地址。');
            }
        }
        return ['resolve' => $resolve];
    }

    protected function uploadType($objectKey, $mime)
    {
        if (strpos((string) $mime, 'image/') === 0 || strpos($objectKey, 'image/') === 0) {
            return 'image';
        }
        return 'file';
    }

    protected function nextHop()
    {
        $current = isset($_SERVER['HTTP_X_BMTOOLS_STORAGE_HOP']) ? (int) $_SERVER['HTTP_X_BMTOOLS_STORAGE_HOP'] : 0;
        if ($current >= 3) {
            throw new \RuntimeException('同系统对接链路过长，可能存在循环转发，请检查主站和仓储站默认存储配置。');
        }
        return $current + 1;
    }

    protected function remoteId($objectKey)
    {
        if (preg_match('/^bmtools:(\d+)$/', (string) $objectKey, $m)) {
            return (int) $m[1];
        }
        return 0;
    }
}
