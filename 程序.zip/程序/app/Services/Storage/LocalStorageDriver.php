<?php
namespace App\Services\Storage;

class LocalStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }

        $objectKey = $this->objectKey($objectKey);
        $target = $this->publicTarget($objectKey);
        $dir = dirname($target);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        if (!copy($localPath, $target)) {
            throw new \RuntimeException('本地存储写入失败，请检查 public/uploads 目录权限。');
        }

        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => 'local',
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $target = $this->publicTarget($objectKey);
        if (is_file($target)) {
            unlink($target);
        }
        return true;
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        return public_url($objectKey);
    }

    public function test()
    {
        $prefix = $this->safeLocalPrefix();
        $dir = APP_ROOT . '/public/' . $prefix;
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        return [
            'success' => is_writable($dir),
            'message' => is_writable($dir) ? '本地目录可写，可以进行真实上传测试。' : '本地目录不可写，请检查 public/uploads 权限。',
        ];
    }

    protected function objectKey($objectKey)
    {
        $objectKey = ltrim(str_replace('\\', '/', (string) $objectKey), '/');
        $objectKey = preg_replace('#/+#', '/', $objectKey);
        $parts = [];
        foreach (explode('/', $objectKey) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                continue;
            }
            $parts[] = preg_replace('/[^A-Za-z0-9_\-.]/', '-', $part);
        }
        $objectKey = implode('/', $parts);
        $prefix = $this->safeLocalPrefix();
        if ($objectKey === '' || strpos($objectKey, $prefix . '/') !== 0) {
            $objectKey = $prefix . '/' . $objectKey;
        }
        return trim($objectKey, '/');
    }

    protected function safeLocalPrefix()
    {
        $prefix = trim(isset($this->config['prefix']) && $this->config['prefix'] ? $this->config['prefix'] : 'uploads/files', '/');
        $prefix = str_replace('\\', '/', $prefix);
        $parts = [];
        foreach (explode('/', $prefix) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                continue;
            }
            $parts[] = preg_replace('/[^A-Za-z0-9_\-.]/', '-', $part);
        }
        if (!$parts || $parts[0] !== 'uploads') {
            array_unshift($parts, 'uploads');
        }
        return implode('/', $parts);
    }

    protected function publicTarget($objectKey)
    {
        $root = realpath(APP_ROOT . '/public');
        if ($root === false) {
            throw new \RuntimeException('public 目录不存在。');
        }
        $target = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($objectKey, '/'));
        $dir = dirname($target);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $realDir = realpath($dir);
        if ($realDir === false || strpos($realDir, $root) !== 0) {
            throw new \RuntimeException('本地存储路径越界，请检查目录前缀。');
        }
        return $target;
    }
}
