<?php
namespace App\Services\Storage;

class S3StorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }

        $objectKey = $this->objectKey($objectKey);
        $contentType = isset($options['mime']) && $options['mime'] ? $options['mime'] : 'application/octet-stream';
        $payloadHash = hash_file('sha256', $localPath);
        if ($payloadHash === false) {
            throw new \RuntimeException('读取本地文件失败，请检查文件权限。');
        }
        $url = $this->objectUrl($objectKey);
        $headers = $this->signedHeaders('PUT', $url, $payloadHash, [
            'content-type' => $contentType,
        ]);
        $headers[] = 'Content-Length: ' . filesize($localPath);

        $this->curlFile('PUT', $url, $headers, $localPath);
        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => $this->driverName(),
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $payloadHash = hash('sha256', '');
        $url = $this->objectUrl($objectKey);
        $this->curl('DELETE', $url, $this->signedHeaders('DELETE', $url, $payloadHash));
        return true;
    }

    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket'])) {
            return ['success' => false, 'message' => 'S3 兼容存储需要填写 Access Key ID、Secret Access Key 和 Bucket。'];
        }
        if ($this->endpointUrl() === '') {
            return ['success' => false, 'message' => 'S3 Endpoint 不能为空。AWS S3 可填写 https://s3.<region>.amazonaws.com，MinIO/Wasabi/B2 请填写厂商给出的 S3 Endpoint。'];
        }
        return ['success' => true, 'message' => 'S3 兼容存储基础配置完整，可以继续进行真实上传测试。'];
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain !== '') {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($objectKey);
        }
        return $this->objectUrl($objectKey);
    }

    protected function signedHeaders($method, $url, $payloadHash, array $extraHeaders = [])
    {
        $amzDate = gmdate('Ymd\THis\Z');
        $headers = [
            'host' => $this->hostHeader($url),
            'x-amz-content-sha256' => $payloadHash,
            'x-amz-date' => $amzDate,
        ];
        foreach ($extraHeaders as $key => $value) {
            $headers[strtolower($key)] = $this->headerValue($value);
        }

        $authorization = $this->authorization($method, $url, $headers, $payloadHash, $amzDate);
        $lines = [];
        foreach ($headers as $key => $value) {
            $lines[] = $key . ': ' . $value;
        }
        $lines[] = 'Authorization: ' . $authorization;
        return $lines;
    }

    protected function authorization($method, $url, array $headers, $payloadHash, $amzDate)
    {
        $normalizedHeaders = [];
        foreach ($headers as $key => $value) {
            $normalizedHeaders[strtolower($key)] = preg_replace('/\s+/', ' ', trim((string) $value));
        }
        ksort($normalizedHeaders);

        $canonicalHeaders = '';
        foreach ($normalizedHeaders as $key => $value) {
            $canonicalHeaders .= $key . ':' . $value . "\n";
        }
        $signedHeaders = implode(';', array_keys($normalizedHeaders));
        $canonicalUri = $this->canonicalPath($url);
        $canonicalQuery = $this->canonicalQuery($url);
        $canonicalRequest = strtoupper($method) . "\n" .
            $canonicalUri . "\n" .
            $canonicalQuery . "\n" .
            $canonicalHeaders . "\n" .
            $signedHeaders . "\n" .
            $payloadHash;

        $date = substr($amzDate, 0, 8);
        $scope = $date . '/' . $this->region() . '/s3/aws4_request';
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" .
            $amzDate . "\n" .
            $scope . "\n" .
            hash('sha256', $canonicalRequest);

        $signature = hash_hmac('sha256', $stringToSign, $this->signingKey($date));
        return 'AWS4-HMAC-SHA256 Credential=' . $this->config['access_key'] . '/' . $scope .
            ', SignedHeaders=' . $signedHeaders .
            ', Signature=' . $signature;
    }

    protected function signingKey($date)
    {
        $secret = isset($this->config['secret_key']) ? $this->config['secret_key'] : '';
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $secret, true);
        $kRegion = hash_hmac('sha256', $this->region(), $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        return hash_hmac('sha256', 'aws4_request', $kService, true);
    }

    protected function objectUrl($objectKey)
    {
        $endpoint = $this->endpointUrl();
        $parts = parse_url($endpoint);
        $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
        $host = isset($parts['host']) ? $parts['host'] : '';
        $port = isset($parts['port']) ? (int) $parts['port'] : null;
        $path = trim(isset($parts['path']) ? $parts['path'] : '', '/');
        $bucket = trim((string) $this->config['bucket']);
        $key = $this->encodePath($objectKey);

        if ($host === '') {
            throw new \RuntimeException('S3 Endpoint 解析失败，请填写完整域名。');
        }

        $hostWithPort = $host . ($port ? ':' . $port : '');
        $base = $scheme . '://';
        $segments = $path === '' ? [] : explode('/', $path);
        if ($this->isEndpointAlreadyBucket($host, $bucket) || $this->useVirtualHostedStyle($host, $bucket)) {
            $targetHost = $this->isEndpointAlreadyBucket($host, $bucket) ? $hostWithPort : $bucket . '.' . $hostWithPort;
            $segments[] = $key;
            return $base . $targetHost . '/' . implode('/', array_filter($segments, 'strlen'));
        }

        $segments[] = rawurlencode($bucket);
        $segments[] = $key;
        return $base . $hostWithPort . '/' . implode('/', array_filter($segments, 'strlen'));
    }

    protected function endpointUrl()
    {
        $endpoint = trim(isset($this->config['endpoint']) ? $this->config['endpoint'] : '');
        if ($endpoint === '') {
            $region = $this->region();
            if ($region === 'us-east-1') {
                return 'https://s3.amazonaws.com';
            }
            return 'https://s3.' . $region . '.amazonaws.com';
        }
        if (!preg_match('#^https?://#i', $endpoint)) {
            $endpoint = 'https://' . $endpoint;
        }
        $parts = parse_url($endpoint);
        if (!$parts || empty($parts['host'])) {
            return '';
        }
        $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
        $host = $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $path = isset($parts['path']) ? trim($parts['path'], '/') : '';
        return rtrim($scheme . '://' . $host . $port . ($path !== '' ? '/' . $this->encodePath($path) : ''), '/');
    }

    protected function region()
    {
        $region = trim(isset($this->config['region']) ? $this->config['region'] : '');
        return $region !== '' ? $region : $this->defaultRegion();
    }

    protected function defaultRegion()
    {
        return 'us-east-1';
    }

    protected function driverName()
    {
        return 's3';
    }

    protected function useVirtualHostedStyle($host, $bucket)
    {
        if ($bucket === '' || strpos($bucket, '.') !== false) {
            return false;
        }
        return stripos($host, 'amazonaws.com') !== false;
    }

    protected function isEndpointAlreadyBucket($host, $bucket)
    {
        return $bucket !== '' && stripos($host, $bucket . '.') === 0;
    }

    protected function hostHeader($url)
    {
        $host = parse_url($url, PHP_URL_HOST);
        $port = parse_url($url, PHP_URL_PORT);
        $scheme = parse_url($url, PHP_URL_SCHEME);
        if ($port && !(strtolower((string) $scheme) === 'https' && (int) $port === 443) && !(strtolower((string) $scheme) === 'http' && (int) $port === 80)) {
            $host .= ':' . (int) $port;
        }
        return strtolower((string) $host);
    }

    protected function canonicalPath($url)
    {
        $path = parse_url($url, PHP_URL_PATH);
        return $path ? $path : '/';
    }

    protected function canonicalQuery($url)
    {
        $query = parse_url($url, PHP_URL_QUERY);
        if (!$query) {
            return '';
        }
        parse_str($query, $params);
        ksort($params);
        $pairs = [];
        foreach ($params as $key => $value) {
            if (is_array($value)) {
                sort($value);
                foreach ($value as $item) {
                    $pairs[] = rawurlencode($key) . '=' . rawurlencode($item);
                }
            } else {
                $pairs[] = rawurlencode($key) . '=' . rawurlencode($value);
            }
        }
        return implode('&', $pairs);
    }

    protected function headerValue($value)
    {
        return trim(str_replace(["\r", "\n"], ' ', (string) $value));
    }
}
