<?php
namespace App\Services\Storage;

class CosStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }
        $objectKey = $this->objectKey($objectKey);
        $contentType = isset($options['mime']) && $options['mime'] ? $options['mime'] : 'application/octet-stream';
        $md5 = hash_file('md5', $localPath, true);
        if ($md5 === false) {
            throw new \RuntimeException('读取本地文件失败，请检查文件权限。');
        }
        $contentMd5 = base64_encode($md5);
        $contentLength = filesize($localPath);
        $url = $this->uploadUrl($objectKey);
        $host = $this->normalizedHost(parse_url($url, PHP_URL_HOST));
        $date = gmdate('D, d M Y H:i:s \G\M\T');
        $headers = [
            'Host: ' . $host,
            'Date: ' . $date,
            'Content-Type: ' . $contentType,
            'Content-MD5: ' . $contentMd5,
            'Content-Length: ' . $contentLength,
            'Authorization: ' . $this->authorization('put', '/' . $this->encodePath($objectKey), [
                'content-md5' => $contentMd5,
                'content-type' => $contentType,
                'date' => $date,
                'host' => $host,
            ]),
        ];
        $this->curlFile('PUT', $url, $headers, $localPath);
        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => 'cos',
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $url = $this->uploadUrl($objectKey);
        $host = $this->normalizedHost(parse_url($url, PHP_URL_HOST));
        $date = gmdate('D, d M Y H:i:s \G\M\T');
        $this->curl('DELETE', $url, [
            'Host: ' . $host,
            'Date: ' . $date,
            'Authorization: ' . $this->authorization('delete', '/' . $this->encodePath($objectKey), ['date' => $date, 'host' => $host]),
        ]);
        return true;
    }

    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || (empty($this->config['region']) && empty($this->config['endpoint']))) {
            return ['success' => false, 'message' => '腾讯云 COS 需要填写 SecretId、SecretKey、Bucket，并填写 Region。Endpoint 可以留空，系统会按 Bucket 和 Region 自动生成。'];
        }
        if (!empty($this->config['region']) && !preg_match('/^[a-z]+-[a-z]+-\d+$/', $this->config['region'])) {
            return ['success' => false, 'message' => '腾讯云 COS Region 格式不正确，例如广州是 ap-guangzhou，上海是 ap-shanghai，不要填写中文地域名或完整域名。'];
        }
        if (strpos($this->config['bucket'], '-') === false) {
            return ['success' => false, 'message' => '腾讯云 COS Bucket 通常是“名称-APPID”，例如 bmtools-1250000000。请确认 Bucket 是否复制完整。'];
        }
        return ['success' => true, 'message' => 'COS 基础配置完整，可以进行真实上传测试。'];
    }

    protected function uploadUrl($objectKey)
    {
        $endpoint = $this->endpoint(true);
        if ($endpoint === '') {
            $endpoint = 'https://' . $this->config['bucket'] . '.cos.' . $this->config['region'] . '.myqcloud.com';
        } else {
            $host = $this->normalizedHost(parse_url($endpoint, PHP_URL_HOST));
            if ($host && strpos($host, $this->config['bucket'] . '.') !== 0) {
                $endpoint = preg_replace('#^(https?://)#', '$1' . $this->config['bucket'] . '.', $endpoint);
            }
        }
        return $endpoint . '/' . $this->encodePath($objectKey);
    }

    protected function authorization($method, $path, array $headers)
    {
        $start = time() - 60;
        $end = $start + 3600;
        ksort($headers);
        $normalizedHeaders = [];
        foreach ($headers as $key => $value) {
            $normalizedHeaders[strtolower($key)] = trim((string) $value);
        }
        ksort($normalizedHeaders);
        $headerKeys = array_keys($normalizedHeaders);
        $headerList = implode(';', $headerKeys);
        $canonicalHeaders = '';
        foreach ($normalizedHeaders as $key => $value) {
            $canonicalHeaders .= rawurlencode($key) . '=' . rawurlencode($value) . '&';
        }
        $canonicalHeaders = rtrim($canonicalHeaders, '&');
        $canonicalRequest = strtolower($method) . "\n" . $path . "\n\n" . $canonicalHeaders . "\n";
        $signKey = hash_hmac('sha1', $start . ';' . $end, $this->config['secret_key']);
        $stringToSign = "sha1\n" . $start . ';' . $end . "\n" . sha1($canonicalRequest) . "\n";
        $signature = hash_hmac('sha1', $stringToSign, $signKey);
        return 'q-sign-algorithm=sha1&q-ak=' . $this->config['access_key'] . '&q-sign-time=' . $start . ';' . $end . '&q-key-time=' . $start . ';' . $end . '&q-header-list=' . $headerList . '&q-url-param-list=&q-signature=' . $signature;
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain) {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($objectKey);
        }
        return $this->uploadUrl($objectKey);
    }
}
