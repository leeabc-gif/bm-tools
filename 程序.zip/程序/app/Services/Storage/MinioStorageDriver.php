<?php
namespace App\Services\Storage;

class MinioStorageDriver extends S3StorageDriver
{
    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || empty($this->config['endpoint'])) {
            return ['success' => false, 'message' => 'MinIO 需要填写 Access Key、Secret Key、Bucket 和完整 Endpoint，例如 https://minio.example.com 或 http://10.0.0.8:9000。'];
        }
        $parts = parse_url($this->config['endpoint']);
        if (!$parts || empty($parts['host']) || !in_array(strtolower(isset($parts['scheme']) ? $parts['scheme'] : ''), ['http', 'https'], true)) {
            return ['success' => false, 'message' => 'MinIO Endpoint 格式不正确，请填写带 http:// 或 https:// 的 S3 API 地址。'];
        }
        if (empty($this->config['domain'])) {
            return ['success' => true, 'message' => 'MinIO 基础配置完整。未填写公开访问域名时，外链会使用 Endpoint + Bucket 路径，内网 Endpoint 可能无法被公网用户访问。'];
        }
        return ['success' => true, 'message' => 'MinIO 基础配置完整，可以继续进行真实上传、外链访问和删除测试。'];
    }

    protected function driverName()
    {
        return 'minio';
    }

    protected function useVirtualHostedStyle($host, $bucket)
    {
        return false;
    }
}
