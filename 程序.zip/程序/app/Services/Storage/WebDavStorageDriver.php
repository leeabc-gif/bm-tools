<?php
namespace App\Services\Storage;

class WebDavStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }

        $objectKey = $this->objectKey($objectKey);
        $this->ensureCollections($objectKey);

        $contentType = isset($options['mime']) && $options['mime'] ? $options['mime'] : 'application/octet-stream';
        $this->curlFile('PUT', $this->remoteUrl($objectKey), [
            'Content-Type: ' . $this->headerValue($contentType),
            'Content-Length: ' . filesize($localPath),
        ], $localPath, [
            CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
            CURLOPT_USERPWD => (isset($this->config['access_key']) ? $this->config['access_key'] : '') . ':' . (isset($this->config['secret_key']) ? $this->config['secret_key'] : ''),
        ]);

        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => 'webdav',
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $this->request('DELETE', $this->remoteUrl($objectKey), [], null, [200, 202, 204, 404]);
        return true;
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain !== '') {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($this->remotePath($objectKey));
        }
        return $this->remoteUrl($objectKey);
    }

    public function test()
    {
        if (empty($this->config['endpoint'])) {
            return ['success' => false, 'message' => 'WebDAV 需要填写服务地址，例如 https://dav.example.com/remote.php/dav/files/user。'];
        }
        if (empty($this->config['access_key']) || empty($this->config['secret_key'])) {
            return ['success' => false, 'message' => 'WebDAV 需要填写用户名和密码/应用专用 Token。'];
        }
        $endpoint = $this->endpointUrl();
        if ($endpoint === '') {
            return ['success' => false, 'message' => 'WebDAV 地址解析失败，请填写完整 http(s) 地址。'];
        }
        return ['success' => true, 'message' => 'WebDAV 基础配置完整，可以继续进行真实上传测试。'];
    }

    protected function ensureCollections($objectKey)
    {
        $segments = $this->remoteSegments($objectKey);
        array_pop($segments);
        if (!$segments) {
            return;
        }

        $url = $this->endpointUrl();
        foreach ($segments as $segment) {
            $url = rtrim($url, '/') . '/' . rawurlencode($segment);
            $this->request('MKCOL', $url, [], '', [200, 201, 204, 405]);
        }
    }

    protected function request($method, $url, array $headers = [], $body = null, array $allowedCodes = [])
    {
        if (!function_exists('curl_init')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl 扩展，无法连接 WebDAV。');
        }

        $ch = curl_init($url);
        $headers[] = 'User-Agent: BMTOOLS-WebDAV/1.0';
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
            CURLOPT_USERPWD => (isset($this->config['access_key']) ? $this->config['access_key'] : '') . ':' . (isset($this->config['secret_key']) ? $this->config['secret_key'] : ''),
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }

        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        if ($response === false || $error) {
            throw new \RuntimeException('WebDAV 请求失败：' . $error);
        }

        $responseHeaders = substr($response, 0, $headerSize);
        $responseBody = substr($response, $headerSize);
        if ($allowedCodes && in_array((int) $code, $allowedCodes, true)) {
            return ['code' => $code, 'body' => $responseBody];
        }
        if (($allowedCodes && !in_array((int) $code, $allowedCodes, true)) || $code < 200 || $code >= 300) {
            $location = '';
            if (preg_match('/^Location:\s*(.+)$/im', $responseHeaders, $m)) {
                $location = ' Location=' . trim($m[1]);
            }
            throw new \RuntimeException('WebDAV 服务返回异常 HTTP ' . $code . $location . '：' . text_limit(strip_tags($responseBody), 600));
        }
        return ['code' => $code, 'body' => $responseBody];
    }

    protected function remoteUrl($objectKey)
    {
        return rtrim($this->endpointUrl(), '/') . '/' . $this->encodePath($this->remotePath($objectKey));
    }

    protected function remotePath($objectKey)
    {
        return implode('/', $this->remoteSegments($objectKey));
    }

    protected function remoteSegments($objectKey)
    {
        $segments = [];
        $bucket = trim(isset($this->config['bucket']) ? $this->config['bucket'] : '', '/');
        if ($bucket !== '') {
            $segments = array_merge($segments, $this->pathSegments($bucket));
        }
        $segments = array_merge($segments, $this->pathSegments($objectKey));
        return $segments;
    }

    protected function pathSegments($path)
    {
        $parts = [];
        foreach (explode('/', str_replace('\\', '/', trim((string) $path, '/'))) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                continue;
            }
            $parts[] = $part;
        }
        return $parts;
    }

    protected function endpointUrl()
    {
        $endpoint = trim(isset($this->config['endpoint']) ? $this->config['endpoint'] : '');
        if ($endpoint === '') {
            return '';
        }
        if (!preg_match('#^https?://#i', $endpoint)) {
            $endpoint = 'https://' . $endpoint;
        }
        $parts = parse_url($endpoint);
        if (!$parts || empty($parts['host'])) {
            return '';
        }
        return rtrim($endpoint, '/');
    }

    protected function headerValue($value)
    {
        return trim(str_replace(["\r", "\n"], ' ', (string) $value));
    }
}
