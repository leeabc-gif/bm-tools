<?php
namespace App\Services\Storage;

use App\Models\StorageDriver;
use App\Services\CryptoService;

class StorageManager
{
    public static function defaultDriverRecord()
    {
        return (new StorageDriver())->defaultDriver();
    }

    public static function make(array $record)
    {
        if (isset($record['secret_key'])) {
            $record['secret_key'] = CryptoService::decrypt($record['secret_key']);
        }
        switch ($record['type']) {
            case 'local':
                return new LocalStorageDriver($record);
            case 'oss':
                return new OssStorageDriver($record);
            case 'cos':
                return new CosStorageDriver($record);
            case 'kodo':
                return new KodoStorageDriver($record);
            case 's3':
                return new S3StorageDriver($record);
            case 'minio':
                return new MinioStorageDriver($record);
            case 'r2':
                return new R2StorageDriver($record);
            case 'webdav':
                return new WebDavStorageDriver($record);
            case 'bmtools':
                return new BmtoolsStorageDriver($record);
            default:
                throw new \InvalidArgumentException('未知存储类型：' . $record['type']);
        }
    }

    public static function default()
    {
        $record = self::defaultDriverRecord();
        if (!$record) {
            return null;
        }
        return self::make($record);
    }
}
