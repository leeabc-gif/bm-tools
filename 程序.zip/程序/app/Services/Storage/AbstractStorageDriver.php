<?php
namespace App\Services\Storage;

abstract class AbstractStorageDriver implements StorageInterface
{
    protected $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain) {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($objectKey);
        }
        $endpoint = rtrim(isset($this->config['endpoint']) ? $this->config['endpoint'] : '', '/');
        if ($endpoint && !preg_match('#^https?://#i', $endpoint)) {
            $endpoint = 'https://' . $endpoint;
        }
        return $endpoint . '/' . $this->encodePath($objectKey);
    }

    public function test()
    {
        return [
            'success' => !empty($this->config['bucket']) && !empty($this->config['access_key']),
            'message' => '配置字段检查完成，可以继续进行真实上传测试。',
        ];
    }

    protected function objectKey($objectKey)
    {
        $prefix = trim(isset($this->config['prefix']) ? $this->config['prefix'] : '', '/');
        $objectKey = ltrim($objectKey, '/');
        if ($prefix === '' || strpos($objectKey, $prefix . '/') === 0) {
            return $objectKey;
        }
        return $prefix . '/' . $objectKey;
    }

    protected function endpoint($withScheme = true)
    {
        $endpoint = trim(isset($this->config['endpoint']) ? $this->config['endpoint'] : '');
        if ($endpoint === '') {
            return '';
        }
        if (!preg_match('#^https?://#i', $endpoint)) {
            $endpoint = 'https://' . $endpoint;
        }
        $parts = parse_url($endpoint);
        if (!$parts || empty($parts['host'])) {
            return '';
        }
        $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : 'https';
        $host = $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $endpoint = $host . $port;
        if ($withScheme && !preg_match('#^https?://#i', $endpoint)) {
            $endpoint = $scheme . '://' . $endpoint;
        }
        return rtrim($endpoint, '/');
    }

    protected function normalizedHost($host)
    {
        $host = trim((string) $host);
        $host = preg_replace('#^https?://#i', '', $host);
        $host = preg_replace('#/.*$#', '', $host);
        return strtolower(trim($host));
    }

    protected function encodePath($path)
    {
        return implode('/', array_map('rawurlencode', explode('/', ltrim($path, '/'))));
    }

    protected function curl($method, $url, array $headers = [], $body = null)
    {
        if (!function_exists('curl_init')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl 扩展，无法连接对象存储。');
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 60,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        if ($response === false || $error) {
            throw new \RuntimeException('存储请求失败：' . $error);
        }

        $responseBody = substr($response, $headerSize);
        if ($code < 200 || $code >= 300) {
            $requestId = '';
            if (preg_match('/<(?:RequestId|RequestID|requestId)>([^<]+)<\//i', $responseBody, $m)) {
                $requestId = ' RequestId=' . $m[1];
            }
            $location = '';
            $responseHeaders = substr($response, 0, $headerSize);
            if (preg_match('/^Location:\s*(.+)$/im', $responseHeaders, $m)) {
                $location = ' Location=' . trim($m[1]);
            }
            throw new \RuntimeException('Storage service returned unexpected HTTP ' . $code . $requestId . $location . ': ' . text_limit(strip_tags($responseBody), 600));
        }

        return ['code' => $code, 'body' => $responseBody];
    }

    protected function curlFile($method, $url, array $headers, $localPath, array $curlOptions = [])
    {
        if (!function_exists('curl_init')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl 扩展，无法连接对象存储。');
        }
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }

        $handle = @fopen($localPath, 'rb');
        if (!$handle) {
            throw new \RuntimeException('读取本地文件失败，请检查文件权限。');
        }

        $ch = curl_init($url);
        $options = [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_UPLOAD => true,
            CURLOPT_INFILE => $handle,
            CURLOPT_INFILESIZE => filesize($localPath),
        ];
        curl_setopt_array($ch, $options + $curlOptions);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        fclose($handle);

        if ($response === false || $error) {
            throw new \RuntimeException('存储请求失败：' . $error);
        }

        $responseBody = substr($response, $headerSize);
        if ($code < 200 || $code >= 300) {
            $requestId = '';
            if (preg_match('/<(?:RequestId|RequestID|requestId)>([^<]+)<\//i', $responseBody, $m)) {
                $requestId = ' RequestId=' . $m[1];
            }
            $location = '';
            $responseHeaders = substr($response, 0, $headerSize);
            if (preg_match('/^Location:\s*(.+)$/im', $responseHeaders, $m)) {
                $location = ' Location=' . trim($m[1]);
            }
            throw new \RuntimeException('Storage service returned unexpected HTTP ' . $code . $requestId . $location . ': ' . text_limit(strip_tags($responseBody), 600));
        }

        return ['code' => $code, 'body' => $responseBody];
    }

    protected function base64Url($value)
    {
        return strtr(base64_encode($value), '+/', '-_');
    }
}
