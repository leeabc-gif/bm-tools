<?php
namespace App\Services\Storage;

use App\Core\Logger;

class StorageTestService
{
    public function run(array $record)
    {
        $started = microtime(true);
        $type = isset($record['type']) ? (string) $record['type'] : '';
        $checks = [
            $this->check('config', '基础配置', 'running', '正在检查必填字段、密钥解密和驱动初始化。'),
        ];

        try {
            $driver = StorageManager::make($record);
        } catch (\Throwable $e) {
            $message = $this->humanizeCloudError($type, $e->getMessage());
            $checks[0] = $this->check('config', '基础配置', 'fail', $message, $this->stageHint($record, 'config'), '', $this->docUrl($record, 'config'));
            return $this->failed('config', '存储驱动初始化失败：' . $message, $record, $checks, $e->getMessage());
        }

        try {
            $basic = method_exists($driver, 'test') ? $driver->test() : ['success' => true, 'message' => '驱动已加载。'];
            if (empty($basic['success'])) {
                $message = isset($basic['message']) ? (string) $basic['message'] : '配置未通过基础检查。';
                $checks[0] = $this->check('config', '基础配置', 'fail', $message, $this->stageHint($record, 'config'), '', $this->docUrl($record, 'config'));
                return $this->failed('config', $message, $record, $checks, $message);
            }
            $checks[0] = $this->check('config', '基础配置', 'pass', isset($basic['message']) ? (string) $basic['message'] : '基础配置完整。');
        } catch (\Throwable $e) {
            $message = $this->humanizeCloudError($type, $e->getMessage());
            $checks[0] = $this->check('config', '基础配置', 'fail', $message, $this->stageHint($record, 'config'), '', $this->docUrl($record, 'config'));
            return $this->failed('config', $message, $record, $checks, $e->getMessage());
        }

        $checks[] = $this->check('upload', '写入测试', 'running', '正在上传一个极小测试文件。');
        $testFile = $this->makeTempFile($record);
        $uploaded = null;
        $urlCheck = null;
        $deleteSuccess = false;

        try {
            $uploaded = $driver->upload($testFile['path'], $testFile['object_key'], ['mime' => $testFile['mime']]);
            $uploadMs = (int) round((microtime(true) - $started) * 1000);
            if (empty($uploaded['path']) || empty($uploaded['url'])) {
                throw new \RuntimeException('驱动返回结果不完整，缺少 path 或 url。');
            }
            $checks[1] = $this->check('upload', '写入测试', 'pass', '测试文件写入成功，用时 ' . $uploadMs . 'ms。', '', $uploaded['url'], '', [
                'object_key' => $uploaded['path'],
                'upload_ms' => $uploadMs,
            ]);
        } catch (\Throwable $e) {
            $message = $this->humanizeCloudError($type, $e->getMessage());
            $checks[1] = $this->check('upload', '写入测试', 'fail', $message, $this->stageHint($record, 'upload'), '', $this->docUrl($record, 'upload'));
            Logger::error('存储写入测试失败：' . $e->getMessage(), ['storage_id' => isset($record['id']) ? $record['id'] : null, 'type' => $type]);
            $this->removeTemp($testFile['path']);
            return $this->failed('upload', '存储写入失败：' . $message, $record, $checks, $e->getMessage(), [
                'object_key' => $testFile['object_key'],
            ]);
        }

        $urlCheck = $this->checkUrl($uploaded['url']);
        $checks[] = $this->check(
            'url',
            '外链访问',
            $urlCheck['success'] ? 'pass' : 'fail',
            $urlCheck['message'],
            $urlCheck['success'] ? '' : $this->stageHint($record, 'url'),
            $uploaded['url'],
            $this->docUrl($record, 'url'),
            [
                'method' => isset($urlCheck['method']) ? $urlCheck['method'] : '',
                'http_code' => isset($urlCheck['http_code']) ? $urlCheck['http_code'] : null,
                'technical_message' => isset($urlCheck['technical_message']) ? $urlCheck['technical_message'] : '',
            ]
        );

        $checks[] = $this->check('delete', '删除清理', 'running', '正在删除测试文件，验证删除权限。');
        try {
            $deleteSuccess = (bool) $driver->delete($uploaded['path']);
            $checks[count($checks) - 1] = $this->check(
                'delete',
                '删除清理',
                $deleteSuccess ? 'pass' : 'warn',
                $deleteSuccess ? '测试文件已删除，删除权限正常。' : '删除接口返回异常，请到云厂商后台确认测试文件是否残留。',
                $deleteSuccess ? '' : $this->stageHint($record, 'delete'),
                '',
                $this->docUrl($record, 'delete')
            );
        } catch (\Throwable $e) {
            $checks[count($checks) - 1] = $this->check('delete', '删除清理', 'fail', $this->humanizeCloudError($type, $e->getMessage()), $this->stageHint($record, 'delete'), '', $this->docUrl($record, 'delete'));
            Logger::error('存储删除测试失败：' . $e->getMessage(), ['storage_id' => isset($record['id']) ? $record['id'] : null, 'path' => $uploaded['path']]);
            $this->removeTemp($testFile['path']);
            return $this->failed('delete', '测试文件已写入，但删除失败。请补充 DeleteObject/DELETE 权限，避免文件无法清理。', $record, $checks, $e->getMessage(), [
                'partial_success' => true,
                'url' => $uploaded['url'],
                'public_url' => $uploaded['url'],
                'object_key' => $uploaded['path'],
                'upload_ms' => $uploadMs,
                'delete_success' => false,
            ]);
        }

        $this->removeTemp($testFile['path']);

        if (empty($urlCheck['success'])) {
            return $this->failed('url', '测试文件已写入，但生成的外链无法访问。上传权限可用，问题集中在公开读权限、访问域名、CDN/HTTPS 或路径前缀。', $record, $checks, isset($urlCheck['technical_message']) ? $urlCheck['technical_message'] : $urlCheck['message'], [
                'partial_success' => true,
                'url' => $uploaded['url'],
                'public_url' => $uploaded['url'],
                'object_key' => $uploaded['path'],
                'upload_ms' => $uploadMs,
                'delete_success' => $deleteSuccess,
            ]);
        }

        if (!$deleteSuccess) {
            return $this->failed('delete', '测试文件写入和访问正常，但删除接口返回异常。请检查删除权限。', $record, $checks, '', [
                'partial_success' => true,
                'url' => $uploaded['url'],
                'public_url' => $uploaded['url'],
                'object_key' => $uploaded['path'],
                'upload_ms' => $uploadMs,
                'delete_success' => false,
            ]);
        }

        return [
            'success' => true,
            'message' => '存储测试通过：配置、写入、外链访问和删除权限均可用。',
            'stage' => 'done',
            'failed_stage_label' => '',
            'failed_stage_hint' => '',
            'next_action' => '当前线路可以用于生产上传。建议再用真实大文件验证 CDN、HTTPS、跨域和下载速度。',
            'docs_url' => $this->docUrl($record, 'upload'),
            'url' => $uploaded['url'],
            'public_url' => $uploaded['url'],
            'object_key' => $uploaded['path'],
            'upload_ms' => $uploadMs,
            'delete_success' => true,
            'checks' => $checks,
        ];
    }

    protected function failed($stage, $message, array $record, array $checks, $technicalMessage = '', array $extra = [])
    {
        $payload = [
            'success' => false,
            'message' => $this->cleanError($message),
            'stage' => $stage,
            'failed_stage' => $stage,
            'failed_stage_label' => $this->stageLabel($stage),
            'failed_stage_hint' => $this->stageHint($record, $stage),
            'next_action' => $this->stageHint($record, $stage),
            'docs_url' => $this->docUrl($record, $stage),
            'technical_message' => $this->cleanError($technicalMessage),
            'checks' => $checks,
            'repair_url' => function_exists('url') ? url('admin/storages?id=' . (int) (isset($record['id']) ? $record['id'] : 0)) : '',
            'error_type' => $stage === 'config' ? 'storage_config' : 'storage_' . $stage,
        ];
        foreach ($extra as $key => $value) {
            $payload[$key] = $value;
        }
        return $payload;
    }

    protected function makeTempFile(array $record)
    {
        if (isset($record['type']) && $record['type'] === 'bmtools') {
            return $this->makeTempImage();
        }
        $tmp = tempnam(sys_get_temp_dir(), 'bm_storage_');
        if ($tmp === false) {
            throw new \RuntimeException('无法创建临时测试文件，请检查服务器临时目录权限。');
        }
        $content = app_brand_name() . " storage health check\n";
        $content .= 'storage=' . (isset($record['name']) ? $record['name'] : '') . "\n";
        $content .= 'time=' . date('Y-m-d H:i:s') . "\n";
        file_put_contents($tmp, $content);
        return [
            'path' => $tmp,
            'mime' => 'text/plain',
            'object_key' => 'bmtools-healthcheck/' . date('Ymd') . '/storage-test-' . date('His') . '-' . bin2hex(random_bytes(4)) . '.txt',
        ];
    }

    protected function makeTempImage()
    {
        $tmp = tempnam(sys_get_temp_dir(), 'bm_storage_');
        if ($tmp === false) {
            throw new \RuntimeException('无法创建临时测试文件，请检查服务器临时目录权限。');
        }
        $png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=';
        file_put_contents($tmp, base64_decode($png));
        return [
            'path' => $tmp,
            'mime' => 'image/png',
            'object_key' => 'image/bmtools-healthcheck/' . date('Ymd') . '/storage-test-' . date('His') . '-' . bin2hex(random_bytes(4)) . '.png',
        ];
    }

    protected function removeTemp($path)
    {
        if ($path && is_file($path)) {
            @unlink($path);
        }
    }

    protected function check($key, $label, $status, $message, $hint = '', $url = '', $docsUrl = '', array $meta = [])
    {
        $item = [
            'key' => $key,
            'label' => $label,
            'status' => $status,
            'message' => $this->cleanError($message),
            'hint' => $hint,
            'url' => $url,
            'docs_url' => $docsUrl,
        ];
        foreach ($meta as $metaKey => $metaValue) {
            if ($metaValue === null || $metaValue === '') {
                continue;
            }
            $item[$metaKey] = is_string($metaValue) ? $this->cleanError($metaValue) : $metaValue;
        }
        return $item;
    }

    protected function stageLabel($stage)
    {
        $labels = [
            'config' => '基础配置',
            'upload' => '写入测试',
            'url' => '外链访问',
            'delete' => '删除清理',
            'done' => '测试通过',
        ];
        return isset($labels[$stage]) ? $labels[$stage] : '未知步骤';
    }

    protected function docUrl(array $record, $stage)
    {
        $type = isset($record['type']) ? (string) $record['type'] : '';
        $docs = [
            'oss' => [
                'config' => 'https://help.aliyun.com/zh/oss/developer-reference/putobject/',
                'upload' => 'https://help.aliyun.com/zh/oss/developer-reference/putobject/',
                'url' => 'https://help.aliyun.com/zh/oss/user-guide/domain-names-1/',
                'delete' => 'https://help.aliyun.com/zh/oss/developer-reference/deleteobject/',
            ],
            'cos' => [
                'config' => 'https://cloud.tencent.com/document/product/436/7749',
                'upload' => 'https://cloud.tencent.com/document/product/436/7749',
                'url' => 'https://cloud.tencent.com/document/product/436/11142',
                'delete' => 'https://cloud.tencent.com/document/product/436/7743',
            ],
            'kodo' => [
                'config' => 'https://developer.qiniu.com/kodo',
                'upload' => 'https://developer.qiniu.com/kodo/1312/upload',
                'url' => 'https://developer.qiniu.com/kodo',
                'delete' => 'https://developer.qiniu.com/kodo/1257/delete',
            ],
            's3' => [
                'config' => 'https://docs.aws.amazon.com/AmazonS3/latest/API/sig-v4-authenticating-requests.html',
                'upload' => 'https://docs.aws.amazon.com/AmazonS3/latest/API/API_PutObject.html',
                'url' => 'https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-bucket-intro.html',
                'delete' => 'https://docs.aws.amazon.com/AmazonS3/latest/API/API_DeleteObject.html',
            ],
            'minio' => [
                'config' => 'https://min.io/docs/minio/linux/developers/s3-drivers.html',
                'upload' => 'https://min.io/docs/minio/linux/developers/s3-drivers.html',
                'url' => 'https://min.io/docs/minio/linux/administration/identity-access-management/policy-based-access-control.html',
                'delete' => 'https://min.io/docs/minio/linux/developers/s3-drivers.html',
            ],
            'r2' => [
                'config' => 'https://developers.cloudflare.com/r2/api/s3/api/',
                'upload' => 'https://developers.cloudflare.com/r2/api/s3/api/',
                'url' => 'https://developers.cloudflare.com/r2/buckets/public-buckets/',
                'delete' => 'https://developers.cloudflare.com/r2/api/s3/api/',
            ],
            'webdav' => [
                'config' => 'https://www.rfc-editor.org/rfc/rfc4918',
                'upload' => 'https://www.rfc-editor.org/rfc/rfc4918#section-9.7',
                'url' => 'https://www.rfc-editor.org/rfc/rfc4918',
                'delete' => 'https://www.rfc-editor.org/rfc/rfc4918#section-9.6',
            ],
        ];
        return isset($docs[$type][$stage]) ? $docs[$type][$stage] : '';
    }

    protected function stageHint(array $record, $stage)
    {
        $type = isset($record['type']) ? (string) $record['type'] : '';
        $hints = [
            'config' => [
                'oss' => '检查 AccessKey、SecretKey、Bucket、Endpoint 是否完整。Endpoint 不要带 Bucket、不要填 CDN 域名。',
                'cos' => '检查 SecretId、SecretKey、Bucket 和 Region。Bucket 通常带数字后缀，例如 name-1250000000。',
                'kodo' => '检查 AK/SK、Bucket、访问域名和 Region。访问域名不是上传域名。',
                's3' => '检查 Access Key、Secret Key、Bucket、Endpoint 和 Region。Endpoint 应是 S3 API 地址。',
                'minio' => '检查 MinIO Access Key、Secret Key、Bucket 和 Endpoint。Endpoint 必须是 MinIO S3 API 地址，不是 Console 地址。',
                'r2' => '检查 R2 Access Key、Secret Key、Bucket 和账户级 Endpoint。Region 可留空或填写 auto。',
                'webdav' => '检查 WebDAV 地址、用户名、密码或应用 Token。远程目录必须可写。',
                'bmtools' => '检查远端站点 HTTPS 根地址和对接 Token，远端账号需开启 API 权限。',
                'local' => '检查 public/uploads 目录是否存在且可写。',
            ],
            'upload' => [
                'oss' => '写入失败通常是 Endpoint、Bucket、PutObject 权限或服务器时间问题。',
                'cos' => '写入失败通常是 Region、Bucket、SecretId 权限或 CAM 策略问题。',
                'kodo' => '写入失败通常是 AK/SK、空间区域、上传域名或 Bucket 不匹配。',
                's3' => '写入失败通常是 Signature V4、Region、Endpoint、Bucket 或 s3:PutObject 权限问题。',
                'minio' => '写入失败通常是 MinIO Endpoint、Bucket 不存在、账号策略缺少 s3:PutObject，或服务器无法访问 MinIO 地址。',
                'r2' => '写入失败通常是 R2 Endpoint、Bucket、Token 授权或 Region(auto) 签名问题。',
                'webdav' => '写入失败通常是 WebDAV 账号权限、PUT/MKCOL 被禁用或 Endpoint 路径不可写。',
                'bmtools' => '写入失败通常是远端 API Token、套餐权限、IP 白名单或远端地址问题。',
                'local' => '写入失败通常是目录权限或磁盘空间问题。',
            ],
            'url' => [
                'oss' => '检查 Bucket 公共读、自定义域名/CDN 绑定、HTTPS 证书和路径前缀。',
                'cos' => '检查存储桶公有读策略、自定义域名绑定和 CDN 回源配置。',
                'kodo' => '检查七牛访问域名是否绑定当前空间，域名是否备案/启用并填写到访问域名字段。',
                's3' => '检查 Bucket 公共读策略、访问域名/CDN 指向和路径风格是否一致。',
                'minio' => 'MinIO 外链不可访问时，检查 Bucket 策略是否允许读取、公开域名是否能访问 Endpoint，以及反向代理路径是否正确。',
                'r2' => '在 R2 开启公开 Bucket、r2.dev 或自定义域名，并把公开域名填到访问域名字段。',
                'webdav' => 'WebDAV 写入可用但外链不可访问时，需要配置公开访问域名或分享地址。',
                'bmtools' => '检查远端返回的 public_url 和远端站点 HTTPS 访问。',
                'local' => '检查站点 public 目录是否为 Web 根目录，或 site_public_url 是否配置正确。',
            ],
            'delete' => [
                'oss' => '给 AccessKey 增加 DeleteObject 权限，或检查 Bucket 授权策略。',
                'cos' => '给 SecretId 增加 DeleteObject 权限，或检查存储桶访问策略。',
                'kodo' => '确认 AK/SK 对当前空间有删除权限，空间名称必须完全一致。',
                's3' => '给当前 Access Key 增加 s3:DeleteObject 权限，或检查 Bucket Policy/对象锁。',
                'minio' => '给 MinIO 用户策略增加 s3:DeleteObject 权限，并确认 Bucket 没有对象锁或只读策略。',
                'r2' => '确认 R2 API Token 对当前 Bucket 有 Object Delete 权限。',
                'webdav' => '确认 WebDAV 账号允许 DELETE；部分网盘只给读写，不给删除。',
                'bmtools' => '确认远端 API 允许删除测试文件，远端账号权限没有被禁用。',
                'local' => '检查本地文件删除权限。',
            ],
        ];
        return isset($hints[$stage][$type]) ? $hints[$stage][$type] : '请根据失败步骤检查对应配置。';
    }

    protected function checkUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return ['success' => false, 'message' => '未生成访问链接。', 'method' => '', 'http_code' => 0];
        }
        if (!preg_match('#^https?://#i', $url)) {
            return ['success' => false, 'message' => '生成的是相对链接，无法远程检测：' . $url, 'method' => 'local', 'http_code' => 0];
        }
        if (!function_exists('curl_init')) {
            return ['success' => true, 'message' => '已生成访问链接。当前 PHP 缺少 curl，已跳过 HTTP 访问验证。', 'method' => 'skip', 'http_code' => 0];
        }

        $head = $this->httpProbe($url, 'HEAD');
        if ($this->httpProbeOk($head)) {
            return $this->describeUrlProbe($head);
        }

        $tryGet = !empty($head['error']) || in_array((int) $head['code'], [0, 401, 403, 405, 501], true);
        if ($tryGet) {
            $get = $this->httpProbe($url, 'GET');
            $result = $this->describeUrlProbe($get);
            if (!empty($head['error']) && empty($get['error'])) {
                $result['technical_message'] = 'HEAD 失败：' . $head['error'] . '；已改用 GET Range 复测。' . (!empty($result['technical_message']) ? ' ' . $result['technical_message'] : '');
            }
            return $result;
        }

        return $this->describeUrlProbe($head);
    }

    protected function httpProbe($url, $method)
    {
        $ch = curl_init($url);
        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'BMTOOLS-StorageHealth/1.1',
        ];
        if ($method === 'HEAD') {
            $options[CURLOPT_NOBODY] = true;
        } else {
            $options[CURLOPT_HTTPGET] = true;
            $options[CURLOPT_RANGE] = '0-16';
            $options[CURLOPT_HTTPHEADER] = ['Range: bytes=0-16'];
        }
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $primaryIp = defined('CURLINFO_PRIMARY_IP') ? curl_getinfo($ch, CURLINFO_PRIMARY_IP) : '';
        $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
        curl_close($ch);

        return [
            'method' => $method,
            'code' => (int) $code,
            'error' => $error,
            'content_type' => $contentType,
            'primary_ip' => $primaryIp,
            'total_ms' => (int) round(((float) $totalTime) * 1000),
        ];
    }

    protected function httpProbeOk(array $probe)
    {
        $code = isset($probe['code']) ? (int) $probe['code'] : 0;
        return empty($probe['error']) && $code >= 200 && $code < 300;
    }

    protected function describeUrlProbe(array $probe)
    {
        $code = isset($probe['code']) ? (int) $probe['code'] : 0;
        $method = isset($probe['method']) ? (string) $probe['method'] : '';
        $technical = $this->probeTechnicalMessage($probe);
        if (!empty($probe['error'])) {
            return [
                'success' => false,
                'message' => '文件已写入，但访问链接检测失败：' . $this->classifyCurlError($probe['error']),
                'method' => $method,
                'http_code' => $code,
                'technical_message' => $technical,
            ];
        }
        if ($code >= 200 && $code < 300) {
            return [
                'success' => true,
                'message' => '访问链接可打开，HTTP ' . $code . '，检测方式：' . $method . '。',
                'method' => $method,
                'http_code' => $code,
                'technical_message' => $technical,
            ];
        }
        if ($code >= 300 && $code < 400) {
            return ['success' => false, 'message' => '访问链接返回跳转 HTTP ' . $code . '。请把访问域名填写为最终可访问的 HTTPS 地址，避免跳转到异常地址。', 'method' => $method, 'http_code' => $code, 'technical_message' => $technical];
        }
        if ($code === 401) {
            return ['success' => false, 'message' => '访问链接返回 401。上传可用，但外链需要登录认证，请开放读权限或配置公开访问域名。', 'method' => $method, 'http_code' => $code, 'technical_message' => $technical];
        }
        if ($code === 403) {
            return ['success' => false, 'message' => '访问链接返回 403。通常是 Bucket/空间未开放公共读，或自定义域名权限尚未生效。', 'method' => $method, 'http_code' => $code, 'technical_message' => $technical];
        }
        if ($code === 404) {
            return ['success' => false, 'message' => '访问链接返回 404。通常是访问域名未绑定当前 Bucket，或路径前缀不一致。', 'method' => $method, 'http_code' => $code, 'technical_message' => $technical];
        }
        if ($code >= 500) {
            return ['success' => false, 'message' => '访问链接返回 HTTP ' . $code . '。通常是 CDN、源站回源或厂商服务端异常。', 'method' => $method, 'http_code' => $code, 'technical_message' => $technical];
        }
        return ['success' => false, 'message' => '访问链接返回 HTTP ' . $code . '。', 'method' => $method, 'http_code' => $code, 'technical_message' => $technical];
    }

    protected function classifyCurlError($error)
    {
        $clean = $this->cleanError($error);
        $lower = strtolower($clean);
        if (strpos($lower, 'could not resolve') !== false || strpos($lower, 'resolve host') !== false) {
            return '域名 DNS 解析失败。请检查访问域名是否填写错误，或服务器 DNS 是否正常。原始信息：' . $clean;
        }
        if (strpos($lower, 'timed out') !== false || strpos($lower, 'timeout') !== false) {
            return '访问超时。请检查 CDN/源站是否可访问，或服务器出网、防火墙是否拦截。原始信息：' . $clean;
        }
        if (strpos($lower, 'ssl') !== false || strpos($lower, 'certificate') !== false) {
            return 'HTTPS 证书校验失败。请检查访问域名证书、服务器 CA 证书和系统时间。原始信息：' . $clean;
        }
        if (strpos($lower, 'connection refused') !== false || strpos($lower, 'failed to connect') !== false) {
            return '连接被拒绝。请检查访问域名是否指向正确服务，80/443 端口是否开放。原始信息：' . $clean;
        }
        return $clean;
    }

    protected function probeTechnicalMessage(array $probe)
    {
        $parts = [];
        if (!empty($probe['method'])) {
            $parts[] = 'method=' . $probe['method'];
        }
        if (isset($probe['code'])) {
            $parts[] = 'http=' . (int) $probe['code'];
        }
        if (!empty($probe['content_type'])) {
            $parts[] = 'content-type=' . $probe['content_type'];
        }
        if (!empty($probe['primary_ip'])) {
            $parts[] = 'ip=' . $probe['primary_ip'];
        }
        if (!empty($probe['total_ms'])) {
            $parts[] = 'time=' . (int) $probe['total_ms'] . 'ms';
        }
        if (!empty($probe['error'])) {
            $parts[] = 'error=' . $this->cleanError($probe['error']);
        }
        return implode(' | ', $parts);
    }

    protected function cleanError($message)
    {
        $message = trim(strip_tags((string) $message));
        $message = preg_replace('/\s+/', ' ', $message);
        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($message) > 420) {
                $message = mb_substr($message, 0, 420) . '...';
            }
        } elseif (strlen($message) > 1260) {
            $message = substr($message, 0, 1260) . '...';
        }
        return $message;
    }

    protected function humanizeCloudError($type, $message)
    {
        $clean = $this->cleanError($message);
        $lower = strtolower($clean);
        if (strpos($lower, 'signature') !== false || strpos($lower, 'sign') !== false) {
            return '签名校验失败，通常是密钥填错、Endpoint/Region 填错，或服务器时间偏差过大。原始信息：' . $clean;
        }
        if (strpos($lower, 'accessdenied') !== false || strpos($lower, 'access denied') !== false || strpos($lower, '403') !== false || strpos($lower, 'forbidden') !== false) {
            return '权限被拒绝，通常是 Key 没有当前 Bucket 的上传/删除权限，或 Bucket 不属于这个账号。原始信息：' . $clean;
        }
        if (strpos($lower, 'unauthorized') !== false || strpos($lower, '401') !== false || strpos($lower, 'bad token') !== false || strpos($lower, 'invalid token') !== false) {
            return '认证失败，通常是 Access Key、Secret Key、密码或 Token 填错。原始信息：' . $clean;
        }
        if (strpos($lower, 'nosuchbucket') !== false || (strpos($lower, 'bucket') !== false && strpos($lower, 'not') !== false)) {
            return 'Bucket 不存在或名称不匹配，请检查空间/桶名称是否复制完整。原始信息：' . $clean;
        }
        if ($type === 'webdav' && (strpos($lower, 'mkcol') !== false || strpos($lower, '409') !== false)) {
            return 'WebDAV 目录创建失败，通常是 Endpoint 路径不是可写目录，或账号没有创建目录权限。原始信息：' . $clean;
        }
        if (($type === 's3' || $type === 'r2') && (strpos($lower, 'authorizationheadermalformed') !== false || strpos($lower, 'region') !== false)) {
            return 'S3 签名区域不匹配，请检查 Region 是否与 Bucket 所在区域一致；Cloudflare R2 建议使用 auto。原始信息：' . $clean;
        }
        if ($type === 'cos' && strpos($lower, 'region') !== false) {
            return '腾讯云 Region 可能填写错误，例如广州应填 ap-guangzhou。原始信息：' . $clean;
        }
        if ($type === 'kodo' && (strpos($lower, 'incorrect region') !== false || strpos($lower, 'qiniu') !== false || strpos($lower, 'qiniup') !== false)) {
            return '七牛空间区域或上传域名不匹配，请按空间所在区域选择 z0/cn-east-2/z1/z2/na0/as0/ap-southeast-2/ap-southeast-3，或填写官方上传域名。原始信息：' . $clean;
        }
        if (strpos($lower, 'resolve') !== false || strpos($lower, 'could not') !== false || strpos($lower, 'timeout') !== false || strpos($lower, 'timed out') !== false) {
            return '网络连接失败，通常是 Endpoint 写错、服务器无法访问外网，或防火墙拦截。原始信息：' . $clean;
        }
        if (strpos($lower, 'ssl') !== false || strpos($lower, 'certificate') !== false) {
            return 'HTTPS 证书校验失败，请检查服务器 CA 证书、系统时间和 Endpoint 域名。原始信息：' . $clean;
        }
        return $clean;
    }
}
