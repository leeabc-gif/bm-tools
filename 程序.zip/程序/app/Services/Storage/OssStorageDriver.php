<?php
namespace App\Services\Storage;

class OssStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }
        $objectKey = $this->objectKey($objectKey);
        $contentType = isset($options['mime']) && $options['mime'] ? $options['mime'] : 'application/octet-stream';
        $md5 = hash_file('md5', $localPath, true);
        if ($md5 === false) {
            throw new \RuntimeException('读取本地文件失败，请检查文件权限。');
        }
        $contentMd5 = base64_encode($md5);
        $contentLength = filesize($localPath);
        $date = gmdate('D, d M Y H:i:s \G\M\T');
        $bucket = $this->config['bucket'];
        $url = $this->uploadUrl($objectKey);
        $canonicalKey = '/' . $bucket . '/' . $objectKey;
        $stringToSign = "PUT\n" . $contentMd5 . "\n" . $contentType . "\n" . $date . "\n" . $canonicalKey;
        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $this->config['secret_key'], true));
        $headers = [
            'Date: ' . $date,
            'Content-Type: ' . $contentType,
            'Content-MD5: ' . $contentMd5,
            'Content-Length: ' . $contentLength,
            'Authorization: OSS ' . $this->config['access_key'] . ':' . $signature,
        ];
        $this->curlFile('PUT', $url, $headers, $localPath);
        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => 'oss',
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $date = gmdate('D, d M Y H:i:s \G\M\T');
        $stringToSign = "DELETE\n\n\n" . $date . "\n/" . $this->config['bucket'] . "/" . $objectKey;
        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $this->config['secret_key'], true));
        $this->curl('DELETE', $this->uploadUrl($objectKey), [
            'Date: ' . $date,
            'Authorization: OSS ' . $this->config['access_key'] . ':' . $signature,
        ]);
        return true;
    }

    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || empty($this->config['endpoint'])) {
            return ['success' => false, 'message' => '阿里云 OSS 需要填写 AccessKey、SecretKey、Bucket 和 Endpoint。Endpoint 可填 oss-cn-hangzhou.aliyuncs.com 这种格式，不要填写 Bucket 域名。'];
        }
        $endpointHost = $this->normalizedHost($this->config['endpoint']);
        if ($endpointHost === '' || strpos($endpointHost, 'aliyuncs.com') === false) {
            return ['success' => false, 'message' => 'OSS Endpoint 应填写地域节点，例如 oss-cn-hangzhou.aliyuncs.com；如果使用自定义域名，请填到“自定义访问域名”，不要填到 Endpoint。'];
        }
        return ['success' => true, 'message' => 'OSS 基础配置完整，可以进行真实上传测试。'];
    }

    protected function uploadUrl($objectKey)
    {
        $endpoint = $this->endpoint(true);
        $host = $this->normalizedHost(parse_url($endpoint, PHP_URL_HOST));
        if ($host && strpos($host, $this->config['bucket'] . '.') === 0) {
            return $endpoint . '/' . $this->encodePath($objectKey);
        }
        return preg_replace('#^(https?://)#', '$1' . $this->config['bucket'] . '.', $endpoint) . '/' . $this->encodePath($objectKey);
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain) {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($objectKey);
        }
        return $this->uploadUrl($objectKey);
    }
}
