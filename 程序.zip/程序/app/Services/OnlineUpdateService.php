<?php
namespace App\Services;

use App\Core\Config;
use App\Core\Database;
use RuntimeException;
use ZipArchive;

class OnlineUpdateService
{
    protected $updatesDir;
    protected $backupsDir;
    protected $maxManifestBytes = 1048576;
    protected $maxPackageBytes = 134217728;

    public function __construct()
    {
        $this->updatesDir = APP_ROOT . '/storage/updates';
        $this->backupsDir = APP_ROOT . '/storage/update_backups';
    }

    public function currentVersion()
    {
        return setting('app_version', Config::get('app.version', '1.0.0'));
    }

    public function check($manifestUrl)
    {
        $manifestUrl = $this->validateRemoteUrl($manifestUrl, '更新清单地址');
        $manifest = $this->fetchJson($manifestUrl);
        $manifest = $this->normalizeManifest($manifest, $manifestUrl);
        $current = $this->currentVersion();

        return [
            'current_version' => $current,
            'latest_version' => $manifest['version'],
            'update_available' => version_compare($manifest['version'], $current, '>'),
            'manifest' => $manifest,
            'checked_at' => now(),
        ];
    }

    public function download($packageUrl, $sha256 = '', $version = '')
    {
        $packageUrl = $this->validateRemoteUrl($packageUrl, '更新包地址');
        $this->ensureDirectory($this->updatesDir);

        $versionSlug = preg_replace('/[^A-Za-z0-9._-]/', '-', $version ?: 'package');
        $fileName = 'bmtools-' . $versionSlug . '-' . date('YmdHis') . '.zip';
        $target = $this->updatesDir . '/' . $fileName;
        $this->downloadFile($packageUrl, $target);

        $hash = hash_file('sha256', $target);
        $sha256 = strtolower(trim((string) $sha256));
        if ($sha256 !== '' && !hash_equals($sha256, strtolower($hash))) {
            @unlink($target);
            throw new RuntimeException('更新包 SHA-256 校验失败，文件已删除。');
        }

        return [
            'file' => $fileName,
            'path' => $target,
            'size' => filesize($target),
            'sha256' => $hash,
            'version' => $version,
            'downloaded_at' => now(),
        ];
    }

    public function install($packageFile, $targetVersion = '')
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('当前 PHP 未启用 ZipArchive 扩展，无法解压更新包。');
        }

        $packagePath = $this->resolvePackagePath($packageFile);
        $zip = new ZipArchive();
        if ($zip->open($packagePath) !== true) {
            throw new RuntimeException('更新包无法打开，请确认文件是有效 ZIP。');
        }

        try {
            $manifest = $this->readPackageManifest($zip);
            if (!empty($manifest['min_php']) && version_compare(PHP_VERSION, (string) $manifest['min_php'], '<')) {
                throw new RuntimeException('当前 PHP 版本过低，更新包要求 PHP ' . $manifest['min_php'] . ' 或更高。');
            }

            if ($targetVersion === '' && !empty($manifest['version'])) {
                $targetVersion = (string) $manifest['version'];
            }

            $files = $this->collectPackageFiles($zip);
            $deleteFiles = $this->normalizeDeleteFiles(isset($manifest['delete']) ? $manifest['delete'] : []);
            $sqlFiles = $this->normalizeSqlFiles(isset($manifest['sql']) ? $manifest['sql'] : []);

            $this->ensureDirectory($this->backupsDir);
            $fileBackup = $this->backupFiles(array_merge($files, $deleteFiles));
            $dbBackup = $this->backupDatabase();

            $extracted = $this->extractFiles($zip, $files);
            $deleted = $this->deleteFiles($deleteFiles);
            $sqlExecuted = $this->executeSqlFiles($zip, $sqlFiles);

            if ($targetVersion !== '') {
                $this->saveSetting('app_version', $targetVersion);
            }
            $this->saveSetting('last_update_at', now());
            $this->saveSetting('last_update_package', basename($packagePath));

            return [
                'version' => $targetVersion,
                'file_backup' => $fileBackup,
                'database_backup' => $dbBackup,
                'extracted_count' => $extracted,
                'deleted_count' => $deleted,
                'sql_count' => $sqlExecuted,
                'installed_at' => now(),
            ];
        } finally {
            $zip->close();
        }
    }

    public function packages()
    {
        if (!is_dir($this->updatesDir)) {
            return [];
        }

        $rows = [];
        foreach (glob($this->updatesDir . '/*.zip') ?: [] as $file) {
            $rows[] = [
                'file' => basename($file),
                'size' => filesize($file),
                'mtime' => date('Y-m-d H:i:s', filemtime($file)),
                'sha256' => hash_file('sha256', $file),
            ];
        }
        usort($rows, function ($a, $b) {
            return strcmp($b['mtime'], $a['mtime']);
        });
        return $rows;
    }

    protected function fetchJson($url)
    {
        $body = $this->request($url, $this->maxManifestBytes);
        $data = json_decode($body, true);
        if (!is_array($data)) {
            throw new RuntimeException('更新清单不是有效 JSON。');
        }
        return $data;
    }

    protected function normalizeManifest(array $manifest, $manifestUrl)
    {
        $version = trim((string) (isset($manifest['version']) ? $manifest['version'] : ''));
        $packageUrl = trim((string) (isset($manifest['package_url']) ? $manifest['package_url'] : ''));
        if ($version === '') {
            throw new RuntimeException('更新清单缺少 version 字段。');
        }
        if ($packageUrl === '') {
            throw new RuntimeException('更新清单缺少 package_url 字段。');
        }

        $manifest['version'] = $version;
        $manifest['package_url'] = $this->resolveRemoteUrl($packageUrl, $manifestUrl);
        $manifest['package_sha256'] = strtolower(trim((string) (isset($manifest['package_sha256']) ? $manifest['package_sha256'] : '')));
        $manifest['released_at'] = isset($manifest['released_at']) ? (string) $manifest['released_at'] : '';
        $manifest['changelog'] = isset($manifest['changelog']) ? $manifest['changelog'] : [];
        if (is_string($manifest['changelog'])) {
            $manifest['changelog'] = [$manifest['changelog']];
        }
        if (!is_array($manifest['changelog'])) {
            $manifest['changelog'] = [];
        }
        $manifest['min_php'] = isset($manifest['min_php']) ? (string) $manifest['min_php'] : '';
        return $manifest;
    }

    protected function request($url, $maxBytes, $redirects = 0)
    {
        if (!extension_loaded('curl')) {
            throw new RuntimeException('当前 PHP 未启用 cURL 扩展，无法在线请求更新源。');
        }
        if ($redirects > 3) {
            throw new RuntimeException('更新源跳转次数过多。');
        }
        $url = $this->validateRemoteUrl($url, '更新源地址');

        $buffer = '';
        $redirectLocation = '';
        $ch = curl_init($url);
        $options = [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'BM-TOOLS-Updater/' . $this->currentVersion(),
            CURLOPT_HEADERFUNCTION => function ($ch, $header) use (&$redirectLocation) {
                if (preg_match('/^Location:\s*(.+)$/i', trim($header), $m)) {
                    $redirectLocation = trim($m[1]);
                }
                return strlen($header);
            },
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$buffer, $maxBytes) {
                $buffer .= $chunk;
                if (strlen($buffer) > $maxBytes) {
                    return 0;
                }
                return strlen($chunk);
            },
        ];
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            throw new RuntimeException('请求更新源失败：' . $error);
        }
        if (in_array($status, [301, 302, 303, 307, 308], true)) {
            if ($redirectLocation === '') {
                throw new RuntimeException('更新源跳转地址缺失。');
            }
            return $this->request($this->resolveRedirectUrl($redirectLocation, $url), $maxBytes, $redirects + 1);
        }
        if ($status < 200 || $status >= 300) {
            throw new RuntimeException('更新源返回 HTTP ' . $status . '。');
        }
        if ($buffer === '') {
            throw new RuntimeException('更新源返回内容为空。');
        }
        return $buffer;
    }

    protected function downloadFile($url, $target, $redirects = 0)
    {
        if (!extension_loaded('curl')) {
            throw new RuntimeException('当前 PHP 未启用 cURL 扩展，无法下载更新包。');
        }
        if ($redirects > 3) {
            throw new RuntimeException('更新包跳转次数过多。');
        }
        $url = $this->validateRemoteUrl($url, '更新包地址');

        $fp = fopen($target, 'wb');
        if (!$fp) {
            throw new RuntimeException('无法写入更新包目录：' . $target);
        }

        $written = 0;
        $redirectLocation = '';
        $ch = curl_init($url);
        $options = [
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'BM-TOOLS-Updater/' . $this->currentVersion(),
            CURLOPT_HEADERFUNCTION => function ($ch, $header) use (&$redirectLocation) {
                if (preg_match('/^Location:\s*(.+)$/i', trim($header), $m)) {
                    $redirectLocation = trim($m[1]);
                }
                return strlen($header);
            },
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use ($fp, &$written) {
                $written += strlen($chunk);
                if ($written > $this->maxPackageBytes) {
                    return 0;
                }
                return fwrite($fp, $chunk);
            },
        ];
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($errno) {
            @unlink($target);
            throw new RuntimeException('下载更新包失败：' . $error);
        }
        if (in_array($status, [301, 302, 303, 307, 308], true)) {
            @unlink($target);
            if ($redirectLocation === '') {
                throw new RuntimeException('更新包跳转地址缺失。');
            }
            $this->downloadFile($this->resolveRedirectUrl($redirectLocation, $url), $target, $redirects + 1);
            return;
        }
        if ($status < 200 || $status >= 300) {
            @unlink($target);
            throw new RuntimeException('更新包下载返回 HTTP ' . $status . '。');
        }
        if (!is_file($target) || filesize($target) <= 0) {
            @unlink($target);
            throw new RuntimeException('更新包下载结果为空。');
        }
    }

    protected function readPackageManifest(ZipArchive $zip)
    {
        $raw = false;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($this->isPackageManifestEntry($name)) {
                $raw = $zip->getFromName($name);
                break;
            }
        }
        if ($raw === false) {
            return [];
        }
        $manifest = json_decode($raw, true);
        if (!is_array($manifest)) {
            throw new RuntimeException('更新包内的 update.json 不是有效 JSON。');
        }
        return $manifest;
    }

    protected function collectPackageFiles(ZipArchive $zip)
    {
        $files = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (!$name || substr($name, -1) === '/') {
                continue;
            }
            if ($this->isPackageManifestEntry($name)) {
                continue;
            }
            $path = $this->normalizePackagePath($name);
            $files[] = $path;
        }
        return array_values(array_unique($files));
    }

    protected function isPackageManifestEntry($name)
    {
        $path = str_replace('\\', '/', trim((string) $name));
        $path = ltrim($path, '/');
        $parts = [];
        foreach (explode('/', $path) as $part) {
            if ($part === '' || $part === '.') {
                continue;
            }
            $parts[] = $part;
        }
        return implode('/', $parts) === 'update.json';
    }

    protected function normalizeDeleteFiles($files)
    {
        if (!is_array($files)) {
            return [];
        }
        $result = [];
        foreach ($files as $file) {
            $result[] = $this->normalizePackagePath((string) $file);
        }
        return array_values(array_unique($result));
    }

    protected function normalizeSqlFiles($files)
    {
        if (!is_array($files)) {
            return [];
        }
        $result = [];
        foreach ($files as $file) {
            $path = $this->normalizePackagePath((string) $file);
            if (substr($path, -4) !== '.sql') {
                throw new RuntimeException('SQL 升级文件必须以 .sql 结尾：' . $path);
            }
            $result[] = $path;
        }
        return array_values(array_unique($result));
    }

    protected function normalizePackagePath($path)
    {
        $path = str_replace('\\', '/', trim($path));
        $path = ltrim($path, '/');
        $parts = [];
        foreach (explode('/', $path) as $part) {
            if ($part === '' || $part === '.') {
                continue;
            }
            if ($part === '..') {
                throw new RuntimeException('更新包包含不安全路径：' . $path);
            }
            $parts[] = $part;
        }
        $path = implode('/', $parts);
        if ($path === '') {
            throw new RuntimeException('更新包包含空路径。');
        }
        if (!$this->isAllowedProjectPath($path)) {
            throw new RuntimeException('更新包尝试写入受保护路径：' . $path);
        }
        return $path;
    }

    protected function isAllowedProjectPath($path)
    {
        $blocked = [
            '.git/',
            'storage/',
            'public/uploads/',
            'config/database.php',
            '.env',
        ];
        foreach ($blocked as $prefix) {
            if ($path === rtrim($prefix, '/') || strpos($path, $prefix) === 0) {
                return false;
            }
        }

        $allowedPrefixes = [
            'app/',
            'public/',
            'database/',
            'config/app.php',
            'cron_monitor.php',
            'index.php',
            'bt-nginx-rewrite.conf',
            'README.md',
            'COMMERCIAL_CHANGELOG.md',
            'COMMERCIAL_ITERATION_CLEAN.md',
            'HTTP_AGENT_MONITOR_GUIDE.md',
            'SSH_MONITOR_COMMERCIAL_PLAN.md',
        ];
        foreach ($allowedPrefixes as $prefix) {
            if ($path === rtrim($prefix, '/') || strpos($path, $prefix) === 0) {
                return true;
            }
        }
        return false;
    }

    protected function extractFiles(ZipArchive $zip, array $files)
    {
        $count = 0;
        foreach ($files as $path) {
            $entryName = $this->findZipEntryName($zip, $path);
            $stream = $entryName ? $zip->getStream($entryName) : false;
            if (!$stream) {
                throw new RuntimeException('更新包缺少文件：' . $path);
            }
            $target = APP_ROOT . '/' . $path;
            $dir = dirname($target);
            $this->ensureDirectory($dir);
            $out = fopen($target, 'wb');
            if (!$out) {
                fclose($stream);
                throw new RuntimeException('无法写入文件：' . $path);
            }
            stream_copy_to_stream($stream, $out);
            fclose($out);
            fclose($stream);
            $count++;
        }
        return $count;
    }

    protected function deleteFiles(array $files)
    {
        $count = 0;
        foreach ($files as $path) {
            $target = APP_ROOT . '/' . $path;
            if (is_file($target)) {
                unlink($target);
                $count++;
            }
        }
        return $count;
    }

    protected function backupFiles(array $paths)
    {
        $paths = array_values(array_unique($paths));
        $fileName = 'files-' . date('Ymd-His') . '.zip';
        $backupPath = $this->backupsDir . '/' . $fileName;
        $zip = new ZipArchive();
        if ($zip->open($backupPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('无法创建文件备份包。');
        }
        $count = 0;
        foreach ($paths as $path) {
            $target = APP_ROOT . '/' . $path;
            if (is_file($target)) {
                $zip->addFile($target, $path);
                $count++;
            }
        }
        $zip->close();
        return ['file' => $fileName, 'path' => $backupPath, 'count' => $count];
    }

    protected function backupDatabase()
    {
        $fileName = 'database-' . date('Ymd-His') . '.sql';
        $path = $this->backupsDir . '/' . $fileName;
        $pdo = Database::getInstance();
        $prefix = Database::prefix();
        $tables = [];
        foreach ($pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_NUM) as $row) {
            if (strpos($row[0], $prefix) === 0) {
                $tables[] = $row[0];
            }
        }

        $fp = fopen($path, 'wb');
        if (!$fp) {
            throw new RuntimeException('无法创建数据库备份文件。');
        }
        fwrite($fp, "-- BM TOOLS update backup\n-- Created at " . now() . "\n\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
        foreach ($tables as $table) {
            $quoted = $this->quoteIdentifier($table);
            $create = $pdo->query('SHOW CREATE TABLE ' . $quoted)->fetch(\PDO::FETCH_ASSOC);
            fwrite($fp, 'DROP TABLE IF EXISTS ' . $quoted . ";\n");
            fwrite($fp, $create['Create Table'] . ";\n\n");
            $stmt = $pdo->query('SELECT * FROM ' . $quoted);
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $columns = [];
                $values = [];
                foreach ($row as $column => $value) {
                    $columns[] = $this->quoteIdentifier($column);
                    $values[] = $value === null ? 'NULL' : $pdo->quote((string) $value);
                }
                fwrite($fp, 'INSERT INTO ' . $quoted . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', $values) . ");\n");
            }
            fwrite($fp, "\n");
        }
        fwrite($fp, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fp);
        return ['file' => $fileName, 'path' => $path, 'tables' => count($tables)];
    }

    protected function executeSqlFiles(ZipArchive $zip, array $sqlFiles)
    {
        $count = 0;
        foreach ($sqlFiles as $sqlFile) {
            $entryName = $this->findZipEntryName($zip, $sqlFile);
            $sql = $entryName ? $zip->getFromName($entryName) : false;
            if ($sql === false) {
                throw new RuntimeException('更新包缺少 SQL 文件：' . $sqlFile);
            }
            $sql = str_replace('__PREFIX__', Database::prefix(), $sql);
            foreach ($this->splitSql($sql) as $statement) {
                Database::getInstance()->exec($statement);
            }
            $count++;
        }
        return $count;
    }

    protected function splitSql($sql)
    {
        $statements = [];
        $current = '';
        $inString = false;
        $quote = '';
        $len = strlen($sql);
        for ($i = 0; $i < $len; $i++) {
            $char = $sql[$i];
            $next = $i + 1 < $len ? $sql[$i + 1] : '';
            if (!$inString && $char === '-' && $next === '-') {
                while ($i < $len && $sql[$i] !== "\n") {
                    $i++;
                }
                continue;
            }
            if (!$inString && $char === '#') {
                while ($i < $len && $sql[$i] !== "\n") {
                    $i++;
                }
                continue;
            }
            if (!$inString && $char === '/' && $next === '*') {
                $i += 2;
                while ($i < $len - 1 && !($sql[$i] === '*' && $sql[$i + 1] === '/')) {
                    $i++;
                }
                $i++;
                continue;
            }
            if (($char === '\'' || $char === '"') && ($i === 0 || $sql[$i - 1] !== '\\')) {
                if (!$inString) {
                    $inString = true;
                    $quote = $char;
                } elseif ($quote === $char) {
                    $inString = false;
                    $quote = '';
                }
            }
            if (!$inString && $char === ';') {
                $statement = trim($current);
                if ($statement !== '') {
                    $statements[] = $statement;
                }
                $current = '';
                continue;
            }
            $current .= $char;
        }
        $statement = trim($current);
        if ($statement !== '') {
            $statements[] = $statement;
        }
        return $statements;
    }

    protected function findZipEntryName(ZipArchive $zip, $normalizedPath)
    {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (!$name || substr($name, -1) === '/') {
                continue;
            }
            try {
                if ($this->normalizePackagePath($name) === $normalizedPath) {
                    return $name;
                }
            } catch (RuntimeException $e) {
                continue;
            }
        }
        return null;
    }

    protected function resolvePackagePath($packageFile)
    {
        $packageFile = basename((string) $packageFile);
        if ($packageFile === '' || substr($packageFile, -4) !== '.zip') {
            throw new RuntimeException('更新包文件名无效。');
        }
        $path = $this->updatesDir . '/' . $packageFile;
        $realUpdates = realpath($this->updatesDir);
        $realFile = realpath($path);
        if (!$realUpdates || !$realFile || strpos($realFile, $realUpdates) !== 0 || !is_file($realFile)) {
            throw new RuntimeException('更新包不存在。');
        }
        return $realFile;
    }

    protected function validateRemoteUrl($url, $label)
    {
        $url = trim((string) $url);
        if ($url === '') {
            throw new RuntimeException($label . '不能为空。');
        }
        if (preg_match('/[\x00-\x1F\x7F]/', $url)) {
            throw new RuntimeException($label . '包含非法控制字符。');
        }
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
            throw new RuntimeException($label . '必须是 http 或 https 地址。');
        }
        if (!empty($parts['user']) || !empty($parts['pass'])) {
            throw new RuntimeException($label . '不能包含账号密码。');
        }
        $scheme = strtolower($parts['scheme']);
        $port = isset($parts['port']) ? (int) $parts['port'] : ($scheme === 'https' ? 443 : 80);
        if (!in_array($port, [80, 443], true)) {
            throw new RuntimeException($label . '仅允许使用 80 或 443 端口。');
        }
        $host = strtolower($parts['host']);
        if ($host === 'localhost' || substr($host, -6) === '.local') {
            throw new RuntimeException($label . '不能指向本机或局域网主机。');
        }
        $ips = $this->resolveHostIps($host);
        if (!$ips) {
            throw new RuntimeException($label . '域名无法解析。');
        }
        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                throw new RuntimeException($label . '不能使用内网或保留 IP。');
            }
        }
        return $url;
    }

    protected function resolveHostIps($host)
    {
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return [$host];
        }

        $ips = [];
        if (function_exists('dns_get_record')) {
            foreach (dns_get_record($host, DNS_A + DNS_AAAA) ?: [] as $record) {
                if (!empty($record['ip'])) {
                    $ips[] = $record['ip'];
                }
                if (!empty($record['ipv6'])) {
                    $ips[] = $record['ipv6'];
                }
            }
        }
        if (!$ips && function_exists('gethostbynamel')) {
            $ips = gethostbynamel($host) ?: [];
        }
        return array_values(array_unique($ips));
    }

    protected function resolveRedirectUrl($location, $baseUrl)
    {
        $location = trim((string) $location);
        if ($location === '') {
            throw new RuntimeException('跳转地址为空。');
        }
        if (preg_match('#^https?://#i', $location)) {
            return $this->validateRemoteUrl($location, '跳转地址');
        }
        if (strpos($location, '//') === 0) {
            $base = parse_url($baseUrl);
            return $this->validateRemoteUrl($base['scheme'] . ':' . $location, '跳转地址');
        }

        $base = parse_url($baseUrl);
        $path = isset($base['path']) ? $base['path'] : '/';
        if (strpos($location, '/') === 0) {
            $resolvedPath = $location;
        } else {
            $dir = rtrim(str_replace('\\', '/', dirname($path)), '/');
            $resolvedPath = ($dir === '' ? '' : $dir) . '/' . $location;
        }
        $resolved = $base['scheme'] . '://' . $base['host'] . (isset($base['port']) ? ':' . $base['port'] : '') . $resolvedPath;
        return $this->validateRemoteUrl($resolved, '跳转地址');
    }

    protected function resolveRemoteUrl($url, $baseUrl)
    {
        if (parse_url($url, PHP_URL_SCHEME)) {
            return $this->validateRemoteUrl($url, '更新包地址');
        }
        $base = parse_url($baseUrl);
        $path = isset($base['path']) ? $base['path'] : '/';
        $dir = rtrim(str_replace('\\', '/', dirname($path)), '/');
        $resolved = $base['scheme'] . '://' . $base['host'] . (isset($base['port']) ? ':' . $base['port'] : '') . $dir . '/' . ltrim($url, '/');
        return $this->validateRemoteUrl($resolved, '更新包地址');
    }

    protected function saveSetting($key, $value)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('settings') . ' (setting_key, setting_value, created_at, updated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
            [$key, $value, now(), now()]
        );
    }

    protected function ensureDirectory($path)
    {
        if (!is_dir($path) && !mkdir($path, 0755, true)) {
            throw new RuntimeException('目录创建失败：' . $path);
        }
        if (!is_writable($path)) {
            throw new RuntimeException('目录不可写：' . $path);
        }
    }

    protected function quoteIdentifier($name)
    {
        return '`' . str_replace('`', '``', $name) . '`';
    }
}
