<?php
namespace App\Services;

use App\Core\Database;

class TeamSpaceService
{
    const ROLE_OWNER = 'owner';
    const ROLE_ADMIN = 'admin';
    const ROLE_MEMBER = 'member';
    const ROLE_VIEWER = 'viewer';

    public function roleLabels()
    {
        return [
            self::ROLE_OWNER => '所有者',
            self::ROLE_ADMIN => '管理员',
            self::ROLE_MEMBER => '成员',
            self::ROLE_VIEWER => '观察者',
        ];
    }

    public function roleDescriptions()
    {
        return [
            self::ROLE_OWNER => '管理团队、成员和邀请，可删除团队。',
            self::ROLE_ADMIN => '管理成员和邀请，适合项目负责人。',
            self::ROLE_MEMBER => '参与团队协作，后续可接入团队文件空间。',
            self::ROLE_VIEWER => '只查看团队信息，适合客户或外部协作方。',
        ];
    }

    public function teamsForUser($userId)
    {
        return Database::fetchAll(
            'SELECT t.*, m.role AS my_role, m.joined_at AS my_joined_at,
                    u.username AS owner_username, u.nickname AS owner_nickname,
                    (SELECT COUNT(*) FROM ' . Database::table('team_members') . ' tm WHERE tm.team_id = t.id) AS member_count,
                    (SELECT COUNT(*) FROM ' . Database::table('team_invites') . ' ti WHERE ti.team_id = t.id AND ti.status = \'pending\' AND ti.expires_at > NOW()) AS pending_invite_count
             FROM ' . Database::table('teams') . ' t
             INNER JOIN ' . Database::table('team_members') . ' m ON m.team_id = t.id
             LEFT JOIN ' . Database::table('users') . ' u ON t.owner_id = u.id
             WHERE m.user_id = ? AND t.status <> \'deleted\'
             ORDER BY m.role = \'owner\' DESC, t.updated_at DESC, t.id DESC',
            [(int) $userId]
        );
    }

    public function overviewForUser($userId)
    {
        $teams = $this->teamsForUser($userId);
        $summary = [
            'team_count' => count($teams),
            'owned_count' => 0,
            'member_count' => 0,
            'pending_invites' => 0,
        ];
        foreach ($teams as $team) {
            if ((string) $team['my_role'] === self::ROLE_OWNER) {
                $summary['owned_count']++;
            }
            $summary['member_count'] += (int) $team['member_count'];
            $summary['pending_invites'] += (int) $team['pending_invite_count'];
        }
        return $summary;
    }

    public function findTeamForUser($teamId, $userId)
    {
        return Database::fetch(
            'SELECT t.*, m.role AS my_role, m.joined_at AS my_joined_at
             FROM ' . Database::table('teams') . ' t
             INNER JOIN ' . Database::table('team_members') . ' m ON m.team_id = t.id
             WHERE t.id = ? AND m.user_id = ? AND t.status <> \'deleted\'
             LIMIT 1',
            [(int) $teamId, (int) $userId]
        );
    }

    public function members($teamId)
    {
        return Database::fetchAll(
            'SELECT m.*, u.username, u.nickname, u.email
             FROM ' . Database::table('team_members') . ' m
             INNER JOIN ' . Database::table('users') . ' u ON m.user_id = u.id
             WHERE m.team_id = ?
             ORDER BY FIELD(m.role, \'owner\', \'admin\', \'member\', \'viewer\'), m.id ASC',
            [(int) $teamId]
        );
    }

    public function pendingInvites($teamId)
    {
        return Database::fetchAll(
            'SELECT i.*, u.username AS invited_username, u.nickname AS invited_nickname, u.email AS invited_email,
                    c.username AS created_username, c.nickname AS created_nickname
             FROM ' . Database::table('team_invites') . ' i
             LEFT JOIN ' . Database::table('users') . ' u ON i.invited_user_id = u.id
             LEFT JOIN ' . Database::table('users') . ' c ON i.created_by = c.id
             WHERE i.team_id = ? AND i.status = \'pending\' AND i.expires_at > NOW()
             ORDER BY i.id DESC',
            [(int) $teamId]
        );
    }

    public function invitesForUser($userId)
    {
        $user = Database::fetch('SELECT id, email FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [(int) $userId]);
        $email = $user && isset($user['email']) ? (string) $user['email'] : '';
        return Database::fetchAll(
            'SELECT i.*, t.name AS team_name, t.description AS team_description, t.slug AS team_slug,
                    u.username AS created_username, u.nickname AS created_nickname
             FROM ' . Database::table('team_invites') . ' i
             INNER JOIN ' . Database::table('teams') . ' t ON i.team_id = t.id
             LEFT JOIN ' . Database::table('users') . ' u ON i.created_by = u.id
             WHERE i.status = \'pending\'
               AND i.expires_at > NOW()
               AND (i.invited_user_id = ? OR (i.invited_email <> \'\' AND i.invited_email = ?))
             ORDER BY i.id DESC',
            [(int) $userId, $email]
        );
    }

    public function createTeam($ownerId, array $data)
    {
        $ownerId = (int) $ownerId;
        $name = $this->normalizeName(isset($data['name']) ? $data['name'] : '');
        $slug = $this->normalizeSlug(isset($data['slug']) ? $data['slug'] : '');
        if ($slug === '') {
            $slug = $this->normalizeSlug($name);
        }
        $this->assertValidSlug($slug);
        if ($this->slugExists($slug)) {
            throw new \RuntimeException('团队标识已存在，请换一个。');
        }

        Database::begin();
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('teams') . '
                 (owner_id, name, slug, description, avatar, status, created_at, updated_at)
                 VALUES (?,?,?,?,?,?,?,?)',
                [
                    $ownerId,
                    $name,
                    $slug,
                    $this->cleanText(isset($data['description']) ? $data['description'] : '', 500),
                    $this->cleanImageUrl(isset($data['avatar']) ? $data['avatar'] : ''),
                    'active',
                    now(),
                    now(),
                ]
            );
            $teamId = (int) Database::lastInsertId();
            Database::execute(
                'INSERT INTO ' . Database::table('team_members') . '
                 (team_id, user_id, role, title, joined_at, created_at, updated_at)
                 VALUES (?,?,?,?,?,?,?)',
                [$teamId, $ownerId, self::ROLE_OWNER, '所有者', now(), now(), now()]
            );
            Database::commit();
            return $teamId;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function updateTeam($teamId, $actorId, array $data)
    {
        $team = $this->requireTeam($teamId, $actorId);
        $this->assertCanManageTeam($team);
        $name = $this->normalizeName(isset($data['name']) ? $data['name'] : '');
        Database::execute(
            'UPDATE ' . Database::table('teams') . '
             SET name = ?, description = ?, avatar = ?, updated_at = ?
             WHERE id = ?',
            [
                $name,
                $this->cleanText(isset($data['description']) ? $data['description'] : '', 500),
                $this->cleanImageUrl(isset($data['avatar']) ? $data['avatar'] : ''),
                now(),
                (int) $teamId,
            ]
        );
        return $this->findTeamForUser($teamId, $actorId);
    }

    public function createInvite($teamId, $actorId, array $data)
    {
        $team = $this->requireTeam($teamId, $actorId);
        $this->assertCanManageMembers($team);
        $role = $this->normalizeRole(isset($data['role']) ? $data['role'] : self::ROLE_MEMBER, false);
        $email = strtolower(trim((string) (isset($data['email']) ? $data['email'] : '')));
        $username = trim((string) (isset($data['username']) ? $data['username'] : ''));
        $invitedUser = null;
        if ($username !== '') {
            $invitedUser = Database::fetch(
                'SELECT id, email FROM ' . Database::table('users') . ' WHERE username = ? OR email = ? LIMIT 1',
                [$username, $username]
            );
        }
        if (!$invitedUser && $email !== '') {
            $invitedUser = Database::fetch('SELECT id, email FROM ' . Database::table('users') . ' WHERE email = ? LIMIT 1', [$email]);
        }
        if (!$invitedUser && $email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException('邀请邮箱格式不正确。');
        }
        $invitedUserId = $invitedUser ? (int) $invitedUser['id'] : null;
        if ($invitedUserId && $this->isMember($teamId, $invitedUserId)) {
            throw new \RuntimeException('该用户已经是团队成员。');
        }
        if (!$invitedUserId && $email === '') {
            throw new \InvalidArgumentException('请填写用户名或邮箱。');
        }
        $email = $invitedUser && !empty($invitedUser['email']) ? (string) $invitedUser['email'] : $email;
        if ($this->pendingInviteExists((int) $teamId, $invitedUserId, $email)) {
            throw new \RuntimeException('已经存在一条未过期的邀请，请先等待对方处理或取消旧邀请。');
        }
        $token = bin2hex(random_bytes(20));
        $expiresAt = date('Y-m-d H:i:s', time() + 7 * 86400);
        Database::execute(
            'INSERT INTO ' . Database::table('team_invites') . '
             (team_id, invited_user_id, invited_email, role, token, status, message, created_by, accepted_at, expires_at, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            [
                (int) $teamId,
                $invitedUserId,
                $email,
                $role,
                hash('sha256', $token),
                'pending',
                $this->cleanText(isset($data['message']) ? $data['message'] : '', 300),
                (int) $actorId,
                null,
                $expiresAt,
                now(),
                now(),
            ]
        );
        return [
            'id' => (int) Database::lastInsertId(),
            'token' => $token,
            'expires_at' => $expiresAt,
        ];
    }

    public function acceptInvite($inviteId, $actorId)
    {
        $invite = $this->inviteForUser($inviteId, $actorId);
        if (!$invite) {
            throw new \RuntimeException('邀请不存在、已过期或无权接受。');
        }
        if ($this->isMember((int) $invite['team_id'], (int) $actorId)) {
            Database::execute(
                'UPDATE ' . Database::table('team_invites') . ' SET status = ?, accepted_at = ?, updated_at = ? WHERE id = ?',
                ['accepted', now(), now(), (int) $inviteId]
            );
            return (int) $invite['team_id'];
        }
        Database::begin();
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('team_members') . '
                 (team_id, user_id, role, title, joined_at, created_at, updated_at)
                 VALUES (?,?,?,?,?,?,?)',
                [(int) $invite['team_id'], (int) $actorId, $this->normalizeRole($invite['role'], false), '', now(), now(), now()]
            );
            Database::execute(
                'UPDATE ' . Database::table('team_invites') . ' SET status = ?, accepted_at = ?, updated_at = ? WHERE id = ?',
                ['accepted', now(), now(), (int) $inviteId]
            );
            Database::execute('UPDATE ' . Database::table('teams') . ' SET updated_at = ? WHERE id = ?', [now(), (int) $invite['team_id']]);
            Database::commit();
            return (int) $invite['team_id'];
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function declineInvite($inviteId, $actorId)
    {
        $invite = $this->inviteForUser($inviteId, $actorId);
        if (!$invite) {
            throw new \RuntimeException('邀请不存在、已过期或无权处理。');
        }
        Database::execute(
            'UPDATE ' . Database::table('team_invites') . ' SET status = ?, updated_at = ? WHERE id = ?',
            ['declined', now(), (int) $inviteId]
        );
        return true;
    }

    public function cancelInvite($inviteId, $actorId)
    {
        $invite = Database::fetch('SELECT * FROM ' . Database::table('team_invites') . ' WHERE id = ? LIMIT 1', [(int) $inviteId]);
        if (!$invite) {
            throw new \RuntimeException('邀请不存在。');
        }
        $team = $this->requireTeam((int) $invite['team_id'], $actorId);
        $this->assertCanManageMembers($team);
        Database::execute(
            'UPDATE ' . Database::table('team_invites') . ' SET status = ?, updated_at = ? WHERE id = ?',
            ['cancelled', now(), (int) $inviteId]
        );
        return true;
    }

    public function updateMember($teamId, $memberUserId, $actorId, array $data)
    {
        $team = $this->requireTeam($teamId, $actorId);
        $this->assertCanManageMembers($team);
        $member = $this->member((int) $teamId, (int) $memberUserId);
        if (!$member) {
            throw new \RuntimeException('成员不存在。');
        }
        if ($member['role'] === self::ROLE_OWNER) {
            throw new \RuntimeException('不能修改所有者角色。');
        }
        $role = $this->normalizeRole(isset($data['role']) ? $data['role'] : self::ROLE_MEMBER, false);
        Database::execute(
            'UPDATE ' . Database::table('team_members') . ' SET role = ?, title = ?, updated_at = ? WHERE team_id = ? AND user_id = ?',
            [$role, $this->cleanText(isset($data['title']) ? $data['title'] : '', 80), now(), (int) $teamId, (int) $memberUserId]
        );
        Database::execute('UPDATE ' . Database::table('teams') . ' SET updated_at = ? WHERE id = ?', [now(), (int) $teamId]);
        return true;
    }

    public function removeMember($teamId, $memberUserId, $actorId)
    {
        $team = $this->requireTeam($teamId, $actorId);
        $member = $this->member((int) $teamId, (int) $memberUserId);
        if (!$member) {
            throw new \RuntimeException('成员不存在。');
        }
        if ((int) $memberUserId === (int) $actorId) {
            return $this->leaveTeam($teamId, $actorId);
        }
        $this->assertCanManageMembers($team);
        if ($member['role'] === self::ROLE_OWNER) {
            throw new \RuntimeException('不能移除团队所有者。');
        }
        Database::execute('DELETE FROM ' . Database::table('team_members') . ' WHERE team_id = ? AND user_id = ?', [(int) $teamId, (int) $memberUserId]);
        Database::execute('UPDATE ' . Database::table('teams') . ' SET updated_at = ? WHERE id = ?', [now(), (int) $teamId]);
        return true;
    }

    public function leaveTeam($teamId, $actorId)
    {
        $member = $this->member((int) $teamId, (int) $actorId);
        if (!$member) {
            throw new \RuntimeException('你不在这个团队中。');
        }
        if ($member['role'] === self::ROLE_OWNER) {
            throw new \RuntimeException('所有者不能直接退出团队，请先转移所有权或删除团队。');
        }
        Database::execute('DELETE FROM ' . Database::table('team_members') . ' WHERE team_id = ? AND user_id = ?', [(int) $teamId, (int) $actorId]);
        Database::execute('UPDATE ' . Database::table('teams') . ' SET updated_at = ? WHERE id = ?', [now(), (int) $teamId]);
        return true;
    }

    public function deleteTeam($teamId, $actorId)
    {
        $team = $this->requireTeam($teamId, $actorId);
        if ((string) $team['my_role'] !== self::ROLE_OWNER) {
            throw new \RuntimeException('只有团队所有者可以删除团队。');
        }
        Database::execute('UPDATE ' . Database::table('teams') . ' SET status = ?, updated_at = ? WHERE id = ?', ['deleted', now(), (int) $teamId]);
        Database::execute('UPDATE ' . Database::table('team_invites') . ' SET status = ?, updated_at = ? WHERE team_id = ? AND status = \'pending\'', ['cancelled', now(), (int) $teamId]);
        return true;
    }

    public function requireTeam($teamId, $actorId)
    {
        $team = $this->findTeamForUser($teamId, $actorId);
        if (!$team) {
            throw new \RuntimeException('团队不存在或无权访问。');
        }
        return $team;
    }

    public function canManageMembers(array $team)
    {
        return in_array(isset($team['my_role']) ? $team['my_role'] : '', [self::ROLE_OWNER, self::ROLE_ADMIN], true);
    }

    public function canManageTeam(array $team)
    {
        return in_array(isset($team['my_role']) ? $team['my_role'] : '', [self::ROLE_OWNER, self::ROLE_ADMIN], true);
    }

    public function roleLabel($role)
    {
        $labels = $this->roleLabels();
        return isset($labels[$role]) ? $labels[$role] : $role;
    }

    protected function inviteForUser($inviteId, $userId)
    {
        $user = Database::fetch('SELECT id, email FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [(int) $userId]);
        $email = $user && isset($user['email']) ? (string) $user['email'] : '';
        return Database::fetch(
            'SELECT i.*
             FROM ' . Database::table('team_invites') . ' i
             INNER JOIN ' . Database::table('teams') . ' t ON i.team_id = t.id
             WHERE i.id = ? AND i.status = \'pending\' AND i.expires_at > NOW() AND t.status <> \'deleted\'
               AND (i.invited_user_id = ? OR (i.invited_email <> \'\' AND i.invited_email = ?))
             LIMIT 1',
            [(int) $inviteId, (int) $userId, $email]
        );
    }

    protected function isMember($teamId, $userId)
    {
        return (bool) $this->member($teamId, $userId);
    }

    protected function member($teamId, $userId)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('team_members') . ' WHERE team_id = ? AND user_id = ? LIMIT 1',
            [(int) $teamId, (int) $userId]
        );
    }

    protected function pendingInviteExists($teamId, $invitedUserId, $email)
    {
        if ($invitedUserId) {
            return (bool) Database::fetch(
                'SELECT id FROM ' . Database::table('team_invites') . ' WHERE team_id = ? AND invited_user_id = ? AND status = \'pending\' AND expires_at > NOW() LIMIT 1',
                [(int) $teamId, (int) $invitedUserId]
            );
        }
        $email = trim((string) $email);
        if ($email === '') {
            return false;
        }
        return (bool) Database::fetch(
            'SELECT id FROM ' . Database::table('team_invites') . ' WHERE team_id = ? AND invited_email = ? AND status = \'pending\' AND expires_at > NOW() LIMIT 1',
            [(int) $teamId, $email]
        );
    }

    protected function assertCanManageMembers(array $team)
    {
        if (!$this->canManageMembers($team)) {
            throw new \RuntimeException('当前角色不能管理团队成员。');
        }
    }

    protected function assertCanManageTeam(array $team)
    {
        if (!$this->canManageTeam($team)) {
            throw new \RuntimeException('当前角色不能编辑团队信息。');
        }
    }

    protected function normalizeRole($role, $allowOwner = true)
    {
        $role = trim((string) $role);
        $valid = [self::ROLE_ADMIN, self::ROLE_MEMBER, self::ROLE_VIEWER];
        if ($allowOwner) {
            $valid[] = self::ROLE_OWNER;
        }
        return in_array($role, $valid, true) ? $role : self::ROLE_MEMBER;
    }

    protected function normalizeName($name)
    {
        $name = $this->cleanText($name, 80);
        if ($name === '') {
            throw new \InvalidArgumentException('请填写团队名称。');
        }
        return $name;
    }

    protected function normalizeSlug($value)
    {
        $value = strtolower(trim((string) $value));
        $value = preg_replace('/[^a-z0-9-]+/', '-', $value);
        $value = preg_replace('/-+/', '-', $value);
        return trim(substr($value, 0, 40), '-');
    }

    protected function assertValidSlug($slug)
    {
        if ($slug === '' || strlen($slug) < 3 || !preg_match('/^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$/', $slug)) {
            throw new \InvalidArgumentException('团队标识需要 3-40 位小写字母、数字或中划线，且不能以中划线开头或结尾。');
        }
        if (in_array($slug, ['admin', 'api', 'team', 'teams', 'system', 'support', 'root', 'www'], true)) {
            throw new \InvalidArgumentException('该团队标识为系统保留，请更换。');
        }
    }

    protected function slugExists($slug)
    {
        return (bool) Database::fetch('SELECT id FROM ' . Database::table('teams') . ' WHERE slug = ? LIMIT 1', [$slug]);
    }

    protected function cleanText($value, $length)
    {
        $value = trim((string) $value);
        $value = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', ' ', $value);
        $value = trim(preg_replace('/\s+/', ' ', $value));
        return text_limit($value, $length, '');
    }

    protected function cleanImageUrl($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $value = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', '', $value);
        if (preg_match('#^https?://#i', $value) || strpos($value, '/') === 0) {
            return text_limit($value, 800, '');
        }
        return '';
    }
}
