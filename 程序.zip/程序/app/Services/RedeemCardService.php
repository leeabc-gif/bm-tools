<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Models\Order;
use App\Models\Package;
use App\Models\Recharge;

class RedeemCardService
{
    protected $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

    public function generate(array $options)
    {
        if (!$this->schemaReady()) {
            throw new \RuntimeException('卡密数据表未准备完成，请进入后台「功能巡检」或「系统维护」执行数据库一键修复后再生成卡密。');
        }

        $inputType = isset($options['type']) ? (string) $options['type'] : 'balance';
        if (!in_array($inputType, ['balance', 'package'], true)) {
            throw new \RuntimeException('请选择正确的卡密类型。');
        }
        $type = $inputType;
        $title = trim(isset($options['title']) ? $options['title'] : '');
        $count = max(1, min(200, (int) (isset($options['count']) ? $options['count'] : 1)));
        $amount = round((float) (isset($options['amount']) ? $options['amount'] : 0), 2);
        $packageId = (int) (isset($options['package_id']) ? $options['package_id'] : 0);
        $durationDays = max(0, (int) (isset($options['duration_days']) ? $options['duration_days'] : 0));
        $channel = text_limit(trim(isset($options['channel']) ? $options['channel'] : ''), 80);
        $remark = text_limit(trim(isset($options['remark']) ? $options['remark'] : ''), 255);
        $prefix = $this->normalizePrefix(isset($options['prefix']) ? $options['prefix'] : 'BM');
        $expireAt = $this->normalizeDateTime(isset($options['expire_at']) ? $options['expire_at'] : '');
        if ($expireAt !== null && strtotime($expireAt) <= time()) {
            throw new \RuntimeException('过期时间必须晚于当前时间。');
        }

        if ($title === '') {
            $title = $type === 'balance' ? '余额充值卡' : '套餐兑换卡';
        }
        if ($type === 'balance' && $amount <= 0) {
            throw new \RuntimeException('余额卡金额必须大于 0。');
        }
        if ($type === 'package') {
            $package = (new Package())->find($packageId);
            if (!$package) {
                throw new \RuntimeException('请选择要兑换的套餐。');
            }
        }

        $batchNo = 'CARD' . date('YmdHis') . mt_rand(100, 999);
        $codes = [];
        for ($i = 0; $i < $count; $i++) {
            $code = $this->uniqueCode($prefix);
            $normalized = $this->normalizeCode($code);
            Database::execute(
                'INSERT INTO ' . Database::table('redeem_cards') . ' (batch_no, title, type, code_hash, code_preview, amount, package_id, duration_days, channel, expire_at, status, remark, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $batchNo,
                    $title,
                    $type,
                    $this->codeHash($normalized),
                    $this->preview($normalized),
                    $type === 'balance' ? $amount : 0,
                    $type === 'package' ? $packageId : null,
                    $type === 'package' ? $durationDays : 0,
                    $channel,
                    $expireAt,
                    'unused',
                    $remark,
                    isset($options['created_by']) ? (int) $options['created_by'] : null,
                    now(),
                    now(),
                ]
            );
            $codes[] = $code;
        }

        return [
            'batch_no' => $batchNo,
            'type' => $type,
            'title' => $title,
            'count' => $count,
            'codes' => $codes,
        ];
    }

    public function redeem($userId, $rawCode)
    {
        if (!$this->schemaReady()) {
            throw new \RuntimeException('卡密数据表未准备完成，请管理员进入后台「功能巡检」或「系统维护」执行数据库一键修复。');
        }

        $normalized = $this->normalizeCode($rawCode);
        if ($normalized === '' || strlen($normalized) < 12) {
            $this->hitRedeemLimit($userId);
            throw new \RuntimeException('请输入完整卡密。');
        }

        $this->assertRedeemLimit($userId);
        $hash = $this->codeHash($normalized);
        $ip = Auth::ip();

        Database::begin();
        try {
            $card = Database::fetch('SELECT * FROM ' . Database::table('redeem_cards') . ' WHERE code_hash = ? LIMIT 1 FOR UPDATE', [$hash]);
            if (!$card) {
                Database::rollBack();
                $this->hitRedeemLimit($userId);
                throw new \RuntimeException('卡密不存在，请检查是否输入完整。');
            }
            if ($card['status'] !== 'unused') {
                Database::rollBack();
                $this->hitRedeemLimit($userId);
                throw new \RuntimeException($card['status'] === 'used' ? '这张卡密已经被兑换。' : '这张卡密已停用。');
            }
            if (!empty($card['expire_at']) && strtotime($card['expire_at']) < time()) {
                Database::rollBack();
                throw new \RuntimeException('这张卡密已过期。');
            }

            if ($card['type'] === 'balance') {
                $result = $this->redeemBalanceCard($userId, $card, $ip);
            } else {
                $result = $this->redeemPackageCard($userId, $card, $ip);
            }

            Database::commit();
            $this->clearRedeemLimit($userId);
            return $result;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function stats()
    {
        if (!$this->schemaReady()) {
            return ['total' => 0, 'unused' => 0, 'used' => 0, 'disabled' => 0, 'balance_amount' => 0, 'used_balance_amount' => 0];
        }
        $row = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(status = 'unused') AS unused,
                    SUM(status = 'used') AS used,
                    SUM(status = 'disabled') AS disabled,
                    COALESCE(SUM(CASE WHEN type = 'balance' THEN amount ELSE 0 END),0) AS balance_amount,
                    COALESCE(SUM(CASE WHEN type = 'balance' AND status = 'used' THEN amount ELSE 0 END),0) AS used_balance_amount
             FROM " . Database::table('redeem_cards')
        );
        return [
            'total' => $row ? (int) $row['total'] : 0,
            'unused' => $row ? (int) $row['unused'] : 0,
            'used' => $row ? (int) $row['used'] : 0,
            'disabled' => $row ? (int) $row['disabled'] : 0,
            'balance_amount' => $row ? (float) $row['balance_amount'] : 0,
            'used_balance_amount' => $row ? (float) $row['used_balance_amount'] : 0,
        ];
    }

    public function recentForUser($userId, $limit = 20)
    {
        if (!$this->schemaReady()) {
            return [];
        }
        $limit = max(1, min(100, (int) $limit));
        return Database::fetchAll(
            'SELECT c.*, p.name AS package_name, o.order_no
             FROM ' . Database::table('redeem_cards') . ' c
             LEFT JOIN ' . Database::table('packages') . ' p ON c.package_id = p.id
             LEFT JOIN ' . Database::table('orders') . ' o ON c.order_id = o.id
             WHERE c.used_by = ?
             ORDER BY c.used_at DESC, c.id DESC' . Database::limitClause($limit, 1, 100),
            [$userId]
        );
    }

    protected function redeemBalanceCard($userId, array $card, $ip)
    {
        $amount = round((float) $card['amount'], 2);
        if ($amount <= 0) {
            throw new \RuntimeException('卡密金额异常，请联系管理员处理。');
        }

        $order = (new Order())->createOrder($userId, 'recharge', $amount, 'card_code', null, '余额卡密充值：' . $card['title'], $amount);
        (new Order())->markPaid($order['id'], 'CARD-' . $card['id']);
        $rechargeId = (new Recharge())->create([
            'user_id' => $userId,
            'order_id' => $order['id'],
            'amount' => $amount,
            'payment_method' => 'card_code',
            'status' => 'paid',
            'audit_remark' => '卡密自动入账：' . $card['code_preview'],
            'paid_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        (new BalanceService())->add($userId, $amount, 'recharge', 'recharge', $rechargeId, '余额卡密充值：' . $card['title']);
        $this->markUsed($card['id'], $userId, $order['id'], $ip);
        (new NotificationService())->send($userId, 'recharge', '余额卡密兑换成功', '你已通过卡密充值 ¥' . number_format($amount, 2) . '。');

        return [
            'type' => 'balance',
            'message' => '兑换成功，余额已入账 ¥' . number_format($amount, 2) . '。',
            'amount' => $amount,
        ];
    }

    protected function redeemPackageCard($userId, array $card, $ip)
    {
        $package = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [(int) $card['package_id']]);
        if (!$package || (int) $package['status'] !== 1) {
            throw new \RuntimeException('卡密绑定的套餐不存在或已停用，请联系管理员处理。');
        }

        $order = (new Order())->createOrder($userId, 'package', (float) $package['price'], 'card_code', (int) $package['id'], '套餐卡密兑换：' . $card['title'], 0);
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1 FOR UPDATE', [$userId]);
        if (!$user) {
            throw new \RuntimeException('用户不存在。');
        }
        $expire = $this->calculatePackageExpire($user, $package, (int) $card['duration_days']);
        Database::execute(
            'UPDATE ' . Database::table('users') . ' SET package_id = ?, package_expire_time = ?, total_storage = ?, total_traffic = ?, updated_at = ? WHERE id = ?',
            [$package['id'], $expire, $package['storage_limit'], $package['traffic_limit'], now(), $userId]
        );
        (new Order())->markPaid($order['id'], 'CARD-' . $card['id']);
        $this->markUsed($card['id'], $userId, $order['id'], $ip);
        (new NotificationService())->send($userId, 'package', '套餐卡密兑换成功', '你已兑换套餐：' . $package['name'] . '。');

        return [
            'type' => 'package',
            'message' => '兑换成功，套餐已切换为：' . $package['name'] . '。',
            'package' => $package,
        ];
    }

    protected function markUsed($cardId, $userId, $orderId, $ip)
    {
        Database::execute(
            'UPDATE ' . Database::table('redeem_cards') . " SET status = 'used', used_by = ?, used_ip = ?, used_at = ?, order_id = ?, updated_at = ? WHERE id = ?",
            [$userId, substr((string) $ip, 0, 45), now(), $orderId, now(), $cardId]
        );
    }

    protected function calculatePackageExpire(array $user, array $package, $cardDurationDays)
    {
        $days = $cardDurationDays > 0 ? $cardDurationDays : (int) $package['duration_days'];
        if ($package['duration_type'] === 'forever' && $cardDurationDays <= 0) {
            return null;
        }
        $base = time();
        if (!empty($user['package_expire_time']) && strtotime($user['package_expire_time']) > $base && (int) $user['package_id'] === (int) $package['id']) {
            $base = strtotime($user['package_expire_time']);
        }
        return date('Y-m-d H:i:s', $base + (max(1, $days) * 86400));
    }

    protected function uniqueCode($prefix)
    {
        for ($i = 0; $i < 20; $i++) {
            $code = $this->makeCode($prefix);
            $hash = $this->codeHash($this->normalizeCode($code));
            $exists = Database::fetch('SELECT id FROM ' . Database::table('redeem_cards') . ' WHERE code_hash = ? LIMIT 1', [$hash]);
            if (!$exists) {
                return $code;
            }
        }
        throw new \RuntimeException('卡密生成重复，请重试。');
    }

    protected function makeCode($prefix)
    {
        $raw = '';
        for ($i = 0; $i < 16; $i++) {
            $raw .= $this->alphabet[random_int(0, strlen($this->alphabet) - 1)];
        }
        return $prefix . '-' . implode('-', str_split($raw, 4));
    }

    protected function normalizePrefix($prefix)
    {
        $prefix = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $prefix));
        return substr($prefix ?: 'BM', 0, 8);
    }

    protected function normalizeCode($code)
    {
        return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $code));
    }

    protected function codeHash($normalizedCode)
    {
        return hash('sha256', $normalizedCode);
    }

    protected function preview($normalizedCode)
    {
        return '****' . substr($normalizedCode, -8);
    }

    protected function normalizeDateTime($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace('T', ' ', $value);
        if (strlen($value) === 16) {
            $value .= ':00';
        }
        return $value;
    }

    protected function assertRedeemLimit($userId)
    {
        $identity = $this->limitIdentity($userId);
        $result = (new RateLimitService())->check('redeem_card', $identity, 900);
        if (!empty($result['limited'])) {
            throw new \RuntimeException('卡密尝试过于频繁，请稍后再试。');
        }
    }

    protected function hitRedeemLimit($userId)
    {
        $identity = $this->limitIdentity($userId);
        (new RateLimitService())->hit('redeem_card', $identity, 8, 900, 900, '卡密兑换：' . $identity, Auth::ip());
    }

    protected function clearRedeemLimit($userId)
    {
        (new RateLimitService())->clear('redeem_card', $this->limitIdentity($userId));
    }

    protected function limitIdentity($userId)
    {
        return (int) $userId . '|' . Auth::ip();
    }

    protected function schemaReady()
    {
        try {
            if (DatabaseUpgradeService::ensureRedeemCardSchema()) {
                return $this->hasRequiredSchema();
            }
        } catch (\Throwable $e) {
            return false;
        }
        try {
            return $this->hasRequiredSchema();
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function hasRequiredSchema()
    {
        $table = Database::table('redeem_cards');
        if (!Database::tableExists($table)) {
            return false;
        }
        $required = [
            'batch_no', 'title', 'type', 'code_hash', 'code_preview', 'amount',
            'package_id', 'duration_days', 'channel', 'expire_at', 'status',
            'used_by', 'used_ip', 'used_at', 'order_id', 'remark', 'created_by',
            'created_at', 'updated_at',
        ];
        foreach ($required as $column) {
            if (!Database::columnExists($table, $column)) {
                return false;
            }
        }
        return true;
    }
}
