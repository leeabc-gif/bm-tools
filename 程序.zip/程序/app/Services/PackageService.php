<?php
namespace App\Services;

use App\Core\Database;
use App\Models\Order;
use App\Models\Package;
use App\Services\Payment\PaymentManager;
use App\Services\Payment\PaymentService;

class PackageService
{
    public function buy($userId, $packageId, $paymentMethod = 'balance', $couponCode = '')
    {
        $couponCode = strtoupper(trim((string) $couponCode));
        $marketingReady = $this->marketingSchemaReady();
        if ($couponCode !== '' && !$marketingReady) {
            throw new \RuntimeException('优惠码数据结构未准备完成，请管理员进入后台「数据库巡检」执行一键修复。');
        }
        $paymentMethod = trim((string) $paymentMethod);
        if ($paymentMethod === '') {
            $paymentMethod = 'balance';
        }

        $package = (new Package())->find($packageId);
        if (!$package || (int) $package['status'] !== 1) {
            throw new \RuntimeException('套餐不存在或已停用。');
        }
        $this->assertPaymentMethodEnabled($paymentMethod);

        Database::begin();
        try {
            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1 FOR UPDATE', [$userId]);
            if (!$user) {
                throw new \RuntimeException('用户不存在。');
            }

            $originalAmount = $this->calculatePayAmount($user, $package);
            $couponQuote = $couponCode !== ''
                ? (new CouponService())->quote($userId, $package, $originalAmount, $couponCode)
                : $this->emptyCouponQuote($originalAmount);
            $payAmount = $couponQuote['final_amount'];
            $remark = $this->packageOrderRemark($couponQuote);

            if ($paymentMethod === 'balance' || (float) $payAmount <= 0) {
                if ((float) $user['balance'] < $payAmount) {
                    throw new \RuntimeException('账户余额不足，请先充值。');
                }
                $order = (new Order())->createOrder($userId, 'package', $originalAmount, 'balance', $packageId, $remark, $payAmount);
                if ($payAmount > 0) {
                    (new BalanceService())->subtract($userId, $payAmount, 'consume', 'order', $order['id'], '购买套餐：' . $package['name']);
                }
                (new CouponService())->redeem($couponQuote['coupon'], $userId, $order['id'], $packageId, $couponQuote['discount'], $payAmount);
                $expire = $this->calculateExpire($user, $package);
                Database::execute(
                    'UPDATE ' . Database::table('users') . ' SET package_id = ?, package_expire_time = ?, total_storage = ?, total_traffic = ?, updated_at = ? WHERE id = ?',
                    [$package['id'], $expire, $package['storage_limit'], $package['traffic_limit'], now(), $userId]
                );
                (new Order())->markPaid($order['id'], 'BALANCE-' . $order['order_no']);
                (new NotificationService())->send($userId, 'package', '套餐购买成功', '你已成功购买 ' . $package['name'] . '。');
                Database::commit();
                return ['mode' => 'paid', 'order' => $order, 'package' => $package];
            }

            $order = (new Order())->createOrder($userId, 'package', $originalAmount, $paymentMethod, $packageId, $remark, $payAmount);
            Database::commit();

            $gateway = PaymentManager::driver($paymentMethod);
            $result = $gateway->create($order);
            return ['mode' => 'pending', 'order' => $order, 'package' => $package, 'gateway' => $result];
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function buyWithBalance($userId, $packageId, $couponCode = '')
    {
        $result = $this->buy($userId, $packageId, 'balance', $couponCode);
        return !empty($result['order']);
    }

    protected function packageOrderRemark(array $couponQuote)
    {
        $remark = '套餐购买待支付';
        if (!empty($couponQuote['coupon'])) {
            $remark .= ' [coupon:' . $couponQuote['coupon']['code'] . '][discount:' . number_format((float) $couponQuote['discount'], 2, '.', '') . ']';
        }
        return $remark;
    }

    protected function emptyCouponQuote($amount)
    {
        $amount = round(max(0, (float) $amount), 2);
        return [
            'coupon' => null,
            'discount' => 0.00,
            'final_amount' => $amount,
            'message' => '',
        ];
    }

    protected function marketingSchemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureMarketingSchema();
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function assertPaymentMethodEnabled($paymentMethod)
    {
        $payment = Database::fetch(
            'SELECT code, is_enabled FROM ' . Database::table('payment_config') . ' WHERE code = ? LIMIT 1',
            [$paymentMethod]
        );
        if (!$payment || (int) $payment['is_enabled'] !== 1) {
            throw new \RuntimeException('当前支付方式未启用，请重新选择。');
        }
    }

    protected function calculateExpire(array $user, array $package)
    {
        if ($package['duration_type'] === 'forever') {
            return null;
        }
        $base = time();
        if (!empty($user['package_expire_time']) && strtotime($user['package_expire_time']) > $base && (int) $user['package_id'] === (int) $package['id']) {
            $base = strtotime($user['package_expire_time']);
        }
        return date('Y-m-d H:i:s', $base + ((int) $package['duration_days'] * 86400));
    }

    protected function calculatePayAmount(array $user, array $newPackage)
    {
        $price = (float) $newPackage['price'];
        if (empty($user['package_id']) || (int) $user['package_id'] === (int) $newPackage['id']) {
            return $price;
        }

        if (empty($user['package_expire_time']) || strtotime($user['package_expire_time']) <= time()) {
            return $price;
        }

        $oldPackage = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        if (!$oldPackage || (float) $oldPackage['price'] <= 0 || (int) $oldPackage['duration_days'] <= 0) {
            return $price;
        }

        $remainingDays = max(0, (strtotime($user['package_expire_time']) - time()) / 86400);
        $credit = ((float) $oldPackage['price']) * min(1, $remainingDays / max(1, (int) $oldPackage['duration_days']));
        return round(max(0, $price - $credit), 2);
    }
}
