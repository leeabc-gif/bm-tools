<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;

class RepositoryService
{
    public function repositoriesForUser($userId)
    {
        $this->ensureSchemaReady();
        return Database::fetchAll('SELECT * FROM ' . Database::table('file_repositories') . ' WHERE user_id = ? ORDER BY id DESC', [(int) $userId]);
    }

    public function repositoryForUser(array $user)
    {
        $this->ensureSchemaReady();
        $repo = Database::fetch('SELECT * FROM ' . Database::table('file_repositories') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$user['id']]);
        if ($repo) {
            return $repo;
        }
        return $this->createRepository($user);
    }

    public function findUserRepository($userId, $id)
    {
        $this->ensureSchemaReady();
        return Database::fetch('SELECT * FROM ' . Database::table('file_repositories') . ' WHERE id = ? AND user_id = ? LIMIT 1', [(int) $id, (int) $userId]);
    }

    public function createRepository(array $user, array $input = [])
    {
        $this->ensureSchemaReady();
        $ownerName = !empty($user['nickname']) ? $user['nickname'] : $user['username'];
        $title = trim((string) $this->input($input, 'title', $ownerName . ' 的个人仓库'));
        if ($title === '') {
            $title = $ownerName . ' 的个人仓库';
        }
        $slugInput = trim((string) $this->input($input, 'slug', ''));
        $base = $slugInput !== '' ? $slugInput : (!empty($user['username']) ? $user['username'] : 'user-' . $user['id']);
        $slug = $this->uniqueSlug($this->slugify($base));
        $coverImage = $this->cleanUrl((string) $this->input($input, 'cover_image', ''));
        $tags = $this->normalizeTags((string) $this->input($input, 'tags', ''));
        $description = trim((string) $this->input($input, 'description', '这里收录了我公开分享的网盘资料。'));

        Database::execute(
            'INSERT INTO ' . Database::table('file_repositories') . ' (user_id, title, slug, description, cover_image, tags, access_type, expire_at, max_views, max_downloads, ip_daily_view_limit, ip_daily_download_limit, allow_download, show_owner, status, admin_status, admin_remark, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [
                $user['id'],
                text_limit($title, 120),
                $slug,
                text_limit($description, 500),
                text_limit($coverImage, 800),
                text_limit($tags, 255),
                'public',
                null,
                0,
                0,
                0,
                0,
                1,
                1,
                1,
                1,
                '',
                now(),
                now(),
            ]
        );
        return Database::fetch('SELECT * FROM ' . Database::table('file_repositories') . ' WHERE id = ? LIMIT 1', [Database::lastInsertId()]);
    }

    public function findBySlug($slug)
    {
        $this->ensureSchemaReady();
        return Database::fetch('SELECT r.*, u.username, u.nickname, u.avatar FROM ' . Database::table('file_repositories') . ' r LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id WHERE r.slug = ? LIMIT 1', [$slug]);
    }

    public function saveRepository($repo, array $input)
    {
        $this->ensureSchemaReady();
        $title = trim((string) $this->input($input, 'title', ''));
        $slug = $this->slugify((string) $this->input($input, 'slug', ''));
        $description = trim((string) $this->input($input, 'description', ''));
        $accessType = (string) $this->input($input, 'access_type', 'public');
        $accessType = in_array($accessType, ['public', 'password', 'private'], true) ? $accessType : 'public';

        if ($title === '') {
            throw new \RuntimeException('请填写仓库名称。');
        }
        if ($slug === '') {
            throw new \RuntimeException('请填写自定义链接。');
        }
        if ($this->reservedSlug($slug)) {
            throw new \RuntimeException('这个链接为系统保留地址，请换一个。');
        }
        if ($this->slugExists($slug, (int) $repo['id'])) {
            throw new \RuntimeException('这个自定义链接已被使用，请换一个。');
        }

        $expireAt = $this->normalizeDateTime($this->input($input, 'expire_at', ''));
        $data = [
            'title' => text_limit($title, 120),
            'slug' => $slug,
            'description' => text_limit($description, 500),
            'cover_image' => text_limit($this->cleanUrl((string) $this->input($input, 'cover_image', '')), 800),
            'tags' => text_limit($this->normalizeTags((string) $this->input($input, 'tags', '')), 255),
            'access_type' => $accessType,
            'expire_at' => $expireAt,
            'max_views' => $this->boundedInt($this->input($input, 'max_views', 0), 0, 100000000),
            'max_downloads' => $this->boundedInt($this->input($input, 'max_downloads', 0), 0, 100000000),
            'ip_daily_view_limit' => $this->boundedInt($this->input($input, 'ip_daily_view_limit', 0), 0, 1000000),
            'ip_daily_download_limit' => $this->boundedInt($this->input($input, 'ip_daily_download_limit', 0), 0, 1000000),
            'allow_download' => !empty($input['allow_download']) ? 1 : 0,
            'show_owner' => !empty($input['show_owner']) ? 1 : 0,
            'status' => !empty($input['status']) ? 1 : 0,
            'updated_at' => now(),
        ];

        $password = trim((string) $this->input($input, 'password', ''));
        if ($accessType === 'password') {
            if ($password !== '') {
                $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
            } elseif (empty($repo['password_hash'])) {
                throw new \RuntimeException('密码访问模式需要设置访问密码。');
            }
        }
        if ($accessType !== 'password') {
            $data['password_hash'] = null;
        }

        $sets = [];
        $params = [];
        foreach ($data as $key => $value) {
            $sets[] = $key . ' = ?';
            $params[] = $value;
        }
        $params[] = $repo['id'];
        Database::execute('UPDATE ' . Database::table('file_repositories') . ' SET ' . implode(',', $sets) . ' WHERE id = ?', $params);
    }

    public function saveItem($repo, $fileId, $visibility, $note = '', $sortOrder = 0)
    {
        $this->ensureSchemaReady();
        $fileId = (int) $fileId;
        if ($fileId <= 0) {
            throw new \RuntimeException('请选择要加入仓库的文件。');
        }
        $file = Database::fetch('SELECT * FROM ' . Database::table('files') . ' WHERE id = ? AND user_id = ? LIMIT 1', [$fileId, $repo['user_id']]);
        if (!$file) {
            throw new \RuntimeException('文件不存在或不属于你。');
        }
        $visibility = $visibility === 'private' ? 'private' : 'public';
        $note = text_limit(trim((string) $note), 255);
        $sortOrder = $this->boundedInt($sortOrder, -999999, 999999);
        $exists = Database::fetch('SELECT id FROM ' . Database::table('file_repository_items') . ' WHERE repository_id = ? AND file_id = ? LIMIT 1', [$repo['id'], $fileId]);
        if ($exists) {
            Database::execute(
                'UPDATE ' . Database::table('file_repository_items') . ' SET visibility = ?, note = ?, sort_order = ?, updated_at = ? WHERE id = ?',
                [$visibility, $note, $sortOrder, now(), $exists['id']]
            );
        } else {
            Database::execute(
                'INSERT INTO ' . Database::table('file_repository_items') . ' (repository_id, user_id, file_id, visibility, note, sort_order, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)',
                [$repo['id'], $repo['user_id'], $fileId, $visibility, $note, $sortOrder, now(), now()]
            );
        }
    }

    public function removeItem($repo, $fileId)
    {
        Database::execute('DELETE FROM ' . Database::table('file_repository_items') . ' WHERE repository_id = ? AND file_id = ? AND user_id = ?', [$repo['id'], $fileId, $repo['user_id']]);
    }

    public function batchSaveItems($repo, array $fileIds, $visibility)
    {
        $visibility = $visibility === 'private' ? 'private' : 'public';
        $count = 0;
        foreach ($this->normalizeIds($fileIds) as $fileId) {
            $this->saveItem($repo, $fileId, $visibility);
            $count++;
        }
        return $count;
    }

    public function batchRemoveItems($repo, array $fileIds)
    {
        $ids = $this->normalizeIds($fileIds);
        if (!$ids) {
            return 0;
        }
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $params = array_merge([$repo['id'], $repo['user_id']], $ids);
        Database::execute('DELETE FROM ' . Database::table('file_repository_items') . ' WHERE repository_id = ? AND user_id = ? AND file_id IN (' . $placeholders . ')', $params);
        return count($ids);
    }

    public function manageFiles($repo, $keyword = '')
    {
        $this->ensureSchemaReady();
        $sql = 'SELECT f.*, i.id AS repo_item_id, i.visibility AS repo_visibility, i.note AS repo_note, i.sort_order AS repo_sort_order
                FROM ' . Database::table('files') . ' f
                LEFT JOIN ' . Database::table('file_repository_items') . ' i ON i.file_id = f.id AND i.repository_id = ?
                WHERE f.user_id = ?';
        $params = [$repo['id'], $repo['user_id']];
        if ($keyword !== '') {
            $sql .= ' AND (f.original_name LIKE ? OR f.file_name LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        $sql .= ' ORDER BY i.id IS NULL ASC, i.sort_order ASC, f.id DESC LIMIT 300';
        return Database::fetchAll($sql, $params);
    }

    public function publicFiles($repo, $keyword = '')
    {
        $this->ensureSchemaReady();
        $sql = 'SELECT f.*, i.note AS repo_note, i.sort_order AS repo_sort_order
                FROM ' . Database::table('file_repository_items') . ' i
                INNER JOIN ' . Database::table('files') . ' f ON f.id = i.file_id
                WHERE i.repository_id = ? AND i.visibility = ?';
        $params = [$repo['id'], 'public'];
        if ($keyword !== '') {
            $sql .= ' AND (f.original_name LIKE ? OR f.file_name LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        $sql .= ' ORDER BY i.sort_order ASC, f.id DESC LIMIT 300';
        return Database::fetchAll($sql, $params);
    }

    public function publicFile($repo, $fileId)
    {
        return Database::fetch('SELECT f.*, i.visibility FROM ' . Database::table('file_repository_items') . ' i INNER JOIN ' . Database::table('files') . ' f ON f.id = i.file_id WHERE i.repository_id = ? AND i.file_id = ? AND i.visibility = ? LIMIT 1', [$repo['id'], $fileId, 'public']);
    }

    public function stats($repo)
    {
        $this->ensureSchemaReady();
        $items = Database::fetch("SELECT COUNT(*) AS total, SUM(CASE WHEN visibility = 'public' THEN 1 ELSE 0 END) AS public_count, SUM(CASE WHEN visibility = 'private' THEN 1 ELSE 0 END) AS private_count FROM " . Database::table('file_repository_items') . ' WHERE repository_id = ?', [$repo['id']]);
        $logs = Database::fetch("SELECT COUNT(*) AS total, SUM(CASE WHEN action = 'view' THEN 1 ELSE 0 END) AS views, SUM(CASE WHEN action = 'download' THEN 1 ELSE 0 END) AS downloads, SUM(CASE WHEN action = 'view' AND DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) AS today_views, SUM(CASE WHEN action = 'download' AND DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) AS today_downloads FROM " . Database::table('file_repository_logs') . ' WHERE repository_id = ?', [$repo['id']]);
        return [
            'items' => (int) $items['total'],
            'public_items' => (int) $items['public_count'],
            'private_items' => (int) $items['private_count'],
            'logs' => (int) $logs['total'],
            'views' => (int) $logs['views'],
            'downloads' => (int) $logs['downloads'],
            'today_views' => (int) $logs['today_views'],
            'today_downloads' => (int) $logs['today_downloads'],
        ];
    }

    public function publishChecklist($repo, array $stats = null)
    {
        $stats = $stats ?: $this->stats($repo);
        $checks = [
            [
                'label' => '仓库已启用',
                'ok' => !empty($repo['status']),
                'detail' => !empty($repo['status']) ? '用户侧开关已打开' : '当前处于用户关闭状态',
            ],
            [
                'label' => '平台未下架',
                'ok' => !empty($repo['admin_status']),
                'detail' => !empty($repo['admin_status']) ? '平台审核状态正常' : ('下架原因：' . (isset($repo['admin_remark']) ? $repo['admin_remark'] : '')),
            ],
            [
                'label' => '有公开文件',
                'ok' => (int) $stats['public_items'] > 0,
                'detail' => (int) $stats['public_items'] > 0 ? $stats['public_items'] . ' 个文件可对外展示' : '请到文件管理页加入公开文件',
            ],
            [
                'label' => '访问方式可用',
                'ok' => $repo['access_type'] !== 'private' && ($repo['access_type'] !== 'password' || !empty($repo['password_hash'])),
                'detail' => $repo['access_type'] === 'private' ? '私密模式不会对外开放' : ($repo['access_type'] === 'password' ? '密码访问已配置' : '公开访问'),
            ],
            [
                'label' => '链接未过期',
                'ok' => empty($repo['expire_at']) || strtotime($repo['expire_at']) >= time(),
                'detail' => empty($repo['expire_at']) ? '长期有效' : ('到期：' . $repo['expire_at']),
            ],
        ];
        $ready = true;
        foreach ($checks as $check) {
            if (empty($check['ok'])) {
                $ready = false;
                break;
            }
        }
        return ['ready' => $ready, 'items' => $checks];
    }

    public function logs($repo, $limit = 80, array $filters = [])
    {
        $sql = 'SELECT l.*, f.original_name FROM ' . Database::table('file_repository_logs') . ' l LEFT JOIN ' . Database::table('files') . ' f ON l.file_id = f.id WHERE l.repository_id = ?';
        $params = [$repo['id']];
        $action = trim((string) $this->input($filters, 'action', ''));
        if ($action !== '' && in_array($action, ['view', 'download', 'auth_success', 'auth_fail', 'blocked', 'expired'], true)) {
            $sql .= ' AND l.action = ?';
            $params[] = $action;
        }
        $keyword = trim((string) $this->input($filters, 'keyword', ''));
        if ($keyword !== '') {
            $sql .= ' AND (f.original_name LIKE ? OR l.ip LIKE ? OR l.referer LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        $dateFrom = $this->normalizeDate($this->input($filters, 'date_from', ''));
        if ($dateFrom) {
            $sql .= ' AND l.created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }
        $dateTo = $this->normalizeDate($this->input($filters, 'date_to', ''));
        if ($dateTo) {
            $sql .= ' AND l.created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }
        $limit = min(5000, max(1, (int) $limit));
        return Database::fetchAll($sql . ' ORDER BY l.id DESC' . Database::limitClause($limit, 1, 5000), $params);
    }

    public function clearLogs($repo)
    {
        $this->ensureSchemaReady();
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_repository_logs') . ' WHERE repository_id = ?', [(int) $repo['id']]);
        $count = $row ? (int) $row['c'] : 0;
        Database::execute('DELETE FROM ' . Database::table('file_repository_logs') . ' WHERE repository_id = ?', [(int) $repo['id']]);
        return $count;
    }

    public function log($repo, $action, $fileId = null)
    {
        $allowed = ['view', 'download', 'auth_success', 'auth_fail', 'blocked', 'expired'];
        if (!in_array($action, $allowed, true)) {
            $action = 'view';
        }
        Database::execute(
            'INSERT INTO ' . Database::table('file_repository_logs') . ' (repository_id, user_id, file_id, action, ip, user_agent, referer, created_at) VALUES (?,?,?,?,?,?,?,?)',
            [
                $repo['id'],
                $repo['user_id'],
                $fileId,
                $action,
                Auth::ip(),
                substr(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 0, 255),
                substr(isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '', 0, 500),
                now(),
            ]
        );
    }

    public function dailyIpCount($repo, $action)
    {
        $row = Database::fetch(
            'SELECT COUNT(*) AS c FROM ' . Database::table('file_repository_logs') . ' WHERE repository_id = ? AND action = ? AND ip = ? AND DATE(created_at) = CURDATE()',
            [$repo['id'], $action, Auth::ip()]
        );
        return $row ? (int) $row['c'] : 0;
    }

    public function incrementView($repo)
    {
        Database::execute('UPDATE ' . Database::table('file_repositories') . ' SET view_count = view_count + 1, updated_at = ? WHERE id = ?', [now(), $repo['id']]);
    }

    public function incrementDownload($repo, $fileId)
    {
        Database::execute('UPDATE ' . Database::table('file_repositories') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $repo['id']]);
        Database::execute('UPDATE ' . Database::table('files') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $fileId]);
    }

    public function adminRepositories(array $filters = [])
    {
        $this->ensureSchemaReady();
        $sql = 'SELECT r.*, u.username, u.nickname,
                    (SELECT COUNT(*) FROM ' . Database::table('file_repository_items') . ' i WHERE i.repository_id = r.id) AS item_count,
                    (SELECT COUNT(*) FROM ' . Database::table('file_repository_items') . " i WHERE i.repository_id = r.id AND i.visibility = 'public') AS public_item_count,
                    (SELECT COUNT(*) FROM " . Database::table('file_repository_logs') . ' l WHERE l.repository_id = r.id) AS log_count,
                    (SELECT MAX(created_at) FROM ' . Database::table('file_repository_logs') . ' l WHERE l.repository_id = r.id) AS latest_log_at
                FROM ' . Database::table('file_repositories') . ' r
                LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id
                WHERE 1 = 1';
        $params = [];
        $keyword = trim((string) $this->input($filters, 'keyword', ''));
        if ($keyword !== '') {
            $sql .= ' AND (r.title LIKE ? OR r.slug LIKE ? OR r.tags LIKE ? OR u.username LIKE ? OR u.nickname LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        $status = trim((string) $this->input($filters, 'status', ''));
        if ($status === 'enabled') {
            $sql .= ' AND r.status = 1 AND r.admin_status = 1';
        } elseif ($status === 'user_disabled') {
            $sql .= ' AND r.status = 0';
        } elseif ($status === 'admin_disabled') {
            $sql .= ' AND r.admin_status = 0';
        } elseif ($status === 'expired') {
            $sql .= ' AND r.expire_at IS NOT NULL AND r.expire_at < NOW()';
        }
        $accessType = trim((string) $this->input($filters, 'access_type', ''));
        if (in_array($accessType, ['public', 'password', 'private'], true)) {
            $sql .= ' AND r.access_type = ?';
            $params[] = $accessType;
        }
        return Database::fetchAll($sql . ' ORDER BY r.id DESC LIMIT 300', $params);
    }

    public function adminRepository($id)
    {
        $this->ensureSchemaReady();
        return Database::fetch(
            'SELECT r.*, u.username, u.nickname, u.email,
                (SELECT COUNT(*) FROM ' . Database::table('file_repository_items') . ' i WHERE i.repository_id = r.id) AS item_count,
                (SELECT COUNT(*) FROM ' . Database::table('file_repository_items') . " i WHERE i.repository_id = r.id AND i.visibility = 'public') AS public_item_count,
                (SELECT COUNT(*) FROM " . Database::table('file_repository_logs') . ' l WHERE l.repository_id = r.id) AS log_count,
                (SELECT MAX(created_at) FROM ' . Database::table('file_repository_logs') . ' l WHERE l.repository_id = r.id) AS latest_log_at
             FROM ' . Database::table('file_repositories') . ' r
             LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id
             WHERE r.id = ? LIMIT 1',
            [(int) $id]
        );
    }

    public function adminRepositoryFiles($repo, $limit = 120)
    {
        $this->ensureSchemaReady();
        $limit = min(500, max(1, (int) $limit));
        return Database::fetchAll(
            'SELECT i.*, f.original_name, f.file_name, f.file_type, f.file_size, f.file_url, f.created_at AS file_created_at, f.updated_at AS file_updated_at
             FROM ' . Database::table('file_repository_items') . ' i
             LEFT JOIN ' . Database::table('files') . ' f ON f.id = i.file_id
             WHERE i.repository_id = ?
             ORDER BY i.visibility ASC, i.sort_order ASC, i.id DESC
             ' . Database::limitClause($limit, 1, 500),
            [(int) $repo['id']]
        );
    }

    public function adminStats()
    {
        $this->ensureSchemaReady();
        return [
            'total' => (int) Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_repositories'))['c'],
            'enabled' => (int) Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_repositories') . ' WHERE status = 1 AND admin_status = 1')['c'],
            'disabled' => (int) Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_repositories') . ' WHERE status = 0 OR admin_status = 0')['c'],
            'today_views' => (int) Database::fetch("SELECT COUNT(*) AS c FROM " . Database::table('file_repository_logs') . " WHERE action = 'view' AND DATE(created_at) = CURDATE()")['c'],
            'today_downloads' => (int) Database::fetch("SELECT COUNT(*) AS c FROM " . Database::table('file_repository_logs') . " WHERE action = 'download' AND DATE(created_at) = CURDATE()")['c'],
            'blocked_today' => (int) Database::fetch("SELECT COUNT(*) AS c FROM " . Database::table('file_repository_logs') . " WHERE action IN ('blocked','auth_fail','expired') AND DATE(created_at) = CURDATE()")['c'],
        ];
    }

    public function updateAdminStatus($id, $enabled, $remark = '')
    {
        $this->ensureSchemaReady();
        $repo = Database::fetch('SELECT id FROM ' . Database::table('file_repositories') . ' WHERE id = ? LIMIT 1', [(int) $id]);
        if (!$repo) {
            throw new \RuntimeException('分享仓库不存在。');
        }
        Database::execute(
            'UPDATE ' . Database::table('file_repositories') . ' SET admin_status = ?, admin_remark = ?, updated_at = ? WHERE id = ?',
            [$enabled ? 1 : 0, text_limit(trim((string) $remark), 255), now(), (int) $id]
        );
    }

    public function deleteRepository($repo)
    {
        $this->ensureSchemaReady();
        $id = (int) $repo['id'];
        Database::execute('DELETE FROM ' . Database::table('file_repository_logs') . ' WHERE repository_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('file_repository_items') . ' WHERE repository_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('file_repositories') . ' WHERE id = ?', [$id]);
        return true;
    }

    public function adminDeleteRepository($id)
    {
        $this->ensureSchemaReady();
        $repo = Database::fetch('SELECT * FROM ' . Database::table('file_repositories') . ' WHERE id = ? LIMIT 1', [(int) $id]);
        if (!$repo) {
            return false;
        }
        return $this->deleteRepository($repo);
    }

    public function adminClearLogs($id)
    {
        $repo = $this->adminRepository((int) $id);
        if (!$repo) {
            throw new \RuntimeException('分享仓库不存在。');
        }
        return $this->clearLogs($repo);
    }

    public function slugify($value)
    {
        $value = strtolower(trim((string) $value));
        $value = preg_replace('/[^a-z0-9_-]+/', '-', $value);
        $value = trim($value, '-_');
        return substr($value, 0, 80);
    }

    protected function ensureSchemaReady()
    {
        try {
            if (DatabaseUpgradeService::ensureRepositorySchema()) {
                return true;
            }
        } catch (\Throwable $e) {
            // Let callers surface one clear maintenance message instead of a raw SQL error.
        }
        throw new \RuntimeException('分享仓库数据结构未准备完成，请进入后台「数据库巡检」执行一键修复。');
    }

    protected function uniqueSlug($base)
    {
        $base = $base ?: 'repo';
        if ($this->reservedSlug($base)) {
            $base = 'repo-' . substr($base, 0, 64);
        }
        $slug = $base;
        $i = 1;
        while ($this->slugExists($slug, 0)) {
            $slug = substr($base, 0, 70) . '-' . $i;
            $i++;
        }
        return $slug;
    }

    protected function slugExists($slug, $ignoreId)
    {
        $row = Database::fetch('SELECT id FROM ' . Database::table('file_repositories') . ' WHERE slug = ? AND id <> ? LIMIT 1', [$slug, $ignoreId]);
        return (bool) $row;
    }

    protected function normalizeDateTime($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace('T', ' ', $value);
        if (strlen($value) === 16) {
            $value .= ':00';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value) || strtotime($value) === false) {
            throw new \RuntimeException('到期时间格式不正确。');
        }
        return $value;
    }

    protected function normalizeDate($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        return substr($value, 0, 10);
    }

    protected function cleanUrl($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $value = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', '', $value);
        if (strpos($value, '//') === 0) {
            return '';
        }
        if (preg_match('#^https?://#i', $value) || strpos($value, '/') === 0) {
            return $value;
        }
        return '';
    }

    protected function normalizeTags($value)
    {
        $parts = preg_split('/[,\x{ff0c}\s]+/u', trim((string) $value));
        $tags = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            $tags[$part] = text_limit($part, 24);
            if (count($tags) >= 12) {
                break;
            }
        }
        return implode(',', array_values($tags));
    }

    protected function normalizeIds(array $ids)
    {
        $result = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $result[$id] = $id;
            }
        }
        return array_values($result);
    }

    protected function boundedInt($value, $min, $max)
    {
        return max((int) $min, min((int) $max, (int) $value));
    }

    protected function reservedSlug($slug)
    {
        $reserved = [
            'admin', 'api', 'app', 'assets', 'auth', 'dashboard', 'download', 'files',
            'install', 'login', 'logout', 'monitor', 'netdisk', 'profile', 'register',
            'repository', 'r', 'share', 'storage', 'system', 'theme', 'user',
        ];
        return in_array(strtolower((string) $slug), $reserved, true);
    }

    protected function input(array $input, $key, $default = null)
    {
        return array_key_exists($key, $input) ? $input[$key] : $default;
    }
}
