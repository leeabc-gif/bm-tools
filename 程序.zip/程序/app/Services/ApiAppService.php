<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;

class ApiAppService
{
    const DEFAULT_SCOPES = ['upload', 'files', 'delete', 'quota'];

    public function scopeLabels()
    {
        return [
            'upload' => '上传文件',
            'files' => '读取列表',
            'delete' => '删除文件',
            'quota' => '读取容量',
        ];
    }

    public function appsForUser($userId)
    {
        return Database::fetchAll(
            'SELECT id, user_id, name, scopes, allowed_ips, status, last_used_at, created_at, updated_at
             FROM ' . Database::table('api_apps') . '
             WHERE user_id = ?
             ORDER BY status DESC, id DESC',
            [(int) $userId]
        );
    }

    public function appsWithStatsForUser($userId)
    {
        $apps = $this->appsForUser($userId);
        if (!$apps) {
            return [];
        }

        $stats = $this->statsForUserApps($userId);
        foreach ($apps as &$app) {
            $id = (int) $app['id'];
            $app['stats'] = isset($stats[$id]) ? $stats[$id] : $this->emptyStats();
            $app['health'] = $this->healthFromStats($app);
        }
        unset($app);
        return $apps;
    }

    public function statsForUserApps($userId)
    {
        $userId = (int) $userId;
        if (!$this->apiLogAppColumnReady()) {
            return [];
        }

        $rows = Database::fetchAll(
            'SELECT app_id,
                    COUNT(*) AS total,
                    SUM(CASE WHEN is_success = 1 THEN 1 ELSE 0 END) AS success,
                    SUM(CASE WHEN is_success = 0 THEN 1 ELSE 0 END) AS failed,
                    SUM(CASE WHEN created_at >= CURDATE() THEN 1 ELSE 0 END) AS today,
                    SUM(CASE WHEN is_success = 0 AND created_at >= CURDATE() THEN 1 ELSE 0 END) AS today_failed,
                    MAX(created_at) AS last_called_at
             FROM ' . Database::table('api_logs') . '
             WHERE user_id = ? AND app_id IS NOT NULL
             GROUP BY app_id',
            [$userId]
        );

        $stats = [];
        foreach ($rows as $row) {
            $id = (int) $row['app_id'];
            $total = (int) $row['total'];
            $success = (int) $row['success'];
            $stats[$id] = [
                'total' => $total,
                'success' => $success,
                'failed' => (int) $row['failed'],
                'today' => (int) $row['today'],
                'today_failed' => (int) $row['today_failed'],
                'success_rate' => $total > 0 ? round(($success / $total) * 100, 1) : 0,
                'last_called_at' => isset($row['last_called_at']) ? $row['last_called_at'] : null,
                'last_error' => null,
            ];
        }

        $errorRows = Database::fetchAll(
            'SELECT l.app_id, l.endpoint, l.status_code, l.message, l.created_at
             FROM ' . Database::table('api_logs') . ' l
             INNER JOIN (
                SELECT app_id, MAX(id) AS max_id
                FROM ' . Database::table('api_logs') . '
                WHERE user_id = ? AND app_id IS NOT NULL AND is_success = 0
                GROUP BY app_id
             ) x ON l.id = x.max_id
             ORDER BY l.id DESC',
            [$userId]
        );
        foreach ($errorRows as $row) {
            $id = (int) $row['app_id'];
            if (!isset($stats[$id])) {
                $stats[$id] = $this->emptyStats();
            }
            $stats[$id]['last_error'] = [
                'endpoint' => isset($row['endpoint']) ? $row['endpoint'] : '',
                'status_code' => isset($row['status_code']) ? (int) $row['status_code'] : 0,
                'message' => isset($row['message']) ? $row['message'] : '',
                'created_at' => isset($row['created_at']) ? $row['created_at'] : '',
            ];
        }

        return $stats;
    }

    public function usageSummaryForUser($userId)
    {
        $userId = (int) $userId;
        $summary = [
            'total' => 0,
            'success' => 0,
            'failed' => 0,
            'today' => 0,
            'today_failed' => 0,
            'success_rate' => 0,
            'app_total' => 0,
            'active_apps' => 0,
            'last_error' => null,
        ];

        $appRows = Database::fetch(
            'SELECT COUNT(*) AS total, SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS active
             FROM ' . Database::table('api_apps') . '
             WHERE user_id = ?',
            [$userId]
        );
        if ($appRows) {
            $summary['app_total'] = (int) $appRows['total'];
            $summary['active_apps'] = (int) $appRows['active'];
        }

        $row = Database::fetch(
            'SELECT COUNT(*) AS total,
                    SUM(CASE WHEN is_success = 1 THEN 1 ELSE 0 END) AS success,
                    SUM(CASE WHEN is_success = 0 THEN 1 ELSE 0 END) AS failed,
                    SUM(CASE WHEN created_at >= CURDATE() THEN 1 ELSE 0 END) AS today,
                    SUM(CASE WHEN is_success = 0 AND created_at >= CURDATE() THEN 1 ELSE 0 END) AS today_failed
             FROM ' . Database::table('api_logs') . '
             WHERE user_id = ?',
            [$userId]
        );
        if ($row) {
            $summary['total'] = (int) $row['total'];
            $summary['success'] = (int) $row['success'];
            $summary['failed'] = (int) $row['failed'];
            $summary['today'] = (int) $row['today'];
            $summary['today_failed'] = (int) $row['today_failed'];
            $summary['success_rate'] = $summary['total'] > 0 ? round(($summary['success'] / $summary['total']) * 100, 1) : 0;
        }

        $lastError = Database::fetch(
            'SELECT endpoint, status_code, message, created_at
             FROM ' . Database::table('api_logs') . '
             WHERE user_id = ? AND is_success = 0
             ORDER BY id DESC LIMIT 1',
            [$userId]
        );
        if ($lastError) {
            $summary['last_error'] = $lastError;
        }

        return $summary;
    }

    public function logsForUser($userId, $limit = 100)
    {
        $userId = (int) $userId;
        $limitClause = Database::limitClause($limit, 1, 300, 100);
        if ($this->apiLogAppColumnReady() && $this->apiAppsTableReady()) {
            return Database::fetchAll(
                'SELECT l.*, a.name AS api_app_name
                 FROM ' . Database::table('api_logs') . ' l
                 LEFT JOIN ' . Database::table('api_apps') . ' a ON l.app_id = a.id
                 WHERE l.user_id = ?
                 ORDER BY l.id DESC' . $limitClause,
                [$userId]
            );
        }
        return Database::fetchAll(
            'SELECT *, "" AS api_app_name
             FROM ' . Database::table('api_logs') . '
             WHERE user_id = ?
             ORDER BY id DESC' . $limitClause,
            [$userId]
        );
    }

    public function appLabelFromLog(array $log)
    {
        if (!empty($log['api_app_name'])) {
            return $log['api_app_name'];
        }
        if (!empty($log['app_id'])) {
            return '应用 #' . (int) $log['app_id'];
        }
        return '总 Token';
    }

    public function create($userId, $name, $scopes, $allowedIps)
    {
        $userId = (int) $userId;
        $name = $this->normalizeName($name);
        $scopeText = implode(',', $this->normalizeScopes($scopes));
        $allowedIps = $this->normalizeAllowedIps($allowedIps);
        if ($allowedIps === false) {
            throw new \InvalidArgumentException('IP 白名单格式不正确，每行填写一个 IPv4 或 IPv6，留空表示不限制。');
        }

        $count = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('api_apps') . ' WHERE user_id = ?', [$userId]);
        if ($count && (int) $count['c'] >= 20) {
            throw new \RuntimeException('每个账号最多创建 20 个应用 Token，请先停用或删除不再使用的应用。');
        }

        $token = $this->generateToken();
        Database::execute(
            'INSERT INTO ' . Database::table('api_apps') . '
             (user_id, name, token_hash, token_cipher, scopes, allowed_ips, status, last_used_at, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?)',
            [
                $userId,
                $name,
                hash('sha256', $token),
                CryptoService::encrypt($token),
                $scopeText,
                $allowedIps,
                1,
                null,
                now(),
                now(),
            ]
        );

        $id = (int) Database::lastInsertId();
        return [
            'app' => $this->findOwned($userId, $id),
            'token' => $token,
        ];
    }

    public function update($userId, $id, $name, $scopes, $allowedIps, $status)
    {
        $app = $this->findOwned($userId, $id);
        if (!$app) {
            throw new \RuntimeException('应用不存在或无权操作。');
        }

        $allowedIps = $this->normalizeAllowedIps($allowedIps);
        if ($allowedIps === false) {
            throw new \InvalidArgumentException('IP 白名单格式不正确，每行填写一个 IPv4 或 IPv6，留空表示不限制。');
        }

        Database::execute(
            'UPDATE ' . Database::table('api_apps') . '
             SET name = ?, scopes = ?, allowed_ips = ?, status = ?, updated_at = ?
             WHERE id = ? AND user_id = ?',
            [
                $this->normalizeName($name),
                implode(',', $this->normalizeScopes($scopes)),
                $allowedIps,
                (int) $status === 1 ? 1 : 0,
                now(),
                (int) $id,
                (int) $userId,
            ]
        );

        return $this->findOwned($userId, $id);
    }

    public function rotate($userId, $id)
    {
        $app = $this->findOwned($userId, $id);
        if (!$app) {
            throw new \RuntimeException('应用不存在或无权操作。');
        }

        $token = $this->generateToken();
        Database::execute(
            'UPDATE ' . Database::table('api_apps') . '
             SET token_hash = ?, token_cipher = ?, updated_at = ?
             WHERE id = ? AND user_id = ?',
            [hash('sha256', $token), CryptoService::encrypt($token), now(), (int) $id, (int) $userId]
        );

        $app = $this->findOwned($userId, $id);
        return [
            'app' => $app,
            'token' => $token,
        ];
    }

    public function delete($userId, $id)
    {
        $app = $this->findOwned($userId, $id);
        if (!$app) {
            throw new \RuntimeException('应用不存在或无权操作。');
        }

        return Database::execute(
            'DELETE FROM ' . Database::table('api_apps') . ' WHERE id = ? AND user_id = ?',
            [(int) $id, (int) $userId]
        );
    }

    public function findOwned($userId, $id)
    {
        return Database::fetch(
            'SELECT id, user_id, name, scopes, allowed_ips, status, last_used_at, created_at, updated_at
             FROM ' . Database::table('api_apps') . '
             WHERE id = ? AND user_id = ?
             LIMIT 1',
            [(int) $id, (int) $userId]
        );
    }

    public function findByToken($token)
    {
        $token = trim((string) $token);
        if ($token === '') {
            return null;
        }

        $app = Database::fetch(
            'SELECT * FROM ' . Database::table('api_apps') . '
             WHERE token_hash = ? AND status = 1
             LIMIT 1',
            [hash('sha256', $token)]
        );
        if (!$app) {
            return null;
        }

        $user = Database::fetch(
            'SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1',
            [(int) $app['user_id']]
        );
        if (!$user) {
            return null;
        }

        return ['app' => $app, 'user' => $user];
    }

    public function touchLastUsed($id)
    {
        try {
            Database::execute(
                'UPDATE ' . Database::table('api_apps') . ' SET last_used_at = ?, updated_at = ? WHERE id = ?',
                [now(), now(), (int) $id]
            );
        } catch (\Throwable $e) {
            // Last-used timestamps are observability only; API calls should not fail because of them.
        }
    }

    public function scopeAllowed(array $app, $scope)
    {
        $scope = (string) $scope;
        if ($scope === '') {
            return true;
        }
        return in_array($scope, $this->normalizeScopes(isset($app['scopes']) ? $app['scopes'] : ''), true);
    }

    public function ipAllowed(array $app, $ip = null)
    {
        $allowed = trim((string) (isset($app['allowed_ips']) ? $app['allowed_ips'] : ''));
        if ($allowed === '') {
            return true;
        }
        $ip = $ip === null ? Auth::ip() : (string) $ip;
        foreach (preg_split('/[\s,;]+/', $allowed) as $item) {
            if (trim($item) === $ip) {
                return true;
            }
        }
        return false;
    }

    public function normalizeScopes($scopes)
    {
        if (is_string($scopes)) {
            $scopes = preg_split('/[\s,;]+/', $scopes);
        }
        if (!is_array($scopes)) {
            $scopes = [];
        }

        $valid = array_fill_keys(self::DEFAULT_SCOPES, true);
        $normalized = [];
        foreach ($scopes as $scope) {
            $scope = trim((string) $scope);
            if ($scope !== '' && isset($valid[$scope])) {
                $normalized[$scope] = true;
            }
        }
        if (!$normalized) {
            $normalized = array_fill_keys(self::DEFAULT_SCOPES, true);
        }
        return array_keys($normalized);
    }

    public function scopeText(array $app)
    {
        $labels = $this->scopeLabels();
        $items = [];
        foreach ($this->normalizeScopes(isset($app['scopes']) ? $app['scopes'] : '') as $scope) {
            $items[] = isset($labels[$scope]) ? $labels[$scope] : $scope;
        }
        return implode(' / ', $items);
    }

    public function normalizeAllowedIps($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $parts = preg_split('/[\s,;]+/', $value);
        $ips = [];
        foreach ($parts as $ip) {
            $ip = trim($ip);
            if ($ip === '') {
                continue;
            }
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                return false;
            }
            $ips[$ip] = true;
        }
        return implode("\n", array_keys($ips));
    }

    protected function normalizeName($name)
    {
        $name = trim((string) $name);
        $name = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', ' ', $name);
        $name = trim(preg_replace('/\s+/', ' ', $name));
        if ($name === '') {
            throw new \InvalidArgumentException('请填写应用名称。');
        }
        return text_limit($name, 80);
    }

    protected function emptyStats()
    {
        return [
            'total' => 0,
            'success' => 0,
            'failed' => 0,
            'today' => 0,
            'today_failed' => 0,
            'success_rate' => 0,
            'last_called_at' => null,
            'last_error' => null,
        ];
    }

    protected function healthFromStats(array $app)
    {
        $stats = isset($app['stats']) && is_array($app['stats']) ? $app['stats'] : $this->emptyStats();
        if (empty($app['status'])) {
            return ['tone' => 'muted', 'label' => '已停用', 'hint' => '该应用不会接受新的 API 请求。'];
        }
        if ((int) $stats['total'] === 0) {
            return ['tone' => 'idle', 'label' => '未调用', 'hint' => '创建后尚未收到请求，可先用 curl 或客户端测试。'];
        }
        if ((int) $stats['today_failed'] > 0) {
            return ['tone' => 'bad', 'label' => '今日有失败', 'hint' => '建议查看最近失败原因、IP 白名单和权限范围。'];
        }
        if ((int) $stats['failed'] > 0 && (float) $stats['success_rate'] < 95) {
            return ['tone' => 'warn', 'label' => '成功率偏低', 'hint' => '失败次数较多，建议检查客户端配置。'];
        }
        return ['tone' => 'ok', 'label' => '运行正常', 'hint' => '最近调用成功率稳定。'];
    }

    protected function apiLogAppColumnReady()
    {
        try {
            return Database::tableExists(Database::table('api_logs')) && Database::columnExists(Database::table('api_logs'), 'app_id');
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function apiAppsTableReady()
    {
        try {
            return Database::tableExists(Database::table('api_apps'));
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function generateToken()
    {
        return 'bm_' . bin2hex(random_bytes(24));
    }
}
