<?php
namespace App\Services;

use App\Core\Database;

class PermissionService
{
    public function assertFeature(array $user, $feature)
    {
        if (!$this->featureAllowed($user, $feature)) {
            throw new \RuntimeException($this->message($feature));
        }
    }

    public function featureAllowed(array $user, $feature, array $package = null)
    {
        $permissionSchemaReady = $this->permissionSchemaReady();
        $feature = $this->feature($feature);
        if ($feature === 'image' && (string) setting('user_image_upload_enabled', '1') !== '1') {
            return false;
        }
        if ($feature === 'netdisk' && (string) setting('user_netdisk_enabled', '1') !== '1') {
            return false;
        }
        if (isset($user['role']) && $user['role'] === 'admin') {
            return true;
        }

        if (in_array($feature, ['image', 'netdisk'], true)) {
            $overrideField = $feature === 'image' ? 'allow_image_override' : 'allow_netdisk_override';
            if ($permissionSchemaReady && !array_key_exists($overrideField, $user) && !empty($user['id'])) {
                $fresh = Database::fetch('SELECT allow_image_override, allow_netdisk_override FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [$user['id']]);
                if ($fresh) {
                    $user = array_merge($user, $fresh);
                }
            }
            if ($permissionSchemaReady && array_key_exists($overrideField, $user) && (int) $user[$overrideField] !== -1) {
                return (int) $user[$overrideField] === 1;
            }
        }

        if ($package === null) {
            $selectFields = [
                'image' => 'allow_image, allow_netdisk',
                'netdisk' => 'allow_image, allow_netdisk',
                'api' => 'allow_api',
                'monitor' => 'allow_monitor',
            ];
            $fields = isset($selectFields[$feature]) ? $selectFields[$feature] : 'allow_image, allow_netdisk';
            $package = Database::fetch('SELECT ' . $fields . ' FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        }
        if (!$package) {
            return false;
        }

        $fields = [
            'image' => 'allow_image',
            'netdisk' => 'allow_netdisk',
            'api' => 'allow_api',
            'monitor' => 'allow_monitor',
        ];
        $field = isset($fields[$feature]) ? $fields[$feature] : 'allow_image';
        return !empty($package[$field]);
    }

    public function message($feature)
    {
        $feature = $this->feature($feature);
        if ($feature === 'image') {
            return '当前账号没有图床上传权限，请联系管理员或升级套餐。';
        }
        if ($feature === 'monitor') {
            return '当前账号没有服务器运维权限，请联系管理员或升级套餐。';
        }
        if ($feature === 'api') {
            return '当前账号没有 API 接入权限，请联系管理员或升级套餐。';
        }
        return '当前账号没有个人网盘权限，请联系管理员或升级套餐。';
    }

    protected function feature($feature)
    {
        if ($feature === 'netdisk' || $feature === 'file') {
            return 'netdisk';
        }
        if ($feature === 'api') {
            return 'api';
        }
        if ($feature === 'monitor' || $feature === 'server' || $feature === 'ssh') {
            return 'monitor';
        }
        return 'image';
    }

    protected function permissionSchemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureUserPermissionSchema();
        } catch (\Throwable $e) {
            return false;
        }
    }
}
