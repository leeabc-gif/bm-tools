<?php
namespace App\Services;

use App\Core\Config;

class CryptoService
{
    protected const PREFIX = 'enc:gcm:v1:';
    protected const LEGACY_PREFIX = 'enc:v1:';

    public static function encrypt($plain)
    {
        $plain = (string) $plain;
        if ($plain === '') {
            return '';
        }
        if (!function_exists('openssl_encrypt')) {
            throw new \RuntimeException('当前 PHP 环境缺少 openssl 扩展，无法加密敏感配置。请启用 openssl 后再保存密钥。');
        }
        $key = self::key();
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) {
            throw new \RuntimeException('敏感配置加密失败，请检查 openssl 扩展。');
        }
        return self::PREFIX . base64_encode($iv) . ':' . base64_encode($tag) . ':' . base64_encode($cipher);
    }

    public static function decrypt($payload)
    {
        $payload = (string) $payload;
        if ($payload === '') {
            return '';
        }
        if (strpos($payload, self::PREFIX) === 0) {
            $payload = substr($payload, strlen(self::PREFIX));
            $plain = self::decryptGcmPayload($payload);
            return $plain === null ? '' : $plain;
        }
        if (strpos($payload, self::LEGACY_PREFIX) === 0) {
            $payload = substr($payload, strlen(self::LEGACY_PREFIX));
            $plain = self::decryptLegacyPayload($payload);
            return $plain === null ? '' : $plain;
        }
        if (strpos($payload, ':') === false) {
            return $payload;
        }
        $plain = self::decryptLegacyPayload($payload);
        return $plain === null ? $payload : $plain;
    }

    public static function isEncrypted($payload)
    {
        $payload = (string) $payload;
        if ($payload === '') {
            return false;
        }
        if (strpos($payload, self::PREFIX) === 0) {
            return true;
        }
        if (strpos($payload, self::LEGACY_PREFIX) === 0) {
            return true;
        }
        if (strpos($payload, ':') === false) {
            return false;
        }
        return self::decryptLegacyPayload($payload) !== null;
    }

    protected static function decryptGcmPayload($payload)
    {
        if (!function_exists('openssl_decrypt')) {
            throw new \RuntimeException('当前 PHP 环境缺少 openssl 扩展，无法读取已加密的密钥配置。请启用 openssl，或重新保存未加密配置。');
        }
        $parts = explode(':', $payload, 3);
        if (count($parts) !== 3) {
            return null;
        }
        list($iv, $tag, $cipher) = $parts;
        $iv = base64_decode($iv, true);
        $tag = base64_decode($tag, true);
        $cipher = base64_decode($cipher, true);
        if ($iv === false || $tag === false || $cipher === false) {
            return null;
        }
        $plain = openssl_decrypt($cipher, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        return $plain === false ? null : $plain;
    }

    protected static function decryptLegacyPayload($payload)
    {
        if (!function_exists('openssl_decrypt')) {
            throw new \RuntimeException('当前 PHP 环境缺少 openssl 扩展，无法读取已加密的密钥配置。请启用 openssl，或重新保存未加密配置。');
        }
        $parts = explode(':', $payload, 2);
        if (count($parts) !== 2) {
            return null;
        }
        list($iv, $cipher) = $parts;
        $iv = base64_decode($iv, true);
        $cipher = base64_decode($cipher, true);
        if ($iv === false || $cipher === false) {
            return null;
        }
        $plain = openssl_decrypt($cipher, 'AES-256-CBC', self::key(), OPENSSL_RAW_DATA, $iv);
        return $plain === false ? null : $plain;
    }

    protected static function key()
    {
        $secret = (string) Config::get('app.security.secret_key', '');
        if ($secret === '' || $secret === 'bm-tools-change-this-secret-key') {
            $db = APP_ROOT . '/config/database.php';
            if (is_file($db)) {
                $secret = hash_file('sha256', $db);
            } else {
                $secret = hash('sha256', APP_ROOT);
            }
        }
        return hash('sha256', $secret, true);
    }
}
