<?php
namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Models\StorageDriver;
use App\Services\Storage\StorageManager;

class StorageMigrationService
{
    const MIGRATION_POLICY_ID = 0;

    public function plan(array $options = [])
    {
        $this->ensureSchema();
        $sourceStorageId = isset($options['source_storage_id']) ? max(0, (int) $options['source_storage_id']) : 0;
        $targetStorageId = isset($options['target_storage_id']) ? max(0, (int) $options['target_storage_id']) : 0;
        $fileScope = $this->fileScope(isset($options['file_scope']) ? $options['file_scope'] : '');

        $total = $this->countFiles($sourceStorageId, $fileScope);
        $alreadyTarget = $targetStorageId > 0 ? $this->countFiles($targetStorageId, $fileScope) : 0;
        $readyBackup = $targetStorageId > 0 ? $this->countReadyBackups($sourceStorageId, $targetStorageId, $fileScope) : 0;
        $localReadable = $this->countLocalReadableCandidates($sourceStorageId, $targetStorageId, $fileScope);

        return [
            'total' => $total,
            'already_target' => $alreadyTarget,
            'ready_backup' => $readyBackup,
            'local_readable' => $localReadable,
            'needs_upload_or_backup' => max(0, $total - $readyBackup),
        ];
    }

    public function migrate(array $options = [])
    {
        $this->ensureSchema();
        $sourceStorageId = isset($options['source_storage_id']) ? max(0, (int) $options['source_storage_id']) : 0;
        $targetStorageId = isset($options['target_storage_id']) ? max(0, (int) $options['target_storage_id']) : 0;
        $fileScope = $this->fileScope(isset($options['file_scope']) ? $options['file_scope'] : '');
        $limit = isset($options['limit']) ? (int) $options['limit'] : 20;
        $limit = max(1, min(100, $limit));
        $switchPrimary = !empty($options['switch_primary']);

        if ($targetStorageId <= 0) {
            throw new \RuntimeException('请选择迁移目标存储。');
        }
        $targetStorage = $this->enabledStorage($targetStorageId);
        if (!$targetStorage) {
            throw new \RuntimeException('目标存储不存在或已停用。');
        }

        $summary = [
            'scanned' => 0,
            'uploaded' => 0,
            'switched' => 0,
            'backup_ready' => 0,
            'skipped' => 0,
            'failed' => 0,
            'errors' => [],
        ];

        $rows = $this->candidateFiles($sourceStorageId, $targetStorageId, $fileScope, $limit);
        foreach ($rows as $file) {
            $summary['scanned']++;
            if ((int) $file['storage_id'] === $targetStorageId) {
                $summary['skipped']++;
                continue;
            }

            $backup = $this->successfulBackup((int) $file['id'], $targetStorageId);
            if ($backup) {
                $summary['backup_ready']++;
                if ($switchPrimary) {
                    $this->switchPrimary($file, $targetStorageId, $backup['object_key'], $backup['file_url']);
                    $summary['switched']++;
                }
                continue;
            }

            $source = $this->localSourcePath($file);
            if ($source === '') {
                $summary['skipped']++;
                $this->recordMigrationResult($file, $targetStorageId, isset($file['file_path']) ? $file['file_path'] : '', '', 'skipped', '源文件不在本地可读路径，无法直接迁移。可先通过多存储备份生成目标副本，再执行切换。');
                continue;
            }

            $objectKey = $this->objectKeyForMigration($file);
            $mime = !empty($file['mime_type']) ? (string) $file['mime_type'] : 'application/octet-stream';
            try {
                $this->recordMigrationResult($file, $targetStorageId, $objectKey, '', 'pending', '');
                $result = StorageManager::make($targetStorage)->upload($source, $objectKey, ['mime' => $mime]);
                $path = isset($result['path']) ? (string) $result['path'] : (string) $objectKey;
                $url = isset($result['url']) ? (string) $result['url'] : '';
                $this->recordMigrationResult($file, $targetStorageId, $path, $url, 'success', '');
                $summary['uploaded']++;
                if ($switchPrimary) {
                    $this->switchPrimary($file, $targetStorageId, $path, $url);
                    $summary['switched']++;
                }
            } catch (\Throwable $e) {
                $summary['failed']++;
                $message = $this->cleanError($e->getMessage());
                $this->recordMigrationResult($file, $targetStorageId, $objectKey, '', 'failed', $message);
                if (count($summary['errors']) < 6) {
                    $summary['errors'][] = 'File #' . (int) $file['id'] . ': ' . $message;
                }
                Logger::error('Storage migration failed: ' . $message, [
                    'file_id' => (int) $file['id'],
                    'target_storage_id' => $targetStorageId,
                ]);
            }
        }

        return $summary;
    }

    public function recentTasks($limit = 80)
    {
        $this->ensureSchema();
        $limit = max(1, min(200, (int) $limit));
        return Database::fetchAll(
            'SELECT b.*, f.original_name, f.file_type, f.file_size, f.file_url AS current_file_url, f.storage_id AS current_storage_id, s.name AS storage_name, s.type AS storage_type
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON b.storage_id = s.id
             WHERE b.policy_id = ?
             ORDER BY b.updated_at DESC, b.id DESC' . Database::limitClause($limit, 1, 200),
            [self::MIGRATION_POLICY_ID]
        );
    }

    protected function candidateFiles($sourceStorageId, $targetStorageId, $fileScope, $limit)
    {
        $where = ['f.storage_id <> ?'];
        $params = [(int) $targetStorageId];
        if ($sourceStorageId > 0) {
            $where[] = 'f.storage_id = ?';
            $params[] = (int) $sourceStorageId;
        }
        if ($fileScope !== '') {
            $where[] = 'f.file_type = ?';
            $params[] = $fileScope;
        }

        return Database::fetchAll(
            'SELECT f.*, s.type AS primary_storage_type, s.prefix AS primary_prefix
             FROM ' . Database::table('files') . ' f
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY f.id ASC' . Database::limitClause($limit, 1, 100),
            $params
        );
    }

    protected function countFiles($storageId, $fileScope)
    {
        $where = [];
        $params = [];
        if ($storageId > 0) {
            $where[] = 'storage_id = ?';
            $params[] = (int) $storageId;
        }
        if ($fileScope !== '') {
            $where[] = 'file_type = ?';
            $params[] = $fileScope;
        }
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ($where ? (' WHERE ' . implode(' AND ', $where)) : ''), $params);
        return $row ? (int) $row['c'] : 0;
    }

    protected function countReadyBackups($sourceStorageId, $targetStorageId, $fileScope)
    {
        $where = ["b.storage_id = ?", "b.status = 'success'"];
        $params = [(int) $targetStorageId];
        if ($sourceStorageId > 0) {
            $where[] = 'f.storage_id = ?';
            $params[] = (int) $sourceStorageId;
        }
        if ($fileScope !== '') {
            $where[] = 'f.file_type = ?';
            $params[] = $fileScope;
        }
        $row = Database::fetch(
            'SELECT COUNT(DISTINCT b.file_id) AS c
             FROM ' . Database::table('file_storage_backups') . ' b
             INNER JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             WHERE ' . implode(' AND ', $where),
            $params
        );
        return $row ? (int) $row['c'] : 0;
    }

    protected function countLocalReadableCandidates($sourceStorageId, $targetStorageId, $fileScope)
    {
        $where = ["s.type = 'local'"];
        $params = [];
        if ($targetStorageId > 0) {
            $where[] = 'f.storage_id <> ?';
            $params[] = (int) $targetStorageId;
        }
        if ($sourceStorageId > 0) {
            $where[] = 'f.storage_id = ?';
            $params[] = (int) $sourceStorageId;
        }
        if ($fileScope !== '') {
            $where[] = 'f.file_type = ?';
            $params[] = $fileScope;
        }
        $row = Database::fetch(
            'SELECT COUNT(*) AS c
             FROM ' . Database::table('files') . ' f
             INNER JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id
             WHERE ' . implode(' AND ', $where),
            $params
        );
        return $row ? (int) $row['c'] : 0;
    }

    protected function successfulBackup($fileId, $targetStorageId)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('file_storage_backups') . " WHERE file_id = ? AND storage_id = ? AND status = 'success' ORDER BY updated_at DESC, id DESC LIMIT 1",
            [(int) $fileId, (int) $targetStorageId]
        );
    }

    protected function recordMigrationResult(array $file, $targetStorageId, $objectKey, $url, $status, $message)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('file_storage_backups') . '
             (file_id, storage_id, policy_id, object_key, file_url, status, error_message, attempts, last_attempt_at, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE object_key = VALUES(object_key), file_url = VALUES(file_url), status = VALUES(status),
                error_message = VALUES(error_message), attempts = attempts + 1, last_attempt_at = VALUES(last_attempt_at), updated_at = VALUES(updated_at)',
            [
                (int) $file['id'],
                (int) $targetStorageId,
                self::MIGRATION_POLICY_ID,
                (string) $objectKey,
                (string) $url,
                (string) $status,
                (string) $message,
                1,
                now(),
                now(),
                now(),
            ]
        );
    }

    protected function switchPrimary(array $file, $targetStorageId, $objectKey, $url)
    {
        $thumbnail = (string) $url;
        if (isset($file['file_type']) && $file['file_type'] !== 'image') {
            $thumbnail = isset($file['thumbnail_url']) ? (string) $file['thumbnail_url'] : $thumbnail;
        }
        Database::execute(
            'UPDATE ' . Database::table('files') . ' SET storage_id = ?, file_path = ?, file_url = ?, thumbnail_url = ?, updated_at = ? WHERE id = ?',
            [(int) $targetStorageId, (string) $objectKey, (string) $url, $thumbnail, now(), (int) $file['id']]
        );
    }

    protected function localSourcePath(array $file)
    {
        if (empty($file['file_path']) || empty($file['primary_storage_type']) || $file['primary_storage_type'] !== 'local') {
            return '';
        }
        $root = realpath(APP_ROOT . '/public');
        if ($root === false) {
            return '';
        }
        $path = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($file['file_path'], '/'));
        $real = realpath($path);
        if ($real === false || strpos($real, $root) !== 0 || !is_file($real)) {
            return '';
        }
        return $real;
    }

    protected function objectKeyForMigration(array $file)
    {
        $path = ltrim(str_replace('\\', '/', isset($file['file_path']) ? (string) $file['file_path'] : ''), '/');
        if ($path === '') {
            $name = isset($file['file_name']) ? (string) $file['file_name'] : ('file-' . (int) $file['id']);
            return (isset($file['file_type']) && $file['file_type'] === 'image' ? 'image' : 'file') . '/' . date('Y/m/d') . '/' . basename($name);
        }
        if (isset($file['primary_storage_type']) && $file['primary_storage_type'] === 'local') {
            $prefix = $this->safeLocalPrefixForStorage($file);
            if ($prefix !== '' && strpos($path, $prefix . '/') === 0) {
                $stripped = substr($path, strlen($prefix) + 1);
                if ($stripped !== '') {
                    return $stripped;
                }
            }
        }
        return $path;
    }

    protected function safeLocalPrefixForStorage(array $storage)
    {
        $prefix = trim(isset($storage['primary_prefix']) && $storage['primary_prefix'] ? $storage['primary_prefix'] : 'uploads/files', '/');
        $prefix = str_replace('\\', '/', $prefix);
        $parts = [];
        foreach (explode('/', $prefix) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                continue;
            }
            $parts[] = preg_replace('/[^A-Za-z0-9_\-.]/', '-', $part);
        }
        if (!$parts || $parts[0] !== 'uploads') {
            array_unshift($parts, 'uploads');
        }
        return implode('/', $parts);
    }

    protected function enabledStorage($storageId)
    {
        return Database::fetch('SELECT * FROM ' . Database::table('storage_drivers') . ' WHERE id = ? AND is_enabled = 1 LIMIT 1', [(int) $storageId]);
    }

    protected function fileScope($value)
    {
        $value = (string) $value;
        return in_array($value, ['image', 'file'], true) ? $value : '';
    }

    protected function ensureSchema()
    {
        if (!DatabaseUpgradeService::ensureStorageBackupSchema()) {
            throw new \RuntimeException('存储迁移依赖多存储备份数据结构，请先进入数据库巡检执行一键修复。');
        }
    }

    protected function cleanError($message)
    {
        return text_limit(trim(strip_tags((string) $message)), 360, '...');
    }
}
