<?php
namespace App\Services;

use App\Core\Database;

class RateLimitService
{
    public function check($scope, $identity, $windowSeconds = 600)
    {
        if (!$this->schemaReady()) {
            return ['limited' => false, 'attempts' => 0, 'retry_after' => 0, 'message' => 'ok'];
        }
        $row = $this->row($scope, $identity);
        if (!$row) {
            return ['limited' => false, 'attempts' => 0, 'retry_after' => 0, 'message' => 'ok'];
        }

        $now = time();
        $lockedUntil = !empty($row['locked_until']) ? strtotime($row['locked_until']) : 0;
        if ($lockedUntil > $now) {
            return [
                'limited' => true,
                'attempts' => (int) $row['attempt_count'],
                'retry_after' => max(1, $lockedUntil - $now),
                'message' => '操作过于频繁，请稍后再试。',
            ];
        }

        $firstAt = !empty($row['first_attempt_at']) ? strtotime($row['first_attempt_at']) : 0;
        if ($firstAt > 0 && $firstAt < ($now - (int) $windowSeconds)) {
            $this->clear($scope, $identity);
            return ['limited' => false, 'attempts' => 0, 'retry_after' => 0, 'message' => 'ok'];
        }

        return [
            'limited' => false,
            'attempts' => (int) $row['attempt_count'],
            'retry_after' => 0,
            'message' => 'ok',
        ];
    }

    public function hit($scope, $identity, $maxAttempts, $windowSeconds, $lockSeconds, $label = '', $ip = '')
    {
        if (!$this->schemaReady()) {
            return ['limited' => false, 'attempts' => 0, 'retry_after' => 0, 'message' => 'ok'];
        }
        $scope = $this->scope($scope);
        $identityHash = $this->identityHash($scope, $identity);
        $label = $this->label($label !== '' ? $label : $identity);
        $ip = substr((string) $ip, 0, 45);
        $now = now();
        $row = $this->row($scope, $identity);
        $reset = true;

        if ($row) {
            $lockedUntil = !empty($row['locked_until']) ? strtotime($row['locked_until']) : 0;
            $firstAt = !empty($row['first_attempt_at']) ? strtotime($row['first_attempt_at']) : 0;
            $reset = $lockedUntil <= time() && ($firstAt <= 0 || $firstAt < time() - (int) $windowSeconds);
        }

        $count = $reset ? 1 : ((int) $row['attempt_count'] + 1);
        $lockedUntilValue = null;
        if ((int) $maxAttempts > 0 && $count >= (int) $maxAttempts) {
            $lockedUntilValue = date('Y-m-d H:i:s', time() + max(1, (int) $lockSeconds));
        }

        Database::execute(
            'INSERT INTO ' . Database::table('security_rate_limits') . ' (scope, identity_hash, identity_label, ip, attempt_count, locked_until, first_attempt_at, last_attempt_at)
             VALUES (?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE identity_label = VALUES(identity_label), ip = VALUES(ip), attempt_count = VALUES(attempt_count), locked_until = VALUES(locked_until), first_attempt_at = VALUES(first_attempt_at), last_attempt_at = VALUES(last_attempt_at)',
            [$scope, $identityHash, $label, $ip, $count, $lockedUntilValue, $reset ? $now : $row['first_attempt_at'], $now]
        );

        return $this->check($scope, $identity, $windowSeconds);
    }

    public function clear($scope, $identity)
    {
        if (!$this->schemaReady()) {
            return;
        }
        $scope = $this->scope($scope);
        Database::execute(
            'DELETE FROM ' . Database::table('security_rate_limits') . ' WHERE scope = ? AND identity_hash = ?',
            [$scope, $this->identityHash($scope, $identity)]
        );
    }

    public function prune($days = 3)
    {
        if (!$this->schemaReady()) {
            return;
        }
        Database::execute('DELETE FROM ' . Database::table('security_rate_limits') . ' WHERE last_attempt_at < DATE_SUB(NOW(), INTERVAL ' . max(1, (int) $days) . ' DAY)');
    }

    protected function schemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureSecuritySchema();
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function row($scope, $identity)
    {
        $scope = $this->scope($scope);
        return Database::fetch(
            'SELECT * FROM ' . Database::table('security_rate_limits') . ' WHERE scope = ? AND identity_hash = ? LIMIT 1',
            [$scope, $this->identityHash($scope, $identity)]
        );
    }

    protected function identityHash($scope, $identity)
    {
        return hash('sha256', $scope . '|' . text_lower(trim((string) $identity)));
    }

    protected function scope($scope)
    {
        $scope = preg_replace('/[^A-Za-z0-9_\-]/', '_', (string) $scope);
        return substr($scope ?: 'default', 0, 40);
    }

    protected function label($label)
    {
        return text_limit((string) $label, 180);
    }
}
