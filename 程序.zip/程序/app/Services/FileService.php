<?php
namespace App\Services;

use App\Core\Config;
use App\Core\Database;
use App\Models\FileItem;
use App\Models\StorageDriver;
use App\Services\Storage\StorageManager;
use App\Services\FileLogService;
use App\Services\StorageBackupService;

class FileService
{
    public function uploadForUser($user, array $file, $type = 'image', $folderId = 0, array $options = [])
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new \RuntimeException($this->uploadErrorMessage((int) $file['error']));
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $this->assertSafeExtension($ext);
        $allowed = $type === 'image' ? Config::get('app.upload.image_ext', []) : Config::get('app.upload.file_ext', []);
        if (!in_array($ext, $allowed, true)) {
            throw new \RuntimeException('不支持的文件类型。');
        }
        $detectedMime = $this->assertFileContent($file, $type, $ext);

        $driverRecord = (new StorageDriver())->defaultDriver();
        if (!$driverRecord) {
            throw new \RuntimeException('请先在后台配置默认对象存储。');
        }

        $freshUser = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$user['id']]);
        if (!$freshUser) {
            throw new \RuntimeException('用户不存在或已被禁用。');
        }
        $package = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$freshUser['package_id']]);
        $this->assertPackageAllow($package, $type, $file['size'], $freshUser, !empty($options['bypass_feature_gate']));

        $objectKey = $this->buildObjectKey($file['name'], $ext, $type);
        try {
            $driver = StorageManager::make($driverRecord);
            $this->assertStoragePreflight($driverRecord, $driver);
        } catch (\Throwable $e) {
            throw $this->storageStageException('config', $driverRecord, $e);
        }

        try {
            $result = $driver->upload($file['tmp_name'], $objectKey, ['mime' => $detectedMime]);
            if (!is_array($result) || empty($result['path']) || empty($result['url'])) {
                throw new \RuntimeException('存储驱动返回结果不完整，缺少 path 或 url。');
            }
        } catch (\Throwable $e) {
            throw $this->storageStageException('upload', $driverRecord, $e, ['object_key' => $objectKey]);
        }

        $imageSize = $type === 'image' ? @getimagesize($file['tmp_name']) : null;
        $thumbnail = $type === 'image' ? $this->uploadImageThumbnail($driver, $driverRecord, $file['tmp_name'], $objectKey, $detectedMime, $imageSize) : null;
        $thumbnailUrl = $thumbnail && !empty($thumbnail['url']) ? $thumbnail['url'] : $result['url'];
        $fileModel = new FileItem();
        Database::begin();
        try {
            $lockedUser = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1 FOR UPDATE', [$user['id']]);
            if (!$lockedUser) {
                throw new \RuntimeException('用户不存在或已被禁用。');
            }
            $this->assertPackageAllow($package, $type, $file['size'], $lockedUser, !empty($options['bypass_feature_gate']));

            $id = $fileModel->create([
                'user_id' => $user['id'],
                'storage_id' => $driverRecord['id'],
                'folder_id' => $folderId,
                'file_type' => $type,
                'file_name' => basename($objectKey),
                'original_name' => $this->safeOriginalName($file['name']),
                'file_ext' => $ext,
                'mime_type' => $detectedMime,
                'file_size' => $file['size'],
                'file_path' => $result['path'],
                'file_url' => $result['url'],
                'thumbnail_url' => $thumbnailUrl,
                'md5' => md5_file($file['tmp_name']),
                'width' => $imageSize ? $imageSize[0] : null,
                'height' => $imageSize ? $imageSize[1] : null,
                'is_public' => 1,
                'download_count' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            Database::execute('UPDATE ' . Database::table('users') . ' SET used_storage = used_storage + ?, updated_at = ? WHERE id = ?', [$file['size'], now(), $user['id']]);
            (new FileLogService())->log($user['id'], $id, $type === 'image' ? 'image_upload' : 'file_upload', $file['name'], $file['size'], ['storage_id' => $driverRecord['id']]);
            (new StorageBackupService())->backupUploadedFile([
                'id' => $id,
                'user_id' => $user['id'],
                'storage_id' => $driverRecord['id'],
                'file_type' => $type,
                'file_path' => $result['path'],
                'file_url' => $result['url'],
            ], $file['tmp_name'], $objectKey, $detectedMime);
            Database::commit();
            return $fileModel->find($id);
        } catch (\Throwable $e) {
            Database::rollBack();
            $cleanupMessage = '系统已尝试清理远程文件。';
            try {
                $driver->delete($result['path']);
                if ($thumbnail && !empty($thumbnail['path'])) {
                    $driver->delete($thumbnail['path']);
                }
            } catch (\Throwable $deleteError) {
                $cleanupMessage = '远程文件自动清理失败，请到对象存储后台检查是否残留：' . $this->cleanExceptionMessage($deleteError->getMessage());
                \App\Core\Logger::error('上传入库失败后清理远程文件失败：' . $deleteError->getMessage(), ['path' => $result['path']]);
            }
            throw $this->storageStageException('database', $driverRecord, $e, [
                'object_key' => isset($result['path']) ? $result['path'] : $objectKey,
                'cleanup' => $cleanupMessage,
            ]);
        }
    }

    protected function storageStageException($stage, array $driverRecord, \Throwable $e, array $context = [])
    {
        $storage = $this->storageDisplayName($driverRecord);
        $message = $this->cleanExceptionMessage($e->getMessage());
        $parts = [
            $this->storageStageLabel($stage) . '失败：默认存储【' . $storage . '】' . $this->storageStageHint($stage),
        ];
        if (!empty($context['object_key'])) {
            $parts[] = '对象路径：' . $this->cleanExceptionMessage($context['object_key']) . '。';
        }
        if (!empty($context['cleanup'])) {
            $parts[] = $context['cleanup'];
        }
        if ($message !== '') {
            $parts[] = '原始错误：' . $message;
        }
        return new \RuntimeException(implode(' ', $parts), 0, $e);
    }

    protected function uploadImageThumbnail($driver, array $driverRecord, $sourcePath, $objectKey, $mime, $imageSize)
    {
        $thumb = $this->createImageThumbnail($sourcePath, $mime, $imageSize);
        if (!$thumb) {
            return null;
        }

        try {
            $thumbKey = $this->thumbnailObjectKey($objectKey, $thumb['ext']);
            $result = $driver->upload($thumb['path'], $thumbKey, ['mime' => $thumb['mime']]);
            if (!is_array($result) || empty($result['path']) || empty($result['url'])) {
                throw new \RuntimeException('缩略图存储驱动返回结果不完整。');
            }
            return $result;
        } catch (\Throwable $e) {
            \App\Core\Logger::error('图片缩略图生成后上传失败：' . $e->getMessage(), [
                'storage_id' => isset($driverRecord['id']) ? (int) $driverRecord['id'] : 0,
                'object_key' => $objectKey,
            ]);
            return null;
        } finally {
            if (!empty($thumb['path']) && is_file($thumb['path'])) {
                @unlink($thumb['path']);
            }
        }
    }

    protected function createImageThumbnail($sourcePath, $mime, $imageSize)
    {
        if (!is_file($sourcePath) || !is_array($imageSize) || empty($imageSize[0]) || empty($imageSize[1])) {
            return null;
        }
        if (!function_exists('imagecreatetruecolor') || !function_exists('imagesx') || !function_exists('imagesy')) {
            return null;
        }

        $mime = strtolower((string) $mime);
        $width = (int) $imageSize[0];
        $height = (int) $imageSize[1];
        if ($width <= 0 || $height <= 0) {
            return null;
        }

        $maxSide = max(120, min(1200, (int) setting('image_thumbnail_max_side', 480)));
        $ratio = min(1, $maxSide / max($width, $height));
        if ($ratio >= 1 && filesize($sourcePath) < 256 * 1024) {
            return null;
        }

        $source = $this->imageResourceFromFile($sourcePath, $mime);
        if (!$source) {
            return null;
        }

        $targetWidth = max(1, (int) round($width * $ratio));
        $targetHeight = max(1, (int) round($height * $ratio));
        $canvas = imagecreatetruecolor($targetWidth, $targetHeight);
        if (!$canvas) {
            imagedestroy($source);
            return null;
        }

        imagealphablending($canvas, false);
        imagesavealpha($canvas, true);
        $transparent = imagecolorallocatealpha($canvas, 255, 255, 255, 127);
        imagefilledrectangle($canvas, 0, 0, $targetWidth, $targetHeight, $transparent);
        imagecopyresampled($canvas, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, imagesx($source), imagesy($source));

        $tmp = tempnam(sys_get_temp_dir(), 'bm_thumb_');
        if (!$tmp) {
            imagedestroy($canvas);
            imagedestroy($source);
            return null;
        }

        $ext = 'jpg';
        $thumbMime = 'image/jpeg';
        $ok = false;
        if (function_exists('imagewebp')) {
            $ext = 'webp';
            $thumbMime = 'image/webp';
            $ok = imagewebp($canvas, $tmp, max(50, min(95, (int) setting('image_thumbnail_quality', 82))));
        }
        if (!$ok && function_exists('imagejpeg')) {
            $ext = 'jpg';
            $thumbMime = 'image/jpeg';
            $ok = imagejpeg($canvas, $tmp, max(50, min(95, (int) setting('image_thumbnail_quality', 82))));
        }

        imagedestroy($canvas);
        imagedestroy($source);

        if (!$ok || !is_file($tmp) || filesize($tmp) <= 0) {
            @unlink($tmp);
            return null;
        }

        return [
            'path' => $tmp,
            'ext' => $ext,
            'mime' => $thumbMime,
        ];
    }

    protected function imageResourceFromFile($path, $mime)
    {
        $mime = strtolower((string) $mime);
        if (($mime === 'image/jpeg' || $mime === 'image/jpg') && function_exists('imagecreatefromjpeg')) {
            return @imagecreatefromjpeg($path);
        }
        if ($mime === 'image/png' && function_exists('imagecreatefrompng')) {
            return @imagecreatefrompng($path);
        }
        if ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) {
            return @imagecreatefromwebp($path);
        }
        if ($mime === 'image/bmp' && function_exists('imagecreatefrombmp')) {
            return @imagecreatefrombmp($path);
        }
        if ($mime === 'image/gif' && function_exists('imagecreatefromgif')) {
            return @imagecreatefromgif($path);
        }
        return null;
    }

    protected function thumbnailObjectKey($objectKey, $ext)
    {
        $objectKey = str_replace('\\', '/', ltrim((string) $objectKey, '/'));
        $dir = trim(dirname($objectKey), '.\\/');
        $name = pathinfo($objectKey, PATHINFO_FILENAME);
        $name = preg_replace('/[^A-Za-z0-9_\-.]/', '-', $name);
        $target = ($dir !== '' ? $dir . '/thumbs/' : 'thumbs/') . $name . '_480.' . ($ext === 'webp' ? 'webp' : 'jpg');
        return preg_replace('#/+#', '/', $target);
    }

    protected function storageDisplayName(array $driverRecord)
    {
        $name = trim((string) (isset($driverRecord['name']) ? $driverRecord['name'] : ''));
        $type = trim((string) (isset($driverRecord['type']) ? $driverRecord['type'] : ''));
        if ($name === '') {
            $name = '未命名存储';
        }
        return $type !== '' ? $name . ' / ' . strtoupper($type) : $name;
    }

    protected function storageStageLabel($stage)
    {
        $labels = [
            'config' => '存储配置检查',
            'upload' => '存储写入',
            'database' => '数据库入库',
        ];
        return isset($labels[$stage]) ? $labels[$stage] : '上传处理';
    }

    protected function storageStageHint($stage)
    {
        if ($stage === 'config') {
            return '无法完成驱动初始化或基础配置检查，请到后台「资源功能管理」重新保存配置并执行真实测试。';
        }
        if ($stage === 'upload') {
            return '向第三方厂商写入文件时失败，请检查 Bucket、Endpoint、区域、AK/SK、写入权限、CORS/防盗链和云厂商服务状态。';
        }
        if ($stage === 'database') {
            return '文件已写入对象存储，但本地文件记录、用户空间或日志写入失败，请进入后台「数据库巡检」修复结构后重试。';
        }
        return '上传链路未完成，请根据原始错误继续排查。';
    }

    protected function cleanExceptionMessage($message)
    {
        $message = trim((string) $message);
        $message = preg_replace('/\s+/', ' ', $message);
        return text_limit($message, 500);
    }

    protected function uploadErrorMessage($code)
    {
        switch ((int) $code) {
            case UPLOAD_ERR_INI_SIZE:
                return '上传失败：文件超过服务器 upload_max_filesize 限制（当前 ' . (ini_get('upload_max_filesize') ?: '-') . '）。请减小文件或在 PHP 配置中调大 upload_max_filesize 和 post_max_size。';
            case UPLOAD_ERR_FORM_SIZE:
                return '上传失败：文件超过表单允许大小，请减小文件后重试。';
            case UPLOAD_ERR_PARTIAL:
                return '上传失败：文件只上传了一部分，通常是网络中断、反向代理超时或服务器连接被重置。请重试或减小文件。';
            case UPLOAD_ERR_NO_FILE:
                return '上传失败：服务器没有收到文件，请重新选择文件后再上传。';
            case UPLOAD_ERR_NO_TMP_DIR:
                return '上传失败：服务器缺少 PHP 上传临时目录，请在后台“环境信息”检查 upload_tmp_dir。';
            case UPLOAD_ERR_CANT_WRITE:
                return '上传失败：服务器无法写入临时文件，请检查临时目录和 public/uploads 权限。';
            case UPLOAD_ERR_EXTENSION:
                return '上传失败：PHP 扩展拦截了本次上传，请检查服务器安全扩展或上传组件配置。';
            default:
                return '上传失败：PHP 返回未知上传错误码 ' . (int) $code . '。请检查服务器 PHP 错误日志。';
        }
    }

    protected function assertPackageAllow($package, $type, $size, array $user, $bypassFeatureGate = false)
    {
        if (!$package) {
            throw new \RuntimeException('当前账户未绑定套餐。');
        }
        if ($bypassFeatureGate) {
            if ($type === 'image' && !(int) $package['allow_image']) {
                throw new \RuntimeException('游客上传归属账号的套餐不允许图床上传。');
            }
            if ($type === 'file' && !(int) $package['allow_netdisk']) {
                throw new \RuntimeException('游客上传归属账号的套餐不允许网盘上传。');
            }
        } else {
            $permission = new PermissionService();
            if ($type === 'image' && !$permission->featureAllowed($user, 'image', $package)) {
                throw new \RuntimeException($permission->message('image'));
            }
            if ($type === 'file' && !$permission->featureAllowed($user, 'netdisk', $package)) {
                throw new \RuntimeException($permission->message('netdisk'));
            }
        }
        if ((int) $package['single_file_limit'] > 0 && $size > (int) $package['single_file_limit']) {
            throw new \RuntimeException('文件大小超过套餐单文件限制。');
        }
        if ((int) $user['total_storage'] > 0 && ((int) $user['used_storage'] + $size) > (int) $user['total_storage']) {
            throw new \RuntimeException('剩余存储空间不足。');
        }
    }

    protected function assertStoragePreflight(array $driverRecord, $driver)
    {
        $name = isset($driverRecord['name']) ? (string) $driverRecord['name'] : '默认存储';
        $type = isset($driverRecord['type']) ? (string) $driverRecord['type'] : '';
        if ($type !== 'local' && !function_exists('curl_init')) {
            throw new \RuntimeException('默认存储【' . $name . '】需要 PHP curl 扩展，当前环境未启用。请在服务器 PHP 扩展中启用 curl 后重试。');
        }
        if (in_array($type, ['kodo', 'bmtools'], true) && !class_exists('\CURLFile')) {
            throw new \RuntimeException('默认存储【' . $name . '】需要 PHP CURLFile 能力，当前环境不可用。请升级/启用 PHP curl 扩展后重试。');
        }
        if (!empty($driverRecord['secret_key']) && strpos((string) $driverRecord['secret_key'], 'enc:') === 0 && !function_exists('openssl_decrypt')) {
            throw new \RuntimeException('默认存储【' . $name . '】的密钥已加密，但当前 PHP 缺少 openssl 扩展，无法读取密钥。请启用 openssl 后重试。');
        }

        if ($type === 'bmtools') {
            if (empty($driverRecord['endpoint']) || empty($driverRecord['secret_key'])) {
                throw new \RuntimeException('默认同系统对接【' . $name . '】缺少远端站点地址或对接 Token，请到后台资源功能管理重新填写并执行真实测试。');
            }
            return;
        }

        if (method_exists($driver, 'test')) {
            $test = $driver->test();
            if (is_array($test) && empty($test['success'])) {
                $message = isset($test['message']) ? $test['message'] : '配置未通过基础检查。';
                throw new \RuntimeException('默认存储【' . $name . ' / ' . $type . '】配置不完整：' . $message . ' 请到后台「资源功能管理」执行真实测试。');
            }
        }
    }

    protected function assertSafeExtension($ext)
    {
        $ext = strtolower(trim((string) $ext));
        if ($ext === '') {
            throw new \RuntimeException('文件缺少扩展名，请确认文件类型后再上传。');
        }

        $dangerous = [
            'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar',
            'cgi', 'pl', 'py', 'rb', 'go', 'jsp', 'asp', 'aspx',
            'sh', 'bash', 'zsh', 'fish', 'bat', 'cmd', 'ps1', 'psm1',
            'exe', 'dll', 'so', 'dylib', 'com', 'scr', 'msi',
            'jar', 'war', 'ear', 'html', 'htm', 'xhtml', 'svg',
            'js', 'mjs', 'jsx', 'ts', 'tsx', 'css',
        ];
        if (in_array($ext, $dangerous, true)) {
            throw new \RuntimeException('出于安全考虑，不允许上传可执行脚本或网页文件。');
        }
    }

    protected function assertFileContent(array $file, $type, $ext = '')
    {
        if (!is_file($file['tmp_name'])) {
            throw new \RuntimeException('上传临时文件不存在，请重试。');
        }

        $mime = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo) {
                $mime = (string) finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
            }
        }
        if ($mime === '' && function_exists('mime_content_type')) {
            $mime = (string) mime_content_type($file['tmp_name']);
        }

        if ($type === 'image') {
            $size = @getimagesize($file['tmp_name']);
            if (!$size || empty($size['mime']) || strpos($size['mime'], 'image/') !== 0) {
                throw new \RuntimeException('上传文件不是有效图片。');
            }
            $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp'];
            if ($mime && !in_array($mime, $allowedMimes, true)) {
                throw new \RuntimeException('图片 MIME 类型异常：' . $mime);
            }
            return $mime ?: (string) $size['mime'];
        }

        $blocked = [
            'application/x-php',
            'text/x-php',
            'application/x-httpd-php',
            'text/html',
            'application/xhtml+xml',
            'image/svg+xml',
            'application/javascript',
            'text/javascript',
            'application/x-javascript',
            'application/ecmascript',
            'text/ecmascript',
            'application/x-sh',
            'text/x-shellscript',
            'application/x-msdownload',
            'application/x-msdos-program',
            'application/vnd.microsoft.portable-executable',
            'application/java-archive',
        ];
        if ($mime && in_array($mime, $blocked, true)) {
            throw new \RuntimeException('出于安全考虑，不允许上传可执行脚本文件。');
        }
        return $mime ?: 'application/octet-stream';
    }

    protected function buildObjectKey($originalName, $ext, $type)
    {
        $strategy = setting('file_naming_strategy', 'random');
        if ($strategy === 'original') {
            $name = pathinfo($originalName, PATHINFO_FILENAME);
            $name = preg_replace('/[^A-Za-z0-9_\x{4e00}-\x{9fa5}-]+/u', '-', $name);
        } elseif ($strategy === 'timestamp') {
            $name = date('YmdHis') . mt_rand(1000, 9999);
        } elseif ($strategy === 'hash') {
            $name = sha1($originalName . microtime(true) . mt_rand());
        } else {
            $name = bin2hex(random_bytes(12));
        }
        return trim($type, '/') . '/' . date('Y/m/d') . '/' . $name . '.' . $ext;
    }

    protected function safeOriginalName($name)
    {
        $name = basename(str_replace('\\', '/', (string) $name));
        $name = preg_replace('/[\x00-\x1F\x7F]+/', '', $name);
        $name = trim($name);
        return text_limit($name !== '' ? $name : 'file', 180);
    }
}
