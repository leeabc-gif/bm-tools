<?php
namespace App\Services\Monitor;

use App\Core\Database;

class AgentMonitorCollector
{
    public function test(array $server)
    {
        $data = $this->request($server);
        if (empty($data['success'])) {
            throw new \RuntimeException('探针返回异常。');
        }
        return $data;
    }

    public function collect(array $server)
    {
        $data = $this->request($server);
        return $this->normalizePayload($server, $data);
    }

    public function normalizePayload(array $server, array $data)
    {
        if (empty($data['success'])) {
            $data['success'] = true;
        }
        $net = $this->networkSpeed($server, $data);
        $diskTotals = $this->diskTotals($data);
        $realDisks = $this->realDisks(isset($data['disk']) && is_array($data['disk']) ? $data['disk'] : []);

        return [
            'cpu_usage' => (float) (isset($data['cpu_usage']) ? $data['cpu_usage'] : 0),
            'memory_total' => (int) (isset($data['memory_total']) ? $data['memory_total'] : 0),
            'memory_used' => (int) (isset($data['memory_used']) ? $data['memory_used'] : 0),
            'memory_usage' => (float) (isset($data['memory_usage']) ? $data['memory_usage'] : 0),
            'disk_total' => (int) $diskTotals['total'],
            'disk_used' => (int) $diskTotals['used'],
            'disk_usage' => (float) $diskTotals['usage'],
            'net_upload' => $net['upload'],
            'net_download' => $net['download'],
            'load_avg' => (string) (isset($data['load_avg']) ? $data['load_avg'] : ''),
            'uptime' => (string) (isset($data['uptime']) ? $data['uptime'] : ''),
            'nginx_status' => 'unknown',
            'mysql_status' => 'unknown',
            'php_status' => 'running',
            'panel_status' => 'agent',
            'raw_data' => ['agent' => $data, 'disk' => $realDisks, 'services' => ['source' => 'agent']],
        ];
    }

    protected function diskTotals(array $data)
    {
        $disks = $this->realDisks(isset($data['disk']) && is_array($data['disk']) ? $data['disk'] : []);
        $total = 0;
        $used = 0;
        foreach ($disks as $disk) {
            $total += (float) (isset($disk['total']) ? $disk['total'] : 0);
            $used += (float) (isset($disk['used']) ? $disk['used'] : 0);
        }
        if ($total <= 0) {
            $total = (float) (isset($data['disk_total']) ? $data['disk_total'] : 0);
            $used = (float) (isset($data['disk_used']) ? $data['disk_used'] : 0);
        }
        return [
            'total' => $total,
            'used' => $used,
            'usage' => $total > 0 ? round($used / $total * 100, 2) : 0,
        ];
    }

    protected function realDisks(array $disks)
    {
        $rows = [];
        foreach ($disks as $disk) {
            if (!is_array($disk)) {
                continue;
            }
            $path = isset($disk['path']) ? (string) $disk['path'] : (isset($disk['mountpoint']) ? (string) $disk['mountpoint'] : '');
            $fs = isset($disk['filesystem']) ? (string) $disk['filesystem'] : '';
            if ($this->isIgnoredDisk($path, $fs)) {
                continue;
            }
            $rows[] = $disk;
        }
        return $rows;
    }

    protected function isIgnoredDisk($path, $filesystem = '')
    {
        foreach (['/run', '/dev', '/sys', '/proc', '/var/lib/docker/overlay', '/var/lib/docker/containers'] as $prefix) {
            if ($path === $prefix || strpos($path, $prefix . '/') === 0) {
                return true;
            }
        }
        $filesystem = strtolower((string) $filesystem);
        return strpos($filesystem, 'overlay') !== false || strpos($filesystem, 'tmpfs') !== false;
    }

    protected function request(array $server)
    {
        $url = trim((string) (isset($server['agent_url']) ? $server['agent_url'] : ''));
        $token = trim((string) (isset($server['agent_token']) ? $server['agent_token'] : ''));
        if ($url === '' || $token === '') {
            throw new \RuntimeException('HTTP 探针地址和 Token 不能为空。');
        }
        $url = $this->normalizeAgentUrl($url);
        $separator = strpos($url, '?') === false ? '?' : '&';
        $url .= $separator . 'token=' . rawurlencode($token);

        $body = '';
        $ch = curl_init();
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_HEADER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => ['User-Agent: BMTOOLS-AgentMonitor/1.0'],
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$body) {
                $body .= $chunk;
                return strlen($body) > 1048576 ? 0 : strlen($chunk);
            },
        ];
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        $ok = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($ok === false || $error) {
            if (strlen($body) > 1048576) {
                throw new \RuntimeException('HTTP 探针返回内容过大。');
            }
            throw new \RuntimeException('HTTP 探针连接失败：' . ($error ?: '未知网络错误'));
        }
        if (in_array($code, [301, 302, 303, 307, 308], true)) {
            throw new \RuntimeException('HTTP 探针发生跳转，请填写最终探针地址。');
        }
        if ($code >= 400) {
            throw new \RuntimeException('HTTP 探针返回异常状态码：' . $code);
        }
        $json = json_decode($body, true);
        if (!is_array($json)) {
            throw new \RuntimeException('HTTP 探针返回无法解析：' . text_limit(strip_tags($body), 160));
        }
        if (empty($json['success'])) {
            throw new \RuntimeException(isset($json['message']) ? $json['message'] : 'HTTP 探针返回失败。');
        }
        return $json;
    }

    protected function normalizeAgentUrl($url)
    {
        $url = trim((string) $url);
        if (preg_match('/[\x00-\x1F\x7F]/', $url)) {
            throw new \RuntimeException('HTTP 探针地址包含非法控制字符。');
        }
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        $parts = parse_url($url);
        if (!$parts || empty($parts['host']) || empty($parts['scheme']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
            throw new \RuntimeException('HTTP 探针地址格式不正确。');
        }
        if (!empty($parts['user']) || !empty($parts['pass'])) {
            throw new \RuntimeException('HTTP 探针地址不能包含账号密码。');
        }
        if ($this->blockedAgentHost($parts['host'])) {
            throw new \RuntimeException('HTTP 探针地址不能指向本机、回环地址或云厂商元数据地址。');
        }
        if (isset($parts['port']) && ((int) $parts['port'] < 1 || (int) $parts['port'] > 65535)) {
            throw new \RuntimeException('HTTP 探针端口不正确。');
        }
        return $url;
    }

    protected function blockedAgentHost($host)
    {
        $host = trim(strtolower((string) $host), " \t\n\r\0\x0B[]");
        if ($host === '' || in_array($host, ['localhost', 'localhost.localdomain'], true)) {
            return $host !== '';
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $host === '0.0.0.0'
                || $host === '::'
                || $host === '::1'
                || strpos($host, '127.') === 0
                || $host === '169.254.169.254';
        }
        return false;
    }

    protected function networkSpeed(array $server, array $data)
    {
        $current = $this->sumNetwork(isset($data['network']) && is_array($data['network']) ? $data['network'] : []);
        $previous = Database::fetch('SELECT raw_data, created_at FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 1', [$server['id']]);
        if (!$previous || empty($previous['raw_data'])) {
            return ['upload' => 0, 'download' => 0];
        }
        $raw = json_decode($previous['raw_data'], true);
        $previousRows = isset($raw['agent']['network']) && is_array($raw['agent']['network']) ? $raw['agent']['network'] : [];
        $last = $this->sumNetwork($previousRows);
        $seconds = max(1, time() - strtotime($previous['created_at']));
        return [
            'upload' => max(0, round(($current['tx'] - $last['tx']) / $seconds, 2)),
            'download' => max(0, round(($current['rx'] - $last['rx']) / $seconds, 2)),
        ];
    }

    protected function sumNetwork(array $rows)
    {
        $rx = 0;
        $tx = 0;
        foreach ($rows as $row) {
            $rx += (float) (isset($row['rx']) ? $row['rx'] : 0);
            $tx += (float) (isset($row['tx']) ? $row['tx'] : 0);
        }
        return ['rx' => $rx, 'tx' => $tx];
    }
}
