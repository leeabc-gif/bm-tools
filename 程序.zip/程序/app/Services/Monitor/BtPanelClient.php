<?php
namespace App\Services\Monitor;

use App\Core\Logger;

class BtPanelClient
{
    protected $panelUrl;
    protected $apiKey;
    protected $cookieFile;

    public function __construct($panelUrl, $apiKey, $port = null)
    {
        $this->panelUrl = $this->normalizePanelUrl($panelUrl, $port);
        $this->apiKey = $apiKey;
        $this->cookieFile = APP_ROOT . '/storage/cache/bt_' . md5($this->panelUrl . $apiKey) . '.cookie';
    }

    public function request($path, array $data = [])
    {
        $requestTime = time();
        $data['request_time'] = $requestTime;
        $data['request_token'] = md5($requestTime . md5($this->apiKey));

        $url = $this->panelUrl . '/' . ltrim($path, '/');
        $ch = curl_init();
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_COOKIEJAR => $this->cookieFile,
            CURLOPT_COOKIEFILE => $this->cookieFile,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded',
                'User-Agent: BMTOOLS-Monitor/1.0',
            ],
        ];
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $error) {
            throw new \RuntimeException('宝塔 API 连接失败：' . ($error ?: '未知网络错误') . '，请检查面板地址、端口、防火墙和 API 白名单。');
        }
        if ($code >= 400) {
            Logger::error('宝塔 API HTTP 异常', ['url' => $url, 'code' => $code, 'body' => text_limit($body, 500)]);
            throw new \RuntimeException('宝塔 API HTTP 状态异常：' . $code . '，请确认面板地址可访问。');
        }

        $json = json_decode($body, true);
        if (!is_array($json)) {
            Logger::error('宝塔 API 返回无法解析', ['url' => $url, 'body' => text_limit($body, 500)]);
            throw new \RuntimeException('宝塔 API 返回无法解析，可能是面板登录页、404 页面或反向代理拦截：' . text_limit(strip_tags($body), 120));
        }
        if (isset($json['status']) && $json['status'] === false && isset($json['msg'])) {
            throw new \RuntimeException('宝塔 API 返回错误：' . $json['msg']);
        }
        if (isset($json['msg']) && is_string($json['msg']) && stripos($json['msg'], 'api') !== false && stripos($json['msg'], 'not') !== false) {
            throw new \RuntimeException('宝塔 API 可能未开启或 IP 未加入白名单：' . $json['msg']);
        }
        return $json;
    }

    public function systemTotal()
    {
        return $this->request('/system?action=GetSystemTotal');
    }

    public function diskInfo()
    {
        return $this->request('/system?action=GetDiskInfo');
    }

    public function network()
    {
        return $this->request('/system?action=GetNetWork');
    }

    public function serviceStatus($name)
    {
        return $this->request('/system?action=ServiceAdmin', ['name' => $name, 'type' => 'status']);
    }

    protected function normalizePanelUrl($panelUrl, $port = null)
    {
        $panelUrl = trim((string) $panelUrl);
        if ($panelUrl === '') {
            throw new \InvalidArgumentException('宝塔面板地址不能为空。');
        }
        if (preg_match('/[\x00-\x1F\x7F]/', $panelUrl)) {
            throw new \InvalidArgumentException('宝塔面板地址包含非法控制字符。');
        }
        if (!preg_match('#^https?://#i', $panelUrl)) {
            $panelUrl = 'http://' . $panelUrl;
        }
        $parts = parse_url($panelUrl);
        if (!$parts || empty($parts['host']) || empty($parts['scheme']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
            throw new \InvalidArgumentException('宝塔面板地址格式不正确。');
        }
        if (!empty($parts['user']) || !empty($parts['pass'])) {
            throw new \InvalidArgumentException('宝塔面板地址不能包含账号密码。');
        }
        $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'http';
        $host = $parts['host'];
        $path = isset($parts['path']) ? rtrim($parts['path'], '/') : '';
        $finalPort = isset($parts['port']) ? $parts['port'] : ($port ? (int) $port : null);
        if ($finalPort !== null && ((int) $finalPort < 1 || (int) $finalPort > 65535)) {
            throw new \InvalidArgumentException('宝塔面板端口不正确。');
        }
        $url = $scheme . '://' . $host . ($finalPort ? ':' . $finalPort : '') . $path;
        return rtrim($url, '/');
    }
}
