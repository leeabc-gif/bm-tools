<?php
namespace App\Services\Monitor;

use App\Core\Database;
use App\Core\Logger;
use App\Models\MonitorMetric;
use App\Services\AlertWebhookService;
use App\Services\NotificationService;

class MonitorService
{
    public function collect(array $server)
    {
        try {
            $metric = $this->collectMetric($server);
            return $this->storeMetric($server, $metric);
        } catch (\Throwable $e) {
            Logger::error('监控采集失败：' . $e->getMessage(), ['server_id' => $server['id']]);
            Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET status = ?, last_error = ?, last_checked_at = ?, updated_at = ? WHERE id = ?', ['offline', $e->getMessage(), now(), now(), $server['id']]);
            $this->createAlert($server, 'danger', 'panel_status', '监控连接失败', $e->getMessage());
            throw $e;
        }
    }

    public function storeMetric(array $server, array $metric)
    {
        $metricId = (new MonitorMetric())->create([
            'server_id' => $server['id'],
            'cpu_usage' => $metric['cpu_usage'],
            'memory_total' => $metric['memory_total'],
            'memory_used' => $metric['memory_used'],
            'memory_usage' => $metric['memory_usage'],
            'disk_total' => $metric['disk_total'],
            'disk_used' => $metric['disk_used'],
            'disk_usage' => $metric['disk_usage'],
            'net_upload' => $metric['net_upload'],
            'net_download' => $metric['net_download'],
            'load_avg' => $metric['load_avg'],
            'uptime' => $metric['uptime'],
            'nginx_status' => $metric['nginx_status'],
            'mysql_status' => $metric['mysql_status'],
            'php_status' => $metric['php_status'],
            'panel_status' => $metric['panel_status'],
            'raw_data' => json_encode($metric['raw_data'], JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
        ]);

        Database::execute(
            'UPDATE ' . Database::table('monitor_servers') . ' SET status = ?, last_error = NULL, last_checked_at = ?, updated_at = ? WHERE id = ?',
            ['online', now(), now(), $server['id']]
        );
        $this->checkAlerts($server, $metric);
        return $metricId;
    }

    public function test(array $server)
    {
        if (isset($server['monitor_type']) && $server['monitor_type'] === 'ssh') {
            (new SshMonitorCollector())->test($server);
            return ['status' => true, 'type' => 'ssh'];
        }
        if (isset($server['monitor_type']) && $server['monitor_type'] === 'agent') {
            return (new AgentMonitorCollector())->test($server);
        }
        $client = new BtPanelClient($server['panel_url'], $server['api_key'], isset($server['panel_port']) ? $server['panel_port'] : null);
        $system = $client->systemTotal();
        if (!is_array($system) || (!$this->pick($system, ['cpuRealUsed', 'cpu', 'memTotal', 'mem', 'loadAverage'], null))) {
            throw new \RuntimeException('连接成功，但返回内容不像系统状态数据，请检查宝塔 API 权限。');
        }
        return $system;
    }

    protected function collectMetric(array $server)
    {
        if (isset($server['monitor_type']) && $server['monitor_type'] === 'ssh') {
            return (new SshMonitorCollector())->collect($server);
        }
        if (isset($server['monitor_type']) && $server['monitor_type'] === 'agent') {
            return (new AgentMonitorCollector())->collect($server);
        }

        $client = new BtPanelClient($server['panel_url'], $server['api_key'], isset($server['panel_port']) ? $server['panel_port'] : null);
        $system = $client->systemTotal();
        $disk = $client->diskInfo();
        $network = $client->network();
        $services = $this->serviceStatuses($client);
        $metric = $this->normalize($system, $disk, $network, $services);
        $metric['panel_status'] = 'online';
        $metric['raw_data'] = ['system' => $system, 'disk' => $disk, 'network' => $network, 'services' => $services];
        return $metric;
    }

    protected function serviceStatuses(BtPanelClient $client)
    {
        $statuses = ['nginx' => 'unknown', 'mysql' => 'unknown', 'php' => 'unknown'];
        foreach (['nginx' => 'nginx', 'mysql' => 'mysql', 'php' => 'php-fpm'] as $key => $service) {
            try {
                $result = $client->serviceStatus($service);
                $statuses[$key] = $this->normalizeServiceStatus($result);
                if ($key === 'php' && $statuses[$key] === 'unknown') {
                    foreach (['php-74', 'php-73', 'php-80', 'php-81', 'php-82', 'php-83'] as $phpName) {
                        $result = $client->serviceStatus($phpName);
                        $statuses[$key] = $this->normalizeServiceStatus($result);
                        if ($statuses[$key] !== 'unknown') {
                            break;
                        }
                    }
                }
            } catch (\Throwable $e) {
                $statuses[$key] = 'unknown';
            }
        }
        return $statuses;
    }

    protected function normalizeServiceStatus($result)
    {
        $text = strtolower(json_encode($result, JSON_UNESCAPED_UNICODE));
        if (isset($result['status']) && ($result['status'] === true || $result['status'] === 'true')) {
            return 'running';
        }
        if (isset($result['status']) && ($result['status'] === false || $result['status'] === 'false')) {
            return 'stopped';
        }
        if (strpos($text, 'true') !== false || strpos($text, 'running') !== false || strpos($text, 'active') !== false || strpos($text, 'start') !== false) {
            return 'running';
        }
        if (strpos($text, 'false') !== false || strpos($text, 'stop') !== false || strpos($text, 'inactive') !== false || strpos($text, 'dead') !== false) {
            return 'stopped';
        }
        return 'unknown';
    }

    protected function normalize(array $system, array $disk, array $network, array $services)
    {
        $mem = isset($system['mem']) && is_array($system['mem']) ? $system['mem'] : [];
        $memTotalRaw = $this->pick($system, ['memTotal', 'mem_total', 'memory_total'], $this->pick($mem, ['memTotal', 'total'], 0));
        $memUsedRaw = $this->pick($system, ['memRealUsed', 'memUsed', 'memory_used'], $this->pick($mem, ['memRealUsed', 'used'], 0));
        $memTotal = $this->normalizeMbToBytes($memTotalRaw);
        $memRealUsed = $this->normalizeMbToBytes($memUsedRaw);
        $memUsage = $this->pick($system, ['memPercent', 'memUsedPercent', 'memory_usage'], null);
        if ($memUsage === null) {
            $memUsage = $memTotal > 0 ? round($memRealUsed / $memTotal * 100, 2) : 0;
        }

        $diskTotal = 0;
        $diskUsed = 0;
        if (is_array($disk)) {
            foreach ($disk as $row) {
                if (isset($row['size']) && isset($row['used'])) {
                    $diskTotal += $this->parseSize($row['size']);
                    $diskUsed += $this->parseSize($row['used']);
                } elseif (isset($row['total']) && isset($row['used'])) {
                    $diskTotal += $this->parseSize($row['total']);
                    $diskUsed += $this->parseSize($row['used']);
                }
            }
        }
        $diskUsage = $diskTotal > 0 ? round($diskUsed / $diskTotal * 100, 2) : 0;

        return [
            'cpu_usage' => (float) $this->pick($system, ['cpuRealUsed', 'cpu_usage', 'cpuUsed', 'cpu'], 0),
            'memory_total' => (int) $memTotal,
            'memory_used' => (int) $memRealUsed,
            'memory_usage' => $memUsage,
            'disk_total' => (int) $diskTotal,
            'disk_used' => (int) $diskUsed,
            'disk_usage' => $diskUsage,
            'net_upload' => (float) $this->pick($network, ['up', 'upTotal', 'upSpeed', 'up_speed'], 0),
            'net_download' => (float) $this->pick($network, ['down', 'downTotal', 'downSpeed', 'down_speed'], 0),
            'load_avg' => (string) $this->pick($system, ['loadAverage', 'load_avg', 'load'], ''),
            'uptime' => (string) $this->pick($system, ['time', 'uptime', 'runTime'], ''),
            'nginx_status' => $services['nginx'],
            'mysql_status' => $services['mysql'],
            'php_status' => $services['php'],
        ];
    }

    protected function pick(array $source, array $keys, $default = null)
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $source) && $source[$key] !== '' && $source[$key] !== null) {
                return $source[$key];
            }
        }
        return $default;
    }

    protected function normalizeMbToBytes($value)
    {
        if (is_numeric($value)) {
            return (float) $value * 1024 * 1024;
        }
        return $this->parseSize($value);
    }

    protected function parseSize($value)
    {
        if (is_numeric($value)) {
            return (float) $value;
        }
        $value = trim((string) $value);
        if (!preg_match('/([\d\.]+)\s*([KMGTP]?)/i', $value, $m)) {
            return 0;
        }
        $num = (float) $m[1];
        $unit = strtoupper($m[2]);
        $map = ['K' => 1024, 'M' => 1048576, 'G' => 1073741824, 'T' => 1099511627776, 'P' => 1125899906842624];
        return $num * (isset($map[$unit]) ? $map[$unit] : 1);
    }

    protected function checkAlerts(array $server, array $metric)
    {
        $config = json_decode((string) $server['threshold_config'], true);
        if (!is_array($config)) {
            $config = ['cpu' => 90, 'memory' => 90, 'disk' => 90];
        }
        if ($metric['cpu_usage'] >= (float) $config['cpu']) {
            $this->createAlert($server, 'warning', 'cpu_usage', 'CPU 使用率过高', '当前 CPU 使用率 ' . $metric['cpu_usage'] . '%');
        }
        if ($metric['memory_usage'] >= (float) $config['memory']) {
            $this->createAlert($server, 'warning', 'memory_usage', '内存使用率过高', '当前内存使用率 ' . $metric['memory_usage'] . '%');
        }
        if ($metric['disk_usage'] >= (float) $config['disk']) {
            $this->createAlert($server, 'danger', 'disk_usage', '磁盘使用率过高', '当前磁盘使用率 ' . $metric['disk_usage'] . '%');
        }
        foreach (['nginx_status' => 'Nginx', 'mysql_status' => 'MySQL', 'php_status' => 'PHP'] as $field => $name) {
            if ($metric[$field] === 'stopped') {
                $this->createAlert($server, 'danger', $field, $name . ' 服务异常', $name . ' 当前状态为 stopped。');
            }
        }
    }

    protected function createAlert(array $server, $level, $metric, $title, $content)
    {
        $recent = Database::fetch(
            'SELECT id FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ? AND metric = ? AND status <> ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE) LIMIT 1',
            [$server['id'], $metric, 'resolved']
        );
        if ($recent) {
            return;
        }

        Database::execute(
            'INSERT INTO ' . Database::table('monitor_alerts') . ' (user_id, server_id, level, metric, title, content, status, created_at) VALUES (?,?,?,?,?,?,?,?)',
            [$server['user_id'], $server['id'], $level, $metric, $title, $content, 'unread', now()]
        );
        $notifier = new NotificationService();
        $notifier->send($server['user_id'], 'monitor_alert', $title, $content);
        $notifier->sendEmail($server['user_id'], $title, $content);
        (new AlertWebhookService())->sendMonitorAlert($server['user_id'], $title, $content, [
            'server_name' => isset($server['name']) ? $server['name'] : '',
            'metric' => $metric,
            'level' => $level,
            'source' => '监控采集',
        ]);
    }
}
