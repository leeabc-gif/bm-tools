<?php
namespace App\Services\Monitor;

use App\Core\Database;

class SlaReportService
{
    public function riskSummary($days = 7)
    {
        try {
            $report = $this->report($days);
            $summary = isset($report['summary']) && is_array($report['summary']) ? $report['summary'] : [];
            $worst = isset($report['worst']) && is_array($report['worst']) ? $report['worst'] : [];
            $worstNode = null;
            foreach ($worst as $server) {
                if (isset($server['sla_percent']) && $server['sla_percent'] !== null) {
                    $worstNode = $server;
                    break;
                }
            }
            return [
                'ok' => true,
                'days' => isset($report['days']) ? (int) $report['days'] : $this->normalizeDays($days),
                'average_sla' => isset($summary['average_sla']) ? $summary['average_sla'] : null,
                'sample_sla' => isset($summary['sample_sla']) ? $summary['sample_sla'] : null,
                'below_99' => isset($summary['below_99']) ? (int) $summary['below_99'] : 0,
                'no_data' => isset($summary['no_data']) ? (int) $summary['no_data'] : 0,
                'collect_delayed' => isset($summary['collect_delayed']) ? (int) $summary['collect_delayed'] : 0,
                'alert_count' => isset($summary['alert_count']) ? (int) $summary['alert_count'] : 0,
                'sample_count' => isset($summary['sample_count']) ? (int) $summary['sample_count'] : 0,
                'worst_node' => $worstNode,
            ];
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'days' => $this->normalizeDays($days),
                'average_sla' => null,
                'sample_sla' => null,
                'below_99' => 0,
                'no_data' => 0,
                'collect_delayed' => 0,
                'alert_count' => 0,
                'sample_count' => 0,
                'worst_node' => null,
            ];
        }
    }

    public function report($days = 7)
    {
        $days = $this->normalizeDays($days);
        $since = date('Y-m-d H:i:s', time() - ($days * 86400));
        $servers = Database::fetchAll(
            'SELECT s.*, u.username, u.nickname
             FROM ' . Database::table('monitor_servers') . ' s
             LEFT JOIN ' . Database::table('users') . ' u ON s.user_id = u.id
             WHERE s.monitor_type = ?
             ORDER BY s.is_enabled DESC, s.status ASC, s.id DESC',
            ['bt']
        );

        $rows = [];
        foreach ($servers as $server) {
            $rows[] = $this->serverRow($server, $since);
        }

        usort($rows, function ($a, $b) {
            $aSla = $a['sla_percent'] === null ? -1 : (float) $a['sla_percent'];
            $bSla = $b['sla_percent'] === null ? -1 : (float) $b['sla_percent'];
            if ($aSla === $bSla) {
                return (int) $b['alert_count'] <=> (int) $a['alert_count'];
            }
            return $aSla <=> $bSla;
        });

        return [
            'days' => $days,
            'since' => $since,
            'summary' => $this->summary($rows),
            'servers' => $rows,
            'worst' => array_slice($rows, 0, 5),
            'recent_alerts' => $this->recentAlerts($since, 10),
        ];
    }

    protected function recentAlerts($since, $limit = 10)
    {
        $limit = min(50, max(1, (int) $limit));
        return Database::fetchAll(
            'SELECT a.id, a.server_id, a.level, a.metric, a.title, a.content, a.status, a.created_at, s.name AS server_name
             FROM ' . Database::table('monitor_alerts') . ' a
             INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id
             WHERE s.monitor_type = ? AND a.created_at >= ?
             ORDER BY a.id DESC' . Database::limitClause($limit, 1, 50),
            ['bt', $since]
        );
    }

    protected function serverRow(array $server, $since)
    {
        $serverId = (int) $server['id'];
        $metric = Database::fetch(
            'SELECT COUNT(*) AS success_samples,
                    AVG(cpu_usage) AS avg_cpu,
                    AVG(memory_usage) AS avg_memory,
                    AVG(disk_usage) AS avg_disk,
                    MAX(created_at) AS last_metric_at
             FROM ' . Database::table('monitor_metrics') . '
             WHERE server_id = ? AND created_at >= ?',
            [$serverId, $since]
        );
        $alert = Database::fetch(
            'SELECT COUNT(*) AS alert_count,
                    SUM(CASE WHEN metric = ? THEN 1 ELSE 0 END) AS connection_failures,
                    MAX(created_at) AS last_alert_at
             FROM ' . Database::table('monitor_alerts') . '
             WHERE server_id = ? AND created_at >= ?',
            ['panel_status', $serverId, $since]
        );
        $lastMetric = Database::fetch(
            'SELECT cpu_usage, memory_usage, disk_usage, nginx_status, mysql_status, php_status, panel_status, created_at
             FROM ' . Database::table('monitor_metrics') . '
             WHERE server_id = ?
             ORDER BY id DESC
             LIMIT 1',
            [$serverId]
        );

        $successSamples = $metric ? (int) $metric['success_samples'] : 0;
        $connectionFailures = $alert ? (int) $alert['connection_failures'] : 0;
        $alertCount = $alert ? (int) $alert['alert_count'] : 0;
        $totalSamples = $successSamples + $connectionFailures;
        $slaPercent = $totalSamples > 0 ? round(($successSamples / $totalSamples) * 100, 2) : null;

        $server['success_samples'] = $successSamples;
        $server['failure_samples'] = $connectionFailures;
        $server['sample_count'] = $totalSamples;
        $server['alert_count'] = $alertCount;
        $server['sla_percent'] = $slaPercent;
        $server['avg_cpu'] = $this->roundMetric($metric, 'avg_cpu');
        $server['avg_memory'] = $this->roundMetric($metric, 'avg_memory');
        $server['avg_disk'] = $this->roundMetric($metric, 'avg_disk');
        $server['last_metric_at'] = $metric && !empty($metric['last_metric_at']) ? $metric['last_metric_at'] : null;
        $server['last_alert_at'] = $alert && !empty($alert['last_alert_at']) ? $alert['last_alert_at'] : null;
        $server['last_sample_at'] = $this->latestTime($server['last_metric_at'], $server['last_alert_at'], isset($server['last_checked_at']) ? $server['last_checked_at'] : null);
        $collectHealth = $this->collectHealth($server);
        $server['collect_status'] = $collectHealth['status'];
        $server['collect_delay_seconds'] = $collectHealth['delay_seconds'];
        $server['collect_delay_minutes'] = $collectHealth['delay_minutes'];
        $server['collect_expected_seconds'] = $collectHealth['expected_seconds'];
        $server['last_metric'] = $lastMetric ?: [];
        $server['health_level'] = $this->healthLevel($slaPercent, $alertCount, isset($server['status']) ? $server['status'] : 'unknown', $server['collect_status']);
        return $server;
    }

    protected function summary(array $rows)
    {
        $total = count($rows);
        $enabled = 0;
        $online = 0;
        $offline = 0;
        $unknown = 0;
        $successSamples = 0;
        $failureSamples = 0;
        $alertCount = 0;
        $slaSum = 0.0;
        $slaCount = 0;
        $below99 = 0;
        $noData = 0;
        $collectDelayed = 0;

        foreach ($rows as $row) {
            if (!empty($row['is_enabled'])) {
                $enabled++;
            }
            $status = isset($row['status']) ? $row['status'] : 'unknown';
            if ($status === 'online') {
                $online++;
            } elseif ($status === 'offline') {
                $offline++;
            } else {
                $unknown++;
            }
            $successSamples += (int) $row['success_samples'];
            $failureSamples += (int) $row['failure_samples'];
            $alertCount += (int) $row['alert_count'];
            if (isset($row['collect_status']) && $row['collect_status'] === 'delayed') {
                $collectDelayed++;
            }
            if ($row['sla_percent'] === null) {
                $noData++;
                continue;
            }
            $slaSum += (float) $row['sla_percent'];
            $slaCount++;
            if ((float) $row['sla_percent'] < 99) {
                $below99++;
            }
        }

        $sampleTotal = $successSamples + $failureSamples;
        return [
            'total' => $total,
            'enabled' => $enabled,
            'online' => $online,
            'offline' => $offline,
            'unknown' => $unknown,
            'success_samples' => $successSamples,
            'failure_samples' => $failureSamples,
            'sample_count' => $sampleTotal,
            'alert_count' => $alertCount,
            'average_sla' => $slaCount > 0 ? round($slaSum / $slaCount, 2) : null,
            'sample_sla' => $sampleTotal > 0 ? round(($successSamples / $sampleTotal) * 100, 2) : null,
            'below_99' => $below99,
            'no_data' => $noData,
            'collect_delayed' => $collectDelayed,
        ];
    }

    protected function collectHealth(array $server)
    {
        if (empty($server['is_enabled'])) {
            return [
                'status' => 'disabled',
                'delay_seconds' => null,
                'delay_minutes' => null,
                'expected_seconds' => null,
            ];
        }

        $frequency = isset($server['frequency']) ? (int) $server['frequency'] : 60;
        $frequency = max(60, $frequency);
        $expectedSeconds = max(300, $frequency * 3);
        $lastChecked = !empty($server['last_checked_at']) ? strtotime((string) $server['last_checked_at']) : 0;
        if ($lastChecked <= 0) {
            return [
                'status' => 'delayed',
                'delay_seconds' => null,
                'delay_minutes' => null,
                'expected_seconds' => $expectedSeconds,
            ];
        }

        $delaySeconds = max(0, time() - $lastChecked);
        return [
            'status' => $delaySeconds > $expectedSeconds ? 'delayed' : 'normal',
            'delay_seconds' => $delaySeconds,
            'delay_minutes' => (int) floor($delaySeconds / 60),
            'expected_seconds' => $expectedSeconds,
        ];
    }

    protected function normalizeDays($days)
    {
        $days = (int) $days;
        return in_array($days, [7, 30, 90], true) ? $days : 7;
    }

    protected function roundMetric($row, $key)
    {
        if (!$row || !isset($row[$key]) || $row[$key] === null) {
            return null;
        }
        return round((float) $row[$key], 2);
    }

    protected function latestTime()
    {
        $latest = null;
        foreach (func_get_args() as $time) {
            if (!$time) {
                continue;
            }
            $stamp = strtotime((string) $time);
            if ($stamp && ($latest === null || $stamp > $latest['stamp'])) {
                $latest = ['stamp' => $stamp, 'value' => $time];
            }
        }
        return $latest ? $latest['value'] : null;
    }

    protected function healthLevel($slaPercent, $alertCount, $status, $collectStatus = 'normal')
    {
        if ($status === 'offline' || $collectStatus === 'delayed') {
            return 'danger';
        }
        if ($slaPercent === null) {
            return 'muted';
        }
        if ($slaPercent < 95 || $alertCount >= 5) {
            return 'danger';
        }
        if ($slaPercent < 99 || $alertCount > 0) {
            return 'warning';
        }
        return 'good';
    }
}
