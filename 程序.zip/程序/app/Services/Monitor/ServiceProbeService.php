<?php
namespace App\Services\Monitor;

use App\Core\Database;
use App\Core\Logger;
use App\Services\AlertWebhookService;
use App\Services\NotificationService;

class ServiceProbeService
{
    public function checksForServer($serverId, $userId = null)
    {
        $sql = 'SELECT * FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ?';
        $params = [(int) $serverId];
        if ($userId !== null) {
            $sql .= ' AND user_id = ?';
            $params[] = (int) $userId;
        }
        $sql .= " ORDER BY FIELD(status, 'down', 'unknown', 'up'), id DESC";
        return Database::fetchAll($sql, $params);
    }

    public function checkForUser($id, $userId)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('server_service_checks') . ' WHERE id = ? AND user_id = ? LIMIT 1',
            [(int) $id, (int) $userId]
        );
    }

    public function statsForUser($userId)
    {
        $row = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status = 'up' THEN 1 ELSE 0 END) AS up_count,
                    SUM(CASE WHEN status = 'down' THEN 1 ELSE 0 END) AS down_count
             FROM " . Database::table('server_service_checks') . ' WHERE user_id = ?',
            [(int) $userId]
        );
        return [
            'total' => $row ? (int) $row['total'] : 0,
            'up' => $row ? (int) $row['up_count'] : 0,
            'down' => $row ? (int) $row['down_count'] : 0,
        ];
    }

    public function statsForServer($serverId)
    {
        $row = Database::fetch(
            "SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status = 'up' THEN 1 ELSE 0 END) AS up_count,
                    SUM(CASE WHEN status = 'down' THEN 1 ELSE 0 END) AS down_count,
                    SUM(CASE WHEN type = 'ssl' AND ssl_expires_at IS NOT NULL AND ssl_expires_at <= DATE_ADD(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS expiring_ssl
             FROM " . Database::table('server_service_checks') . ' WHERE server_id = ?',
            [(int) $serverId]
        );
        return [
            'total' => $row ? (int) $row['total'] : 0,
            'up' => $row ? (int) $row['up_count'] : 0,
            'down' => $row ? (int) $row['down_count'] : 0,
            'expiring_ssl' => $row ? (int) $row['expiring_ssl'] : 0,
        ];
    }

    public function latestLogsForServer($serverId, $limit = 12)
    {
        return Database::fetchAll(
            'SELECT l.*, c.name AS check_name, c.type
             FROM ' . Database::table('server_service_check_logs') . ' l
             LEFT JOIN ' . Database::table('server_service_checks') . ' c ON c.id = l.check_id
             WHERE l.server_id = ?
             ORDER BY l.id DESC' . Database::limitClause($limit, 1, 100),
            [(int) $serverId]
        );
    }

    public function collectForServer(array $server, $force = false)
    {
        $sql = 'SELECT * FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ? AND is_enabled = 1';
        if (!$force) {
            $sql .= ' AND (last_checked_at IS NULL OR TIMESTAMPDIFF(SECOND, last_checked_at, NOW()) >= frequency)';
        }
        $sql .= ' ORDER BY last_checked_at IS NULL DESC, last_checked_at ASC, id ASC';
        $checks = Database::fetchAll($sql, [(int) $server['id']]);
        $result = ['total' => count($checks), 'up' => 0, 'down' => 0, 'items' => []];
        foreach ($checks as $check) {
            try {
                $item = $this->collectCheck($check, $server);
                $result[$item['status'] === 'up' ? 'up' : 'down']++;
                $result['items'][] = $item;
            } catch (\Throwable $e) {
                Logger::error('服务探针采集失败：' . $e->getMessage(), ['check_id' => isset($check['id']) ? $check['id'] : 0]);
            }
        }
        return $result;
    }

    public function collectCheck(array $check, array $server = null)
    {
        try {
            $probe = $this->run($check);
        } catch (\Throwable $e) {
            $probe = $this->probeResult(false, 0, $e->getMessage(), null);
        }
        $status = $probe['success'] ? 'up' : 'down';
        $message = $probe['message'];
        $sslExpiresAt = isset($probe['ssl_expires_at']) ? $probe['ssl_expires_at'] : null;
        $statusCode = isset($probe['status_code']) ? $probe['status_code'] : null;

        Database::execute(
            'UPDATE ' . Database::table('server_service_checks') . ' SET status = ?, response_time_ms = ?, status_code = ?, ssl_expires_at = ?, last_error = ?, last_checked_at = ?, updated_at = ? WHERE id = ?',
            [$status, (int) $probe['response_time_ms'], $statusCode, $sslExpiresAt, $status === 'up' ? '' : $message, now(), now(), (int) $check['id']]
        );
        Database::execute(
            'INSERT INTO ' . Database::table('server_service_check_logs') . ' (check_id, user_id, server_id, status, response_time_ms, status_code, ssl_expires_at, message, checked_at) VALUES (?,?,?,?,?,?,?,?,?)',
            [(int) $check['id'], (int) $check['user_id'], (int) $check['server_id'], $status, (int) $probe['response_time_ms'], $statusCode, $sslExpiresAt, $message, now()]
        );

        if ($status === 'down') {
            $this->createAlert($check, 'danger', '服务探针异常：' . $check['name'], $message);
        } elseif ($sslExpiresAt && strtotime($sslExpiresAt) <= time() + 7 * 86400) {
            $this->createAlert($check, 'warning', 'SSL 证书即将过期：' . $check['name'], '证书到期时间：' . $sslExpiresAt);
        }

        return [
            'id' => (int) $check['id'],
            'name' => $check['name'],
            'type' => $check['type'],
            'status' => $status,
            'message' => $message,
            'response_time_ms' => (int) $probe['response_time_ms'],
            'status_code' => $statusCode,
            'ssl_expires_at' => $sslExpiresAt,
        ];
    }

    public function testPayload(array $payload)
    {
        return $this->run($payload);
    }

    protected function run(array $check)
    {
        $type = isset($check['type']) ? $check['type'] : 'http';
        if ($type === 'tcp') {
            return $this->checkTcp($check);
        }
        if ($type === 'ssl') {
            return $this->checkSsl($check);
        }
        return $this->checkHttp($check);
    }

    protected function checkHttp(array $check)
    {
        $url = trim((string) $check['target']);
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
            throw new \RuntimeException('HTTP 检测目标必须是完整 http:// 或 https:// 地址。');
        }
        $this->assertPublicHost($parts['host']);

        $timeout = $this->timeout($check);
        $method = strtoupper((string) (isset($check['method']) ? $check['method'] : 'HEAD'));
        $method = $method === 'GET' ? 'GET' : 'HEAD';
        $keyword = trim((string) (isset($check['keyword']) ? $check['keyword'] : ''));
        if ($keyword !== '') {
            $method = 'GET';
        }

        $start = microtime(true);
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_NOBODY, $method === 'HEAD');
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_USERAGENT, 'BMTOOLS-ServiceProbe/1.0');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            $body = curl_exec($ch);
            $error = curl_error($ch);
            $statusCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $responseTime = (int) round((microtime(true) - $start) * 1000);
            curl_close($ch);
            if ($body === false) {
                return $this->probeResult(false, $responseTime, 'HTTP 请求失败：' . $error, $statusCode);
            }
        } else {
            $context = stream_context_create([
                'http' => [
                    'method' => $method,
                    'timeout' => $timeout,
                    'ignore_errors' => true,
                    'header' => "User-Agent: BMTOOLS-ServiceProbe/1.0\r\n",
                ],
                'ssl' => [
                    'verify_peer' => true,
                    'verify_peer_name' => true,
                ],
            ]);
            $body = @file_get_contents($url, false, $context);
            $responseTime = (int) round((microtime(true) - $start) * 1000);
            $statusCode = $this->statusCodeFromHeaders(isset($http_response_header) ? $http_response_header : []);
            if ($body === false && $statusCode === 0) {
                return $this->probeResult(false, $responseTime, 'HTTP 请求失败，请检查域名、网络或证书。', 0);
            }
        }

        $expected = trim((string) (isset($check['expected_status']) ? $check['expected_status'] : '200-399'));
        if (!$this->statusMatches($statusCode, $expected)) {
            return $this->probeResult(false, $responseTime, '状态码 ' . $statusCode . ' 不符合预期 ' . ($expected ?: '200-399') . '。', $statusCode);
        }
        if ($keyword !== '' && strpos((string) $body, $keyword) === false) {
            return $this->probeResult(false, $responseTime, '页面可访问，但没有找到关键词：' . $keyword, $statusCode);
        }
        return $this->probeResult(true, $responseTime, 'HTTP 检测通过，状态码 ' . $statusCode . '。', $statusCode);
    }

    protected function checkTcp(array $check)
    {
        $host = $this->host($check);
        $port = $this->port($check, 80);
        $this->assertPublicHost($host);
        $timeout = $this->timeout($check);
        $start = microtime(true);
        $errno = 0;
        $errstr = '';
        $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
        $responseTime = (int) round((microtime(true) - $start) * 1000);
        if (!$fp) {
            return $this->probeResult(false, $responseTime, 'TCP 端口不可达：' . ($errstr ?: ('错误码 ' . $errno)), null);
        }
        fclose($fp);
        return $this->probeResult(true, $responseTime, 'TCP 端口可达：' . $host . ':' . $port, null);
    }

    protected function checkSsl(array $check)
    {
        $host = $this->host($check);
        $port = $this->port($check, 443);
        $this->assertPublicHost($host);
        $timeout = $this->timeout($check);
        $context = stream_context_create([
            'ssl' => [
                'capture_peer_cert' => true,
                'verify_peer' => true,
                'verify_peer_name' => true,
                'SNI_enabled' => true,
                'peer_name' => $host,
            ],
        ]);
        $start = microtime(true);
        $client = @stream_socket_client('ssl://' . $host . ':' . $port, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);
        $responseTime = (int) round((microtime(true) - $start) * 1000);
        if (!$client) {
            return $this->probeResult(false, $responseTime, 'SSL 连接失败：' . ($errstr ?: ('错误码 ' . $errno)), null);
        }
        $params = stream_context_get_params($client);
        fclose($client);
        if (empty($params['options']['ssl']['peer_certificate'])) {
            return $this->probeResult(false, $responseTime, 'SSL 连接成功，但未读取到证书。', null);
        }
        if (!function_exists('openssl_x509_parse')) {
            return $this->probeResult(false, $responseTime, '当前 PHP 未启用 OpenSSL，无法解析 SSL 证书。', null);
        }
        $cert = openssl_x509_parse($params['options']['ssl']['peer_certificate']);
        if (!$cert || empty($cert['validTo_time_t'])) {
            return $this->probeResult(false, $responseTime, 'SSL 证书解析失败。', null);
        }
        $expiresAt = date('Y-m-d H:i:s', (int) $cert['validTo_time_t']);
        if ((int) $cert['validTo_time_t'] <= time()) {
            return $this->probeResult(false, $responseTime, 'SSL 证书已过期：' . $expiresAt, null, $expiresAt);
        }
        $days = floor(((int) $cert['validTo_time_t'] - time()) / 86400);
        return $this->probeResult(true, $responseTime, 'SSL 证书有效，剩余约 ' . $days . ' 天。', null, $expiresAt);
    }

    protected function probeResult($success, $responseTime, $message, $statusCode = null, $sslExpiresAt = null)
    {
        return [
            'success' => (bool) $success,
            'status' => $success ? 'up' : 'down',
            'response_time_ms' => max(0, (int) $responseTime),
            'message' => $message,
            'status_code' => $statusCode,
            'ssl_expires_at' => $sslExpiresAt,
        ];
    }

    protected function statusCodeFromHeaders(array $headers)
    {
        $status = 0;
        foreach ($headers as $header) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $header, $m)) {
                $status = (int) $m[1];
            }
        }
        return $status;
    }

    protected function statusMatches($status, $expected)
    {
        $status = (int) $status;
        $expected = trim((string) $expected);
        if ($expected === '') {
            $expected = '200-399';
        }
        foreach (preg_split('/\s*,\s*/', $expected) as $part) {
            if ($part === '') {
                continue;
            }
            if (preg_match('/^(\d{3})-(\d{3})$/', $part, $m) && $status >= (int) $m[1] && $status <= (int) $m[2]) {
                return true;
            }
            if (preg_match('/^(\d)x{2}$/i', $part, $m) && (int) floor($status / 100) === (int) $m[1]) {
                return true;
            }
            if (ctype_digit($part) && $status === (int) $part) {
                return true;
            }
        }
        return false;
    }

    protected function host(array $check)
    {
        $target = trim((string) $check['target']);
        $parts = parse_url(strpos($target, '://') === false ? 'tcp://' . $target : $target);
        $host = isset($parts['host']) ? $parts['host'] : $target;
        return trim($host, " \t\n\r\0\x0B[]");
    }

    protected function port(array $check, $default)
    {
        $port = isset($check['port']) ? (int) $check['port'] : 0;
        if ($port > 0 && $port <= 65535) {
            return $port;
        }
        $target = trim((string) $check['target']);
        $parts = parse_url(strpos($target, '://') === false ? 'tcp://' . $target : $target);
        if (!empty($parts['port'])) {
            return (int) $parts['port'];
        }
        return (int) $default;
    }

    protected function timeout(array $check)
    {
        return max(2, min(15, (int) (isset($check['timeout_seconds']) ? $check['timeout_seconds'] : 5)));
    }

    protected function assertPublicHost($host)
    {
        $host = trim(strtolower((string) $host), " \t\n\r\0\x0B[]");
        if ($host === '' || in_array($host, ['localhost', 'localhost.localdomain'], true) || substr($host, -6) === '.local') {
            throw new \RuntimeException('检测目标不能是本机、localhost 或 .local 内网地址。');
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            if (!$this->isPublicIp($host)) {
                throw new \RuntimeException('检测目标不能是内网、回环、保留地址或云厂商元数据地址。');
            }
            return;
        }
        $ips = @gethostbynamel($host);
        if (is_array($ips)) {
            foreach ($ips as $ip) {
                if (!$this->isPublicIp($ip)) {
                    throw new \RuntimeException('域名解析到内网或保留地址，已阻止检测：' . $ip);
                }
            }
        }
    }

    protected function isPublicIp($ip)
    {
        if ($ip === '169.254.169.254') {
            return false;
        }
        return (bool) filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }

    protected function createAlert(array $check, $level, $title, $content)
    {
        $metric = 'probe_' . (int) $check['id'];
        $recent = Database::fetch(
            'SELECT id FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ? AND metric = ? AND status <> ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE) LIMIT 1',
            [(int) $check['server_id'], $metric, 'resolved']
        );
        if ($recent) {
            return;
        }
        Database::execute(
            'INSERT INTO ' . Database::table('monitor_alerts') . ' (user_id, server_id, level, metric, title, content, status, created_at) VALUES (?,?,?,?,?,?,?,?)',
            [(int) $check['user_id'], (int) $check['server_id'], $level, $metric, $title, $content, 'unread', now()]
        );
        $notifier = new NotificationService();
        $notifier->send((int) $check['user_id'], 'monitor_alert', $title, $content);
        $notifier->sendEmail((int) $check['user_id'], $title, $content);
        (new AlertWebhookService())->sendMonitorAlert((int) $check['user_id'], $title, $content, [
            'server_name' => isset($check['name']) ? $check['name'] : (isset($check['server_name']) ? $check['server_name'] : ''),
            'metric' => $metric,
            'level' => $level,
            'source' => '服务探测',
        ]);
    }
}
