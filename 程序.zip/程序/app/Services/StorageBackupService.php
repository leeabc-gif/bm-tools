<?php
namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Models\StorageDriver;
use App\Services\Storage\StorageManager;

class StorageBackupService
{
    public function backupUploadedFile(array $fileRecord, $localPath, $objectKey, $mime = '')
    {
        if (empty($fileRecord['id']) || empty($fileRecord['storage_id']) || !is_file($localPath)) {
            return ['total' => 0, 'success' => 0, 'failed' => 0, 'skipped' => 0, 'strict_failed' => false];
        }
        if (!$this->schemaReady()) {
            Logger::error('Storage backup skipped because schema is not ready.', ['file_id' => $fileRecord['id']]);
            return ['total' => 0, 'success' => 0, 'failed' => 0, 'skipped' => 0, 'strict_failed' => false];
        }

        $primaryStorageId = (int) $fileRecord['storage_id'];
        $fileType = isset($fileRecord['file_type']) ? (string) $fileRecord['file_type'] : 'file';
        $policies = $this->activePolicies($primaryStorageId, $fileType);
        $summary = ['total' => 0, 'success' => 0, 'failed' => 0, 'skipped' => 0, 'strict_failed' => false];
        $strictFailures = [];
        $uploadedForCleanup = [];

        foreach ($policies as $policy) {
            $backupStorageIds = $this->policyStorageIds($policy);
            foreach ($backupStorageIds as $storageId) {
                $summary['total']++;
                $result = $this->attemptBackupTarget($fileRecord, $policy, $storageId, $localPath, $objectKey, $mime);
                if ($result['status'] === 'success') {
                    $uploadedForCleanup[] = ['storage_id' => $storageId, 'object_key' => $result['object_key']];
                    $summary['success']++;
                } elseif ($result['status'] === 'skipped') {
                    $summary['skipped']++;
                } else {
                    $summary['failed']++;
                    if ($this->isStrict($policy)) {
                        $strictFailures[] = $policy['name'] . ' -> storage #' . $storageId . ': ' . $result['message'];
                    }
                }
            }
        }

        if ($strictFailures) {
            $summary['strict_failed'] = true;
            $this->cleanupUploadedBackups($uploadedForCleanup);
            throw new \RuntimeException('多存储备份严格模式失败：' . implode('；', array_slice($strictFailures, 0, 3)));
        }

        return $summary;
    }

    public function activePolicies($primaryStorageId, $fileType)
    {
        if (!$this->schemaReady()) {
            return [];
        }
        return Database::fetchAll(
            'SELECT * FROM ' . Database::table('storage_backup_policies') . "
             WHERE is_enabled = 1
               AND (primary_storage_id = 0 OR primary_storage_id = ?)
               AND (file_scope = 'all' OR file_scope = ?)
             ORDER BY sort_order ASC, id ASC",
            [(int) $primaryStorageId, (string) $fileType]
        );
    }

    public function backfillLocalFiles(array $options = [])
    {
        if (!$this->schemaReady()) {
            throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入数据库巡检执行一键修复。');
        }

        $limit = isset($options['limit']) ? (int) $options['limit'] : 20;
        $limit = max(1, min(200, $limit));
        $policyId = isset($options['policy_id']) ? max(0, (int) $options['policy_id']) : 0;
        $targetStorageId = isset($options['target_storage_id']) ? max(0, (int) $options['target_storage_id']) : 0;

        $summary = [
            'scanned' => 0,
            'targets' => 0,
            'success' => 0,
            'failed' => 0,
            'skipped' => 0,
            'already_success' => 0,
            'unreadable' => 0,
            'no_policy' => 0,
            'errors' => [],
        ];

        $files = $this->backfillCandidateFiles($options, $limit);
        foreach ($files as $file) {
            $summary['scanned']++;
            $source = $this->localSourcePath([
                'primary_storage_id' => isset($file['storage_id']) ? (int) $file['storage_id'] : 0,
                'primary_path' => isset($file['file_path']) ? $file['file_path'] : '',
            ]);
            if ($source === '') {
                $summary['unreadable']++;
                continue;
            }

            $policies = $this->activePolicies((int) $file['storage_id'], (string) $file['file_type']);
            if ($policyId > 0) {
                $policies = array_values(array_filter($policies, function ($policy) use ($policyId) {
                    return (int) $policy['id'] === $policyId;
                }));
            }
            if (!$policies) {
                $summary['no_policy']++;
                continue;
            }

            $primaryStorage = [
                'type' => isset($file['primary_storage_type']) ? $file['primary_storage_type'] : 'local',
                'prefix' => isset($file['primary_prefix']) ? $file['primary_prefix'] : '',
            ];
            $objectKey = $this->backupObjectKeyForFile($file, $primaryStorage);
            $fileRecord = [
                'id' => (int) $file['id'],
                'user_id' => isset($file['user_id']) ? (int) $file['user_id'] : 0,
                'storage_id' => (int) $file['storage_id'],
                'file_type' => (string) $file['file_type'],
                'file_path' => (string) $file['file_path'],
                'file_url' => isset($file['file_url']) ? (string) $file['file_url'] : '',
            ];
            $mime = !empty($file['mime_type']) ? (string) $file['mime_type'] : 'application/octet-stream';

            foreach ($policies as $policy) {
                foreach ($this->policyStorageIds($policy) as $storageId) {
                    if ($targetStorageId > 0 && $storageId !== $targetStorageId) {
                        continue;
                    }
                    if ($this->hasSuccessfulBackup((int) $file['id'], $storageId, (int) $policy['id'])) {
                        $summary['already_success']++;
                        $summary['skipped']++;
                        continue;
                    }

                    $summary['targets']++;
                    $result = $this->attemptBackupTarget($fileRecord, $policy, $storageId, $source, $objectKey, $mime);
                    if ($result['status'] === 'success') {
                        $summary['success']++;
                    } elseif ($result['status'] === 'skipped') {
                        $summary['skipped']++;
                    } else {
                        $summary['failed']++;
                        if (count($summary['errors']) < 5) {
                            $summary['errors'][] = 'File #' . $file['id'] . ' -> storage #' . $storageId . ': ' . $result['message'];
                        }
                    }
                }
            }
        }

        return $summary;
    }

    public function retryFailedBackups(array $options = [])
    {
        if (!$this->schemaReady()) {
            throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入数据库巡检执行一键修复。');
        }

        $limit = isset($options['limit']) ? (int) $options['limit'] : 20;
        $limit = max(1, min(100, $limit));
        $where = ["b.status = 'failed'"];
        $params = [];

        if (!empty($options['policy_id'])) {
            $where[] = 'b.policy_id = ?';
            $params[] = (int) $options['policy_id'];
        }
        if (!empty($options['storage_id'])) {
            $where[] = 'b.storage_id = ?';
            $params[] = (int) $options['storage_id'];
        }
        if (!empty($options['file_scope']) && in_array($options['file_scope'], ['image', 'file'], true)) {
            $where[] = 'f.file_type = ?';
            $params[] = (string) $options['file_scope'];
        }

        $rows = Database::fetchAll(
            'SELECT b.id
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY b.updated_at ASC, b.id ASC' . Database::limitClause($limit, 1, 100),
            $params
        );

        $summary = ['total' => count($rows), 'success' => 0, 'failed' => 0, 'errors' => []];
        foreach ($rows as $row) {
            try {
                $this->retryBackup((int) $row['id']);
                $summary['success']++;
            } catch (\Throwable $e) {
                $summary['failed']++;
                if (count($summary['errors']) < 5) {
                    $summary['errors'][] = 'Task #' . $row['id'] . ': ' . $this->cleanError($e->getMessage());
                }
            }
        }

        return $summary;
    }

    public function retryBackup($backupId)
    {
        if (!$this->schemaReady()) {
            throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入数据库巡检执行一键修复。');
        }
        $row = Database::fetch(
            'SELECT b.*, f.storage_id AS primary_storage_id, f.file_path AS primary_path, f.file_url AS primary_url, f.file_type, f.mime_type, f.original_name
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             WHERE b.id = ? LIMIT 1',
            [(int) $backupId]
        );
        if (!$row || empty($row['file_id'])) {
            throw new \RuntimeException('备份任务不存在或源文件记录已删除。');
        }
        $source = $this->localSourcePath($row);
        if ($source === '') {
            throw new \RuntimeException('当前源文件不在本地可读路径，暂不能后台重试。请重新上传该文件，或把主存储设为本地后再重试。');
        }
        $storage = $this->enabledStorage((int) $row['storage_id']);
        if (!$storage) {
            throw new \RuntimeException('备份目标存储不存在或已停用。');
        }

        $mime = !empty($row['mime_type']) ? $row['mime_type'] : 'application/octet-stream';
        $objectKey = !empty($row['object_key']) ? $row['object_key'] : $row['primary_path'];
        try {
            $this->markBackup($row, 'pending', $objectKey, '', '');
            $result = StorageManager::make($storage)->upload($source, $objectKey, ['mime' => $mime]);
            $path = isset($result['path']) ? (string) $result['path'] : (string) $objectKey;
            $url = isset($result['url']) ? (string) $result['url'] : '';
            $this->markBackup($row, 'success', $path, $url, '');
            return ['success' => true, 'message' => '备份重试成功。', 'url' => $url];
        } catch (\Throwable $e) {
            $message = $this->cleanError($e->getMessage());
            $this->markBackup($row, 'failed', $objectKey, '', $message);
            throw new \RuntimeException('备份重试失败：' . $message);
        }
    }

    public function deleteBackupsForFile(array $file)
    {
        if (empty($file['id'])) {
            return;
        }
        if (!$this->schemaReady()) {
            Logger::error('Storage backup delete skipped because schema is not ready.', ['file_id' => $file['id']]);
            return;
        }
        $rows = Database::fetchAll(
            'SELECT * FROM ' . Database::table('file_storage_backups') . " WHERE file_id = ? AND status = 'success'",
            [(int) $file['id']]
        );
        foreach ($rows as $row) {
            try {
                $storage = (new StorageDriver())->find((int) $row['storage_id']);
                if ($storage) {
                    StorageManager::make($storage)->delete($row['object_key']);
                }
                Database::execute(
                    'UPDATE ' . Database::table('file_storage_backups') . ' SET status = ?, updated_at = ? WHERE id = ?',
                    ['deleted', now(), $row['id']]
                );
            } catch (\Throwable $e) {
                Logger::error('Storage backup delete failed: ' . $e->getMessage(), [
                    'file_id' => $file['id'],
                    'backup_id' => $row['id'],
                ]);
            }
        }
    }

    public function policyStorageIds(array $policy)
    {
        $raw = isset($policy['backup_storage_ids']) ? trim((string) $policy['backup_storage_ids']) : '';
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            $decoded = preg_split('/[,\s]+/', $raw);
        }
        $ids = [];
        foreach ($decoded as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        return array_values($ids);
    }

    public function policyStorageNames(array $policy, array $storages)
    {
        $map = [];
        foreach ($storages as $storage) {
            $map[(int) $storage['id']] = $storage['name'] . ' / ' . $storage['type'];
        }
        $names = [];
        foreach ($this->policyStorageIds($policy) as $id) {
            $names[] = isset($map[$id]) ? $map[$id] : ('#' . $id);
        }
        return $names;
    }

    protected function enabledStorage($storageId)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('storage_drivers') . ' WHERE id = ? AND is_enabled = 1 LIMIT 1',
            [(int) $storageId]
        );
    }

    protected function attemptBackupTarget(array $fileRecord, array $policy, $storageId, $localPath, $objectKey, $mime = '')
    {
        $primaryStorageId = isset($fileRecord['storage_id']) ? (int) $fileRecord['storage_id'] : 0;
        if ((int) $storageId === $primaryStorageId) {
            $message = 'Backup storage is same as primary storage.';
            $this->recordSkipped($fileRecord, $policy, $storageId, $objectKey, $message);
            return ['status' => 'skipped', 'message' => $message, 'object_key' => (string) $objectKey, 'url' => ''];
        }

        $storage = $this->enabledStorage($storageId);
        if (!$storage) {
            $message = 'Backup storage is missing or disabled.';
            $this->recordFailure($fileRecord, $policy, $storageId, $objectKey, $message);
            return ['status' => 'failed', 'message' => $message, 'object_key' => (string) $objectKey, 'url' => ''];
        }

        try {
            $this->recordPending($fileRecord, $policy, $storageId, $objectKey);
            $result = StorageManager::make($storage)->upload($localPath, $objectKey, ['mime' => $mime ?: 'application/octet-stream']);
            $path = isset($result['path']) ? (string) $result['path'] : (string) $objectKey;
            $url = isset($result['url']) ? (string) $result['url'] : '';
            $this->recordSuccess($fileRecord, $policy, $storageId, $path, $url);
            return ['status' => 'success', 'message' => '', 'object_key' => $path, 'url' => $url];
        } catch (\Throwable $e) {
            $message = $this->cleanError($e->getMessage());
            $this->recordFailure($fileRecord, $policy, $storageId, $objectKey, $message);
            Logger::error('Storage backup upload failed: ' . $message, [
                'file_id' => isset($fileRecord['id']) ? $fileRecord['id'] : null,
                'policy_id' => isset($policy['id']) ? $policy['id'] : null,
                'storage_id' => $storageId,
            ]);
            return ['status' => 'failed', 'message' => $message, 'object_key' => (string) $objectKey, 'url' => ''];
        }
    }

    protected function recordPending(array $fileRecord, array $policy, $storageId, $objectKey)
    {
        $this->upsertBackup($fileRecord, $policy, $storageId, $objectKey, '', 'pending', '');
    }

    protected function recordSuccess(array $fileRecord, array $policy, $storageId, $objectKey, $url)
    {
        $this->upsertBackup($fileRecord, $policy, $storageId, $objectKey, $url, 'success', '');
    }

    protected function recordFailure(array $fileRecord, array $policy, $storageId, $objectKey, $message)
    {
        $this->upsertBackup($fileRecord, $policy, $storageId, $objectKey, '', 'failed', $message);
    }

    protected function recordSkipped(array $fileRecord, array $policy, $storageId, $objectKey, $message)
    {
        $this->upsertBackup($fileRecord, $policy, $storageId, $objectKey, '', 'skipped', $message);
    }

    protected function upsertBackup(array $fileRecord, array $policy, $storageId, $objectKey, $url, $status, $message)
    {
        $attemptIncrement = $status === 'pending' ? 0 : 1;
        Database::execute(
            'INSERT INTO ' . Database::table('file_storage_backups') . '
             (file_id, storage_id, policy_id, object_key, file_url, status, error_message, attempts, last_attempt_at, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE object_key = VALUES(object_key), file_url = VALUES(file_url), status = VALUES(status),
                error_message = VALUES(error_message), attempts = attempts + ?, last_attempt_at = VALUES(last_attempt_at), updated_at = VALUES(updated_at)',
            [
                (int) $fileRecord['id'],
                (int) $storageId,
                (int) $policy['id'],
                (string) $objectKey,
                (string) $url,
                (string) $status,
                (string) $message,
                $attemptIncrement,
                now(),
                now(),
                now(),
                $attemptIncrement,
            ]
        );
    }

    protected function markBackup(array $row, $status, $objectKey, $url, $message)
    {
        $attemptIncrement = $status === 'pending' ? 0 : 1;
        Database::execute(
            'UPDATE ' . Database::table('file_storage_backups') . '
             SET status = ?, object_key = ?, file_url = ?, error_message = ?, attempts = attempts + ?, last_attempt_at = ?, updated_at = ?
             WHERE id = ?',
            [(string) $status, (string) $objectKey, (string) $url, (string) $message, $attemptIncrement, now(), now(), (int) $row['id']]
        );
    }

    protected function hasSuccessfulBackup($fileId, $storageId, $policyId)
    {
        return (bool) Database::fetch(
            'SELECT id FROM ' . Database::table('file_storage_backups') . " WHERE file_id = ? AND storage_id = ? AND policy_id = ? AND status = 'success' LIMIT 1",
            [(int) $fileId, (int) $storageId, (int) $policyId]
        );
    }

    protected function backfillCandidateFiles(array $options, $limit)
    {
        $where = ["s.type = 'local'"];
        $params = [];
        if (!empty($options['primary_storage_id'])) {
            $where[] = 'f.storage_id = ?';
            $params[] = (int) $options['primary_storage_id'];
        }
        if (!empty($options['file_scope']) && in_array($options['file_scope'], ['image', 'file'], true)) {
            $where[] = 'f.file_type = ?';
            $params[] = (string) $options['file_scope'];
        }

        $policyExists = "EXISTS (
            SELECT 1 FROM " . Database::table('storage_backup_policies') . " p
            WHERE p.is_enabled = 1
              AND (p.primary_storage_id = 0 OR p.primary_storage_id = f.storage_id)
              AND (p.file_scope = 'all' OR p.file_scope = f.file_type)";
        if (!empty($options['policy_id'])) {
            $policyExists .= ' AND p.id = ?';
            $params[] = (int) $options['policy_id'];
        }
        $policyExists .= ')';
        $where[] = $policyExists;

        return Database::fetchAll(
            'SELECT f.*, s.type AS primary_storage_type, s.prefix AS primary_prefix, COALESCE(sb.success_count, 0) AS backup_success_count
             FROM ' . Database::table('files') . ' f
             INNER JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id
             LEFT JOIN (
                SELECT file_id, COUNT(*) AS success_count
                FROM ' . Database::table('file_storage_backups') . '
                WHERE status = ?
                GROUP BY file_id
             ) sb ON sb.file_id = f.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY COALESCE(sb.success_count, 0) ASC, f.id DESC' . Database::limitClause($limit, 1, 200),
            array_merge(['success'], $params)
        );
    }

    protected function backupObjectKeyForFile(array $file, array $primaryStorage)
    {
        $path = ltrim(str_replace('\\', '/', isset($file['file_path']) ? (string) $file['file_path'] : ''), '/');
        if ($path === '') {
            $name = isset($file['file_name']) ? (string) $file['file_name'] : ('file-' . (isset($file['id']) ? (int) $file['id'] : time()));
            return 'file/' . date('Y/m/d') . '/' . basename($name);
        }

        if (isset($primaryStorage['type']) && $primaryStorage['type'] === 'local') {
            $prefix = $this->safeLocalPrefixForStorage($primaryStorage);
            if ($prefix !== '' && strpos($path, $prefix . '/') === 0) {
                $stripped = substr($path, strlen($prefix) + 1);
                if ($stripped !== '') {
                    return $stripped;
                }
            }
        }

        return $path;
    }

    protected function safeLocalPrefixForStorage(array $storage)
    {
        $prefix = trim(isset($storage['prefix']) && $storage['prefix'] ? $storage['prefix'] : 'uploads/files', '/');
        $prefix = str_replace('\\', '/', $prefix);
        $parts = [];
        foreach (explode('/', $prefix) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                continue;
            }
            $parts[] = preg_replace('/[^A-Za-z0-9_\-.]/', '-', $part);
        }
        if (!$parts || $parts[0] !== 'uploads') {
            array_unshift($parts, 'uploads');
        }
        return implode('/', $parts);
    }

    protected function isStrict(array $policy)
    {
        return isset($policy['failure_strategy']) && $policy['failure_strategy'] === 'strict';
    }

    protected function cleanupUploadedBackups(array $items)
    {
        foreach ($items as $item) {
            try {
                $storage = (new StorageDriver())->find((int) $item['storage_id']);
                if ($storage) {
                    StorageManager::make($storage)->delete($item['object_key']);
                }
            } catch (\Throwable $e) {
                Logger::error('Strict storage backup cleanup failed: ' . $e->getMessage(), $item);
            }
        }
    }

    protected function localSourcePath(array $row)
    {
        if (empty($row['primary_storage_id']) || empty($row['primary_path'])) {
            return '';
        }
        $storage = (new StorageDriver())->find((int) $row['primary_storage_id']);
        if (!$storage || $storage['type'] !== 'local') {
            return '';
        }
        $root = realpath(APP_ROOT . '/public');
        if ($root === false) {
            return '';
        }
        $path = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($row['primary_path'], '/'));
        $real = realpath($path);
        if ($real === false || strpos($real, $root) !== 0 || !is_file($real)) {
            return '';
        }
        return $real;
    }

    protected function cleanError($message)
    {
        return text_limit(trim(strip_tags((string) $message)), 360, '...');
    }

    protected function schemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureStorageBackupSchema();
        } catch (\Throwable $e) {
            Logger::error('Storage backup schema check failed: ' . $e->getMessage());
            return false;
        }
    }
}
