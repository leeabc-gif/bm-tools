<?php
namespace App\Services;

use App\Core\Database;

class SubsiteService
{
    public function enabled()
    {
        return (string) setting('subsite_enabled', '1') === '1';
    }

    public function requiresReview()
    {
        return (string) setting('subsite_requires_review', '0') === '1';
    }

    public function customDomainEnabled()
    {
        return (string) setting('subsite_custom_domain_enabled', '1') === '1';
    }

    public function suffixes()
    {
        $raw = (string) setting('subsite_domain_suffixes', '');
        $items = preg_split('/[\r\n,;]+/', $raw);
        $suffixes = [];
        foreach ($items as $item) {
            $host = $this->normalizeHost($item);
            if ($host !== '') {
                $suffixes[$host] = true;
            }
        }
        if (!$suffixes) {
            $publicHost = $this->normalizeHost(public_url('/'));
            if ($publicHost !== '') {
                $suffixes[$publicHost] = true;
            }
        }
        return array_keys($suffixes);
    }

    public function suffixText()
    {
        return implode("\n", $this->suffixes());
    }

    public function defaultSuffix()
    {
        $suffixes = $this->suffixes();
        return $suffixes ? $suffixes[0] : '';
    }

    public function cnameTarget()
    {
        $target = $this->normalizeHost(setting('subsite_cname_target', ''));
        if ($target !== '') {
            return $target;
        }
        return $this->defaultSuffix();
    }

    public function httpsMode()
    {
        $mode = (string) setting('subsite_https_mode', 'auto');
        return in_array($mode, ['auto', 'force', 'off'], true) ? $mode : 'auto';
    }

    public function domainConfigSummary()
    {
        $suffixes = $this->suffixes();
        $target = $this->cnameTarget();
        return [
            'enabled' => $this->enabled(),
            'requires_review' => $this->requiresReview(),
            'custom_domain_enabled' => $this->customDomainEnabled(),
            'suffixes' => $suffixes,
            'default_suffix' => $this->defaultSuffix(),
            'cname_target' => $target,
            'https_mode' => $this->httpsMode(),
            'public_scheme' => $this->publicScheme(),
            'wildcard_hint' => $suffixes && $target !== '' ? '*.' . $suffixes[0] . ' CNAME ' . $target : '',
            'custom_domain_hint' => $target !== '' ? 'CNAME ' . $target : '',
        ];
    }

    public function platformDomain($slug, $preferredSuffix = '')
    {
        $slug = $this->normalizeSlug($slug);
        $suffix = $this->normalizeHost($preferredSuffix);
        if ($suffix === '' || !in_array($suffix, $this->suffixes(), true)) {
            $suffix = $this->defaultSuffix();
        }
        return $slug !== '' && $suffix !== '' ? $slug . '.' . $suffix : '';
    }

    public function suffixFromPlatformDomain($domain)
    {
        $domain = $this->normalizeHost($domain);
        foreach ($this->suffixes() as $suffix) {
            if ($domain === $suffix || substr($domain, -strlen('.' . $suffix)) === '.' . $suffix) {
                return $suffix;
            }
        }
        return $this->defaultSuffix();
    }

    public function publicScheme()
    {
        $mode = $this->httpsMode();
        if ($mode === 'off') {
            return 'http';
        }
        if ($mode === 'force') {
            return 'https';
        }
        $configured = trim((string) setting('site_public_url', ''));
        if ($configured !== '') {
            $scheme = parse_url(preg_match('#^https?://#i', $configured) ? $configured : 'https://' . $configured, PHP_URL_SCHEME);
            if ($scheme === 'http' || $scheme === 'https') {
                return $scheme;
            }
        }
        return function_exists('bm_is_https_request') && bm_is_https_request() ? 'https' : 'http';
    }

    public function publicUrlFor(array $subsite, $preferCustom = true, $allowUnverifiedCustom = false)
    {
        $host = '';
        if ($preferCustom
            && !empty($subsite['custom_domain'])
            && ($allowUnverifiedCustom || !isset($subsite['custom_domain_status']) || $subsite['custom_domain_status'] === 'verified')
        ) {
            $host = $this->normalizeHost($subsite['custom_domain']);
        }
        if ($host === '') {
            $host = $this->normalizeHost(isset($subsite['platform_domain']) ? $subsite['platform_domain'] : '');
        }
        return $host !== '' ? $this->publicScheme() . '://' . $host : '';
    }

    public function normalizeSuffixList($value)
    {
        $items = preg_split('/[\r\n,;]+/', (string) $value);
        $suffixes = [];
        foreach ($items as $item) {
            $host = $this->normalizeHost($item);
            if ($host !== '') {
                $suffixes[$host] = true;
            }
        }
        return implode("\n", array_keys($suffixes));
    }

    public function normalizeHost($value)
    {
        $value = strtolower(trim((string) $value));
        if ($value === '') {
            return '';
        }
        $value = preg_replace('#^https?://#i', '', $value);
        $value = preg_replace('#/.*$#', '', $value);
        $value = preg_replace('/:\d+$/', '', $value);
        $value = trim($value, ". \t\r\n");
        if (strpos($value, '*.') === 0) {
            $value = substr($value, 2);
        }
        if (!$this->validDomain($value)) {
            return '';
        }
        return $value;
    }

    public function normalizeSlug($value)
    {
        $value = strtolower(trim((string) $value));
        $value = preg_replace('/[^a-z0-9-]+/', '-', $value);
        $value = trim($value, '-');
        $value = preg_replace('/-+/', '-', $value);
        return substr($value, 0, 40);
    }

    public function validateSlug($slug)
    {
        $slug = $this->normalizeSlug($slug);
        if ($slug === '' || strlen($slug) < 3) {
            return '分站标识至少需要 3 个字符。';
        }
        if (!preg_match('/^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$/', $slug)) {
            return '分站标识只能使用小写字母、数字和中划线，且不能以中划线开头或结尾。';
        }
        if (in_array($slug, $this->reservedSlugs(), true)) {
            return '该分站标识为系统保留，请更换。';
        }
        return '';
    }

    public function reservedSlugs()
    {
        $base = [
            'admin', 'api', 'app', 'assets', 'cdn', 'console', 'dashboard', 'dev', 'files',
            'help', 'home', 'img', 'install', 'login', 'logout', 'mail', 'netdisk', 'pay',
            'register', 'root', 'share', 'static', 'status', 'support', 'system', 'upload',
            'uploads', 'user', 'www',
        ];
        $custom = preg_split('/[\r\n,;]+/', (string) setting('subsite_reserved_slugs', ''));
        foreach ($custom as $item) {
            $slug = $this->normalizeSlug($item);
            if ($slug !== '') {
                $base[] = $slug;
            }
        }
        return array_values(array_unique($base));
    }

    public function packageLimit(array $user)
    {
        $default = max(0, (int) setting('subsite_default_limit', '1'));
        if (empty($user['package_id'])) {
            return $default;
        }
        try {
            $package = Database::fetch('SELECT allow_subsite, subsite_limit FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
            if (!$package) {
                return $default;
            }
            if (isset($package['allow_subsite']) && (int) $package['allow_subsite'] !== 1) {
                return 0;
            }
            $limit = isset($package['subsite_limit']) ? (int) $package['subsite_limit'] : $default;
            return $limit > 0 ? $limit : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    public function packageInfo(array $user)
    {
        $default = max(0, (int) setting('subsite_default_limit', '1'));
        if (empty($user['package_id'])) {
            return ['allow' => $default > 0, 'limit' => $default, 'name' => '默认权益'];
        }
        try {
            $package = Database::fetch('SELECT name, allow_subsite, subsite_limit FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
            if (!$package) {
                return ['allow' => $default > 0, 'limit' => $default, 'name' => '默认权益'];
            }
            $allow = !isset($package['allow_subsite']) || (int) $package['allow_subsite'] === 1;
            $limit = isset($package['subsite_limit']) ? (int) $package['subsite_limit'] : $default;
            $limit = $allow ? max(1, $limit) : 0;
            return ['allow' => $allow, 'limit' => $limit, 'name' => isset($package['name']) ? $package['name'] : '当前套餐'];
        } catch (\Throwable $e) {
            return ['allow' => $default > 0, 'limit' => $default, 'name' => '默认权益'];
        }
    }

    public function canCreate(array $user)
    {
        if (!$this->enabled()) {
            return [false, '主站暂未开放分站开通。'];
        }
        $limit = $this->packageLimit($user);
        if ($limit <= 0) {
            return [false, '当前套餐未包含分站权益，请升级套餐后开通。'];
        }
        $count = $this->countUserSubsites((int) $user['id']);
        if ($count >= $limit) {
            return [false, '当前套餐最多可开通 ' . $limit . ' 个分站。'];
        }
        return [true, ''];
    }

    public function countUserSubsites($userId)
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('subsites') . ' WHERE user_id = ?', [(int) $userId]);
        return $row ? (int) $row['c'] : 0;
    }

    public function userSubsites($userId)
    {
        return Database::fetchAll('SELECT * FROM ' . Database::table('subsites') . ' WHERE user_id = ? ORDER BY is_default DESC, id DESC', [(int) $userId]);
    }

    public function allSubsites($status = '', $keyword = '')
    {
        $where = [];
        $params = [];
        if ($status !== '' && in_array($status, ['pending', 'active', 'suspended', 'rejected'], true)) {
            $where[] = 's.status = ?';
            $params[] = $status;
        }
        if ($keyword !== '') {
            $where[] = '(s.name LIKE ? OR s.slug LIKE ? OR s.platform_domain LIKE ? OR s.custom_domain LIKE ? OR u.username LIKE ? OR u.email LIKE ?)';
            for ($i = 0; $i < 6; $i++) {
                $params[] = '%' . $keyword . '%';
            }
        }
        $sql = 'SELECT s.*, u.username, u.nickname, u.email FROM ' . Database::table('subsites') . ' s LEFT JOIN ' . Database::table('users') . ' u ON s.user_id = u.id';
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= " ORDER BY FIELD(s.status, 'pending', 'active', 'suspended', 'rejected'), s.id DESC LIMIT 500";
        return Database::fetchAll($sql, $params);
    }

    public function find($id)
    {
        return Database::fetch('SELECT * FROM ' . Database::table('subsites') . ' WHERE id = ? LIMIT 1', [(int) $id]);
    }

    public function findBySlug($slug)
    {
        return Database::fetch('SELECT s.*, u.username, u.nickname, u.email FROM ' . Database::table('subsites') . ' s LEFT JOIN ' . Database::table('users') . ' u ON s.user_id = u.id WHERE s.slug = ? LIMIT 1', [$this->normalizeSlug($slug)]);
    }

    public function findUserSubsite($id, $userId)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('subsites') . ' WHERE id = ? AND user_id = ? LIMIT 1',
            [(int) $id, (int) $userId]
        );
    }

    public function resolveByHost($host)
    {
        $host = $this->normalizeHost($host);
        if ($host === '' || $this->isMainHost($host)) {
            return null;
        }
        return Database::fetch(
            'SELECT s.*, u.username, u.nickname, u.email FROM ' . Database::table('subsites') . ' s
             LEFT JOIN ' . Database::table('users') . ' u ON s.user_id = u.id
             WHERE s.status = ? AND (s.platform_domain = ? OR (s.custom_domain = ? AND s.custom_domain_status = ?)) LIMIT 1',
            ['active', $host, $host, 'verified']
        );
    }

    public function resolveCurrentHost()
    {
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        if ($host === '') {
            return null;
        }
        return $this->resolveByHost($host);
    }

    public function saveForUser(array $user, array $payload, array $existing = null)
    {
        $userId = (int) $user['id'];
        $slug = $this->normalizeSlug(isset($payload['slug']) ? $payload['slug'] : '');
        $slugError = $this->validateSlug($slug);
        if ($slugError !== '') {
            throw new \RuntimeException($slugError);
        }
        $name = text_limit(trim((string) (isset($payload['name']) ? $payload['name'] : '')), 80);
        if ($name === '') {
            throw new \RuntimeException('请填写分站名称。');
        }
        $platformDomain = $this->platformDomain($slug, isset($payload['platform_suffix']) ? $payload['platform_suffix'] : '');
        if ($platformDomain === '') {
            throw new \RuntimeException('主站还没有配置分站域名后缀，请联系管理员。');
        }
        $customDomain = '';
        if ($this->customDomainEnabled()) {
            $customDomain = $this->normalizeHost(isset($payload['custom_domain']) ? $payload['custom_domain'] : '');
        }
        if ($customDomain !== '' && $this->isMainHost($customDomain)) {
            throw new \RuntimeException('自有域名不能填写主站域名。');
        }
        $id = $existing ? (int) $existing['id'] : 0;
        if ($this->domainInUse($platformDomain, $id) || ($customDomain !== '' && $this->domainInUse($customDomain, $id))) {
            throw new \RuntimeException('该分站标识或绑定域名已被使用。');
        }
        if (!$existing) {
            list($canCreate, $message) = $this->canCreate($user);
            if (!$canCreate) {
                throw new \RuntimeException($message);
            }
        }

        $status = $existing ? $existing['status'] : ($this->requiresReview() ? 'pending' : 'active');
        if ($existing && $existing['status'] === 'rejected') {
            $status = $this->requiresReview() ? 'pending' : 'active';
        }
        $domainStatus = $customDomain === '' ? 'none' : 'pending';
        if ($existing && $customDomain !== '' && $customDomain === (string) $existing['custom_domain']) {
            $domainStatus = $existing['custom_domain_status'];
        }
        $domainChanged = !$existing
            || $customDomain !== (string) (isset($existing['custom_domain']) ? $existing['custom_domain'] : '')
            || $platformDomain !== (string) (isset($existing['platform_domain']) ? $existing['platform_domain'] : '');

        $data = [
            'user_id' => $userId,
            'name' => $name,
            'slug' => $slug,
            'platform_domain' => $platformDomain,
            'custom_domain' => $customDomain,
            'custom_domain_status' => $domainStatus,
            'verification_token' => $existing && !empty($existing['verification_token']) ? $existing['verification_token'] : $this->verificationToken(),
            'title' => text_limit(trim((string) (isset($payload['title']) ? $payload['title'] : $name)), 120),
            'subtitle' => text_limit(trim((string) (isset($payload['subtitle']) ? $payload['subtitle'] : '')), 240),
            'logo' => $this->cleanUrl(isset($payload['logo']) ? $payload['logo'] : ''),
            'theme_color' => $this->themeColor(isset($payload['theme_color']) ? $payload['theme_color'] : ''),
            'hero_title' => text_limit(trim((string) (isset($payload['hero_title']) ? $payload['hero_title'] : '')), 160),
            'hero_description' => text_limit(trim((string) (isset($payload['hero_description']) ? $payload['hero_description'] : '')), 360),
            'announcement' => text_limit(trim((string) (isset($payload['announcement']) ? $payload['announcement'] : '')), 500),
            'contact_email' => $this->contactEmail(isset($payload['contact_email']) ? $payload['contact_email'] : ''),
            'icp_text' => text_limit(trim((string) (isset($payload['icp_text']) ? $payload['icp_text'] : '')), 120),
            'status' => $status,
            'is_default' => !empty($payload['is_default']) ? 1 : 0,
            'updated_at' => now(),
        ];
        if ($domainChanged) {
            $data['domain_check_result'] = '';
            $data['domain_checked_at'] = null;
        }

        Database::begin();
        try {
            if (!empty($data['is_default'])) {
                Database::execute('UPDATE ' . Database::table('subsites') . ' SET is_default = 0 WHERE user_id = ?', [$userId]);
            }
            if ($id > 0) {
                $sets = [];
                foreach ($data as $key => $value) {
                    if ($key === 'user_id') {
                        continue;
                    }
                    $sets[] = $key . ' = ?';
                }
                $params = [];
                foreach ($data as $key => $value) {
                    if ($key !== 'user_id') {
                        $params[] = $value;
                    }
                }
                $params[] = $id;
                $params[] = $userId;
                Database::execute('UPDATE ' . Database::table('subsites') . ' SET ' . implode(',', $sets) . ' WHERE id = ? AND user_id = ?', $params);
            } else {
                $data['created_at'] = now();
                $keys = array_keys($data);
                Database::execute(
                    'INSERT INTO ' . Database::table('subsites') . ' (' . implode(',', $keys) . ') VALUES (' . implode(',', array_fill(0, count($keys), '?')) . ')',
                    array_values($data)
                );
                $id = (int) Database::lastInsertId();
                if ($this->countUserSubsites($userId) === 1) {
                    Database::execute('UPDATE ' . Database::table('subsites') . ' SET is_default = 1 WHERE id = ?', [$id]);
                }
            }
            Database::commit();
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
        return $id;
    }

    public function saveDomainDiagnostic($id, array $diagnostic)
    {
        $json = json_encode($diagnostic, JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            $json = '{}';
        }
        return Database::execute(
            'UPDATE ' . Database::table('subsites') . ' SET domain_check_result = ?, domain_checked_at = ?, updated_at = ? WHERE id = ?',
            [$json, now(), now(), (int) $id]
        );
    }

    public function decodeDomainDiagnostic(array $subsite)
    {
        $raw = isset($subsite['domain_check_result']) ? trim((string) $subsite['domain_check_result']) : '';
        if ($raw === '') {
            return null;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }

    public function domainInUse($domain, $excludeId = 0)
    {
        $domain = $this->normalizeHost($domain);
        if ($domain === '') {
            return false;
        }
        $row = Database::fetch(
            'SELECT id FROM ' . Database::table('subsites') . ' WHERE (platform_domain = ? OR custom_domain = ?) AND id <> ? LIMIT 1',
            [$domain, $domain, (int) $excludeId]
        );
        return (bool) $row;
    }

    public function setAdminStatus($id, $status, $domainStatus = null, $remark = '')
    {
        if (!in_array($status, ['pending', 'active', 'suspended', 'rejected'], true)) {
            throw new \RuntimeException('分站状态不正确。');
        }
        $sets = ['status = ?', 'admin_remark = ?', 'updated_at = ?'];
        $params = [$status, text_limit(trim((string) $remark), 255), now()];
        if ($domainStatus !== null && in_array($domainStatus, ['none', 'pending', 'verified', 'failed'], true)) {
            $sets[] = 'custom_domain_status = ?';
            $params[] = $domainStatus;
        }
        $params[] = (int) $id;
        return Database::execute('UPDATE ' . Database::table('subsites') . ' SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }

    public function deleteForUser($id, $userId)
    {
        Database::begin();
        try {
            Database::execute('DELETE FROM ' . Database::table('subsite_access_logs') . ' WHERE subsite_id = ? AND user_id = ?', [(int) $id, (int) $userId]);
            $affected = Database::execute('DELETE FROM ' . Database::table('subsites') . ' WHERE id = ? AND user_id = ?', [(int) $id, (int) $userId]);
            Database::commit();
            return $affected > 0;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function deleteByAdmin($id)
    {
        $subsite = $this->find($id);
        if (!$subsite) {
            return false;
        }
        Database::begin();
        try {
            Database::execute('DELETE FROM ' . Database::table('subsite_access_logs') . ' WHERE subsite_id = ?', [(int) $id]);
            Database::execute('DELETE FROM ' . Database::table('subsites') . ' WHERE id = ?', [(int) $id]);
            Database::commit();
            return true;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function publicData(array $subsite)
    {
        $userId = (int) $subsite['user_id'];
        $files = Database::fetchAll(
            'SELECT id, original_name, file_type, file_size, file_url, thumbnail_url, created_at
             FROM ' . Database::table('files') . '
             WHERE user_id = ? AND is_public = 1
             ORDER BY id DESC LIMIT 12',
            [$userId]
        );
        $repositories = Database::fetchAll(
            'SELECT id, title, slug, description, cover_image, view_count, download_count, created_at
             FROM ' . Database::table('file_repositories') . '
             WHERE user_id = ? AND status = 1 AND admin_status = 1
             ORDER BY id DESC LIMIT 8',
            [$userId]
        );
        $stats = [
            'files' => $this->safeCount('files', 'user_id = ? AND is_public = 1', [$userId]),
            'images' => $this->safeCount('files', 'user_id = ? AND is_public = 1 AND file_type = \'image\'', [$userId]),
            'repositories' => $this->safeCount('file_repositories', 'user_id = ? AND status = 1 AND admin_status = 1', [$userId]),
            'servers' => $this->safeCount('monitor_servers', 'user_id = ? AND monitor_type IN (\'ssh\',\'agent\')', [$userId]),
            'views' => isset($subsite['view_count']) ? (int) $subsite['view_count'] : 0,
        ];
        return ['files' => $files, 'repositories' => $repositories, 'stats' => $stats];
    }

    public function logView(array $subsite)
    {
        try {
            Database::execute(
                'UPDATE ' . Database::table('subsites') . ' SET view_count = view_count + 1, last_viewed_at = ? WHERE id = ?',
                [now(), (int) $subsite['id']]
            );
            Database::execute(
                'INSERT INTO ' . Database::table('subsite_access_logs') . ' (subsite_id, user_id, host, path, ip, user_agent, referer, created_at) VALUES (?,?,?,?,?,?,?,?)',
                [
                    (int) $subsite['id'],
                    (int) $subsite['user_id'],
                    isset($_SERVER['HTTP_HOST']) ? text_limit($_SERVER['HTTP_HOST'], 180) : '',
                    isset($_SERVER['REQUEST_URI']) ? text_limit($_SERVER['REQUEST_URI'], 500) : '',
                    isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
                    isset($_SERVER['HTTP_USER_AGENT']) ? text_limit($_SERVER['HTTP_USER_AGENT'], 255) : '',
                    isset($_SERVER['HTTP_REFERER']) ? text_limit($_SERVER['HTTP_REFERER'], 500) : '',
                    now(),
                ]
            );
        } catch (\Throwable $e) {
            // View logging must never block the public subsite page.
        }
    }

    public function recentAccessLogs($limit = 20, $userId = 0)
    {
        $limit = max(1, min(100, (int) $limit));
        $where = '';
        $params = [];
        if ((int) $userId > 0) {
            $where = ' WHERE l.user_id = ?';
            $params[] = (int) $userId;
        }
        return Database::fetchAll(
            'SELECT l.*, s.name AS subsite_name, s.platform_domain, s.custom_domain, u.username, u.email
             FROM ' . Database::table('subsite_access_logs') . ' l
             LEFT JOIN ' . Database::table('subsites') . ' s ON s.id = l.subsite_id
             LEFT JOIN ' . Database::table('users') . ' u ON u.id = l.user_id' .
            $where .
            ' ORDER BY l.id DESC' . Database::limitClause($limit, 1, 100),
            $params
        );
    }

    public function domainDiagnostic(array $subsite)
    {
        $platformHost = $this->normalizeHost(isset($subsite['platform_domain']) ? $subsite['platform_domain'] : '');
        $customHost = $this->normalizeHost(isset($subsite['custom_domain']) ? $subsite['custom_domain'] : '');
        $token = isset($subsite['verification_token']) ? (string) $subsite['verification_token'] : '';
        $checks = [];

        $platformDns = $this->dnsSummary($platformHost);
        $platformResolved = !empty($platformDns['a']) || !empty($platformDns['aaaa']) || !empty($platformDns['cname']);
        $checks[] = [
            'key' => 'platform_dns',
            'label' => '平台域名解析',
            'status' => $platformResolved ? 'ok' : ($platformHost === '' ? 'bad' : 'warn'),
            'message' => $platformResolved
                ? '平台分站域名已解析：' . $this->dnsHumanText($platformDns)
                : ($platformHost === '' ? '平台域名为空，请先配置分站域名后缀。' : '暂未查询到平台域名解析，请检查泛解析或 DNS 是否生效。'),
        ];

        if ($customHost === '') {
            $checks[] = [
                'key' => 'custom_domain',
                'label' => '自有域名',
                'status' => 'soft',
                'message' => '该分站未绑定自有域名，当前使用平台域名访问。',
            ];
            return [
                'ok' => $platformResolved,
                'custom_domain_status' => 'none',
                'checked_at' => now(),
                'host' => $platformHost,
                'public_url' => $this->publicUrlFor($subsite, false),
                'checks' => $checks,
            ];
        }

        $customDns = $this->dnsSummary($customHost);
        $customResolved = !empty($customDns['a']) || !empty($customDns['aaaa']) || !empty($customDns['cname']);
        $cnameTarget = $this->cnameTarget();
        $expectedTarget = $cnameTarget !== '' ? $cnameTarget : $platformHost;
        $cnameMatched = $this->cnameMatches($customDns, $expectedTarget) || $this->cnameMatches($customDns, $platformHost);
        $checks[] = [
            'key' => 'custom_dns',
            'label' => '自有域名解析',
            'status' => $customResolved ? ($cnameMatched ? 'ok' : 'warn') : 'bad',
            'message' => $customResolved
                ? ($cnameMatched ? 'CNAME 已指向接入目标：' . $expectedTarget : '已查询到解析记录，但未确认 CNAME 指向接入目标 ' . $expectedTarget . '：' . $this->dnsHumanText($customDns))
                : '未查询到自有域名 A/AAAA/CNAME 解析，请先在域名 DNS 控制台完成解析。',
        ];

        $txt = $this->verificationTxtCheck($customHost, $token);
        $checks[] = [
            'key' => 'txt_verify',
            'label' => 'TXT 所有权验证',
            'status' => $txt['ok'] ? 'ok' : 'warn',
            'message' => $txt['ok']
                ? '已找到验证 TXT：' . $token
                : '未找到验证 TXT。建议添加 TXT 记录：主机记录 @ 或 _bmtools，记录值 ' . $token,
        ];

        $route = $this->httpProbe($customHost);
        $checks[] = [
            'key' => 'http_route',
            'label' => '访问链路',
            'status' => $route['ok'] ? 'ok' : 'warn',
            'message' => $route['message'],
        ];

        $verified = $txt['ok'] && ($route['ok'] || $cnameMatched);
        $status = $verified ? 'verified' : ($customResolved ? 'pending' : 'failed');

        return [
            'ok' => $platformResolved && $customResolved && $verified,
            'custom_domain_status' => $status,
            'checked_at' => now(),
            'host' => $customHost,
            'public_url' => $this->publicUrlFor($subsite, true, true),
            'checks' => $checks,
        ];
    }

    public function statusLabel($status)
    {
        $map = [
            'pending' => '待审核',
            'active' => '已启用',
            'suspended' => '已停用',
            'rejected' => '已拒绝',
        ];
        return isset($map[$status]) ? $map[$status] : $status;
    }

    public function domainStatusLabel($status)
    {
        $map = [
            'none' => '未绑定',
            'pending' => '待验证',
            'verified' => '已验证',
            'failed' => '验证失败',
        ];
        return isset($map[$status]) ? $map[$status] : $status;
    }

    protected function safeCount($table, $where, array $params)
    {
        try {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table($table) . ' WHERE ' . $where, $params);
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function dnsSummary($host)
    {
        $host = $this->normalizeHost($host);
        $summary = ['a' => [], 'aaaa' => [], 'cname' => [], 'txt' => [], 'available' => function_exists('dns_get_record')];
        if ($host === '' || !function_exists('dns_get_record')) {
            return $summary;
        }
        $types = [
            'a' => defined('DNS_A') ? DNS_A : 1,
            'aaaa' => defined('DNS_AAAA') ? DNS_AAAA : 134217728,
            'cname' => defined('DNS_CNAME') ? DNS_CNAME : 16,
            'txt' => defined('DNS_TXT') ? DNS_TXT : 32768,
        ];
        foreach ($types as $key => $type) {
            $records = @dns_get_record($host, $type);
            if (!is_array($records)) {
                continue;
            }
            foreach ($records as $record) {
                if ($key === 'a' && !empty($record['ip'])) {
                    $summary['a'][] = $record['ip'];
                } elseif ($key === 'aaaa' && !empty($record['ipv6'])) {
                    $summary['aaaa'][] = $record['ipv6'];
                } elseif ($key === 'cname' && !empty($record['target'])) {
                    $summary['cname'][] = $this->normalizeHost($record['target']);
                } elseif ($key === 'txt') {
                    if (!empty($record['txt'])) {
                        $summary['txt'][] = (string) $record['txt'];
                    } elseif (!empty($record['entries']) && is_array($record['entries'])) {
                        $summary['txt'][] = implode('', $record['entries']);
                    }
                }
            }
        }
        foreach ($summary as $key => $values) {
            if (is_array($values)) {
                $summary[$key] = array_values(array_unique(array_filter($values)));
            }
        }
        return $summary;
    }

    protected function dnsHumanText(array $summary)
    {
        $parts = [];
        if (!empty($summary['a'])) {
            $parts[] = 'A ' . implode(', ', array_slice($summary['a'], 0, 3));
        }
        if (!empty($summary['aaaa'])) {
            $parts[] = 'AAAA ' . implode(', ', array_slice($summary['aaaa'], 0, 2));
        }
        if (!empty($summary['cname'])) {
            $parts[] = 'CNAME ' . implode(', ', array_slice($summary['cname'], 0, 2));
        }
        return $parts ? implode('；', $parts) : '暂无解析记录';
    }

    protected function cnameMatches(array $summary, $platformHost)
    {
        $platformHost = $this->normalizeHost($platformHost);
        if ($platformHost === '' || empty($summary['cname'])) {
            return false;
        }
        foreach ($summary['cname'] as $target) {
            if ($this->normalizeHost($target) === $platformHost) {
                return true;
            }
        }
        return false;
    }

    protected function verificationTxtCheck($host, $token)
    {
        $host = $this->normalizeHost($host);
        $token = trim((string) $token);
        if ($host === '' || $token === '') {
            return ['ok' => false, 'records' => []];
        }
        $records = [];
        foreach ([$host, '_bmtools.' . $host] as $txtHost) {
            $summary = $this->dnsSummary($txtHost);
            foreach ($summary['txt'] as $txt) {
                $records[] = $txt;
                if (strpos($txt, $token) !== false) {
                    return ['ok' => true, 'records' => $records];
                }
            }
        }
        return ['ok' => false, 'records' => $records];
    }

    protected function httpProbe($host)
    {
        $host = $this->normalizeHost($host);
        if ($host === '') {
            return ['ok' => false, 'message' => '域名为空，无法检测访问链路。'];
        }
        foreach (['https://' . $host, 'http://' . $host] as $url) {
            if (function_exists('curl_init')) {
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_NOBODY, true);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
                curl_setopt($ch, CURLOPT_TIMEOUT, 8);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_exec($ch);
                $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $error = curl_error($ch);
                curl_close($ch);
                if ($code >= 200 && $code < 400) {
                    return ['ok' => true, 'message' => $url . ' 可访问，HTTP ' . $code . '。'];
                }
                if ($code > 0) {
                    return ['ok' => false, 'message' => $url . ' 已响应但状态码为 HTTP ' . $code . '，请检查 Web 绑定或反向代理。'];
                }
                if ($error !== '') {
                    continue;
                }
            } elseif (function_exists('get_headers')) {
                $context = stream_context_create(['http' => ['method' => 'HEAD', 'timeout' => 6, 'ignore_errors' => true]]);
                $headers = @get_headers($url, false, $context);
                if (is_array($headers) && isset($headers[0]) && preg_match('/\s([0-9]{3})\s/', $headers[0], $match)) {
                    $code = (int) $match[1];
                    if ($code >= 200 && $code < 400) {
                        return ['ok' => true, 'message' => $url . ' 可访问，HTTP ' . $code . '。'];
                    }
                    return ['ok' => false, 'message' => $url . ' 已响应但状态码为 HTTP ' . $code . '。'];
                }
            }
        }
        return ['ok' => false, 'message' => '暂时无法通过 HTTP/HTTPS 访问该域名，请检查 DNS 生效、站点绑定和 SSL 配置。'];
    }

    protected function isMainHost($host)
    {
        $host = $this->normalizeHost($host);
        if ($host === '') {
            return false;
        }
        $mainHosts = [];
        $configured = trim((string) setting('site_public_url', ''));
        $publicHost = $configured !== '' ? $this->normalizeHost($configured) : '';
        if ($publicHost !== '') {
            $mainHosts[] = $publicHost;
        }
        return in_array($host, array_unique($mainHosts), true);
    }

    protected function validDomain($host)
    {
        if ($host === '' || strlen($host) > 253 || strpos($host, '..') !== false) {
            return false;
        }
        $plain = trim($host, '[]');
        if (filter_var($plain, FILTER_VALIDATE_IP)) {
            return false;
        }
        if (in_array($host, ['localhost', 'localhost.localdomain'], true) || substr($host, -6) === '.local') {
            return false;
        }
        return (bool) preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $host);
    }

    protected function cleanUrl($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        if (strpos($value, '//') === 0) {
            return '';
        }
        if (preg_match('#^https?://#i', $value) || strpos($value, '/') === 0) {
            return text_limit(preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', '', $value), 800);
        }
        return '';
    }

    protected function themeColor($value)
    {
        $value = trim((string) $value);
        return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? strtoupper($value) : '#2563EB';
    }

    protected function contactEmail($value)
    {
        $value = trim((string) $value);
        return filter_var($value, FILTER_VALIDATE_EMAIL) ? text_limit($value, 120) : '';
    }

    protected function verificationToken()
    {
        return 'bm-site-' . bin2hex(random_bytes(10));
    }
}
