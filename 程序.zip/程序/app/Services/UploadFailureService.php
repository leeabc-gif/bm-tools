<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;
use App\Models\StorageDriver;

class UploadFailureService
{
    public function record($userId, $scope, array $file, $message, array $context = [])
    {
        try {
            DatabaseUpgradeService::ensureUploadFailureSchema();
            $payload = $this->payload($message);
            $storage = $this->storageSnapshot();
            Database::execute(
                'INSERT INTO ' . Database::table('upload_failures') . ' (user_id, scope, file_name, file_size, mime_type, folder_id, storage_id, storage_type, error_type, message, suggestion, ip, user_agent, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $userId ? (int) $userId : null,
                    $this->scope($scope),
                    $this->fileName($file),
                    max(0, (int) (isset($file['size']) ? $file['size'] : 0)),
                    text_limit((string) (isset($file['type']) ? $file['type'] : ''), 120),
                    max(0, (int) (isset($context['folder_id']) ? $context['folder_id'] : 0)),
                    $storage ? (int) $storage['id'] : null,
                    $storage ? text_limit((string) $storage['type'], 32) : '',
                    $payload['error_type'],
                    text_limit($payload['message'], 800),
                    text_limit($payload['suggestion'], 800),
                    Auth::ip(),
                    text_limit((string) (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''), 255),
                    now(),
                ]
            );
        } catch (\Throwable $e) {
            Logger::error('上传失败记录写入失败：' . $e->getMessage(), [
                'user_id' => $userId,
                'scope' => $scope,
                'message' => (string) $message,
            ]);
        }
    }

    public function payload($message)
    {
        $message = trim((string) $message);
        $lower = strtolower($message);
        $payload = [
            'message' => $message !== '' ? $message : '上传失败，请检查文件、套餐额度和对象存储配置。',
            'error_type' => 'upload',
            'suggestion' => '请先根据提示处理文件或套餐限制；如果提示存储异常，请管理员进入后台资源功能管理执行真实测试。',
        ];

        $storageStage = $this->detectStorageStage($message, $lower);
        if ($storageStage) {
            return array_merge($payload, $storageStage);
        }

        if (
            strpos($lower, 'sqlstate') !== false
            || strpos($lower, 'base table or view not found') !== false
            || strpos($lower, 'unknown column') !== false
            || strpos($message, '数据结构') !== false
            || strpos($message, '数据库巡检') !== false
            || strpos($message, '缺少数据表') !== false
            || strpos($message, '缺失字段') !== false
        ) {
            $payload['error_type'] = 'schema';
            $payload['failed_stage'] = 'database';
            $payload['failed_stage_label'] = '数据库结构';
            $payload['failed_stage_hint'] = '当前功能依赖的数据表或字段不完整，先执行数据库巡检一键修复。';
            $payload['suggestion'] = '请管理员进入后台「数据库巡检」执行一键修复；如果仍未完成，请检查数据库账号是否有 CREATE、ALTER、INDEX 权限。';
            return $payload;
        }

        if (
            strpos($message, 'post_max_size') !== false
            || strpos($message, 'upload_max_filesize') !== false
            || (strpos($message, 'PHP') !== false && strpos($lower, 'curl') === false && strpos($lower, 'openssl') === false)
            || strpos($message, '临时目录') !== false
            || strpos($message, '临时文件') !== false
        ) {
            $payload['error_type'] = 'php_upload_limit';
            $payload['failed_stage'] = 'php';
            $payload['failed_stage_label'] = 'PHP 上传环境';
            $payload['failed_stage_hint'] = '上传还没进入对象存储，先检查 PHP 限制、临时目录和 Web 服务限制。';
            $payload['suggestion'] = '服务器 PHP 上传限制或临时目录异常，请检查 upload_max_filesize、post_max_size、upload_tmp_dir 和目录权限。';
            return $payload;
        }

        if (
            strpos($message, '套餐') !== false
            || strpos($message, '空间不足') !== false
            || strpos($message, '剩余存储') !== false
            || strpos($message, '不允许') !== false
            || (strpos($message, '权限') !== false && strpos($message, '存储') === false)
        ) {
            $payload['error_type'] = 'quota_or_permission';
            $payload['suggestion'] = '当前账号的套餐额度或功能权限不足，请升级套餐或联系管理员调整用户权限。';
            return $payload;
        }

        if (
            strpos($lower, 'storage') !== false
            || strpos($message, '对象存储') !== false
            || strpos($message, '默认存储') !== false
            || strpos($message, 'Bucket') !== false
            || strpos($message, 'Endpoint') !== false
            || strpos($message, 'AccessKey') !== false
            || strpos($message, 'Secret') !== false
            || strpos($message, 'curl') !== false
            || strpos($message, '七牛') !== false
            || strpos($message, 'OSS') !== false
            || strpos($message, 'COS') !== false
            || strpos($message, 'WebDAV') !== false
            || strpos($message, 'R2') !== false
            || strpos($message, 'S3') !== false
            || strpos($message, '签名') !== false
        ) {
            $payload['error_type'] = 'storage_upload';
            $payload['failed_stage'] = 'upload';
            $payload['failed_stage_label'] = '对象存储写入';
            $payload['failed_stage_hint'] = '上传已进入存储链路，请检查厂商配置、区域、签名、写入权限和网络连通。';
            $payload['suggestion'] = '对象存储写入失败。管理员应进入后台资源功能管理，点击对应存储源的真实测试，系统会指出配置、写入、外链或删除是哪一步不通。';
            return $payload;
        }

        return $payload;
    }

    protected function detectStorageStage($message, $lower)
    {
        if ($message === '') {
            return null;
        }

        if (
            strpos($message, '存储配置检查失败') !== false
            || strpos($message, '默认对象存储') !== false
            || strpos($message, '配置不完整') !== false
            || strpos($message, '驱动初始化') !== false
            || strpos($message, '资源功能管理重新填写') !== false
            || strpos($lower, 'curl') !== false
            || strpos($lower, 'openssl') !== false
        ) {
            return [
                'error_type' => 'storage_config',
                'failed_stage' => 'config',
                'failed_stage_label' => '存储配置',
                'failed_stage_hint' => '默认存储无法初始化或基础配置未通过，先检查 Bucket、Endpoint、区域、AK/SK、Token、curl/openssl 扩展。',
                'suggestion' => '请管理员进入后台「资源功能管理」，重新保存默认存储配置，并点击“真实测试”。测试会按配置、写入、外链、删除四步指出不通位置。',
            ];
        }

        if (
            strpos($message, '数据库入库失败') !== false
            || strpos($message, '文件已写入对象存储') !== false
            || strpos($message, '用户空间或日志写入失败') !== false
            || strpos($message, '远程文件自动清理失败') !== false
        ) {
            return [
                'error_type' => 'storage_db',
                'failed_stage' => 'database',
                'failed_stage_label' => '数据库入库',
                'failed_stage_hint' => '对象存储已经写入成功，但本地文件记录、用户空间或日志写入失败。',
                'suggestion' => '请管理员进入后台「数据库巡检」执行一键修复；如果提示远程清理失败，请同时到对象存储后台检查是否留下了未入库文件。',
            ];
        }

        if (
            strpos($message, '存储写入失败') !== false
            || strpos($message, '对象路径') !== false
            || strpos($message, '写入文件时失败') !== false
            || strpos($message, 'PutObject') !== false
            || strpos($message, 'Signature') !== false
            || strpos($message, 'AccessDenied') !== false
            || strpos($message, 'InvalidAccessKeyId') !== false
            || strpos($message, 'NoSuchBucket') !== false
            || strpos($message, '存储驱动返回结果不完整') !== false
        ) {
            return [
                'error_type' => 'storage_upload',
                'failed_stage' => 'upload',
                'failed_stage_label' => '对象存储写入',
                'failed_stage_hint' => '文件写入第三方厂商失败，重点检查 Bucket 是否存在、区域是否匹配、AK/SK 是否正确、账号是否有写入权限。',
                'suggestion' => '请管理员进入后台「资源功能管理」对默认存储执行真实测试；若卡在写入测试，按厂商控制台核对区域、Endpoint、访问密钥和写入权限。',
            ];
        }

        return null;
    }

    protected function storageSnapshot()
    {
        try {
            return (new StorageDriver())->defaultDriver();
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function scope($scope)
    {
        $scope = (string) $scope;
        return in_array($scope, ['image', 'file', 'guest', 'api', 'unknown'], true) ? $scope : 'unknown';
    }

    protected function fileName(array $file)
    {
        $name = isset($file['name']) ? (string) $file['name'] : '';
        $name = basename(str_replace('\\', '/', $name));
        $name = preg_replace('/[\x00-\x1F\x7F]+/', '', $name);
        return text_limit(trim($name) !== '' ? trim($name) : 'unknown', 255);
    }
}
