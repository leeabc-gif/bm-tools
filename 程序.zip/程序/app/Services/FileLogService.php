<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;

class FileLogService
{
    protected static $schemaReady = false;

    public function log($userId, $fileId, $action, $fileName = '', $fileSize = 0, array $detail = [])
    {
        try {
            if (!self::$schemaReady) {
                self::$schemaReady = DatabaseUpgradeService::ensureFileLogSchema();
            }
            Database::execute(
                'INSERT INTO ' . Database::table('file_logs') . ' (user_id, file_id, action, file_name, file_size, ip, detail, created_at) VALUES (?,?,?,?,?,?,?,?)',
                [(int) $userId, $fileId ? (int) $fileId : null, (string) $action, (string) $fileName, (int) $fileSize, Auth::ip(), json_encode($detail, JSON_UNESCAPED_UNICODE), now()]
            );
            return true;
        } catch (\Throwable $e) {
            Logger::error('文件记录写入失败：' . $e->getMessage(), [
                'user_id' => (int) $userId,
                'file_id' => $fileId ? (int) $fileId : null,
                'action' => (string) $action,
            ]);
            return false;
        }
    }
}
