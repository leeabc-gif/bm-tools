<?php
namespace App\Services;

use App\Core\Config;
use App\Core\Logger;

class BrandProtectionService
{
    const ADMIN_COPYRIGHT_BRAND = 'BM ucloud tools';

    protected static $checked = false;
    protected static $hasIssues = false;
    protected static $issues = [];

    public static function brandName()
    {
        return (string) Config::get('app.name', 'BM TOOLS');
    }

    public static function version()
    {
        return (string) Config::get('app.version', '1.0.0');
    }

    public static function copyrightText()
    {
        return 'Powered by ' . self::ADMIN_COPYRIGHT_BRAND;
    }

    public static function protectRequest()
    {
        if (PHP_SAPI === 'cli') {
            return;
        }

        $result = self::check();
        if (!$result['ok']) {
            self::reportIssues($result['issues']);
        }
    }

    public static function check()
    {
        if (self::$checked) {
            return ['ok' => !self::$hasIssues, 'issues' => self::$issues];
        }

        self::$checked = true;
        self::$issues = [];

        $adminLayout = APP_ROOT . '/app/Views/layouts/admin.php';
        if (!is_file($adminLayout)) {
            self::$issues[] = '后台管理系统版权文件缺失：app/Views/layouts/admin.php';
        } else {
            $content = (string) file_get_contents($adminLayout);
            if (strpos($content, 'app_copyright_text()') === false || strpos($content, 'admin-global-footer') === false) {
                self::$issues[] = '后台管理系统核心版权标识未按标准输出，请检查后台底部版权调用。';
            }
        }

        self::$hasIssues = !empty(self::$issues);
        return ['ok' => !self::$hasIssues, 'issues' => self::$issues];
    }

    public static function hasIssues()
    {
        $result = self::check();
        return !$result['ok'];
    }

    public static function issues()
    {
        $result = self::check();
        return $result['issues'];
    }

    protected static function reportIssues(array $issues)
    {
        static $reported = false;
        if ($reported || empty($issues)) {
            return;
        }
        $reported = true;

        Logger::error('Admin copyright check failed; site remains available for repair.', [
            'issues' => array_values($issues),
            'request' => isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '',
        ]);
    }
}
