<?php
namespace App\Services;

use App\Core\Logger;

class AlertWebhookService
{
    public function sendMonitorAlert($userId, $title, $content, array $context = [])
    {
        if ((string) setting('alert_webhook_enabled', '0') !== '1') {
            return ['sent' => 0, 'failed' => 0, 'results' => []];
        }

        $text = $this->formatAlertText($title, $content, $context);
        $results = [];
        foreach ($this->configuredChannels() as $channel) {
            try {
                $result = $this->sendChannel($channel['type'], $text, $channel);
                $results[] = $result;
                if (empty($result['success'])) {
                    Logger::error('告警通知通道发送失败：' . $channel['type'], [
                        'user_id' => (int) $userId,
                        'channel' => $channel['type'],
                        'message' => $this->safeMessage(isset($result['message']) ? $result['message'] : ''),
                    ]);
                }
            } catch (\Throwable $e) {
                $results[] = ['channel' => $channel['type'], 'success' => false, 'message' => $e->getMessage()];
                Logger::error('告警通知通道异常：' . $e->getMessage(), [
                    'user_id' => (int) $userId,
                    'channel' => $channel['type'],
                ]);
            }
        }

        $sent = 0;
        $failed = 0;
        foreach ($results as $result) {
            if (!empty($result['success'])) {
                $sent++;
            } else {
                $failed++;
            }
        }
        return ['sent' => $sent, 'failed' => $failed, 'results' => $results];
    }

    public function test($channel)
    {
        $channel = $this->normalizeChannel($channel);
        $text = $this->formatAlertText(
            '告警通知通道测试',
            '如果你能看到这条消息，说明该通道已经可以接收平台告警。',
            ['source' => '后台测试', 'time' => now()]
        );

        $settings = $this->settingsSnapshot();
        if ($channel === 'wecom') {
            return $this->sendWeCom($settings['alert_wecom_webhook'], $text);
        }
        if ($channel === 'dingtalk') {
            return $this->sendDingTalk($settings['alert_dingtalk_webhook'], $settings['alert_dingtalk_secret'], $text);
        }
        if ($channel === 'telegram') {
            return $this->sendTelegram($settings['alert_telegram_bot_token'], $settings['alert_telegram_chat_id'], $text);
        }

        return ['channel' => $channel, 'success' => false, 'message' => '不支持的测试通道。'];
    }

    public function configuredChannels()
    {
        $settings = $this->settingsSnapshot();
        $channels = [];
        if ($settings['alert_wecom_webhook'] !== '') {
            $channels[] = ['type' => 'wecom', 'webhook' => $settings['alert_wecom_webhook']];
        }
        if ($settings['alert_dingtalk_webhook'] !== '') {
            $channels[] = [
                'type' => 'dingtalk',
                'webhook' => $settings['alert_dingtalk_webhook'],
                'secret' => $settings['alert_dingtalk_secret'],
            ];
        }
        if ($settings['alert_telegram_bot_token'] !== '' && $settings['alert_telegram_chat_id'] !== '') {
            $channels[] = [
                'type' => 'telegram',
                'bot_token' => $settings['alert_telegram_bot_token'],
                'chat_id' => $settings['alert_telegram_chat_id'],
            ];
        }
        return $channels;
    }

    public function validateSettings(array $settings)
    {
        $errors = [];
        $wecom = trim((string) (isset($settings['alert_wecom_webhook']) ? $settings['alert_wecom_webhook'] : ''));
        $ding = trim((string) (isset($settings['alert_dingtalk_webhook']) ? $settings['alert_dingtalk_webhook'] : ''));
        $telegramToken = trim((string) (isset($settings['alert_telegram_bot_token']) ? $settings['alert_telegram_bot_token'] : ''));
        $telegramChat = trim((string) (isset($settings['alert_telegram_chat_id']) ? $settings['alert_telegram_chat_id'] : ''));

        if ($wecom !== '' && !$this->allowedWebhookUrl($wecom, ['qyapi.weixin.qq.com'])) {
            $errors[] = '企业微信 Webhook 必须是 https://qyapi.weixin.qq.com 开头的机器人地址。';
        }
        if ($ding !== '' && !$this->allowedWebhookUrl($ding, ['oapi.dingtalk.com'])) {
            $errors[] = '钉钉 Webhook 必须是 https://oapi.dingtalk.com 开头的机器人地址。';
        }
        if ($telegramToken !== '' && !preg_match('/^\d{5,20}:[A-Za-z0-9_-]{20,120}$/', $telegramToken)) {
            $errors[] = 'Telegram Bot Token 格式不正确。';
        }
        if (($telegramToken !== '' && $telegramChat === '') || ($telegramToken === '' && $telegramChat !== '')) {
            $errors[] = 'Telegram 需要同时填写 Bot Token 和 Chat ID。';
        }

        return $errors;
    }

    public function normalizeChannel($channel)
    {
        $channel = strtolower(trim((string) $channel));
        return in_array($channel, ['wecom', 'dingtalk', 'telegram'], true) ? $channel : '';
    }

    protected function sendChannel($type, $text, array $channel)
    {
        if ($type === 'wecom') {
            return $this->sendWeCom(isset($channel['webhook']) ? $channel['webhook'] : '', $text);
        }
        if ($type === 'dingtalk') {
            return $this->sendDingTalk(isset($channel['webhook']) ? $channel['webhook'] : '', isset($channel['secret']) ? $channel['secret'] : '', $text);
        }
        if ($type === 'telegram') {
            return $this->sendTelegram(isset($channel['bot_token']) ? $channel['bot_token'] : '', isset($channel['chat_id']) ? $channel['chat_id'] : '', $text);
        }
        return ['channel' => $type, 'success' => false, 'message' => '未知通道。'];
    }

    protected function sendWeCom($webhook, $text)
    {
        $webhook = trim((string) $webhook);
        if (!$this->allowedWebhookUrl($webhook, ['qyapi.weixin.qq.com'])) {
            return ['channel' => 'wecom', 'success' => false, 'message' => '企业微信 Webhook 未配置或域名不正确。'];
        }
        return $this->postJson('wecom', $webhook, [
            'msgtype' => 'text',
            'text' => ['content' => $text],
        ]);
    }

    protected function sendDingTalk($webhook, $secret, $text)
    {
        $webhook = trim((string) $webhook);
        if (!$this->allowedWebhookUrl($webhook, ['oapi.dingtalk.com'])) {
            return ['channel' => 'dingtalk', 'success' => false, 'message' => '钉钉 Webhook 未配置或域名不正确。'];
        }
        $secret = trim((string) $secret);
        if ($secret !== '') {
            $timestamp = (string) round(microtime(true) * 1000);
            $sign = urlencode(base64_encode(hash_hmac('sha256', $timestamp . "\n" . $secret, $secret, true)));
            $webhook .= (strpos($webhook, '?') === false ? '?' : '&') . 'timestamp=' . rawurlencode($timestamp) . '&sign=' . $sign;
        }
        return $this->postJson('dingtalk', $webhook, [
            'msgtype' => 'text',
            'text' => ['content' => $text],
        ]);
    }

    protected function sendTelegram($botToken, $chatId, $text)
    {
        $botToken = trim((string) $botToken);
        $chatId = trim((string) $chatId);
        if ($botToken === '' || $chatId === '') {
            return ['channel' => 'telegram', 'success' => false, 'message' => 'Telegram Bot Token 或 Chat ID 未配置。'];
        }
        if (!preg_match('/^\d{5,20}:[A-Za-z0-9_-]{20,120}$/', $botToken)) {
            return ['channel' => 'telegram', 'success' => false, 'message' => 'Telegram Bot Token 格式不正确。'];
        }
        return $this->postForm('telegram', 'https://api.telegram.org/bot' . $botToken . '/sendMessage', [
            'chat_id' => $chatId,
            'text' => $text,
            'disable_web_page_preview' => 'true',
        ]);
    }

    protected function postJson($channel, $url, array $payload)
    {
        return $this->request($channel, $url, json_encode($payload, JSON_UNESCAPED_UNICODE), [
            'Content-Type: application/json; charset=utf-8',
        ]);
    }

    protected function postForm($channel, $url, array $payload)
    {
        return $this->request($channel, $url, http_build_query($payload), [
            'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
        ]);
    }

    protected function request($channel, $url, $body, array $headers)
    {
        if (!function_exists('curl_init')) {
            return ['channel' => $channel, 'success' => false, 'message' => '当前 PHP 环境缺少 curl 扩展，无法发送 Webhook。'];
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false) {
            return ['channel' => $channel, 'success' => false, 'message' => '网络请求失败：' . $this->safeMessage($error)];
        }
        if ($status < 200 || $status >= 300) {
            return ['channel' => $channel, 'success' => false, 'message' => 'HTTP 状态异常：' . $status . '，响应：' . $this->safeMessage($response)];
        }

        $decoded = json_decode((string) $response, true);
        if (is_array($decoded)) {
            if ($channel === 'wecom' && isset($decoded['errcode']) && (int) $decoded['errcode'] !== 0) {
                return ['channel' => $channel, 'success' => false, 'message' => '企业微信返回错误：' . $this->safeMessage(isset($decoded['errmsg']) ? $decoded['errmsg'] : $response)];
            }
            if ($channel === 'dingtalk' && isset($decoded['errcode']) && (int) $decoded['errcode'] !== 0) {
                return ['channel' => $channel, 'success' => false, 'message' => '钉钉返回错误：' . $this->safeMessage(isset($decoded['errmsg']) ? $decoded['errmsg'] : $response)];
            }
            if ($channel === 'telegram' && isset($decoded['ok']) && !$decoded['ok']) {
                return ['channel' => $channel, 'success' => false, 'message' => 'Telegram 返回错误：' . $this->safeMessage(isset($decoded['description']) ? $decoded['description'] : $response)];
            }
        }

        return ['channel' => $channel, 'success' => true, 'message' => '发送成功。'];
    }

    protected function allowedWebhookUrl($url, array $hosts)
    {
        $url = trim((string) $url);
        if ($url === '' || !preg_match('#^https://#i', $url)) {
            return false;
        }
        $parts = parse_url($url);
        if (!$parts || empty($parts['host'])) {
            return false;
        }
        $host = strtolower((string) $parts['host']);
        foreach ($hosts as $allowed) {
            if ($host === strtolower($allowed)) {
                return true;
            }
        }
        return false;
    }

    protected function settingsSnapshot()
    {
        return [
            'alert_wecom_webhook' => trim((string) CryptoService::decrypt(setting('alert_wecom_webhook', ''))),
            'alert_dingtalk_webhook' => trim((string) CryptoService::decrypt(setting('alert_dingtalk_webhook', ''))),
            'alert_dingtalk_secret' => trim((string) CryptoService::decrypt(setting('alert_dingtalk_secret', ''))),
            'alert_telegram_bot_token' => trim((string) CryptoService::decrypt(setting('alert_telegram_bot_token', ''))),
            'alert_telegram_chat_id' => trim((string) setting('alert_telegram_chat_id', '')),
        ];
    }

    protected function formatAlertText($title, $content, array $context)
    {
        $lines = [
            '[' . setting('site_name', app_brand_name()) . '] ' . trim((string) $title),
            trim((string) $content),
        ];
        foreach (['server_name' => '服务器', 'metric' => '指标', 'level' => '级别', 'source' => '来源', 'time' => '时间'] as $key => $label) {
            if (isset($context[$key]) && trim((string) $context[$key]) !== '') {
                $lines[] = $label . '：' . trim((string) $context[$key]);
            }
        }
        if (!isset($context['time'])) {
            $lines[] = '时间：' . now();
        }
        return text_limit(implode("\n", array_filter($lines)), 1800);
    }

    protected function safeMessage($message)
    {
        $message = preg_replace('/(access_token=)[A-Za-z0-9._-]+/i', '$1***', (string) $message);
        $message = preg_replace('/(bot)\d{5,20}:[A-Za-z0-9_-]{20,120}/i', '$1***', $message);
        return text_limit($message, 240);
    }
}
