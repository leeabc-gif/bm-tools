<?php
namespace App\Services\Payment;

use App\Core\Database;
use App\Services\BalanceService;
use App\Services\NotificationService;

class PaymentService
{
    public function markOrderPaid($orderNo, $tradeNo = '', $amount = null)
    {
        $order = Database::fetch('SELECT type FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1', [$orderNo]);
        if (!$order) {
            throw new \RuntimeException('订单不存在。');
        }
        if ($order['type'] === 'recharge') {
            return $this->markRechargePaid($orderNo, $tradeNo, $amount);
        }
        if ($order['type'] === 'package') {
            return $this->markPackagePaid($orderNo, $tradeNo, $amount);
        }
        throw new \RuntimeException('暂不支持的订单类型。');
    }

    public function markRechargePaid($orderNo, $tradeNo, $amount = null)
    {
        Database::begin();
        try {
            $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1 FOR UPDATE', [$orderNo]);
            if (!$order || $order['type'] !== 'recharge') {
                throw new \RuntimeException('充值订单不存在。');
            }
            if ($order['status'] === 'paid') {
                Database::commit();
                return true;
            }
            if ($order['status'] !== 'pending') {
                throw new \RuntimeException('订单状态不可入账。');
            }
            if ($amount !== null && abs((float) $order['pay_amount'] - (float) $amount) > 0.01) {
                throw new \RuntimeException('支付金额与订单金额不一致。');
            }

            $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE order_id = ? LIMIT 1 FOR UPDATE', [$order['id']]);
            if (!$recharge) {
                throw new \RuntimeException('充值记录不存在。');
            }
            if ($recharge['status'] === 'paid') {
                Database::commit();
                return true;
            }
            if ($recharge['status'] !== 'pending') {
                throw new \RuntimeException('充值记录状态不可入账。');
            }

            Database::execute(
                'UPDATE ' . Database::table('orders') . ' SET status = ?, trade_no = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                ['paid', $tradeNo, now(), now(), $order['id']]
            );
            Database::execute(
                'UPDATE ' . Database::table('recharges') . ' SET status = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                ['paid', now(), now(), $recharge['id']]
            );
            (new BalanceService())->add($order['user_id'], $order['pay_amount'], 'recharge', 'order', $order['id'], '充值订单入账：' . $order['order_no']);
            (new NotificationService())->send($order['user_id'], 'recharge', '充值成功', '你的账户已充值 ' . $order['pay_amount'] . ' 元。');
            Database::commit();
            return true;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function markPackagePaid($orderNo, $tradeNo = '', $amount = null)
    {
        Database::begin();
        try {
            $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1 FOR UPDATE', [$orderNo]);
            if (!$order || $order['type'] !== 'package') {
                throw new \RuntimeException('套餐订单不存在。');
            }
            if ($order['status'] === 'paid') {
                Database::commit();
                return true;
            }
            if ($order['status'] !== 'pending') {
                throw new \RuntimeException('订单状态不可开通。');
            }
            if ($amount !== null && abs((float) $order['pay_amount'] - (float) $amount) > 0.01) {
                throw new \RuntimeException('支付金额与订单金额不一致。');
            }

            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1 FOR UPDATE', [$order['user_id']]);
            if (!$user) {
                throw new \RuntimeException('用户不存在。');
            }
            $package = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$order['package_id']]);
            if (!$package || (int) $package['status'] !== 1) {
                throw new \RuntimeException('套餐不存在或已停用。');
            }

            $couponMeta = $this->extractCouponMeta(isset($order['remark']) ? (string) $order['remark'] : '');
            if (!empty($couponMeta['code']) && !empty($couponMeta['discount'])) {
                $coupon = Database::fetch('SELECT * FROM ' . Database::table('coupons') . ' WHERE code = ? LIMIT 1', [$couponMeta['code']]);
                $existingRedemption = Database::fetch(
                    'SELECT id FROM ' . Database::table('coupon_redemptions') . ' WHERE order_id = ? LIMIT 1',
                    [$order['id']]
                );
                if ($coupon && !$existingRedemption) {
                    Database::execute(
                        'INSERT INTO ' . Database::table('coupon_redemptions') . ' (coupon_id, user_id, order_id, package_id, discount_amount, final_amount, ip, used_at) VALUES (?,?,?,?,?,?,?,?)',
                        [(int) $coupon['id'], $order['user_id'], $order['id'], $order['package_id'], round((float) $couponMeta['discount'], 2), round((float) $order['pay_amount'], 2), '', now()]
                    );
                }
            }

            $expire = $this->calculatePackageExpire($user, $package);
            Database::execute(
                'UPDATE ' . Database::table('users') . ' SET package_id = ?, package_expire_time = ?, total_storage = ?, total_traffic = ?, updated_at = ? WHERE id = ?',
                [$package['id'], $expire, $package['storage_limit'], $package['traffic_limit'], now(), $order['user_id']]
            );
            Database::execute(
                'UPDATE ' . Database::table('orders') . ' SET status = ?, trade_no = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                ['paid', $tradeNo, now(), now(), $order['id']]
            );
            (new NotificationService())->send($order['user_id'], 'package', '套餐购买成功', '你已成功开通 ' . $package['name'] . '。');
            Database::commit();
            return true;
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    protected function calculatePackageExpire(array $user, array $package)
    {
        if ($package['duration_type'] === 'forever') {
            return null;
        }
        $base = time();
        if (!empty($user['package_expire_time']) && strtotime($user['package_expire_time']) > $base && (int) $user['package_id'] === (int) $package['id']) {
            $base = strtotime($user['package_expire_time']);
        }
        return date('Y-m-d H:i:s', $base + ((int) $package['duration_days'] * 86400));
    }

    protected function extractCouponMeta($remark)
    {
        $meta = ['code' => '', 'discount' => 0];
        if (preg_match('/\[coupon:([A-Z0-9_-]+)\]/', $remark, $codeMatch)) {
            $meta['code'] = $codeMatch[1];
        }
        if (preg_match('/\[discount:([0-9]+(?:\.[0-9]{1,2})?)\]/', $remark, $discountMatch)) {
            $meta['discount'] = (float) $discountMatch[1];
        }
        return $meta;
    }
}
