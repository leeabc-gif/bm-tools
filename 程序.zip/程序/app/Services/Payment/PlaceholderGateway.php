<?php
namespace App\Services\Payment;

class PlaceholderGateway implements PaymentGatewayInterface
{
    protected $code;

    public function __construct($code)
    {
        $this->code = $code;
    }

    public function create(array $order)
    {
        return [
            'type' => $this->code,
            'message' => '该支付方式缺少商户参数，请先在后台支付配置中填写密钥、回调地址并启用后再下单。',
            'order_no' => $order['order_no'],
        ];
    }

    public function verifyNotify(array $payload)
    {
        return false;
    }
}
