<?php
namespace App\Services\Payment;

use App\Core\Database;

class AlipayF2FGateway implements PaymentGatewayInterface
{
    protected $config;

    public function __construct(array $config = [])
    {
        $this->config = $config;
    }

    public function create(array $order)
    {
        $this->assertConfigured();

        $bizContent = [
            'out_trade_no' => $order['order_no'],
            'total_amount' => number_format((float) $order['pay_amount'], 2, '.', ''),
            'subject' => $this->subject($order),
            'timeout_express' => isset($this->config['timeout_express']) ? $this->config['timeout_express'] : '10m',
        ];

        $params = $this->baseParams('alipay.trade.precreate');
        $params['biz_content'] = json_encode($bizContent, JSON_UNESCAPED_UNICODE);
        $params['notify_url'] = $this->notifyUrl();
        $params['sign'] = $this->sign($params);

        $response = $this->post($this->gatewayUrl(), $params);
        $json = json_decode($response, true);
        if (!is_array($json) || empty($json['alipay_trade_precreate_response'])) {
            throw new \RuntimeException('Alipay returned an invalid response: ' . text_limit($response, 300));
        }

        $payload = $json['alipay_trade_precreate_response'];
        if (!$this->verifyResponse($response, $json, 'alipay_trade_precreate_response')) {
            throw new \RuntimeException('Alipay response signature verification failed. Please check alipay_public_key.');
        }
        if (isset($payload['code']) && $payload['code'] !== '10000') {
            throw new \RuntimeException('Alipay order creation failed: ' . (isset($payload['sub_msg']) ? $payload['sub_msg'] : $payload['msg']));
        }

        return [
            'type' => 'alipay_f2f',
            'message' => 'Alipay face-to-face order created.',
            'order_no' => $order['order_no'],
            'qr_code' => isset($payload['qr_code']) ? $payload['qr_code'] : '',
            'redirect' => url('pay/alipay/' . $order['order_no']),
        ];
    }

    public function verifyNotify(array $payload)
    {
        if (!function_exists('openssl_verify')) {
            return false;
        }
        if (empty($payload['sign'])) {
            return false;
        }
        $sign = $payload['sign'];
        unset($payload['sign'], $payload['sign_type']);
        ksort($payload);
        $content = $this->buildSignContent($payload);
        $publicKey = $this->publicKey();
        $ok = openssl_verify($content, base64_decode($sign), $publicKey, OPENSSL_ALGO_SHA256);
        return $ok === 1;
    }

    public function query($orderNo)
    {
        $this->assertConfigured();
        $params = $this->baseParams('alipay.trade.query');
        $params['biz_content'] = json_encode(['out_trade_no' => $orderNo], JSON_UNESCAPED_UNICODE);
        $params['sign'] = $this->sign($params);
        $response = $this->post($this->gatewayUrl(), $params);
        $json = json_decode($response, true);
        if (!is_array($json) || empty($json['alipay_trade_query_response'])) {
            throw new \RuntimeException('Alipay query returned an invalid response.');
        }
        if (!$this->verifyResponse($response, $json, 'alipay_trade_query_response')) {
            throw new \RuntimeException('Alipay query signature verification failed. Please check alipay_public_key.');
        }
        return $json['alipay_trade_query_response'];
    }

    protected function baseParams($method)
    {
        return [
            'app_id' => $this->config['app_id'],
            'method' => $method,
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
        ];
    }

    protected function sign(array $params)
    {
        if (!function_exists('openssl_sign')) {
            throw new \RuntimeException('PHP openssl extension is required for Alipay signing.');
        }
        unset($params['sign']);
        ksort($params);
        $content = $this->buildSignContent($params);
        $privateKey = $this->privateKey();
        $signature = '';
        $ok = openssl_sign($content, $signature, $privateKey, OPENSSL_ALGO_SHA256);
        if (!$ok) {
            throw new \RuntimeException('Alipay signing failed. Please check private_key format.');
        }
        return base64_encode($signature);
    }

    protected function verifyResponse($rawBody, array $json, $responseKey)
    {
        if (!function_exists('openssl_verify')) {
            throw new \RuntimeException('PHP openssl extension is required for Alipay response verification.');
        }
        if (empty($json['sign']) || empty($json[$responseKey])) {
            return false;
        }
        $content = $this->extractResponseContent($rawBody, $responseKey);
        if ($content === '') {
            $content = json_encode($json[$responseKey], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $publicKey = $this->publicKey();
        $ok = openssl_verify($content, base64_decode($json['sign']), $publicKey, OPENSSL_ALGO_SHA256);
        return $ok === 1;
    }

    protected function extractResponseContent($body, $responseKey)
    {
        $needle = '"' . $responseKey . '":';
        $pos = strpos($body, $needle);
        if ($pos === false) {
            return '';
        }
        $start = $pos + strlen($needle);
        while (isset($body[$start]) && ctype_space($body[$start])) {
            $start++;
        }
        if (!isset($body[$start]) || $body[$start] !== '{') {
            return '';
        }

        $depth = 0;
        $inString = false;
        $escape = false;
        $length = strlen($body);
        for ($i = $start; $i < $length; $i++) {
            $char = $body[$i];
            if ($escape) {
                $escape = false;
                continue;
            }
            if ($char === '\\') {
                $escape = true;
                continue;
            }
            if ($char === '"') {
                $inString = !$inString;
                continue;
            }
            if ($inString) {
                continue;
            }
            if ($char === '{') {
                $depth++;
            } elseif ($char === '}') {
                $depth--;
                if ($depth === 0) {
                    return substr($body, $start, $i - $start + 1);
                }
            }
        }
        return '';
    }

    protected function buildSignContent(array $params)
    {
        $pieces = [];
        foreach ($params as $key => $value) {
            if ($value === '' || $value === null) {
                continue;
            }
            $pieces[] = $key . '=' . $value;
        }
        return implode('&', $pieces);
    }

    protected function post($url, array $params)
    {
        if (!function_exists('curl_init')) {
            throw new \RuntimeException('PHP curl extension is required for Alipay requests.');
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 30,
        ]);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $error || $code >= 400) {
            throw new \RuntimeException('Alipay request failed: ' . ($error ?: ('HTTP ' . $code)));
        }
        return $body;
    }

    protected function gatewayUrl()
    {
        if (!empty($this->config['sandbox'])) {
            return 'https://openapi-sandbox.dl.alipaydev.com/gateway.do';
        }
        return 'https://openapi.alipay.com/gateway.do';
    }

    protected function notifyUrl()
    {
        if (!empty($this->config['notify_url'])) {
            return $this->config['notify_url'];
        }
        return url('pay/alipay/notify');
    }

    protected function subject(array $order)
    {
        $siteName = setting('site_name', app_brand_name());
        return $siteName . ' recharge ' . number_format((float) $order['pay_amount'], 2, '.', '') . ' CNY';
    }

    protected function assertConfigured()
    {
        foreach (['app_id', 'private_key', 'alipay_public_key'] as $key) {
            if (empty($this->config[$key])) {
                throw new \RuntimeException('Alipay F2F config missing: ' . $key);
            }
        }
    }

    protected function privateKey()
    {
        return $this->formatKey($this->config['private_key'], 'PRIVATE KEY');
    }

    protected function publicKey()
    {
        return $this->formatKey($this->config['alipay_public_key'], 'PUBLIC KEY');
    }

    protected function formatKey($key, $type)
    {
        $key = trim($key);
        if (strpos($key, 'BEGIN') !== false) {
            return $key;
        }
        $key = str_replace(["\r", "\n", ' '], '', $key);
        return "-----BEGIN " . $type . "-----\n" . chunk_split($key, 64, "\n") . "-----END " . $type . "-----";
    }

    public static function config()
    {
        $row = Database::fetch('SELECT config FROM ' . Database::table('payment_config') . ' WHERE code = ? AND is_enabled = 1 LIMIT 1', ['alipay']);
        if (!$row) {
            return [];
        }
        $config = json_decode((string) $row['config'], true);
        return is_array($config) ? $config : [];
    }
}
