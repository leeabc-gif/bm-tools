<?php
namespace App\Services;

use App\Core\Database;
use App\Core\Logger;

class DatabaseUpgradeService
{
    protected static $runtimeSchemaChecked = false;
    protected static $standardSchemaReadyCache = null;

    public static function ensureRuntimeSchema()
    {
        if (self::$runtimeSchemaChecked) {
            return true;
        }
        self::$runtimeSchemaChecked = true;

        try {
            $cacheDir = APP_ROOT . '/storage/cache';
            if (!is_dir($cacheDir)) {
                @mkdir($cacheDir, 0755, true);
            }

            $schemaPath = APP_ROOT . '/database/schema.sql';
            $schemaHash = is_file($schemaPath) ? sha1_file($schemaPath) : 'missing-schema';
            $serviceMtime = is_file(__FILE__) ? (string) filemtime(__FILE__) : '0';
            $prefix = Database::prefix();
            $cacheKey = sha1($prefix . '|' . $schemaHash . '|' . $serviceMtime . '|runtime-schema-v2');
            $cacheFile = $cacheDir . '/runtime-schema-' . preg_replace('/[^A-Za-z0-9_-]/', '_', $prefix) . '.json';

            if (is_file($cacheFile)) {
                $cached = json_decode((string) @file_get_contents($cacheFile), true);
                if (
                    is_array($cached)
                    && isset($cached['key'], $cached['checked_at'])
                    && hash_equals((string) $cached['key'], $cacheKey)
                    && (time() - (int) $cached['checked_at']) < 3600
                ) {
                    return true;
                }
            }

            $result = self::repairAll();
            $ok = !empty($result['ok']) || self::standardSchemaReady();
            if ($ok && is_dir($cacheDir)) {
                @file_put_contents($cacheFile, json_encode([
                    'key' => $cacheKey,
                    'checked_at' => time(),
                    'ran_at' => now(),
                ], JSON_UNESCAPED_UNICODE));
            } elseif (!$ok) {
                @unlink($cacheFile);
            }

            return $ok;
        } catch (\Throwable $e) {
            Logger::error('Runtime schema guard failed: ' . $e->getMessage());
            return false;
        }
    }

    public static function standardSchemaReady()
    {
        if (self::$standardSchemaReadyCache !== null) {
            return self::$standardSchemaReadyCache;
        }

        try {
            $audit = self::inspectLiveSchema();
            self::$standardSchemaReadyCache = !empty($audit['ok']);
            return self::$standardSchemaReadyCache;
        } catch (\Throwable $e) {
            Logger::error('Standard schema readiness check failed: ' . $e->getMessage());
            self::$standardSchemaReadyCache = false;
            return false;
        }
    }

    protected static function allowWhenStandardSchemaReady($context, \Throwable $e)
    {
        $ready = self::standardSchemaReady();
        if ($ready) {
            Logger::error($context . '写入升级失败，但标准数据库结构巡检已匹配，功能页面已放行：' . $e->getMessage());
        }
        return $ready;
    }

    public static function ensureMarketingSchema()
    {
        try {
            $couponTable = Database::table('coupons');
            if (!self::tableExists($couponTable)) {
                Database::execute("CREATE TABLE `" . $couponTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `title` varchar(120) NOT NULL,
                    `code` varchar(40) NOT NULL,
                    `discount_type` enum('fixed','percent') NOT NULL DEFAULT 'fixed',
                    `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `min_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `package_scope` enum('all','include','exclude') NOT NULL DEFAULT 'all',
                    `package_ids` varchar(500) NOT NULL DEFAULT '',
                    `start_at` datetime DEFAULT NULL,
                    `end_at` datetime DEFAULT NULL,
                    `total_limit` int(10) unsigned NOT NULL DEFAULT '0',
                    `user_limit` int(10) unsigned NOT NULL DEFAULT '1',
                    `first_order_only` tinyint(1) NOT NULL DEFAULT '0',
                    `status` tinyint(1) NOT NULL DEFAULT '1',
                    `sort_order` int(11) NOT NULL DEFAULT '0',
                    `description` varchar(500) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_code` (`code`),
                    KEY `idx_status_time` (`status`, `start_at`, `end_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $redemptionTable = Database::table('coupon_redemptions');
            if (!self::tableExists($redemptionTable)) {
                Database::execute("CREATE TABLE `" . $redemptionTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `coupon_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `order_id` int(10) unsigned DEFAULT NULL,
                    `package_id` int(10) unsigned DEFAULT NULL,
                    `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `final_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `used_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_coupon` (`coupon_id`),
                    KEY `idx_user` (`user_id`),
                    UNIQUE KEY `uk_order` (`order_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            if (!self::hasIndex($redemptionTable, 'uk_order')) {
                Database::execute("ALTER TABLE `" . $redemptionTable . "` ADD UNIQUE KEY `uk_order` (`order_id`)");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('营销活动表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('营销活动表结构自动升级', $e);
        }
    }

    public static function ensureRedeemCardSchema()
    {
        try {
            $table = Database::table('redeem_cards');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `batch_no` varchar(40) NOT NULL,
                    `title` varchar(120) NOT NULL,
                    `type` enum('balance','package') NOT NULL,
                    `code_hash` char(64) NOT NULL,
                    `code_preview` varchar(32) NOT NULL DEFAULT '',
                    `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `package_id` int(10) unsigned DEFAULT NULL,
                    `duration_days` int(10) unsigned NOT NULL DEFAULT '0',
                    `channel` varchar(80) NOT NULL DEFAULT '',
                    `expire_at` datetime DEFAULT NULL,
                    `status` enum('unused','used','disabled') NOT NULL DEFAULT 'unused',
                    `used_by` int(10) unsigned DEFAULT NULL,
                    `used_ip` varchar(45) NOT NULL DEFAULT '',
                    `used_at` datetime DEFAULT NULL,
                    `order_id` int(10) unsigned DEFAULT NULL,
                    `remark` varchar(255) NOT NULL DEFAULT '',
                    `created_by` int(10) unsigned DEFAULT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_code_hash` (`code_hash`),
                    KEY `idx_batch` (`batch_no`),
                    KEY `idx_status_type` (`status`, `type`),
                    KEY `idx_used_by` (`used_by`),
                    KEY `idx_expire` (`expire_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            $columns = [
                'batch_no' => "`batch_no` varchar(40) NOT NULL DEFAULT ''",
                'title' => "`title` varchar(120) NOT NULL DEFAULT ''",
                'type' => "`type` enum('balance','package') NOT NULL DEFAULT 'balance'",
                'code_hash' => "`code_hash` char(64) NOT NULL DEFAULT ''",
                'code_preview' => "`code_preview` varchar(32) NOT NULL DEFAULT ''",
                'amount' => "`amount` decimal(10,2) NOT NULL DEFAULT '0.00'",
                'package_id' => "`package_id` int(10) unsigned DEFAULT NULL",
                'duration_days' => "`duration_days` int(10) unsigned NOT NULL DEFAULT '0'",
                'channel' => "`channel` varchar(80) NOT NULL DEFAULT ''",
                'expire_at' => "`expire_at` datetime DEFAULT NULL",
                'status' => "`status` enum('unused','used','disabled') NOT NULL DEFAULT 'unused'",
                'used_by' => "`used_by` int(10) unsigned DEFAULT NULL",
                'used_ip' => "`used_ip` varchar(45) NOT NULL DEFAULT ''",
                'used_at' => "`used_at` datetime DEFAULT NULL",
                'order_id' => "`order_id` int(10) unsigned DEFAULT NULL",
                'remark' => "`remark` varchar(255) NOT NULL DEFAULT ''",
                'created_by' => "`created_by` int(10) unsigned DEFAULT NULL",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            Database::execute("UPDATE `" . $table . "` SET code_hash = SHA2(CONCAT('legacy-redeem-card-', id), 256) WHERE code_hash = ''");
            Database::execute("UPDATE `" . $table . "` SET batch_no = CONCAT('LEGACY', id) WHERE batch_no = ''");
            Database::execute("UPDATE `" . $table . "` SET title = 'Legacy redeem card' WHERE title = ''");
            if (!self::hasIndex($table, 'uk_code_hash')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD UNIQUE KEY `uk_code_hash` (`code_hash`)");
            }
            if (!self::hasIndex($table, 'idx_batch')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_batch` (`batch_no`)");
            }
            if (!self::hasIndex($table, 'idx_status_type')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_status_type` (`status`, `type`)");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('卡密表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('卡密表结构自动升级', $e);
        }
    }

    public static function ensureRechargeOrderConstraint()
    {
        try {
            $table = Database::table('recharges');
            if (!self::tableExists($table)) {
                return false;
            }
            if (!self::hasIndex($table, 'uk_order')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD UNIQUE KEY `uk_order` (`order_id`)");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('充值订单唯一约束自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('充值订单唯一约束自动升级', $e);
        }
    }

    public static function ensureMonitorSchema()
    {
        try {
            $table = Database::table('monitor_servers');
            if (!self::tableExists($table)) {
                return false;
            }

            $monitorTypeColumn = self::column($table, 'monitor_type');
            if ($monitorTypeColumn) {
                $type = isset($monitorTypeColumn['Type']) ? $monitorTypeColumn['Type'] : (isset($monitorTypeColumn['type']) ? $monitorTypeColumn['type'] : '');
                if (stripos($type, 'agent') === false) {
                    Database::execute("ALTER TABLE `" . $table . "` MODIFY COLUMN `monitor_type` enum('bt','ssh','agent') NOT NULL DEFAULT 'bt'");
                }
            } else {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `monitor_type` enum('bt','ssh','agent') NOT NULL DEFAULT 'bt' AFTER `user_id`");
            }

            $columns = [
                'ssh_host' => "`ssh_host` varchar(120) DEFAULT NULL AFTER `server_ip`",
                'ssh_port' => "`ssh_port` int(10) unsigned NOT NULL DEFAULT '22' AFTER `ssh_host`",
                'ssh_username' => "`ssh_username` varchar(80) DEFAULT NULL AFTER `ssh_port`",
                'ssh_auth_type' => "`ssh_auth_type` enum('password','key') NOT NULL DEFAULT 'password' AFTER `ssh_username`",
                'ssh_password' => "`ssh_password` text AFTER `ssh_auth_type`",
                'ssh_private_key' => "`ssh_private_key` mediumtext AFTER `ssh_password`",
                'ssh_key_passphrase' => "`ssh_key_passphrase` text AFTER `ssh_private_key`",
                'agent_url' => "`agent_url` varchar(255) DEFAULT NULL AFTER `ssh_key_passphrase`",
                'agent_token' => "`agent_token` varchar(120) DEFAULT NULL AFTER `agent_url`",
            ];

            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }

            $packageTable = Database::table('packages');
            if (self::tableExists($packageTable) && !self::hasColumn($packageTable, 'allow_monitor')) {
                Database::execute("ALTER TABLE `" . $packageTable . "` ADD COLUMN `allow_monitor` tinyint(1) NOT NULL DEFAULT '0' AFTER `allow_api`");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('监控表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('监控表结构自动升级', $e);
        }
    }

    public static function ensureServerOpsSchema()
    {
        try {
            self::ensureMonitorSchema();

            $userTable = Database::table('users');
            if (self::tableExists($userTable)) {
                self::ensureColumns($userTable, [
                    'server_ops_cron_token' => "`server_ops_cron_token` char(64) DEFAULT NULL AFTER `admin_theme_style`",
                ]);
                if (!self::hasIndex($userTable, 'idx_server_ops_cron_token')) {
                    Database::execute("ALTER TABLE `" . $userTable . "` ADD KEY `idx_server_ops_cron_token` (`server_ops_cron_token`)");
                }
            }

            $serverTable = Database::table('monitor_servers');
            if (self::tableExists($serverTable) && !self::hasIndex($serverTable, 'idx_user_type')) {
                Database::execute("ALTER TABLE `" . $serverTable . "` ADD KEY `idx_user_type` (`user_id`, `monitor_type`)");
            }

            $sessionTable = Database::table('server_ssh_sessions');
            if (!self::tableExists($sessionTable)) {
                Database::execute("CREATE TABLE `" . $sessionTable . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `server_id` int(10) unsigned NOT NULL,
                    `token_hash` char(64) NOT NULL,
                    `gateway_url` varchar(255) NOT NULL DEFAULT '',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `user_agent` varchar(255) NOT NULL DEFAULT '',
                    `status` enum('issued','connected','closed','expired','failed') NOT NULL DEFAULT 'issued',
                    `started_at` datetime DEFAULT NULL,
                    `ended_at` datetime DEFAULT NULL,
                    `expires_at` datetime NOT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_token_hash` (`token_hash`),
                    KEY `idx_user_server` (`user_id`, `server_id`),
                    KEY `idx_status_time` (`status`, `created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $logTable = Database::table('server_command_logs');
            if (!self::tableExists($logTable)) {
                Database::execute("CREATE TABLE `" . $logTable . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `server_id` int(10) unsigned NOT NULL,
                    `session_id` bigint(20) unsigned DEFAULT NULL,
                    `command` text NOT NULL,
                    `output_summary` mediumtext,
                    `exit_status` int(11) DEFAULT NULL,
                    `risk_level` enum('normal','warning','danger') NOT NULL DEFAULT 'normal',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `user_agent` varchar(255) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_user_time` (`user_id`, `created_at`),
                    KEY `idx_server_time` (`server_id`, `created_at`),
                    KEY `idx_risk` (`risk_level`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $pageTable = Database::table('server_monitor_pages');
            if (!self::tableExists($pageTable)) {
                Database::execute("CREATE TABLE `" . $pageTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `server_id` int(10) unsigned NOT NULL,
                    `title` varchar(120) NOT NULL DEFAULT '',
                    `token` varchar(64) NOT NULL,
                    `visibility` enum('private','public','password') NOT NULL DEFAULT 'private',
                    `password_hash` varchar(255) DEFAULT NULL,
                    `show_metrics` tinyint(1) NOT NULL DEFAULT '1',
                    `show_services` tinyint(1) NOT NULL DEFAULT '1',
                    `expires_at` datetime DEFAULT NULL,
                    `view_count` int(10) unsigned NOT NULL DEFAULT '0',
                    `last_viewed_at` datetime DEFAULT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_token` (`token`),
                    UNIQUE KEY `uk_server` (`server_id`),
                    KEY `idx_user` (`user_id`),
                    KEY `idx_visibility` (`visibility`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $probeTable = Database::table('server_service_checks');
            if (!self::tableExists($probeTable)) {
                Database::execute("CREATE TABLE `" . $probeTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `server_id` int(10) unsigned NOT NULL,
                    `type` enum('http','tcp','ssl') NOT NULL DEFAULT 'http',
                    `name` varchar(120) NOT NULL,
                    `target` varchar(500) NOT NULL,
                    `port` int(10) unsigned NOT NULL DEFAULT '0',
                    `method` varchar(8) NOT NULL DEFAULT 'HEAD',
                    `expected_status` varchar(80) NOT NULL DEFAULT '200-399',
                    `keyword` varchar(255) NOT NULL DEFAULT '',
                    `timeout_seconds` int(10) unsigned NOT NULL DEFAULT '5',
                    `frequency` int(10) unsigned NOT NULL DEFAULT '300',
                    `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
                    `status` enum('up','down','unknown') NOT NULL DEFAULT 'unknown',
                    `response_time_ms` int(10) unsigned NOT NULL DEFAULT '0',
                    `status_code` int(10) unsigned DEFAULT NULL,
                    `ssl_expires_at` datetime DEFAULT NULL,
                    `last_error` varchar(500) NOT NULL DEFAULT '',
                    `last_checked_at` datetime DEFAULT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_user_server` (`user_id`, `server_id`),
                    KEY `idx_enabled_due` (`is_enabled`, `last_checked_at`),
                    KEY `idx_status` (`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $probeLogTable = Database::table('server_service_check_logs');
            if (!self::tableExists($probeLogTable)) {
                Database::execute("CREATE TABLE `" . $probeLogTable . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `check_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `server_id` int(10) unsigned NOT NULL,
                    `status` enum('up','down') NOT NULL DEFAULT 'down',
                    `response_time_ms` int(10) unsigned NOT NULL DEFAULT '0',
                    `status_code` int(10) unsigned DEFAULT NULL,
                    `ssl_expires_at` datetime DEFAULT NULL,
                    `message` varchar(500) NOT NULL DEFAULT '',
                    `checked_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_check_time` (`check_id`, `checked_at`),
                    KEY `idx_server_time` (`server_id`, `checked_at`),
                    KEY `idx_user_time` (`user_id`, `checked_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            self::ensureColumns($sessionTable, [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `id`",
                'server_id' => "`server_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `user_id`",
                'token_hash' => "`token_hash` char(64) NOT NULL DEFAULT '' AFTER `server_id`",
                'gateway_url' => "`gateway_url` varchar(255) NOT NULL DEFAULT '' AFTER `token_hash`",
                'ip' => "`ip` varchar(45) NOT NULL DEFAULT '' AFTER `gateway_url`",
                'user_agent' => "`user_agent` varchar(255) NOT NULL DEFAULT '' AFTER `ip`",
                'status' => "`status` enum('issued','connected','closed','expired','failed') NOT NULL DEFAULT 'issued' AFTER `user_agent`",
                'started_at' => "`started_at` datetime DEFAULT NULL AFTER `status`",
                'ended_at' => "`ended_at` datetime DEFAULT NULL AFTER `started_at`",
                'expires_at' => "`expires_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `ended_at`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `expires_at`",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `created_at`",
            ]);

            self::ensureColumns($logTable, [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `id`",
                'server_id' => "`server_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `user_id`",
                'session_id' => "`session_id` bigint(20) unsigned DEFAULT NULL AFTER `server_id`",
                'command' => "`command` text AFTER `session_id`",
                'output_summary' => "`output_summary` mediumtext AFTER `command`",
                'exit_status' => "`exit_status` int(11) DEFAULT NULL AFTER `output_summary`",
                'risk_level' => "`risk_level` enum('normal','warning','danger') NOT NULL DEFAULT 'normal' AFTER `exit_status`",
                'ip' => "`ip` varchar(45) NOT NULL DEFAULT '' AFTER `risk_level`",
                'user_agent' => "`user_agent` varchar(255) NOT NULL DEFAULT '' AFTER `ip`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `user_agent`",
            ]);

            self::ensureColumns($pageTable, [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `id`",
                'server_id' => "`server_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `user_id`",
                'title' => "`title` varchar(120) NOT NULL DEFAULT '' AFTER `server_id`",
                'token' => "`token` varchar(64) NOT NULL DEFAULT '' AFTER `title`",
                'visibility' => "`visibility` enum('private','public','password') NOT NULL DEFAULT 'private' AFTER `token`",
                'password_hash' => "`password_hash` varchar(255) DEFAULT NULL AFTER `visibility`",
                'show_metrics' => "`show_metrics` tinyint(1) NOT NULL DEFAULT '1' AFTER `password_hash`",
                'show_services' => "`show_services` tinyint(1) NOT NULL DEFAULT '1' AFTER `show_metrics`",
                'expires_at' => "`expires_at` datetime DEFAULT NULL AFTER `show_services`",
                'view_count' => "`view_count` int(10) unsigned NOT NULL DEFAULT '0' AFTER `expires_at`",
                'last_viewed_at' => "`last_viewed_at` datetime DEFAULT NULL AFTER `view_count`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `last_viewed_at`",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `created_at`",
            ]);

            self::ensureColumns($probeTable, [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `id`",
                'server_id' => "`server_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `user_id`",
                'type' => "`type` enum('http','tcp','ssl') NOT NULL DEFAULT 'http' AFTER `server_id`",
                'name' => "`name` varchar(120) NOT NULL DEFAULT '' AFTER `type`",
                'target' => "`target` varchar(500) NOT NULL DEFAULT '' AFTER `name`",
                'port' => "`port` int(10) unsigned NOT NULL DEFAULT '0' AFTER `target`",
                'method' => "`method` varchar(8) NOT NULL DEFAULT 'HEAD' AFTER `port`",
                'expected_status' => "`expected_status` varchar(80) NOT NULL DEFAULT '200-399' AFTER `method`",
                'keyword' => "`keyword` varchar(255) NOT NULL DEFAULT '' AFTER `expected_status`",
                'timeout_seconds' => "`timeout_seconds` int(10) unsigned NOT NULL DEFAULT '5' AFTER `keyword`",
                'frequency' => "`frequency` int(10) unsigned NOT NULL DEFAULT '300' AFTER `timeout_seconds`",
                'is_enabled' => "`is_enabled` tinyint(1) NOT NULL DEFAULT '1' AFTER `frequency`",
                'status' => "`status` enum('up','down','unknown') NOT NULL DEFAULT 'unknown' AFTER `is_enabled`",
                'response_time_ms' => "`response_time_ms` int(10) unsigned NOT NULL DEFAULT '0' AFTER `status`",
                'status_code' => "`status_code` int(10) unsigned DEFAULT NULL AFTER `response_time_ms`",
                'ssl_expires_at' => "`ssl_expires_at` datetime DEFAULT NULL AFTER `status_code`",
                'last_error' => "`last_error` varchar(500) NOT NULL DEFAULT '' AFTER `ssl_expires_at`",
                'last_checked_at' => "`last_checked_at` datetime DEFAULT NULL AFTER `last_error`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `last_checked_at`",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `created_at`",
            ]);

            self::ensureColumns($probeLogTable, [
                'check_id' => "`check_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `id`",
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `check_id`",
                'server_id' => "`server_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `user_id`",
                'status' => "`status` enum('up','down') NOT NULL DEFAULT 'down' AFTER `server_id`",
                'response_time_ms' => "`response_time_ms` int(10) unsigned NOT NULL DEFAULT '0' AFTER `status`",
                'status_code' => "`status_code` int(10) unsigned DEFAULT NULL AFTER `response_time_ms`",
                'ssl_expires_at' => "`ssl_expires_at` datetime DEFAULT NULL AFTER `status_code`",
                'message' => "`message` varchar(500) NOT NULL DEFAULT '' AFTER `ssl_expires_at`",
                'checked_at' => "`checked_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `message`",
            ]);

            self::ensureSettingDefault('ssh_terminal_enabled', '1');
            self::ensureSettingDefault('ssh_terminal_user_server_limit', '5');
            self::ensureSettingDefault('ssh_terminal_session_timeout', '600');
            self::ensureSettingDefault('ssh_terminal_command_timeout', '30');
            self::ensureSettingDefault('ssh_terminal_gateway_url', '');
            self::ensureSettingDefault('server_probe_user_check_limit', '20');
            self::ensureUploadLimitDefaults();
            return true;
        } catch (\Throwable $e) {
            Logger::error('服务器管家表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('服务器管家表结构自动升级', $e);
        }
    }

    public static function ensureAnnouncementSchema()
    {
        try {
            $table = Database::table('announcements');
            if (!self::tableExists($table)) {
                return false;
            }
            $columns = [
                'category' => "`category` varchar(40) NOT NULL DEFAULT 'platform' AFTER `content`",
                'summary' => "`summary` varchar(300) NOT NULL DEFAULT '' AFTER `category`",
                'cover_image' => "`cover_image` varchar(255) NOT NULL DEFAULT '' AFTER `summary`",
                'tags' => "`tags` varchar(255) NOT NULL DEFAULT '' AFTER `cover_image`",
                'content_format' => "`content_format` varchar(20) NOT NULL DEFAULT 'html' AFTER `tags`",
                'view_count' => "`view_count` int(10) unsigned NOT NULL DEFAULT '0' AFTER `content_format`",
            ];
            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            if (!self::hasIndex($table, 'idx_category_status')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_category_status` (`category`, `status`, `published_at`)");
            }
            self::ensureSiteDocumentRows($table);
            return true;
        } catch (\Throwable $e) {
            Logger::error('公告表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('公告表结构自动升级', $e);
        }
    }

    public static function ensureFileLogSchema()
    {
        try {
            $table = Database::table('file_logs');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `file_id` int(10) unsigned DEFAULT NULL,
                    `action` varchar(40) NOT NULL,
                    `file_name` varchar(255) DEFAULT NULL,
                    `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `detail` text,
                    `created_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_user_time` (`user_id`, `created_at`),
                    KEY `idx_file` (`file_id`),
                    KEY `idx_action` (`action`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            $columns = [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `id`",
                'file_id' => "`file_id` int(10) unsigned DEFAULT NULL AFTER `user_id`",
                'action' => "`action` varchar(40) NOT NULL DEFAULT '' AFTER `file_id`",
                'file_name' => "`file_name` varchar(255) DEFAULT NULL AFTER `action`",
                'file_size' => "`file_size` bigint(20) unsigned NOT NULL DEFAULT '0' AFTER `file_name`",
                'ip' => "`ip` varchar(45) NOT NULL DEFAULT '' AFTER `file_size`",
                'detail' => "`detail` text AFTER `ip`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00' AFTER `detail`",
            ];
            foreach ($columns as $column => $definition) {
                if (!self::hasColumn($table, $column)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            if (!self::hasIndex($table, 'idx_user_time')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_user_time` (`user_id`, `created_at`)");
            }
            if (!self::hasIndex($table, 'idx_file')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_file` (`file_id`)");
            }
            if (!self::hasIndex($table, 'idx_action')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_action` (`action`)");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('文件记录表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('文件记录表结构自动升级', $e);
        }
    }

    public static function ensureUploadFailureSchema()
    {
        try {
            $table = Database::table('upload_failures');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned DEFAULT NULL,
                    `scope` enum('image','file','guest','api','unknown') NOT NULL DEFAULT 'unknown',
                    `file_name` varchar(255) NOT NULL DEFAULT '',
                    `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
                    `mime_type` varchar(120) NOT NULL DEFAULT '',
                    `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
                    `storage_id` int(10) unsigned DEFAULT NULL,
                    `storage_type` varchar(32) NOT NULL DEFAULT '',
                    `error_type` varchar(60) NOT NULL DEFAULT 'upload',
                    `message` varchar(800) NOT NULL DEFAULT '',
                    `suggestion` varchar(800) NOT NULL DEFAULT '',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `user_agent` varchar(255) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_user_time` (`user_id`, `created_at`),
                    KEY `idx_scope_time` (`scope`, `created_at`),
                    KEY `idx_error_type` (`error_type`, `created_at`),
                    KEY `idx_storage` (`storage_id`, `created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            self::ensureColumns($table, [
                'user_id' => "`user_id` int(10) unsigned DEFAULT NULL AFTER `id`",
                'scope' => "`scope` enum('image','file','guest','api','unknown') NOT NULL DEFAULT 'unknown' AFTER `user_id`",
                'file_name' => "`file_name` varchar(255) NOT NULL DEFAULT '' AFTER `scope`",
                'file_size' => "`file_size` bigint(20) unsigned NOT NULL DEFAULT '0' AFTER `file_name`",
                'mime_type' => "`mime_type` varchar(120) NOT NULL DEFAULT '' AFTER `file_size`",
                'folder_id' => "`folder_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `mime_type`",
                'storage_id' => "`storage_id` int(10) unsigned DEFAULT NULL AFTER `folder_id`",
                'storage_type' => "`storage_type` varchar(32) NOT NULL DEFAULT '' AFTER `storage_id`",
                'error_type' => "`error_type` varchar(60) NOT NULL DEFAULT 'upload' AFTER `storage_type`",
                'message' => "`message` varchar(800) NOT NULL DEFAULT '' AFTER `error_type`",
                'suggestion' => "`suggestion` varchar(800) NOT NULL DEFAULT '' AFTER `message`",
                'ip' => "`ip` varchar(45) NOT NULL DEFAULT '' AFTER `suggestion`",
                'user_agent' => "`user_agent` varchar(255) NOT NULL DEFAULT '' AFTER `ip`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00' AFTER `user_agent`",
            ]);
            if (!self::hasIndex($table, 'idx_user_time')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_user_time` (`user_id`, `created_at`)");
            }
            if (!self::hasIndex($table, 'idx_scope_time')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_scope_time` (`scope`, `created_at`)");
            }
            if (!self::hasIndex($table, 'idx_error_type')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_error_type` (`error_type`, `created_at`)");
            }
            if (!self::hasIndex($table, 'idx_storage')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_storage` (`storage_id`, `created_at`)");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('上传失败记录表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('上传失败记录表结构自动升级', $e);
        }
    }

    protected static function ensureSiteDocumentRows($table)
    {
        foreach (\App\Models\Announcement::documentTemplates() as $template) {
            $exists = Database::fetch("SELECT id FROM `" . $table . "` WHERE category = 'docs' AND title = ? LIMIT 1", [$template['title']]);
            if ($exists) {
                continue;
            }
            Database::execute(
                "INSERT INTO `" . $table . "` (`title`, `content`, `category`, `summary`, `cover_image`, `tags`, `content_format`, `view_count`, `is_top`, `show_home`, `status`, `published_at`, `created_at`, `updated_at`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [
                    $template['title'],
                    $template['content'],
                    'docs',
                    $template['summary'],
                    '',
                    '站点文档,ImgURL',
                    'html',
                    0,
                    0,
                    1,
                    1,
                    now(),
                    now(),
                    now(),
                ]
            );
        }
    }

    public static function ensureRepositorySchema()
    {
        try {
            $repositoryTable = Database::table('file_repositories');
            if (!self::tableExists($repositoryTable)) {
                Database::execute("CREATE TABLE `" . $repositoryTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `title` varchar(120) NOT NULL,
                    `slug` varchar(80) NOT NULL,
                    `description` varchar(500) NOT NULL DEFAULT '',
                    `cover_image` varchar(800) NOT NULL DEFAULT '',
                    `tags` varchar(255) NOT NULL DEFAULT '',
                    `access_type` enum('public','password','private') NOT NULL DEFAULT 'public',
                    `password_hash` varchar(255) DEFAULT NULL,
                    `expire_at` datetime DEFAULT NULL,
                    `max_views` int(10) unsigned NOT NULL DEFAULT '0',
                    `max_downloads` int(10) unsigned NOT NULL DEFAULT '0',
                    `ip_daily_view_limit` int(10) unsigned NOT NULL DEFAULT '0',
                    `ip_daily_download_limit` int(10) unsigned NOT NULL DEFAULT '0',
                    `allow_download` tinyint(1) NOT NULL DEFAULT '1',
                    `show_owner` tinyint(1) NOT NULL DEFAULT '1',
                    `status` tinyint(1) NOT NULL DEFAULT '1',
                    `admin_status` tinyint(1) NOT NULL DEFAULT '1',
                    `admin_remark` varchar(255) NOT NULL DEFAULT '',
                    `view_count` int(10) unsigned NOT NULL DEFAULT '0',
                    `download_count` int(10) unsigned NOT NULL DEFAULT '0',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_slug` (`slug`),
                    KEY `idx_user` (`user_id`),
                    KEY `idx_status` (`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            $repositoryColumns = [
                'description' => "`description` varchar(500) NOT NULL DEFAULT '' AFTER `slug`",
                'cover_image' => "`cover_image` varchar(800) NOT NULL DEFAULT '' AFTER `description`",
                'tags' => "`tags` varchar(255) NOT NULL DEFAULT '' AFTER `cover_image`",
                'access_type' => "`access_type` enum('public','password','private') NOT NULL DEFAULT 'public' AFTER `tags`",
                'password_hash' => "`password_hash` varchar(255) DEFAULT NULL AFTER `access_type`",
                'expire_at' => "`expire_at` datetime DEFAULT NULL AFTER `password_hash`",
                'max_views' => "`max_views` int(10) unsigned NOT NULL DEFAULT '0' AFTER `expire_at`",
                'max_downloads' => "`max_downloads` int(10) unsigned NOT NULL DEFAULT '0' AFTER `max_views`",
                'ip_daily_view_limit' => "`ip_daily_view_limit` int(10) unsigned NOT NULL DEFAULT '0' AFTER `max_downloads`",
                'ip_daily_download_limit' => "`ip_daily_download_limit` int(10) unsigned NOT NULL DEFAULT '0' AFTER `ip_daily_view_limit`",
                'allow_download' => "`allow_download` tinyint(1) NOT NULL DEFAULT '1' AFTER `ip_daily_download_limit`",
                'show_owner' => "`show_owner` tinyint(1) NOT NULL DEFAULT '1' AFTER `allow_download`",
                'status' => "`status` tinyint(1) NOT NULL DEFAULT '1' AFTER `show_owner`",
                'admin_status' => "`admin_status` tinyint(1) NOT NULL DEFAULT '1' AFTER `status`",
                'admin_remark' => "`admin_remark` varchar(255) NOT NULL DEFAULT '' AFTER `admin_status`",
                'view_count' => "`view_count` int(10) unsigned NOT NULL DEFAULT '0' AFTER `admin_remark`",
                'download_count' => "`download_count` int(10) unsigned NOT NULL DEFAULT '0' AFTER `view_count`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($repositoryColumns as $name => $definition) {
                if (!self::hasColumn($repositoryTable, $name)) {
                    Database::execute("ALTER TABLE `" . $repositoryTable . "` ADD COLUMN " . $definition);
                }
            }
            $accessColumn = self::column($repositoryTable, 'access_type');
            if ($accessColumn) {
                $type = isset($accessColumn['Type']) ? $accessColumn['Type'] : (isset($accessColumn['type']) ? $accessColumn['type'] : '');
                if (stripos($type, 'password') === false || stripos($type, 'private') === false) {
                    Database::execute("ALTER TABLE `" . $repositoryTable . "` MODIFY COLUMN `access_type` enum('public','password','private') NOT NULL DEFAULT 'public'");
                }
            }

            $itemTable = Database::table('file_repository_items');
            if (!self::tableExists($itemTable)) {
                Database::execute("CREATE TABLE `" . $itemTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `repository_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `file_id` int(10) unsigned NOT NULL,
                    `visibility` enum('public','private') NOT NULL DEFAULT 'public',
                    `note` varchar(255) NOT NULL DEFAULT '',
                    `sort_order` int(11) NOT NULL DEFAULT '0',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_repo_file` (`repository_id`, `file_id`),
                    KEY `idx_user` (`user_id`),
                    KEY `idx_repo_visibility` (`repository_id`, `visibility`, `sort_order`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            $itemColumns = [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `repository_id`",
                'visibility' => "`visibility` enum('public','private') NOT NULL DEFAULT 'public' AFTER `file_id`",
                'note' => "`note` varchar(255) NOT NULL DEFAULT '' AFTER `visibility`",
                'sort_order' => "`sort_order` int(11) NOT NULL DEFAULT '0' AFTER `note`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($itemColumns as $name => $definition) {
                if (!self::hasColumn($itemTable, $name)) {
                    Database::execute("ALTER TABLE `" . $itemTable . "` ADD COLUMN " . $definition);
                }
            }
            $itemVisibilityColumn = self::column($itemTable, 'visibility');
            if ($itemVisibilityColumn) {
                $type = isset($itemVisibilityColumn['Type']) ? $itemVisibilityColumn['Type'] : (isset($itemVisibilityColumn['type']) ? $itemVisibilityColumn['type'] : '');
                if (stripos($type, 'private') === false) {
                    Database::execute("ALTER TABLE `" . $itemTable . "` MODIFY COLUMN `visibility` enum('public','private') NOT NULL DEFAULT 'public'");
                }
            }

            $logTable = Database::table('file_repository_logs');
            if (!self::tableExists($logTable)) {
                Database::execute("CREATE TABLE `" . $logTable . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `repository_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `file_id` int(10) unsigned DEFAULT NULL,
                    `action` enum('view','download','auth_success','auth_fail','blocked','expired') NOT NULL DEFAULT 'view',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `user_agent` varchar(255) NOT NULL DEFAULT '',
                    `referer` varchar(500) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_repo_time` (`repository_id`, `created_at`),
                    KEY `idx_user_time` (`user_id`, `created_at`),
                    KEY `idx_action` (`action`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            $logColumns = [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0' AFTER `repository_id`",
                'file_id' => "`file_id` int(10) unsigned DEFAULT NULL AFTER `user_id`",
                'action' => "`action` enum('view','download','auth_success','auth_fail','blocked','expired') NOT NULL DEFAULT 'view' AFTER `file_id`",
                'ip' => "`ip` varchar(45) NOT NULL DEFAULT '' AFTER `action`",
                'user_agent' => "`user_agent` varchar(255) NOT NULL DEFAULT '' AFTER `ip`",
                'referer' => "`referer` varchar(500) NOT NULL DEFAULT '' AFTER `user_agent`",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($logColumns as $name => $definition) {
                if (!self::hasColumn($logTable, $name)) {
                    Database::execute("ALTER TABLE `" . $logTable . "` ADD COLUMN " . $definition);
                }
            }
            $actionColumn = self::column($logTable, 'action');
            if ($actionColumn) {
                $type = isset($actionColumn['Type']) ? $actionColumn['Type'] : (isset($actionColumn['type']) ? $actionColumn['type'] : '');
                if (stripos($type, 'blocked') === false || stripos($type, 'expired') === false) {
                    Database::execute("ALTER TABLE `" . $logTable . "` MODIFY COLUMN `action` enum('view','download','auth_success','auth_fail','blocked','expired') NOT NULL DEFAULT 'view'");
                }
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('个人仓库表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('个人仓库表结构自动升级', $e);
        }
    }

    public static function ensureShareLogSchema()
    {
        try {
            $table = Database::table('file_share_logs');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `share_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `file_id` int(10) unsigned NOT NULL,
                    `action` enum('view','download','auth_fail','blocked','expired') NOT NULL DEFAULT 'view',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `user_agent` varchar(255) NOT NULL DEFAULT '',
                    `referer` varchar(500) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_share_time` (`share_id`, `created_at`),
                    KEY `idx_user_time` (`user_id`, `created_at`),
                    KEY `idx_action` (`action`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('文件分享日志表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('文件分享日志表结构自动升级', $e);
        }
    }

    public static function ensureSecuritySchema()
    {
        try {
            $table = Database::table('security_rate_limits');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `scope` varchar(40) NOT NULL,
                    `identity_hash` char(64) NOT NULL,
                    `identity_label` varchar(180) NOT NULL DEFAULT '',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `attempt_count` int(10) unsigned NOT NULL DEFAULT '0',
                    `locked_until` datetime DEFAULT NULL,
                    `first_attempt_at` datetime NOT NULL,
                    `last_attempt_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_scope_identity` (`scope`, `identity_hash`),
                    KEY `idx_locked_until` (`locked_until`),
                    KEY `idx_last_attempt` (`last_attempt_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('安全频率限制表自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('安全频率限制表自动升级', $e);
        }
    }

    public static function ensureUserPermissionSchema()
    {
        try {
            $table = Database::table('users');
            if (!self::tableExists($table)) {
                return false;
            }
            $columns = [
                'allow_image_override' => "`allow_image_override` tinyint(2) NOT NULL DEFAULT '-1' AFTER `package_id`",
                'allow_netdisk_override' => "`allow_netdisk_override` tinyint(2) NOT NULL DEFAULT '-1' AFTER `allow_image_override`",
            ];
            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('用户权限字段自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('用户权限字段自动升级', $e);
        }
    }

    public static function ensureStorageSecretEncryption()
    {
        try {
            $table = Database::table('storage_drivers');
            if (!self::tableExists($table) || !self::hasColumn($table, 'secret_key')) {
                return false;
            }
            self::ensureStorageDriverTypes();
            $rows = Database::fetchAll('SELECT id, secret_key FROM `' . $table . "` WHERE secret_key <> ''");
            foreach ($rows as $row) {
                if (!CryptoService::isEncrypted($row['secret_key'])) {
                    Database::execute(
                        'UPDATE `' . $table . '` SET secret_key = ?, updated_at = ? WHERE id = ?',
                        [CryptoService::encrypt($row['secret_key']), now(), $row['id']]
                    );
                }
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('存储密钥自动加密失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('存储密钥自动加密', $e);
        }
    }

    public static function ensureStorageDriverTypes()
    {
        try {
            $table = Database::table('storage_drivers');
            if (!self::tableExists($table) || !self::hasColumn($table, 'type')) {
                return false;
            }
            $column = self::column($table, 'type');
            $type = isset($column['Type']) ? $column['Type'] : (isset($column['type']) ? $column['type'] : '');
            $requiredTypes = ["'local'", "'oss'", "'cos'", "'kodo'", "'s3'", "'minio'", "'r2'", "'webdav'", "'bmtools'"];
            $needsUpgrade = false;
            foreach ($requiredTypes as $requiredType) {
                if (stripos($type, $requiredType) === false) {
                    $needsUpgrade = true;
                    break;
                }
            }
            if ($needsUpgrade) {
                Database::execute("ALTER TABLE `" . $table . "` MODIFY COLUMN `type` enum('local','oss','cos','kodo','s3','minio','r2','webdav','bmtools') NOT NULL");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('存储类型自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('存储类型自动升级', $e);
        }
    }

    public static function ensureStorageBackupSchema()
    {
        try {
            self::ensureStorageDriverTypes();

            $policyTable = Database::table('storage_backup_policies');
            if (!self::tableExists($policyTable)) {
                Database::execute("CREATE TABLE `" . $policyTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `name` varchar(120) NOT NULL,
                    `primary_storage_id` int(10) unsigned NOT NULL DEFAULT '0',
                    `backup_storage_ids` text,
                    `file_scope` enum('all','image','file') NOT NULL DEFAULT 'all',
                    `mode` enum('sync','queue') NOT NULL DEFAULT 'sync',
                    `failure_strategy` enum('ignore','warn','strict') NOT NULL DEFAULT 'warn',
                    `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
                    `sort_order` int(11) NOT NULL DEFAULT '0',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_enabled_scope` (`is_enabled`, `file_scope`),
                    KEY `idx_primary` (`primary_storage_id`),
                    KEY `idx_sort` (`sort_order`, `id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $policyColumns = [
                'name' => "`name` varchar(120) NOT NULL DEFAULT ''",
                'primary_storage_id' => "`primary_storage_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'backup_storage_ids' => "`backup_storage_ids` text",
                'file_scope' => "`file_scope` enum('all','image','file') NOT NULL DEFAULT 'all'",
                'mode' => "`mode` enum('sync','queue') NOT NULL DEFAULT 'sync'",
                'failure_strategy' => "`failure_strategy` enum('ignore','warn','strict') NOT NULL DEFAULT 'warn'",
                'is_enabled' => "`is_enabled` tinyint(1) NOT NULL DEFAULT '1'",
                'sort_order' => "`sort_order` int(11) NOT NULL DEFAULT '0'",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($policyColumns as $name => $definition) {
                if (!self::hasColumn($policyTable, $name)) {
                    Database::execute("ALTER TABLE `" . $policyTable . "` ADD COLUMN " . $definition);
                }
            }
            if (!self::hasIndex($policyTable, 'idx_enabled_scope')) {
                Database::execute("ALTER TABLE `" . $policyTable . "` ADD KEY `idx_enabled_scope` (`is_enabled`, `file_scope`)");
            }
            if (!self::hasIndex($policyTable, 'idx_primary')) {
                Database::execute("ALTER TABLE `" . $policyTable . "` ADD KEY `idx_primary` (`primary_storage_id`)");
            }

            $backupTable = Database::table('file_storage_backups');
            if (!self::tableExists($backupTable)) {
                Database::execute("CREATE TABLE `" . $backupTable . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `file_id` int(10) unsigned NOT NULL,
                    `storage_id` int(10) unsigned NOT NULL,
                    `policy_id` int(10) unsigned NOT NULL DEFAULT '0',
                    `object_key` varchar(500) NOT NULL DEFAULT '',
                    `file_url` varchar(800) NOT NULL DEFAULT '',
                    `status` enum('pending','success','failed','skipped','deleted') NOT NULL DEFAULT 'pending',
                    `error_message` text,
                    `attempts` int(10) unsigned NOT NULL DEFAULT '0',
                    `last_attempt_at` datetime DEFAULT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_file_storage_policy` (`file_id`, `storage_id`, `policy_id`),
                    KEY `idx_file` (`file_id`),
                    KEY `idx_storage` (`storage_id`),
                    KEY `idx_status` (`status`, `updated_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $backupColumns = [
                'file_id' => "`file_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'storage_id' => "`storage_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'policy_id' => "`policy_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'object_key' => "`object_key` varchar(500) NOT NULL DEFAULT ''",
                'file_url' => "`file_url` varchar(800) NOT NULL DEFAULT ''",
                'status' => "`status` enum('pending','success','failed','skipped','deleted') NOT NULL DEFAULT 'pending'",
                'error_message' => "`error_message` text",
                'attempts' => "`attempts` int(10) unsigned NOT NULL DEFAULT '0'",
                'last_attempt_at' => "`last_attempt_at` datetime DEFAULT NULL",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($backupColumns as $name => $definition) {
                if (!self::hasColumn($backupTable, $name)) {
                    Database::execute("ALTER TABLE `" . $backupTable . "` ADD COLUMN " . $definition);
                }
            }
            $statusColumn = self::column($backupTable, 'status');
            $statusType = $statusColumn ? (isset($statusColumn['Type']) ? $statusColumn['Type'] : (isset($statusColumn['type']) ? $statusColumn['type'] : '')) : '';
            if ($statusType && stripos($statusType, "'deleted'") === false) {
                Database::execute("ALTER TABLE `" . $backupTable . "` MODIFY COLUMN `status` enum('pending','success','failed','skipped','deleted') NOT NULL DEFAULT 'pending'");
            }
            if (!self::hasIndex($backupTable, 'uk_file_storage_policy')) {
                Database::execute("ALTER TABLE `" . $backupTable . "` ADD UNIQUE KEY `uk_file_storage_policy` (`file_id`, `storage_id`, `policy_id`)");
            }
            if (!self::hasIndex($backupTable, 'idx_file')) {
                Database::execute("ALTER TABLE `" . $backupTable . "` ADD KEY `idx_file` (`file_id`)");
            }
            if (!self::hasIndex($backupTable, 'idx_status')) {
                Database::execute("ALTER TABLE `" . $backupTable . "` ADD KEY `idx_status` (`status`, `updated_at`)");
            }

            return true;
        } catch (\Throwable $e) {
            Logger::error('Storage backup schema upgrade failed: ' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('多存储备份表结构自动升级', $e);
        }
    }

    public static function ensureApiSecuritySchema()
    {
        try {
            $table = Database::table('users');
            if (!self::tableExists($table)) {
                return false;
            }
            if (self::hasColumn($table, 'api_token')) {
                $column = self::column($table, 'api_token');
                $type = isset($column['Type']) ? $column['Type'] : (isset($column['type']) ? $column['type'] : '');
                if (stripos($type, 'varchar(255)') === false) {
                    Database::execute("ALTER TABLE `" . $table . "` MODIFY COLUMN `api_token` varchar(255) DEFAULT NULL");
                }
            }
            if (!self::hasColumn($table, 'email_verified_at')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `email_verified_at` datetime DEFAULT NULL AFTER `status`");
            }
            if (!self::hasColumn($table, 'api_token_hash')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `api_token_hash` char(64) DEFAULT NULL AFTER `api_token`");
            }
            if (!self::hasColumn($table, 'api_allowed_ips')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `api_allowed_ips` text AFTER `api_token_hash`");
            }
            if (!self::hasIndex($table, 'idx_api_token_hash')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_api_token_hash` (`api_token_hash`)");
            }
            $rows = Database::fetchAll('SELECT id, api_token, api_token_hash FROM `' . $table . "` WHERE api_token IS NOT NULL AND api_token <> '' AND (api_token_hash IS NULL OR api_token_hash = '' OR (api_token NOT LIKE 'enc:%' AND api_token NOT LIKE '%:%'))");
            foreach ($rows as $row) {
                $token = CryptoService::decrypt($row['api_token']);
                if ($token === '') {
                    continue;
                }
                $hash = hash('sha256', $token);
                $storedToken = CryptoService::isEncrypted($row['api_token']) ? $row['api_token'] : CryptoService::encrypt($token);
                if ($storedToken !== $row['api_token'] || (string) $row['api_token_hash'] !== $hash) {
                    Database::execute(
                        'UPDATE `' . $table . '` SET api_token = ?, api_token_hash = ?, updated_at = ? WHERE id = ?',
                        [$storedToken, $hash, now(), $row['id']]
                    );
                }
            }
            self::ensureApiAppSchema();
            return true;
        } catch (\Throwable $e) {
            Logger::error('API 安全字段自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('API 安全字段自动升级', $e);
        }
    }

    public static function ensureApiAppSchema()
    {
        try {
            $table = Database::table('api_apps');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `name` varchar(80) NOT NULL,
                    `token_hash` char(64) NOT NULL,
                    `token_cipher` varchar(255) DEFAULT NULL,
                    `scopes` varchar(255) NOT NULL DEFAULT 'upload,files,delete,quota',
                    `allowed_ips` text,
                    `status` tinyint(1) NOT NULL DEFAULT '1',
                    `last_used_at` datetime DEFAULT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_token_hash` (`token_hash`),
                    KEY `idx_user_status` (`user_id`, `status`),
                    KEY `idx_last_used` (`last_used_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $columns = [
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'name' => "`name` varchar(80) NOT NULL DEFAULT ''",
                'token_hash' => "`token_hash` char(64) NOT NULL DEFAULT ''",
                'token_cipher' => "`token_cipher` varchar(255) DEFAULT NULL",
                'scopes' => "`scopes` varchar(255) NOT NULL DEFAULT 'upload,files,delete,quota'",
                'allowed_ips' => "`allowed_ips` text",
                'status' => "`status` tinyint(1) NOT NULL DEFAULT '1'",
                'last_used_at' => "`last_used_at` datetime DEFAULT NULL",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ];
            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            if (!self::hasIndex($table, 'uk_token_hash')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD UNIQUE KEY `uk_token_hash` (`token_hash`)");
            }
            if (!self::hasIndex($table, 'idx_user_status')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_user_status` (`user_id`, `status`)");
            }
            if (!self::hasIndex($table, 'idx_last_used')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_last_used` (`last_used_at`)");
            }

            $logTable = Database::table('api_logs');
            if (self::tableExists($logTable)) {
                if (!self::hasColumn($logTable, 'app_id')) {
                    Database::execute("ALTER TABLE `" . $logTable . "` ADD COLUMN `app_id` bigint(20) unsigned DEFAULT NULL AFTER `user_id`");
                }
                if (!self::hasIndex($logTable, 'idx_app_time')) {
                    Database::execute("ALTER TABLE `" . $logTable . "` ADD KEY `idx_app_time` (`app_id`, `created_at`)");
                }
            }

            return true;
        } catch (\Throwable $e) {
            Logger::error('API 应用 Token 表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('API 应用 Token 表结构自动升级', $e);
        }
    }

    public static function ensureSensitiveSettingsEncrypted()
    {
        try {
            $table = Database::table('settings');
            if (!self::tableExists($table)) {
                return false;
            }
            $keys = ['email_password', 'alert_wecom_webhook', 'alert_dingtalk_webhook', 'alert_dingtalk_secret', 'alert_telegram_bot_token'];
            foreach ($keys as $key) {
                $row = Database::fetch('SELECT setting_value FROM `' . $table . '` WHERE setting_key = ? LIMIT 1', [$key]);
                if ($row && (string) $row['setting_value'] !== '' && !CryptoService::isEncrypted($row['setting_value'])) {
                    Database::execute(
                        'UPDATE `' . $table . '` SET setting_value = ?, updated_at = ? WHERE setting_key = ?',
                        [CryptoService::encrypt($row['setting_value']), now(), $key]
                    );
                }
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('敏感系统设置自动加密失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('敏感系统设置自动加密', $e);
        }
    }

    public static function ensureUserThemeSchema()
    {
        try {
            $table = Database::table('users');
            if (!self::tableExists($table)) {
                return false;
            }
            if (!self::hasColumn($table, 'frontend_theme_style')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `frontend_theme_style` varchar(20) NOT NULL DEFAULT '' AFTER `api_allowed_ips`");
            }
            if (!self::hasColumn($table, 'admin_theme_style')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `admin_theme_style` varchar(20) NOT NULL DEFAULT '' AFTER `frontend_theme_style`");
            }
            return true;
        } catch (\Throwable $e) {
            Logger::error('用户主题偏好字段自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('用户主题偏好字段自动升级', $e);
        }
    }

    public static function ensureSubsiteSchema()
    {
        try {
            $packageTable = Database::table('packages');
            if (self::tableExists($packageTable)) {
                if (!self::hasColumn($packageTable, 'allow_subsite')) {
                    Database::execute("ALTER TABLE `" . $packageTable . "` ADD COLUMN `allow_subsite` tinyint(1) NOT NULL DEFAULT '0' AFTER `allow_share`");
                }
                if (!self::hasColumn($packageTable, 'subsite_limit')) {
                    Database::execute("ALTER TABLE `" . $packageTable . "` ADD COLUMN `subsite_limit` int(10) unsigned NOT NULL DEFAULT '1' AFTER `allow_subsite`");
                }
            }

            $table = Database::table('subsites');
            if (!self::tableExists($table)) {
                Database::execute("CREATE TABLE `" . $table . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int(10) unsigned NOT NULL,
                    `name` varchar(80) NOT NULL,
                    `slug` varchar(40) NOT NULL,
                    `platform_domain` varchar(180) NOT NULL,
                    `custom_domain` varchar(180) NOT NULL DEFAULT '',
                    `custom_domain_status` enum('none','pending','verified','failed') NOT NULL DEFAULT 'none',
                    `verification_token` varchar(80) NOT NULL DEFAULT '',
                    `title` varchar(120) NOT NULL DEFAULT '',
                    `subtitle` varchar(240) NOT NULL DEFAULT '',
                    `logo` varchar(800) NOT NULL DEFAULT '',
                    `theme_color` varchar(20) NOT NULL DEFAULT '#2563EB',
                    `hero_title` varchar(160) NOT NULL DEFAULT '',
                    `hero_description` varchar(360) NOT NULL DEFAULT '',
                    `announcement` varchar(500) NOT NULL DEFAULT '',
                    `contact_email` varchar(120) NOT NULL DEFAULT '',
                    `icp_text` varchar(120) NOT NULL DEFAULT '',
                    `status` enum('pending','active','suspended','rejected') NOT NULL DEFAULT 'pending',
                    `is_default` tinyint(1) NOT NULL DEFAULT '0',
                    `view_count` int(10) unsigned NOT NULL DEFAULT '0',
                    `last_viewed_at` datetime DEFAULT NULL,
                    `domain_check_result` text,
                    `domain_checked_at` datetime DEFAULT NULL,
                    `admin_remark` varchar(255) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_slug` (`slug`),
                    UNIQUE KEY `uk_platform_domain` (`platform_domain`),
                    KEY `idx_user_status` (`user_id`, `status`),
                    KEY `idx_custom_domain` (`custom_domain`),
                    KEY `idx_status_created` (`status`, `created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            if (self::tableExists($table)) {
                $columns = [
                    'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0'",
                    'name' => "`name` varchar(80) NOT NULL DEFAULT ''",
                    'slug' => "`slug` varchar(40) NOT NULL DEFAULT ''",
                    'platform_domain' => "`platform_domain` varchar(180) NOT NULL DEFAULT ''",
                    'custom_domain' => "`custom_domain` varchar(180) NOT NULL DEFAULT ''",
                    'custom_domain_status' => "`custom_domain_status` enum('none','pending','verified','failed') NOT NULL DEFAULT 'none'",
                    'verification_token' => "`verification_token` varchar(80) NOT NULL DEFAULT ''",
                    'title' => "`title` varchar(120) NOT NULL DEFAULT ''",
                    'subtitle' => "`subtitle` varchar(240) NOT NULL DEFAULT ''",
                    'logo' => "`logo` varchar(800) NOT NULL DEFAULT ''",
                    'theme_color' => "`theme_color` varchar(20) NOT NULL DEFAULT '#2563EB'",
                    'hero_title' => "`hero_title` varchar(160) NOT NULL DEFAULT ''",
                    'hero_description' => "`hero_description` varchar(360) NOT NULL DEFAULT ''",
                    'announcement' => "`announcement` varchar(500) NOT NULL DEFAULT ''",
                    'contact_email' => "`contact_email` varchar(120) NOT NULL DEFAULT ''",
                    'icp_text' => "`icp_text` varchar(120) NOT NULL DEFAULT ''",
                    'status' => "`status` enum('pending','active','suspended','rejected') NOT NULL DEFAULT 'pending'",
                    'is_default' => "`is_default` tinyint(1) NOT NULL DEFAULT '0'",
                    'view_count' => "`view_count` int(10) unsigned NOT NULL DEFAULT '0'",
                    'last_viewed_at' => "`last_viewed_at` datetime DEFAULT NULL",
                    'domain_check_result' => "`domain_check_result` text",
                    'domain_checked_at' => "`domain_checked_at` datetime DEFAULT NULL",
                    'admin_remark' => "`admin_remark` varchar(255) NOT NULL DEFAULT ''",
                    'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                    'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                ];
                foreach ($columns as $name => $definition) {
                    if (!self::hasColumn($table, $name)) {
                        Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                    }
                }
                if (!self::hasIndex($table, 'uk_slug')) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD UNIQUE KEY `uk_slug` (`slug`)");
                }
                if (!self::hasIndex($table, 'uk_platform_domain')) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD UNIQUE KEY `uk_platform_domain` (`platform_domain`)");
                }
                if (!self::hasIndex($table, 'idx_user_status')) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_user_status` (`user_id`, `status`)");
                }
                if (!self::hasIndex($table, 'idx_custom_domain')) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_custom_domain` (`custom_domain`)");
                }
            }

            $logTable = Database::table('subsite_access_logs');
            if (!self::tableExists($logTable)) {
                Database::execute("CREATE TABLE `" . $logTable . "` (
                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    `subsite_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `host` varchar(180) NOT NULL DEFAULT '',
                    `path` varchar(500) NOT NULL DEFAULT '',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `user_agent` varchar(255) NOT NULL DEFAULT '',
                    `referer` varchar(500) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_subsite_time` (`subsite_id`, `created_at`),
                    KEY `idx_user_time` (`user_id`, `created_at`),
                    KEY `idx_host_time` (`host`, `created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            self::ensureSettingDefault('subsite_enabled', '1');
            self::ensureSettingDefault('subsite_domain_suffixes', '');
            self::ensureSettingDefault('subsite_cname_target', '');
            self::ensureSettingDefault('subsite_https_mode', 'auto');
            self::ensureSettingDefault('subsite_custom_domain_enabled', '1');
            self::ensureSettingDefault('subsite_requires_review', '0');
            self::ensureSettingDefault('subsite_default_limit', '1');
            self::ensureSettingDefault('subsite_reserved_slugs', 'admin,api,www,cdn,static,status,login,register,assets,uploads,files,share');

            return true;
        } catch (\Throwable $e) {
            Logger::error('用户分站表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('用户分站表结构自动升级', $e);
        }
    }

    public static function ensureTeamSpaceSchema()
    {
        try {
            $teamTable = Database::table('teams');
            if (!self::tableExists($teamTable)) {
                Database::execute("CREATE TABLE `" . $teamTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `owner_id` int(10) unsigned NOT NULL,
                    `name` varchar(80) NOT NULL,
                    `slug` varchar(40) NOT NULL,
                    `description` varchar(500) NOT NULL DEFAULT '',
                    `avatar` varchar(800) NOT NULL DEFAULT '',
                    `status` enum('active','archived','deleted') NOT NULL DEFAULT 'active',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_slug` (`slug`),
                    KEY `idx_owner_status` (`owner_id`, `status`),
                    KEY `idx_status_updated` (`status`, `updated_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            self::ensureColumns($teamTable, [
                'owner_id' => "`owner_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'name' => "`name` varchar(80) NOT NULL DEFAULT ''",
                'slug' => "`slug` varchar(40) NOT NULL DEFAULT ''",
                'description' => "`description` varchar(500) NOT NULL DEFAULT ''",
                'avatar' => "`avatar` varchar(800) NOT NULL DEFAULT ''",
                'status' => "`status` enum('active','archived','deleted') NOT NULL DEFAULT 'active'",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ]);
            if (self::tableExists($teamTable)) {
                if (!self::hasIndex($teamTable, 'uk_slug')) {
                    Database::execute("ALTER TABLE `" . $teamTable . "` ADD UNIQUE KEY `uk_slug` (`slug`)");
                }
                if (!self::hasIndex($teamTable, 'idx_owner_status')) {
                    Database::execute("ALTER TABLE `" . $teamTable . "` ADD KEY `idx_owner_status` (`owner_id`, `status`)");
                }
            }

            $memberTable = Database::table('team_members');
            if (!self::tableExists($memberTable)) {
                Database::execute("CREATE TABLE `" . $memberTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `team_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `role` enum('owner','admin','member','viewer') NOT NULL DEFAULT 'member',
                    `title` varchar(80) NOT NULL DEFAULT '',
                    `joined_at` datetime NOT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_team_user` (`team_id`, `user_id`),
                    KEY `idx_user_role` (`user_id`, `role`),
                    KEY `idx_team_role` (`team_id`, `role`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            self::ensureColumns($memberTable, [
                'team_id' => "`team_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'user_id' => "`user_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'role' => "`role` enum('owner','admin','member','viewer') NOT NULL DEFAULT 'member'",
                'title' => "`title` varchar(80) NOT NULL DEFAULT ''",
                'joined_at' => "`joined_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ]);
            if (self::tableExists($memberTable)) {
                if (!self::hasIndex($memberTable, 'uk_team_user')) {
                    Database::execute("ALTER TABLE `" . $memberTable . "` ADD UNIQUE KEY `uk_team_user` (`team_id`, `user_id`)");
                }
                if (!self::hasIndex($memberTable, 'idx_user_role')) {
                    Database::execute("ALTER TABLE `" . $memberTable . "` ADD KEY `idx_user_role` (`user_id`, `role`)");
                }
            }

            $inviteTable = Database::table('team_invites');
            if (!self::tableExists($inviteTable)) {
                Database::execute("CREATE TABLE `" . $inviteTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `team_id` int(10) unsigned NOT NULL,
                    `invited_user_id` int(10) unsigned DEFAULT NULL,
                    `invited_email` varchar(120) NOT NULL DEFAULT '',
                    `role` enum('admin','member','viewer') NOT NULL DEFAULT 'member',
                    `token` char(64) NOT NULL,
                    `status` enum('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending',
                    `message` varchar(300) NOT NULL DEFAULT '',
                    `created_by` int(10) unsigned NOT NULL,
                    `accepted_at` datetime DEFAULT NULL,
                    `expires_at` datetime NOT NULL,
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_token` (`token`),
                    KEY `idx_team_status` (`team_id`, `status`),
                    KEY `idx_user_status` (`invited_user_id`, `status`),
                    KEY `idx_email_status` (`invited_email`, `status`),
                    KEY `idx_expires` (`expires_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            self::ensureColumns($inviteTable, [
                'team_id' => "`team_id` int(10) unsigned NOT NULL DEFAULT '0'",
                'invited_user_id' => "`invited_user_id` int(10) unsigned DEFAULT NULL",
                'invited_email' => "`invited_email` varchar(120) NOT NULL DEFAULT ''",
                'role' => "`role` enum('admin','member','viewer') NOT NULL DEFAULT 'member'",
                'token' => "`token` char(64) NOT NULL DEFAULT ''",
                'status' => "`status` enum('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending'",
                'message' => "`message` varchar(300) NOT NULL DEFAULT ''",
                'created_by' => "`created_by` int(10) unsigned NOT NULL DEFAULT '0'",
                'accepted_at' => "`accepted_at` datetime DEFAULT NULL",
                'expires_at' => "`expires_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'created_at' => "`created_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
                'updated_at' => "`updated_at` datetime NOT NULL DEFAULT '1970-01-01 00:00:00'",
            ]);
            if (self::tableExists($inviteTable)) {
                if (!self::hasIndex($inviteTable, 'uk_token')) {
                    Database::execute("ALTER TABLE `" . $inviteTable . "` ADD UNIQUE KEY `uk_token` (`token`)");
                }
                if (!self::hasIndex($inviteTable, 'idx_team_status')) {
                    Database::execute("ALTER TABLE `" . $inviteTable . "` ADD KEY `idx_team_status` (`team_id`, `status`)");
                }
                if (!self::hasIndex($inviteTable, 'idx_user_status')) {
                    Database::execute("ALTER TABLE `" . $inviteTable . "` ADD KEY `idx_user_status` (`invited_user_id`, `status`)");
                }
            }

            return true;
        } catch (\Throwable $e) {
            Logger::error('团队空间表结构自动升级失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('团队空间表结构自动升级', $e);
        }
    }

    public static function repairAll()
    {
        self::$standardSchemaReadyCache = null;
        $results = [];

        $schema = self::ensureBaseSchemaTables();
        $schemaOk = !empty($schema['ok']) && empty($schema['missing_after']) && empty($schema['column_errors']);
        $schemaMissingTableCount = isset($schema['missing_after']) && is_array($schema['missing_after']) ? count($schema['missing_after']) : 0;
        $schemaColumnErrorCount = isset($schema['column_errors']) && is_array($schema['column_errors']) ? count($schema['column_errors']) : 0;
        $results[] = [
            'key' => 'base_schema',
            'label' => '基础数据表',
            'ok' => $schemaOk,
            'message' => $schemaOk
                ? '基础数据表已检查，补齐 ' . (int) (isset($schema['created_count']) ? $schema['created_count'] : 0) . ' 张缺失表。'
                : '基础数据表仍有 ' . $schemaMissingTableCount . ' 张表、' . $schemaColumnErrorCount . ' 个字段未完成。' . ($schemaMissingTableCount > 0 ? '缺失表：' . implode(', ', array_slice($schema['missing_after'], 0, 8)) : ''),
        ];

        foreach (self::upgradeTasks() as $task) {
            try {
                $ok = (bool) call_user_func($task['callback']);
                $results[] = [
                    'key' => $task['key'],
                    'label' => $task['label'],
                    'ok' => $ok,
                    'message' => $ok ? '已完成' : '未完成，请检查相关基础表、字段或数据库权限。',
                ];
            } catch (\Throwable $e) {
                Logger::error('数据库结构修复任务失败：' . $task['key'] . ' / ' . $e->getMessage());
                $results[] = [
                    'key' => $task['key'],
                    'label' => $task['label'],
                    'ok' => false,
                    'message' => $e->getMessage(),
                ];
            }
        }

        $defaults = self::ensureBaseDefaultRows();
        $results[] = [
            'key' => 'base_defaults',
            'label' => '默认配置与基础数据',
            'ok' => !empty($defaults['ok']),
            'message' => !empty($defaults['ok'])
                ? '默认配置已检查，补齐 ' . (int) (isset($defaults['created_count']) ? $defaults['created_count'] : 0) . ' 条基础记录。'
                : (isset($defaults['message']) ? $defaults['message'] : '默认配置检查失败。'),
        ];

        $autoSqlRepair = [
            'executed_count' => 0,
            'failed_count' => 0,
            'results' => [],
        ];
        for ($pass = 1; $pass <= 2; $pass++) {
            $passAudit = self::inspectLiveSchema();
            $repairSql = isset($passAudit['repair_sql']) && is_array($passAudit['repair_sql']) ? $passAudit['repair_sql'] : [];
            if (empty($repairSql)) {
                break;
            }
            $passRepair = self::executeRepairSqlStatements($repairSql, $pass);
            $autoSqlRepair['executed_count'] += $passRepair['executed_count'];
            $autoSqlRepair['failed_count'] += $passRepair['failed_count'];
            $autoSqlRepair['results'] = array_merge($autoSqlRepair['results'], $passRepair['results']);
            if ($passRepair['failed_count'] > 0) {
                break;
            }
        }
        if ($autoSqlRepair['executed_count'] > 0 || $autoSqlRepair['failed_count'] > 0) {
            $results[] = [
                'key' => 'auto_repair_sql',
                'label' => '缺失表字段自动补齐',
                'ok' => $autoSqlRepair['failed_count'] === 0,
                'message' => '自动执行补齐 SQL ' . $autoSqlRepair['executed_count'] . ' 条，失败 ' . $autoSqlRepair['failed_count'] . ' 条。',
            ];
        }

        $schemaUnresolvedCount = $schemaMissingTableCount + $schemaColumnErrorCount;
        $finalAudit = self::inspectLiveSchema();
        $finalSchemaReady = !empty($finalAudit['ok']);
        if ($finalSchemaReady) {
            self::$standardSchemaReadyCache = true;
            foreach ($results as &$result) {
                if (empty($result['ok'])) {
                    $originalMessage = isset($result['message']) ? (string) $result['message'] : '';
                    $result['ok'] = true;
                    $result['message'] = '最终数据库结构巡检已匹配，本项不再阻塞页面。' . ($originalMessage !== '' ? '原任务返回：' . $originalMessage : '');
                    $result['soft_ok'] = true;
                }
            }
            unset($result);
            $schemaUnresolvedCount = 0;
        }

        $successCount = 0;
        $failCount = 0;
        foreach ($results as $result) {
            if (!empty($result['ok'])) {
                $successCount++;
            } else {
                $failCount++;
            }
        }

        return [
            'ok' => ($failCount === 0 && empty($schema['missing_after'])) || $finalSchemaReady,
            'schema' => $finalSchemaReady ? $finalAudit : $schema,
            'defaults' => $defaults,
            'results' => $results,
            'privileges' => self::databasePrivilegeDiagnostics(true),
            'success_count' => $successCount,
            'fail_count' => $failCount,
            'schema_unresolved_count' => $schemaUnresolvedCount,
            'unresolved_count' => $schemaUnresolvedCount + $failCount,
            'missing_tables' => $finalSchemaReady ? [] : (isset($schema['missing_after']) ? $schema['missing_after'] : []),
            'final_schema_ready' => $finalSchemaReady,
            'auto_sql_repair' => $autoSqlRepair,
            'ran_at' => now(),
        ];
    }

    public static function inspectLiveSchema()
    {
        $result = [
            'ok' => false,
            'prefix' => Database::prefix(),
            'expected_table_count' => 0,
            'current_database_table_count' => 0,
            'current_prefixed_table_count' => 0,
            'existing_table_count' => 0,
            'missing_table_count' => 0,
            'missing_tables' => [],
            'extra_prefixed_tables' => [],
            'missing_column_count' => 0,
            'missing_columns' => [],
            'code_used_table_count' => 0,
            'code_missing_table_count' => 0,
            'code_missing_tables' => [],
            'repair_sql' => [],
            'privileges' => [],
            'checked_at' => now(),
            'message' => '',
        ];

        try {
            $schemaPath = APP_ROOT . '/database/schema.sql';
            if (!is_file($schemaPath)) {
                $result['message'] = 'database/schema.sql not found.';
                return $result;
            }

            $schema = file_get_contents($schemaPath);
            if ($schema === false || trim($schema) === '') {
                $result['message'] = 'database/schema.sql is empty or unreadable.';
                return $result;
            }

            $definitions = self::schemaTableDefinitions($schema);
            $columnDefinitions = self::schemaTableColumnDefinitions($schema);
            $expectedTables = array_keys($definitions);
            $expectedFullTables = [];
            foreach ($expectedTables as $table) {
                $expectedFullTables[$table] = Database::table($table);
            }

            $pdo = Database::getInstance();
            $allRows = Database::fetchAll(
                'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME'
            );
            $liveTables = [];
            foreach ($allRows as $row) {
                $liveTables[] = isset($row['TABLE_NAME']) ? $row['TABLE_NAME'] : reset($row);
            }

            $prefix = Database::prefix();
            $prefixedTables = [];
            foreach ($liveTables as $tableName) {
                if ($prefix === '' || strpos($tableName, $prefix) === 0) {
                    $prefixedTables[] = $tableName;
                }
            }

            $missingTables = [];
            $missingColumns = [];
            foreach ($expectedFullTables as $shortName => $fullName) {
                if (!in_array($fullName, $liveTables, true)) {
                    $missingTables[] = $fullName;
                    continue;
                }

                $columnRows = Database::fetchAll('SHOW COLUMNS FROM `' . self::quoteIdentifier($fullName) . '`');
                $liveColumns = [];
                foreach ($columnRows as $columnRow) {
                    if (isset($columnRow['Field'])) {
                        $liveColumns[] = $columnRow['Field'];
                    }
                }

                foreach ($definitions[$shortName] as $column) {
                    if (!in_array($column, $liveColumns, true)) {
                        $missingColumns[] = [
                            'table' => $fullName,
                            'column' => $column,
                        ];
                    }
                }
            }

            $codeTables = self::codeReferencedTables();
            $codeMissingTables = [];
            foreach ($codeTables as $table) {
                $fullName = Database::table($table);
                if (!in_array($fullName, $liveTables, true)) {
                    $codeMissingTables[] = $fullName;
                }
            }

            $result['expected_table_count'] = count($expectedTables);
            $result['current_database_table_count'] = count($liveTables);
            $result['current_prefixed_table_count'] = count($prefixedTables);
            $result['missing_tables'] = $missingTables;
            $result['missing_table_count'] = count($missingTables);
            $result['existing_table_count'] = $result['expected_table_count'] - $result['missing_table_count'];
            $result['extra_prefixed_tables'] = array_values(array_diff($prefixedTables, array_values($expectedFullTables)));
            $result['missing_columns'] = $missingColumns;
            $result['missing_column_count'] = count($missingColumns);
            $result['code_used_table_count'] = count($codeTables);
            $result['code_missing_tables'] = $codeMissingTables;
            $result['code_missing_table_count'] = count($codeMissingTables);
            $result['repair_sql'] = self::schemaRepairSql($schema, $expectedFullTables, $missingTables, $missingColumns, $columnDefinitions);
            $result['privileges'] = self::databasePrivilegeDiagnostics(false);
            $result['ok'] = $result['missing_table_count'] === 0 && $result['missing_column_count'] === 0 && $result['code_missing_table_count'] === 0;
            $result['message'] = $result['ok'] ? 'schema matched' : 'schema mismatch';
        } catch (\Throwable $e) {
            Logger::error('Database schema inspect failed: ' . $e->getMessage());
            $result['message'] = $e->getMessage();
            $result['privileges'] = self::databasePrivilegeDiagnostics(false);
        }

        return $result;
    }

    protected static function upgradeTasks()
    {
        return [
            ['key' => 'marketing', 'label' => '营销活动与优惠券', 'callback' => [self::class, 'ensureMarketingSchema']],
            ['key' => 'recharge_order_constraint', 'label' => '充值订单唯一约束', 'callback' => [self::class, 'ensureRechargeOrderConstraint']],
            ['key' => 'redeem_cards', 'label' => '卡密兑换', 'callback' => [self::class, 'ensureRedeemCardSchema']],
            ['key' => 'monitor', 'label' => '服务器监控', 'callback' => [self::class, 'ensureMonitorSchema']],
            ['key' => 'server_ops', 'label' => '服务器管家与 SSH 终端', 'callback' => [self::class, 'ensureServerOpsSchema']],
            ['key' => 'announcements', 'label' => '公告与文档', 'callback' => [self::class, 'ensureAnnouncementSchema']],
            ['key' => 'file_logs', 'label' => '文件上传下载记录', 'callback' => [self::class, 'ensureFileLogSchema']],
            ['key' => 'upload_failures', 'label' => '上传失败记录', 'callback' => [self::class, 'ensureUploadFailureSchema']],
            ['key' => 'repositories', 'label' => '分享仓库', 'callback' => [self::class, 'ensureRepositorySchema']],
            ['key' => 'share_logs', 'label' => '分享访问日志', 'callback' => [self::class, 'ensureShareLogSchema']],
            ['key' => 'security', 'label' => '安全限频', 'callback' => [self::class, 'ensureSecuritySchema']],
            ['key' => 'user_permissions', 'label' => '用户功能权限', 'callback' => [self::class, 'ensureUserPermissionSchema']],
            ['key' => 'storage_types', 'label' => '第三方存储类型', 'callback' => [self::class, 'ensureStorageDriverTypes']],
            ['key' => 'storage_secret', 'label' => '存储密钥加密', 'callback' => [self::class, 'ensureStorageSecretEncryption']],
            ['key' => 'storage_backups', 'label' => '多存储备份', 'callback' => [self::class, 'ensureStorageBackupSchema']],
            ['key' => 'api_security', 'label' => 'API 安全字段', 'callback' => [self::class, 'ensureApiSecuritySchema']],
            ['key' => 'api_apps', 'label' => '开放平台应用 Token', 'callback' => [self::class, 'ensureApiAppSchema']],
            ['key' => 'sensitive_settings', 'label' => '敏感配置加密', 'callback' => [self::class, 'ensureSensitiveSettingsEncrypted']],
            ['key' => 'user_themes', 'label' => '用户主题偏好', 'callback' => [self::class, 'ensureUserThemeSchema']],
            ['key' => 'subsites', 'label' => '用户分站', 'callback' => [self::class, 'ensureSubsiteSchema']],
            ['key' => 'team_spaces', 'label' => '团队空间', 'callback' => [self::class, 'ensureTeamSpaceSchema']],
            ['key' => 'upload_limits', 'label' => '上传限制默认配置', 'callback' => [self::class, 'ensureUploadLimitDefaults']],
        ];
    }

    protected static function ensureBaseSchemaTables()
    {
        $path = APP_ROOT . '/database/schema.sql';
        $result = [
            'ok' => false,
            'created_count' => 0,
            'created_column_count' => 0,
            'executed_count' => 0,
            'missing_before' => [],
            'missing_after' => [],
            'created_tables' => [],
            'created_columns' => [],
            'column_errors' => [],
            'message' => '',
        ];

        try {
            if (!is_file($path)) {
                $result['message'] = 'database/schema.sql 不存在。';
                return $result;
            }

            $schema = file_get_contents($path);
            if ($schema === false || trim($schema) === '') {
                $result['message'] = 'database/schema.sql 为空或无法读取。';
                return $result;
            }

            $baseTables = self::schemaBaseTables($schema);
            $result['missing_before'] = self::missingBaseTables($baseTables);

            $sql = str_replace('__PREFIX__', Database::prefix(), $schema);
            $pdo = Database::getInstance();
            $pdo->exec('SET NAMES utf8mb4');
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            try {
                foreach (self::splitSql($sql) as $statement) {
                    if (!preg_match('/^CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\b/i', $statement)) {
                        continue;
                    }
                    $pdo->exec($statement);
                    $result['executed_count']++;
                }
            } finally {
                $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            }

            $columnRepair = self::repairBaseSchemaColumns($schema);
            $result['created_columns'] = $columnRepair['created_columns'];
            $result['created_column_count'] = count($result['created_columns']);
            $result['column_errors'] = $columnRepair['errors'];

            $result['missing_after'] = self::missingBaseTables($baseTables);
            $result['created_tables'] = array_values(array_diff($result['missing_before'], $result['missing_after']));
            $result['created_count'] = count($result['created_tables']);
            $result['ok'] = empty($result['missing_after']) && empty($result['column_errors']);
            $result['message'] = $result['ok'] ? '基础数据表检查完成。' : '仍有基础数据表缺失。';
            return $result;
        } catch (\Throwable $e) {
            Logger::error('基础数据表一键修复失败：' . $e->getMessage());
            $result['message'] = $e->getMessage();
            try {
                Database::getInstance()->exec('SET FOREIGN_KEY_CHECKS=1');
            } catch (\Throwable $ignored) {
            }
            return $result;
        }
    }

    protected static function schemaBaseTables($schema)
    {
        preg_match_all('/CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`__PREFIX__([A-Za-z0-9_]+)`/i', $schema, $matches);
        if (empty($matches[1])) {
            throw new \RuntimeException('database/schema.sql 中没有可识别的建表语句。');
        }
        return array_values(array_unique($matches[1]));
    }

    protected static function schemaTableDefinitions($schema)
    {
        preg_match_all(
            '/CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`__PREFIX__([A-Za-z0-9_]+)`\s*\(([\s\S]*?)\)\s*ENGINE=/i',
            $schema,
            $matches,
            PREG_SET_ORDER
        );
        if (!$matches) {
            throw new \RuntimeException('database/schema.sql has no recognizable CREATE TABLE statements.');
        }

        $definitions = [];
        foreach ($matches as $match) {
            $columns = [];
            foreach (preg_split('/\r?\n/', $match[2]) as $line) {
                if (preg_match('/^\s*`([A-Za-z0-9_]+)`\s+/', $line, $columnMatch)) {
                    $columns[] = $columnMatch[1];
                }
            }
            $definitions[$match[1]] = array_values(array_unique($columns));
        }
        return $definitions;
    }

    protected static function schemaTableColumnDefinitions($schema)
    {
        preg_match_all(
            '/CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`__PREFIX__([A-Za-z0-9_]+)`\s*\(([\s\S]*?)\)\s*ENGINE=/i',
            $schema,
            $matches,
            PREG_SET_ORDER
        );
        if (!$matches) {
            throw new \RuntimeException('database/schema.sql has no recognizable CREATE TABLE statements.');
        }

        $definitions = [];
        foreach ($matches as $match) {
            $columns = [];
            foreach (preg_split('/\r?\n/', $match[2]) as $line) {
                $line = trim($line);
                if (!preg_match('/^`([A-Za-z0-9_]+)`\s+(.+?)(,)?$/', $line, $columnMatch)) {
                    continue;
                }
                $definition = '`' . $columnMatch[1] . '` ' . rtrim($columnMatch[2], ',');
                $columns[$columnMatch[1]] = $definition;
            }
            $definitions[$match[1]] = $columns;
        }
        return $definitions;
    }

    protected static function repairBaseSchemaColumns($schema)
    {
        $result = [
            'created_columns' => [],
            'errors' => [],
        ];

        $definitions = self::schemaTableColumnDefinitions($schema);
        foreach ($definitions as $shortTable => $columns) {
            $table = Database::table($shortTable);
            if (!self::tableExists($table)) {
                continue;
            }

            foreach ($columns as $column => $definition) {
                if (self::hasColumn($table, $column)) {
                    continue;
                }

                try {
                    Database::execute(
                        'ALTER TABLE `' . self::quoteIdentifier($table) . '` ADD COLUMN ' . self::normalRepairColumnDefinition($definition)
                    );
                    $result['created_columns'][] = $table . '.' . $column;
                } catch (\Throwable $e) {
                    $result['errors'][] = [
                        'table' => $table,
                        'column' => $column,
                        'message' => $e->getMessage(),
                    ];
                    Logger::error('Base schema column repair failed: ' . $table . '.' . $column . ' / ' . $e->getMessage());
                }
            }
        }

        return $result;
    }

    protected static function normalRepairColumnDefinition($definition)
    {
        $definition = trim($definition);
        if (stripos($definition, 'AUTO_INCREMENT') !== false) {
            return $definition;
        }
        if (preg_match('/^`[^`]+`\s+(tinytext|text|mediumtext|longtext)\b/i', $definition) && stripos($definition, 'NOT NULL') !== false) {
            return preg_replace('/\s+NOT\s+NULL\b/i', ' NULL', $definition, 1);
        }
        if (stripos($definition, 'NOT NULL') === false || preg_match('/\bDEFAULT\b/i', $definition)) {
            return $definition;
        }

        if (preg_match('/^`[^`]+`\s+(tinyint|smallint|mediumint|int|bigint|decimal|float|double)\b/i', $definition)) {
            return $definition . " DEFAULT '0'";
        }
        if (preg_match('/^`[^`]+`\s+(varchar|char)\b/i', $definition)) {
            return $definition . " DEFAULT ''";
        }
        if (preg_match('/^`[^`]+`\s+enum\(\s*\'([^\']*)\'/i', $definition, $match)) {
            return $definition . " DEFAULT '" . str_replace("'", "''", $match[1]) . "'";
        }
        if (preg_match('/^`[^`]+`\s+date\b/i', $definition)) {
            return $definition . " DEFAULT '1970-01-01'";
        }
        if (preg_match('/^`[^`]+`\s+(datetime|timestamp)\b/i', $definition)) {
            return $definition . " DEFAULT '1970-01-01 00:00:00'";
        }

        return $definition;
    }

    protected static function schemaRepairSql($schema, array $expectedFullTables, array $missingTables, array $missingColumns, array $columnDefinitions)
    {
        $sql = [];
        $missingLookup = array_fill_keys($missingTables, true);
        foreach (self::schemaTableCreateStatements($schema) as $shortTable => $statement) {
            $fullTable = isset($expectedFullTables[$shortTable]) ? $expectedFullTables[$shortTable] : Database::table($shortTable);
            if (!isset($missingLookup[$fullTable])) {
                continue;
            }
            $sql[] = rtrim(str_replace('__PREFIX__', Database::prefix(), $statement), ';') . ';';
        }

        foreach ($missingColumns as $item) {
            $fullTable = isset($item['table']) ? (string) $item['table'] : '';
            $column = isset($item['column']) ? (string) $item['column'] : '';
            $shortTable = self::stripPrefixFromTable($fullTable);
            if ($fullTable === '' || $column === '' || !isset($columnDefinitions[$shortTable][$column])) {
                continue;
            }
            $definition = self::normalRepairColumnDefinition($columnDefinitions[$shortTable][$column]);
            $sql[] = 'ALTER TABLE `' . self::quoteIdentifier($fullTable) . '` ADD COLUMN ' . $definition . ';';
        }

        return array_values(array_unique($sql));
    }

    protected static function executeRepairSqlStatements(array $statements, $pass = 1)
    {
        $result = [
            'executed_count' => 0,
            'failed_count' => 0,
            'results' => [],
        ];
        $pdo = Database::getInstance();
        foreach (array_values(array_unique($statements)) as $statement) {
            $statement = trim((string) $statement);
            if ($statement === '') {
                continue;
            }
            try {
                $pdo->exec($statement);
                $result['executed_count']++;
                $result['results'][] = [
                    'pass' => (int) $pass,
                    'ok' => true,
                    'sql' => $statement,
                    'message' => 'ok',
                ];
            } catch (\Throwable $e) {
                $result['failed_count']++;
                $result['results'][] = [
                    'pass' => (int) $pass,
                    'ok' => false,
                    'sql' => $statement,
                    'message' => $e->getMessage(),
                ];
                Logger::error('自动补齐数据库结构 SQL 失败：pass=' . (int) $pass . ' / ' . $e->getMessage() . ' / SQL=' . $statement);
            }
        }
        return $result;
    }

    protected static function schemaTableCreateStatements($schema)
    {
        preg_match_all(
            '/(CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`__PREFIX__([A-Za-z0-9_]+)`\s*\([\s\S]*?\)\s*ENGINE=[^;]+;?)/i',
            $schema,
            $matches,
            PREG_SET_ORDER
        );
        $statements = [];
        foreach ($matches as $match) {
            $statements[$match[2]] = $match[1];
        }
        return $statements;
    }

    protected static function stripPrefixFromTable($fullTable)
    {
        $prefix = Database::prefix();
        if ($prefix !== '' && strpos($fullTable, $prefix) === 0) {
            return substr($fullTable, strlen($prefix));
        }
        return $fullTable;
    }

    protected static function databasePrivilegeDiagnostics($runProbe = false)
    {
        $result = [
            'current_user' => '',
            'database' => '',
            'grants' => [],
            'grant_summary' => [
                'create' => false,
                'alter' => false,
                'index' => false,
                'drop' => false,
            ],
            'probe' => [],
            'ok' => false,
            'message' => '',
        ];

        try {
            $row = Database::fetch('SELECT CURRENT_USER() AS user, DATABASE() AS db');
            $result['current_user'] = $row && isset($row['user']) ? (string) $row['user'] : '';
            $result['database'] = $row && isset($row['db']) ? (string) $row['db'] : '';
        } catch (\Throwable $e) {
            $result['message'] = $e->getMessage();
        }

        try {
            $rows = Database::fetchAll('SHOW GRANTS FOR CURRENT_USER()');
            foreach ($rows as $row) {
                $grant = (string) reset($row);
                $result['grants'][] = $grant;
                $upper = strtoupper($grant);
                if (strpos($upper, 'ALL PRIVILEGES') !== false) {
                    foreach ($result['grant_summary'] as $key => $value) {
                        $result['grant_summary'][$key] = true;
                    }
                    continue;
                }
                foreach (array_keys($result['grant_summary']) as $privilege) {
                    if (preg_match('/\b' . strtoupper($privilege) . '\b/', $upper)) {
                        $result['grant_summary'][$privilege] = true;
                    }
                }
            }
        } catch (\Throwable $e) {
            $result['message'] = $result['message'] !== '' ? $result['message'] . ' / ' . $e->getMessage() : $e->getMessage();
        }

        if ($runProbe) {
            $result['probe'] = self::databasePrivilegeProbe();
        }

        $grantOk = !empty($result['grant_summary']['create'])
            && !empty($result['grant_summary']['alter'])
            && !empty($result['grant_summary']['index']);
        $probeOk = !$runProbe || self::databasePrivilegeProbeOk($result['probe']);
        $result['ok'] = $runProbe ? $probeOk : $grantOk;
        if ($result['message'] === '') {
            $result['message'] = $result['ok']
                ? '数据库账号具备当前修复所需的基础 DDL 权限。'
                : '数据库账号可能缺少 CREATE / ALTER / INDEX 权限，或权限被主机面板限制。';
        }
        return $result;
    }

    protected static function databasePrivilegeProbe()
    {
        $table = Database::table('_schema_repair_probe_' . substr(sha1(uniqid('', true)), 0, 10));
        $steps = [
            'create' => ['ok' => false, 'message' => 'not run'],
            'alter' => ['ok' => false, 'message' => 'not run'],
            'index' => ['ok' => false, 'message' => 'not run'],
            'drop' => ['ok' => false, 'message' => 'not run'],
        ];
        $created = false;

        try {
            Database::execute('CREATE TABLE `' . self::quoteIdentifier($table) . '` (`id` int(10) unsigned NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            $created = true;
            $steps['create'] = ['ok' => true, 'message' => 'ok'];
        } catch (\Throwable $e) {
            $steps['create'] = ['ok' => false, 'message' => $e->getMessage()];
            return $steps;
        }

        try {
            Database::execute('ALTER TABLE `' . self::quoteIdentifier($table) . '` ADD COLUMN `probe_value` varchar(32) NOT NULL DEFAULT \'\'');
            $steps['alter'] = ['ok' => true, 'message' => 'ok'];
        } catch (\Throwable $e) {
            $steps['alter'] = ['ok' => false, 'message' => $e->getMessage()];
        }

        try {
            Database::execute('CREATE INDEX `idx_probe_value` ON `' . self::quoteIdentifier($table) . '` (`probe_value`)');
            $steps['index'] = ['ok' => true, 'message' => 'ok'];
        } catch (\Throwable $e) {
            $steps['index'] = ['ok' => false, 'message' => $e->getMessage()];
        }

        try {
            if ($created) {
                Database::execute('DROP TABLE `' . self::quoteIdentifier($table) . '`');
            }
            $steps['drop'] = ['ok' => true, 'message' => 'ok'];
        } catch (\Throwable $e) {
            $steps['drop'] = ['ok' => false, 'message' => $e->getMessage()];
        }

        return $steps;
    }

    protected static function databasePrivilegeProbeOk(array $probe)
    {
        foreach (['create', 'alter', 'index'] as $key) {
            if (empty($probe[$key]['ok'])) {
                return false;
            }
        }
        return true;
    }

    protected static function codeReferencedTables()
    {
        $tables = [];
        $root = APP_ROOT . '/app';
        if (!is_dir($root)) {
            return [];
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile() || strtolower($file->getExtension()) !== 'php') {
                continue;
            }
            $source = file_get_contents($file->getPathname());
            if ($source === false) {
                continue;
            }
            if (preg_match_all('/Database::table\(\s*[\'"]([A-Za-z0-9_]+)[\'"]\s*\)/', $source, $matches)) {
                foreach ($matches[1] as $table) {
                    $tables[$table] = true;
                }
            }
        }
        $tables = array_keys($tables);
        sort($tables);
        return $tables;
    }

    protected static function quoteIdentifier($name)
    {
        return str_replace('`', '``', $name);
    }

    protected static function missingBaseTables(array $baseTables)
    {
        $missing = [];
        foreach ($baseTables as $table) {
            $fullTable = Database::table($table);
            if (!self::tableExists($fullTable)) {
                $missing[] = $fullTable;
            }
        }
        return $missing;
    }

    protected static function ensureBaseDefaultRows()
    {
        $created = 0;
        try {
            $freePackageId = self::ensurePackageDefaults($created);
            self::ensurePaymentDefaults($created);
            self::ensureStorageDefaults($created);
            self::ensureSettingDefaults($created, $freePackageId);
            self::ensureAnnouncementDefaults($created);
            return ['ok' => true, 'created_count' => $created];
        } catch (\Throwable $e) {
            Logger::error('默认配置一键修复失败：' . $e->getMessage());
            if (self::standardSchemaReady()) {
                return ['ok' => true, 'created_count' => $created, 'message' => '默认配置写入失败，但标准数据库结构已匹配，页面不再阻塞。原错误：' . $e->getMessage(), 'soft_ok' => true];
            }
            return ['ok' => false, 'created_count' => $created, 'message' => $e->getMessage()];
        }
    }

    protected static function ensurePackageDefaults(&$created)
    {
        $table = Database::table('packages');
        if (!self::tableExists($table)) {
            return 1;
        }
        self::ensureSubsiteSchema();
        $count = self::tableCount($table);
        if ($count === 0) {
            Database::execute("INSERT INTO `" . $table . "`
                (`name`, `price`, `duration_type`, `duration_days`, `storage_limit`, `traffic_limit`, `single_file_limit`, `allow_image`, `allow_netdisk`, `allow_api`, `allow_monitor`, `allow_multi_storage`, `allow_share`, `allow_subsite`, `subsite_limit`, `allow_video_preview`, `allow_external_link`, `status`, `sort_order`, `description`, `created_at`, `updated_at`)
                VALUES
                ('免费套餐', 0.00, 'forever', 36500, 1073741824, 5368709120, 10485760, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, '适合个人轻量图片与文件管理，作为新用户默认套餐。', NOW(), NOW()),
                ('专业套餐', 29.00, 'month', 30, 10737418240, 107374182400, 104857600, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 10, '提供更大空间、API 上传、多存储线路、分享仓库、服务器运维监控、视频预览和个人分站能力。', NOW(), NOW())");
            $created += 2;
        }
        $row = Database::fetch("SELECT id FROM `" . $table . "` ORDER BY price ASC, sort_order ASC, id ASC LIMIT 1");
        return $row ? (int) $row['id'] : 1;
    }

    protected static function ensurePaymentDefaults(&$created)
    {
        $table = Database::table('payment_config');
        if (!self::tableExists($table)) {
            return;
        }
        $payments = [
            ['balance', '余额支付', '{}', 1, 1],
            ['alipay', '支付宝当面付', '{"app_id":"","private_key":"","alipay_public_key":"","sandbox":false,"notify_url":"","timeout_express":"10m"}', 0, 10],
            ['wechat', '微信支付', '{}', 0, 20],
            ['epay', '易支付', '{}', 0, 30],
            ['manual', '人工充值审核', '{}', 1, 40],
        ];
        foreach ($payments as $payment) {
            $exists = Database::fetch("SELECT id FROM `" . $table . "` WHERE code = ? LIMIT 1", [$payment[0]]);
            if ($exists) {
                continue;
            }
            Database::execute(
                "INSERT INTO `" . $table . "` (`code`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES (?,?,?,?,?,NOW(),NOW())",
                [$payment[0], $payment[1], $payment[2], $payment[3], $payment[4]]
            );
            $created++;
        }
    }

    protected static function ensureStorageDefaults(&$created)
    {
        $table = Database::table('storage_drivers');
        if (!self::tableExists($table) || self::tableCount($table) > 0) {
            return;
        }
        Database::execute(
            "INSERT INTO `" . $table . "` (`name`, `type`, `access_key`, `secret_key`, `bucket`, `region`, `endpoint`, `domain`, `prefix`, `is_enabled`, `is_default`, `is_public`, `created_at`, `updated_at`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())",
            ['本地存储', 'local', '', '', '', '', '', '', 'uploads/files', 1, 1, 1]
        );
        $created++;
    }

    protected static function ensureSettingDefaults(&$created, $freePackageId)
    {
        $siteName = function_exists('app_brand_name') ? app_brand_name() : 'BM ucloud tools';
        $settings = [
            'site_name' => $siteName,
            'site_public_url' => '',
            'site_logo' => '',
            'seo_keywords' => '图床,网盘,对象存储,服务器状态,监控',
            'seo_description' => '综合型图床、轻量网盘、套餐充值、多对象存储与服务器状态监控平台。',
            'register_enabled' => '1',
            'register_email_code_enabled' => '0',
            'user_image_upload_enabled' => '1',
            'user_netdisk_enabled' => '1',
            'guest_image_upload_enabled' => '0',
            'guest_image_upload_user_id' => '',
            'guest_image_upload_max_size' => '5242880',
            'guest_image_upload_daily_ip_limit' => '20',
            'upload_max_concurrency' => '2',
            'upload_image_batch_limit' => '20',
            'upload_file_batch_limit' => '10',
            'upload_image_daily_limit' => '0',
            'upload_file_daily_limit' => '0',
            'security_login_max_attempts' => '5',
            'security_login_window_minutes' => '10',
            'security_login_lock_minutes' => '15',
            'security_email_code_max_per_hour' => '5',
            'security_email_code_ip_max_per_hour' => '20',
            'default_theme' => 'auto',
            'frontend_theme_style' => 'classic',
            'frontend_home_style' => 'default',
            'file_naming_strategy' => 'random',
            'default_free_package_id' => (string) max(1, (int) $freePackageId),
            'api_rate_limit_per_minute' => '60',
            'api_rate_limit_per_day' => '1000',
            'app_version' => '1.0.0',
            'update_manifest_url' => '',
            'email_host' => '',
            'email_port' => '465',
            'email_username' => '',
            'email_password' => '',
            'email_from' => '',
            'alert_webhook_enabled' => '0',
            'alert_wecom_webhook' => '',
            'alert_dingtalk_webhook' => '',
            'alert_dingtalk_secret' => '',
            'alert_telegram_bot_token' => '',
            'alert_telegram_chat_id' => '',
            'ssh_terminal_enabled' => '1',
            'ssh_terminal_user_server_limit' => '5',
            'ssh_terminal_session_timeout' => '600',
            'ssh_terminal_command_timeout' => '30',
            'ssh_terminal_gateway_url' => '',
            'server_probe_user_check_limit' => '20',
            'subsite_enabled' => '1',
            'subsite_domain_suffixes' => '',
            'subsite_cname_target' => '',
            'subsite_https_mode' => 'auto',
            'subsite_custom_domain_enabled' => '1',
            'subsite_requires_review' => '0',
            'subsite_default_limit' => '1',
            'subsite_reserved_slugs' => 'admin,api,www,cdn,static,status,login,register,assets,uploads,files,share',
        ];
        foreach ($settings as $key => $value) {
            if (self::ensureSettingDefault($key, $value)) {
                $created++;
            }
        }
    }

    public static function ensureUploadLimitDefaults()
    {
        try {
            self::ensureSettingDefault('upload_max_concurrency', '2');
            self::ensureSettingDefault('upload_image_batch_limit', '20');
            self::ensureSettingDefault('upload_file_batch_limit', '10');
            self::ensureSettingDefault('upload_image_daily_limit', '0');
            self::ensureSettingDefault('upload_file_daily_limit', '0');
            return true;
        } catch (\Throwable $e) {
            Logger::error('上传限制默认配置写入失败：' . $e->getMessage());
            return self::allowWhenStandardSchemaReady('上传限制默认配置写入', $e);
        }
    }

    protected static function ensureAnnouncementDefaults(&$created)
    {
        $table = Database::table('announcements');
        if (!self::tableExists($table) || self::tableCount($table) > 0) {
            return;
        }
        $siteName = function_exists('setting') ? setting('site_name', 'BM ucloud tools') : 'BM ucloud tools';
        Database::execute(
            "INSERT INTO `" . $table . "` (`title`, `content`, `category`, `summary`, `is_top`, `show_home`, `status`, `published_at`, `created_at`, `updated_at`) VALUES (?,?,?,?,?,?,?,NOW(),NOW(),NOW())",
            ['欢迎使用 ' . $siteName, '系统已安装完成。你可以在后台配置对象存储、支付方式、套餐、公告和服务器监控。', 'platform', '系统安装完成后的默认公告。', 1, 1, 1]
        );
        $created++;
    }

    protected static function tableCount($table)
    {
        $row = Database::fetch("SELECT COUNT(*) AS c FROM `" . $table . "`");
        return $row ? (int) $row['c'] : 0;
    }

    protected static function splitSql($sql)
    {
        $statements = [];
        $current = '';
        $inString = false;
        $quote = '';
        $len = strlen($sql);
        for ($i = 0; $i < $len; $i++) {
            $char = $sql[$i];
            $next = $i + 1 < $len ? $sql[$i + 1] : '';
            if (!$inString && $char === '-' && $next === '-') {
                while ($i < $len && $sql[$i] !== "\n") {
                    $i++;
                }
                continue;
            }
            if (!$inString && $char === '#') {
                while ($i < $len && $sql[$i] !== "\n") {
                    $i++;
                }
                continue;
            }
            if (!$inString && $char === '/' && $next === '*') {
                $i += 2;
                while ($i < $len - 1 && !($sql[$i] === '*' && $sql[$i + 1] === '/')) {
                    $i++;
                }
                $i++;
                continue;
            }
            if (($char === '\'' || $char === '"') && ($i === 0 || $sql[$i - 1] !== '\\')) {
                if (!$inString) {
                    $inString = true;
                    $quote = $char;
                } elseif ($quote === $char) {
                    $inString = false;
                    $quote = '';
                }
            }
            if (!$inString && $char === ';') {
                $statement = trim($current);
                if ($statement !== '') {
                    $statements[] = $statement;
                }
                $current = '';
                continue;
            }
            $current .= $char;
        }
        $statement = trim($current);
        if ($statement !== '') {
            $statements[] = $statement;
        }
        return $statements;
    }

    protected static function tableExists($table)
    {
        return Database::tableExists($table);
    }

    protected static function hasColumn($table, $column)
    {
        return (bool) self::column($table, $column);
    }

    protected static function ensureColumns($table, array $columns)
    {
        if (!self::tableExists($table)) {
            return;
        }
        foreach ($columns as $column => $definition) {
            if (!self::hasColumn($table, $column)) {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
            }
        }
    }

    protected static function column($table, $column)
    {
        return Database::columnInfo($table, $column);
    }

    protected static function hasIndex($table, $index)
    {
        return Database::indexExists($table, $index);
    }

    protected static function ensureSettingDefault($key, $value)
    {
        $table = Database::table('settings');
        if (!self::tableExists($table)) {
            return false;
        }
        $exists = Database::fetch('SELECT id FROM `' . $table . '` WHERE setting_key = ? LIMIT 1', [$key]);
        if ($exists) {
            return false;
        }
        Database::execute(
            'INSERT INTO `' . $table . '` (`setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE `setting_key` = `setting_key`',
            [$key, $value, now(), now()]
        );
        return true;
    }
}
