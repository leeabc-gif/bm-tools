<?php
namespace App\Services;

use App\Core\Database;

class PackageExpiryService
{
    public function summary()
    {
        return [
            'expired' => $this->count("u.status = 1 AND u.package_expire_time IS NOT NULL AND u.package_expire_time < NOW()"),
            'today' => $this->count("u.status = 1 AND u.package_expire_time IS NOT NULL AND DATE(u.package_expire_time) = CURDATE()"),
            'three_days' => $this->count("u.status = 1 AND u.package_expire_time IS NOT NULL AND u.package_expire_time >= NOW() AND u.package_expire_time < DATE_ADD(NOW(), INTERVAL 3 DAY)"),
            'seven_days' => $this->count("u.status = 1 AND u.package_expire_time IS NOT NULL AND u.package_expire_time >= NOW() AND u.package_expire_time < DATE_ADD(NOW(), INTERVAL 7 DAY)"),
        ];
    }

    public function expiringUsers($days = 7, $limit = 100)
    {
        $days = min(365, max(1, (int) $days));
        $limit = min(500, max(1, (int) $limit));
        return Database::fetchAll(
            'SELECT u.id, u.username, u.nickname, u.email, u.package_id, u.package_expire_time, u.balance, p.name AS package_name, p.price
             FROM ' . Database::table('users') . ' u
             LEFT JOIN ' . Database::table('packages') . ' p ON u.package_id = p.id
             WHERE u.status = 1
               AND u.package_expire_time IS NOT NULL
               AND u.package_expire_time >= NOW()
               AND u.package_expire_time < DATE_ADD(NOW(), INTERVAL ' . $days . ' DAY)
             ORDER BY u.package_expire_time ASC' . Database::limitClause($limit, 1, 500)
        );
    }

    public function expiredUsers($limit = 100)
    {
        $limit = min(500, max(1, (int) $limit));
        return Database::fetchAll(
            'SELECT u.id, u.username, u.nickname, u.email, u.package_id, u.package_expire_time, u.balance, p.name AS package_name, p.price
             FROM ' . Database::table('users') . ' u
             LEFT JOIN ' . Database::table('packages') . ' p ON u.package_id = p.id
             WHERE u.status = 1
               AND u.package_expire_time IS NOT NULL
               AND u.package_expire_time < NOW()
             ORDER BY u.package_expire_time DESC' . Database::limitClause($limit, 1, 500)
        );
    }

    public function sendReminders($days = 7)
    {
        $days = min(30, max(1, (int) $days));
        $users = $this->expiringUsers($days, 300);
        $sent = 0;
        $skipped = 0;
        $service = new NotificationService();
        foreach ($users as $user) {
            $leftDays = $this->daysLeft($user['package_expire_time']);
            $title = '套餐即将到期';
            $content = '你的' . ($user['package_name'] ?: '当前套餐') . '将在 ' . $user['package_expire_time'] . ' 到期，建议提前续费，避免图床、网盘、API 或服务器运维功能受到影响。';
            if ($this->alreadyNotified((int) $user['id'], $leftDays)) {
                $skipped++;
                continue;
            }
            $service->send((int) $user['id'], 'package_expire_' . $leftDays, $title, $content);
            $sent++;
        }
        return [
            'checked' => count($users),
            'sent' => $sent,
            'skipped' => $skipped,
            'days' => $days,
        ];
    }

    public function daysLeft($expireTime)
    {
        $seconds = strtotime((string) $expireTime) - time();
        return max(0, (int) ceil($seconds / 86400));
    }

    protected function alreadyNotified($userId, $leftDays)
    {
        $row = Database::fetch(
            'SELECT id FROM ' . Database::table('notifications') . '
             WHERE user_id = ? AND type = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
             LIMIT 1',
            [(int) $userId, 'package_expire_' . (int) $leftDays]
        );
        return (bool) $row;
    }

    protected function count($where)
    {
        try {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('users') . ' u WHERE ' . $where);
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
