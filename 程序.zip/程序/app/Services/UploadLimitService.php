<?php
namespace App\Services;

use App\Core\Database;

class UploadLimitService
{
    protected $locks = [];

    public function frontendConfig()
    {
        return [
            'concurrency' => $this->maxConcurrency(),
            'imageBatch' => $this->imageBatchLimit(),
            'fileBatch' => $this->fileBatchLimit(),
            'imageDaily' => $this->imageDailyLimit(),
            'fileDaily' => $this->fileDailyLimit(),
        ];
    }

    public function maxConcurrency()
    {
        return $this->intSetting('upload_max_concurrency', 2, 1, 8);
    }

    public function imageBatchLimit()
    {
        return $this->intSetting('upload_image_batch_limit', 20, 1, 500);
    }

    public function fileBatchLimit()
    {
        return $this->intSetting('upload_file_batch_limit', 10, 1, 300);
    }

    public function imageDailyLimit()
    {
        return $this->intSetting('upload_image_daily_limit', 0, 0, 1000000);
    }

    public function fileDailyLimit()
    {
        return $this->intSetting('upload_file_daily_limit', 0, 0, 1000000);
    }

    public function assertBatchLimit($scope, $count)
    {
        $count = max(0, (int) $count);
        $scope = $this->normalizeScope($scope);
        $limit = $scope === 'image' ? $this->imageBatchLimit() : $this->fileBatchLimit();
        if ($limit > 0 && $count > $limit) {
            throw new \RuntimeException(($scope === 'image' ? '图片' : '文件') . '单次最多上传 ' . $limit . ' 个，请减少选择数量后再试。');
        }
    }

    public function assertDailyLimit($userId, $scope, $incomingCount = 1)
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return;
        }
        $scope = $this->normalizeScope($scope);
        $limit = $scope === 'image' ? $this->imageDailyLimit() : $this->fileDailyLimit();
        if ($limit <= 0) {
            return;
        }
        $used = $this->todayCount($userId, $scope);
        $incomingCount = max(1, (int) $incomingCount);
        if ($used + $incomingCount > $limit) {
            throw new \RuntimeException('今日' . ($scope === 'image' ? '图片' : '文件') . '上传数量已达上限：已上传 ' . $used . ' 个，最多 ' . $limit . ' 个。');
        }
    }

    public function acquireDailyLimitSlot($userId, $scope)
    {
        $userId = (int) $userId;
        $scope = $this->normalizeScope($scope);
        $limit = $scope === 'image' ? $this->imageDailyLimit() : $this->fileDailyLimit();
        if ($userId <= 0 || $limit <= 0) {
            return null;
        }
        $lockRoot = $this->lockRoot();
        if ($lockRoot === '') {
            $this->assertDailyLimit($userId, $scope, 1);
            return null;
        }
        $guard = $this->acquireDailyLock($userId, $scope);
        try {
            $this->pruneReservations($lockRoot, $userId, $scope);
            $used = $this->todayCount($userId, $scope);
            $reserved = count(glob($this->reservationPattern($lockRoot, $userId, $scope)) ?: []);
            if ($used + $reserved + 1 > $limit) {
                throw new \RuntimeException('今日' . ($scope === 'image' ? '图片' : '文件') . '上传数量已达上限：已上传 ' . $used . ' 个，处理中 ' . $reserved . ' 个，最多 ' . $limit . ' 个。');
            }
            $reservation = $lockRoot . '/reserve_' . $scope . '_' . $userId . '_' . date('Ymd') . '_' . bin2hex(random_bytes(8)) . '.lock';
            @file_put_contents($reservation, (string) time());
            return ['path' => $reservation, 'handle' => null, 'reservation' => true];
        } catch (\Throwable $e) {
            throw $e;
        } finally {
            $this->releaseConcurrency($guard);
        }
    }

    public function acquireConcurrency($userId)
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return null;
        }
        $limit = $this->maxConcurrency();
        $lockRoot = $this->lockRoot();
        if ($lockRoot === '') {
            return null;
        }

        $this->pruneLocks($lockRoot, $userId);
        $held = 0;
        for ($i = 1; $i <= $limit; $i++) {
            $path = $lockRoot . '/user_' . $userId . '_' . $i . '.lock';
            $handle = @fopen($path, 'c+');
            if (!$handle) {
                continue;
            }
            if (@flock($handle, LOCK_EX | LOCK_NB)) {
                ftruncate($handle, 0);
                fwrite($handle, (string) time());
                $token = ['path' => $path, 'handle' => $handle];
                $this->locks[] = $token;
                return $token;
            }
            $held++;
            fclose($handle);
        }

        if ($held >= $limit) {
            throw new \RuntimeException('当前上传并发过高，系统最多允许同时上传 ' . $limit . ' 个文件，请等待前面的文件完成。');
        }
        return null;
    }

    public function acquireDailyLock($userId, $scope)
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return null;
        }
        $scope = $this->normalizeScope($scope);
        $lockRoot = $this->lockRoot();
        if ($lockRoot === '') {
            return null;
        }
        $path = $lockRoot . '/daily_' . $scope . '_' . $userId . '.lock';
        $handle = @fopen($path, 'c+');
        if (!$handle) {
            return null;
        }
        if (!@flock($handle, LOCK_EX)) {
            fclose($handle);
            return null;
        }
        ftruncate($handle, 0);
        fwrite($handle, (string) time());
        $token = ['path' => $path, 'handle' => $handle];
        $this->locks[] = $token;
        return $token;
    }

    public function releaseConcurrency($token)
    {
        if (!$token) {
            return;
        }
        if (!empty($token['handle'])) {
            @flock($token['handle'], LOCK_UN);
            @fclose($token['handle']);
        }
        if (!empty($token['reservation']) && !empty($token['path']) && is_file($token['path'])) {
            @unlink($token['path']);
        }
        foreach ($this->locks as $index => $held) {
            if (!empty($token['handle']) && !empty($held['handle']) && $held['handle'] === $token['handle']) {
                unset($this->locks[$index]);
            } elseif (!empty($token['path']) && !empty($held['path']) && $held['path'] === $token['path']) {
                unset($this->locks[$index]);
            }
        }
    }

    public function todayCount($userId, $scope)
    {
        $scope = $this->normalizeScope($scope);
        try {
            $row = Database::fetch(
                'SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE user_id = ? AND file_type = ? AND created_at >= CURDATE()',
                [(int) $userId, $scope]
            );
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function intSetting($key, $default, $min, $max)
    {
        $value = (int) setting($key, $default);
        if ($value < $min) {
            $value = $min;
        }
        if ($value > $max) {
            $value = $max;
        }
        return $value;
    }

    protected function normalizeScope($scope)
    {
        return $scope === 'image' ? 'image' : 'file';
    }

    protected function pruneLocks($lockRoot, $userId)
    {
        foreach (glob($lockRoot . '/user_' . (int) $userId . '_*.lock') ?: [] as $path) {
            if (@filemtime($path) !== false && filemtime($path) < time() - 3600) {
                $this->deleteUnlockedFile($path);
            }
        }
    }

    protected function lockRoot()
    {
        $lockRoot = APP_ROOT . '/storage/upload_locks';
        if (!is_dir($lockRoot)) {
            @mkdir($lockRoot, 0755, true);
        }
        if (!is_dir($lockRoot) || !is_writable($lockRoot)) {
            return '';
        }
        $this->protectLockRoot($lockRoot);
        return $lockRoot;
    }

    protected function reservationPattern($lockRoot, $userId, $scope)
    {
        return $lockRoot . '/reserve_' . $this->normalizeScope($scope) . '_' . (int) $userId . '_' . date('Ymd') . '_*.lock';
    }

    protected function pruneReservations($lockRoot, $userId, $scope)
    {
        foreach (glob($this->reservationPattern($lockRoot, $userId, $scope)) ?: [] as $path) {
            if (@filemtime($path) === false || filemtime($path) < time() - 7200) {
                @unlink($path);
            }
        }
    }

    protected function deleteUnlockedFile($path)
    {
        $handle = @fopen($path, 'c+');
        if (!$handle) {
            @unlink($path);
            return;
        }
        if (@flock($handle, LOCK_EX | LOCK_NB)) {
            @unlink($path);
            @flock($handle, LOCK_UN);
        }
        @fclose($handle);
    }

    protected function protectLockRoot($lockRoot)
    {
        $htaccess = $lockRoot . '/.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents($htaccess, "Require all denied\nDeny from all\n");
        }
        $index = $lockRoot . '/index.html';
        if (!is_file($index)) {
            @file_put_contents($index, '');
        }
    }

    public function __destruct()
    {
        foreach ($this->locks as $token) {
            $this->releaseConcurrency($token);
        }
        $this->locks = [];
    }
}
