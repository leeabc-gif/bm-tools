<?php
date_default_timezone_set('Asia/Shanghai');
ini_set('default_charset', 'UTF-8');

spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) !== 0) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $file = APP_ROOT . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

if (!function_exists('bm_is_https_request')) {
    function bm_is_https_request()
    {
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            return true;
        }
        if (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) {
            return true;
        }
        foreach (['HTTP_X_FORWARDED_PROTO', 'HTTP_X_FORWARDED_SSL', 'HTTP_FRONT_END_HTTPS'] as $key) {
            if (empty($_SERVER[$key])) {
                continue;
            }
            $value = strtolower(trim((string) $_SERVER[$key]));
            if ($value === 'https' || $value === 'on') {
                return true;
            }
        }
        return false;
    }
}

if (PHP_SAPI !== 'cli' && !headers_sent()) {
    if (function_exists('header_remove')) {
        header_remove('X-Powered-By');
    }
    $isHttpsRequest = bm_is_https_request();
    header('Content-Type: text/html; charset=utf-8');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header('X-Permitted-Cross-Domain-Policies: none');
    header('Cross-Origin-Opener-Policy: same-origin');
    $requestPath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    $isPublicAsset = preg_match('#^/(uploads|assets)/#', (string) $requestPath);
    header('Cross-Origin-Resource-Policy: ' . ($isPublicAsset ? 'cross-origin' : 'same-origin'));
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'; object-src 'none'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: http: https:; media-src 'self' data: blob: http: https:; font-src 'self' data:; connect-src 'self' http: https:");
    if ($isHttpsRequest) {
        header('Strict-Transport-Security: max-age=15552000; includeSubDomains');
    }
}

$vendorAutoload = APP_ROOT . '/vendor/autoload.php';
if (is_file($vendorAutoload)) {
    require $vendorAutoload;
}

if (session_status() === PHP_SESSION_NONE) {
    $isHttps = bm_is_https_request();
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params([
        'lifetime' => isset($cookieParams['lifetime']) ? $cookieParams['lifetime'] : 0,
        'path' => isset($cookieParams['path']) ? $cookieParams['path'] : '/',
        'domain' => isset($cookieParams['domain']) ? $cookieParams['domain'] : '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('BMToolsSID');
    session_start();
}

require APP_ROOT . '/app/helpers.php';

App\Services\BrandProtectionService::protectRequest();

if (!function_exists('bm_request_expects_json')) {
    function bm_request_expects_json()
    {
        $accept = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
        $xhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) : '';
        $contentType = isset($_SERVER['CONTENT_TYPE']) ? strtolower((string) $_SERVER['CONTENT_TYPE']) : '';
        return $xhr === 'xmlhttprequest'
            || stripos($accept, 'application/json') !== false
            || stripos($contentType, 'application/json') !== false
            || !empty($_POST['ajax_upload']);
    }
}

if (!function_exists('bm_runtime_error_id')) {
    function bm_runtime_error_id()
    {
        try {
            return strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));
        } catch (\Throwable $e) {
            return strtoupper(substr(uniqid('', true), -12));
        }
    }
}

if (!function_exists('bm_error_text_limit')) {
    function bm_error_text_limit($value, $length = 220)
    {
        if (function_exists('text_limit')) {
            return text_limit((string) $value, (int) $length);
        }
        $value = trim((string) $value);
        return strlen($value) > $length ? substr($value, 0, $length) . '...' : $value;
    }
}

if (!function_exists('bm_runtime_can_show_detail')) {
    function bm_runtime_can_show_detail()
    {
        if (defined('APP_DEBUG') && APP_DEBUG) {
            return true;
        }
        if (empty($_SESSION['user_id'])) {
            return false;
        }
        try {
            $row = App\Core\Database::fetch(
                'SELECT role FROM ' . App\Core\Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1',
                [(int) $_SESSION['user_id']]
            );
            return $row && isset($row['role']) && $row['role'] === 'admin';
        } catch (\Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_runtime_detail_message')) {
    function bm_runtime_detail_message($message, $file = '', $line = 0)
    {
        if (!bm_runtime_can_show_detail()) {
            return '';
        }
        $message = bm_error_text_limit($message, 240);
        $file = str_replace('\\', '/', (string) $file);
        if (defined('APP_ROOT')) {
            $root = str_replace('\\', '/', APP_ROOT);
            if (strpos($file, $root) === 0) {
                $file = ltrim(substr($file, strlen($root)), '/');
            }
        }
        $file = $file !== '' ? '（' . bm_error_text_limit($file, 180) . ':' . (int) $line . '）' : '';
        return ' 管理员诊断：' . $message . $file;
    }
}

if (!function_exists('bm_emit_json_error')) {
    function bm_emit_json_error($message, $status = 500, array $extra = [])
    {
        if (!headers_sent()) {
            http_response_code((int) $status);
            header('Content-Type: application/json; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
        }
        echo json_encode(array_merge([
            'success' => false,
            'message' => $message,
        ], $extra), JSON_UNESCAPED_UNICODE);
    }
}

if (!function_exists('bm_emit_html_error')) {
    function bm_emit_html_error($title, $message, $errorId = '', array $actions = [])
    {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: text/html; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
        }
        $safeTitle = htmlspecialchars((string) $title, ENT_QUOTES, 'UTF-8');
        $safeMessage = htmlspecialchars((string) $message, ENT_QUOTES, 'UTF-8');
        $safeErrorId = htmlspecialchars((string) $errorId, ENT_QUOTES, 'UTF-8');
        $actionHtml = '';
        foreach ($actions as $action) {
            $href = isset($action['href']) ? (string) $action['href'] : '';
            $label = isset($action['label']) ? (string) $action['label'] : '';
            if ($href === '' || $label === '') {
                continue;
            }
            $class = !empty($action['primary']) ? 'btn primary' : 'btn soft';
            $actionHtml .= '<a class="' . $class . '" href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</a>';
        }
        if ($actionHtml !== '') {
            $actionHtml = '<div class="actions">' . $actionHtml . '</div>';
        }
        $errorMeta = $safeErrorId !== '' ? '<p class="meta">错误编号：<code>' . $safeErrorId . '</code> · 日志：<code>storage/logs/' . date('Y-m-d') . '.log</code></p>' : '';
        echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $safeTitle . '</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:22px;background:linear-gradient(135deg,#f6f8fb,#eef4ff);color:#172033;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",Arial,sans-serif}.card{width:min(620px,100%);padding:30px;border:1px solid rgba(148,163,184,.22);border-radius:22px;background:rgba(255,255,255,.92);box-shadow:0 22px 60px rgba(15,23,42,.10);backdrop-filter:blur(18px)}.eyebrow{margin:0 0 12px;color:#2563eb;font-size:12px;font-weight:900;letter-spacing:.12em;text-transform:uppercase}h1{margin:0 0 12px;font-size:26px;line-height:1.25;letter-spacing:0}p{margin:0;color:#64748b;line-height:1.8}.meta{margin-top:14px;padding:12px;border:1px solid #e2e8f0;border-radius:14px;background:#f8fafc;color:#475569;font-size:13px}code{padding:2px 6px;border-radius:7px;background:#eaf1ff;color:#1d4ed8;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:18px}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800}.primary{color:#fff;background:#2563eb}.soft{color:#334155;background:#eef2f7}@media(max-width:520px){.card{padding:22px;border-radius:18px}h1{font-size:22px}.actions{display:grid}.btn{width:100%}}</style></head><body><main class="card"><p class="eyebrow">Runtime Error</p><h1>' . $safeTitle . '</h1><p>' . $safeMessage . '</p>' . $errorMeta . $actionHtml . '</main></body></html>';
    }
}

register_shutdown_function(function () {
    $error = error_get_last();
    if (!$error) {
        return;
    }
    $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR];
    if (!in_array((int) $error['type'], $fatalTypes, true)) {
        return;
    }

    $errorId = bm_runtime_error_id();
    $logFile = 'storage/logs/' . date('Y-m-d') . '.log';
    App\Core\Logger::error('Fatal error #' . $errorId . ': ' . (isset($error['message']) ? $error['message'] : 'unknown'), [
        'file' => isset($error['file']) ? $error['file'] : '',
        'line' => isset($error['line']) ? $error['line'] : 0,
        'type' => isset($error['type']) ? $error['type'] : 0,
        'request' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
    ]);

    if (!bm_request_expects_json()) {
        while (ob_get_level() > 0) {
            @ob_end_clean();
        }
        $message = '服务器处理页面时出现内部异常，系统已记录错误日志。请管理员进入后台功能巡检查看 PHP 扩展、数据库结构和运行日志。';
        $detail = bm_runtime_detail_message(
            isset($error['message']) ? (string) $error['message'] : '',
            isset($error['file']) ? (string) $error['file'] : '',
            isset($error['line']) ? (int) $error['line'] : 0
        );
        if ($detail !== '') {
            $message .= $detail;
        }
        bm_emit_html_error('页面暂时不可用', $message, $errorId, [
            ['href' => url('admin/feature-audit'), 'label' => '进入功能巡检', 'primary' => true],
            ['href' => url('admin/maintenance/environment'), 'label' => '环境信息'],
        ]);
        return;
    }

    while (ob_get_level() > 0) {
        @ob_end_clean();
    }

    $message = '上传处理出现服务器内部异常，错误编号：' . $errorId . '。请查看 ' . $logFile . '，或进入后台「系统维护 / 功能巡检」检查 PHP 扩展、数据库结构和对象存储配置。';
    $detail = bm_runtime_detail_message(
        isset($error['message']) ? (string) $error['message'] : '',
        isset($error['file']) ? (string) $error['file'] : '',
        isset($error['line']) ? (int) $error['line'] : 0
    );
    if ($detail !== '') {
        $message .= $detail;
    }
    bm_emit_json_error($message, 500, [
        'error_type' => 'fatal',
        'error_id' => $errorId,
        'log_file' => $logFile,
    ]);
});

if (is_file(APP_ROOT . '/storage/install.lock') && is_file(APP_ROOT . '/config/database.php')) {
    try {
        App\Core\Auth::bootRemember();
    } catch (\Throwable $e) {
        App\Core\Logger::error('自动登录初始化失败：' . $e->getMessage());
    }
}

set_exception_handler(function ($e) {
    $errorId = bm_runtime_error_id();
    App\Core\Logger::error('Unhandled exception #' . $errorId . ': ' . $e->getMessage(), [
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString(),
    ]);

    http_response_code(500);
    $requestPath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    $message = (string) $e->getMessage();
    $isAdminPath = strpos((string) $requestPath, '/admin') === 0;
    $isSchemaError = preg_match('/SQLSTATE\[42S(02|22)\]|Base table or view not found|Unknown column|Unknown table|doesn\'t exist|Table .* doesn.t exist/i', $message);
    if (bm_request_expects_json()) {
        $jsonMessage = $isSchemaError
            ? '数据库结构不完整，请管理员进入系统维护执行数据库巡检修复。'
            : '服务器处理请求时出现异常，错误编号：' . $errorId . '。请查看 storage/logs/' . date('Y-m-d') . '.log。';
        if (defined('APP_DEBUG') && APP_DEBUG && !$isSchemaError) {
            $jsonMessage .= ' 原始错误：' . text_limit($message, 220);
        }
        bm_emit_json_error($jsonMessage, 500, [
            'error_type' => $isSchemaError ? 'schema' : 'server',
            'error_id' => $errorId,
            'log_file' => 'storage/logs/' . date('Y-m-d') . '.log',
            'repair_url' => $isSchemaError ? url('admin/maintenance/schema-audit') : '',
        ]);
        return;
    }
    if (defined('APP_DEBUG') && APP_DEBUG) {
        echo '<pre>' . htmlspecialchars((string) $e, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
    if ($isSchemaError) {
        $auditUrl = htmlspecialchars(url('admin/maintenance/schema-audit'), ENT_QUOTES, 'UTF-8');
        $maintenanceUrl = htmlspecialchars(url('admin/maintenance'), ENT_QUOTES, 'UTF-8');
        $canRepair = $isAdminPath;
        try {
            if (!$canRepair && class_exists('App\\Core\\Auth') && App\Core\Auth::check()) {
                $current = App\Core\Auth::user();
                $canRepair = $current && isset($current['role']) && $current['role'] === 'admin';
            }
        } catch (\Throwable $ignored) {
            $canRepair = false;
        }
        $body = $canRepair
            ? '<p>当前功能依赖的数据表或字段不完整，系统已记录错误日志。请进入数据库巡检执行一键修复，修复后刷新当前页面。</p><div class="actions"><a class="btn primary" href="' . $auditUrl . '">进入数据库巡检</a><a class="btn soft" href="' . $maintenanceUrl . '">进入系统维护</a></div>'
            : '<p>当前页面依赖的数据表或字段不完整，系统已记录错误日志。请联系管理员进入后台「系统维护」执行数据库巡检和一键修复。</p>';
        echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>数据库结构需要修复</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f6f7f9;color:#111827;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",Arial,sans-serif}.card{width:min(560px,calc(100% - 32px));padding:28px;border:1px solid #e5e7eb;border-radius:18px;background:#fff;box-shadow:0 12px 30px rgba(16,24,40,.08)}h1{margin:0 0 10px;font-size:24px;line-height:1.25}p{margin:0 0 16px;color:#667085;line-height:1.75}.actions{display:flex;flex-wrap:wrap;gap:10px}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 16px;border-radius:10px;text-decoration:none;font-weight:700}.primary{color:#fff;background:#2563eb}.soft{color:#344054;background:#f3f4f6}</style></head><body><main class="card"><h1>数据库结构需要修复</h1>' . $body . '</main></body></html>';
        return;
    }
    $detail = bm_runtime_detail_message($message, $e->getFile(), $e->getLine());
    bm_emit_html_error('页面暂时不可用', '服务器处理请求时出现异常，系统已记录错误日志。请管理员按错误编号查看日志，或进入后台功能巡检定位数据库、PHP 扩展、对象存储和页面入口问题。' . $detail, $errorId, [
        ['href' => url('admin/feature-audit'), 'label' => '进入功能巡检', 'primary' => true],
        ['href' => url('admin/maintenance'), 'label' => '系统维护'],
    ]);
});
