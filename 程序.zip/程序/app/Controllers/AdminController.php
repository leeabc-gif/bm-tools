<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Core\Validator;
use App\Models\Announcement;
use App\Models\Coupon;
use App\Models\Package;
use App\Models\StorageDriver;
use App\Models\User;
use App\Services\BalanceService;
use App\Services\AlertWebhookService;
use App\Services\CryptoService;
use App\Services\DatabaseUpgradeService;
use App\Services\MailerService;
use App\Services\Monitor\MonitorService;
use App\Services\Monitor\SlaReportService;
use App\Services\NotificationService;
use App\Services\OnlineUpdateService;
use App\Services\Payment\PaymentService;
use App\Services\PackageExpiryService;
use App\Services\RepositoryService;
use App\Services\RedeemCardService;
use App\Services\Storage\StorageManager;
use App\Services\Storage\StorageTestService;
use App\Services\StorageBackupService;
use App\Services\StorageMigrationService;
use App\Services\SubsiteService;
use App\Services\UploadLimitService;

class AdminController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'users' => $this->count('users'),
            'today_users' => $this->count('users', 'DATE(created_at) = CURDATE()'),
            'files' => $this->count('files'),
            'images' => $this->count('files', "file_type = 'image'"),
            'netdisk_files' => $this->count('files', "file_type = 'file'"),
            'storage_used' => Database::fetch('SELECT COALESCE(SUM(file_size),0) AS total FROM ' . Database::table('files'))['total'],
            'today_orders' => $this->count('orders', 'DATE(created_at) = CURDATE()'),
            'today_recharge' => Database::fetch("SELECT COALESCE(SUM(amount),0) AS total FROM " . Database::table('recharges') . " WHERE status = 'paid' AND DATE(paid_at) = CURDATE()")['total'],
            'online_servers' => $this->count('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'online'"),
            'abnormal_servers' => $this->count('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'"),
        ];
        $this->adminView('admin/dashboard', [
            'title' => '运营控制台',
            'stats' => $stats,
            'serverInfo' => $this->localServerInfo(),
            'revenueTrend' => $this->dashboardRevenueTrend(),
            'recentOrders' => $this->dashboardRecentOrders(),
            'pendingRecharges' => $this->dashboardPendingRecharges(),
            'opsTodos' => $this->dashboardOpsTodos(),
            'opsAlerts' => $this->dashboardOpsAlerts(),
        ]);
    }

    public function screen()
    {
        $range = $this->dashboardScreenRange();
        $this->adminView('admin/screen', [
            'title' => '数据大屏',
            'screenData' => $this->dashboardScreenData($range),
        ]);
    }

    public function users()
    {
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema'], '用户权限');
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'], 'API 安全');
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $role = isset($_GET['role']) && in_array($_GET['role'], ['user', 'admin'], true) ? $_GET['role'] : '';
        $status = isset($_GET['status']) && in_array((string) $_GET['status'], ['0', '1'], true) ? (string) $_GET['status'] : '';
        $packageId = isset($_GET['package_id']) ? (int) $_GET['package_id'] : 0;
        $sql = 'SELECT u.*, p.name AS package_name FROM ' . Database::table('users') . ' u LEFT JOIN ' . Database::table('packages') . ' p ON u.package_id = p.id';
        $params = [];
        $where = [];
        if ($keyword !== '') {
            $where[] = '(u.username LIKE ? OR u.email LIKE ? OR u.nickname LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        if ($role !== '') {
            $where[] = 'u.role = ?';
            $params[] = $role;
        }
        if ($status !== '') {
            $where[] = 'u.status = ?';
            $params[] = (int) $status;
        }
        if ($packageId > 0) {
            $where[] = 'u.package_id = ?';
            $params[] = $packageId;
        }
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY u.id DESC LIMIT 200';
        $packages = (new Package())->all('sort_order ASC, id ASC');
        $this->adminView('admin/users', [
            'title' => '用户管理',
            'users' => Database::fetchAll($sql, $params),
            'packages' => $packages,
            'filters' => ['keyword' => $keyword, 'role' => $role, 'status' => $status, 'package_id' => $packageId],
            'userStats' => $this->userStats(),
        ]);
    }

    public function packageExpiry()
    {
        $service = new PackageExpiryService();
        $days = isset($_GET['days']) ? (int) $_GET['days'] : 7;
        $days = in_array($days, [3, 7, 15, 30], true) ? $days : 7;
        $this->adminView('admin/package_expiry', [
            'title' => '套餐到期提醒',
            'days' => $days,
            'summary' => $service->summary(),
            'expiringUsers' => $service->expiringUsers($days, 200),
            'expiredUsers' => $service->expiredUsers(80),
        ]);
    }

    public function sendPackageExpiryReminders()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        try {
            $days = isset($_POST['days']) ? (int) $_POST['days'] : 7;
            $result = (new PackageExpiryService())->sendReminders($days);
            $this->adminLog('发送套餐到期提醒', 'package_expiry', null);
            set_flash('success', '套餐到期提醒已执行：检查 ' . (int) $result['checked'] . ' 个用户，发送 ' . (int) $result['sent'] . ' 条，跳过 ' . (int) $result['skipped'] . ' 条。');
        } catch (\Throwable $e) {
            set_flash('error', '发送套餐到期提醒失败：' . $e->getMessage());
        }
        $this->redirect('admin/package-expiry');
    }

    public function createUser()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $permissionSchemaReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema'], '用户权限');
        $apiSchemaReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'], 'API 安全');

        $username = trim(isset($_POST['username']) ? $_POST['username'] : '');
        $nickname = trim(isset($_POST['nickname']) ? $_POST['nickname'] : '');
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        $password = isset($_POST['password']) ? (string) $_POST['password'] : '';
        $role = isset($_POST['role']) && $_POST['role'] === 'admin' ? 'admin' : 'user';
        $status = isset($_POST['status']) && (int) $_POST['status'] === 0 ? 0 : 1;
        $balance = round((float) (isset($_POST['balance']) ? $_POST['balance'] : 0), 2);
        $package = $this->adminPackageById(isset($_POST['package_id']) ? (int) $_POST['package_id'] : 0);
        $apiAllowedIps = $this->normalizeApiAllowedIps(isset($_POST['api_allowed_ips']) ? $_POST['api_allowed_ips'] : '');
        $userModel = new User();

        if (!Validator::username($username)) {
            $this->failUserForm('用户名必须为 3-32 位字母、数字或下划线。', '#create-user');
        }
        if (!Validator::email($email)) {
            $this->failUserForm('邮箱格式不正确。', '#create-user');
        }
        if (!Validator::password($password)) {
            $this->failUserForm('密码至少需要 6 位。', '#create-user');
        }
        if ($userModel->existsUsername($username)) {
            $this->failUserForm('用户名已存在，请换一个。', '#create-user');
        }
        if ($userModel->existsEmail($email)) {
            $this->failUserForm('邮箱已存在，请换一个。', '#create-user');
        }
        if ($apiAllowedIps === false) {
            $this->failUserForm('API 白名单格式不正确，每行填写一个 IPv4 或 IPv6，留空表示不限制。', '#create-user');
        }

        $quota = $this->adminUserQuotaPayload($package, isset($_POST['sync_package_limits']), null);
        $apiToken = bin2hex(random_bytes(24));
        $data = [
            'username' => $username,
            'nickname' => $nickname !== '' ? $nickname : $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'avatar' => '',
            'role' => $role,
            'balance' => $balance,
            'package_id' => $package ? (int) $package['id'] : null,
            'package_expire_time' => $quota['package_expire_time'],
            'used_storage' => 0,
            'total_storage' => $quota['total_storage'],
            'used_traffic' => 0,
            'total_traffic' => $quota['total_traffic'],
            'status' => $status,
            'email_verified_at' => isset($_POST['email_verified']) ? now() : null,
            'api_token' => $apiToken,
            'created_at' => now(),
            'updated_at' => now(),
        ];
        if ($permissionSchemaReady) {
            $data['allow_image_override'] = $this->permissionOverride(isset($_POST['allow_image_override']) ? $_POST['allow_image_override'] : -1);
            $data['allow_netdisk_override'] = $this->permissionOverride(isset($_POST['allow_netdisk_override']) ? $_POST['allow_netdisk_override'] : -1);
        }
        if ($apiSchemaReady) {
            $data['api_token'] = CryptoService::encrypt($apiToken);
            $data['api_token_hash'] = hash('sha256', $apiToken);
            $data['api_allowed_ips'] = $apiAllowedIps;
        }

        $id = $userModel->create($data);
        if ($balance != 0.0) {
            (new BalanceService())->log($id, 'adjust', $balance, 0, $balance, 'admin', Auth::id(), '管理员创建用户初始余额');
        }
        $this->adminLog('创建用户', 'user', $id);
        clear_old();
        set_flash('success', '用户已创建。');
        $this->redirect('admin/users');
    }

    public function updateUser()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $permissionSchemaReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema'], '用户权限');
        $apiSchemaReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'], 'API 安全');
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $userModel = new User();
        $oldUser = $userModel->find($id);
        if (!$oldUser) {
            set_flash('error', '用户不存在。');
            $this->redirect('admin/users');
        }
        $username = trim(isset($_POST['username']) ? $_POST['username'] : $oldUser['username']);
        $nickname = trim(isset($_POST['nickname']) ? $_POST['nickname'] : $oldUser['nickname']);
        $email = trim(isset($_POST['email']) ? $_POST['email'] : $oldUser['email']);
        $role = isset($_POST['role']) && $_POST['role'] === 'admin' ? 'admin' : 'user';
        $status = isset($_POST['status']) && (int) $_POST['status'] === 0 ? 0 : 1;
        $apiAllowedIps = $this->normalizeApiAllowedIps(isset($_POST['api_allowed_ips']) ? $_POST['api_allowed_ips'] : '');
        if (!Validator::username($username)) {
            set_flash('error', '用户名必须为 3-32 位字母、数字或下划线。');
            $this->redirect('admin/users');
        }
        if (!Validator::email($email)) {
            set_flash('error', '邮箱格式不正确。');
            $this->redirect('admin/users');
        }
        if ($userModel->existsUsername($username, $id)) {
            set_flash('error', '用户名已存在，请换一个。');
            $this->redirect('admin/users');
        }
        if ($userModel->existsEmail($email, $id)) {
            set_flash('error', '邮箱已存在，请换一个。');
            $this->redirect('admin/users');
        }
        if ($id === (int) Auth::id() && ($role !== 'admin' || $status !== 1)) {
            set_flash('error', '不能把当前登录的管理员降级或禁用，避免后台无法登录。');
            $this->redirect('admin/users');
        }
        if ($apiAllowedIps === false) {
            set_flash('error', 'API 白名单格式不正确。每行填写一个 IPv4 或 IPv6，留空表示不限制。');
            $this->redirect('admin/users');
        }
        if (!empty($_POST['password']) && !Validator::password($_POST['password'])) {
            set_flash('error', '新密码至少需要 6 位。');
            $this->redirect('admin/users');
        }
        $package = $this->adminPackageById(isset($_POST['package_id']) ? (int) $_POST['package_id'] : 0);
        $quota = $this->adminUserQuotaPayload($package, isset($_POST['sync_package_limits']), $oldUser);
        $data = [
            'username' => $username,
            'nickname' => $nickname !== '' ? $nickname : $username,
            'email' => $email,
            'role' => $role,
            'balance' => round((float) $_POST['balance'], 2),
            'package_id' => $package ? (int) $package['id'] : null,
            'package_expire_time' => $quota['package_expire_time'],
            'total_storage' => $quota['total_storage'],
            'total_traffic' => $quota['total_traffic'],
            'status' => $status,
            'email_verified_at' => isset($_POST['email_verified']) ? (!empty($oldUser['email_verified_at']) ? $oldUser['email_verified_at'] : now()) : null,
            'updated_at' => now(),
        ];
        if ($permissionSchemaReady) {
            $data['allow_image_override'] = $this->permissionOverride(isset($_POST['allow_image_override']) ? $_POST['allow_image_override'] : -1);
            $data['allow_netdisk_override'] = $this->permissionOverride(isset($_POST['allow_netdisk_override']) ? $_POST['allow_netdisk_override'] : -1);
        }
        if ($apiSchemaReady) {
            $data['api_allowed_ips'] = $apiAllowedIps;
            if (!empty($_POST['reset_api_token'])) {
                $apiToken = bin2hex(random_bytes(24));
                $data['api_token'] = CryptoService::encrypt($apiToken);
                $data['api_token_hash'] = hash('sha256', $apiToken);
            }
        } elseif (!empty($_POST['reset_api_token'])) {
            $data['api_token'] = bin2hex(random_bytes(24));
        }
        if (!empty($_POST['password'])) {
            $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }
        $userModel->update($id, $data);
        if ($oldUser && (float) $oldUser['balance'] !== (float) $data['balance']) {
            (new BalanceService())->log($id, 'adjust', round((float) $data['balance'] - (float) $oldUser['balance'], 2), $oldUser['balance'], $data['balance'], 'admin', Auth::id(), '管理员调整余额');
        }
        $this->adminLog('更新用户', 'user', $id);
        set_flash('success', '用户已更新。');
        $this->redirect('admin/users');
    }

    public function packages()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '套餐管理'),
            '套餐管理',
            '套餐管理依赖 packages 套餐字段和分站套餐字段。系统自动升级失败时，请先执行数据库巡检修复。'
        )) {
            return;
        }
        $this->adminView('admin/packages', [
            'title' => '套餐管理',
            'packages' => (new Package())->all('sort_order ASC, id ASC'),
            'editPackage' => !empty($_GET['id']) ? (new Package())->find((int) $_GET['id']) : null,
        ]);
    }

    public function savePackage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '套餐管理'),
            '套餐管理',
            'admin/packages',
            '套餐数据结构未准备完成，请先进入数据库巡检执行一键修复。'
        )) {
            return;
        }
        $data = [
            'name' => trim($_POST['name']),
            'price' => round((float) $_POST['price'], 2),
            'duration_type' => $_POST['duration_type'],
            'duration_days' => (int) $_POST['duration_days'],
            'storage_limit' => (int) $_POST['storage_limit'],
            'traffic_limit' => (int) $_POST['traffic_limit'],
            'single_file_limit' => (int) $_POST['single_file_limit'],
            'allow_image' => isset($_POST['allow_image']) ? 1 : 0,
            'allow_netdisk' => isset($_POST['allow_netdisk']) ? 1 : 0,
            'allow_api' => isset($_POST['allow_api']) ? 1 : 0,
            'allow_monitor' => isset($_POST['allow_monitor']) ? 1 : 0,
            'allow_multi_storage' => isset($_POST['allow_multi_storage']) ? 1 : 0,
            'allow_share' => isset($_POST['allow_share']) ? 1 : 0,
            'allow_subsite' => isset($_POST['allow_subsite']) ? 1 : 0,
            'subsite_limit' => max(0, (int) (isset($_POST['subsite_limit']) ? $_POST['subsite_limit'] : 1)),
            'allow_video_preview' => isset($_POST['allow_video_preview']) ? 1 : 0,
            'allow_external_link' => isset($_POST['allow_external_link']) ? 1 : 0,
            'status' => (int) $_POST['status'],
            'sort_order' => (int) $_POST['sort_order'],
            'description' => trim($_POST['description']),
            'updated_at' => now(),
        ];
        if ($data['name'] === '') {
            set_flash('error', '请填写套餐名称。');
            $this->back();
        }
        $model = new Package();
        if (!empty($_POST['id'])) {
            $id = (int) $_POST['id'];
            $model->update($id, $data);
        } else {
            $data['created_at'] = now();
            $id = $model->create($data);
        }
        $this->adminLog('保存套餐', 'package', $id);
        set_flash('success', '套餐已保存。');
        $this->redirect('admin/packages');
    }

    public function deletePackage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        (new Package())->delete($id);
        $this->adminLog('删除套餐', 'package', $id);
        set_flash('success', '套餐已删除。');
        $this->redirect('admin/packages');
    }

    public function coupons()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动'),
            '营销活动',
            '营销活动依赖优惠码和核销记录数据表。系统自动升级失败时，请先执行数据库巡检修复。'
        )) {
            return;
        }
        $this->adminView('admin/coupons', [
            'title' => '营销活动',
            'coupons' => (new Coupon())->all('sort_order ASC, id DESC'),
            'packages' => (new Package())->all('sort_order ASC, id ASC'),
            'editCoupon' => !empty($_GET['id']) ? (new Coupon())->find((int) $_GET['id']) : null,
            'couponStats' => $this->couponStats(),
            'recentRedemptions' => $this->recentCouponRedemptions(),
        ]);
    }

    public function cards()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理'),
            '卡密管理',
            '卡密管理依赖 redeem_cards 数据表。系统自动升级失败时，请先执行数据库巡检修复。'
        )) {
            return;
        }
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $type = isset($_GET['type']) && in_array($_GET['type'], ['balance', 'package'], true) ? $_GET['type'] : '';
        $status = isset($_GET['status']) && in_array($_GET['status'], ['unused', 'used', 'disabled'], true) ? $_GET['status'] : '';
        $where = [];
        $params = [];
        if ($keyword !== '') {
            $where[] = '(c.batch_no LIKE ? OR c.title LIKE ? OR c.code_preview LIKE ? OR c.channel LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        if ($type !== '') {
            $where[] = 'c.type = ?';
            $params[] = $type;
        }
        if ($status !== '') {
            $where[] = 'c.status = ?';
            $params[] = $status;
        }
        $sql = 'SELECT c.*, u.username, p.name AS package_name, o.order_no
                FROM ' . Database::table('redeem_cards') . ' c
                LEFT JOIN ' . Database::table('users') . ' u ON c.used_by = u.id
                LEFT JOIN ' . Database::table('packages') . ' p ON c.package_id = p.id
                LEFT JOIN ' . Database::table('orders') . ' o ON c.order_id = o.id';
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY c.id DESC LIMIT 300';
        $generated = isset($_SESSION['generated_redeem_cards']) ? $_SESSION['generated_redeem_cards'] : null;
        unset($_SESSION['generated_redeem_cards']);
        $this->adminView('admin/cards', [
            'title' => '卡密管理',
            'cards' => Database::fetchAll($sql, $params),
            'packages' => (new Package())->all('sort_order ASC, id ASC'),
            'cardStats' => (new RedeemCardService())->stats(),
            'generatedCards' => $generated,
            'filters' => ['keyword' => $keyword, 'type' => $type, 'status' => $status],
        ]);
    }

    public function generateCards()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理'),
            '卡密管理',
            'admin/cards',
            '卡密表结构未准备完成，请先进入数据库巡检执行一键修复。'
        )) {
            return;
        }
        try {
            $result = (new RedeemCardService())->generate([
                'type' => isset($_POST['type']) ? $_POST['type'] : 'balance',
                'title' => isset($_POST['title']) ? $_POST['title'] : '',
                'amount' => isset($_POST['amount']) ? $_POST['amount'] : 0,
                'package_id' => isset($_POST['package_id']) ? $_POST['package_id'] : 0,
                'duration_days' => isset($_POST['duration_days']) ? $_POST['duration_days'] : 0,
                'count' => isset($_POST['count']) ? $_POST['count'] : 1,
                'prefix' => isset($_POST['prefix']) ? $_POST['prefix'] : 'BM',
                'channel' => isset($_POST['channel']) ? $_POST['channel'] : '',
                'expire_at' => isset($_POST['expire_at']) ? $_POST['expire_at'] : '',
                'remark' => isset($_POST['remark']) ? $_POST['remark'] : '',
                'created_by' => Auth::id(),
            ]);
            $_SESSION['generated_redeem_cards'] = $result;
            $this->adminLog('生成卡密', 'redeem_card', null);
            set_flash('success', '卡密已生成，本次明文只在当前页面展示，请及时复制保存。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/cards');
    }

    public function updateCardStatus()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理'),
            '卡密管理',
            'admin/cards',
            '卡密表结构未准备完成，请先进入数据库巡检执行一键修复。'
        )) {
            return;
        }
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $action = isset($_POST['action']) ? $_POST['action'] : '';
        $card = Database::fetch('SELECT * FROM ' . Database::table('redeem_cards') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$card) {
            set_flash('error', '卡密不存在。');
            $this->redirect('admin/cards');
        }
        if ($card['status'] === 'used') {
            set_flash('error', '已兑换卡密不能修改状态。');
            $this->redirect('admin/cards');
        }
        $status = $action === 'restore' ? 'unused' : 'disabled';
        Database::execute('UPDATE ' . Database::table('redeem_cards') . ' SET status = ?, updated_at = ? WHERE id = ?', [$status, now(), $id]);
        $this->adminLog($status === 'unused' ? '恢复卡密' : '停用卡密', 'redeem_card', $id);
        set_flash('success', $status === 'unused' ? '卡密已恢复可兑换。' : '卡密已停用。');
        $this->redirect('admin/cards');
    }

    public function deleteCard()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理'),
            '卡密管理',
            'admin/cards',
            '卡密表结构未准备完成，请先进入数据库巡检执行一键修复。'
        )) {
            return;
        }
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $card = Database::fetch('SELECT * FROM ' . Database::table('redeem_cards') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$card) {
            set_flash('error', '卡密不存在。');
            $this->redirect('admin/cards');
        }
        if ($card['status'] === 'used') {
            set_flash('error', '已兑换卡密不能删除，需要保留财务和售后记录。');
            $this->redirect('admin/cards');
        }
        Database::execute('DELETE FROM ' . Database::table('redeem_cards') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除未兑换卡密', 'redeem_card', $id);
        set_flash('success', '未兑换卡密已删除。');
        $this->redirect('admin/cards');
    }

    public function saveCoupon()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动'),
            '营销活动',
            'admin/coupons',
            '营销活动数据结构未准备完成，请先进入数据库巡检执行一键修复。'
        )) {
            return;
        }
        $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        $code = strtoupper(trim($_POST['code']));
        $data = [
            'title' => trim($_POST['title']),
            'code' => $code,
            'discount_type' => $_POST['discount_type'] === 'percent' ? 'percent' : 'fixed',
            'discount_value' => round((float) $_POST['discount_value'], 2),
            'min_amount' => round((float) $_POST['min_amount'], 2),
            'package_scope' => in_array($_POST['package_scope'], ['all', 'include', 'exclude'], true) ? $_POST['package_scope'] : 'all',
            'package_ids' => isset($_POST['package_ids']) && is_array($_POST['package_ids']) ? implode(',', array_map('intval', $_POST['package_ids'])) : '',
            'start_at' => $this->normalizeDateTime(isset($_POST['start_at']) ? $_POST['start_at'] : ''),
            'end_at' => $this->normalizeDateTime(isset($_POST['end_at']) ? $_POST['end_at'] : ''),
            'total_limit' => max(0, (int) $_POST['total_limit']),
            'user_limit' => max(0, (int) $_POST['user_limit']),
            'first_order_only' => isset($_POST['first_order_only']) ? 1 : 0,
            'status' => (int) $_POST['status'],
            'sort_order' => (int) $_POST['sort_order'],
            'description' => trim($_POST['description']),
            'updated_at' => now(),
        ];
        if ($data['title'] === '' || $data['code'] === '') {
            set_flash('error', '请填写活动名称和优惠码。');
            $this->back();
        }
        if ($data['discount_value'] <= 0) {
            set_flash('error', '优惠力度必须大于 0。');
            $this->back();
        }
        if ($data['discount_type'] === 'percent' && $data['discount_value'] > 100) {
            set_flash('error', '折扣比例不能超过 100%。');
            $this->back();
        }
        $exists = Database::fetch('SELECT id FROM ' . Database::table('coupons') . ' WHERE code = ? AND id <> ? LIMIT 1', [$data['code'], $id]);
        if ($exists) {
            set_flash('error', '优惠码已存在，请换一个更容易识别的代码。');
            $this->back();
        }
        if ($id) {
            (new Coupon())->update($id, $data);
        } else {
            $data['created_at'] = now();
            $id = (new Coupon())->create($data);
        }
        $this->adminLog('保存营销活动', 'coupon', $id);
        set_flash('success', '营销活动已保存。');
        $this->redirect('admin/coupons');
    }

    public function deleteCoupon()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动'),
            '营销活动',
            'admin/coupons',
            '营销活动数据结构未准备完成，请先进入数据库巡检执行一键修复。'
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('coupon_redemptions') . ' WHERE coupon_id = ?', [$id]);
        if ($used && (int) $used['c'] > 0) {
            Database::execute('UPDATE ' . Database::table('coupons') . ' SET status = 0, updated_at = ? WHERE id = ?', [now(), $id]);
            set_flash('success', '该活动已有使用记录，已改为停用。');
        } else {
            (new Coupon())->delete($id);
            set_flash('success', '营销活动已删除。');
        }
        $this->adminLog('删除营销活动', 'coupon', $id);
        $this->redirect('admin/coupons');
    }

    public function orders()
    {
        if (!$this->ensureAdminTables(
            ['orders', 'users', 'packages'],
            '订单管理',
            '订单管理依赖 orders、users、packages 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'status' => trim(isset($_GET['status']) ? $_GET['status'] : ''),
            'type' => trim(isset($_GET['type']) ? $_GET['type'] : ''),
            'payment_method' => trim(isset($_GET['payment_method']) ? $_GET['payment_method'] : ''),
        ];
        $where = [];
        $params = [];
        if ($filters['keyword'] !== '') {
            $where[] = '(o.order_no LIKE ? OR u.username LIKE ? OR o.trade_no LIKE ?)';
            $params[] = '%' . $filters['keyword'] . '%';
            $params[] = '%' . $filters['keyword'] . '%';
            $params[] = '%' . $filters['keyword'] . '%';
        }
        if ($filters['status'] !== '') {
            $where[] = 'o.status = ?';
            $params[] = $filters['status'];
        }
        if ($filters['type'] !== '') {
            $where[] = 'o.type = ?';
            $params[] = $filters['type'];
        }
        if ($filters['payment_method'] !== '') {
            $where[] = 'o.payment_method = ?';
            $params[] = $filters['payment_method'];
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $rows = Database::fetchAll(
            'SELECT o.*, u.username, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ' . $whereSql . ' ORDER BY o.id DESC LIMIT 300',
            $params
        );
        $filteredStats = [
            'total' => count($rows),
            'pending' => 0,
            'paid' => 0,
            'recharge' => 0,
            'package' => 0,
            'amount' => 0.0,
        ];
        foreach ($rows as $row) {
            if ($row['status'] === 'pending') {
                $filteredStats['pending']++;
            }
            if ($row['status'] === 'paid') {
                $filteredStats['paid']++;
            }
            if ($row['type'] === 'recharge') {
                $filteredStats['recharge']++;
            } else {
                $filteredStats['package']++;
            }
            $filteredStats['amount'] += (float) $row['pay_amount'];
        }
        $orderStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending, " .
            "SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid, " .
            "SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) AS today, " .
            "COALESCE(SUM(CASE WHEN status = 'paid' THEN pay_amount ELSE 0 END),0) AS revenue " .
            'FROM ' . Database::table('orders')
        );
        $this->adminView('admin/orders', [
            'title' => '订单管理',
            'orders' => $rows,
            'filters' => $filters,
            'orderStats' => $orderStats,
            'filteredStats' => $filteredStats,
        ]);
    }

    public function orderDetail()
    {
        if (!$this->ensureAdminTables(
            ['orders', 'users', 'packages', 'recharges', 'balance_logs'],
            '订单详情',
            '订单详情依赖订单、充值和余额流水数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $order = Database::fetch('SELECT o.*, u.username, u.nickname, u.email, u.balance, u.created_at AS user_created_at, p.name AS package_name, p.price AS package_price FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id WHERE o.id = ? LIMIT 1', [$id]);
        if (!$order) {
            set_flash('error', '订单不存在。');
            $this->redirect('admin/orders');
        }
        $recharge = null;
        if ($order['type'] === 'recharge') {
            $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE order_id = ? LIMIT 1', [$order['id']]);
        }
        $relatedTypes = ['order'];
        $relatedIds = [$order['id']];
        if ($recharge) {
            $relatedTypes[] = 'recharge';
            $relatedIds[] = $recharge['id'];
        }
        $placeholders = implode(',', array_fill(0, count($relatedTypes), '?'));
        $idPlaceholders = implode(',', array_fill(0, count($relatedIds), '?'));
        $balanceLogs = Database::fetchAll(
            'SELECT * FROM ' . Database::table('balance_logs') . ' WHERE related_type IN (' . $placeholders . ') AND related_id IN (' . $idPlaceholders . ') ORDER BY id DESC LIMIT 20',
            array_merge($relatedTypes, $relatedIds)
        );
        $this->adminView('admin/order_detail', [
            'title' => '订单详情',
            'order' => $order,
            'recharge' => $recharge,
            'balanceLogs' => $balanceLogs,
        ]);
    }

    public function exportOrders()
    {
        $this->requireAdmin();
        if (!$this->ensureAdminTables(
            ['orders', 'users', 'packages'],
            '订单导出',
            '订单导出依赖 orders、users、packages 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $rows = Database::fetchAll('SELECT o.*, u.username, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=orders-' . date('YmdHis') . '.csv');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        fputcsv($out, ['订单号', '用户', '类型', '套餐', '原价', '实付', '支付方式', '状态', '交易号', '支付时间', '创建时间']);
        foreach ($rows as $row) {
            fputcsv($out, [$row['order_no'], $row['username'], $row['type'], $row['package_name'], $row['amount'], $row['pay_amount'], $row['payment_method'], $row['status'], $row['trade_no'], $row['paid_at'], $row['created_at']]);
        }
        fclose($out);
        exit;
    }

    public function recharges()
    {
        if (!$this->ensureAdminTables(
            ['recharges', 'users', 'orders'],
            '充值审核',
            '充值审核依赖 recharges、users、orders 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'status' => trim(isset($_GET['status']) ? $_GET['status'] : ''),
            'payment_method' => trim(isset($_GET['payment_method']) ? $_GET['payment_method'] : ''),
        ];
        $where = [];
        $params = [];
        if ($filters['keyword'] !== '') {
            $where[] = '(u.username LIKE ? OR o.order_no LIKE ? OR CAST(r.id AS CHAR) LIKE ?)';
            $params[] = '%' . $filters['keyword'] . '%';
            $params[] = '%' . $filters['keyword'] . '%';
            $params[] = '%' . $filters['keyword'] . '%';
        }
        if ($filters['status'] !== '') {
            $where[] = 'r.status = ?';
            $params[] = $filters['status'];
        }
        if ($filters['payment_method'] !== '') {
            $where[] = 'r.payment_method = ?';
            $params[] = $filters['payment_method'];
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $rows = Database::fetchAll(
            "SELECT r.*, u.username, o.order_no FROM " . Database::table('recharges') . " r LEFT JOIN " . Database::table('users') . " u ON r.user_id = u.id LEFT JOIN " . Database::table('orders') . " o ON r.order_id = o.id " . $whereSql . " ORDER BY FIELD(r.status, 'pending', 'paid', 'rejected'), r.id DESC LIMIT 300",
            $params
        );
        $filteredStats = [
            'total' => count($rows),
            'pending' => 0,
            'paid' => 0,
            'rejected' => 0,
            'amount' => 0.0,
        ];
        foreach ($rows as $row) {
            if (isset($filteredStats[$row['status']])) {
                $filteredStats[$row['status']]++;
            }
            $filteredStats['amount'] += (float) $row['amount'];
        }
        $rechargeStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending, " .
            "SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid, " .
            "SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected, " .
            "COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END),0) AS amount_paid " .
            'FROM ' . Database::table('recharges')
        );
        $this->adminView('admin/recharges', [
            'title' => '充值审核',
            'recharges' => $rows,
            'filters' => $filters,
            'rechargeStats' => $rechargeStats,
            'filteredStats' => $filteredStats,
        ]);
    }

    public function payments()
    {
        if (!$this->ensureAdminTables(
            ['payment_config'],
            '支付配置',
            '支付配置依赖 payment_config 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $rows = Database::fetchAll('SELECT * FROM ' . Database::table('payment_config') . ' ORDER BY sort_order ASC, id ASC');
        $paymentStats = [
            'total' => count($rows),
            'enabled' => 0,
            'manual' => 0,
            'online' => 0,
            'configured' => 0,
        ];
        foreach ($rows as $row) {
            $config = json_decode((string) $row['config'], true);
            $config = is_array($config) ? $config : [];
            if (!empty($row['is_enabled'])) {
                $paymentStats['enabled']++;
            }
            if ($row['code'] === 'manual') {
                $paymentStats['manual']++;
            } else {
                $paymentStats['online']++;
            }
            if ($row['code'] === 'alipay') {
                if (!empty($config['app_id']) && !empty($config['private_key']) && !empty($config['alipay_public_key'])) {
                    $paymentStats['configured']++;
                }
            } elseif ($row['code'] === 'manual') {
                if (!empty($config['instructions']) || !empty($config['contact'])) {
                    $paymentStats['configured']++;
                }
            } elseif (!empty($config)) {
                $paymentStats['configured']++;
            }
        }
        $this->adminView('admin/payments', ['title' => '支付配置', 'payments' => $rows, 'paymentStats' => $paymentStats]);
    }

    public function savePayment()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $code = isset($_POST['code']) ? $_POST['code'] : '';
        $config = [];
        if ($code === 'alipay') {
            $config = [
                'app_id' => trim(isset($_POST['app_id']) ? $_POST['app_id'] : ''),
                'private_key' => trim(isset($_POST['private_key']) ? $_POST['private_key'] : ''),
                'alipay_public_key' => trim(isset($_POST['alipay_public_key']) ? $_POST['alipay_public_key'] : ''),
                'sandbox' => !empty($_POST['sandbox']),
                'notify_url' => trim(isset($_POST['notify_url']) ? $_POST['notify_url'] : ''),
                'timeout_express' => trim(isset($_POST['timeout_express']) ? $_POST['timeout_express'] : '10m'),
            ];
        } elseif ($code === 'manual') {
            $config = [
                'instructions' => trim(isset($_POST['instructions']) ? $_POST['instructions'] : ''),
                'contact' => trim(isset($_POST['contact']) ? $_POST['contact'] : ''),
            ];
        } elseif (!empty($_POST['config_json'])) {
            $decoded = json_decode($_POST['config_json'], true);
            if (!is_array($decoded)) {
                set_flash('error', '支付配置 JSON 格式错误。');
                $this->redirect('admin/payments');
            }
            $config = $decoded;
        }
        Database::execute(
            'UPDATE ' . Database::table('payment_config') . ' SET name = ?, config = ?, is_enabled = ?, sort_order = ?, updated_at = ? WHERE id = ?',
            [trim($_POST['name']), json_encode($config, JSON_UNESCAPED_UNICODE), (int) $_POST['is_enabled'], (int) $_POST['sort_order'], now(), $id]
        );
        $this->adminLog('保存支付配置', 'payment', $id);
        set_flash('success', '支付配置已保存。');
        $this->redirect('admin/payments');
    }

    public function auditRecharge()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$recharge || $recharge['status'] !== 'pending') {
            set_flash('error', '充值记录不存在或已处理。');
            $this->redirect('admin/recharges');
        }
        if ($_POST['action'] === 'approve') {
            Database::begin();
            try {
                Database::execute('UPDATE ' . Database::table('recharges') . ' SET status = ?, auditor_id = ?, audit_remark = ?, paid_at = ?, updated_at = ? WHERE id = ?', ['paid', Auth::id(), trim($_POST['remark']), now(), now(), $id]);
                Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, paid_at = ?, updated_at = ? WHERE id = ?', ['paid', now(), now(), $recharge['order_id']]);
                (new BalanceService())->add($recharge['user_id'], $recharge['amount'], 'recharge', 'recharge', $id, '人工充值审核通过');
                (new NotificationService())->send($recharge['user_id'], 'recharge', '充值成功', '你的账户已充值 ' . $recharge['amount'] . ' 元。');
                Database::commit();
            } catch (\Throwable $e) {
                Database::rollBack();
                throw $e;
            }
        } else {
            Database::execute('UPDATE ' . Database::table('recharges') . ' SET status = ?, auditor_id = ?, audit_remark = ?, updated_at = ? WHERE id = ?', ['rejected', Auth::id(), trim($_POST['remark']), now(), $id]);
            Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?', ['closed', now(), $recharge['order_id']]);
        }
        $this->adminLog('审核充值', 'recharge', $id);
        set_flash('success', '充值审核已处理。');
        $this->redirect('admin/recharges');
    }

    public function manualPaidOrder()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $orderNo = trim($_POST['order_no']);
        $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1', [$orderNo]);
        if (!$order || $order['status'] !== 'pending' || !in_array($order['type'], ['recharge', 'package'], true)) {
            set_flash('error', '仅支持处理待支付的充值或套餐订单。');
            $this->redirect('admin/orders');
        }
        try {
            (new PaymentService())->markOrderPaid($orderNo, 'MANUAL-' . date('YmdHis'), $order['pay_amount']);
            $this->adminLog('手动补单', 'order', $order['id']);
            set_flash('success', $order['type'] === 'package' ? '手动补单成功，套餐已开通。' : '手动补单成功，余额已入账。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/orders');
    }

    public function storages()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->ensureStorageDriverSchemaReady(),
            '资源功能管理',
            '资源功能管理依赖 storage_drivers 数据表和存储类型字段。系统自动升级失败时，请先执行数据库巡检修复。'
        )) {
            return;
        }
        $storages = Database::fetchAll('SELECT * FROM ' . Database::table('storage_drivers') . " WHERE type <> 'bmtools' ORDER BY is_default DESC, id DESC");
        $editStorage = !empty($_GET['id']) ? (new StorageDriver())->find((int) $_GET['id']) : null;
        if ($editStorage && isset($editStorage['type']) && $editStorage['type'] === 'bmtools') {
            $this->redirect('admin/storage-integrations?id=' . (int) $editStorage['id']);
        }
        $this->adminView('admin/storages', [
            'title' => '资源功能管理',
            'storages' => $storages,
            'editStorage' => $editStorage,
            'storageStats' => $this->storageStats($storages),
            'storagePageMode' => 'storage',
        ]);
    }

    public function storageIntegrations()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->ensureStorageDriverSchemaReady(),
            '同系统对接',
            '同系统对接依赖 storage_drivers 数据表和 bmtools 存储类型字段，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $storages = Database::fetchAll('SELECT * FROM ' . Database::table('storage_drivers') . " WHERE type = 'bmtools' ORDER BY is_default DESC, id DESC");
        $editStorage = !empty($_GET['id']) ? (new StorageDriver())->find((int) $_GET['id']) : null;
        if ($editStorage && (!isset($editStorage['type']) || $editStorage['type'] !== 'bmtools')) {
            $this->redirect('admin/storages?id=' . (int) $editStorage['id']);
        }
        $this->adminView('admin/storages', [
            'title' => '同系统对接',
            'storages' => $storages,
            'editStorage' => $editStorage,
            'storageStats' => $this->storageStats($storages),
            'storagePageMode' => 'integration',
        ]);
    }

    public function storageBackups()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureStorageBackupSchema'], '备份策略'),
            '备份策略',
            '备份策略依赖 storage_backup_policies 和 file_storage_backups 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        if (!$this->ensureAdminFeatureSchema(
            $this->ensureStorageDriverSchemaReady(),
            '备份策略',
            '备份策略需要可用的存储源，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new StorageBackupService();
        $storages = Database::fetchAll('SELECT id, name, type, is_enabled, is_default FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, is_enabled DESC, id DESC');
        $policies = Database::fetchAll('SELECT * FROM ' . Database::table('storage_backup_policies') . ' ORDER BY sort_order ASC, id DESC');
        foreach ($policies as &$policy) {
            $policy['backup_names'] = $service->policyStorageNames($policy, $storages);
        }
        unset($policy);
        $editPolicy = !empty($_GET['id']) ? Database::fetch('SELECT * FROM ' . Database::table('storage_backup_policies') . ' WHERE id = ? LIMIT 1', [(int) $_GET['id']]) : null;
        if ($editPolicy) {
            $editPolicy['backup_storage_id_list'] = $service->policyStorageIds($editPolicy);
        }
        $stats = [
            'policies' => $this->safeCount('storage_backup_policies'),
            'enabled_policies' => $this->safeCount('storage_backup_policies', 'is_enabled = 1'),
            'success' => $this->safeCount('file_storage_backups', "status = 'success'"),
            'failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
        ];
        $this->adminView('admin/storage_backups', [
            'title' => '备份策略',
            'storages' => $storages,
            'policies' => $policies,
            'editPolicy' => $editPolicy,
            'stats' => $stats,
            'service' => $service,
        ]);
    }

    public function storageBackupTasks()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureStorageBackupSchema'], '备份任务'),
            '备份任务',
            '备份任务依赖 file_storage_backups 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        if (!$this->ensureAdminFeatureSchema(
            $this->ensureStorageDriverSchemaReady(),
            '备份任务',
            '备份任务需要可用的存储源，请先执行数据库巡检修复。',
        )) {
            return;
        }

        $filters = [
            'status' => isset($_GET['status']) ? trim((string) $_GET['status']) : '',
            'policy_id' => isset($_GET['policy_id']) ? max(0, (int) $_GET['policy_id']) : 0,
            'storage_id' => isset($_GET['storage_id']) ? max(0, (int) $_GET['storage_id']) : 0,
            'file_scope' => isset($_GET['file_scope']) ? trim((string) $_GET['file_scope']) : '',
        ];
        if (!in_array($filters['status'], ['', 'pending', 'success', 'failed', 'skipped', 'deleted'], true)) {
            $filters['status'] = '';
        }
        if (!in_array($filters['file_scope'], ['', 'image', 'file'], true)) {
            $filters['file_scope'] = '';
        }

        $where = [];
        $params = [];
        if ($filters['status'] !== '') {
            $where[] = 'b.status = ?';
            $params[] = $filters['status'];
        }
        if ($filters['policy_id'] > 0) {
            $where[] = 'b.policy_id = ?';
            $params[] = $filters['policy_id'];
        }
        if ($filters['storage_id'] > 0) {
            $where[] = 'b.storage_id = ?';
            $params[] = $filters['storage_id'];
        }
        if ($filters['file_scope'] !== '') {
            $where[] = 'f.file_type = ?';
            $params[] = $filters['file_scope'];
        }
        $whereSql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';

        $tasks = Database::fetchAll(
            'SELECT b.*, f.original_name, f.file_type, f.file_size, f.file_url AS primary_url, s.name AS storage_name, s.type AS storage_type, p.name AS policy_name
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON b.storage_id = s.id
             LEFT JOIN ' . Database::table('storage_backup_policies') . ' p ON b.policy_id = p.id' . $whereSql . '
             ORDER BY b.id DESC
             LIMIT 120',
            $params
        );
        $stats = [
            'total' => $this->safeCount('file_storage_backups'),
            'success' => $this->safeCount('file_storage_backups', "status = 'success'"),
            'failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
            'pending' => $this->safeCount('file_storage_backups', "status = 'pending'"),
        ];

        $this->adminView('admin/storage_backup_tasks', [
            'title' => '备份任务',
            'tasks' => $tasks,
            'policies' => Database::fetchAll('SELECT id, name FROM ' . Database::table('storage_backup_policies') . ' ORDER BY sort_order ASC, id DESC'),
            'storages' => Database::fetchAll('SELECT id, name, type, is_enabled, is_default FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, is_enabled DESC, id DESC'),
            'filters' => $filters,
            'stats' => $stats,
        ]);
    }

    public function storageBackupBackfill()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureStorageBackupSchema'], '历史文件补备'),
            '历史文件补备',
            '历史文件补备依赖备份数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        if (!$this->ensureAdminFeatureSchema(
            $this->ensureStorageDriverSchemaReady(),
            '历史文件补备',
            '历史文件补备需要可用的存储源，请先执行数据库巡检修复。',
        )) {
            return;
        }

        $localFiles = 0;
        try {
            $row = Database::fetch(
                'SELECT COUNT(*) AS c
                 FROM ' . Database::table('files') . ' f
                 INNER JOIN ' . Database::table('storage_drivers') . " s ON f.storage_id = s.id
                 WHERE s.type = 'local'"
            );
            $localFiles = $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            $localFiles = 0;
        }

        $this->adminView('admin/storage_backup_backfill', [
            'title' => '历史文件补备',
            'policies' => Database::fetchAll('SELECT id, name, file_scope, primary_storage_id FROM ' . Database::table('storage_backup_policies') . ' WHERE is_enabled = 1 ORDER BY sort_order ASC, id DESC'),
            'storages' => Database::fetchAll('SELECT id, name, type, is_enabled, is_default FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, is_enabled DESC, id DESC'),
            'stats' => [
                'local_files' => $localFiles,
                'success' => $this->safeCount('file_storage_backups', "status = 'success'"),
                'failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
                'policies' => $this->safeCount('storage_backup_policies', 'is_enabled = 1'),
            ],
        ]);
    }

    public function storageMigration()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureStorageBackupSchema'], '存储迁移'),
            '存储迁移',
            '存储迁移依赖 file_storage_backups 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        if (!$this->ensureAdminFeatureSchema(
            $this->ensureStorageDriverSchemaReady(),
            '存储迁移',
            '存储迁移需要可用的存储源，请先执行数据库巡检修复。',
        )) {
            return;
        }

        $filters = [
            'source_storage_id' => isset($_GET['source_storage_id']) ? max(0, (int) $_GET['source_storage_id']) : 0,
            'target_storage_id' => isset($_GET['target_storage_id']) ? max(0, (int) $_GET['target_storage_id']) : 0,
            'file_scope' => isset($_GET['file_scope']) && in_array($_GET['file_scope'], ['image', 'file'], true) ? $_GET['file_scope'] : '',
        ];
        $service = new StorageMigrationService();
        $this->adminView('admin/storage_migration', [
            'title' => '存储迁移',
            'storages' => Database::fetchAll('SELECT id, name, type, is_enabled, is_default FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, is_enabled DESC, id DESC'),
            'filters' => $filters,
            'plan' => $service->plan($filters),
            'tasks' => $service->recentTasks(80),
            'summary' => flash('storage_migration_summary', null),
        ]);
    }

    public function runStorageMigration()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->ensureStorageBackupSchemaOrRedirect('admin/storage-migration');

        $options = [
            'source_storage_id' => isset($_POST['source_storage_id']) ? max(0, (int) $_POST['source_storage_id']) : 0,
            'target_storage_id' => isset($_POST['target_storage_id']) ? max(0, (int) $_POST['target_storage_id']) : 0,
            'file_scope' => isset($_POST['file_scope']) && in_array($_POST['file_scope'], ['image', 'file'], true) ? $_POST['file_scope'] : '',
            'limit' => isset($_POST['limit']) ? (int) $_POST['limit'] : 20,
            'switch_primary' => isset($_POST['switch_primary']) ? 1 : 0,
        ];
        if ($options['target_storage_id'] <= 0) {
            set_flash('error', '请选择目标存储。');
            $this->redirect('admin/storage-migration');
        }
        if ($options['source_storage_id'] > 0 && $options['source_storage_id'] === $options['target_storage_id']) {
            set_flash('error', '源存储和目标存储不能相同。');
            $this->redirect('admin/storage-migration');
        }

        try {
            $summary = (new StorageMigrationService())->migrate($options);
            set_flash('storage_migration_summary', $summary);
            set_flash('success', '存储迁移批次已执行：扫描 ' . (int) $summary['scanned'] . ' 个，上传 ' . (int) $summary['uploaded'] . ' 个，切换 ' . (int) $summary['switched'] . ' 个。');
            $this->adminLog('执行存储迁移', 'storage_migration', $options['target_storage_id']);
        } catch (\Throwable $e) {
            set_flash('error', '存储迁移失败：' . $e->getMessage());
        }

        $query = http_build_query([
            'source_storage_id' => $options['source_storage_id'],
            'target_storage_id' => $options['target_storage_id'],
            'file_scope' => $options['file_scope'],
        ]);
        $this->redirect('admin/storage-migration' . ($query ? '?' . $query : ''));
    }

    public function saveStorageBackupPolicy()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->ensureStorageBackupSchemaOrRedirect();

        $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        $name = trim(isset($_POST['name']) ? (string) $_POST['name'] : '');
        $primaryStorageId = max(0, (int) (isset($_POST['primary_storage_id']) ? $_POST['primary_storage_id'] : 0));
        $fileScope = isset($_POST['file_scope']) && in_array($_POST['file_scope'], ['all', 'image', 'file'], true) ? $_POST['file_scope'] : 'all';
        $mode = 'sync';
        $failureStrategy = isset($_POST['failure_strategy']) && in_array($_POST['failure_strategy'], ['ignore', 'warn', 'strict'], true) ? $_POST['failure_strategy'] : 'warn';
        $backupIds = isset($_POST['backup_storage_ids']) ? (array) $_POST['backup_storage_ids'] : [];
        $cleanBackupIds = [];
        foreach ($backupIds as $storageId) {
            $storageId = (int) $storageId;
            if ($storageId > 0 && $storageId !== $primaryStorageId) {
                $storage = Database::fetch('SELECT id FROM ' . Database::table('storage_drivers') . ' WHERE id = ? AND is_enabled = 1 LIMIT 1', [$storageId]);
                if ($storage) {
                    $cleanBackupIds[$storageId] = $storageId;
                }
            }
        }
        if ($name === '') {
            set_flash('error', '请填写备份策略名称。');
            $this->redirect('admin/storage-backups');
        }
        if (!$cleanBackupIds) {
            set_flash('error', '请至少选择一个可用的备份存储源。');
            $this->redirect('admin/storage-backups');
        }
        $data = [
            'name' => $name,
            'primary_storage_id' => $primaryStorageId,
            'backup_storage_ids' => json_encode(array_values($cleanBackupIds)),
            'file_scope' => $fileScope,
            'mode' => $mode,
            'failure_strategy' => $failureStrategy,
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'sort_order' => (int) (isset($_POST['sort_order']) ? $_POST['sort_order'] : 0),
            'updated_at' => now(),
        ];
        if ($id > 0) {
            Database::execute(
                'UPDATE ' . Database::table('storage_backup_policies') . ' SET name = ?, primary_storage_id = ?, backup_storage_ids = ?, file_scope = ?, mode = ?, failure_strategy = ?, is_enabled = ?, sort_order = ?, updated_at = ? WHERE id = ?',
                [$data['name'], $data['primary_storage_id'], $data['backup_storage_ids'], $data['file_scope'], $data['mode'], $data['failure_strategy'], $data['is_enabled'], $data['sort_order'], $data['updated_at'], $id]
            );
        } else {
            $data['created_at'] = now();
            Database::execute(
                'INSERT INTO ' . Database::table('storage_backup_policies') . ' (name, primary_storage_id, backup_storage_ids, file_scope, mode, failure_strategy, is_enabled, sort_order, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [$data['name'], $data['primary_storage_id'], $data['backup_storage_ids'], $data['file_scope'], $data['mode'], $data['failure_strategy'], $data['is_enabled'], $data['sort_order'], $data['created_at'], $data['updated_at']]
            );
            $id = (int) Database::lastInsertId();
        }
        $this->adminLog($id > 0 ? '保存备份策略' : '新增备份策略', 'storage_backup_policy', $id);
        set_flash('success', '备份策略已保存。');
        $this->redirect('admin/storage-backups');
    }

    public function deleteStorageBackupPolicy()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->ensureStorageBackupSchemaOrRedirect();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        Database::execute('DELETE FROM ' . Database::table('storage_backup_policies') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除备份策略', 'storage_backup_policy', $id);
        set_flash('success', '备份策略已删除。');
        $this->redirect('admin/storage-backups');
    }

    public function retryStorageBackup()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->ensureStorageBackupSchemaOrRedirect('admin/storage-backups/tasks');
        try {
            (new StorageBackupService())->retryBackup((int) (isset($_POST['id']) ? $_POST['id'] : 0));
            set_flash('success', '备份任务已重新加入队列。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/storage-backups/tasks');
    }

    public function retryFailedStorageBackups()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->ensureStorageBackupSchemaOrRedirect('admin/storage-backups/tasks');
        $service = new StorageBackupService();
        $summary = $service->retryFailedBackups([
            'limit' => isset($_POST['limit']) ? (int) $_POST['limit'] : 20,
            'policy_id' => isset($_POST['policy_id']) ? (int) $_POST['policy_id'] : 0,
            'storage_id' => isset($_POST['storage_id']) ? (int) $_POST['storage_id'] : 0,
            'file_scope' => isset($_POST['file_scope']) ? (string) $_POST['file_scope'] : '',
        ]);
        $message = '批量重试完成：成功 ' . (int) $summary['success'] . ' 个，失败 ' . (int) $summary['failed'] . ' 个。';
        if (!empty($summary['errors'])) {
            $message .= ' 示例错误：' . implode('；', $summary['errors']);
        }
        set_flash($summary['failed'] > 0 ? 'error' : 'success', $message);
        $this->adminLog('批量重试备份任务', 'storage_backup_task', null);
        $this->redirect('admin/storage-backups/tasks');
    }

    public function runStorageBackupBackfill()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->ensureStorageBackupSchemaOrRedirect('admin/storage-backups/backfill');
        $service = new StorageBackupService();
        $summary = $service->backfillLocalFiles([
            'limit' => isset($_POST['limit']) ? (int) $_POST['limit'] : 20,
            'policy_id' => isset($_POST['policy_id']) ? (int) $_POST['policy_id'] : 0,
            'primary_storage_id' => isset($_POST['primary_storage_id']) ? (int) $_POST['primary_storage_id'] : 0,
            'target_storage_id' => isset($_POST['target_storage_id']) ? (int) $_POST['target_storage_id'] : 0,
            'file_scope' => isset($_POST['file_scope']) ? (string) $_POST['file_scope'] : '',
        ]);
        $message = '历史补备完成：扫描 ' . (int) $summary['scanned'] . ' 个文件，执行 ' . (int) $summary['targets'] . ' 个目标，成功 ' . (int) $summary['success'] . '，失败 ' . (int) $summary['failed'] . '，跳过 ' . (int) $summary['skipped'] . '。';
        if ((int) $summary['unreadable'] > 0) {
            $message .= ' 本地不可读 ' . (int) $summary['unreadable'] . ' 个。';
        }
        if (!empty($summary['errors'])) {
            $message .= ' 示例错误：' . implode('；', $summary['errors']);
        }
        set_flash($summary['failed'] > 0 ? 'error' : 'success', $message);
        $this->adminLog('执行历史文件补备', 'storage_backup_backfill', null);
        $this->redirect('admin/storage-backups/backfill');
    }

    public function saveStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        $type = isset($_POST['type']) ? $_POST['type'] : 'local';
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->ensureStorageDriverSchemaReady(),
            '资源功能管理',
            $this->storageRedirect($type),
            '资源功能管理依赖 storage_drivers 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $old = $id ? (new StorageDriver())->find($id) : null;
        if (!in_array($type, ['local', 'oss', 'cos', 'kodo', 's3', 'minio', 'r2', 'webdav', 'bmtools'], true)) {
            set_flash('error', '不支持的存储类型。');
            $this->back();
        }
        $secretInput = trim(isset($_POST['secret_key']) ? $_POST['secret_key'] : '');
        $plainSecret = $secretInput;
        $storedSecret = $secretInput !== '' ? CryptoService::encrypt($secretInput) : '';
        if ($old && $secretInput === '') {
            $plainSecret = CryptoService::decrypt($old['secret_key']);
            $storedSecret = $old['secret_key'];
        }
        $data = $this->normalizeStorageInput([
            'name' => trim($_POST['name']),
            'type' => $type,
            'access_key' => trim(isset($_POST['access_key']) ? $_POST['access_key'] : ''),
            'secret_key' => $storedSecret,
            'bucket' => trim(isset($_POST['bucket']) ? $_POST['bucket'] : ''),
            'region' => trim(isset($_POST['region']) ? $_POST['region'] : ''),
            'endpoint' => trim(isset($_POST['endpoint']) ? $_POST['endpoint'] : ''),
            'domain' => trim(isset($_POST['domain']) ? $_POST['domain'] : ''),
            'prefix' => trim(trim(isset($_POST['prefix']) ? $_POST['prefix'] : ''), '/'),
            'is_enabled' => (int) (isset($_POST['is_enabled']) ? $_POST['is_enabled'] : 1),
            'is_default' => isset($_POST['is_default']) ? 1 : 0,
            'is_public' => isset($_POST['is_public']) ? 1 : 0,
            'updated_at' => now(),
        ]);
        $error = $this->validateStorageInput($data, $plainSecret);
        if ($error !== '') {
            set_flash('error', $error);
            $this->back();
        }
        Database::begin();
        try {
            if ($data['is_default']) {
                Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 0');
            }
            if ($id) {
                (new StorageDriver())->update($id, $data);
            } else {
                $data['created_at'] = now();
                $id = (new StorageDriver())->create($data);
            }
            Database::commit();
        } catch (\Throwable $e) {
            Database::rollBack();
            throw $e;
        }
        $this->adminLog('保存存储源', 'storage', $id);
        set_flash('success', '存储源已保存。');
        $this->redirect($this->storageRedirect($data['type']));
    }

    protected function normalizeStorageInput(array $data)
    {
        foreach (['access_key', 'secret_key', 'bucket', 'region', 'endpoint', 'domain', 'prefix'] as $field) {
            $data[$field] = trim((string) $data[$field]);
        }
        $data['endpoint'] = rtrim($data['endpoint'], '/');
        $data['domain'] = rtrim($data['domain'], '/');
        if ($data['type'] === 'oss') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
            $data['endpoint'] = preg_replace('#/.*$#', '', $data['endpoint']);
            if ($data['bucket'] !== '') {
                $data['endpoint'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#', '', $data['endpoint']);
            }
        }
        if ($data['type'] === 'cos' && $data['endpoint'] !== '') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
            $data['endpoint'] = preg_replace('#/.*$#', '', $data['endpoint']);
            if ($data['bucket'] !== '') {
                $data['endpoint'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#', '', $data['endpoint']);
            }
        }
        if ($data['type'] === 'kodo' && $data['endpoint'] !== '') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
            $data['endpoint'] = preg_replace('#/.*$#', '', $data['endpoint']);
        }
        if ($data['type'] === 'kodo') {
            $data['region'] = $this->normalizeKodoRegion($data['region']);
        }
        if (in_array($data['type'], ['s3', 'minio', 'r2'], true) && $data['endpoint'] !== '') {
            if (!preg_match('#^https?://#i', $data['endpoint'])) {
                $data['endpoint'] = 'https://' . $data['endpoint'];
            }
            $parts = parse_url($data['endpoint']);
            if ($parts && !empty($parts['host'])) {
                $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
                $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
                $path = isset($parts['path']) ? trim($parts['path'], '/') : '';
                if ($data['bucket'] !== '' && ($path === $data['bucket'] || strpos($path, $data['bucket'] . '/') === 0)) {
                    $path = trim(substr($path, strlen($data['bucket'])), '/');
                }
                if ($data['type'] === 'r2') {
                    $path = '';
                }
                if ($data['bucket'] !== '' && stripos($parts['host'], $data['bucket'] . '.') === 0) {
                    $parts['host'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#i', '', $parts['host']);
                    $path = '';
                }
                $data['endpoint'] = rtrim($scheme . '://' . $parts['host'] . $port . ($path !== '' ? '/' . $path : ''), '/');
            }
        }
        if ($data['type'] === 'webdav') {
            if ($data['endpoint'] !== '' && !preg_match('#^https?://#i', $data['endpoint'])) {
                $data['endpoint'] = 'https://' . $data['endpoint'];
            }
            $data['bucket'] = trim($data['bucket'], '/');
            $data['region'] = '';
        }
        if ($data['domain'] !== '' && !preg_match('#^https?://#i', $data['domain'])) {
            $data['domain'] = 'https://' . $data['domain'];
        }
        if ($data['endpoint'] !== '' && in_array($data['type'], ['kodo', 'bmtools'], true) && !preg_match('#^https?://#i', $data['endpoint'])) {
            $data['endpoint'] = 'https://' . $data['endpoint'];
        }
        if ($data['type'] === 'bmtools') {
            $data['access_key'] = '';
            $data['bucket'] = '';
            $data['region'] = '';
            $data['domain'] = '';
        }
        return $data;
    }

    protected function validateStorageInput(array $data, $secret)
    {
        if ($data['name'] === '') {
            return '请填写存储名称。';
        }
        if ($data['type'] === 'local') {
            return '';
        }
        if ($data['type'] === 'bmtools') {
            if ($data['endpoint'] === '') {
                return '请填写同系统站点地址。';
            }
            if (!preg_match('#^https://#i', $data['endpoint'])) {
                return '同系统站点地址必须使用 HTTPS。';
            }
            $parts = parse_url($data['endpoint']);
            if (!$parts || empty($parts['host']) || !empty($parts['user']) || !empty($parts['pass']) || !empty($parts['query']) || !empty($parts['fragment'])) {
                return '同系统站点地址格式不正确，请只填写站点根地址。';
            }
            if ($this->isCurrentSiteEndpoint($data['endpoint'])) {
                return '同系统站点不能填写当前站点自身地址。';
            }
            if ($secret === '') {
                return '请填写同系统对接 Token。';
            }
            return '';
        }
        if ($data['type'] === 'webdav') {
            if ($data['endpoint'] === '') {
                return '请填写 WebDAV 地址。';
            }
            $parts = parse_url($data['endpoint']);
            if (!$parts || empty($parts['host']) || !in_array(strtolower(isset($parts['scheme']) ? $parts['scheme'] : ''), ['http', 'https'], true)) {
                return 'WebDAV 地址格式不正确。';
            }
            if ($data['access_key'] === '') {
                return '请填写 WebDAV 用户名。';
            }
            if ($secret === '') {
                return '请填写 WebDAV 密码。';
            }
            return '';
        }
        if ($data['access_key'] === '') {
            return $data['type'] === 'cos' ? '请填写腾讯云 SecretId。' : '请填写 AccessKey。';
        }
        if ($secret === '') {
            return $data['type'] === 'cos' ? '请填写腾讯云 SecretKey。' : '请填写 SecretKey。';
        }
        if ($data['bucket'] === '') {
            return '请填写 Bucket 名称。';
        }
        if ($data['type'] === 'oss' && $data['endpoint'] === '') {
            return '请填写阿里云 OSS Endpoint。';
        }
        if ($data['type'] === 'cos' && $data['region'] === '' && $data['endpoint'] === '') {
            return '请填写腾讯云 COS 地域或 Endpoint。';
        }
        if ($data['type'] === 'kodo' && $data['domain'] === '') {
            return '请填写七牛云访问域名。';
        }
        if ($data['type'] === 'kodo' && $data['region'] !== '' && !in_array($data['region'], ['z0', 'z1', 'z2', 'na0', 'as0', 'cn-east-2', 'ap-southeast-2', 'ap-southeast-3'], true)) {
            return '七牛云区域不正确，请选择华东、华东浙江2、华北、华南、北美、亚太新加坡、亚太河内或亚太胡志明。';
        }
        if ($data['type'] === 's3' && $data['endpoint'] === '' && $data['region'] === '') {
            return '请填写 S3 Endpoint 或 Region。';
        }
        if ($data['type'] === 'minio' && $data['endpoint'] === '') {
            return '请填写 MinIO Endpoint。';
        }
        if ($data['type'] === 'r2' && $data['endpoint'] === '') {
            return '请填写 Cloudflare R2 Endpoint。';
        }
        return '';
    }

    protected function normalizeKodoRegion($region)
    {
        $region = strtolower(trim((string) $region));
        $aliases = [
            'huadong' => 'z0',
            'east' => 'z0',
            'cn-east-1' => 'z0',
            '华东' => 'z0',
            '华东-浙江' => 'z0',
            'zhejiang' => 'z0',
            'huabei' => 'z1',
            'north' => 'z1',
            'cn-north-1' => 'z1',
            '华北' => 'z1',
            '华北-河北' => 'z1',
            'hebei' => 'z1',
            'huanan' => 'z2',
            'south' => 'z2',
            'cn-south-1' => 'z2',
            '华南' => 'z2',
            '华南-广东' => 'z2',
            'guangdong' => 'z2',
            'beimei' => 'na0',
            'north-america' => 'na0',
            'america' => 'na0',
            'us-north-1' => 'na0',
            '北美' => 'na0',
            '亚太' => 'as0',
            '亚太-新加坡' => 'as0',
            'singapore' => 'as0',
            'ap-southeast' => 'as0',
            'ap-southeast-1' => 'as0',
            '华东-浙江2' => 'cn-east-2',
            'zhejiang2' => 'cn-east-2',
            '亚太-河内' => 'ap-southeast-2',
            'hanoi' => 'ap-southeast-2',
            'vietnam' => 'ap-southeast-2',
            '亚太-胡志明' => 'ap-southeast-3',
            'ho-chi-minh' => 'ap-southeast-3',
            'hcm' => 'ap-southeast-3',
            'up.qiniup.com' => 'z0',
            'upload.qiniup.com' => 'z0',
            'up-z0.qiniup.com' => 'z0',
            'upload-z0.qiniup.com' => 'z0',
            'up-cn-east-2.qiniup.com' => 'cn-east-2',
            'upload-cn-east-2.qiniup.com' => 'cn-east-2',
            'up-z1.qiniup.com' => 'z1',
            'upload-z1.qiniup.com' => 'z1',
            'up-z2.qiniup.com' => 'z2',
            'upload-z2.qiniup.com' => 'z2',
            'up-na0.qiniup.com' => 'na0',
            'upload-na0.qiniup.com' => 'na0',
            'up-as0.qiniup.com' => 'as0',
            'upload-as0.qiniup.com' => 'as0',
            'up-ap-southeast-2.qiniup.com' => 'ap-southeast-2',
            'upload-ap-southeast-2.qiniup.com' => 'ap-southeast-2',
            'up-ap-southeast-3.qiniup.com' => 'ap-southeast-3',
            'upload-ap-southeast-3.qiniup.com' => 'ap-southeast-3',
        ];
        return isset($aliases[$region]) ? $aliases[$region] : $region;
    }

    protected function storageRedirect($type)
    {
        return $type === 'bmtools' ? 'admin/storage-integrations' : 'admin/storages';
    }

    public function testStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->ensureStorageDriverSchemaReady(),
            '资源功能管理',
            'admin/storages',
            '请先完成存储数据表修复后再测试。',
        )) {
            return;
        }
        $driver = (new StorageDriver())->find((int) $_POST['id']);
        if (!$driver) {
            $this->json(['success' => false, 'message' => '存储源不存在。'], 404);
        }
        $this->json((new StorageTestService())->run($driver));
    }

    public function setDefaultStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->ensureStorageDriverSchemaReady(),
            '资源功能管理',
            'admin/storages',
            '请先完成存储数据表修复后再设置默认存储。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $driver = (new StorageDriver())->find($id);
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 0');
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 1, updated_at = ? WHERE id = ?', [now(), $id]);
        $this->adminLog('设置默认存储', 'storage', $id);
        set_flash('success', '默认存储已更新。');
        $this->redirect($this->storageRedirect($driver && isset($driver['type']) ? $driver['type'] : 'local'));
    }

    public function deleteStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->ensureStorageDriverSchemaReady(),
            '资源功能管理',
            'admin/storages',
            '请先完成存储数据表修复后再删除存储源。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $driver = (new StorageDriver())->find($id);
        $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE storage_id = ?', [$id]);
        if ($used && (int) $used['c'] > 0) {
            set_flash('error', '该存储源已有文件使用，不能直接删除。');
            $this->redirect($this->storageRedirect($driver && isset($driver['type']) ? $driver['type'] : 'local'));
        }
        (new StorageDriver())->delete($id);
        $this->adminLog('删除存储源', 'storage', $id);
        set_flash('success', '存储源已删除。');
        $this->redirect($this->storageRedirect($driver && isset($driver['type']) ? $driver['type'] : 'local'));
    }

    public function files()
    {
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'type' => isset($_GET['type']) && in_array($_GET['type'], ['image', 'file'], true) ? $_GET['type'] : '',
            'storage_id' => isset($_GET['storage_id']) ? (int) $_GET['storage_id'] : 0,
            'user' => trim(isset($_GET['user']) ? $_GET['user'] : ''),
            'date_start' => trim(isset($_GET['date_start']) ? $_GET['date_start'] : ''),
            'date_end' => trim(isset($_GET['date_end']) ? $_GET['date_end'] : ''),
        ];

        $where = [];
        $params = [];
        if ($filters['keyword'] !== '') {
            $where[] = '(f.original_name LIKE ? OR f.file_name LIKE ? OR f.file_ext LIKE ? OR f.mime_type LIKE ? OR f.md5 LIKE ?)';
            for ($i = 0; $i < 5; $i++) {
                $params[] = '%' . $filters['keyword'] . '%';
            }
        }
        if ($filters['type'] !== '') {
            $where[] = 'f.file_type = ?';
            $params[] = $filters['type'];
        }
        if ($filters['storage_id'] > 0) {
            $where[] = 'f.storage_id = ?';
            $params[] = $filters['storage_id'];
        }
        if ($filters['user'] !== '') {
            if (ctype_digit($filters['user'])) {
                $where[] = '(f.user_id = ? OR u.username LIKE ? OR u.email LIKE ? OR u.nickname LIKE ?)';
                $params[] = (int) $filters['user'];
                $params[] = '%' . $filters['user'] . '%';
                $params[] = '%' . $filters['user'] . '%';
                $params[] = '%' . $filters['user'] . '%';
            } else {
                $where[] = '(u.username LIKE ? OR u.email LIKE ? OR u.nickname LIKE ?)';
                $params[] = '%' . $filters['user'] . '%';
                $params[] = '%' . $filters['user'] . '%';
                $params[] = '%' . $filters['user'] . '%';
            }
        }
        if ($filters['date_start'] !== '') {
            $where[] = 'f.created_at >= ?';
            $params[] = $filters['date_start'] . ' 00:00:00';
        }
        if ($filters['date_end'] !== '') {
            $where[] = 'f.created_at <= ?';
            $params[] = $filters['date_end'] . ' 23:59:59';
        }

        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $rows = Database::fetchAll(
            'SELECT f.*, u.username, u.email, s.name AS storage_name, s.type AS storage_type
             FROM ' . Database::table('files') . ' f
             LEFT JOIN ' . Database::table('users') . ' u ON f.user_id = u.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id
             ' . $whereSql . '
             ORDER BY f.id DESC
             LIMIT 300',
            $params
        );
        $filtered = Database::fetch(
            'SELECT COUNT(*) AS total, COALESCE(SUM(f.file_size),0) AS size
             FROM ' . Database::table('files') . ' f
             LEFT JOIN ' . Database::table('users') . ' u ON f.user_id = u.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id
             ' . $whereSql,
            $params
        );
        $stats = [
            'total' => $this->safeCount('files'),
            'images' => $this->safeCount('files', "file_type = 'image'"),
            'files' => $this->safeCount('files', "file_type = 'file'"),
            'today' => $this->safeCount('files', 'DATE(created_at) = CURDATE()'),
            'size' => Database::fetch('SELECT COALESCE(SUM(file_size),0) AS total FROM ' . Database::table('files'))['total'],
            'filtered_total' => $filtered ? (int) $filtered['total'] : 0,
            'filtered_size' => $filtered ? (int) $filtered['size'] : 0,
        ];
        $storages = Database::fetchAll('SELECT id, name, type, is_enabled, is_default FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, id DESC');
        $storageStats = Database::fetchAll(
            'SELECT COALESCE(s.name, \'未绑定存储\') AS name, COALESCE(s.type, \'unknown\') AS type, COUNT(f.id) AS total, COALESCE(SUM(f.file_size),0) AS size
             FROM ' . Database::table('files') . ' f
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id
             GROUP BY f.storage_id, s.name, s.type
             ORDER BY total DESC
             LIMIT 8'
        );
        $this->adminView('admin/files', [
            'title' => '文件管理',
            'files' => $rows,
            'filters' => $filters,
            'stats' => $stats,
            'storages' => $storages,
            'storageStats' => $storageStats,
        ]);
    }

    public function repositories()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
                [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            ], '分享仓库'),
            '分享仓库',
            '分享仓库依赖 file_repositories 和访问日志数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new RepositoryService();
        $filters = [
            'keyword' => isset($_GET['keyword']) ? $_GET['keyword'] : '',
            'status' => isset($_GET['status']) ? $_GET['status'] : '',
            'access_type' => isset($_GET['access_type']) ? $_GET['access_type'] : '',
        ];
        $this->adminView('admin/repositories', [
            'title' => '分享仓库管理',
            'repositories' => $service->adminRepositories($filters),
            'stats' => $service->adminStats(),
            'filters' => $filters,
        ]);
    }

    public function repositoryDetail()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
                [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            ], '分享仓库详情'),
            '分享仓库详情',
            '分享仓库详情依赖仓库和访问日志数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new RepositoryService();
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $repo = $service->adminRepository($id);
        if (!$repo) {
            set_flash('error', '分享仓库不存在。');
            $this->redirect('admin/repositories');
        }
        $logFilters = [
            'action' => isset($_GET['action']) ? $_GET['action'] : '',
            'keyword' => isset($_GET['keyword']) ? $_GET['keyword'] : '',
            'date_from' => isset($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to' => isset($_GET['date_to']) ? $_GET['date_to'] : '',
        ];
        $stats = $service->stats($repo);
        $this->adminView('admin/repository_detail', [
            'title' => '分享仓库详情',
            'repo' => $repo,
            'stats' => $stats,
            'checklist' => $service->publishChecklist($repo, $stats),
            'files' => $service->adminRepositoryFiles($repo),
            'logs' => $service->logs($repo, 120, $logFilters),
            'logFilters' => $logFilters,
            'publicLink' => public_url('r/' . $repo['slug']),
        ]);
    }

    public function subsites()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理'),
            '分站管理',
            '分站管理依赖 subsites、subsite_access_logs 等数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new SubsiteService();
        $filters = [
            'status' => isset($_GET['status']) && in_array($_GET['status'], ['pending', 'active', 'suspended', 'rejected'], true) ? $_GET['status'] : '',
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
        ];
        $rows = $service->allSubsites($filters['status'], $filters['keyword']);
        $this->adminView('admin/subsites', [
            'title' => '分站管理',
            'subsites' => $rows,
            'accessLogs' => $service->recentAccessLogs(18),
            'filters' => $filters,
            'settings' => $this->settingsMap(),
            'service' => $service,
            'stats' => [
                'total' => $this->safeCount('subsites'),
                'pending' => $this->safeCount('subsites', "status = 'pending'"),
                'active' => $this->safeCount('subsites', "status = 'active'"),
                'suspended' => $this->safeCount('subsites', "status = 'suspended'"),
                'views' => (int) (Database::fetch('SELECT COALESCE(SUM(view_count),0) AS total FROM ' . Database::table('subsites'))['total'] ?: 0),
            ],
        ]);
    }

    public function saveSubsiteSettings()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理'),
            '分站管理',
            'admin/subsites',
            '分站管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new SubsiteService();
        $reserved = [];
        foreach (preg_split('/[\r\n,;]+/', isset($_POST['subsite_reserved_slugs']) ? (string) $_POST['subsite_reserved_slugs'] : '') as $item) {
            $slug = $service->normalizeSlug($item);
            if ($slug !== '') {
                $reserved[$slug] = true;
            }
        }
        $values = [
            'subsite_enabled' => isset($_POST['subsite_enabled']) ? '1' : '0',
            'subsite_domain_suffixes' => $service->normalizeSuffixList(isset($_POST['subsite_domain_suffixes']) ? $_POST['subsite_domain_suffixes'] : ''),
            'subsite_cname_target' => $service->normalizeHost(isset($_POST['subsite_cname_target']) ? $_POST['subsite_cname_target'] : ''),
            'subsite_https_mode' => isset($_POST['subsite_https_mode']) && in_array($_POST['subsite_https_mode'], ['auto', 'force', 'off'], true) ? $_POST['subsite_https_mode'] : 'auto',
            'subsite_custom_domain_enabled' => isset($_POST['subsite_custom_domain_enabled']) ? '1' : '0',
            'subsite_requires_review' => isset($_POST['subsite_requires_review']) ? '1' : '0',
            'subsite_default_limit' => (string) max(0, min(100, (int) (isset($_POST['subsite_default_limit']) ? $_POST['subsite_default_limit'] : 1))),
            'subsite_reserved_slugs' => implode(',', array_keys($reserved)),
        ];
        foreach ($values as $key => $value) {
            $this->saveSettingValue($key, $value);
        }
        $this->adminLog('保存分站设置', 'setting', null);
        set_flash('success', '分站设置已保存。');
        $this->redirect('admin/subsites');
    }

    public function updateSubsiteStatus()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理'),
            '分站管理',
            'admin/subsites',
            '分站管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new SubsiteService();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $subsite = $service->find($id);
        if (!$subsite) {
            set_flash('error', '分站不存在。');
            $this->redirect('admin/subsites');
        }
        $status = isset($_POST['status']) ? $_POST['status'] : $subsite['status'];
        if (!in_array($status, ['pending', 'active', 'suspended', 'rejected'], true)) {
            $status = $subsite['status'];
        }
        $domainStatus = null;
        if (isset($_POST['custom_domain_status']) && in_array($_POST['custom_domain_status'], ['none', 'pending', 'verified', 'failed'], true)) {
            $domainStatus = $_POST['custom_domain_status'];
        }
        $remark = trim(isset($_POST['admin_remark']) ? $_POST['admin_remark'] : '');
        $service->setAdminStatus($id, $status, $domainStatus, $remark);
        $this->adminLog('更新分站状态', 'subsite', $id);
        set_flash('success', '分站状态已更新。');
        $this->redirect('admin/subsites');
    }

    public function checkSubsiteDomain()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理'),
            '分站管理',
            'admin/subsites',
            '分站管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $service = new SubsiteService();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $subsite = $service->find($id);
        if (!$subsite) {
            set_flash('error', '分站不存在。');
            $this->redirect('admin/subsites');
        }

        try {
            $diagnostic = $service->domainDiagnostic($subsite);
            $service->setAdminStatus(
                $id,
                $subsite['status'],
                isset($diagnostic['custom_domain_status']) ? $diagnostic['custom_domain_status'] : null,
                isset($subsite['admin_remark']) ? $subsite['admin_remark'] : ''
            );
            $diagnostic['site'] = [
                'id' => $subsite['id'],
                'name' => $subsite['name'],
                'platform_domain' => $subsite['platform_domain'],
                'custom_domain' => $subsite['custom_domain'],
            ];
            $service->saveDomainDiagnostic($id, $diagnostic);
            set_flash('subsite_domain_diagnostic', $diagnostic);
            $this->adminLog('检测分站域名', 'subsite', $id);
            set_flash($diagnostic['ok'] ? 'success' : 'error', $diagnostic['ok'] ? '域名接入检测通过。' : '域名接入检测完成，仍有步骤未通过。');
        } catch (\Throwable $e) {
            set_flash('error', '域名接入检测失败：' . $e->getMessage());
        }
        $this->redirect('admin/subsites');
    }

    public function deleteSubsite()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理'),
            '分站管理',
            'admin/subsites',
            '分站管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        if ((new SubsiteService())->deleteByAdmin($id)) {
            $this->adminLog('删除分站', 'subsite', $id);
            set_flash('success', '分站已删除。');
        } else {
            set_flash('error', '分站不存在或删除失败。');
        }
        $this->redirect('admin/subsites');
    }

    public function serverOps()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '服务器管家'),
            '服务器管家',
            '服务器管家依赖用户服务器、SSH 会话和命令审计数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'type' => isset($_GET['type']) && in_array($_GET['type'], ['ssh', 'agent'], true) ? $_GET['type'] : '',
            'status' => isset($_GET['status']) && in_array($_GET['status'], ['online', 'offline', 'unknown'], true) ? $_GET['status'] : '',
        ];

        $where = [];
        $params = [];
        if ($filters['type'] !== '') {
            $where[] = 's.monitor_type = ?';
            $params[] = $filters['type'];
        } else {
            $where[] = 's.monitor_type IN (?, ?)';
            $params[] = 'ssh';
            $params[] = 'agent';
        }
        if ($filters['status'] !== '') {
            $where[] = 's.status = ?';
            $params[] = $filters['status'];
        }
        if ($filters['keyword'] !== '') {
            $like = '%' . $filters['keyword'] . '%';
            $where[] = '(s.name LIKE ? OR s.ssh_host LIKE ? OR s.server_ip LIKE ? OR s.agent_url LIKE ? OR u.username LIKE ? OR u.email LIKE ?)';
            array_push($params, $like, $like, $like, $like, $like, $like);
        }

        $servers = Database::fetchAll(
            'SELECT s.*, u.username, u.email, p.visibility, p.token, p.view_count
             FROM ' . Database::table('monitor_servers') . ' s
             LEFT JOIN ' . Database::table('users') . ' u ON s.user_id = u.id
             LEFT JOIN ' . Database::table('server_monitor_pages') . ' p ON p.server_id = s.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY s.id DESC
             LIMIT 300',
            $params
        );

        foreach ($servers as &$server) {
            $server['latest'] = Database::fetch(
                'SELECT * FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 1',
                [$server['id']]
            );
            $server['commands_today'] = $this->serverCommandCount((int) $server['id'], "DATE(created_at) = CURDATE()");
        }
        unset($server);

        $stats = [
            'total' => count($servers),
            'online' => 0,
            'offline' => 0,
            'shared' => 0,
            'commands_today' => $this->safeUserServerCommandLogCount("DATE(cl.created_at) = CURDATE()"),
        ];
        foreach ($servers as $server) {
            if ($server['status'] === 'online') {
                $stats['online']++;
            } elseif ($server['status'] === 'offline') {
                $stats['offline']++;
            }
            if (!empty($server['visibility']) && $server['visibility'] !== 'private') {
                $stats['shared']++;
            }
        }

        $this->adminView('admin/server_ops', [
            'title' => '服务器管家',
            'servers' => $servers,
            'stats' => $stats,
            'filters' => $filters,
        ]);
    }

    public function sshSessions()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], 'SSH 会话'),
            'SSH 会话',
            'SSH 会话依赖 server_ssh_sessions 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $sessions = Database::fetchAll(
            'SELECT ss.*, u.username, s.name AS server_name, s.ssh_host
             FROM ' . Database::table('server_ssh_sessions') . ' ss
             LEFT JOIN ' . Database::table('users') . ' u ON ss.user_id = u.id
             LEFT JOIN ' . Database::table('monitor_servers') . ' s ON ss.server_id = s.id
             WHERE s.monitor_type IN (?, ?)
             ORDER BY ss.id DESC
             LIMIT 300',
            ['ssh', 'agent']
        );
        $this->adminView('admin/ssh_sessions', [
            'title' => 'SSH 会话',
            'sessions' => $sessions,
            'stats' => [
                'issued' => $this->safeUserServerSessionCount("ss.status = 'issued'"),
                'connected' => $this->safeUserServerSessionCount("ss.status = 'connected'"),
                'closed' => $this->safeUserServerSessionCount("ss.status IN ('closed','expired')"),
                'failed' => $this->safeUserServerSessionCount("ss.status = 'failed'"),
            ],
        ]);
    }

    public function commandLogs()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '命令审计'),
            '命令审计',
            '命令审计依赖 server_command_logs 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $risk = isset($_GET['risk']) && in_array($_GET['risk'], ['normal', 'warning', 'danger'], true) ? $_GET['risk'] : '';
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $where = ['s.monitor_type IN (?, ?)'];
        $params = ['ssh', 'agent'];
        if ($risk !== '') {
            $where[] = 'cl.risk_level = ?';
            $params[] = $risk;
        }
        if ($keyword !== '') {
            $where[] = '(cl.command LIKE ? OR u.username LIKE ? OR s.name LIKE ? OR s.ssh_host LIKE ?)';
            for ($i = 0; $i < 4; $i++) {
                $params[] = '%' . $keyword . '%';
            }
        }
        $logs = Database::fetchAll(
            'SELECT cl.*, u.username, s.name AS server_name, s.ssh_host
             FROM ' . Database::table('server_command_logs') . ' cl
             LEFT JOIN ' . Database::table('users') . ' u ON cl.user_id = u.id
             LEFT JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY cl.id DESC
             LIMIT 300',
            $params
        );
        $this->adminView('admin/command_logs', [
            'title' => '命令审计',
            'logs' => $logs,
            'filters' => ['risk' => $risk, 'keyword' => $keyword],
            'stats' => [
                'total' => $this->safeUserServerCommandLogCount(),
                'today' => $this->safeUserServerCommandLogCount("DATE(cl.created_at) = CURDATE()"),
                'warning' => $this->safeUserServerCommandLogCount("cl.risk_level = 'warning'"),
                'danger' => $this->safeUserServerCommandLogCount("cl.risk_level = 'danger'"),
            ],
        ]);
    }

    public function serverOpsSettings()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '运维设置'),
            '运维设置',
            '运维设置依赖服务器运维数据结构，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $this->adminView('admin/server_ops_settings', [
            'title' => '运维设置',
            'settings' => $this->settingsMap(),
        ]);
    }

    public function saveServerOpsSettings()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '运维设置'),
            '运维设置',
            'admin/server-ops/settings',
            '运维设置数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }

        $gatewayUrl = trim((string) (isset($_POST['ssh_terminal_gateway_url']) ? $_POST['ssh_terminal_gateway_url'] : ''));
        if ($gatewayUrl !== '' && !preg_match('#^wss?://#i', $gatewayUrl)) {
            set_flash('error', '网关地址必须以 ws:// 或 wss:// 开头。');
            $this->redirect('admin/server-ops/settings');
        }

        $values = [
            'ssh_terminal_enabled' => isset($_POST['ssh_terminal_enabled']) ? '1' : '0',
            'ssh_terminal_user_server_limit' => (string) max(0, min(1000, (int) (isset($_POST['ssh_terminal_user_server_limit']) ? $_POST['ssh_terminal_user_server_limit'] : 5))),
            'ssh_terminal_session_timeout' => (string) max(60, min(86400, (int) (isset($_POST['ssh_terminal_session_timeout']) ? $_POST['ssh_terminal_session_timeout'] : 600))),
            'ssh_terminal_command_timeout' => (string) max(3, min(3600, (int) (isset($_POST['ssh_terminal_command_timeout']) ? $_POST['ssh_terminal_command_timeout'] : 30))),
            'ssh_terminal_gateway_url' => $gatewayUrl,
        ];
        foreach ($values as $key => $value) {
            $this->saveSettingValue($key, $value);
        }
        $this->adminLog('保存运维设置', 'setting', null);
        set_flash('success', '运维设置已保存。');
        $this->redirect('admin/server-ops/settings');
    }

    public function repositoryStatus()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
                [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            ], '分享仓库管理'),
            '分享仓库管理',
            'admin/repositories',
            '分享仓库数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $enabled = (int) (isset($_POST['admin_status']) ? $_POST['admin_status'] : 0) === 1;
        $remark = trim(isset($_POST['admin_remark']) ? $_POST['admin_remark'] : '');
        try {
            (new RepositoryService())->updateAdminStatus($id, $enabled, $remark);
            $this->adminLog($enabled ? '恢复分享仓库' : '下架分享仓库', 'repository', $id);
            set_flash('success', $enabled ? '分享仓库已恢复。' : '分享仓库已下架。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/repositories');
    }

    public function deleteRepository()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
                [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            ], '分享仓库管理'),
            '分享仓库管理',
            'admin/repositories',
            '分享仓库数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        if ((new RepositoryService())->adminDeleteRepository($id)) {
            $this->adminLog('删除分享仓库', 'repository', $id);
            set_flash('success', '分享仓库已删除。');
        } else {
            set_flash('error', '分享仓库不存在或删除失败。');
        }
        $this->redirect('admin/repositories');
    }

    public function clearRepositoryLogs()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
                [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            ], '分享仓库日志'),
            '分享仓库日志',
            'admin/repositories',
            '分享仓库日志数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            $count = (new RepositoryService())->adminClearLogs($id);
            $this->adminLog('清空分享仓库日志', 'repository', $id);
            set_flash('success', '已清空 ' . (int) $count . ' 条分享仓库日志。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/repositories/detail?id=' . $id);
    }

    public function deleteFile()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $file = Database::fetch('SELECT * FROM ' . Database::table('files') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$file) {
            set_flash('error', '文件不存在。');
            $this->redirect('admin/files');
        }
        try {
            $storage = $file['storage_id'] ? (new StorageDriver())->find((int) $file['storage_id']) : null;
            if ($storage) {
                (new StorageBackupService())->deleteBackupsForFile($file);
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Throwable $e) {
            Logger::error('删除文件存储对象失败：' . $e->getMessage());
        }
        Database::execute('DELETE FROM ' . Database::table('files') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除文件', 'file', $id);
        set_flash('success', '文件已删除。');
        $this->redirect('admin/files');
    }

    public function apiLogs()
    {
        if (!$this->ensureAdminTables(
            ['api_logs', 'users'],
            'API 日志',
            'API 日志依赖 api_logs 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $hasApiAppLog = $this->tableExists('api_apps') && $this->columnExists('api_logs', 'app_id');
        $appSelect = $hasApiAppLog ? ', a.name AS api_app_name' : ", '' AS api_app_name";
        $appJoin = $hasApiAppLog ? ' LEFT JOIN ' . Database::table('api_apps') . ' a ON l.app_id = a.id' : '';
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'method' => strtoupper(trim(isset($_GET['method']) ? $_GET['method'] : '')),
            'success' => isset($_GET['success']) && in_array((string) $_GET['success'], ['0', '1'], true) ? (string) $_GET['success'] : '',
            'app_id' => $hasApiAppLog ? max(0, (int) (isset($_GET['app_id']) ? $_GET['app_id'] : 0)) : 0,
            'date_start' => trim(isset($_GET['date_start']) ? $_GET['date_start'] : ''),
            'date_end' => trim(isset($_GET['date_end']) ? $_GET['date_end'] : ''),
        ];
        $allowedMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
        if (!in_array($filters['method'], $allowedMethods, true)) {
            $filters['method'] = '';
        }

        $where = [];
        $params = [];
        if ($filters['keyword'] !== '') {
            $where[] = $hasApiAppLog
                ? '(l.endpoint LIKE ? OR l.ip LIKE ? OR l.message LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR a.name LIKE ?)'
                : '(l.endpoint LIKE ? OR l.ip LIKE ? OR l.message LIKE ? OR u.username LIKE ? OR u.email LIKE ?)';
            for ($i = 0; $i < ($hasApiAppLog ? 6 : 5); $i++) {
                $params[] = '%' . $filters['keyword'] . '%';
            }
        }
        if ($filters['method'] !== '') {
            $where[] = 'l.method = ?';
            $params[] = $filters['method'];
        }
        if ($filters['success'] !== '') {
            $where[] = 'l.is_success = ?';
            $params[] = (int) $filters['success'];
        }
        if ($hasApiAppLog && $filters['app_id'] > 0) {
            $where[] = 'l.app_id = ?';
            $params[] = (int) $filters['app_id'];
        }
        if ($filters['date_start'] !== '') {
            $where[] = 'l.created_at >= ?';
            $params[] = $filters['date_start'] . ' 00:00:00';
        }
        if ($filters['date_end'] !== '') {
            $where[] = 'l.created_at <= ?';
            $params[] = $filters['date_end'] . ' 23:59:59';
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

        $rows = Database::fetchAll(
            'SELECT l.*, u.username, u.email' . $appSelect . '
             FROM ' . Database::table('api_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             ' . $appJoin . '
             ' . $whereSql . '
             ORDER BY l.id DESC
             LIMIT 300',
            $params
        );
        $filtered = Database::fetch(
             'SELECT COUNT(*) AS total
             FROM ' . Database::table('api_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             ' . $appJoin . '
             ' . $whereSql,
            $params
        );
        $stats = [
            'total' => $this->safeCount('api_logs'),
            'today' => $this->safeCount('api_logs', 'DATE(created_at) = CURDATE()'),
            'success' => $this->safeCount('api_logs', 'is_success = 1'),
            'failed' => $this->safeCount('api_logs', 'is_success = 0'),
            'filtered_total' => $filtered ? (int) $filtered['total'] : 0,
        ];
        $endpointStats = Database::fetchAll(
            'SELECT endpoint, COUNT(*) AS total, SUM(CASE WHEN is_success = 0 THEN 1 ELSE 0 END) AS failed
             FROM ' . Database::table('api_logs') . '
             GROUP BY endpoint
             ORDER BY total DESC
             LIMIT 8'
        );
        $apiApps = $hasApiAppLog
            ? Database::fetchAll(
                'SELECT id, name, status, last_used_at
                 FROM ' . Database::table('api_apps') . '
                 ORDER BY status DESC, last_used_at DESC, id DESC
                 LIMIT 300'
            )
            : [];
        $appStats = $hasApiAppLog
            ? Database::fetchAll(
                'SELECT l.app_id, COALESCE(a.name, CONCAT(\'应用 #\', l.app_id)) AS api_app_name,
                        COUNT(*) AS total,
                        SUM(CASE WHEN l.is_success = 0 THEN 1 ELSE 0 END) AS failed,
                        MAX(l.created_at) AS last_called_at
                 FROM ' . Database::table('api_logs') . ' l
                 LEFT JOIN ' . Database::table('api_apps') . ' a ON l.app_id = a.id
                 WHERE l.app_id IS NOT NULL
                 GROUP BY l.app_id, a.name
                 ORDER BY total DESC
                 LIMIT 10'
            )
            : [];
        $failedAppStats = $hasApiAppLog
            ? Database::fetchAll(
                'SELECT l.app_id, COALESCE(a.name, CONCAT(\'应用 #\', l.app_id)) AS api_app_name,
                        COUNT(*) AS failed,
                        MAX(l.created_at) AS last_failed_at
                 FROM ' . Database::table('api_logs') . ' l
                 LEFT JOIN ' . Database::table('api_apps') . ' a ON l.app_id = a.id
                 WHERE l.app_id IS NOT NULL AND l.is_success = 0
                 GROUP BY l.app_id, a.name
                 ORDER BY failed DESC, last_failed_at DESC
                 LIMIT 10'
            )
            : [];
        $this->adminView('admin/api_logs', [
            'title' => 'API 日志',
            'logs' => $rows,
            'filters' => $filters,
            'stats' => $stats,
            'endpointStats' => $endpointStats,
            'apiApps' => $apiApps,
            'appStats' => $appStats,
            'failedAppStats' => $failedAppStats,
            'methods' => $allowedMethods,
        ]);
    }

    public function balanceLogs()
    {
        if (!$this->ensureAdminTables(
            ['balance_logs', 'users'],
            '余额流水',
            '余额流水依赖 balance_logs、users 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'type' => isset($_GET['type']) && in_array($_GET['type'], ['recharge', 'consume', 'refund', 'adjust'], true) ? $_GET['type'] : '',
            'date_start' => trim(isset($_GET['date_start']) ? $_GET['date_start'] : ''),
            'date_end' => trim(isset($_GET['date_end']) ? $_GET['date_end'] : ''),
        ];
        $where = [];
        $params = [];
        if ($filters['keyword'] !== '') {
            $where[] = '(u.username LIKE ? OR u.email LIKE ? OR l.remark LIKE ? OR l.related_type LIKE ? OR CAST(l.related_id AS CHAR) LIKE ?)';
            for ($i = 0; $i < 5; $i++) {
                $params[] = '%' . $filters['keyword'] . '%';
            }
        }
        if ($filters['type'] !== '') {
            $where[] = 'l.type = ?';
            $params[] = $filters['type'];
        }
        if ($filters['date_start'] !== '') {
            $where[] = 'l.created_at >= ?';
            $params[] = $filters['date_start'] . ' 00:00:00';
        }
        if ($filters['date_end'] !== '') {
            $where[] = 'l.created_at <= ?';
            $params[] = $filters['date_end'] . ' 23:59:59';
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $rows = Database::fetchAll(
            'SELECT l.*, u.username, u.email
             FROM ' . Database::table('balance_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             ' . $whereSql . '
             ORDER BY l.id DESC
             LIMIT 300',
            $params
        );
        $filtered = Database::fetch(
            'SELECT COUNT(*) AS total, COALESCE(SUM(l.amount),0) AS amount
             FROM ' . Database::table('balance_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             ' . $whereSql,
            $params
        );
        $summary = Database::fetch(
            'SELECT COUNT(*) AS total,
                    COALESCE(SUM(CASE WHEN type = \'recharge\' THEN amount ELSE 0 END),0) AS recharge,
                    COALESCE(SUM(CASE WHEN type = \'consume\' THEN amount ELSE 0 END),0) AS consume,
                    COALESCE(SUM(CASE WHEN type = \'refund\' THEN amount ELSE 0 END),0) AS refund,
                    COALESCE(SUM(CASE WHEN type = \'adjust\' THEN amount ELSE 0 END),0) AS adjust
             FROM ' . Database::table('balance_logs')
        );
        $this->adminView('admin/balance_logs', [
            'title' => '余额流水',
            'logs' => $rows,
            'filters' => $filters,
            'stats' => [
                'total' => $summary ? (int) $summary['total'] : 0,
                'recharge' => $summary ? $summary['recharge'] : 0,
                'consume' => $summary ? $summary['consume'] : 0,
                'refund' => $summary ? $summary['refund'] : 0,
                'adjust' => $summary ? $summary['adjust'] : 0,
                'filtered_total' => $filtered ? (int) $filtered['total'] : 0,
                'filtered_amount' => $filtered ? $filtered['amount'] : 0,
            ],
        ]);
    }

    public function incidentCenter()
    {
        $filters = [
            'scope' => isset($_GET['scope']) ? trim((string) $_GET['scope']) : '',
            'date_start' => trim(isset($_GET['date_start']) ? (string) $_GET['date_start'] : ''),
            'date_end' => trim(isset($_GET['date_end']) ? (string) $_GET['date_end'] : ''),
        ];
        if (!in_array($filters['scope'], ['', 'api', 'backup', 'command', 'upload_failure', 'upload', 'admin'], true)) {
            $filters['scope'] = '';
        }

        $created = $this->incidentDateSql($filters, 'created_at');
        $updated = $this->incidentDateSql($filters, 'updated_at');
        $incidents = [];

        if ($filters['scope'] === '' || $filters['scope'] === 'api') {
            foreach ($this->incidentApiRows($created['where'], $created['params']) as $row) {
                $incidents[] = [
                    'type' => 'api',
                    'level' => 'warning',
                    'icon' => 'terminal',
                    'title' => 'API 请求失败',
                    'desc' => ($row['method'] ?: '-') . ' ' . ($row['endpoint'] ?: '-') . ' / ' . ($row['message'] ?: '无错误信息'),
                    'user' => $row['username'] ?: '游客/未知',
                    'time' => $row['created_at'],
                    'url' => 'admin/api-logs?success=0',
                ];
            }
        }

        if ($filters['scope'] === '' || $filters['scope'] === 'backup') {
            foreach ($this->incidentBackupRows($updated['where'], $updated['params']) as $row) {
                $incidents[] = [
                    'type' => 'backup',
                    'level' => 'danger',
                    'icon' => 'database-backup',
                    'title' => '备份任务失败',
                    'desc' => ($row['file_name'] ?: '-') . ' / ' . ($row['message'] ?: '无错误信息'),
                    'user' => $row['username'] ?: '-',
                    'time' => $row['updated_at'] ?: $row['created_at'],
                    'url' => 'admin/storage-backups/tasks?status=failed',
                ];
            }
        }

        if ($filters['scope'] === '' || $filters['scope'] === 'command') {
            foreach ($this->incidentCommandRows($created['where'], $created['params']) as $row) {
                $incidents[] = [
                    'type' => 'command',
                    'level' => $row['risk_level'] === 'danger' ? 'danger' : 'warning',
                    'icon' => 'square-terminal',
                    'title' => 'SSH 命令审计标记',
                    'desc' => text_limit($row['command'], 120) . ' / ' . text_limit($row['output_summary'], 120),
                    'user' => $row['username'] ?: ('用户 #' . $row['user_id']),
                    'time' => $row['created_at'],
                    'url' => 'admin/command-logs?risk=' . urlencode($row['risk_level']),
                ];
            }
        }

        if ($filters['scope'] === '' || $filters['scope'] === 'upload_failure') {
            foreach ($this->incidentUploadFailureRows($created['where'], $created['params']) as $row) {
                $storageName = isset($row['storage_name']) && $row['storage_name'] !== '' ? $row['storage_name'] : (isset($row['storage_type']) ? strtoupper((string) $row['storage_type']) : '-');
                $errorType = isset($row['error_type']) ? (string) $row['error_type'] : 'upload';
                $storageDanger = in_array($errorType, ['storage', 'storage_config', 'storage_upload', 'storage_url', 'storage_delete', 'storage_db'], true);
                $stageLabel = $this->uploadFailureStageLabel($errorType);
                $incidents[] = [
                    'type' => 'upload_failure',
                    'level' => $storageDanger ? 'danger' : 'warning',
                    'icon' => 'cloud-alert',
                    'title' => $stageLabel ? ('上传失败：' . $stageLabel) : '上传失败',
                    'desc' => ($row['file_name'] ?: '未进入文件处理') . ' / ' . $errorType . ' / ' . ($row['suggestion'] ?: $row['message'] ?: '无错误信息') . ' / ' . $storageName,
                    'user' => $row['username'] ?: ($row['user_id'] ? ('用户 #' . $row['user_id']) : '未知用户'),
                    'time' => $row['created_at'],
                    'url' => 'admin/incident-center?scope=upload_failure',
                ];
            }
        }

        if ($filters['scope'] === '' || $filters['scope'] === 'upload') {
            foreach ($this->incidentUploadRows($created['where'], $created['params']) as $row) {
                $incidents[] = [
                    'type' => 'upload',
                    'level' => 'soft',
                    'icon' => 'upload-cloud',
                    'title' => '上传记录',
                    'desc' => ($row['file_name'] ?: '-') . ' / ' . ($row['action'] ?: '-') . ' / ' . format_bytes((int) $row['file_size']),
                    'user' => $row['username'] ?: ('用户 #' . $row['user_id']),
                    'time' => $row['created_at'],
                    'url' => 'files/logs?scope=upload',
                ];
            }
        }

        if ($filters['scope'] === '' || $filters['scope'] === 'admin') {
            foreach ($this->incidentAdminRows($created['where'], $created['params']) as $row) {
                $incidents[] = [
                    'type' => 'admin',
                    'level' => 'soft',
                    'icon' => 'clipboard-list',
                    'title' => '后台关键操作',
                    'desc' => ($row['action'] ?: '-') . ' / ' . ($row['target_type'] ?: '-') . ($row['target_id'] ? ' #' . $row['target_id'] : ''),
                    'user' => $row['username'] ?: '未知管理员',
                    'time' => $row['created_at'],
                    'url' => 'admin/logs',
                ];
            }
        }

        usort($incidents, function ($a, $b) {
            return strcmp((string) $b['time'], (string) $a['time']);
        });

        $this->adminView('admin/incident_center', [
            'title' => '异常事件中心',
            'filters' => $filters,
            'incidents' => array_slice($incidents, 0, 80),
            'stats' => [
                'api_failed_today' => $this->safeCount('api_logs', 'is_success = 0 AND DATE(created_at) = CURDATE()'),
                'backup_failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
                'command_risky_today' => $this->safeCount('server_command_logs', "risk_level IN ('warning','danger') AND DATE(created_at) = CURDATE()"),
                'upload_today' => $this->safeCount('file_logs', "action IN ('image_upload','file_upload') AND DATE(created_at) = CURDATE()"),
                'upload_failed_today' => $this->safeCount('upload_failures', 'DATE(created_at) = CURDATE()'),
            ],
        ]);
    }

    public function monitors()
    {
        $monitorReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema'], '监控管理');
        $serverOpsReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '监控管理');
        if (!$this->ensureAdminFeatureSchema(
            $monitorReady && $serverOpsReady,
            '监控管理',
            '监控管理依赖 monitor_servers、monitor_metrics、monitor_alerts 等数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $cronToken = trim((string) setting('monitor_cron_token', ''));
        if ($cronToken === '') {
            $cronToken = bin2hex(random_bytes(24));
            $this->saveSettingValue('monitor_cron_token', $cronToken);
        }
        $servers = Database::fetchAll('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type = ? ORDER BY id DESC', ['bt']);
        $alerts = Database::fetchAll('SELECT a.*, s.name AS server_name FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE s.monitor_type = ? ORDER BY a.id DESC LIMIT 100', ['bt']);
        $this->adminView('admin/monitors', [
            'title' => '监控管理',
            'servers' => $servers,
            'alerts' => $alerts,
            'monitorCronUrl' => url('cron/monitor/collect?token=' . $cronToken),
            'monitorCronForceUrl' => url('cron/monitor/collect?force=1&token=' . $cronToken),
            'serverOpsCronUrl' => url('cron/server-ops/collect?token=' . $cronToken),
            'serverOpsCronForceUrl' => url('cron/server-ops/collect?force=1&token=' . $cronToken),
        ]);
    }

    public function monitorSla()
    {
        $monitorReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema'], '监控 SLA 统计');
        if (!$this->ensureAdminFeatureSchema(
            $monitorReady,
            '监控 SLA 统计',
            '监控 SLA 统计依赖监控采集数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }

        $days = isset($_GET['days']) ? (int) $_GET['days'] : 7;
        $this->adminView('admin/monitor_sla', [
            'title' => '监控 SLA 统计',
            'report' => (new SlaReportService())->report($days),
        ]);
    }

    public function exportMonitorSla()
    {
        $this->requireAdmin();
        $monitorReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema'], '监控 SLA 统计');
        if (!$this->ensureAdminFeatureSchema(
            $monitorReady,
            '监控 SLA 统计',
            '监控 SLA 统计依赖监控采集数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }

        $days = isset($_GET['days']) ? (int) $_GET['days'] : 7;
        $report = (new SlaReportService())->report($days);
        $rows = isset($report['servers']) && is_array($report['servers']) ? $report['servers'] : [];
        $days = isset($report['days']) ? (int) $report['days'] : 7;

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=monitor-sla-' . $days . 'd-' . date('YmdHis') . '.csv');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        fputcsv($out, ['服务器', 'IP/地址', '状态', '采集健康', '采集延迟分钟', 'SLA', '成功样本', '失败样本', '总样本', '告警数', '平均CPU', '平均内存', '平均磁盘', '最近采集', '最后错误']);
        foreach ($rows as $row) {
            $address = !empty($row['server_ip']) ? $row['server_ip'] : parse_url((string) $row['panel_url'], PHP_URL_HOST);
            fputcsv($out, [
                isset($row['name']) ? $row['name'] : '',
                $address ?: '',
                isset($row['status']) ? $row['status'] : 'unknown',
                isset($row['collect_status']) ? $row['collect_status'] : 'normal',
                isset($row['collect_delay_minutes']) && $row['collect_delay_minutes'] !== null ? (int) $row['collect_delay_minutes'] : '',
                $row['sla_percent'] === null ? '' : number_format((float) $row['sla_percent'], 2) . '%',
                (int) $row['success_samples'],
                (int) $row['failure_samples'],
                (int) $row['sample_count'],
                (int) $row['alert_count'],
                $row['avg_cpu'] === null ? '' : number_format((float) $row['avg_cpu'], 2) . '%',
                $row['avg_memory'] === null ? '' : number_format((float) $row['avg_memory'], 2) . '%',
                $row['avg_disk'] === null ? '' : number_format((float) $row['avg_disk'], 2) . '%',
                isset($row['last_sample_at']) ? $row['last_sample_at'] : '',
                isset($row['last_error']) ? $row['last_error'] : '',
            ]);
        }
        fclose($out);
        exit;
    }

    public function toggleMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
                [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            ], '监控管理'),
            '监控管理',
            'admin/monitors',
            '监控管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$server) {
            set_flash('error', '监控服务器不存在。');
            $this->redirect('admin/monitors');
        }
        Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET is_enabled = ?, updated_at = ? WHERE id = ? AND monitor_type = ?', [(int) !$server['is_enabled'], now(), $id, 'bt']);
        $this->adminLog('切换监控状态', 'monitor_server', $id);
        set_flash('success', '监控状态已更新。');
        $this->redirect('admin/monitors');
    }

    public function collectMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
                [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            ], '监控管理'),
            '监控管理',
            'admin/monitors',
            '监控管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$server) {
            set_flash('error', '监控服务器不存在。');
            $this->redirect('admin/monitors');
        }
        try {
            (new MonitorService())->collect($server);
            set_flash('success', '监控采集已执行。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/monitors');
    }

    public function saveMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
                [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            ], '监控管理'),
            '监控管理',
            'admin/monitors',
            '监控管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $monitorType = 'bt';
        $name = trim($_POST['name']);
        if ($name === '') {
            set_flash('error', '请填写服务器名称。');
            $this->redirect('admin/monitors');
        }
        $data = [
            'user_id' => Auth::id(),
            'monitor_type' => $monitorType,
            'name' => $name,
            'remark' => trim(isset($_POST['remark']) ? $_POST['remark'] : ''),
            'panel_url' => trim(isset($_POST['panel_url']) ? $_POST['panel_url'] : ''),
            'api_key' => trim(isset($_POST['api_key']) ? $_POST['api_key'] : ''),
            'panel_port' => isset($_POST['panel_port']) && (int) $_POST['panel_port'] > 0 ? (int) $_POST['panel_port'] : 8888,
            'server_ip' => trim(isset($_POST['server_ip']) ? $_POST['server_ip'] : ''),
            'ssh_host' => trim(isset($_POST['ssh_host']) ? $_POST['ssh_host'] : ''),
            'ssh_port' => isset($_POST['ssh_port']) && (int) $_POST['ssh_port'] > 0 ? (int) $_POST['ssh_port'] : 22,
            'ssh_username' => trim(isset($_POST['ssh_username']) ? $_POST['ssh_username'] : ''),
            'ssh_auth_type' => isset($_POST['ssh_auth_type']) && $_POST['ssh_auth_type'] === 'key' ? 'key' : 'password',
            'agent_url' => trim(isset($_POST['agent_url']) ? $_POST['agent_url'] : ''),
            'agent_token' => trim(isset($_POST['agent_token']) ? $_POST['agent_token'] : ''),
            'group_name' => trim(isset($_POST['group_name']) ? $_POST['group_name'] : '平台节点'),
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'frequency' => max(30, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 60)),
            'threshold_config' => json_encode([
                'cpu' => (float) (isset($_POST['cpu_threshold']) ? $_POST['cpu_threshold'] : 90),
                'memory' => (float) (isset($_POST['memory_threshold']) ? $_POST['memory_threshold'] : 90),
                'disk' => (float) (isset($_POST['disk_threshold']) ? $_POST['disk_threshold'] : 90),
            ], JSON_UNESCAPED_UNICODE),
            'updated_at' => now(),
        ];
        if ($monitorType === 'ssh') {
            if (!empty($_POST['ssh_password'])) {
                $data['ssh_password'] = CryptoService::encrypt($_POST['ssh_password']);
            }
            if (!empty($_POST['ssh_private_key'])) {
                $data['ssh_private_key'] = CryptoService::encrypt($_POST['ssh_private_key']);
            }
            if (!empty($_POST['ssh_key_passphrase'])) {
                $data['ssh_key_passphrase'] = CryptoService::encrypt($_POST['ssh_key_passphrase']);
            }
        }
        if (!empty($_POST['id'])) {
            $id = (int) $_POST['id'];
            $existing = Database::fetch('SELECT ssh_password, ssh_private_key, ssh_key_passphrase FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
            if (!$existing) {
                set_flash('error', 'Platform monitor server not found.');
                $this->redirect('admin/monitors');
            }
            foreach (['ssh_password', 'ssh_private_key', 'ssh_key_passphrase'] as $field) {
                if (!isset($data[$field]) && $existing) {
                    $data[$field] = $existing[$field];
                }
            }
            $set = [];
            $params = [];
            foreach ($data as $key => $value) {
                $set[] = $key . ' = ?';
                $params[] = $value;
            }
            $params[] = $id;
            $params[] = 'bt';
            Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET ' . implode(',', $set) . ' WHERE id = ? AND monitor_type = ?', $params);
        } else {
            $data['status'] = 'unknown';
            $data['created_at'] = now();
            $columns = array_keys($data);
            Database::execute('INSERT INTO ' . Database::table('monitor_servers') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')', array_values($data));
            $id = Database::lastInsertId();
        }
        $this->adminLog('保存监控服务器', 'monitor_server', $id);
        set_flash('success', '监控服务器已保存。');
        $this->redirect('admin/monitors');
    }

    public function testMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
                [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            ], '监控管理'),
            '监控管理',
            'admin/monitors',
            '监控管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $server = $_POST;
        $server['id'] = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        $server['monitor_type'] = 'bt';
        if (!empty($_POST['ssh_password'])) {
            $server['ssh_password'] = CryptoService::encrypt($_POST['ssh_password']);
        }
        if (!empty($_POST['ssh_private_key'])) {
            $server['ssh_private_key'] = CryptoService::encrypt($_POST['ssh_private_key']);
        }
        if (!empty($_POST['ssh_key_passphrase'])) {
            $server['ssh_key_passphrase'] = CryptoService::encrypt($_POST['ssh_key_passphrase']);
        }
        try {
            $data = (new MonitorService())->test($server);
            $this->json(['success' => true, 'message' => '连接成功，监控通道可用。', 'data' => $data]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function deleteMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
                [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            ], '监控管理'),
            '监控管理',
            'admin/monitors',
            '监控管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$server) {
            set_flash('error', 'Platform monitor server not found.');
            $this->redirect('admin/monitors');
        }
        Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$id]);
        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '服务器运维')) {
                throw new \RuntimeException('服务器运维附属结构未准备完成。');
            }
            Database::execute('DELETE FROM ' . Database::table('server_command_logs') . ' WHERE server_id = ?', [$id]);
            Database::execute('DELETE FROM ' . Database::table('server_ssh_sessions') . ' WHERE server_id = ?', [$id]);
            Database::execute('DELETE FROM ' . Database::table('server_monitor_pages') . ' WHERE server_id = ?', [$id]);
            $probeRows = Database::fetchAll('SELECT id FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ?', [$id]);
            foreach ($probeRows as $probeRow) {
                Database::execute('DELETE FROM ' . Database::table('server_service_check_logs') . ' WHERE check_id = ?', [$probeRow['id']]);
            }
            Database::execute('DELETE FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ?', [$id]);
        } catch (\Throwable $e) {
            Logger::error('删除监控服务器附属运维记录失败：' . $e->getMessage());
        }
        Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ?', [$id, 'bt']);
        $this->adminLog('删除监控服务器', 'monitor_server', $id);
        set_flash('success', '监控服务器已删除。');
        $this->redirect('admin/monitors');
    }

    public function resolveAlert()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->combinedSchemaReady([
                [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
                [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            ], '监控告警'),
            '监控告警',
            'admin/monitors',
            '监控告警数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        $alert = Database::fetch('SELECT a.id FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE a.id = ? AND s.monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$alert) {
            set_flash('error', 'Platform monitor alert not found.');
            $this->redirect('admin/monitors');
        }
        Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ?, resolved_at = ? WHERE id = ?', ['resolved', now(), $id]);
        $this->adminLog('处理监控告警', 'monitor_alert', $id);
        set_flash('success', '监控告警已处理。');
        $this->redirect('admin/monitors');
    }

    public function announcements()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureAnnouncementSchema'], '公告管理'),
            '公告管理',
            '公告管理依赖 announcements 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $this->adminView('admin/announcements', [
            'title' => '公告管理',
            'announcements' => Database::fetchAll('SELECT * FROM ' . Database::table('announcements') . ' ORDER BY id DESC'),
            'editAnnouncement' => !empty($_GET['id']) ? Database::fetch('SELECT * FROM ' . Database::table('announcements') . ' WHERE id = ? LIMIT 1', [(int) $_GET['id']]) : null,
            'announcementCategories' => Announcement::categories(),
            'siteDocuments' => (new Announcement())->siteDocuments(false),
        ]);
    }

    public function saveAnnouncement()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureAnnouncementSchema'], '公告管理'),
            '公告管理',
            'admin/announcements',
            '公告管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $categories = Announcement::categories();
        $category = isset($_POST['category']) && isset($categories[$_POST['category']]) ? $_POST['category'] : 'platform';
        $data = [
            'title' => trim($_POST['title']),
            'content' => trim($_POST['content']),
            'category' => $category,
            'summary' => trim(isset($_POST['summary']) ? $_POST['summary'] : ''),
            'cover_image' => trim(isset($_POST['cover_image']) ? $_POST['cover_image'] : ''),
            'tags' => trim(isset($_POST['tags']) ? $_POST['tags'] : ''),
            'content_format' => isset($_POST['content_format']) && $_POST['content_format'] === 'plain' ? 'plain' : 'html',
            'is_top' => isset($_POST['is_top']) ? 1 : 0,
            'show_home' => isset($_POST['show_home']) ? 1 : 0,
            'status' => (int) $_POST['status'],
            'published_at' => $_POST['published_at'] ?: now(),
            'updated_at' => now(),
        ];
        if (!empty($_POST['id'])) {
            Database::execute('UPDATE ' . Database::table('announcements') . ' SET title=?, content=?, category=?, summary=?, cover_image=?, tags=?, content_format=?, is_top=?, show_home=?, status=?, published_at=?, updated_at=? WHERE id=?', [$data['title'], $data['content'], $data['category'], $data['summary'], $data['cover_image'], $data['tags'], $data['content_format'], $data['is_top'], $data['show_home'], $data['status'], $data['published_at'], $data['updated_at'], (int) $_POST['id']]);
            $id = (int) $_POST['id'];
        } else {
            Database::execute('INSERT INTO ' . Database::table('announcements') . ' (title, content, category, summary, cover_image, tags, content_format, is_top, show_home, status, published_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', [$data['title'], $data['content'], $data['category'], $data['summary'], $data['cover_image'], $data['tags'], $data['content_format'], $data['is_top'], $data['show_home'], $data['status'], $data['published_at'], now(), now()]);
            $id = Database::lastInsertId();
        }
        $this->adminLog('保存公告', 'announcement', $id);
        set_flash('success', '公告已保存。');
        $this->redirect('admin/announcements');
    }

    public function deleteAnnouncement()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureAnnouncementSchema'], '公告管理'),
            '公告管理',
            'admin/announcements',
            '公告管理数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $id = (int) $_POST['id'];
        Database::execute('DELETE FROM ' . Database::table('announcements') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除公告', 'announcement', $id);
        set_flash('success', '公告已删除。');
        $this->redirect('admin/announcements');
    }

    public function settings()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $settings = $this->settingsMap();
        $packages = (new Package())->all();
        $settingsOverview = [
            'site_name' => isset($settings['site_name']) && trim((string) $settings['site_name']) !== '' ? $settings['site_name'] : app_brand_name(),
            'site_public_url' => isset($settings['site_public_url']) ? trim((string) $settings['site_public_url']) : '',
            'register_enabled' => isset($settings['register_enabled']) ? (string) $settings['register_enabled'] === '1' : true,
            'email_code_enabled' => isset($settings['register_email_code_enabled']) ? (string) $settings['register_email_code_enabled'] === '1' : false,
            'guest_upload_enabled' => isset($settings['guest_image_upload_enabled']) ? (string) $settings['guest_image_upload_enabled'] === '1' : false,
            'default_package_id' => isset($settings['default_free_package_id']) ? (int) $settings['default_free_package_id'] : 0,
            'api_rate_minute' => isset($settings['api_rate_limit_per_minute']) ? (int) $settings['api_rate_limit_per_minute'] : 0,
            'api_rate_day' => isset($settings['api_rate_limit_per_day']) ? (int) $settings['api_rate_limit_per_day'] : 0,
            'email_host' => isset($settings['email_host']) ? trim((string) $settings['email_host']) : '',
            'alert_webhook_enabled' => isset($settings['alert_webhook_enabled']) ? (string) $settings['alert_webhook_enabled'] === '1' : false,
            'upload_max_size' => isset($settings['guest_image_upload_max_size']) ? (int) $settings['guest_image_upload_max_size'] : 0,
            'package_count' => count($packages),
        ];
        $this->adminView('admin/settings_index', [
            'title' => '系统设置',
            'settings' => $settings,
            'packages' => $packages,
            'settingSections' => $this->settingsSections(),
            'settingsOverview' => $settingsOverview,
        ]);
    }

    public function saveSettings()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->saveSettingsValues([
            'site_name', 'site_public_url', 'site_logo', 'seo_keywords', 'seo_description',
            'register_enabled', 'register_email_code_enabled',
            'user_image_upload_enabled', 'user_netdisk_enabled', 'guest_image_upload_enabled',
            'guest_image_upload_user_id', 'guest_image_upload_max_size', 'guest_image_upload_daily_ip_limit',
            'security_login_max_attempts', 'security_login_window_minutes', 'security_login_lock_minutes',
            'security_email_code_max_per_hour', 'security_email_code_ip_max_per_hour',
            'file_naming_strategy', 'default_free_package_id',
            'api_rate_limit_per_minute', 'api_rate_limit_per_day',
            'email_host', 'email_port', 'email_username', 'email_password', 'email_from',
        ], 'admin/settings');
    }

    public function settingsSite()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $settings = $this->settingsMap();
        $this->adminView('admin/settings_site', [
            'title' => '站点信息设置',
            'settings' => $settings,
            'packages' => (new Package())->all(),
            'settingSections' => $this->settingsSections('site'),
        ]);
    }

    public function saveSettingsSite()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->saveSettingsValues([
            'site_name', 'site_public_url', 'site_logo', 'seo_keywords', 'seo_description', 'file_naming_strategy', 'default_free_package_id',
        ], 'admin/settings/site');
    }

    public function settingsSecurity()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $this->adminView('admin/settings_security', [
            'title' => '安全与注册设置',
            'settings' => $this->settingsMap(),
            'settingSections' => $this->settingsSections('security'),
        ]);
    }

    public function saveSettingsSecurity()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->saveSettingsValues([
            'register_enabled', 'register_email_code_enabled',
            'security_login_max_attempts', 'security_login_window_minutes', 'security_login_lock_minutes',
            'security_email_code_max_per_hour', 'security_email_code_ip_max_per_hour',
        ], 'admin/settings/security');
    }

    public function settingsUpload()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $this->adminView('admin/settings_upload', [
            'title' => '上传权限设置',
            'settings' => $this->settingsMap(),
            'settingSections' => $this->settingsSections('upload'),
        ]);
    }

    public function saveSettingsUpload()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->saveSettingsValues([
            'user_image_upload_enabled', 'user_netdisk_enabled', 'guest_image_upload_enabled',
            'guest_image_upload_user_id', 'guest_image_upload_max_size', 'guest_image_upload_daily_ip_limit',
        ], 'admin/settings/upload');
    }

    public function uploadLimits()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $service = new UploadLimitService();
        $this->adminView('admin/upload_limits', [
            'title' => '上传限制',
            'settings' => $this->settingsMap(),
            'limits' => $service->frontendConfig(),
            'uploadChecks' => $this->uploadRuntimeChecks(),
            'serverUploadLimits' => [
                'upload_max_filesize' => ini_get('upload_max_filesize') ?: '-',
                'post_max_size' => ini_get('post_max_size') ?: '-',
                'max_file_uploads' => ini_get('max_file_uploads') ?: '-',
                'max_execution_time' => ini_get('max_execution_time') ?: '-',
            ],
        ]);
    }

    public function saveUploadLimits()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $rules = [
            'upload_max_concurrency' => [1, 8],
            'upload_image_batch_limit' => [1, 500],
            'upload_file_batch_limit' => [1, 300],
            'upload_image_daily_limit' => [0, 1000000],
            'upload_file_daily_limit' => [0, 1000000],
        ];
        foreach ($rules as $key => $range) {
            $value = isset($_POST[$key]) ? (int) $_POST[$key] : 0;
            $value = max((int) $range[0], min((int) $range[1], $value));
            $this->saveSettingValue($key, (string) $value);
        }
        $this->adminLog('保存上传限制', 'setting', null);
        set_flash('success', '上传限制已保存。');
        $this->redirect('admin/upload-limits');
    }

    public function settingsApi()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $this->adminView('admin/settings_api', [
            'title' => 'API 限制设置',
            'settings' => $this->settingsMap(),
            'settingSections' => $this->settingsSections('api'),
        ]);
    }

    public function saveSettingsApi()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->saveSettingsValues([
            'api_rate_limit_per_minute', 'api_rate_limit_per_day',
        ], 'admin/settings/api');
    }

    public function settingsEmail()
    {
        DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        $this->adminView('admin/settings_email', [
            'title' => '邮件服务设置',
            'settings' => $this->settingsMap(),
            'settingSections' => $this->settingsSections('email'),
        ]);
    }

    public function saveSettingsEmail()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $this->saveSettingsValues([
            'email_host', 'email_port', 'email_username', 'email_password', 'email_from',
        ], 'admin/settings/email');
    }

    public function saveSettingsNotify()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $settings = [
            'alert_webhook_enabled' => isset($_POST['alert_webhook_enabled']) && (string) $_POST['alert_webhook_enabled'] === '1' ? '1' : '0',
            'alert_wecom_webhook' => trim((string) (isset($_POST['alert_wecom_webhook']) ? $_POST['alert_wecom_webhook'] : '')),
            'alert_dingtalk_webhook' => trim((string) (isset($_POST['alert_dingtalk_webhook']) ? $_POST['alert_dingtalk_webhook'] : '')),
            'alert_dingtalk_secret' => trim((string) (isset($_POST['alert_dingtalk_secret']) ? $_POST['alert_dingtalk_secret'] : '')),
            'alert_telegram_bot_token' => trim((string) (isset($_POST['alert_telegram_bot_token']) ? $_POST['alert_telegram_bot_token'] : '')),
            'alert_telegram_chat_id' => trim((string) (isset($_POST['alert_telegram_chat_id']) ? $_POST['alert_telegram_chat_id'] : '')),
        ];

        $errors = (new AlertWebhookService())->validateSettings($settings);
        if ($errors) {
            remember_old();
            set_flash('error', implode(' ', $errors));
            $this->redirect('admin/settings/email');
        }

        $existing = $this->settingsMap();
        foreach ($settings as $key => $value) {
            if (in_array($key, ['alert_wecom_webhook', 'alert_dingtalk_webhook', 'alert_dingtalk_secret', 'alert_telegram_bot_token'], true)) {
                if ($value === '' && isset($existing[$key]) && (string) $existing[$key] !== '') {
                    $value = (string) $existing[$key];
                } elseif ($value !== '') {
                    $value = CryptoService::encrypt($value);
                }
            }
            $this->saveSettingValue($key, $value);
        }

        $this->adminLog('保存告警通知通道', 'setting', null);
        set_flash('success', '告警通知通道已保存。');
        $this->redirect('admin/settings/email');
    }

    public function testEmail()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $email = trim($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            set_flash('error', '请填写正确的测试邮箱。');
            $this->redirect('admin/settings/email');
        }
        $ok = (new MailerService())->send($email, '邮件发送测试', '这是一封来自 ' . setting('site_name', app_brand_name()) . ' 的测试邮件。');
        set_flash($ok ? 'success' : 'error', $ok ? '测试邮件已发送。' : '测试邮件发送失败，请查看 storage/logs 日志。');
        $this->redirect('admin/settings/email');
    }

    public function testNotifyChannel()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $service = new AlertWebhookService();
        $channel = $service->normalizeChannel(isset($_POST['channel']) ? $_POST['channel'] : '');
        if ($channel === '') {
            set_flash('error', '请选择要测试的告警通知通道。');
            $this->redirect('admin/settings/email');
        }
        $result = $service->test($channel);
        $message = isset($result['message']) ? (string) $result['message'] : '';
        set_flash(!empty($result['success']) ? 'success' : 'error', !empty($result['success']) ? '测试消息已发送。' : ('测试发送失败：' . $message));
        $this->redirect('admin/settings/email');
    }

    public function themes()
    {
        if (!$this->ensureAdminFeatureSchema(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserThemeSchema'], '主题设置'),
            '主题设置',
            '主题设置依赖用户主题字段，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $user = Auth::user();
        $this->adminView('admin/themes', [
            'title' => '主题设置',
            'adminThemeStyle' => $user && isset($user['admin_theme_style']) && in_array($user['admin_theme_style'], ['classic', 'anime'], true) ? $user['admin_theme_style'] : '',
            'frontendThemeStyle' => setting('frontend_theme_style', 'classic'),
            'frontendHomeStyle' => setting('frontend_home_style', 'default'),
        ]);
    }

    public function saveThemes()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        if (!$this->ensureAdminFeatureSchemaOrRedirect(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserThemeSchema'], '主题设置'),
            '主题设置',
            'admin/themes',
            '主题设置数据结构未准备完成，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $adminStyle = $this->themeStyle(isset($_POST['admin_theme_style']) ? $_POST['admin_theme_style'] : 'anime');
        $frontendStyle = $this->themeStyle(isset($_POST['frontend_theme_style']) ? $_POST['frontend_theme_style'] : 'anime');
        $frontendHomeStyle = $this->frontendHomeStyle(isset($_POST['frontend_home_style']) ? $_POST['frontend_home_style'] : 'default');
        Database::execute('UPDATE ' . Database::table('users') . ' SET admin_theme_style = ?, updated_at = ? WHERE id = ?', [$adminStyle, now(), Auth::id()]);
        $this->saveSettingValue('frontend_theme_style', $frontendStyle);
        $this->saveSettingValue('frontend_home_style', $frontendHomeStyle);
        $this->adminLog('保存主题设置', 'setting', null);
        set_flash('success', '主题设置已保存。');
        $this->redirect('admin/themes');
    }

    public function maintenance()
    {
        $settings = [];
        foreach (Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings')) as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        $checks = [
            ['name' => 'PHP 版本', 'value' => PHP_VERSION, 'ok' => version_compare(PHP_VERSION, '7.4.0', '>=')],
            ['name' => 'PDO 扩展', 'value' => extension_loaded('pdo') ? '已启用' : '未启用', 'ok' => extension_loaded('pdo')],
            ['name' => 'cURL 扩展', 'value' => extension_loaded('curl') ? '已启用' : '未启用', 'ok' => extension_loaded('curl')],
            ['name' => 'OpenSSL 扩展', 'value' => extension_loaded('openssl') ? '已启用' : '未启用', 'ok' => extension_loaded('openssl')],
            ['name' => 'Fileinfo 扩展', 'value' => extension_loaded('fileinfo') ? '已启用' : '未启用', 'ok' => extension_loaded('fileinfo')],
            ['name' => 'ZipArchive 扩展', 'value' => class_exists('ZipArchive') ? '已启用' : '未启用，在线更新安装需要', 'ok' => class_exists('ZipArchive')],
            ['name' => 'storage 可写', 'value' => is_writable(APP_ROOT . '/storage') ? '可写' : '不可写', 'ok' => is_writable(APP_ROOT . '/storage')],
            ['name' => 'public/uploads 可写', 'value' => is_writable(APP_ROOT . '/public/uploads') ? '可写' : '不可写', 'ok' => is_writable(APP_ROOT . '/public/uploads')],
        ];
        try {
            $db = Database::fetch('SELECT VERSION() AS version');
            $dbVersion = $db ? $db['version'] : 'unknown';
        } catch (\Throwable $e) {
            $dbVersion = '读取失败';
        }
        $schemaAudit = DatabaseUpgradeService::inspectLiveSchema();
        $updateService = new OnlineUpdateService();
        $this->adminView('admin/maintenance', [
            'title' => '系统维护',
            'settings' => $settings,
            'checks' => $checks,
            'serverInfo' => $this->localServerInfo(),
            'databaseVersion' => $dbVersion,
            'schemaAudit' => $schemaAudit,
            'updateCurrentVersion' => $updateService->currentVersion(),
            'updateManifestUrl' => isset($settings['update_manifest_url']) ? $settings['update_manifest_url'] : '',
            'updatePackages' => $updateService->packages(),
        ]);
    }

    public function maintenanceUpdate()
    {
        $settings = $this->settingsMap();
        $updateService = new OnlineUpdateService();
        $this->adminView('admin/maintenance_update', [
            'title' => '在线更新',
            'settings' => $settings,
            'updateCurrentVersion' => $updateService->currentVersion(),
            'updateManifestUrl' => isset($settings['update_manifest_url']) ? $settings['update_manifest_url'] : '',
            'updatePackages' => $updateService->packages(),
        ]);
    }

    public function maintenanceEnvironment()
    {
        $this->adminView('admin/maintenance_environment', [
            'title' => '环境信息',
            'checks' => $this->environmentChecks(),
            'uploadChecks' => $this->uploadRuntimeChecks(),
            'serverInfo' => $this->localServerInfo(),
            'databaseVersion' => $this->databaseVersion(),
        ]);
    }

    public function schemaAudit()
    {
        $this->adminView('admin/schema_audit', [
            'title' => 'Database Schema Audit',
            'schemaAudit' => DatabaseUpgradeService::inspectLiveSchema(),
        ]);
    }

    public function saveMaintenance()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $maintenance = isset($_POST['site_maintenance']) ? '1' : '0';
        $message = trim(isset($_POST['maintenance_message']) ? $_POST['maintenance_message'] : '');
        if ($message === '') {
            $message = '系统正在维护升级，请稍后再访问。';
        }
        $this->saveSettingValue('site_maintenance', $maintenance);
        $this->saveSettingValue('maintenance_message', $message);
        $this->adminLog('保存维护模式', 'maintenance', null);
        set_flash('success', $maintenance === '1' ? '维护模式已开启，前台访问将显示维护页。' : '维护模式已关闭，前台已恢复访问。');
        $this->redirect('admin/maintenance');
    }

    public function repairSchema()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $repairOk = false;

        try {
            $result = DatabaseUpgradeService::repairAll();
            $repairOk = !empty($result['ok']);
            set_flash('schema_repair_result', $result);

            $createdTables = isset($result['schema']['created_count']) ? (int) $result['schema']['created_count'] : 0;
            $createdRows = isset($result['defaults']['created_count']) ? (int) $result['defaults']['created_count'] : 0;
            $successCount = isset($result['success_count']) ? (int) $result['success_count'] : 0;
            $failCount = isset($result['fail_count']) ? (int) $result['fail_count'] : 0;
            $schemaIssueCount = isset($result['schema_unresolved_count']) ? (int) $result['schema_unresolved_count'] : 0;

            if (!empty($result['ok'])) {
                $autoSqlText = '';
                if (!empty($result['auto_sql_repair']) && is_array($result['auto_sql_repair'])) {
                    $autoSqlText = '，自动执行补齐 SQL ' . (int) (isset($result['auto_sql_repair']['executed_count']) ? $result['auto_sql_repair']['executed_count'] : 0) . ' 条';
                }
                set_flash('success', '数据库结构修复已完成，创建或检查表 ' . $createdTables . ' 个，补齐默认数据 ' . $createdRows . ' 条，成功任务 ' . $successCount . ' 个' . $autoSqlText . '。');
            } else {
                $missing = !empty($result['missing_tables']) ? '，仍缺少：' . implode('、', array_slice($result['missing_tables'], 0, 8)) : '';
                $failedLabels = [];
                foreach (isset($result['results']) && is_array($result['results']) ? $result['results'] : [] as $item) {
                    if (empty($item['ok'])) {
                        $failedLabels[] = isset($item['label']) ? $item['label'] : (isset($item['key']) ? $item['key'] : '未知任务');
                    }
                }
                $failedText = $failedLabels ? '，失败项：' . implode('、', array_slice($failedLabels, 0, 5)) . (count($failedLabels) > 5 ? ' 等' : '') : '';
                $privilegeText = '';
                if (!empty($result['privileges']) && is_array($result['privileges']) && empty($result['privileges']['ok'])) {
                    $privilegeText = '权限探针未通过，请查看页面里的权限检测明细。';
                } else {
                    $privilegeText = '请查看页面里的失败任务和待执行 SQL。';
                }
                $countText = $schemaIssueCount > 0
                    ? '仍有 ' . $schemaIssueCount . ' 个表/字段结构问题，' . $failCount . ' 个修复任务未完成'
                    : '仍有 ' . $failCount . ' 个修复任务未完成';
                set_flash('error', '数据库结构修复已执行，但' . $countText . $missing . $failedText . '。' . $privilegeText);
            }

            try {
                $this->adminLog('一键修复数据库结构', 'maintenance', null);
            } catch (\Throwable $logException) {
                Logger::error('记录数据库修复日志失败：' . $logException->getMessage());
            }
        } catch (\Throwable $e) {
            Logger::error('数据库结构修复失败：' . $e->getMessage());
            set_flash('error', '数据库结构修复失败：' . $e->getMessage());
        }

        $returnTo = isset($_POST['return_to']) ? trim((string) $_POST['return_to']) : '';
        if (!$repairOk) {
            $this->redirect('admin/maintenance/schema-audit');
        }
        if ($returnTo === 'feature-audit') {
            $this->redirect('admin/feature-audit');
        }
        if ($returnTo === 'schema-audit') {
            $this->redirect('admin/maintenance/schema-audit');
        }
        $this->redirect('admin/maintenance');
    }

    public function repairSchemaWithTemporaryAdmin()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $username = trim(isset($_POST['db_admin_user']) ? (string) $_POST['db_admin_user'] : '');
        $password = isset($_POST['db_admin_pass']) ? (string) $_POST['db_admin_pass'] : '';
        if ($username === '') {
            set_flash('error', '请填写临时数据库账号。');
            $this->redirect('admin/maintenance/schema-audit');
        }

        $originalPdo = null;
        try {
            $originalPdo = Database::getInstance();
            $temporaryPdo = Database::connectionFromConfig([
                'username' => $username,
                'password' => $password,
            ]);
            Database::swapConnection($temporaryPdo);

            $result = DatabaseUpgradeService::repairAll();
            $result['temporary_admin_repair'] = true;
            set_flash('schema_repair_result', $result);

            if (!empty($result['ok'])) {
                $executed = !empty($result['auto_sql_repair']) && is_array($result['auto_sql_repair'])
                    ? (int) (isset($result['auto_sql_repair']['executed_count']) ? $result['auto_sql_repair']['executed_count'] : 0)
                    : 0;
                set_flash('success', '已使用临时高权限账号完成数据库结构修复，自动执行 SQL ' . $executed . ' 条。');
            } else {
                set_flash('error', '临时高权限账号已执行修复，但仍有未完成项，请查看失败项和待执行 SQL。');
            }

            try {
                $this->adminLog('使用临时数据库账号修复结构', 'maintenance', null);
            } catch (\Throwable $logException) {
                Logger::error('记录临时数据库修复日志失败：' . $logException->getMessage());
            }
        } catch (\Throwable $e) {
            Logger::error('临时数据库账号修复失败：' . $e->getMessage());
            set_flash('error', '临时数据库账号修复失败：' . $e->getMessage());
        }

        if ($originalPdo) {
            Database::swapConnection($originalPdo);
        } else {
            Database::resetConnection();
        }
        $this->redirect('admin/maintenance/schema-audit');
    }

    public function exportDatabase()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $pdo = Database::getInstance();
        $prefix = Database::prefix();
        $tables = [];
        foreach ($pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_NUM) as $row) {
            $name = $row[0];
            if (strpos($name, $prefix) === 0) {
                $tables[] = $name;
            }
        }
        $fileName = 'bmtools-backup-' . date('Ymd-His') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        echo "-- BM TOOLS database backup\n";
        echo "-- Created at " . now() . "\n\n";
        echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";
        foreach ($tables as $table) {
            $quotedTable = $this->quoteIdentifier($table);
            $create = $pdo->query('SHOW CREATE TABLE ' . $quotedTable)->fetch(\PDO::FETCH_ASSOC);
            echo 'DROP TABLE IF EXISTS ' . $quotedTable . ";\n";
            echo $create['Create Table'] . ";\n\n";
            $stmt = $pdo->query('SELECT * FROM ' . $quotedTable);
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $columns = [];
                $values = [];
                foreach ($row as $column => $value) {
                    $columns[] = $this->quoteIdentifier($column);
                    $values[] = $value === null ? 'NULL' : $pdo->quote((string) $value);
                }
                echo 'INSERT INTO ' . $quotedTable . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', $values) . ");\n";
            }
            echo "\n";
        }
        echo "SET FOREIGN_KEY_CHECKS=1;\n";
        $this->adminLog('导出数据库备份', 'maintenance', null);
        exit;
    }

    public function checkUpdate()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $manifestUrl = trim(isset($_POST['manifest_url']) ? $_POST['manifest_url'] : '');
        try {
            $result = (new OnlineUpdateService())->check($manifestUrl);
            $this->saveSettingValue('update_manifest_url', $manifestUrl);
            set_flash('update_result', $result);
            set_flash('success', '更新源检查完成。');
            $this->adminLog('检查在线更新', 'maintenance', null);
        } catch (\Throwable $e) {
            set_flash('error', '检查更新失败：' . $e->getMessage());
        }
        $this->redirect('admin/maintenance/update');
    }

    public function downloadUpdate()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $packageUrl = trim(isset($_POST['package_url']) ? $_POST['package_url'] : '');
        $sha256 = trim(isset($_POST['package_sha256']) ? $_POST['package_sha256'] : '');
        $version = trim(isset($_POST['version']) ? $_POST['version'] : '');
        try {
            $package = (new OnlineUpdateService())->download($packageUrl, $sha256, $version);
            set_flash('update_package', $package);
            set_flash('success', '更新包已下载。');
            $this->adminLog('下载更新包', 'maintenance', null);
        } catch (\Throwable $e) {
            set_flash('error', '下载更新包失败：' . $e->getMessage());
        }
        $this->redirect('admin/maintenance/update');
    }

    public function installUpdate()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $packageFile = trim(isset($_POST['package_file']) ? $_POST['package_file'] : '');
        $version = trim(isset($_POST['version']) ? $_POST['version'] : '');
        try {
            $result = (new OnlineUpdateService())->install($packageFile, $version);
            set_flash('update_install_result', $result);
            set_flash('success', '更新包已安装。');
            $this->adminLog('安装更新包', 'maintenance', null);
        } catch (\Throwable $e) {
            set_flash('error', '安装更新包失败：' . $e->getMessage());
        }
        $this->redirect('admin/maintenance/update');
    }

    public function logs()
    {
        if (!$this->ensureAdminTables(
            ['admin_logs', 'users'],
            '管理员日志',
            '管理员日志依赖 admin_logs、users 数据表，请先执行数据库巡检修复。',
        )) {
            return;
        }
        $filters = [
            'keyword' => trim(isset($_GET['keyword']) ? $_GET['keyword'] : ''),
            'date_start' => trim(isset($_GET['date_start']) ? $_GET['date_start'] : ''),
            'date_end' => trim(isset($_GET['date_end']) ? $_GET['date_end'] : ''),
        ];
        $where = [];
        $params = [];
        if ($filters['keyword'] !== '') {
            $where[] = '(u.username LIKE ? OR u.email LIKE ? OR l.action LIKE ? OR l.target_type LIKE ? OR l.ip LIKE ?)';
            for ($i = 0; $i < 5; $i++) {
                $params[] = '%' . $filters['keyword'] . '%';
            }
        }
        if ($filters['date_start'] !== '') {
            $where[] = 'l.created_at >= ?';
            $params[] = $filters['date_start'] . ' 00:00:00';
        }
        if ($filters['date_end'] !== '') {
            $where[] = 'l.created_at <= ?';
            $params[] = $filters['date_end'] . ' 23:59:59';
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $logs = Database::fetchAll(
            'SELECT l.*, u.username, u.email
             FROM ' . Database::table('admin_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.admin_id = u.id
             ' . $whereSql . '
             ORDER BY l.id DESC
             LIMIT 300',
            $params
        );
        $filtered = Database::fetch(
            'SELECT COUNT(*) AS total
             FROM ' . Database::table('admin_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.admin_id = u.id
             ' . $whereSql,
            $params
        );
        $stats = [
            'total' => $this->safeCount('admin_logs'),
            'today' => $this->safeCount('admin_logs', 'DATE(created_at) = CURDATE()'),
            'admins' => (int) Database::fetch('SELECT COUNT(DISTINCT admin_id) AS c FROM ' . Database::table('admin_logs'))['c'],
            'filtered_total' => $filtered ? (int) $filtered['total'] : 0,
        ];
        $this->adminView('admin/logs', [
            'title' => '管理员日志',
            'logs' => $logs,
            'filters' => $filters,
            'stats' => $stats,
        ]);
    }

    public function featureAudit()
    {
        $menuAudit = $this->auditMenuLinks([
            APP_ROOT . '/app/Views/layouts/app.php' => '前台主菜单',
            APP_ROOT . '/app/Views/layouts/admin.php' => '后台主菜单',
        ]);
        $menuAudit = array_merge($menuAudit, $this->auditRouteList([
            ['scope' => '前台公共菜单', 'label' => '首页', 'path' => '/'],
            ['scope' => '前台公共菜单', 'label' => '公告通知', 'path' => '/announcements'],
            ['scope' => '前台公共菜单', 'label' => '服务状态', 'path' => '/status'],
            ['scope' => '前台账户菜单', 'label' => '登录', 'path' => '/login'],
            ['scope' => '前台账户菜单', 'label' => '注册', 'path' => '/register'],
            ['scope' => '用户工作台', 'label' => '个人中心', 'path' => '/dashboard'],
            ['scope' => '用户工作台', 'label' => '消息中心', 'path' => '/notifications'],
            ['scope' => '用户资源', 'label' => '图床服务', 'path' => '/files'],
            ['scope' => '用户资源', 'label' => '个人网盘', 'path' => '/netdisk'],
            ['scope' => '用户资源', 'label' => '分享仓库', 'path' => '/repository'],
            ['scope' => '用户运维', 'label' => '服务器管家', 'path' => '/servers'],
            ['scope' => '用户运维', 'label' => '监控告警', 'path' => '/alerts'],
            ['scope' => '用户商业', 'label' => '套餐升级', 'path' => '/packages'],
            ['scope' => '用户商业', 'label' => '账户充值', 'path' => '/recharge'],
            ['scope' => '用户商业', 'label' => '卡密兑换', 'path' => '/cards'],
            ['scope' => '用户商业', 'label' => '订单记录', 'path' => '/orders'],
            ['scope' => '用户设置', 'label' => '账户资料', 'path' => '/profile'],
            ['scope' => '用户设置', 'label' => 'API 管理', 'path' => '/api/console'],
            ['scope' => '后台运营', 'label' => '控制台', 'path' => '/admin'],
            ['scope' => '后台运营', 'label' => '用户管理', 'path' => '/admin/users'],
            ['scope' => '后台运营', 'label' => '套餐管理', 'path' => '/admin/packages'],
            ['scope' => '后台运营', 'label' => '营销活动', 'path' => '/admin/coupons'],
            ['scope' => '后台运营', 'label' => '卡密管理', 'path' => '/admin/cards'],
            ['scope' => '后台交易', 'label' => '订单管理', 'path' => '/admin/orders'],
            ['scope' => '后台交易', 'label' => '充值审核', 'path' => '/admin/recharges'],
            ['scope' => '后台交易', 'label' => '支付配置', 'path' => '/admin/payments'],
            ['scope' => '后台交易', 'label' => '余额流水', 'path' => '/admin/balance-logs'],
            ['scope' => '后台资源', 'label' => '资源功能管理', 'path' => '/admin/storages'],
            ['scope' => '后台资源', 'label' => '同系统对接', 'path' => '/admin/storage-integrations'],
            ['scope' => '后台资源', 'label' => '文件管理', 'path' => '/admin/files'],
            ['scope' => '后台资源', 'label' => '分享仓库', 'path' => '/admin/repositories'],
            ['scope' => '后台资源', 'label' => '监控管理', 'path' => '/admin/monitors'],
            ['scope' => '后台资源', 'label' => '用户服务器', 'path' => '/admin/user-servers'],
            ['scope' => '后台资源', 'label' => 'SSH 会话', 'path' => '/admin/ssh-sessions'],
            ['scope' => '后台资源', 'label' => '命令审计', 'path' => '/admin/command-logs'],
            ['scope' => '后台内容', 'label' => '公告管理', 'path' => '/admin/announcements'],
            ['scope' => '后台系统', 'label' => '站点信息', 'path' => '/admin/settings/site'],
            ['scope' => '后台系统', 'label' => '安全与注册', 'path' => '/admin/settings/security'],
            ['scope' => '后台系统', 'label' => '上传权限', 'path' => '/admin/settings/upload'],
            ['scope' => '后台系统', 'label' => 'API 限制', 'path' => '/admin/settings/api'],
            ['scope' => '后台系统', 'label' => '邮件服务', 'path' => '/admin/settings/email'],
            ['scope' => '后台系统', 'label' => '运维设置', 'path' => '/admin/server-ops/settings'],
            ['scope' => '后台系统', 'label' => '主题设置', 'path' => '/admin/themes'],
            ['scope' => '后台系统', 'label' => '系统设置', 'path' => '/admin/settings'],
            ['scope' => '后台系统', 'label' => 'API 日志', 'path' => '/admin/api-logs'],
            ['scope' => '后台系统', 'label' => '功能巡检', 'path' => '/admin/feature-audit'],
            ['scope' => '后台系统', 'label' => '系统维护', 'path' => '/admin/maintenance'],
            ['scope' => '后台系统', 'label' => '管理员日志', 'path' => '/admin/logs'],
        ]));
        $routeAudit = $this->auditRouterTargets();
        $formAudit = $this->auditViewForms();
        $tableAudit = $this->auditResponsiveTables();
        $assetChecks = $this->auditFrontendAssets();
        $schemaAudit = DatabaseUpgradeService::inspectLiveSchema();
        $schemaChecks = $this->schemaHealthChecks($schemaAudit);
        $environmentChecks = $this->environmentChecks();
        $uploadChecks = $this->uploadRuntimeChecks();
        $securityChecks = $this->auditSecurityPosture();

        $requiredTables = [
            'users' => '用户账户',
            'files' => '图床与网盘文件',
            'file_folders' => '网盘目录',
            'file_shares' => '网盘分享',
            'file_repositories' => '分享仓库',
            'packages' => '套餐',
            'orders' => '订单',
            'recharges' => '充值',
            'balance_logs' => '余额流水',
            'storage_drivers' => '第三方存储',
            'payment_config' => '支付配置',
            'monitor_servers' => '服务器监控',
            'monitor_metrics' => '监控指标',
            'monitor_alerts' => '监控告警',
            'server_command_logs' => 'SSH 命令审计',
            'api_logs' => '开放 API 日志',
            'admin_logs' => '后台操作日志',
            'settings' => '系统设置',
        ];
        $tableChecks = [];
        foreach ($requiredTables as $table => $label) {
            $exists = $this->tableExists($table);
            $tableChecks[] = [
                'label' => $label,
                'table' => Database::table($table),
                'ok' => $exists,
                'count' => $exists ? $this->safeCount($table) : 0,
                'hint' => $exists ? '数据表正常' : '缺少数据表，可直接点击“一键修复数据表”自动补齐',
            ];
        }

        $directoryChecks = [];
        foreach ([
            APP_ROOT . '/storage' => '运行缓存目录',
            APP_ROOT . '/storage/cache' => '缓存目录',
            APP_ROOT . '/storage/logs' => '日志目录',
            APP_ROOT . '/public/uploads' => '本地上传目录',
        ] as $path => $label) {
            $directoryChecks[] = [
                'label' => $label,
                'path' => $path,
                'ok' => is_dir($path) && is_writable($path),
                'hint' => is_dir($path) ? (is_writable($path) ? '可写' : '不可写，请检查权限') : '目录不存在',
            ];
        }

        $defaultStorage = null;
        $enabledStorageCount = 0;
        $enabledPaymentCount = 0;
        try {
            $defaultStorage = Database::fetch('SELECT name, type FROM ' . Database::table('storage_drivers') . ' WHERE is_enabled = 1 AND is_default = 1 LIMIT 1');
            $enabledStorageCount = $this->safeCount('storage_drivers', 'is_enabled = 1');
            $enabledPaymentCount = $this->safeCount('payment_config', 'is_enabled = 1');
        } catch (\Throwable $e) {
            $defaultStorage = null;
        }
        $cronToken = trim((string) setting('monitor_cron_token', ''));
        $siteUrl = rtrim(url('/'), '/');
        $serviceChecks = [
            [
                'label' => '默认存储源',
                'ok' => (bool) $defaultStorage,
                'value' => $defaultStorage ? (($defaultStorage['name'] ?: '未命名') . ' / ' . strtoupper((string) $defaultStorage['type'])) : '未配置',
                'hint' => $defaultStorage ? '上传链路已有默认存储。' : '请先配置并启用一个默认存储源。',
                'stage' => '上传链路',
                'action_url' => 'admin/storages',
                'action_label' => '配置存储',
            ],
            [
                'label' => '可用存储源',
                'ok' => $enabledStorageCount > 0,
                'value' => $enabledStorageCount,
                'hint' => $enabledStorageCount > 0 ? '第三方或本地存储可用。' : '没有启用的存储源。',
                'stage' => '存储接入',
                'action_url' => 'admin/storages',
                'action_label' => '查看存储',
            ],
            [
                'label' => '支付通道',
                'ok' => $enabledPaymentCount > 0,
                'value' => $enabledPaymentCount,
                'hint' => $enabledPaymentCount > 0 ? '至少一个支付通道已启用。' : '未启用支付通道，套餐购买只能人工处理。',
                'stage' => '商业闭环',
                'action_url' => 'admin/payments',
                'action_label' => '配置支付',
            ],
            [
                'label' => '监控采集链接',
                'ok' => $cronToken !== '',
                'value' => $cronToken !== '' ? $siteUrl . '/cron/monitor?token=' . $cronToken : '未生成',
                'hint' => $cronToken !== '' ? '计划任务可访问该链接触发采集。' : '进入监控管理页会自动生成 Token。',
                'stage' => '监控采集',
                'action_url' => 'admin/monitors',
                'action_label' => '打开监控',
            ],
            [
                'label' => '邮件服务',
                'ok' => trim((string) setting('email_host', '')) !== '',
                'value' => trim((string) setting('email_host', '')) !== '' ? setting('email_host', '') : '未配置',
                'hint' => trim((string) setting('email_host', '')) !== '' ? '邮件通知具备发送配置。' : '未配置邮件服务，注册验证和通知会受影响。',
                'stage' => '通知送达',
                'action_url' => 'admin/settings/email',
                'action_label' => '配置邮件',
            ],
            [
                'label' => 'SSH 运维能力',
                'ok' => class_exists('\\phpseclib3\\Net\\SSH2') || function_exists('ssh2_connect') || (string) setting('ssh_terminal_enabled', '1') !== '1',
                'value' => class_exists('\\phpseclib3\\Net\\SSH2') ? 'phpseclib 3' : (function_exists('ssh2_connect') ? 'ssh2 扩展' : ((string) setting('ssh_terminal_enabled', '1') === '1' ? '缺少 SSH 客户端' : '终端已关闭')),
                'hint' => class_exists('\\phpseclib3\\Net\\SSH2') || function_exists('ssh2_connect') ? '在线终端和 SSH 采集具备运行条件。' : '如需在线终端，请安装 phpseclib/phpseclib 或 PHP ssh2 扩展；也可改用 Agent 主动上报。',
                'stage' => '运维工具',
                'action_url' => 'admin/server-ops/settings',
                'action_label' => '运维设置',
            ],
        ];
        $diagnosticCards = $this->featureDiagnosticCards($schemaChecks, $environmentChecks, $securityChecks, $serviceChecks, $directoryChecks, $uploadChecks);

        $this->adminView('admin/feature_audit', [
            'title' => '功能巡检',
            'menuAudit' => $menuAudit,
            'routeAudit' => $routeAudit,
            'formAudit' => $formAudit,
            'tableAudit' => $tableAudit,
            'assetChecks' => $assetChecks,
            'schemaAudit' => $schemaAudit,
            'schemaChecks' => $schemaChecks,
            'environmentChecks' => $environmentChecks,
            'uploadChecks' => $uploadChecks,
            'securityChecks' => $securityChecks,
            'diagnosticCards' => $diagnosticCards,
            'tableChecks' => $tableChecks,
            'directoryChecks' => $directoryChecks,
            'serviceChecks' => $serviceChecks,
        ]);
    }

    protected function couponStats()
    {
        return [
            'total' => $this->count('coupons'),
            'enabled' => $this->count('coupons', 'status = 1'),
            'used' => $this->count('coupon_redemptions'),
            'discount' => Database::fetch('SELECT COALESCE(SUM(discount_amount),0) AS total FROM ' . Database::table('coupon_redemptions'))['total'],
        ];
    }

    protected function recentCouponRedemptions()
    {
        if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动')) {
            return [];
        }
        return Database::fetchAll('SELECT r.*, c.title AS coupon_title, c.code AS coupon_code, u.username, o.order_no, p.name AS package_name FROM ' . Database::table('coupon_redemptions') . ' r LEFT JOIN ' . Database::table('coupons') . ' c ON r.coupon_id = c.id LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id LEFT JOIN ' . Database::table('orders') . ' o ON r.order_id = o.id LEFT JOIN ' . Database::table('packages') . ' p ON r.package_id = p.id ORDER BY r.id DESC LIMIT 12');
    }

    protected function normalizeDateTime($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace('T', ' ', $value);
        if (strlen($value) === 16) {
            $value .= ':00';
        }
        return $value;
    }

    protected function count($table, $where = '')
    {
        $sql = 'SELECT COUNT(*) AS c FROM ' . Database::table($table);
        if ($where) {
            $sql .= ' WHERE ' . $where;
        }
        return (int) Database::fetch($sql)['c'];
    }

    protected function safeCount($table, $where = '')
    {
        try {
            return $this->count($table, $where);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function tableExists($table)
    {
        try {
            return Database::tableExists(Database::table($table));
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function columnExists($table, $column)
    {
        try {
            return Database::columnExists(Database::table($table), $column);
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function safeRows($sql, array $params = [])
    {
        try {
            return Database::fetchAll($sql, $params);
        } catch (\Throwable $e) {
            Logger::error('安全查询失败：' . $e->getMessage());
            return [];
        }
    }

    protected function incidentDateSql(array $filters, $column)
    {
        $where = [];
        $params = [];
        $column = preg_match('/^[A-Za-z0-9_\.]+$/', (string) $column) ? $column : 'created_at';
        if (!empty($filters['date_start'])) {
            $where[] = $column . ' >= ?';
            $params[] = $filters['date_start'] . ' 00:00:00';
        }
        if (!empty($filters['date_end'])) {
            $where[] = $column . ' <= ?';
            $params[] = $filters['date_end'] . ' 23:59:59';
        }
        return ['where' => $where, 'params' => $params];
    }

    protected function incidentApiRows(array $dateWhere, array $dateParams)
    {
        if (!$this->tableExists('api_logs')) {
            return [];
        }
        $where = array_merge(['l.is_success = 0'], array_map(function ($item) {
            return 'l.' . $item;
        }, $dateWhere));
        return $this->safeRows(
            'SELECT l.*, u.username
             FROM ' . Database::table('api_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY l.id DESC LIMIT 20',
            $dateParams
        );
    }

    protected function incidentBackupRows(array $dateWhere, array $dateParams)
    {
        if (!$this->tableExists('file_storage_backups')) {
            return [];
        }
        $where = array_merge(["b.status = 'failed'"], array_map(function ($item) {
            return 'b.' . $item;
        }, $dateWhere));
        return $this->safeRows(
            'SELECT b.*, f.original_name, f.user_id, u.username, s.name AS storage_name
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             LEFT JOIN ' . Database::table('users') . ' u ON f.user_id = u.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON b.storage_id = s.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY b.updated_at DESC, b.id DESC LIMIT 20',
            $dateParams
        );
    }

    protected function incidentCommandRows(array $dateWhere, array $dateParams)
    {
        if (!$this->tableExists('server_command_logs')) {
            return [];
        }
        $where = array_merge(["cl.risk_level IN ('warning','danger')"], array_map(function ($item) {
            return 'cl.' . $item;
        }, $dateWhere));
        return $this->safeRows(
            'SELECT cl.*, u.username, s.name AS server_name
             FROM ' . Database::table('server_command_logs') . ' cl
             LEFT JOIN ' . Database::table('users') . ' u ON cl.user_id = u.id
             LEFT JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY cl.id DESC LIMIT 20',
            $dateParams
        );
    }

    protected function incidentUploadRows(array $dateWhere, array $dateParams)
    {
        if (!$this->tableExists('file_logs')) {
            return [];
        }
        $where = array_merge(["l.action IN ('image_upload','file_upload')"], array_map(function ($item) {
            return 'l.' . $item;
        }, $dateWhere));
        return $this->safeRows(
            'SELECT l.*, u.username
             FROM ' . Database::table('file_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY l.id DESC LIMIT 20',
            $dateParams
        );
    }

    protected function incidentUploadFailureRows(array $dateWhere, array $dateParams)
    {
        if (!$this->tableExists('upload_failures')) {
            return [];
        }
        $where = array_map(function ($item) {
            return 'uf.' . $item;
        }, $dateWhere);
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        return $this->safeRows(
            'SELECT uf.*, u.username, s.name AS storage_name
             FROM ' . Database::table('upload_failures') . ' uf
             LEFT JOIN ' . Database::table('users') . ' u ON uf.user_id = u.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON uf.storage_id = s.id
             ' . $whereSql . '
             ORDER BY uf.id DESC LIMIT 30',
            $dateParams
        );
    }

    protected function uploadFailureStageLabel($errorType)
    {
        $labels = [
            'php_upload_limit' => 'PHP 上传环境',
            'quota_or_permission' => '套餐或权限',
            'storage' => '对象存储',
            'storage_config' => '存储配置',
            'storage_upload' => '对象写入',
            'storage_url' => '外链访问',
            'storage_delete' => '删除清理',
            'storage_db' => '数据库入库',
            'schema' => '数据库结构',
        ];
        return isset($labels[$errorType]) ? $labels[$errorType] : '';
    }

    protected function incidentAdminRows(array $dateWhere, array $dateParams)
    {
        if (!$this->tableExists('admin_logs')) {
            return [];
        }
        $where = array_map(function ($item) {
            return 'l.' . $item;
        }, $dateWhere);
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        return $this->safeRows(
            'SELECT l.*, u.username
             FROM ' . Database::table('admin_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.admin_id = u.id
             ' . $whereSql . '
             ORDER BY l.id DESC LIMIT 20',
            $dateParams
        );
    }

    protected function ensureAdminFeatureSchema($ready, $featureLabel, $detail = '')
    {
        if ($ready) {
            return true;
        }
        if (DatabaseUpgradeService::standardSchemaReady()) {
            return true;
        }

        Logger::error('Admin feature schema is not ready: ' . $featureLabel);
        $this->adminView('admin/schema_repair_required', [
            'title' => $featureLabel . '需要数据库修复',
            'featureLabel' => $featureLabel,
            'detail' => '当前功能依赖的数据表或字段还没有准备完成，请进入系统维护执行数据库升级。',
            'repairUrl' => 'admin/maintenance/schema-audit',
            'maintenanceUrl' => 'admin/maintenance',
        ]);
        return false;
    }

    protected function safeSchemaReady(callable $callback, $featureLabel = '')
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            Logger::error('Schema guard failed for ' . $featureLabel . ': ' . $e->getMessage());
            return false;
        }
    }

    protected function combinedSchemaReady(array $callbacks, $featureLabel = '')
    {
        foreach ($callbacks as $callback) {
            if (!$this->safeSchemaReady($callback, $featureLabel)) {
                return false;
            }
        }
        return true;
    }

    protected function ensureAdminTables(array $tables, $featureLabel, $detail = '')
    {
        $missing = [];
        foreach ($tables as $table) {
            if (!$this->tableExists($table)) {
                $missing[] = $table;
            }
        }
        if (!$missing) {
            return true;
        }

        $message = $detail !== '' ? $detail : ($featureLabel . '依赖的数据表未准备完成。');
        $message .= ' 缺失表：' . implode(', ', $missing) . '。';
        Logger::error('Admin feature required tables are missing: ' . $featureLabel . ' / ' . implode(',', $missing));
        $this->adminView('admin/schema_repair_required', [
            'title' => $featureLabel . '需要数据库修复',
            'featureLabel' => $featureLabel,
            'detail' => $message,
            'repairUrl' => 'admin/maintenance/schema-audit',
            'maintenanceUrl' => 'admin/maintenance',
        ]);
        return false;
    }

    protected function ensureAdminFeatureSchemaOrRedirect($ready, $featureLabel, $back = 'admin/maintenance/schema-audit', $detail = '')
    {
        if ($ready) {
            return true;
        }
        if (DatabaseUpgradeService::standardSchemaReady()) {
            return true;
        }

        $message = $detail !== '' ? $detail : ($featureLabel . '数据结构未准备完成，请先进入数据库巡检执行一键修复。');
        Logger::error('Admin feature schema is not ready for action: ' . $featureLabel . ' / back=' . $back);

        if ($this->expectsJson()) {
            $this->json([
                'success' => false,
                'message' => $message,
                'error_type' => 'schema',
                'repair_url' => url('admin/maintenance/schema-audit'),
            ], 500);
        }

        set_flash('error', $message);
        $this->redirect('admin/maintenance/schema-audit');
        return false;
    }

    protected function ensureStorageDriverSchemaReady()
    {
        $ready = $this->combinedSchemaReady([
            [DatabaseUpgradeService::class, 'ensureStorageDriverTypes'],
            [DatabaseUpgradeService::class, 'ensureStorageSecretEncryption'],
        ], '资源功能管理');
        return $ready || DatabaseUpgradeService::standardSchemaReady();
    }

    protected function ensureStorageBackupSchemaOrRedirect($back = 'admin/storage-backups')
    {
        if ($this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureStorageBackupSchema'], '备份策略')) {
            return true;
        }
        if (DatabaseUpgradeService::standardSchemaReady()) {
            return true;
        }

        return $this->ensureAdminFeatureSchemaOrRedirect(
            false,
            '备份策略',
            $back,
            '备份策略数据结构未准备完成，请先执行数据库巡检修复。',
        );
    }

    protected function auditMenuLinks(array $files)
    {
        $routes = $this->routerRoutes();
        $items = [];
        foreach ($files as $file => $scope) {
            if (!is_file($file)) {
                continue;
            }
            $source = file_get_contents($file);
            if ($source === false) {
                continue;
            }
            if (!preg_match_all('/url\(\s*([\'"])([^\'"]*)\1\s*\)/', $source, $matches, PREG_SET_ORDER)) {
                continue;
            }
            foreach ($matches as $match) {
                $raw = trim($match[2]);
                if ($raw === '' || strpos($raw, 'http') === 0 || strpos($raw, '#') === 0) {
                    continue;
                }
                $path = '/' . trim($raw, '/');
                if ($raw === '/') {
                    $path = '/';
                }
                $key = $scope . '|' . $path;
                if (isset($items[$key])) {
                    continue;
                }
                $exists = isset($routes['GET'][$path]);
                $items[$key] = [
                    'scope' => $scope,
                    'path' => $path,
                    'ok' => $exists,
                    'target' => $exists ? $routes['GET'][$path] : '未找到 GET 路由',
                ];
            }
        }
        return array_values($items);
    }

    protected function auditRouteList(array $definitions)
    {
        $routes = $this->routerRoutes();
        $items = [];
        foreach ($definitions as $definition) {
            $path = isset($definition['path']) ? (string) $definition['path'] : '/';
            $path = $path === '/' ? '/' : '/' . trim($path, '/');
            $exists = isset($routes['GET'][$path]);
            $items[] = [
                'scope' => isset($definition['scope']) ? $definition['scope'] : '菜单',
                'label' => isset($definition['label']) ? $definition['label'] : $path,
                'path' => $path,
                'ok' => $exists,
                'target' => $exists ? $routes['GET'][$path] : '未找到 GET 路由',
            ];
        }
        return $items;
    }

    protected function routerRoutes()
    {
        try {
            $ref = new \ReflectionClass('App\\Core\\Router');
            $prop = $ref->getProperty('routes');
            $prop->setAccessible(true);
            $routes = $prop->getValue();
            return is_array($routes) ? $routes : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    protected function auditRouterTargets()
    {
        $routes = $this->routerRoutes();
        $items = [];
        foreach ($routes as $method => $methodRoutes) {
            if (!is_array($methodRoutes)) {
                continue;
            }
            foreach ($methodRoutes as $path => $target) {
                $target = (string) $target;
                $ok = false;
                $hint = '路由目标格式异常';
                if (strpos($target, '@') !== false) {
                    list($controller, $action) = explode('@', $target, 2);
                    $class = 'App\\Controllers\\' . $controller;
                    $ok = class_exists($class) && method_exists($class, $action);
                    $hint = $ok ? $class . '::' . $action : '控制器或方法不存在：' . $class . '::' . $action;
                }
                $items[] = [
                    'method' => $method,
                    'path' => $path,
                    'target' => $target,
                    'ok' => $ok,
                    'hint' => $hint,
                ];
            }
        }
        usort($items, function ($a, $b) {
            if ($a['ok'] === $b['ok']) {
                return strcmp($a['method'] . $a['path'], $b['method'] . $b['path']);
            }
            return $a['ok'] ? 1 : -1;
        });
        return $items;
    }

    protected function auditViewForms()
    {
        $routes = $this->routerRoutes();
        $items = [];
        foreach ($this->viewFiles() as $file) {
            $source = @file_get_contents($file);
            if ($source === false || stripos($source, '<form') === false) {
                continue;
            }
            if (!preg_match_all('/<form\b/i', $source, $forms, PREG_OFFSET_CAPTURE)) {
                continue;
            }
            foreach ($forms[0] as $formMatch) {
                $chunk = substr($source, $formMatch[1], 900);
                if (!preg_match('/action\s*=\s*([\'"])[\s\S]{0,320}?url\(\s*([\'"])([^\'"]+)\2\s*\)[\s\S]{0,80}?\1/i', $chunk, $actionMatch)) {
                    continue;
                }
                $method = 'GET';
                if (preg_match('/method\s*=\s*([\'"])([^\'"]+)\1/i', $chunk, $methodMatch)) {
                    $method = strtoupper($methodMatch[2]);
                }
                if (!in_array($method, ['GET', 'POST'], true)) {
                    $method = 'GET';
                }
                $path = $this->normalizeAuditPath($actionMatch[3]);
                $ok = isset($routes[$method][$path]);
                $items[] = [
                    'file' => $this->relativePath($file),
                    'method' => $method,
                    'path' => $path,
                    'ok' => $ok,
                    'hint' => $ok ? '表单提交路由正常' : '缺少 ' . $method . ' 路由',
                ];
            }
        }
        usort($items, function ($a, $b) {
            if ($a['ok'] === $b['ok']) {
                return strcmp($a['file'] . $a['path'], $b['file'] . $b['path']);
            }
            return $a['ok'] ? 1 : -1;
        });
        return $items;
    }

    protected function auditResponsiveTables()
    {
        $items = [];
        $responsiveHints = ['table-wrap', 'bm-responsive-table', 'admin-responsive-table', 'server-admin-table', 'bm-record-list', 'bm-monitor-list', 'bm-alert-list'];
        foreach ($this->viewFiles() as $file) {
            $source = @file_get_contents($file);
            if ($source === false || stripos($source, '<table') === false) {
                continue;
            }
            $tableCount = preg_match_all('/<table\b/i', $source, $unused);
            $hasResponsiveHint = false;
            foreach ($responsiveHints as $hint) {
                if (strpos($source, $hint) !== false) {
                    $hasResponsiveHint = true;
                    break;
                }
            }
            $items[] = [
                'file' => $this->relativePath($file),
                'tables' => (int) $tableCount,
                'ok' => $hasResponsiveHint,
                'hint' => $hasResponsiveHint ? '已包含响应式表格/卡片容器' : '表格可能在手机端横向溢出',
            ];
        }
        usort($items, function ($a, $b) {
            if ($a['ok'] === $b['ok']) {
                return strcmp($a['file'], $b['file']);
            }
            return $a['ok'] ? 1 : -1;
        });
        return $items;
    }

    protected function auditFrontendAssets()
    {
        $items = [];
        foreach (['app/Views/layouts/app.php', 'app/Views/layouts/admin.php', 'app/Views/layouts/auth.php', 'app/Views/layouts/install.php', 'app/Views/layouts/status.php'] as $layout) {
            $file = APP_ROOT . '/' . $layout;
            if (!is_file($file)) {
                continue;
            }
            $source = @file_get_contents($file);
            if ($source === false) {
                continue;
            }
            if (!preg_match_all('/asset\(\s*([\'"])([^\'"]+)\1\s*\)/', $source, $matches, PREG_SET_ORDER)) {
                continue;
            }
            foreach ($matches as $match) {
                $asset = ltrim($match[2], '/');
                $assetPath = APP_ROOT . '/public/assets/' . $asset;
                $exists = is_file($assetPath);
                $items[] = [
                    'file' => $layout,
                    'asset' => $asset,
                    'ok' => $exists,
                    'size' => $exists ? filesize($assetPath) : 0,
                    'hint' => $exists ? '资源文件存在' : '资源文件缺失，页面样式或脚本可能失效',
                ];
            }
        }
        $unique = [];
        foreach ($items as $item) {
            $unique[$item['file'] . '|' . $item['asset']] = $item;
        }
        return array_values($unique);
    }

    protected function viewFiles()
    {
        $base = APP_ROOT . '/app/Views';
        $files = [];
        if (!is_dir($base)) {
            return $files;
        }
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
                $files[] = $file->getPathname();
            }
        }
        sort($files);
        return $files;
    }

    protected function normalizeAuditPath($raw)
    {
        $raw = trim((string) $raw);
        $raw = preg_replace('/[?#].*$/', '', $raw);
        if ($raw === '' || $raw === '/') {
            return '/';
        }
        return '/' . trim($raw, '/');
    }

    protected function relativePath($path)
    {
        $path = str_replace('\\', '/', (string) $path);
        $root = str_replace('\\', '/', APP_ROOT) . '/';
        return strpos($path, $root) === 0 ? substr($path, strlen($root)) : $path;
    }

    protected function serverCommandCount($serverId, $where = '')
    {
        $conditions = ['server_id = ' . (int) $serverId];
        if ($where !== '') {
            $conditions[] = $where;
        }
        return $this->safeCount('server_command_logs', implode(' AND ', $conditions));
    }

    protected function safeUserServerSessionCount($where = '')
    {
        try {
            $conditions = ["s.monitor_type IN ('ssh','agent')"];
            if ($where !== '') {
                $conditions[] = $where;
            }
            $row = Database::fetch(
                'SELECT COUNT(*) AS c FROM ' . Database::table('server_ssh_sessions') . ' ss
                 INNER JOIN ' . Database::table('monitor_servers') . ' s ON ss.server_id = s.id
                 WHERE ' . implode(' AND ', $conditions)
            );
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function safeUserServerCommandLogCount($where = '')
    {
        try {
            $conditions = ["s.monitor_type IN ('ssh','agent')"];
            if ($where !== '') {
                $conditions[] = $where;
            }
            $row = Database::fetch(
                'SELECT COUNT(*) AS c FROM ' . Database::table('server_command_logs') . ' cl
                 INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
                 WHERE ' . implode(' AND ', $conditions)
            );
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function userStats()
    {
        try {
            $storage = Database::fetch('SELECT COALESCE(SUM(used_storage),0) AS used, COALESCE(SUM(total_storage),0) AS total FROM ' . Database::table('users'));
            return [
                'total' => $this->count('users'),
                'enabled' => $this->count('users', 'status = 1'),
                'disabled' => $this->count('users', 'status = 0'),
                'admins' => $this->count('users', "role = 'admin'"),
                'today' => $this->count('users', 'DATE(created_at) = CURDATE()'),
                'storage_used' => $storage ? (int) $storage['used'] : 0,
                'storage_total' => $storage ? (int) $storage['total'] : 0,
            ];
        } catch (\Throwable $e) {
            return ['total' => 0, 'enabled' => 0, 'disabled' => 0, 'admins' => 0, 'today' => 0, 'storage_used' => 0, 'storage_total' => 0];
        }
    }

    protected function adminPackageById($id)
    {
        $id = (int) $id;
        if ($id <= 0) {
            return null;
        }
        try {
            return Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$id]);
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function adminUserQuotaPayload($package, $syncPackageLimits, array $existing = null)
    {
        $fallbackStorage = $existing && isset($existing['total_storage']) ? (int) $existing['total_storage'] : 0;
        $fallbackTraffic = $existing && isset($existing['total_traffic']) ? (int) $existing['total_traffic'] : 0;
        if ($syncPackageLimits) {
            $storage = $package ? (int) $package['storage_limit'] : 0;
            $traffic = $package ? (int) $package['traffic_limit'] : 0;
            $expire = $this->adminPackageExpire($package);
        } else {
            $storage = $this->postedPositiveBytes('total_storage', $fallbackStorage);
            $traffic = $this->postedPositiveBytes('total_traffic', $fallbackTraffic);
            $expireInput = trim((string) (isset($_POST['package_expire_time']) ? $_POST['package_expire_time'] : ''));
            $expire = $expireInput !== '' ? $this->normalizeDateTime($expireInput) : null;
        }
        return [
            'total_storage' => max(0, (int) $storage),
            'total_traffic' => max(0, (int) $traffic),
            'package_expire_time' => $expire,
        ];
    }

    protected function adminPackageExpire($package)
    {
        if (!$package || !isset($package['duration_type']) || $package['duration_type'] === 'forever') {
            return null;
        }
        $days = isset($package['duration_days']) ? (int) $package['duration_days'] : 0;
        if ($days <= 0) {
            return null;
        }
        return date('Y-m-d H:i:s', time() + ($days * 86400));
    }

    protected function postedPositiveBytes($field, $fallback)
    {
        if (!isset($_POST[$field]) || trim((string) $_POST[$field]) === '') {
            return max(0, (int) $fallback);
        }
        return max(0, (int) $_POST[$field]);
    }

    protected function failUserForm($message, $anchor = '')
    {
        remember_old();
        set_flash('error', $message);
        $this->redirect('admin/users' . $anchor);
    }

    protected function settingsMap()
    {
        $settings = [];
        foreach (Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings')) as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    }

    protected function settingsSections($active = 'all')
    {
        return [
            ['key' => 'site', 'label' => '站点信息', 'path' => 'admin/settings/site', 'active' => $active === 'site'],
            ['key' => 'security', 'label' => '安全与注册', 'path' => 'admin/settings/security', 'active' => $active === 'security'],
            ['key' => 'upload', 'label' => '上传权限', 'path' => 'admin/settings/upload', 'active' => $active === 'upload'],
            ['key' => 'api', 'label' => 'API 限制', 'path' => 'admin/settings/api', 'active' => $active === 'api'],
            ['key' => 'email', 'label' => '邮件服务', 'path' => 'admin/settings/email', 'active' => $active === 'email'],
            ['key' => 'themes', 'label' => '界面主题', 'path' => 'admin/themes', 'active' => $active === 'themes'],
            ['key' => 'maintenance', 'label' => '系统维护', 'path' => 'admin/maintenance', 'active' => $active === 'maintenance'],
        ];
    }

    protected function themeStyle($value)
    {
        $value = (string) $value;
        return $value === 'anime' ? 'anime' : 'anime';
    }

    protected function frontendHomeStyle($value)
    {
        $value = (string) $value;
        return in_array($value, ['default', 'terminal', 'technology', 'anime', 'business', 'blog'], true) ? $value : 'default';
    }

    protected function themeMode($value)
    {
        $value = (string) $value;
        return in_array($value, ['auto', 'light', 'dark'], true) ? $value : 'auto';
    }

    protected function schemaHealthChecks(array $schemaAudit)
    {
        $expected = isset($schemaAudit['expected_table_count']) ? (int) $schemaAudit['expected_table_count'] : 0;
        $existing = isset($schemaAudit['existing_table_count']) ? (int) $schemaAudit['existing_table_count'] : 0;
        $missingTables = isset($schemaAudit['missing_table_count']) ? (int) $schemaAudit['missing_table_count'] : 0;
        $missingColumns = isset($schemaAudit['missing_column_count']) ? (int) $schemaAudit['missing_column_count'] : 0;
        $codeMissingTables = isset($schemaAudit['code_missing_table_count']) ? (int) $schemaAudit['code_missing_table_count'] : 0;
        return [
            [
                'label' => '数据表覆盖',
                'ok' => $missingTables === 0,
                'value' => $existing . ' / ' . $expected,
                'hint' => $missingTables === 0 ? '核心数据表已覆盖当前程序。' : '存在缺失数据表，请执行数据库巡检修复。',
                'action_url' => 'admin/maintenance/schema-audit',
                'action_label' => '数据库巡检',
            ],
            [
                'label' => '字段结构',
                'ok' => $missingColumns === 0,
                'value' => $missingColumns,
                'hint' => $missingColumns === 0 ? '数据字段已匹配。' : '存在缺失字段，请执行数据库巡检修复。',
                'action_url' => 'admin/maintenance/schema-audit',
                'action_label' => '查看字段',
            ],
            [
                'label' => '代码引用表',
                'ok' => $codeMissingTables === 0,
                'value' => $codeMissingTables,
                'hint' => $codeMissingTables === 0 ? '程序直接引用的数据表均存在。' : '有功能引用的数据表不存在，请点击一键修复。',
                'action_url' => 'admin/feature-audit',
                'action_label' => '重新巡检',
            ],
        ];
    }

    protected function auditSecurityPosture()
    {
        $rootHtaccess = APP_ROOT . '/.htaccess';
        $uploadHtaccess = APP_ROOT . '/public/uploads/.htaccess';
        $nginxGuard = APP_ROOT . '/bt-nginx-rewrite.conf';
        $fileService = APP_ROOT . '/app/Services/FileService.php';
        $rootRules = is_file($rootHtaccess) ? (string) file_get_contents($rootHtaccess) : '';
        $uploadRules = is_file($uploadHtaccess) ? (string) file_get_contents($uploadHtaccess) : '';
        $nginxRules = is_file($nginxGuard) ? (string) file_get_contents($nginxGuard) : '';
        $fileServiceSource = is_file($fileService) ? (string) file_get_contents($fileService) : '';
        $secret = (string) \App\Core\Config::get('app.security.secret_key', '');
        $databaseConfigReady = is_file(APP_ROOT . '/config/database.php');
        $installLocked = is_file(APP_ROOT . '/storage/install.lock');

        return [
            [
                'label' => '安装锁',
                'ok' => $installLocked,
                'value' => $installLocked ? '已锁定' : '未锁定',
                'hint' => $installLocked ? '安装入口已锁定。' : '请创建 storage/install.lock，避免重复安装。',
            ],
            [
                'label' => '数据库配置',
                'ok' => $databaseConfigReady,
                'value' => $databaseConfigReady ? '已生成' : '未生成',
                'hint' => $databaseConfigReady ? '数据库配置文件存在。' : '请先完成安装生成 config/database.php。',
            ],
            [
                'label' => '运行调试',
                'ok' => !(defined('APP_DEBUG') && APP_DEBUG),
                'value' => defined('APP_DEBUG') && APP_DEBUG ? '已开启' : '已关闭',
                'hint' => defined('APP_DEBUG') && APP_DEBUG ? '生产环境建议关闭 APP_DEBUG。' : '生产环境错误不会直接暴露堆栈。',
            ],
            [
                'label' => '核心目录保护',
                'ok' => strpos($rootRules, 'app|config|database|storage|vendor') !== false || strpos($nginxRules, 'app|config|database|storage|vendor') !== false,
                'value' => strpos($rootRules, 'app|config|database|storage|vendor') !== false || strpos($nginxRules, 'app|config|database|storage|vendor') !== false ? '已配置' : '未检测到',
                'hint' => '建议禁止 Web 直接访问 app、config、database、storage、vendor 目录。',
            ],
            [
                'label' => '上传脚本防护',
                'ok' => (stripos($uploadRules, 'php_flag engine off') !== false || stripos($uploadRules, 'Require all denied') !== false) && stripos($rootRules . $nginxRules, 'uploads') !== false,
                'value' => (stripos($uploadRules, 'php_flag engine off') !== false || stripos($uploadRules, 'Require all denied') !== false) ? '已配置' : '需检查',
                'hint' => '防止上传目录内脚本被 Web 服务执行。',
            ],
            [
                'label' => '上传内容拦截',
                'ok' => strpos($fileServiceSource, 'assertSafeExtension') !== false && strpos($fileServiceSource, 'image/svg+xml') !== false,
                'value' => strpos($fileServiceSource, 'assertSafeExtension') !== false ? '已启用' : '未启用',
                'hint' => '服务层会拦截脚本、网页、SVG、可执行文件等高风险上传。',
            ],
            [
                'label' => '加密密钥',
                'ok' => $secret !== '' && ($secret !== 'bm-tools-change-this-secret-key' || $databaseConfigReady),
                'value' => $secret === 'bm-tools-change-this-secret-key' ? '安装配置派生' : '独立密钥',
                'hint' => $secret === 'bm-tools-change-this-secret-key' ? '安装后会使用数据库配置派生密钥；迁移站点时请保留 config/database.php。' : '敏感配置使用独立密钥加密。',
            ],
        ];
    }

    protected function featureDiagnosticCards(array $schemaChecks, array $environmentChecks, array $securityChecks, array $serviceChecks, array $directoryChecks, array $uploadChecks = [])
    {
        $storageOk = $this->namedCheckOk($serviceChecks, '默认存储源') && $this->namedCheckOk($serviceChecks, '可用存储源') && $this->namedCheckOk($directoryChecks, '本地上传目录');
        if ($uploadChecks) {
            $storageOk = $storageOk && $this->checksAllOk($uploadChecks);
        }
        $monitorOk = $this->namedCheckOk($serviceChecks, '监控采集链接');
        $sshOk = $this->namedCheckOk($serviceChecks, 'SSH 运维能力');
        return [
            [
                'title' => '数据结构',
                'status' => $this->checksAllOk($schemaChecks) ? 'ok' : 'bad',
                'desc' => $this->checksAllOk($schemaChecks) ? '表和字段已匹配当前程序。' : '存在缺表或缺字段，部分页面会提示表结构未准备完成。',
                'action_url' => 'admin/maintenance/schema-audit',
                'action_label' => '数据库巡检',
            ],
            [
                'title' => '上传链路',
                'status' => $storageOk ? 'ok' : 'bad',
                'desc' => $storageOk ? '上传链路具备基础运行条件。' : 'PHP 上传入口、临时目录、默认存储或厂商基础配置存在阻断。',
                'action_url' => 'admin/feature-audit#upload-runtime-checks',
                'action_label' => '查看上传链路',
            ],
            [
                'title' => '安全基线',
                'status' => $this->checksAllOk($securityChecks) ? 'ok' : 'warn',
                'desc' => $this->checksAllOk($securityChecks) ? '安装锁、目录保护和上传防护已就绪。' : '建议检查安装锁、上传目录规则和调试开关。',
                'action_url' => 'admin/settings/security',
                'action_label' => '安全设置',
            ],
            [
                'title' => '运行环境',
                'status' => $this->checksAllOk($environmentChecks) ? 'ok' : 'warn',
                'desc' => $this->checksAllOk($environmentChecks) ? 'PHP 扩展和目录权限满足主要功能。' : '有扩展或目录权限未满足，会影响更新、上传、邮件或远程连接。',
                'action_url' => 'admin/maintenance/environment',
                'action_label' => '环境信息',
            ],
            [
                'title' => '监控采集',
                'status' => $monitorOk ? 'ok' : 'warn',
                'desc' => $monitorOk ? '计划任务采集链接已可复制使用。' : '尚未生成采集 Token，请先进入监控管理页初始化。',
                'action_url' => 'admin/monitors',
                'action_label' => '监控管理',
            ],
            [
                'title' => 'SSH 运维',
                'status' => $sshOk ? 'ok' : 'warn',
                'desc' => $sshOk ? '在线终端具备基础连接能力或已关闭。' : '缺少 phpseclib/ssh2，建议安装依赖或使用 Agent 模式。',
                'action_url' => 'admin/server-ops/settings',
                'action_label' => '运维设置',
            ],
        ];
    }

    protected function checksAllOk(array $checks)
    {
        foreach ($checks as $check) {
            if (empty($check['ok'])) {
                return false;
            }
        }
        return true;
    }

    protected function namedCheckOk(array $checks, $label)
    {
        foreach ($checks as $check) {
            if (isset($check['label']) && $check['label'] === $label) {
                return !empty($check['ok']);
            }
        }
        return false;
    }

    protected function environmentChecks()
    {
        return [
            ['name' => 'PHP Version', 'value' => PHP_VERSION, 'ok' => version_compare(PHP_VERSION, '7.4.0', '>=')],
            ['name' => 'PDO', 'value' => extension_loaded('pdo') ? 'enabled' : 'disabled', 'ok' => extension_loaded('pdo')],
            ['name' => 'cURL', 'value' => extension_loaded('curl') ? 'enabled' : 'disabled', 'ok' => extension_loaded('curl')],
            ['name' => 'OpenSSL', 'value' => extension_loaded('openssl') ? 'enabled' : 'disabled', 'ok' => extension_loaded('openssl')],
            ['name' => 'Fileinfo', 'value' => extension_loaded('fileinfo') ? 'enabled' : 'disabled', 'ok' => extension_loaded('fileinfo')],
            ['name' => 'ZipArchive', 'value' => class_exists('ZipArchive') ? 'enabled' : 'disabled, online update install needs it', 'ok' => class_exists('ZipArchive')],
            ['name' => 'storage writable', 'value' => is_writable(APP_ROOT . '/storage') ? 'writable' : 'not writable', 'ok' => is_writable(APP_ROOT . '/storage')],
            ['name' => 'public/uploads writable', 'value' => is_writable(APP_ROOT . '/public/uploads') ? 'writable' : 'not writable', 'ok' => is_writable(APP_ROOT . '/public/uploads')],
        ];
    }

    protected function uploadRuntimeChecks()
    {
        $checks = [];
        $defaultStorage = null;
        $enabledStorageCount = 0;
        $storageLoadError = '';

        try {
            $defaultStorage = Database::fetch('SELECT * FROM ' . Database::table('storage_drivers') . ' WHERE is_enabled = 1 AND is_default = 1 LIMIT 1');
            if (!$defaultStorage) {
                $defaultStorage = Database::fetch('SELECT * FROM ' . Database::table('storage_drivers') . ' WHERE is_enabled = 1 ORDER BY id ASC LIMIT 1');
            }
            $enabledStorageCount = $this->safeCount('storage_drivers', 'is_enabled = 1');
        } catch (\Throwable $e) {
            $storageLoadError = $e->getMessage();
        }

        $defaultType = $defaultStorage && isset($defaultStorage['type']) ? (string) $defaultStorage['type'] : '';
        $requiresCurl = $defaultStorage && $defaultType !== 'local';
        $requiresCurlFile = $defaultStorage && in_array($defaultType, ['kodo', 'bmtools'], true);

        $fileUploadsRaw = ini_get('file_uploads');
        $fileUploadsOk = $this->iniSwitchEnabled($fileUploadsRaw);
        $checks[] = $this->uploadRuntimeCheck(
            'php_uploads',
            'PHP 文件上传',
            $fileUploadsOk ? '已启用' : '未启用',
            $fileUploadsOk,
            $fileUploadsOk ? 'PHP file_uploads 已开启，浏览器上传入口可用。' : '请在 php.ini 开启 file_uploads，否则所有上传都会被 PHP 拦截。',
            'PHP 上传入口',
            'admin/upload-limits',
            '上传限制'
        );

        $uploadMax = ini_get('upload_max_filesize') ?: '';
        $postMax = ini_get('post_max_size') ?: '';
        $uploadBytes = $this->iniBytes($uploadMax);
        $postBytes = $this->iniBytes($postMax);
        $postOk = $postBytes <= 0 || $uploadBytes <= 0 || $postBytes >= $uploadBytes;
        $checks[] = $this->uploadRuntimeCheck(
            'post_size',
            'POST 总量',
            ($postMax !== '' ? $postMax : '-') . ' / 单文件 ' . ($uploadMax !== '' ? $uploadMax : '-'),
            $postOk,
            $postOk ? 'post_max_size 不小于 upload_max_filesize，批量上传不会先被 POST 总量截断。' : 'post_max_size 小于 upload_max_filesize，大文件会在进入业务代码前被截断。',
            'PHP 限制',
            'admin/upload-limits',
            '调整限制'
        );

        $maxFiles = (int) ini_get('max_file_uploads');
        $checks[] = $this->uploadRuntimeCheck(
            'max_file_uploads',
            '批量文件数量',
            $maxFiles > 0 ? (string) $maxFiles : '未限制',
            $maxFiles !== 0,
            $maxFiles !== 0 ? 'PHP 允许表单携带文件，批量上传数量还会受后台上传限制控制。' : 'max_file_uploads 为 0 会导致批量上传不可用，请调大到 20 或以上。',
            'PHP 限制',
            'admin/upload-limits',
            '上传限制'
        );

        $tmpIni = trim((string) ini_get('upload_tmp_dir'));
        $tmpDir = $tmpIni !== '' ? $tmpIni : sys_get_temp_dir();
        $tmpOk = $tmpDir !== '' && is_dir($tmpDir) && is_writable($tmpDir);
        $checks[] = $this->uploadRuntimeCheck(
            'upload_tmp_dir',
            '上传临时目录',
            $tmpDir !== '' ? $tmpDir : '未设置',
            $tmpOk,
            $tmpOk ? ($tmpIni !== '' ? 'PHP 上传临时目录存在且可写。' : 'upload_tmp_dir 未单独设置，当前系统临时目录可写。') : 'PHP 临时目录不可写或不存在，文件会在业务处理前失败。',
            '临时目录',
            'admin/maintenance/environment',
            '环境信息'
        );

        $memoryLimit = ini_get('memory_limit') ?: '';
        $memoryBytes = $this->iniBytes($memoryLimit);
        $memoryOk = $memoryBytes < 0 || $memoryBytes === 0 || $uploadBytes <= 0 || $memoryBytes >= min($uploadBytes, 32 * 1024 * 1024);
        $checks[] = $this->uploadRuntimeCheck(
            'memory_limit',
            'PHP 内存限制',
            $memoryLimit !== '' ? $memoryLimit : '未设置',
            $memoryOk,
            $memoryOk ? '对象存储已改为流式上传，内存压力较低。' : 'memory_limit 过低，图片识别、MD5 或插件处理时可能触发 500。',
            'PHP 限制',
            'admin/maintenance/environment',
            '环境信息'
        );

        $checks[] = $this->uploadRuntimeCheck(
            'curl',
            'cURL 扩展',
            function_exists('curl_init') ? '已启用' : '未启用',
            !$requiresCurl || function_exists('curl_init'),
            !$requiresCurl ? '当前默认存储不强制依赖 cURL。' : (function_exists('curl_init') ? '默认对象存储需要 cURL，当前已启用。' : '默认对象存储需要 cURL，请先启用 PHP curl 扩展。'),
            '对象存储',
            'admin/maintenance/environment',
            '环境信息'
        );

        $checks[] = $this->uploadRuntimeCheck(
            'curl_file',
            'CURLFile 能力',
            class_exists('\CURLFile') ? '可用' : '不可用',
            !$requiresCurlFile || class_exists('\CURLFile'),
            !$requiresCurlFile ? '当前默认存储不需要 CURLFile 表单上传。' : (class_exists('\CURLFile') ? '七牛云 Kodo 或同系统对接所需 CURLFile 可用。' : '七牛云 Kodo 或同系统对接需要 CURLFile，请升级或启用 PHP curl。'),
            '对象存储',
            'admin/maintenance/environment',
            '环境信息'
        );

        $secretEncrypted = $defaultStorage && !empty($defaultStorage['secret_key']) && strpos((string) $defaultStorage['secret_key'], 'enc:') === 0;
        $checks[] = $this->uploadRuntimeCheck(
            'openssl',
            'OpenSSL 解密',
            function_exists('openssl_decrypt') ? '已启用' : '未启用',
            !$secretEncrypted || function_exists('openssl_decrypt'),
            !$secretEncrypted ? '默认存储密钥未处于必须解密的状态。' : (function_exists('openssl_decrypt') ? '默认存储密钥可正常解密。' : '默认存储密钥已加密，但 PHP 缺少 OpenSSL，无法读取 SecretKey。'),
            '密钥读取',
            'admin/maintenance/environment',
            '环境信息'
        );

        $uploadsDir = APP_ROOT . '/public/uploads';
        $checks[] = $this->uploadRuntimeCheck(
            'public_uploads',
            '本地上传目录',
            is_dir($uploadsDir) ? (is_writable($uploadsDir) ? '可写' : '不可写') : '不存在',
            is_dir($uploadsDir) && is_writable($uploadsDir),
            is_dir($uploadsDir) && is_writable($uploadsDir) ? '本地存储、缩略图和上传保护文件可正常写入。' : '请创建 public/uploads 并赋予 Web 用户写入权限。',
            '目录权限',
            'admin/maintenance/environment',
            '环境信息'
        );

        $lockDir = APP_ROOT . '/storage/upload_locks';
        $lockParentOk = is_dir(APP_ROOT . '/storage') && is_writable(APP_ROOT . '/storage');
        $lockOk = (is_dir($lockDir) && is_writable($lockDir)) || (!is_dir($lockDir) && $lockParentOk);
        $checks[] = $this->uploadRuntimeCheck(
            'upload_locks',
            '上传限流锁目录',
            is_dir($lockDir) ? (is_writable($lockDir) ? '可写' : '不可写') : ($lockParentOk ? '可自动创建' : '不可创建'),
            $lockOk,
            $lockOk ? '上传并发和每日限制所需锁目录具备运行条件。' : 'storage/upload_locks 不可写，批量上传并发限制会失效。',
            '上传限流',
            'admin/upload-limits',
            '上传限制'
        );

        if ($storageLoadError !== '') {
            $checks[] = $this->uploadRuntimeCheck(
                'default_storage',
                '默认存储',
                '读取失败',
                false,
                '读取 storage_drivers 失败：' . $storageLoadError . '。请先执行数据库一键修复。',
                '存储配置',
                'admin/feature-audit',
                '重新巡检',
            );
            return $checks;
        }

        $checks[] = $this->uploadRuntimeCheck(
            'enabled_storage',
            '启用存储数量',
            (string) $enabledStorageCount,
            $enabledStorageCount > 0,
            $enabledStorageCount > 0 ? '至少存在一个启用的存储源。' : '请先在资源功能管理新增并启用一个存储源。',
            '存储配置',
            'admin/storages',
            '配置存储'
        );

        if (!$defaultStorage) {
            $checks[] = $this->uploadRuntimeCheck(
                'default_storage',
                '默认存储',
                '未配置',
                false,
                '未找到可用默认存储，请先启用一个存储源并设置为默认。',
                '存储配置',
                'admin/storages',
                '配置存储'
            );
            return $checks;
        }

        $storageValue = (isset($defaultStorage['name']) ? $defaultStorage['name'] : '未命名') . ' / ' . strtoupper($defaultType ?: 'unknown');
        $storageOk = true;
        $storageHint = '默认存储基础配置完整。建议在资源功能管理点击“真实测试”，确认上传、访问链接和删除权限。';

        try {
            if ($defaultType === 'bmtools') {
                if (empty($defaultStorage['endpoint']) || empty($defaultStorage['secret_key'])) {
                    $storageOk = false;
                    $storageHint = '同系统对接需要远端站点地址和对接 Token。';
                }
            } else {
                $driver = StorageManager::make($defaultStorage);
                $test = method_exists($driver, 'test') ? $driver->test() : ['success' => true, 'message' => '驱动未提供基础测试。'];
                $storageOk = !empty($test['success']);
                $storageHint = isset($test['message']) ? $test['message'] : $storageHint;
            }
        } catch (\Throwable $e) {
            $storageOk = false;
            $storageHint = $e->getMessage();
        }

        $checks[] = $this->uploadRuntimeCheck(
            'default_storage',
            '默认存储',
            $storageValue,
            $storageOk,
            $storageHint,
            '存储配置',
            $defaultType === 'bmtools' ? 'admin/storage-integrations' : 'admin/storages',
            '真实测试'
        );

        return $checks;
    }

    protected function uploadRuntimeCheck($key, $label, $value, $ok, $hint, $stage, $actionUrl = '', $actionLabel = '')
    {
        return [
            'key' => $key,
            'label' => $label,
            'name' => $label,
            'value' => (string) $value,
            'ok' => (bool) $ok,
            'hint' => (string) $hint,
            'stage' => (string) $stage,
            'action_url' => (string) $actionUrl,
            'action_label' => (string) $actionLabel,
        ];
    }

    protected function iniSwitchEnabled($value)
    {
        $value = strtolower(trim((string) $value));
        return !in_array($value, ['', '0', 'off', 'false', 'no'], true);
    }

    protected function databaseVersion()
    {
        try {
            $db = Database::fetch('SELECT VERSION() AS version');
            return $db ? $db['version'] : 'unknown';
        } catch (\Throwable $e) {
            return 'read failed';
        }
    }

    protected function saveSettingValue($key, $value)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('settings') . ' (setting_key, setting_value, created_at, updated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
            [$key, $value, now(), now()]
        );
    }

    protected function saveSettingsValues(array $keys, $redirect)
    {
        $existingSettings = [];
        foreach (Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings')) as $row) {
            $existingSettings[$row['setting_key']] = $row['setting_value'];
        }
        foreach ($keys as $key) {
            if (!array_key_exists($key, $_POST)) {
                continue;
            }
            $value = $_POST[$key];
            if ($key === 'email_password') {
                $value = trim((string) $value);
                if ($value === '' && array_key_exists($key, $existingSettings)) {
                    $value = $existingSettings[$key];
                } elseif ($value !== '') {
                    $value = CryptoService::encrypt($value);
                }
            }
            if ($key === 'site_public_url') {
                $value = trim((string) $value);
                if ($value !== '' && !preg_match('#^https?://#i', $value)) {
                    $value = 'https://' . $value;
                }
                $value = rtrim($value, '/');
            }
            if (in_array($key, ['guest_image_upload_user_id', 'guest_image_upload_max_size', 'guest_image_upload_daily_ip_limit', 'security_login_max_attempts', 'security_login_window_minutes', 'security_login_lock_minutes', 'security_email_code_max_per_hour', 'security_email_code_ip_max_per_hour', 'default_free_package_id', 'api_rate_limit_per_minute', 'api_rate_limit_per_day', 'email_port'], true)) {
                $value = (string) max(0, (int) $value);
            }
            Database::execute(
                'INSERT INTO ' . Database::table('settings') . ' (setting_key, setting_value, created_at, updated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
                [$key, $value, now(), now()]
            );
        }
        $this->adminLog('保存系统设置', 'setting', null);
        set_flash('success', '系统设置已保存。');
        $this->redirect($redirect);
    }

    protected function permissionOverride($value)
    {
        $value = (int) $value;
        return in_array($value, [-1, 0, 1], true) ? $value : -1;
    }

    protected function normalizeApiAllowedIps($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $parts = preg_split('/[\s,;]+/', $value);
        $ips = [];
        foreach ($parts as $ip) {
            $ip = trim($ip);
            if ($ip === '') {
                continue;
            }
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                return false;
            }
            $ips[$ip] = true;
        }
        return implode("\n", array_keys($ips));
    }

    protected function isCurrentSiteEndpoint($endpoint)
    {
        $host = parse_url($endpoint, PHP_URL_HOST);
        if (!$host) {
            return false;
        }
        $current = !empty($_SERVER['HTTP_HOST']) ? parse_url('https://' . $_SERVER['HTTP_HOST'], PHP_URL_HOST) : '';
        if ($current && strtolower($host) === strtolower($current)) {
            return true;
        }
        $publicHost = parse_url(public_url('/'), PHP_URL_HOST);
        return $publicHost && strtolower($host) === strtolower($publicHost);
    }

    protected function quoteIdentifier($name)
    {
        return '`' . str_replace('`', '``', $name) . '`';
    }

    protected function dashboardRevenueTrend($days = 7)
    {
        $days = max(1, (int) $days);
        $interval = max(0, $days - 1);
        $orderRows = Database::fetchAll(
            "SELECT DATE(created_at) AS day, COALESCE(SUM(pay_amount),0) AS total, COUNT(*) AS orders_count
             FROM " . Database::table('orders') . "
             WHERE status = 'paid' AND created_at >= DATE_SUB(CURDATE(), INTERVAL {$interval} DAY)
             GROUP BY DATE(created_at)
             ORDER BY day ASC"
        );
        $rechargeRows = Database::fetchAll(
            "SELECT DATE(paid_at) AS day, COALESCE(SUM(amount),0) AS total, COUNT(*) AS recharge_count
             FROM " . Database::table('recharges') . "
             WHERE status = 'paid' AND paid_at IS NOT NULL AND paid_at >= DATE_SUB(CURDATE(), INTERVAL {$interval} DAY)
             GROUP BY DATE(paid_at)
             ORDER BY day ASC"
        );
        $days = [];
        for ($i = $interval; $i >= 0; $i--) {
            $days[date('Y-m-d', strtotime('-' . $i . ' day'))] = [
                'day' => date('m/d', strtotime('-' . $i . ' day')),
                'orders_total' => 0,
                'recharge_total' => 0,
                'orders_count' => 0,
                'recharge_count' => 0,
            ];
        }
        foreach ($orderRows as $row) {
            if (isset($days[$row['day']])) {
                $days[$row['day']]['orders_total'] = (float) $row['total'];
                $days[$row['day']]['orders_count'] = (int) $row['orders_count'];
            }
        }
        foreach ($rechargeRows as $row) {
            if (isset($days[$row['day']])) {
                $days[$row['day']]['recharge_total'] = (float) $row['total'];
                $days[$row['day']]['recharge_count'] = (int) $row['recharge_count'];
            }
        }
        return array_values($days);
    }

    protected function dashboardRecentOrders()
    {
        return Database::fetchAll(
            'SELECT o.*, u.username, u.nickname, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC LIMIT 8'
        );
    }

    protected function dashboardPendingRecharges()
    {
        return Database::fetchAll(
            'SELECT r.*, u.username, o.order_no FROM ' . Database::table('recharges') . ' r LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id LEFT JOIN ' . Database::table('orders') . ' o ON r.order_id = o.id WHERE r.status = \'pending\' ORDER BY r.id DESC LIMIT 8'
        );
    }

    protected function dashboardOpsTodos()
    {
        $storages = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('storage_drivers') . ' WHERE is_default = 1 AND is_enabled = 1');
        $pendingRecharge = $this->count('recharges', "status = 'pending'");
        $pendingOrders = $this->count('orders', "status = 'pending'");
        $offlineServers = $this->count('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'");
        $packageExpiring = $this->safeCount('users', 'status = 1 AND package_expire_time IS NOT NULL AND package_expire_time >= NOW() AND package_expire_time < DATE_ADD(NOW(), INTERVAL 7 DAY)');
        $slaRisk = (new SlaReportService())->riskSummary(7);
        return [
            'default_storage' => $storages ? (int) $storages['c'] : 0,
            'pending_recharge' => $pendingRecharge,
            'pending_orders' => $pendingOrders,
            'offline_servers' => $offlineServers,
            'package_expiring' => $packageExpiring,
            'sla_below_99' => isset($slaRisk['below_99']) ? (int) $slaRisk['below_99'] : 0,
            'sla_no_data' => isset($slaRisk['no_data']) ? (int) $slaRisk['no_data'] : 0,
            'sla_collect_delayed' => isset($slaRisk['collect_delayed']) ? (int) $slaRisk['collect_delayed'] : 0,
        ];
    }

    protected function dashboardOpsAlerts()
    {
        $alerts = [];
        $schemaOk = true;
        try {
            $schemaOk = DatabaseUpgradeService::standardSchemaReady();
        } catch (\Throwable $e) {
            $schemaOk = false;
        }
        if (!$schemaOk) {
            $alerts[] = [
                'level' => 'danger',
                'icon' => 'database-zap',
                'title' => '数据库结构未完成',
                'desc' => '存在缺表或缺字段时，相关页面会提示进入数据库巡检，并降级显示空状态。',
                'value' => '待修复',
                'url' => 'admin/maintenance/schema-audit',
                'action' => '一键巡检',
            ];
        }

        $defaultStorage = $this->safeCount('storage_drivers', 'is_default = 1 AND is_enabled = 1');
        $enabledStorage = $this->safeCount('storage_drivers', 'is_enabled = 1');
        if ($defaultStorage <= 0 || $enabledStorage <= 0) {
            $alerts[] = [
                'level' => 'danger',
                'icon' => 'database',
                'title' => '默认存储缺失',
                'desc' => '没有启用的默认存储，上传图片或网盘文件会失败。',
                'value' => '未配置',
                'url' => 'admin/storages',
                'action' => '配置存储',
            ];
        }

        $failedBackups = $this->safeCount('file_storage_backups', "status = 'failed'");
        if ($failedBackups > 0) {
            $alerts[] = [
                'level' => 'warning',
                'icon' => 'database-backup',
                'title' => '存在失败备份任务',
                'desc' => '建议及时重试或检查备份存储的访问权限。',
                'value' => $failedBackups,
                'url' => 'admin/storage-backups/tasks',
                'action' => '查看任务',
            ];
        }

        $pendingRecharges = $this->safeCount('recharges', "status = 'pending'");
        if ($pendingRecharges > 0) {
            $alerts[] = [
                'level' => 'warning',
                'icon' => 'wallet-cards',
                'title' => '有充值待审核',
                'desc' => '用户充值等待人工确认，处理后余额会同步入账。',
                'value' => $pendingRecharges,
                'url' => 'admin/recharges',
                'action' => '去审核',
            ];
        }

        $pendingOrders = $this->safeCount('orders', "status = 'pending'");
        if ($pendingOrders > 0) {
            $alerts[] = [
                'level' => 'soft',
                'icon' => 'receipt-text',
                'title' => '有订单待处理',
                'desc' => '存在待支付或待确认订单，请及时查看交易状态。',
                'value' => $pendingOrders,
                'url' => 'admin/orders?status=pending',
                'action' => '查看订单',
            ];
        }

        $packageExpiring = $this->safeCount('users', 'status = 1 AND package_expire_time IS NOT NULL AND package_expire_time >= NOW() AND package_expire_time < DATE_ADD(NOW(), INTERVAL 7 DAY)');
        if ($packageExpiring > 0) {
            $alerts[] = [
                'level' => 'warning',
                'icon' => 'calendar-clock',
                'title' => '套餐即将到期',
                'desc' => '有用户套餐将在 7 天内到期，可发送提醒降低流失。',
                'value' => $packageExpiring,
                'url' => 'admin/package-expiry',
                'action' => '去提醒',
            ];
        }

        $offlineServers = $this->safeCount('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'");
        if ($offlineServers > 0) {
            $alerts[] = [
                'level' => 'danger',
                'icon' => 'activity',
                'title' => '平台监控离线',
                'desc' => '有平台服务器监控处于离线状态，请检查采集任务或节点状态。',
                'value' => $offlineServers,
                'url' => 'admin/monitors',
                'action' => '查看监控',
            ];
        }

        $unreadMonitorAlerts = $this->safeCount('monitor_alerts', "status = 'unread'");
        if ($unreadMonitorAlerts > 0) {
            $alerts[] = [
                'level' => 'warning',
                'icon' => 'bell-ring',
                'title' => '监控告警未处理',
                'desc' => '存在未读监控告警，请确认是否影响服务可用性。',
                'value' => $unreadMonitorAlerts,
                'url' => 'admin/monitors',
                'action' => '处理告警',
            ];
        }

        $slaRisk = (new SlaReportService())->riskSummary(7);
        if (!empty($slaRisk['ok']) && ((int) $slaRisk['below_99'] > 0 || (int) $slaRisk['no_data'] > 0 || (int) $slaRisk['collect_delayed'] > 0)) {
            $worstNode = isset($slaRisk['worst_node']) && is_array($slaRisk['worst_node']) ? $slaRisk['worst_node'] : null;
            $worstText = $worstNode ? ($worstNode['name'] . ' ' . number_format((float) $worstNode['sla_percent'], 2) . '%') : '有节点采集异常';
            $alerts[] = [
                'level' => ((int) $slaRisk['below_99'] > 0 || (int) $slaRisk['collect_delayed'] > 0) ? 'warning' : 'soft',
                'icon' => 'chart-no-axes-combined',
                'title' => '监控 SLA 需要关注',
                'desc' => '最近 7 天有 ' . (int) $slaRisk['below_99'] . ' 台节点低于 99%，' . (int) $slaRisk['collect_delayed'] . ' 台采集超时，' . (int) $slaRisk['no_data'] . ' 台暂无样本。最差节点：' . $worstText . '。',
                'value' => $slaRisk['average_sla'] === null ? '暂无样本' : number_format((float) $slaRisk['average_sla'], 2) . '%',
                'url' => 'admin/monitor-sla',
                'action' => '查看 SLA',
            ];
        }

        $apiFailures = $this->safeCount('api_logs', 'is_success = 0 AND DATE(created_at) = CURDATE()');
        if ($apiFailures > 0) {
            $alerts[] = [
                'level' => 'warning',
                'icon' => 'shield-alert',
                'title' => '今日 API 异常请求',
                'desc' => '开放接口今日出现失败请求，请检查鉴权、频率限制或调用参数。',
                'value' => $apiFailures,
                'url' => 'admin/api-logs',
                'action' => '查看日志',
            ];
        }

        $uploadChecks = $this->dashboardUploadHealth();
        foreach ($uploadChecks as $check) {
            if (empty($check['ok'])) {
                $alerts[] = [
                    'level' => 'danger',
                    'icon' => 'upload-cloud',
                    'title' => $check['title'],
                    'desc' => $check['desc'],
                    'value' => $check['value'],
                    'url' => $check['url'],
                    'action' => $check['action'],
                ];
            }
        }

        if (!$alerts) {
            $alerts[] = [
                'level' => 'ok',
                'icon' => 'circle-check',
                'title' => '核心功能运行正常',
                'desc' => '当前没有待处理风险，建议定期查看功能巡检和上传链路。',
                'value' => '正常',
                'url' => 'admin/feature-audit',
                'action' => '查看巡检',
            ];
        }

        return array_slice($alerts, 0, 8);
    }

    protected function dashboardUploadHealth()
    {
        $checks = [];
        $fileUploads = strtolower((string) ini_get('file_uploads'));
        $fileUploadsOk = !in_array($fileUploads, ['0', 'off', 'false'], true);
        $checks[] = [
            'ok' => $fileUploadsOk,
            'title' => 'PHP 上传入口关闭',
            'desc' => 'file_uploads 未开启时，浏览器上传会在进入业务代码前失败。',
            'value' => $fileUploads === '' ? '-' : $fileUploads,
            'url' => 'admin/maintenance/environment',
            'action' => '看环境',
        ];

        $postBytes = $this->iniBytes(ini_get('post_max_size'));
        $uploadBytes = $this->iniBytes(ini_get('upload_max_filesize'));
        $postOk = $postBytes <= 0 || $uploadBytes <= 0 || $postBytes >= $uploadBytes;
        $checks[] = [
            'ok' => $postOk,
            'title' => 'POST 总量限制异常',
            'desc' => 'post_max_size 小于 upload_max_filesize，批量或大文件上传会被截断。',
            'value' => (ini_get('post_max_size') ?: '-') . ' / ' . (ini_get('upload_max_filesize') ?: '-'),
            'url' => 'admin/upload-limits',
            'action' => '查看限制',
        ];

        $tmpDir = trim((string) ini_get('upload_tmp_dir'));
        $targetTmp = $tmpDir !== '' ? $tmpDir : sys_get_temp_dir();
        $tmpOk = is_dir($targetTmp) && is_writable($targetTmp);
        $checks[] = [
            'ok' => $tmpOk,
            'title' => '上传临时目录不可写',
            'desc' => 'PHP 临时目录不可写或不存在，上传文件会在业务处理前失败。',
            'value' => $targetTmp,
            'url' => 'admin/maintenance/environment',
            'action' => '看环境',
        ];

        $uploadsDir = APP_ROOT . '/public/uploads';
        $uploadsOk = is_dir($uploadsDir) && is_writable($uploadsDir);
        $checks[] = [
            'ok' => $uploadsOk,
            'title' => '本地上传目录不可写',
            'desc' => 'public/uploads 不可写会影响本地存储、缩略图和上传保护文件生成。',
            'value' => $uploadsOk ? '可写' : '不可写',
            'url' => 'admin/maintenance/environment',
            'action' => '看环境',
        ];

        return $checks;
    }

    protected function dashboardScreenData($range = '7d')
    {
        $config = $this->dashboardScreenRangeConfig($range);
        $days = (int) $config['days'];
        $interval = max(0, $days - 1);
        $dateFilter = $days === 1
            ? 'DATE(%s) = CURDATE()'
            : 'DATE(%s) >= DATE_SUB(CURDATE(), INTERVAL ' . $interval . ' DAY)';
        $orderStatusStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            "SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid, " .
            "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending, " .
            "SUM(CASE WHEN status NOT IN ('paid','pending') THEN 1 ELSE 0 END) AS other " .
            'FROM ' . Database::table('orders')
        );
        $rechargeStatusStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            "SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid, " .
            "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending, " .
            "SUM(CASE WHEN status NOT IN ('paid','pending') THEN 1 ELSE 0 END) AS other " .
            'FROM ' . Database::table('recharges')
        );
        $todayIncome = Database::fetch(
            "SELECT COALESCE(SUM(pay_amount),0) AS total, COUNT(*) AS count FROM " . Database::table('orders') . " WHERE status = 'paid' AND " . sprintf($dateFilter, 'created_at')
        );
        $monthIncome = Database::fetch(
            "SELECT COALESCE(SUM(pay_amount),0) AS total, COUNT(*) AS count FROM " . Database::table('orders') . " WHERE status = 'paid' AND " . sprintf($dateFilter, 'created_at')
        );
        $todayRecharge = Database::fetch(
            "SELECT COALESCE(SUM(amount),0) AS total, COUNT(*) AS count FROM " . Database::table('recharges') . " WHERE status = 'paid' AND paid_at IS NOT NULL AND " . sprintf($dateFilter, 'paid_at')
        );
        $apiToday = $this->tableExists('api_logs')
            ? Database::fetch(
                'SELECT COUNT(*) AS total, ' .
                'SUM(CASE WHEN is_success = 1 THEN 1 ELSE 0 END) AS success, ' .
                'SUM(CASE WHEN is_success = 0 THEN 1 ELSE 0 END) AS failed ' .
                'FROM ' . Database::table('api_logs') . ' WHERE ' . sprintf($dateFilter, 'created_at')
            )
            : ['total' => 0, 'success' => 0, 'failed' => 0];
        $repositoryStats = $this->tableExists('file_repositories')
            ? Database::fetch(
                'SELECT COUNT(*) AS total, ' .
                'SUM(CASE WHEN status = 1 AND admin_status = 1 THEN 1 ELSE 0 END) AS enabled, ' .
                "SUM(CASE WHEN admin_status = 0 THEN 1 ELSE 0 END) AS pending " .
                'FROM ' . Database::table('file_repositories')
            )
            : ['total' => 0, 'enabled' => 0, 'pending' => 0];
        $subsiteStats = $this->tableExists('subsites')
            ? Database::fetch(
                'SELECT COUNT(*) AS total, ' .
                "SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active, " .
                "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending " .
                'FROM ' . Database::table('subsites')
            )
            : ['total' => 0, 'active' => 0, 'pending' => 0];
        $monitorStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            "SUM(CASE WHEN status = 'online' THEN 1 ELSE 0 END) AS online, " .
            "SUM(CASE WHEN status = 'offline' THEN 1 ELSE 0 END) AS offline " .
            'FROM ' . Database::table('monitor_servers') . ' WHERE is_enabled = 1'
        );
        $storageStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            'SUM(CASE WHEN is_enabled = 1 THEN 1 ELSE 0 END) AS enabled, ' .
            'SUM(CASE WHEN is_default = 1 AND is_enabled = 1 THEN 1 ELSE 0 END) AS defaults ' .
            'FROM ' . Database::table('storage_drivers')
        );
        $contentStats = Database::fetch(
            'SELECT COUNT(*) AS total, ' .
            "SUM(CASE WHEN file_type = 'image' THEN 1 ELSE 0 END) AS images, " .
            "SUM(CASE WHEN file_type = 'file' THEN 1 ELSE 0 END) AS files, " .
            'COALESCE(SUM(file_size),0) AS total_size, ' .
            'COUNT(*) AS today_files ' .
            'FROM ' . Database::table('files') . ' WHERE ' . sprintf($dateFilter, 'created_at')
        );
        $userQuota = Database::fetch(
            'SELECT COALESCE(SUM(used_storage),0) AS used_storage, COALESCE(SUM(total_storage),0) AS total_storage, COALESCE(SUM(balance),0) AS total_balance FROM ' . Database::table('users')
        );
        $topUsers = Database::fetchAll(
            'SELECT id, username, nickname, used_storage, total_storage, used_traffic, total_traffic, balance FROM ' . Database::table('users') . ' ORDER BY used_storage DESC, id DESC LIMIT 6'
        );
        $latestFiles = Database::fetchAll(
            'SELECT f.original_name, f.file_type, f.file_size, f.created_at, u.username, u.nickname FROM ' . Database::table('files') . ' f LEFT JOIN ' . Database::table('users') . ' u ON f.user_id = u.id WHERE ' . sprintf($dateFilter, 'f.created_at') . ' ORDER BY f.id DESC LIMIT 6'
        );
        $alerts = $this->dashboardScreenAlerts([
            'pending_orders' => $this->safeCount('orders', "status = 'pending'"),
            'pending_recharges' => $this->safeCount('recharges', "status = 'pending'"),
            'monitor_offline' => (int) $monitorStats['offline'],
            'api_today_failed' => (int) $apiToday['failed'],
            'repository_pending' => (int) $repositoryStats['pending'],
            'subsite_pending' => (int) $subsiteStats['pending'],
            'storage_default' => (int) $storageStats['defaults'],
        ]);
        $pendingOrders = $this->safeCount('orders', "status = 'pending'");
        $pendingRecharges = $this->safeCount('recharges', "status = 'pending'");
        $orderTotal = max(0, (int) $orderStatusStats['total']);
        $orderPaid = max(0, (int) $orderStatusStats['paid']);
        $rechargeTotal = max(0, (int) $rechargeStatusStats['total']);
        $rechargePaid = max(0, (int) $rechargeStatusStats['paid']);
        $imageCount = max(0, (int) $contentStats['images']);
        $fileCount = max(0, (int) $contentStats['files']);
        $contentTotal = max(0, (int) $contentStats['total']);
        $storageTotal = max(0, (int) $storageStats['total']);
        $storageEnabled = max(0, (int) $storageStats['enabled']);
        $pendingTotal = $pendingOrders + $pendingRecharges + (int) $monitorStats['offline'] + (int) $repositoryStats['pending'] + (int) $subsiteStats['pending'];
        $conversionCards = [
            [
                'label' => '订单支付率',
                'value' => $orderTotal > 0 ? round(($orderPaid / $orderTotal) * 100, 1) : 0,
                'suffix' => '%',
                'detail' => $orderPaid . ' / ' . $orderTotal . ' 笔订单已支付',
                'tone' => 'blue',
            ],
            [
                'label' => '充值到账率',
                'value' => $rechargeTotal > 0 ? round(($rechargePaid / $rechargeTotal) * 100, 1) : 0,
                'suffix' => '%',
                'detail' => $rechargePaid . ' / ' . $rechargeTotal . ' 笔充值已到账',
                'tone' => 'green',
            ],
            [
                'label' => '图片占比',
                'value' => $contentTotal > 0 ? round(($imageCount / $contentTotal) * 100, 1) : 0,
                'suffix' => '%',
                'detail' => $imageCount . ' 张图片 / ' . $fileCount . ' 个普通文件',
                'tone' => 'purple',
            ],
            [
                'label' => '存储启用率',
                'value' => $storageTotal > 0 ? round(($storageEnabled / $storageTotal) * 100, 1) : 0,
                'suffix' => '%',
                'detail' => $storageEnabled . ' / ' . $storageTotal . ' 个存储源已启用',
                'tone' => 'orange',
            ],
        ];
        $distribution = [
            'orders' => [
                ['label' => '已支付', 'value' => $orderPaid],
                ['label' => '待处理', 'value' => (int) $orderStatusStats['pending']],
                ['label' => '其他状态', 'value' => (int) $orderStatusStats['other']],
            ],
            'files' => [
                ['label' => '图片资源', 'value' => $imageCount],
                ['label' => '普通文件', 'value' => $fileCount],
            ],
            'todos' => [
                ['label' => '待处理订单', 'value' => $pendingOrders],
                ['label' => '待审充值', 'value' => $pendingRecharges],
                ['label' => '离线监控', 'value' => (int) $monitorStats['offline']],
                ['label' => '仓库待处理', 'value' => (int) $repositoryStats['pending']],
                ['label' => '分站待审核', 'value' => (int) $subsiteStats['pending']],
            ],
        ];
        $opsSummary = [
            [
                'label' => '总待办数',
                'value' => $pendingTotal,
                'detail' => '订单、充值、监控、仓库和分站的待处理事项合计',
            ],
            [
                'label' => 'API 今日失败',
                'value' => (int) $apiToday['failed'],
                'detail' => '异常请求需要及时回看日志与鉴权链路',
            ],
            [
                'label' => '分站待审核',
                'value' => (int) $subsiteStats['pending'],
                'detail' => '影响用户开通体验，适合运营优先处理',
            ],
        ];
        $overview = [
            [
                'label' => '全站用户',
                'value' => $this->safeCount('users'),
                'delta' => $config['label'] . '新增 ' . $this->safeCount('users', sprintf($dateFilter, 'created_at')),
                'icon' => 'users',
                'tone' => 'blue',
            ],
            [
                'label' => '内容资产',
                'value' => (int) $contentStats['total'],
                'delta' => $config['label'] . '新增 ' . (int) $contentStats['today_files'],
                'icon' => 'files',
                'tone' => 'green',
            ],
            [
                'label' => '今日收入',
                'value' => '¥' . number_format((float) $todayIncome['total'], 2),
                'delta' => $config['label'] . ' ' . (int) $todayIncome['count'] . ' 笔已支付订单',
                'icon' => 'badge-yen-sign',
                'tone' => 'orange',
            ],
            [
                'label' => '监控在线率',
                'value' => ($monitorStats && (int) $monitorStats['total'] > 0) ? number_format(((int) $monitorStats['online'] / (int) $monitorStats['total']) * 100, 1) . '%' : '0%',
                'delta' => '在线 ' . (int) $monitorStats['online'] . ' / 总计 ' . (int) $monitorStats['total'],
                'icon' => 'activity',
                'tone' => ((int) $monitorStats['offline'] > 0 ? 'orange' : 'green'),
            ],
        ];
        return [
            'overview' => $overview,
            'business' => [
                'today_income' => (float) $todayIncome['total'],
                'today_income_count' => (int) $todayIncome['count'],
                'month_income' => (float) $monthIncome['total'],
                'month_income_count' => (int) $monthIncome['count'],
                'today_recharge' => (float) $todayRecharge['total'],
                'today_recharge_count' => (int) $todayRecharge['count'],
                'pending_orders' => $pendingOrders,
                'pending_recharges' => $pendingRecharges,
                'total_balance' => (float) $userQuota['total_balance'],
            ],
            'assets' => [
                'total_files' => (int) $contentStats['total'],
                'images' => (int) $contentStats['images'],
                'files' => (int) $contentStats['files'],
                'storage_used' => (float) $contentStats['total_size'],
                'user_storage_used' => (float) $userQuota['used_storage'],
                'user_storage_total' => (float) $userQuota['total_storage'],
                'repository_total' => (int) $repositoryStats['total'],
                'repository_enabled' => (int) $repositoryStats['enabled'],
                'repository_pending' => (int) $repositoryStats['pending'],
                'subsite_total' => (int) $subsiteStats['total'],
                'subsite_active' => (int) $subsiteStats['active'],
                'subsite_pending' => (int) $subsiteStats['pending'],
            ],
            'service' => [
                'monitor_total' => (int) $monitorStats['total'],
                'monitor_online' => (int) $monitorStats['online'],
                'monitor_offline' => (int) $monitorStats['offline'],
                'storage_total' => (int) $storageStats['total'],
                'storage_enabled' => (int) $storageStats['enabled'],
                'storage_default' => (int) $storageStats['defaults'],
                'api_today_total' => (int) $apiToday['total'],
                'api_today_success' => (int) $apiToday['success'],
                'api_today_failed' => (int) $apiToday['failed'],
            ],
            'revenueTrend' => $this->dashboardRevenueTrend($days),
            'growthTrend' => $this->dashboardScreenGrowthTrend($days),
            'topUsers' => $topUsers,
            'latestFiles' => $latestFiles,
            'recentOrders' => $this->dashboardRecentOrders(),
            'alerts' => $alerts,
            'conversionCards' => $conversionCards,
            'distribution' => $distribution,
            'opsSummary' => $opsSummary,
            'meta' => [
                'generated_at' => now(),
                'refresh_seconds' => 60,
                'range' => $config['key'],
                'range_label' => $config['label'],
                'range_options' => $this->dashboardScreenRangeOptions(),
            ],
        ];
    }

    protected function dashboardScreenRange()
    {
        $range = isset($_GET['range']) ? (string) $_GET['range'] : '7d';
        return isset($this->dashboardScreenRangeOptions()[$range]) ? $range : '7d';
    }

    protected function dashboardScreenRangeOptions()
    {
        return [
            'today' => ['key' => 'today', 'label' => '今日', 'days' => 1],
            '7d' => ['key' => '7d', 'label' => '近 7 天', 'days' => 7],
            '30d' => ['key' => '30d', 'label' => '近 30 天', 'days' => 30],
        ];
    }

    protected function dashboardScreenRangeConfig($range)
    {
        $options = $this->dashboardScreenRangeOptions();
        return isset($options[$range]) ? $options[$range] : $options['7d'];
    }

    protected function dashboardScreenAlerts(array $stats)
    {
        $items = [];
        if (!empty($stats['pending_orders'])) {
            $items[] = [
                'level' => 'warn',
                'title' => '待处理订单',
                'value' => (int) $stats['pending_orders'],
                'detail' => '有订单等待支付确认或人工处理',
                'url' => 'admin/orders',
                'icon' => 'receipt-text',
            ];
        }
        if (!empty($stats['pending_recharges'])) {
            $items[] = [
                'level' => 'warn',
                'title' => '待审充值',
                'value' => (int) $stats['pending_recharges'],
                'detail' => '有用户充值等待审核入账',
                'url' => 'admin/recharges',
                'icon' => 'wallet-cards',
            ];
        }
        if (!empty($stats['monitor_offline'])) {
            $items[] = [
                'level' => 'danger',
                'title' => '离线监控',
                'value' => (int) $stats['monitor_offline'],
                'detail' => '有监控节点离线，请检查采集任务或服务器状态',
                'url' => 'admin/monitors',
                'icon' => 'triangle-alert',
            ];
        }
        if (!empty($stats['api_today_failed'])) {
            $items[] = [
                'level' => 'danger',
                'title' => 'API 失败',
                'value' => (int) $stats['api_today_failed'],
                'detail' => '今日开放接口存在失败请求，请查看日志',
                'url' => 'admin/api-logs',
                'icon' => 'shield-alert',
            ];
        }
        if (!empty($stats['repository_pending'])) {
            $items[] = [
                'level' => 'soft',
                'title' => '仓库待处理',
                'value' => (int) $stats['repository_pending'],
                'detail' => '有分享仓库等待审核或处理',
                'url' => 'admin/repositories',
                'icon' => 'library',
            ];
        }
        if (!empty($stats['subsite_pending'])) {
            $items[] = [
                'level' => 'soft',
                'title' => '分站待审核',
                'value' => (int) $stats['subsite_pending'],
                'detail' => '有用户分站等待审核开通',
                'url' => 'admin/subsites',
                'icon' => 'globe-2',
            ];
        }
        if (empty($stats['storage_default'])) {
            $items[] = [
                'level' => 'danger',
                'title' => '默认存储缺失',
                'value' => 0,
                'detail' => '未配置默认存储，上传功能可能失败',
                'url' => 'admin/storages',
                'icon' => 'database-zap',
            ];
        }
        if (!$items) {
            $items[] = [
                'level' => 'ok',
                'title' => '系统运行平稳',
                'value' => 0,
                'detail' => '当前没有需要优先处理的运营风险',
                'url' => 'admin',
                'icon' => 'badge-check',
            ];
        }
        return $items;
    }

    protected function dashboardScreenGrowthTrend($days = 7)
    {
        $days = max(1, (int) $days);
        $interval = max(0, $days - 1);
        $userRows = Database::fetchAll(
            'SELECT DATE(created_at) AS day, COUNT(*) AS total FROM ' . Database::table('users') . ' WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ' . $interval . ' DAY) GROUP BY DATE(created_at) ORDER BY day ASC'
        );
        $fileRows = Database::fetchAll(
            'SELECT DATE(created_at) AS day, COUNT(*) AS total FROM ' . Database::table('files') . ' WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ' . $interval . ' DAY) GROUP BY DATE(created_at) ORDER BY day ASC'
        );
        $days = [];
        for ($i = $interval; $i >= 0; $i--) {
            $days[date('Y-m-d', strtotime('-' . $i . ' day'))] = [
                'day' => date('m/d', strtotime('-' . $i . ' day')),
                'users' => 0,
                'files' => 0,
            ];
        }
        foreach ($userRows as $row) {
            if (isset($days[$row['day']])) {
                $days[$row['day']]['users'] = (int) $row['total'];
            }
        }
        foreach ($fileRows as $row) {
            if (isset($days[$row['day']])) {
                $days[$row['day']]['files'] = (int) $row['total'];
            }
        }
        return array_values($days);
    }

    protected function storageStats(array $storages)
    {
        $stats = ['total' => count($storages), 'enabled' => 0, 'cloud' => 0, 'default_name' => '未设置'];
        foreach ($storages as $storage) {
            if (!empty($storage['is_enabled'])) {
                $stats['enabled']++;
            }
            if (isset($storage['type']) && $storage['type'] !== 'local') {
                $stats['cloud']++;
            }
            if (!empty($storage['is_default'])) {
                $stats['default_name'] = $storage['name'];
            }
        }
        return $stats;
    }

    protected function localServerInfo()
    {
        try {
            $row = Database::fetch('SELECT VERSION() AS version');
            $dbVersion = $row ? $row['version'] : 'unknown';
        } catch (\Throwable $e) {
            $dbVersion = '读取失败';
        }
        $root = defined('APP_ROOT') ? APP_ROOT : dirname(__DIR__, 2);
        $diskTotal = @disk_total_space($root);
        $diskFree = @disk_free_space($root);
        $diskUsed = $diskTotal && $diskFree !== false ? $diskTotal - $diskFree : 0;
        $extensions = [];
        foreach (['pdo', 'curl', 'openssl', 'fileinfo', 'mbstring', 'gd', 'zip'] as $ext) {
            $extensions[$ext] = extension_loaded($ext);
        }
        return [
            'os' => php_uname('s') . ' ' . php_uname('r'),
            'php_version' => PHP_VERSION,
            'server_software' => isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'CLI/Unknown',
            'database_version' => $dbVersion,
            'memory_limit' => ini_get('memory_limit'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size'),
            'max_execution_time' => ini_get('max_execution_time') . 's',
            'disk_total' => $diskTotal ? format_bytes($diskTotal) : 'unknown',
            'disk_used' => $diskTotal ? format_bytes($diskUsed) : 'unknown',
            'disk_free' => $diskFree !== false ? format_bytes($diskFree) : 'unknown',
            'extensions' => $extensions,
            'time' => now(),
        ];
    }

    protected function adminLog($action, $targetType = null, $targetId = null)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('admin_logs') . ' (admin_id, action, target_type, target_id, ip, detail, created_at) VALUES (?,?,?,?,?,?,?)',
            [Auth::id(), $action, $targetType, $targetId, Auth::ip(), json_encode($this->redactLogData($_POST), JSON_UNESCAPED_UNICODE), now()]
        );
    }

    protected function redactLogData(array $data)
    {
        foreach ($data as $key => $value) {
            if (preg_match('/(password|secret|token|key|api_key)/i', (string) $key)) {
                $data[$key] = $value === '' ? '' : '******';
            } elseif (is_array($value)) {
                $data[$key] = $this->redactLogData($value);
            }
        }
        return $data;
    }
}
