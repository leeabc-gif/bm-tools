<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Config;
use App\Core\Router;
use App\Core\Validator;
use PDO;

class InstallController extends Controller
{
    public function index()
    {
        if (Router::installed()) {
            $this->view('install/locked', ['title' => '系统已安装'], 'layouts/install');
            return;
        }
        $this->view('install/index', [
            'title' => '安装向导',
            'checks' => $this->environmentChecks(),
        ], 'layouts/install');
    }

    public function success()
    {
        if (!Router::installed()) {
            $this->redirect('install');
        }
        $this->view('install/success', [
            'title' => '安装完成',
            'frontUrl' => url('/'),
            'adminUrl' => url('admin'),
            'loginUrl' => url('login'),
        ], 'layouts/install');
    }

    public function install()
    {
        if (Router::installed()) {
            $this->redirect('login');
        }
        $this->verifyCsrf();

        $required = ['db_host', 'db_port', 'db_name', 'db_user', 'table_prefix', 'admin_username', 'admin_email', 'admin_password', 'site_name'];
        foreach ($required as $key) {
            if (!Validator::required(isset($_POST[$key]) ? $_POST[$key] : '')) {
                set_flash('error', '请完整填写安装信息。');
                remember_old();
                $this->redirect('install');
            }
        }

        if (empty($_POST['install_confirm'])) {
            set_flash('error', '请先确认数据库信息正确，并勾选安装确认声明。');
            remember_old();
            $this->redirect('install');
        }

        if (!Validator::username($_POST['admin_username']) || !Validator::email($_POST['admin_email']) || !Validator::password($_POST['admin_password'])) {
            set_flash('error', '管理员用户名、邮箱或密码格式不正确。');
            remember_old();
            $this->redirect('install');
        }

        $prefix = preg_replace('/[^A-Za-z0-9_]/', '', $_POST['table_prefix']);
        if ($prefix === '') {
            $prefix = 'bm_';
        }

        try {
            $pdo = $this->connectDatabase($_POST['db_host'], $_POST['db_port'], $_POST['db_name'], $_POST['db_user'], isset($_POST['db_pass']) ? $_POST['db_pass'] : '');

            $schema = file_get_contents(APP_ROOT . '/database/schema.sql');
            $schema = str_replace('__PREFIX__', $prefix, $schema);
            $this->executeSql($pdo, $schema);

            $freePackageId = $this->seedInitialData($pdo, $prefix, $_POST['site_name']);

            $adminPassword = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO `' . $prefix . 'users` (`username`, `nickname`, `email`, `password`, `avatar`, `role`, `balance`, `package_id`, `used_storage`, `total_storage`, `used_traffic`, `total_traffic`, `status`, `api_token`, `created_at`, `updated_at`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE `nickname` = VALUES(`nickname`), `email` = VALUES(`email`), `password` = VALUES(`password`), `role` = VALUES(`role`), `status` = 1, `updated_at` = VALUES(`updated_at`)');
            $stmt->execute([
                $_POST['admin_username'],
                $_POST['admin_username'],
                $_POST['admin_email'],
                $adminPassword,
                '',
                'admin',
                0,
                $freePackageId,
                0,
                1073741824,
                0,
                5368709120,
                1,
                bin2hex(random_bytes(24)),
                now(),
                now(),
            ]);
            $admin = $pdo->prepare('SELECT id FROM `' . $prefix . 'users` WHERE username = ? LIMIT 1');
            $admin->execute([$_POST['admin_username']]);
            $adminId = (int) $admin->fetchColumn();

            $this->writeDatabaseConfig([
                'host' => $_POST['db_host'],
                'port' => $_POST['db_port'],
                'database' => $_POST['db_name'],
                'username' => $_POST['db_user'],
                'password' => isset($_POST['db_pass']) ? $_POST['db_pass'] : '',
                'prefix' => $prefix,
                'charset' => 'utf8mb4',
            ]);

            file_put_contents(APP_ROOT . '/storage/install.lock', 'installed at ' . now());
            clear_old();
            if ($adminId > 0) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $adminId;
            }
            $this->redirect('install/success');
        } catch (\Throwable $e) {
            set_flash('error', '安装失败：' . $this->friendlyDatabaseError($e));
            remember_old();
            $this->redirect('install');
        }
    }

    public function testDatabase()
    {
        if (Router::installed()) {
            $this->json(['success' => false, 'message' => '系统已安装，不能重复测试安装数据库。'], 403);
        }
        $this->verifyCsrf();

        $host = trim(isset($_POST['db_host']) ? $_POST['db_host'] : '');
        $port = trim(isset($_POST['db_port']) ? $_POST['db_port'] : '3306');
        $name = trim(isset($_POST['db_name']) ? $_POST['db_name'] : '');
        $user = trim(isset($_POST['db_user']) ? $_POST['db_user'] : '');
        $pass = isset($_POST['db_pass']) ? $_POST['db_pass'] : '';
        $prefix = trim(isset($_POST['table_prefix']) ? $_POST['table_prefix'] : 'bm_');

        if ($host === '' || $port === '' || $name === '' || $user === '' || $prefix === '') {
            $this->json(['success' => false, 'message' => '请先完整填写数据库地址、端口、数据库名、用户名和表前缀。'], 422);
        }
        if (!preg_match('/^[A-Za-z0-9_]+$/', $prefix)) {
            $this->json(['success' => false, 'message' => '表前缀只能包含字母、数字和下划线。'], 422);
        }

        try {
            $pdo = $this->connectDatabase($host, $port, $name, $user, $pass);
            $version = $pdo->query('SELECT VERSION()')->fetchColumn();
            $this->json([
                'success' => true,
                'message' => '数据库连接成功，可以继续安装。',
                'version' => $version,
            ]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $this->friendlyDatabaseError($e)], 422);
        }
    }

    protected function executeSql(PDO $pdo, $sql)
    {
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        foreach ($statements as $statement) {
            if ($statement !== '') {
                $pdo->exec($statement);
            }
        }
    }

    protected function writeDatabaseConfig(array $config)
    {
        $content = "<?php\nreturn " . var_export($config, true) . ";\n";
        file_put_contents(APP_ROOT . '/config/database.php', $content);

        $appConfigPath = APP_ROOT . '/config/app.php';
        if (is_file($appConfigPath)) {
            $appConfig = require $appConfigPath;
            if (!isset($appConfig['security']) || !is_array($appConfig['security'])) {
                $appConfig['security'] = [];
            }
            if (empty($appConfig['security']['secret_key']) || $appConfig['security']['secret_key'] === 'bm-tools-change-this-secret-key') {
                $appConfig['security']['secret_key'] = bin2hex(random_bytes(32));
                file_put_contents($appConfigPath, "<?php\nreturn " . var_export($appConfig, true) . ";\n");
            }
        }
    }

    protected function seedInitialData(PDO $pdo, $prefix, $siteName)
    {
        $packageCount = (int) $pdo->query('SELECT COUNT(*) FROM `' . $prefix . 'packages`')->fetchColumn();
        if ($packageCount === 0) {
            $pdo->exec("INSERT INTO `" . $prefix . "packages`
(`name`, `price`, `duration_type`, `duration_days`, `storage_limit`, `traffic_limit`, `single_file_limit`, `allow_image`, `allow_netdisk`, `allow_api`, `allow_monitor`, `allow_multi_storage`, `allow_share`, `allow_subsite`, `subsite_limit`, `allow_video_preview`, `allow_external_link`, `status`, `sort_order`, `description`, `created_at`, `updated_at`)
VALUES
('免费套餐', 0.00, 'forever', 36500, 1073741824, 5368709120, 10485760, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, '适合个人轻量图片与文件管理，默认新用户套餐。', NOW(), NOW()),
('专业套餐', 29.00, 'month', 30, 10737418240, 107374182400, 104857600, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 10, '提供更大空间、API 上传、多存储线路、分享仓库、服务器运维监控、视频预览和个人分站能力。', NOW(), NOW())");
        }

        $payments = [
            ['余额支付', 'balance', '{}', 1, 1],
            ['支付宝当面付', 'alipay', '{"app_id":"","private_key":"","alipay_public_key":"","sandbox":false,"notify_url":"","timeout_express":"10m"}', 0, 10],
            ['微信支付', 'wechat', '{}', 0, 20],
            ['易支付', 'epay', '{}', 0, 30],
            ['人工充值审核', 'manual', '{}', 1, 40],
        ];
        $stmt = $pdo->prepare('INSERT INTO `' . $prefix . 'payment_config` (`name`,`code`,`config`,`is_enabled`,`sort_order`,`created_at`,`updated_at`) VALUES (?,?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE `name`=VALUES(`name`), `config`=VALUES(`config`), `is_enabled`=VALUES(`is_enabled`), `sort_order`=VALUES(`sort_order`), `updated_at`=NOW()');
        foreach ($payments as $payment) {
            $stmt->execute($payment);
        }

        $storageCount = (int) $pdo->query('SELECT COUNT(*) FROM `' . $prefix . 'storage_drivers`')->fetchColumn();
        if ($storageCount === 0) {
            $pdo->exec("INSERT INTO `" . $prefix . "storage_drivers` (`name`, `type`, `access_key`, `secret_key`, `bucket`, `region`, `endpoint`, `domain`, `prefix`, `is_enabled`, `is_default`, `is_public`, `created_at`, `updated_at`) VALUES ('本地测试存储', 'local', '', '', '', '', '', '', 'uploads/files', 1, 1, 1, NOW(), NOW())");
        }

        $freePackageId = (int) $pdo->query('SELECT id FROM `' . $prefix . 'packages` ORDER BY price ASC, sort_order ASC, id ASC LIMIT 1')->fetchColumn();
        if ($freePackageId <= 0) {
            $freePackageId = 1;
        }

        $settings = [
            'site_name' => $siteName,
            'site_public_url' => '',
            'site_logo' => '',
            'seo_keywords' => '图床,网盘,对象存储,服务器状态,宝塔监控',
            'seo_description' => '综合型图床、轻量网盘、套餐充值、多对象存储与运营方服务器状态展示平台。',
            'register_enabled' => '1',
            'register_email_code_enabled' => '0',
            'user_image_upload_enabled' => '1',
            'user_netdisk_enabled' => '1',
            'guest_image_upload_enabled' => '0',
            'guest_image_upload_user_id' => '',
            'guest_image_upload_max_size' => '5242880',
            'guest_image_upload_daily_ip_limit' => '20',
            'upload_max_concurrency' => '2',
            'upload_image_batch_limit' => '20',
            'upload_file_batch_limit' => '10',
            'upload_image_daily_limit' => '0',
            'upload_file_daily_limit' => '0',
            'security_login_max_attempts' => '5',
            'security_login_window_minutes' => '10',
            'security_login_lock_minutes' => '15',
            'security_email_code_max_per_hour' => '5',
            'security_email_code_ip_max_per_hour' => '20',
            'default_theme' => 'light',
            'file_naming_strategy' => 'random',
            'default_free_package_id' => (string) $freePackageId,
            'api_rate_limit_per_minute' => '60',
            'api_rate_limit_per_day' => '1000',
            'app_version' => Config::get('app.version', '1.0.0'),
            'update_manifest_url' => '',
            'email_host' => '',
            'email_port' => '465',
            'email_username' => '',
            'email_password' => '',
            'email_from' => '',
            'ssh_terminal_enabled' => '1',
            'ssh_terminal_user_server_limit' => '5',
            'ssh_terminal_session_timeout' => '600',
            'ssh_terminal_command_timeout' => '30',
            'ssh_terminal_gateway_url' => '',
            'subsite_enabled' => '1',
            'subsite_domain_suffixes' => '',
            'subsite_cname_target' => '',
            'subsite_https_mode' => 'auto',
            'subsite_custom_domain_enabled' => '1',
            'subsite_requires_review' => '0',
            'subsite_default_limit' => '1',
            'subsite_reserved_slugs' => 'admin,api,www,cdn,static,status,login,register,assets,uploads,files,share',
        ];
        $stmt = $pdo->prepare('INSERT INTO `' . $prefix . 'settings` (`setting_key`,`setting_value`,`created_at`,`updated_at`) VALUES (?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`), `updated_at`=NOW()');
        foreach ($settings as $key => $value) {
            $stmt->execute([$key, $value]);
        }

        $announcementCount = (int) $pdo->query('SELECT COUNT(*) FROM `' . $prefix . 'announcements`')->fetchColumn();
        if ($announcementCount === 0) {
            $stmt = $pdo->prepare('INSERT INTO `' . $prefix . 'announcements` (`title`,`content`,`is_top`,`show_home`,`status`,`published_at`,`created_at`,`updated_at`) VALUES (?,?,?,?,?,NOW(),NOW(),NOW())');
            $stmt->execute(['欢迎使用 ' . $siteName, '系统已安装完成。你可以在后台配置对象存储、支付方式、套餐与运营方服务器状态监控。', 1, 1, 1]);
        }

        return $freePackageId;
    }

    protected function connectDatabase($host, $port, $database, $username, $password)
    {
        return new PDO(
            'mysql:host=' . trim($host) . ';port=' . trim($port) . ';dbname=' . trim($database) . ';charset=utf8mb4',
            trim($username),
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
    }

    protected function friendlyDatabaseError(\Exception $e)
    {
        $message = $e->getMessage();
        if (strpos($message, '1045') !== false || stripos($message, 'Access denied') !== false) {
            return '数据库账号或密码错误，或该账号没有访问此数据库的权限。宝塔里通常需要使用“数据库管理”中创建的专用账号和密码，不建议直接填 root。原始错误：' . $message;
        }
        if (strpos($message, '1049') !== false || stripos($message, 'Unknown database') !== false) {
            return '数据库不存在，请先在宝塔面板创建数据库后再继续。原始错误：' . $message;
        }
        if (strpos($message, '2002') !== false || stripos($message, 'Connection refused') !== false || stripos($message, 'No such file') !== false) {
            return '无法连接 MySQL，请检查数据库地址、端口、MySQL 服务状态和防火墙。原始错误：' . $message;
        }
        if (strpos($message, '1142') !== false) {
            return '数据库账号权限不足，请给该账号授予当前数据库的建表、写入和修改权限。原始错误：' . $message;
        }
        return $message;
    }

    protected function environmentChecks()
    {
        $dirs = ['config', 'storage', 'storage/logs', 'storage/cache', 'public/uploads'];
        $dirChecks = [];
        foreach ($dirs as $dir) {
            $path = APP_ROOT . '/' . $dir;
            $dirChecks[] = [
                'name' => $dir,
                'ok' => is_dir($path) && is_writable($path),
                'value' => is_dir($path) ? (is_writable($path) ? '可写' : '不可写') : '不存在',
            ];
        }

        return [
            ['name' => 'PHP 版本', 'ok' => version_compare(PHP_VERSION, '7.4.0', '>='), 'value' => PHP_VERSION],
            ['name' => 'PDO 扩展', 'ok' => extension_loaded('pdo_mysql'), 'value' => extension_loaded('pdo_mysql') ? '已启用' : '未启用'],
            ['name' => 'curl 扩展', 'ok' => extension_loaded('curl'), 'value' => extension_loaded('curl') ? '已启用' : '未启用'],
            ['name' => 'openssl 扩展', 'ok' => extension_loaded('openssl'), 'value' => extension_loaded('openssl') ? '已启用' : '未启用'],
            ['name' => 'fileinfo 扩展', 'ok' => extension_loaded('fileinfo'), 'value' => extension_loaded('fileinfo') ? '已启用' : '未启用'],
            ['name' => 'mbstring 扩展', 'ok' => extension_loaded('mbstring'), 'value' => extension_loaded('mbstring') ? '已启用' : '未启用'],
            ['name' => 'gd 扩展', 'ok' => extension_loaded('gd'), 'value' => extension_loaded('gd') ? '已启用' : '未启用'],
            ['name' => '目录权限', 'ok' => count(array_filter($dirChecks, function ($item) { return !$item['ok']; })) === 0, 'value' => $dirChecks],
        ];
    }
}
