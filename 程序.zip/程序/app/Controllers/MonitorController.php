<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\MonitorMetric;
use App\Models\MonitorServer;
use App\Services\DatabaseUpgradeService;
use App\Services\Monitor\MonitorService;
use App\Services\Monitor\ServiceProbeService;
use App\Services\PermissionService;

class MonitorController extends Controller
{
    protected function ensureMonitorReady($back = 'status')
    {
        return $this->ensureFeatureReady(
            $this->schemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema']) && $this->schemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema']),
            '服务器监控',
            $back,
            '服务器监控数据结构未准备完成，请联系管理员进入后台「系统维护」执行数据库一键修复。'
        );
    }

    protected function schemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function index()
    {
        $this->requireLogin();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $group = trim(isset($_GET['group']) ? $_GET['group'] : '');
        $status = trim(isset($_GET['status']) ? $_GET['status'] : '');

        $sql = 'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type = ?';
        $params = ['bt'];
        if ($keyword !== '') {
            $sql .= ' AND (name LIKE ? OR remark LIKE ? OR server_ip LIKE ? OR panel_url LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        if ($group !== '') {
            $sql .= ' AND group_name = ?';
            $params[] = $group;
        }
        if (in_array($status, ['online', 'offline', 'unknown'], true)) {
            $sql .= ' AND status = ?';
            $params[] = $status;
        }
        $sql .= " ORDER BY FIELD(status, 'offline', 'unknown', 'online'), id DESC";

        $servers = Database::fetchAll($sql, $params);
        $metricModel = new MonitorMetric();
        foreach ($servers as &$server) {
            $server['latest'] = $metricModel->latest($server['id']);
        }
        unset($server);

        $groups = Database::fetchAll('SELECT group_name, COUNT(*) AS total FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type = ? AND group_name <> "" GROUP BY group_name ORDER BY total DESC, group_name ASC', ['bt']);
        $stats = [
            'total' => $this->countMonitorServers(),
            'online' => $this->countMonitorServers("status = 'online'"),
            'offline' => $this->countMonitorServers("status = 'offline'"),
            'unknown' => $this->countMonitorServers("status = 'unknown'"),
            'alerts_today' => $this->countMonitorAlerts("DATE(a.created_at) = CURDATE()"),
            'unread_alerts' => $this->countMonitorAlerts("a.status = 'unread'"),
        ];

        $this->view('monitor/index', [
            'title' => '服务器监控',
            'servers' => $servers,
            'groups' => $groups,
            'filters' => ['keyword' => $keyword, 'group' => $group, 'status' => $status],
            'stats' => $stats,
        ]);
    }

    public function create()
    {
        $this->requireLogin();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }
        $this->view('monitor/create', ['title' => '添加服务器']);
    }

    public function store()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $name = trim(isset($_POST['name']) ? $_POST['name'] : '');
        $panelUrl = trim(isset($_POST['panel_url']) ? $_POST['panel_url'] : '');
        $apiKey = trim(isset($_POST['api_key']) ? $_POST['api_key'] : '');
        if ($name === '' || $panelUrl === '' || $apiKey === '') {
            set_flash('error', '请填写服务器名称、宝塔面板地址和 API 密钥。');
            $this->back();
        }

        (new MonitorServer())->create([
            'user_id' => Auth::id(),
            'monitor_type' => 'bt',
            'name' => $name,
            'remark' => trim(isset($_POST['remark']) ? $_POST['remark'] : ''),
            'panel_url' => $panelUrl,
            'api_key' => $apiKey,
            'panel_port' => (int) (isset($_POST['panel_port']) ? $_POST['panel_port'] : 8888),
            'server_ip' => trim(isset($_POST['server_ip']) ? $_POST['server_ip'] : ''),
            'group_name' => trim(isset($_POST['group_name']) ? $_POST['group_name'] : ''),
            'is_enabled' => 1,
            'frequency' => max(30, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 60)),
            'threshold_config' => json_encode([
                'cpu' => (float) (isset($_POST['cpu_threshold']) ? $_POST['cpu_threshold'] : 90),
                'memory' => (float) (isset($_POST['memory_threshold']) ? $_POST['memory_threshold'] : 90),
                'disk' => (float) (isset($_POST['disk_threshold']) ? $_POST['disk_threshold'] : 90),
            ], JSON_UNESCAPED_UNICODE),
            'status' => 'unknown',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        set_flash('success', '监控服务器已添加，建议先执行一次立即采集确认数据。');
        $this->redirect('monitor');
    }

    public function test()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->json(['success' => false, 'message' => '只有管理员可以测试运营服务器连接。'], 403);
        }

        $server = [
            'monitor_type' => 'bt',
            'panel_url' => isset($_POST['panel_url']) ? $_POST['panel_url'] : '',
            'api_key' => isset($_POST['api_key']) ? $_POST['api_key'] : '',
            'panel_port' => isset($_POST['panel_port']) ? $_POST['panel_port'] : null,
        ];

        try {
            $data = (new MonitorService())->test($server);
            $this->json(['success' => true, 'message' => '连接成功，已获取到服务器状态数据。', 'data' => $data]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function collect()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->json(['success' => false, 'message' => '只有管理员可以手动采集。'], 403);
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $server = $this->platformServer($id);
        if (!$server) {
            $this->json(['success' => false, 'message' => '服务器不存在。'], 404);
        }

        try {
            (new MonitorService())->collect($server);
            $this->json(['success' => true, 'message' => '采集完成，页面数据将刷新。']);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function cronCollect()
    {
        if (!$this->ensureMonitorReady()) {
            return;
        }
        $token = trim(isset($_GET['token']) ? $_GET['token'] : '');
        $saved = trim((string) setting('monitor_cron_token', ''));
        if ($saved === '' || $token === '' || !hash_equals($saved, $token)) {
            $this->json(['success' => false, 'message' => '监控采集密钥不正确。'], 403);
        }

        $force = isset($_GET['force']) && (string) $_GET['force'] === '1';
        $limit = max(1, min(50, (int) (isset($_GET['limit']) ? $_GET['limit'] : 20)));
        $table = Database::table('monitor_servers');
        $sql = 'SELECT * FROM ' . $table . ' WHERE monitor_type = \'bt\' AND is_enabled = 1';
        if (!$force) {
            $sql .= ' AND (last_checked_at IS NULL OR TIMESTAMPDIFF(SECOND, last_checked_at, NOW()) >= frequency)';
        }
        $sql .= ' ORDER BY last_checked_at IS NULL DESC, last_checked_at ASC, id ASC' . Database::limitClause($limit, 1, 50);
        $servers = Database::fetchAll($sql);

        $service = new MonitorService();
        $probeService = new ServiceProbeService();
        $result = [
            'success' => true,
            'message' => '监控采集任务已执行。',
            'time' => now(),
            'force' => $force,
            'total' => count($servers),
            'success_count' => 0,
            'failed_count' => 0,
            'items' => [],
        ];

        foreach ($servers as $server) {
            try {
                $service->collect($server);
                $probeResult = $probeService->collectForServer($server);
                $result['success_count']++;
                $result['items'][] = [
                    'id' => (int) $server['id'],
                    'name' => $server['name'],
                    'status' => 'online',
                    'message' => '采集成功',
                    'probes' => $probeResult,
                ];
            } catch (\Throwable $e) {
                $result['failed_count']++;
                $result['items'][] = [
                    'id' => (int) $server['id'],
                    'name' => $server['name'],
                    'status' => 'offline',
                    'message' => $e->getMessage(),
                ];
            }
        }

        $this->json($result);
    }

    public function show()
    {
        $this->requireLogin();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) $_GET['id'];
        $server = $this->platformServer($id);
        if (!$server) {
            http_response_code(404);
            echo '服务器不存在';
            return;
        }

        $this->view('monitor/show', [
            'title' => $server['name'],
            'server' => $server,
            'latest' => (new MonitorMetric())->latest($id),
            'alerts' => Database::fetchAll("SELECT * FROM " . Database::table('monitor_alerts') . " WHERE server_id = ? ORDER BY FIELD(status, 'unread', 'read', 'resolved'), id DESC LIMIT 20", [$id]),
            'history' => $this->historySummary($id),
        ]);
    }

    public function metrics()
    {
        $this->requireLogin();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->json(['success' => false, 'message' => '只有管理员可以读取运营服务器监控曲线。'], 403);
        }

        $id = (int) $_GET['id'];
        $range = isset($_GET['range']) ? $_GET['range'] : '1h';
        $server = $this->platformServer($id);
        if (!$server) {
            $this->json(['success' => false, 'message' => '服务器不存在或已被删除。'], 404);
        }

        $rows = (new MonitorMetric())->range($id, $range);
        $this->json(['success' => true, 'data' => $rows]);
    }

    public function alerts()
    {
        $this->requireLogin();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        $this->requireMonitorAlertAccess();

        $status = isset($_GET['status']) ? trim($_GET['status']) : '';
        $level = isset($_GET['level']) ? trim($_GET['level']) : '';
        $serverId = (int) (isset($_GET['server_id']) ? $_GET['server_id'] : 0);
        if (!in_array($status, ['', 'unread', 'read', 'resolved'], true)) {
            $status = '';
        }
        if (!in_array($level, ['', 'info', 'warning', 'danger'], true)) {
            $level = '';
        }

        $isAdmin = Auth::user()['role'] === 'admin';
        $monitorTypes = $isAdmin ? ['bt'] : ['ssh', 'agent'];
        $placeholders = implode(',', array_fill(0, count($monitorTypes), '?'));
        $sql = 'SELECT a.*, s.name AS server_name, s.monitor_type FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE s.monitor_type IN (' . $placeholders . ')';
        $params = $monitorTypes;
        if (!$isAdmin) {
            $sql .= ' AND s.user_id = ?';
            $params[] = Auth::id();
        }
        if ($status !== '') {
            $sql .= ' AND a.status = ?';
            $params[] = $status;
        }
        if ($level !== '') {
            $sql .= ' AND a.level = ?';
            $params[] = $level;
        }
        if ($serverId > 0) {
            $sql .= ' AND a.server_id = ?';
            $params[] = $serverId;
        }
        $sql .= " ORDER BY FIELD(a.status, 'unread', 'read', 'resolved'), a.id DESC LIMIT 300";

        $alerts = Database::fetchAll($sql, $params);
        $serverSql = 'SELECT id, name FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type IN (' . $placeholders . ')';
        $serverParams = $monitorTypes;
        if (!$isAdmin) {
            $serverSql .= ' AND user_id = ?';
            $serverParams[] = Auth::id();
        }
        $serverSql .= ' ORDER BY id DESC';
        $servers = Database::fetchAll($serverSql, $serverParams);
        $stats = [
            'total' => $this->countScopedAlerts($monitorTypes, $isAdmin ? 0 : Auth::id()),
            'unread' => $this->countScopedAlerts($monitorTypes, $isAdmin ? 0 : Auth::id(), "a.status = 'unread'"),
            'read' => $this->countScopedAlerts($monitorTypes, $isAdmin ? 0 : Auth::id(), "a.status = 'read'"),
            'resolved' => $this->countScopedAlerts($monitorTypes, $isAdmin ? 0 : Auth::id(), "a.status = 'resolved'"),
        ];

        $this->view('monitor/alerts', [
            'title' => '告警记录',
            'alerts' => $alerts,
            'servers' => $servers,
            'stats' => $stats,
            'filters' => ['status' => $status, 'level' => $level, 'server_id' => $serverId],
            'isAdminAlerts' => $isAdmin,
        ]);
    }

    public function markAlertRead()
    {
        $this->updateAlertStatus('read', null, '告警已标记为已读。');
    }

    public function resolveAlert()
    {
        $this->updateAlertStatus('resolved', now(), '告警已标记为已处理。');
    }

    protected function updateAlertStatus($status, $resolvedAt, $message)
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        $this->requireMonitorAlertAccess();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        if ($id <= 0) {
            set_flash('error', '告警记录不存在。');
            $this->back();
        }

        if (Auth::user()['role'] === 'admin') {
            $alert = Database::fetch('SELECT a.id FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE a.id = ? AND s.monitor_type = ? LIMIT 1', [$id, 'bt']);
        } else {
            $alert = Database::fetch('SELECT a.id FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE a.id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?) LIMIT 1', [$id, Auth::id(), 'ssh', 'agent']);
        }
        if (!$alert) {
            set_flash('error', '告警记录不存在或无权操作。');
            $this->back();
        }

        if ($status === 'resolved') {
            Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ?, resolved_at = ? WHERE id = ?', [$status, $resolvedAt, $id]);
        } else {
            Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ? WHERE id = ?', [$status, $id]);
        }
        set_flash('success', $message);
        $this->back();
    }

    protected function requireMonitorAlertAccess()
    {
        $user = Auth::user();
        if (!$user || (isset($user['role']) && $user['role'] === 'admin')) {
            return;
        }

        try {
            $package = Database::fetch(
                'SELECT allow_monitor FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1',
                [isset($user['package_id']) ? (int) $user['package_id'] : 0]
            );
            if ((new PermissionService())->featureAllowed($user, 'monitor', $package ?: [])) {
                return;
            }
        } catch (\Throwable $e) {
            // Keep the response user-facing; detailed errors are handled by the schema repair page.
        }

        set_flash('error', '当前账号没有服务器运维权限，请升级套餐或联系管理员开通。');
        $this->redirect('packages');
    }

    public function toggle()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) $_POST['id'];
        $server = $this->platformServer($id);
        if (!$server) {
            set_flash('error', '服务器不存在。');
            $this->redirect('monitor');
        }

        $enabled = (int) $server['is_enabled'] ? 0 : 1;
        Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET is_enabled = ?, updated_at = ? WHERE id = ? AND monitor_type = ?', [$enabled, now(), $id, 'bt']);
        set_flash('success', $enabled ? '监控已启用。' : '监控已暂停。');
        $this->redirect('monitor');
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureMonitorReady()) {
            return;
        }
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) $_POST['id'];
        $server = $this->platformServer($id);
        if (!$server) {
            set_flash('error', '服务器不存在。');
            $this->redirect('monitor');
        }

        Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ?', [$id, 'bt']);
        set_flash('success', '监控服务器已删除，历史数据也已清理。');
        $this->redirect('monitor');
    }

    protected function platformServer($id)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1',
            [(int) $id, 'bt']
        );
    }

    protected function countMonitorServers($where = '1=1')
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type = ? AND (' . $where . ')', ['bt']);
        return $row ? (int) $row['c'] : 0;
    }

    protected function countMonitorAlerts($where = '1=1')
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE s.monitor_type = ? AND (' . $where . ')', ['bt']);
        return $row ? (int) $row['c'] : 0;
    }

    protected function countScopedAlerts(array $monitorTypes, $userId = 0, $where = '1=1')
    {
        $placeholders = implode(',', array_fill(0, count($monitorTypes), '?'));
        $sql = 'SELECT COUNT(*) AS c FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE s.monitor_type IN (' . $placeholders . ')';
        $params = $monitorTypes;
        if ($userId > 0) {
            $sql .= ' AND s.user_id = ?';
            $params[] = (int) $userId;
        }
        $sql .= ' AND (' . $where . ')';
        $row = Database::fetch($sql, $params);
        return $row ? (int) $row['c'] : 0;
    }

    protected function historySummary($serverId)
    {
        $rows = Database::fetchAll(
            'SELECT cpu_usage, memory_usage, disk_usage, load_avg, uptime, created_at FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 6',
            [$serverId]
        );
        return array_reverse($rows);
    }
}
