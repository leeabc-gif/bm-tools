<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Announcement;
use App\Services\DatabaseUpgradeService;

class AnnouncementController extends Controller
{
    public function index()
    {
        if (!$this->announcementSchemaReady()) {
            $this->view('announcements/index', [
                'title' => '公告中心',
                'announcements' => [],
                'categories' => Announcement::categories(),
                'counts' => [],
                'siteDocuments' => [],
                'currentCategory' => '',
                'keyword' => '',
            ], 'layouts/announcement');
            return;
        }
        $model = new Announcement();
        $category = trim(isset($_GET['category']) ? $_GET['category'] : '');
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        if ($category === 'all') {
            $category = '';
        }
        $this->view('announcements/index', [
            'title' => '公告中心',
            'announcements' => $model->visibleByCategory($category, $keyword),
            'categories' => Announcement::categories(),
            'counts' => $model->categoryCounts(),
            'siteDocuments' => $model->siteDocuments(true),
            'currentCategory' => $category,
            'keyword' => $keyword,
        ], 'layouts/announcement');
    }

    public function show()
    {
        if (!$this->announcementSchemaReady()) {
            http_response_code(404);
            echo '公告数据结构未准备完成，请管理员进入后台「数据库巡检」执行一键修复。';
            return;
        }
        $model = new Announcement();
        $item = $model->find((int) $_GET['id']);
        if (!$item || (int) $item['status'] !== 1) {
            http_response_code(404);
            echo '公告不存在';
            return;
        }
        $model->incrementViews($item['id']);
        $item['view_count'] = (int) $item['view_count'] + 1;
        $this->view('announcements/show', [
            'title' => $item['title'],
            'item' => $item,
            'categories' => Announcement::categories(),
            'siteDocuments' => $model->siteDocuments(true),
        ], 'layouts/announcement');
    }

    protected function announcementSchemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureAnnouncementSchema();
        } catch (\Throwable $e) {
            return false;
        }
    }
}
