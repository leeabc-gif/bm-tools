<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Models\Coupon;
use App\Models\Package;
use App\Core\Database;
use App\Services\DatabaseUpgradeService;
use App\Services\PackageService;

class PackageController extends Controller
{
    public function index()
    {
        $marketingReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema']);
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema']);
        $payments = $this->safePayments();
        $this->view('packages/index', [
            'title' => '套餐',
            'packages' => (new Package())->enabled(),
            'coupons' => $marketingReady ? (new Coupon())->activeList() : [],
            'payments' => $payments,
        ]);
    }

    public function buy()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        try {
            $result = (new PackageService())->buy(
                Auth::id(),
                (int) $_POST['package_id'],
                isset($_POST['payment_method']) ? (string) $_POST['payment_method'] : 'balance',
                isset($_POST['coupon_code']) ? $_POST['coupon_code'] : ''
            );
            if ($result['mode'] === 'paid') {
                set_flash('success', '套餐购买成功。');
            } elseif (!empty($result['gateway']['redirect'])) {
                $_SESSION['alipay_qr'][$result['order']['order_no']] = isset($result['gateway']['qr_code']) ? $result['gateway']['qr_code'] : '';
                $this->redirect('pay/alipay/' . $result['order']['order_no']);
            } else {
                set_flash('success', isset($result['gateway']['message']) ? $result['gateway']['message'] : '套餐订单已创建，请继续完成支付。');
            }
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('packages');
    }

    protected function safeSchemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function safePayments()
    {
        try {
            return Database::fetchAll('SELECT * FROM ' . Database::table('payment_config') . ' WHERE is_enabled = 1 AND code IN (\'balance\',\'manual\',\'alipay\') ORDER BY sort_order ASC, id ASC');
        } catch (\Throwable $e) {
            return [];
        }
    }
}
