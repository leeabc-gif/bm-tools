<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Models\FileItem;
use App\Models\Folder;
use App\Models\StorageDriver;
use App\Services\FileService;
use App\Services\FileLogService;
use App\Services\FileTrashService;
use App\Services\DatabaseUpgradeService;
use App\Services\PermissionService;
use App\Services\RateLimitService;
use App\Services\RepositoryService;
use App\Services\StorageBackupService;
use App\Services\Storage\StorageManager;
use App\Services\UploadFailureService;
use App\Services\UploadLimitService;

class NetdiskController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $folderId = isset($_GET['folder_id']) ? (int) $_GET['folder_id'] : 0;
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $category = isset($_GET['category']) ? trim($_GET['category']) : '';
        if (!in_array($category, ['', 'image', 'document', 'archive', 'video', 'audio', 'other'], true)) {
            $category = '';
        }
        if (!$this->folderBelongsToUser($folderId, Auth::id())) {
            set_flash('error', '文件夹不存在或无权访问。');
            $this->redirect('netdisk');
        }
        $user = Auth::user();
        $this->view('netdisk/index', [
            'title' => '轻量网盘',
            'folderId' => $folderId,
            'folders' => (new Folder())->userFolders(Auth::id(), $folderId),
            'allFolders' => Database::fetchAll('SELECT * FROM ' . Database::table('file_folders') . ' WHERE user_id = ? ORDER BY parent_id ASC, name ASC', [Auth::id()]),
            'files' => (new FileItem())->searchUserFiles(Auth::id(), null, $folderId, $keyword, '', '', $category),
            'keyword' => $keyword,
            'category' => $category,
            'usage' => $this->usageSummary($user),
        ]);
    }

    public function createFolder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $name = trim(isset($_POST['name']) ? $_POST['name'] : '');
        $parentId = (int) (isset($_POST['parent_id']) ? $_POST['parent_id'] : 0);
        if ($name === '') {
            set_flash('error', '文件夹名称不能为空。');
            $this->redirect('netdisk');
        }
        if (!$this->folderBelongsToUser($parentId, Auth::id())) {
            set_flash('error', '父级文件夹不存在或无权访问。');
            $this->redirect('netdisk');
        }
        (new Folder())->create([
            'user_id' => Auth::id(),
            'parent_id' => $parentId,
            'name' => $name,
            'path' => '',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        set_flash('success', '文件夹已创建。');
        $this->redirect('netdisk?folder_id=' . $parentId);
    }

    public function deleteFolder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $folderId = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $folder = (new Folder())->find($folderId);
        if (!$folder || (int) $folder['user_id'] !== Auth::id()) {
            set_flash('error', '文件夹不存在。');
            $this->redirect('netdisk');
        }

        $childCount = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_folders') . ' WHERE user_id = ? AND parent_id = ?', [Auth::id(), $folderId]);
        if ($childCount && (int) $childCount['c'] > 0) {
            set_flash('error', '该文件夹包含子文件夹，请先处理子文件夹后再删除。');
            $this->redirect('netdisk?folder_id=' . $folder['parent_id']);
        }

        $files = Database::fetchAll('SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? AND folder_id = ?', [Auth::id(), $folderId]);
        foreach ($files as $file) {
            (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
        }
        Database::execute('DELETE FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ?', [$folderId, Auth::id()]);
        (new FileLogService())->log(Auth::id(), null, 'folder_delete', $folder['name'], 0, ['folder_id' => $folderId, 'files' => count($files)]);
        set_flash('success', '文件夹已删除，文件已移入回收站。');
        $this->redirect('netdisk?folder_id=' . $folder['parent_id']);
    }

    public function upload()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $wantsJson = $this->wantsJson();
        if (!$this->netdiskAllowed()) {
            $message = (new PermissionService())->message('netdisk');
            if ($wantsJson) {
                $this->json(['success' => false, 'message' => $message], 403);
            }
            set_flash('error', $message);
            $this->redirect('dashboard');
        }
        $folderId = (int) (isset($_POST['folder_id']) ? $_POST['folder_id'] : 0);
        $uploaded = [];
        $failureRecorder = new UploadFailureService();
        try {
            if (!$this->folderBelongsToUser($folderId, Auth::id())) {
                throw new \RuntimeException('目标文件夹不存在或无权访问。');
            }
            if (empty($_FILES['files'])) {
                throw new \RuntimeException('请选择文件。');
            }
            $files = $this->normalizeFiles($_FILES['files']);
            $limits = new UploadLimitService();
            $limits->assertBatchLimit('file', count($files));
            $service = new FileService();
            $failed = [];
            foreach ($files as $file) {
                $scope = 'file';
                $lock = null;
                $dailyLock = null;
                try {
                    $dailyLock = $limits->acquireDailyLimitSlot(Auth::id(), $scope);
                    $lock = $limits->acquireConcurrency(Auth::id());
                    $uploaded[] = $service->uploadForUser(Auth::user(), $file, $scope, $folderId);
                } catch (\Throwable $itemError) {
                    $failureRecorder->record(Auth::id(), $scope, $file, $itemError->getMessage(), ['folder_id' => $folderId]);
                    $failed[] = $file['name'] . '：' . $itemError->getMessage();
                    Logger::error('网盘上传失败：' . $itemError->getMessage(), [
                        'user_id' => Auth::id(),
                        'folder_id' => $folderId,
                        'file' => isset($file['name']) ? $file['name'] : '',
                        'size' => isset($file['size']) ? (int) $file['size'] : 0,
                    ]);
                    if ($wantsJson) {
                        break;
                    }
                } finally {
                    $limits->releaseConcurrency($lock);
                    $limits->releaseConcurrency($dailyLock);
                }
            }
            if ($wantsJson) {
                if ($uploaded) {
                    $this->json([
                        'success' => true,
                        'message' => '上传成功',
                        'files' => array_map([$this, 'uploadResponseFile'], $uploaded),
                    ]);
                }
                $message = $failed ? implode('；', $failed) : '上传没有返回成功结果，请检查上传限制、对象存储配置和运行日志。';
                $this->json([
                    'success' => false,
                ] + $this->uploadErrorPayload($message), 422);
            }
            if ($uploaded) {
                set_flash('success', '成功上传 ' . count($uploaded) . ' 个文件。');
            }
            if ($failed) {
                set_flash('error', '有 ' . count($failed) . ' 个文件上传失败：' . implode('；', array_slice($failed, 0, 3)) . (count($failed) > 3 ? '；更多失败请分批重试。' : ''));
            }
            if (!$uploaded && $failed) {
                $this->redirect('netdisk?folder_id=' . $folderId);
            }
        } catch (\Throwable $e) {
            $failureRecorder->record(Auth::id(), 'file', $this->emptyUploadFailureFile(), $e->getMessage(), ['folder_id' => $folderId]);
            Logger::error('网盘上传请求失败：' . $e->getMessage(), ['user_id' => Auth::id(), 'folder_id' => $folderId]);
            if ($wantsJson) {
                $this->json(['success' => false] + $this->uploadErrorPayload($e->getMessage()), 422);
            }
            set_flash('error', $e->getMessage());
        }
        $this->redirect('netdisk?folder_id=' . $folderId);
    }

    public function download()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }

        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $file = (new FileItem())->find($id);
        if (!$file || (int) $file['user_id'] !== Auth::id()) {
            set_flash('error', '文件不存在或无权下载。');
            $this->redirect('netdisk');
        }

        $folderId = (int) (isset($file['folder_id']) ? $file['folder_id'] : 0);
        $location = $this->publicFileLocation($file);
        if ($location === '') {
            set_flash('error', '文件链接不可用，请检查存储配置。');
            $this->redirect('netdisk?folder_id=' . $folderId);
        }

        Database::execute('UPDATE ' . Database::table('files') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $id]);
        (new FileLogService())->log(Auth::id(), $id, $file['file_type'] === 'image' ? 'image_download' : 'file_download', $file['original_name'], (int) $file['file_size'], [
            'source' => 'netdisk',
            'folder_id' => $folderId,
        ]);

        header('Location: ' . $location);
        exit;
    }

    public function batchDownload()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }

        $currentFolderId = (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0);
        $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (!$ids) {
            set_flash('error', '请选择要下载的文件。');
            $this->redirect('netdisk?folder_id=' . $currentFolderId);
        }
        if (count($ids) > 100) {
            set_flash('error', '批量下载一次最多选择 100 个文件，请分批处理。');
            $this->redirect('netdisk?folder_id=' . $currentFolderId);
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $params = array_merge([Auth::id()], $ids);
        $files = Database::fetchAll(
            'SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? AND id IN (' . $placeholders . ') ORDER BY id DESC',
            $params
        );
        if (!$files) {
            set_flash('error', '选中的文件不存在或无权下载。');
            $this->redirect('netdisk?folder_id=' . $currentFolderId);
        }

        $totalSize = 0;
        foreach ($files as &$file) {
            $totalSize += (int) $file['file_size'];
            $file['download_url'] = url('netdisk/download?id=' . (int) $file['id']);
            $file['public_url'] = public_url($file['file_url']);
            $file['can_download'] = $this->publicFileLocation($file) !== '';
        }
        unset($file);

        $this->view('netdisk/batch_download', [
            'title' => '批量下载',
            'files' => $files,
            'totalSize' => $totalSize,
            'currentFolderId' => $currentFolderId,
        ]);
    }

    public function rename()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $id = (int) $_POST['id'];
        $type = $_POST['type'];
        $name = trim($_POST['name']);
        if ($name === '') {
            set_flash('error', '名称不能为空。');
            $this->redirect('netdisk');
        }
        if ($type === 'folder') {
            $folder = (new Folder())->find($id);
            if ($folder && (int) $folder['user_id'] === Auth::id()) {
                (new Folder())->update($id, ['name' => $name, 'updated_at' => now()]);
            }
        } else {
            $file = (new FileItem())->find($id);
            if ($file && (int) $file['user_id'] === Auth::id()) {
                (new FileItem())->update($id, ['original_name' => $name, 'updated_at' => now()]);
            }
        }
        set_flash('success', '名称已更新。');
        $this->redirect('netdisk?folder_id=' . (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0));
    }

    public function move()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $fileId = (int) $_POST['file_id'];
        $folderId = (int) $_POST['folder_id'];
        $file = (new FileItem())->find($fileId);
        if (!$file || (int) $file['user_id'] !== Auth::id()) {
            set_flash('error', '文件不存在。');
            $this->redirect('netdisk');
        }
        if ($folderId > 0) {
            $folder = (new Folder())->find($folderId);
            if (!$folder || (int) $folder['user_id'] !== Auth::id()) {
                set_flash('error', '目标文件夹不存在。');
                $this->redirect('netdisk');
            }
        }
        (new FileItem())->update($fileId, ['folder_id' => $folderId, 'updated_at' => now()]);
        set_flash('success', '文件已移动。');
        $this->redirect('netdisk?folder_id=' . $folderId);
    }

    public function createShare()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        if (!$this->packageAllowsShare()) {
            set_flash('error', '当前套餐不支持文件分享。');
            $this->redirect('netdisk');
        }
        $fileId = (int) (isset($_POST['file_id']) ? $_POST['file_id'] : 0);
        $file = (new FileItem())->find($fileId);
        if (!$file || (int) $file['user_id'] !== Auth::id()) {
            set_flash('error', '文件不存在。');
            $this->redirect('netdisk');
        }
        $code = bin2hex(random_bytes(5));
        $expireDays = (int) (isset($_POST['expire_days']) ? $_POST['expire_days'] : 0);
        Database::execute(
            'INSERT INTO ' . Database::table('file_shares') . ' (user_id, file_id, share_code, extract_code, expire_at, download_limit, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
            [Auth::id(), $fileId, $code, trim(isset($_POST['extract_code']) ? $_POST['extract_code'] : ''), $expireDays > 0 ? date('Y-m-d H:i:s', time() + $expireDays * 86400) : null, (int) (isset($_POST['download_limit']) ? $_POST['download_limit'] : 0), 1, now(), now()]
        );
        set_flash('success', '分享链接已生成：' . public_url('share/' . $code));
        $this->redirect('shares');
    }

    public function shares()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $shareLogsReady = $this->shareLogSchemaReady();
        $shares = $shareLogsReady
            ? Database::fetchAll(
                'SELECT s.*, f.original_name, f.file_url,
                    (SELECT COUNT(*) FROM ' . Database::table('file_share_logs') . " l WHERE l.share_id = s.id AND l.action = 'view') AS view_count,
                    (SELECT COUNT(*) FROM " . Database::table('file_share_logs') . " l WHERE l.share_id = s.id AND l.action = 'download') AS download_log_count
                 FROM " . Database::table('file_shares') . ' s
                 LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id
                 WHERE s.user_id = ? ORDER BY s.id DESC',
                [Auth::id()]
            )
            : Database::fetchAll(
                'SELECT s.*, f.original_name, f.file_url, 0 AS view_count, 0 AS download_log_count
                 FROM ' . Database::table('file_shares') . ' s
                 LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id
                 WHERE s.user_id = ? ORDER BY s.id DESC',
                [Auth::id()]
            );
        $this->view('netdisk/shares', [
            'title' => '我的分享仓库',
            'shares' => $shares,
            'shareStats' => $this->shareStats($shares),
        ]);
    }

    public function repository()
    {
        $this->redirect('repository/files' . $this->repositoryQueryString(isset($_GET['id']) ? (int) $_GET['id'] : 0));
    }

    public function repositoryCreate()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        $repositories = $service->repositoriesForUser(Auth::id());
        $repo = $this->currentRepositoryFromQuery($service);
        if (!$repo && $repositories) {
            $repo = $repositories[0];
        }
        $this->view('netdisk/repository_create', [
            'title' => '分享仓库创建',
            'repositories' => $repositories,
            'repo' => $repo,
            'stats' => $repo ? $service->stats($repo) : null,
        ]);
    }

    public function repositoryFiles()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        $repo = $this->currentRepositoryOrRedirect($service, 'repository/create');
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $this->view('netdisk/repository_files', [
            'title' => '我的分享仓库列表',
            'repositories' => $service->repositoriesForUser(Auth::id()),
            'repo' => $repo,
            'publicLink' => public_url('r/' . $repo['slug']),
            'stats' => $service->stats($repo),
            'files' => $service->manageFiles($repo, $keyword),
            'keyword' => $keyword,
        ]);
    }

    public function repositorySettings()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        $repo = $this->currentRepositoryOrRedirect($service, 'repository/create');
        $stats = $service->stats($repo);
        $this->view('netdisk/repository_settings', [
            'title' => '链接与权限设置',
            'repositories' => $service->repositoriesForUser(Auth::id()),
            'repo' => $repo,
            'publicLink' => public_url('r/' . $repo['slug']),
            'stats' => $stats,
            'checklist' => $service->publishChecklist($repo, $stats),
        ]);
    }

    public function repositoryAccessLogs()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        $repo = $this->currentRepositoryOrRedirect($service, 'repository/create');
        $logFilters = [
            'action' => 'view',
            'keyword' => isset($_GET['log_keyword']) ? $_GET['log_keyword'] : '',
            'date_from' => isset($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to' => isset($_GET['date_to']) ? $_GET['date_to'] : '',
        ];
        $this->view('netdisk/repository_access_logs', [
            'title' => '访问日志',
            'repositories' => $service->repositoriesForUser(Auth::id()),
            'repo' => $repo,
            'stats' => $service->stats($repo),
            'logs' => $service->logs($repo, 120, $logFilters),
            'logFilters' => $logFilters,
        ]);
    }

    public function repositoryDownloadLogs()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        $repo = $this->currentRepositoryOrRedirect($service, 'repository/create');
        $logFilters = [
            'action' => 'download',
            'keyword' => isset($_GET['log_keyword']) ? $_GET['log_keyword'] : '',
            'date_from' => isset($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to' => isset($_GET['date_to']) ? $_GET['date_to'] : '',
        ];
        $this->view('netdisk/repository_download_logs', [
            'title' => '下载日志',
            'repositories' => $service->repositoriesForUser(Auth::id()),
            'repo' => $repo,
            'stats' => $service->stats($repo),
            'logs' => $service->logs($repo, 120, $logFilters),
            'logFilters' => $logFilters,
        ]);
    }

    public function createRepository()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        try {
            $repo = (new RepositoryService())->createRepository(Auth::user(), [
                'title' => isset($_POST['title']) ? $_POST['title'] : '',
                'slug' => isset($_POST['slug']) ? $_POST['slug'] : '',
            ]);
            set_flash('success', '新仓库已创建，请继续完善权限和文件。');
            $this->redirect('repository/settings?id=' . $repo['id']);
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
            $this->redirect('repository/create');
        }
    }

    public function saveRepository()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();

        try {
            $repo = $this->currentUserRepository($service);
            $service->saveRepository($repo, [
                'title' => isset($_POST['title']) ? $_POST['title'] : '',
                'slug' => isset($_POST['slug']) ? $_POST['slug'] : '',
                'description' => isset($_POST['description']) ? $_POST['description'] : '',
                'cover_image' => isset($_POST['cover_image']) ? $_POST['cover_image'] : '',
                'tags' => isset($_POST['tags']) ? $_POST['tags'] : '',
                'access_type' => isset($_POST['access_type']) ? $_POST['access_type'] : 'public',
                'password' => isset($_POST['password']) ? $_POST['password'] : '',
                'expire_at' => isset($_POST['expire_at']) ? $_POST['expire_at'] : '',
                'max_views' => isset($_POST['max_views']) ? $_POST['max_views'] : 0,
                'max_downloads' => isset($_POST['max_downloads']) ? $_POST['max_downloads'] : 0,
                'ip_daily_view_limit' => isset($_POST['ip_daily_view_limit']) ? $_POST['ip_daily_view_limit'] : 0,
                'ip_daily_download_limit' => isset($_POST['ip_daily_download_limit']) ? $_POST['ip_daily_download_limit'] : 0,
                'allow_download' => isset($_POST['allow_download']) ? $_POST['allow_download'] : 0,
                'show_owner' => isset($_POST['show_owner']) ? $_POST['show_owner'] : 0,
                'status' => isset($_POST['status']) ? $_POST['status'] : 0,
            ]);
            unset($_SESSION['repository_auth'][$repo['id']]);
            set_flash('success', '个人仓库设置已保存。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('repository/settings' . (isset($repo) && $repo ? '?id=' . $repo['id'] : ''));
    }

    public function saveRepositoryItem()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();

        try {
            $repo = $this->currentUserRepository($service);
            $service->saveItem(
                $repo,
                (int) (isset($_POST['file_id']) ? $_POST['file_id'] : 0),
                isset($_POST['visibility']) ? $_POST['visibility'] : 'public',
                isset($_POST['note']) ? $_POST['note'] : '',
                (int) (isset($_POST['sort_order']) ? $_POST['sort_order'] : 0)
            );
            set_flash('success', '仓库文件已更新。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('repository/files' . (isset($repo) && $repo ? '?id=' . $repo['id'] : ''));
    }

    public function removeRepositoryItem()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        try {
            $repo = $this->currentUserRepository($service);
            $service->removeItem($repo, (int) (isset($_POST['file_id']) ? $_POST['file_id'] : 0));
            set_flash('success', '文件已从个人仓库移除，原网盘文件不会删除。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('repository/files' . (isset($repo) && $repo ? '?id=' . $repo['id'] : ''));
    }

    public function deleteRepository()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();

        try {
            $repo = $this->currentUserRepository($service);
            $service->deleteRepository($repo);
            unset($_SESSION['repository_auth'][$repo['id']]);
            set_flash('success', '分享仓库已删除，原网盘文件仍然保留。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('repository/create');
    }

    public function batchRepositoryItems()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();

        try {
            $repo = $this->currentUserRepository($service);
            $ids = isset($_POST['file_ids']) ? (array) $_POST['file_ids'] : [];
            $action = isset($_POST['batch_action']) ? trim((string) $_POST['batch_action']) : '';
            if (!$ids) {
                throw new \RuntimeException('请先选择要处理的文件。');
            }
            if ($action === 'add_public') {
                $count = $service->batchSaveItems($repo, $ids, 'public');
                set_flash('success', '已批量加入 ' . $count . ' 个公开文件。');
            } elseif ($action === 'add_private') {
                $count = $service->batchSaveItems($repo, $ids, 'private');
                set_flash('success', '已批量加入 ' . $count . ' 个私密文件。');
            } elseif ($action === 'remove') {
                $count = $service->batchRemoveItems($repo, $ids);
                set_flash('success', '已从仓库移除 ' . $count . ' 个文件，原网盘文件不会删除。');
            } else {
                throw new \RuntimeException('请选择批量操作。');
            }
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        $this->redirect('repository/files' . (isset($repo) && $repo ? '?id=' . $repo['id'] : ''));
    }

    public function exportRepositoryLogs()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        $repo = $this->currentUserRepository($service, isset($_GET['id']) ? (int) $_GET['id'] : 0);
        $filters = [
            'action' => isset($_GET['log_action']) ? $_GET['log_action'] : '',
            'keyword' => isset($_GET['log_keyword']) ? $_GET['log_keyword'] : '',
            'date_from' => isset($_GET['date_from']) ? $_GET['date_from'] : '',
            'date_to' => isset($_GET['date_to']) ? $_GET['date_to'] : '',
        ];
        $rows = $service->logs($repo, 5000, $filters);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=repository-logs-' . $repo['id'] . '-' . date('YmdHis') . '.csv');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        fputcsv($out, ['时间', '行为', '文件', 'IP', '来源', 'User-Agent']);
        foreach ($rows as $row) {
            fputcsv($out, [$row['created_at'], $row['action'], $row['original_name'], $row['ip'], $row['referer'], $row['user_agent']]);
        }
        fclose($out);
        exit;
    }

    public function clearRepositoryLogs()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $service = new RepositoryService();
        try {
            $repo = $this->currentUserRepository($service);
            $count = $service->clearLogs($repo);
            set_flash('success', '已清空 ' . $count . ' 条仓库日志。');
            $this->redirect('repository/logs/access?id=' . $repo['id']);
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
            $this->redirect('repository/create');
        }
    }

    public function repositoryPublic()
    {
        $slug = trim(isset($_GET['slug']) ? $_GET['slug'] : '');
        $service = new RepositoryService();
        $repo = $service->findBySlug($slug);
        $availability = $this->repositoryAvailability($repo, $service, 'view');
        if (!$availability['ok']) {
            http_response_code($availability['status']);
            echo $availability['message'];
            return;
        }

        $locked = $this->repositoryLocked($repo);
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $service->log($repo, 'view');
        $service->incrementView($repo);
        $repo['view_count'] = (int) $repo['view_count'] + 1;

        $this->view('netdisk/repository_public', [
            'title' => $repo['title'],
            'repo' => $repo,
            'publicLink' => public_url('r/' . $repo['slug']),
            'locked' => $locked,
            'files' => $locked ? [] : $service->publicFiles($repo, $keyword),
            'stats' => $service->stats($repo),
            'keyword' => $keyword,
        ]);
    }

    public function repositoryAuth()
    {
        $this->verifyCsrf();
        $slug = trim(isset($_GET['slug']) ? $_GET['slug'] : '');
        $service = new RepositoryService();
        $repo = $service->findBySlug($slug);
        if (!$this->repositoryAvailable($repo)) {
            http_response_code(404);
            echo '仓库不存在或暂未公开';
            return;
        }

        $password = trim(isset($_POST['password']) ? $_POST['password'] : '');
        if ($repo['access_type'] !== 'password') {
            $this->redirect('r/' . $repo['slug']);
        }

        $limiter = new RateLimitService();
        $identity = 'repo:' . $repo['id'] . ':ip:' . Auth::ip();
        $check = $limiter->check('repository_password', $identity, 600);
        if (!empty($check['limited'])) {
            $service->log($repo, 'blocked');
            set_flash('error', '密码尝试过于频繁，请稍后再试。');
            $this->redirect('r/' . $repo['slug']);
        }

        if (!empty($repo['password_hash']) && password_verify($password, $repo['password_hash'])) {
            $_SESSION['repository_auth'][$repo['id']] = 1;
            $limiter->clear('repository_password', $identity);
            $service->log($repo, 'auth_success');
            set_flash('success', '访问密码正确。');
        } else {
            $limiter->hit('repository_password', $identity, 10, 600, 900, Auth::ip(), Auth::ip());
            $service->log($repo, 'auth_fail');
            set_flash('error', '访问密码错误，请重新输入。');
        }
        $this->redirect('r/' . $repo['slug']);
    }

    public function repositoryDownload()
    {
        $slug = trim(isset($_GET['slug']) ? $_GET['slug'] : '');
        $fileId = (int) (isset($_GET['file_id']) ? $_GET['file_id'] : 0);
        $service = new RepositoryService();
        $repo = $service->findBySlug($slug);
        $availability = $this->repositoryAvailability($repo, $service, 'download');
        if (!$availability['ok']) {
            http_response_code($availability['status']);
            echo $availability['message'];
            return;
        }
        if ($this->repositoryLocked($repo)) {
            set_flash('error', '请先输入访问密码。');
            $this->redirect('r/' . $repo['slug']);
        }
        if (empty($repo['allow_download'])) {
            set_flash('error', '仓库主人暂未开放下载。');
            $this->redirect('r/' . $repo['slug']);
        }

        $file = $service->publicFile($repo, $fileId);
        if (!$file || empty($file['file_url'])) {
            http_response_code(404);
            echo '文件不存在或暂未公开';
            return;
        }

        $service->incrementDownload($repo, $fileId);
        $service->log($repo, 'download', $fileId);
        $location = $this->publicPathLocation($file['file_url']);
        if ($location === '') {
            http_response_code(404);
            echo '文件链接不可用。';
            return;
        }
        header('Location: ' . $location);
        exit;
    }

    public function repositoryDownloadZip()
    {
        $slug = trim(isset($_GET['slug']) ? $_GET['slug'] : '');
        $service = new RepositoryService();
        $repo = $service->findBySlug($slug);
        $availability = $this->repositoryAvailability($repo, $service, 'download');
        if (!$availability['ok']) {
            http_response_code($availability['status']);
            echo $availability['message'];
            return;
        }
        if ($this->repositoryLocked($repo)) {
            set_flash('error', '请先输入访问密码。');
            $this->redirect('r/' . $repo['slug']);
        }
        if (empty($repo['allow_download'])) {
            set_flash('error', '仓库主人暂未开放下载。');
            $this->redirect('r/' . $repo['slug']);
        }
        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            echo '当前服务器未启用 ZipArchive，暂不支持打包下载。';
            return;
        }

        $files = $service->publicFiles($repo);
        $zipFiles = [];
        foreach ($files as $file) {
            $path = $this->localRepositoryFilePath($file);
            if ($path) {
                $zipFiles[] = ['file' => $file, 'path' => $path];
            }
        }
        if (!$zipFiles) {
            http_response_code(400);
            echo '当前仓库没有可打包的本地文件，请使用单个文件下载。';
            return;
        }

        if ((int) $repo['max_downloads'] > 0 && ((int) $repo['download_count'] + count($zipFiles)) > (int) $repo['max_downloads']) {
            $service->log($repo, 'blocked');
            http_response_code(429);
            echo '仓库剩余下载次数不足，无法打包下载。';
            return;
        }
        if ((int) $repo['ip_daily_download_limit'] > 0 && ($service->dailyIpCount($repo, 'download') + count($zipFiles)) > (int) $repo['ip_daily_download_limit']) {
            $service->log($repo, 'blocked');
            http_response_code(429);
            echo '今日下载次数不足，无法打包下载。';
            return;
        }

        $dir = APP_ROOT . '/storage/repository_zips';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $zipPath = $dir . '/repository-' . $repo['id'] . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(4)) . '.zip';
        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            http_response_code(500);
            echo '打包文件创建失败，请检查 storage 目录写入权限和当天运行日志。';
            return;
        }

        $usedNames = [];
        foreach ($zipFiles as $index => $item) {
            $entryName = $this->zipEntryName($item['file'], $index + 1, $usedNames);
            $zip->addFile($item['path'], $entryName);
        }
        $zip->close();

        foreach ($zipFiles as $item) {
            $service->incrementDownload($repo, (int) $item['file']['id']);
            $service->log($repo, 'download', (int) $item['file']['id']);
        }

        $downloadName = preg_replace('/[^A-Za-z0-9_\-\x{4e00}-\x{9fa5}]+/u', '-', $repo['title']);
        $downloadName = trim($downloadName, '-_') ?: 'repository';
        $fallbackName = preg_replace('/[^A-Za-z0-9_-]+/', '-', $downloadName);
        $fallbackName = trim($fallbackName, '-_') ?: 'repository';
        header('Content-Type: application/zip');
        header('Content-Length: ' . filesize($zipPath));
        header('Content-Disposition: attachment; filename="' . $fallbackName . '.zip"; filename*=UTF-8\'\'' . rawurlencode($downloadName) . '.zip');
        readfile($zipPath);
        @unlink($zipPath);
        exit;
    }

    public function recycle()
    {
        $this->requireLogin();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $items = (new FileTrashService())->userTrash(Auth::id());
        foreach ($items as &$item) {
            $snapshot = json_decode((string) $item['snapshot'], true);
            $item['file'] = is_array($snapshot) ? $snapshot : [];
        }
        $this->view('netdisk/recycle', ['title' => '回收站', 'items' => $items]);
    }

    public function shareStatus()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $id = (int) $_POST['id'];
        $status = (int) $_POST['status'];
        Database::execute('UPDATE ' . Database::table('file_shares') . ' SET status = ?, updated_at = ? WHERE id = ? AND user_id = ?', [$status ? 1 : 0, now(), $id, Auth::id()]);
        set_flash('success', '分享状态已更新。');
        $this->redirect('shares');
    }

    public function shareView()
    {
        $this->shareLogSchemaReady();
        $code = isset($_GET['code']) ? $_GET['code'] : '';
        $share = Database::fetch('SELECT f.*, s.id AS share_id, s.user_id AS share_user_id, s.file_id AS file_id, s.share_code, s.extract_code, s.expire_at, s.download_limit, s.download_count, s.status AS share_status, s.created_at AS share_created_at FROM ' . Database::table('file_shares') . ' s LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id WHERE s.share_code = ? AND s.status = 1 LIMIT 1', [$code]);
        if (!$this->shareAvailable($share)) {
            if ($share) {
                $this->shareLog($share, !empty($share['expire_at']) && strtotime($share['expire_at']) < time() ? 'expired' : 'blocked');
            }
            http_response_code(404);
            echo '分享不存在或已过期';
            return;
        }
        $inputCode = isset($_GET['extract_code']) ? trim($_GET['extract_code']) : '';
        $locked = !empty($share['extract_code']) && $inputCode !== $share['extract_code'];
        if ($locked && $inputCode !== '' && $this->shareCodeLimited($share)) {
            set_flash('error', '提取码尝试过于频繁，请稍后再试。');
            $this->redirect('share/' . $code);
        }
        if ($locked && $inputCode !== '') {
            $this->hitShareCodeFailure($share);
        } elseif (!$locked) {
            $this->clearShareCodeFailure($share);
        }
        $this->shareLog($share, ($locked && $inputCode !== '') ? 'auth_fail' : 'view');
        $this->view('netdisk/share_view', [
            'title' => '文件分享',
            'share' => $share,
            'locked' => $locked,
            'extractCode' => $inputCode,
        ]);
    }

    public function shareDownload()
    {
        $this->shareLogSchemaReady();
        $code = isset($_GET['code']) ? $_GET['code'] : '';
        $share = Database::fetch('SELECT s.*, s.id AS share_id, f.file_url FROM ' . Database::table('file_shares') . ' s LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id WHERE s.share_code = ? AND s.status = 1 LIMIT 1', [$code]);
        if (!$this->shareAvailable($share)) {
            if ($share) {
                $this->shareLog($share, !empty($share['expire_at']) && strtotime($share['expire_at']) < time() ? 'expired' : 'blocked');
            }
            http_response_code(404);
            echo '分享不存在、已过期或下载次数已达上限';
            return;
        }
        $inputCode = isset($_GET['extract_code']) ? trim($_GET['extract_code']) : '';
        if (!empty($share['extract_code']) && $inputCode !== $share['extract_code']) {
            if ($this->shareCodeLimited($share)) {
                $this->shareLog($share, 'blocked');
                set_flash('error', '提取码尝试过于频繁，请稍后再试。');
                $this->redirect('share/' . $code);
            }
            $this->hitShareCodeFailure($share);
            $this->shareLog($share, 'auth_fail');
            set_flash('error', '提取码错误。');
            $this->redirect('share/' . $code);
        }
        $this->clearShareCodeFailure($share);
        Database::execute('UPDATE ' . Database::table('file_shares') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $share['id']]);
        Database::execute('UPDATE ' . Database::table('files') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $share['file_id']]);
        $this->shareLog($share, 'download');
        $location = $this->publicPathLocation($share['file_url']);
        if ($location === '') {
            http_response_code(404);
            echo '文件链接不可用。';
            return;
        }
        header('Location: ' . $location);
        exit;
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $id = (int) $_POST['id'];
        $file = (new FileItem())->find($id);
        if ($file && (int) $file['user_id'] === Auth::id()) {
            (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
            set_flash('success', '文件已移入回收站。');
        }
        $this->redirect('netdisk?folder_id=' . (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0));
    }

    public function batchDelete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
        $currentFolderId = (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0);
        if (!$ids) {
            set_flash('error', '请选择要删除的文件。');
            $this->redirect('netdisk?folder_id=' . $currentFolderId);
        }

        $count = 0;
        foreach ($ids as $id) {
            $file = (new FileItem())->find((int) $id);
            if ($file && (int) $file['user_id'] === Auth::id()) {
                (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
                $count++;
            }
        }
        set_flash('success', '已将 ' . $count . ' 个文件移入回收站。');
        $this->redirect('netdisk?folder_id=' . $currentFolderId);
    }

    public function restore()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        try {
            (new FileTrashService())->restore((int) $_POST['id'], Auth::id());
            set_flash('success', '文件已恢复。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('netdisk/recycle');
    }

    public function purge()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->netdiskAllowed()) {
            set_flash('error', (new PermissionService())->message('netdisk'));
            $this->redirect('dashboard');
        }
        try {
            $self = $this;
            (new FileTrashService())->purge((int) $_POST['id'], Auth::id(), function ($file) use ($self) {
                $self->deleteRemoteObject($file);
            });
            set_flash('success', '文件已彻底删除。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('netdisk/recycle');
    }

    protected function normalizeFiles(array $files)
    {
        $normalized = [];
        if (is_array($files['name'])) {
            foreach ($files['name'] as $i => $name) {
                $normalized[] = [
                    'name' => $name,
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i],
                ];
            }
        } else {
            $normalized[] = $files;
        }
        return $normalized;
    }

    protected function wantsJson()
    {
        $accept = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
        $xhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) : '';
        return $xhr === 'xmlhttprequest' || stripos($accept, 'application/json') !== false || !empty($_POST['ajax_upload']);
    }

    protected function uploadResponseFile(array $file)
    {
        $url = public_url(isset($file['file_url']) ? $file['file_url'] : '');
        $thumbnailUrl = public_url(isset($file['thumbnail_url']) && $file['thumbnail_url'] ? $file['thumbnail_url'] : (isset($file['file_url']) ? $file['file_url'] : ''));
        return [
            'id' => (int) (isset($file['id']) ? $file['id'] : 0),
            'name' => isset($file['original_name']) ? $file['original_name'] : '',
            'size' => (int) (isset($file['file_size']) ? $file['file_size'] : 0),
            'type' => isset($file['file_type']) ? $file['file_type'] : 'file',
            'url' => $url,
            'thumbnail_url' => $thumbnailUrl,
        ];
    }

    protected function uploadErrorPayload($message)
    {
        $payload = (new UploadFailureService())->payload($message);
        if ($payload['error_type'] === 'php_upload_limit') {
            $payload['repair_url'] = url('admin/maintenance/environment');
        } elseif ($payload['error_type'] === 'quota_or_permission') {
            $payload['repair_url'] = url('packages');
        } elseif (in_array($payload['error_type'], ['storage_config', 'storage_upload', 'storage_url', 'storage_delete'], true)) {
            $payload['storage_url'] = url('admin/storages');
            $payload['repair_url'] = url('admin/storages');
        } elseif (in_array($payload['error_type'], ['schema', 'storage_db'], true)) {
            $payload['repair_url'] = url('admin/maintenance/schema-audit');
        }
        return $payload;
    }

    protected function emptyUploadFailureFile()
    {
        return [
            'name' => '',
            'size' => 0,
            'type' => '',
            'tmp_name' => '',
            'error' => 0,
        ];
    }

    protected function publicFileLocation(array $file)
    {
        return $this->publicPathLocation(isset($file['file_url']) ? $file['file_url'] : '');
    }

    protected function publicPathLocation($path)
    {
        $url = public_url($path);
        if ($url === '' || preg_match('/[\r\n]/', $url) || !preg_match('#^https?://#i', $url)) {
            return '';
        }
        return $url;
    }

    protected function repositoryAvailable($repo)
    {
        return $repo && (int) $repo['status'] === 1 && (int) $repo['admin_status'] === 1 && $repo['access_type'] !== 'private';
    }

    protected function repositoryLocked($repo)
    {
        return $repo['access_type'] === 'password' && empty($_SESSION['repository_auth'][$repo['id']]);
    }

    protected function repositoryAvailability($repo, RepositoryService $service, $scene)
    {
        if (!$repo) {
            return ['ok' => false, 'status' => 404, 'message' => '仓库不存在或暂未公开'];
        }
        if ((int) $repo['admin_status'] !== 1) {
            $service->log($repo, 'blocked');
            return ['ok' => false, 'status' => 403, 'message' => '该仓库已被平台下架'];
        }
        if ((int) $repo['status'] !== 1 || $repo['access_type'] === 'private') {
            return ['ok' => false, 'status' => 404, 'message' => '仓库不存在或暂未公开'];
        }
        if (!empty($repo['expire_at']) && strtotime($repo['expire_at']) < time()) {
            $service->log($repo, 'expired');
            return ['ok' => false, 'status' => 410, 'message' => '仓库链接已过期'];
        }
        if ($scene === 'view') {
            if ((int) $repo['max_views'] > 0 && (int) $repo['view_count'] >= (int) $repo['max_views']) {
                $service->log($repo, 'blocked');
                return ['ok' => false, 'status' => 429, 'message' => '仓库访问次数已达上限'];
            }
            if ((int) $repo['ip_daily_view_limit'] > 0 && $service->dailyIpCount($repo, 'view') >= (int) $repo['ip_daily_view_limit']) {
                $service->log($repo, 'blocked');
                return ['ok' => false, 'status' => 429, 'message' => '今日访问次数已达上限，请明天再试'];
            }
        }
        if ($scene === 'download') {
            if ((int) $repo['max_downloads'] > 0 && (int) $repo['download_count'] >= (int) $repo['max_downloads']) {
                $service->log($repo, 'blocked');
                return ['ok' => false, 'status' => 429, 'message' => '仓库下载次数已达上限'];
            }
            if ((int) $repo['ip_daily_download_limit'] > 0 && $service->dailyIpCount($repo, 'download') >= (int) $repo['ip_daily_download_limit']) {
                $service->log($repo, 'blocked');
                return ['ok' => false, 'status' => 429, 'message' => '今日下载次数已达上限，请明天再试'];
            }
        }
        return ['ok' => true, 'status' => 200, 'message' => 'ok'];
    }

    protected function currentUserRepository(RepositoryService $service, $id = null)
    {
        $repoId = $id !== null ? (int) $id : (int) (isset($_POST['repository_id']) ? $_POST['repository_id'] : 0);
        if ($repoId > 0) {
            $repo = $service->findUserRepository(Auth::id(), $repoId);
            if (!$repo) {
                throw new \RuntimeException('仓库不存在或不属于你。');
            }
            return $repo;
        }
        return $service->repositoryForUser(Auth::user());
    }

    protected function currentRepositoryFromQuery(RepositoryService $service)
    {
        $repoId = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        if ($repoId > 0) {
            return $service->findUserRepository(Auth::id(), $repoId);
        }
        return null;
    }

    protected function currentRepositoryOrRedirect(RepositoryService $service, $fallback)
    {
        $repo = $this->currentRepositoryFromQuery($service);
        if ($repo) {
            return $repo;
        }
        $repositories = $service->repositoriesForUser(Auth::id());
        if ($repositories) {
            return $repositories[0];
        }
        set_flash('error', '请先创建一个分享仓库。');
        $this->redirect($fallback);
    }

    protected function repositoryQueryString($id)
    {
        return (int) $id > 0 ? '?id=' . (int) $id : '';
    }

    protected function shareStats(array $shares)
    {
        $stats = [
            'total' => count($shares),
            'enabled' => 0,
            'views' => 0,
            'downloads' => 0,
        ];
        foreach ($shares as $share) {
            if (!empty($share['status'])) {
                $stats['enabled']++;
            }
            $stats['views'] += (int) (isset($share['view_count']) ? $share['view_count'] : 0);
            $stats['downloads'] += (int) (isset($share['download_log_count']) ? $share['download_log_count'] : 0);
        }
        return $stats;
    }

    protected function deleteRemoteObject(array $file)
    {
        if (empty($file['storage_id'])) {
            return;
        }
        try {
            $storage = (new StorageDriver())->find((int) $file['storage_id']);
            if ($storage) {
                (new StorageBackupService())->deleteBackupsForFile($file);
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Throwable $e) {
            \App\Core\Logger::error('远程文件删除失败：' . $e->getMessage(), ['file_id' => $file['id']]);
        }
    }

    protected function packageAllowsShare()
    {
        $user = Auth::user();
        $package = Database::fetch('SELECT allow_share FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        return $package && (int) $package['allow_share'] === 1;
    }

    protected function netdiskAllowed()
    {
        return (new PermissionService())->featureAllowed(Auth::user(), 'netdisk');
    }

    protected function usageSummary(array $user)
    {
        $count = Database::fetch('SELECT COUNT(*) AS c, COALESCE(SUM(file_size),0) AS s FROM ' . Database::table('files') . ' WHERE user_id = ?', [$user['id']]);
        $folderCount = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_folders') . ' WHERE user_id = ?', [$user['id']]);
        $package = Database::fetch('SELECT name, single_file_limit, allow_image, allow_netdisk, allow_api, allow_share, allow_video_preview FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        $total = (int) $user['total_storage'];
        $used = (int) $user['used_storage'];
        $percent = $total > 0 ? min(100, round($used / $total * 100, 2)) : 0;
        return [
            'package' => $package ?: ['name' => '默认套餐', 'single_file_limit' => 0, 'allow_share' => 0, 'allow_video_preview' => 0],
            'file_count' => (int) $count['c'],
            'folder_count' => (int) $folderCount['c'],
            'file_size' => (int) $count['s'],
            'used_storage' => $used,
            'total_storage' => $total,
            'free_storage' => max(0, $total - $used),
            'storage_percent' => $percent,
            'is_near_limit' => $total > 0 && $percent >= 80,
        ];
    }

    protected function shareAvailable($share)
    {
        if (!$share) {
            return false;
        }
        if (!empty($share['expire_at']) && strtotime($share['expire_at']) < time()) {
            return false;
        }
        if ((int) $share['download_limit'] > 0 && (int) $share['download_count'] >= (int) $share['download_limit']) {
            return false;
        }
        return true;
    }

    protected function shareLog($share, $action)
    {
        if (!$share) {
            return;
        }
        $allowed = ['view', 'download', 'auth_fail', 'blocked', 'expired'];
        if (!in_array($action, $allowed, true)) {
            $action = 'view';
        }
        try {
            if (!$this->shareLogSchemaReady()) {
                return;
            }
            Database::execute(
                'INSERT INTO ' . Database::table('file_share_logs') . ' (share_id, user_id, file_id, action, ip, user_agent, referer, created_at) VALUES (?,?,?,?,?,?,?,?)',
                [
                    (int) (isset($share['share_id']) ? $share['share_id'] : $share['id']),
                    (int) (isset($share['share_user_id']) ? $share['share_user_id'] : $share['user_id']),
                    (int) $share['file_id'],
                    $action,
                    Auth::ip(),
                    substr(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 0, 255),
                    substr(isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '', 0, 500),
                    now(),
                ]
            );
        } catch (\Throwable $e) {
            \App\Core\Logger::error('文件分享日志写入失败：' . $e->getMessage());
        }
    }

    protected function shareLogSchemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureShareLogSchema();
        } catch (\Throwable $e) {
            \App\Core\Logger::error('文件分享日志结构检查失败：' . $e->getMessage());
            return false;
        }
    }

    protected function shareCodeLimited($share)
    {
        $check = (new RateLimitService())->check('share_extract_code', $this->shareCodeIdentity($share), 600);
        return !empty($check['limited']);
    }

    protected function hitShareCodeFailure($share)
    {
        (new RateLimitService())->hit('share_extract_code', $this->shareCodeIdentity($share), 8, 600, 900, 'share:' . $this->shareId($share), Auth::ip());
    }

    protected function clearShareCodeFailure($share)
    {
        (new RateLimitService())->clear('share_extract_code', $this->shareCodeIdentity($share));
    }

    protected function shareCodeIdentity($share)
    {
        return 'share:' . $this->shareId($share) . ':ip:' . Auth::ip();
    }

    protected function shareId($share)
    {
        return (int) (isset($share['share_id']) ? $share['share_id'] : $share['id']);
    }

    protected function localRepositoryFilePath(array $file)
    {
        if (empty($file['file_path'])) {
            return '';
        }
        $driver = null;
        if (!empty($file['storage_id'])) {
            $driver = Database::fetch('SELECT type FROM ' . Database::table('storage_drivers') . ' WHERE id = ? LIMIT 1', [(int) $file['storage_id']]);
        }
        if ($driver && $driver['type'] !== 'local') {
            return '';
        }
        $root = realpath(APP_ROOT . '/public');
        if ($root === false) {
            return '';
        }
        $path = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($file['file_path'], '/'));
        $real = realpath($path);
        if ($real === false || strpos($real, $root) !== 0 || !is_file($real)) {
            return '';
        }
        return $real;
    }

    protected function zipEntryName(array $file, $index, array &$usedNames)
    {
        $name = trim((string) (isset($file['original_name']) ? $file['original_name'] : 'file'));
        if ($name === '') {
            $name = 'file-' . $index;
        }
        $name = preg_replace('/[\\\\\/:*?"<>|]+/', '-', $name);
        $name = preg_replace('/\s+/', ' ', $name);
        $name = trim($name);
        if ($name === '') {
            $name = 'file-' . $index;
        }
        $base = $name;
        $i = 1;
        while (isset($usedNames[$name])) {
            $ext = pathinfo($base, PATHINFO_EXTENSION);
            $stem = $ext ? substr($base, 0, -(strlen($ext) + 1)) : $base;
            $name = $stem . '-' . $i . ($ext ? '.' . $ext : '');
            $i++;
        }
        $usedNames[$name] = true;
        return $name;
    }

    protected function folderBelongsToUser($folderId, $userId)
    {
        $folderId = (int) $folderId;
        if ($folderId === 0) {
            return true;
        }
        return Database::fetch('SELECT id FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ? LIMIT 1', [$folderId, $userId]) !== null;
    }
}
