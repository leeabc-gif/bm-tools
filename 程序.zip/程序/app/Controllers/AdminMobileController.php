<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Core\Validator;
use App\Models\Announcement;
use App\Models\Coupon;
use App\Models\Package;
use App\Models\StorageDriver;
use App\Models\User;
use App\Services\BalanceService;
use App\Services\AlertWebhookService;
use App\Services\CryptoService;
use App\Services\DatabaseUpgradeService;
use App\Services\Monitor\MonitorService;
use App\Services\NotificationService;
use App\Services\Payment\PaymentService;
use App\Services\RepositoryService;
use App\Services\RedeemCardService;
use App\Services\Storage\StorageManager;
use App\Services\Storage\StorageTestService;
use App\Services\StorageBackupService;
use App\Services\StorageMigrationService;
use App\Services\SubsiteService;
use App\Services\UploadLimitService;

class AdminMobileController extends Controller
{
    protected function mobileView($view, array $data = [])
    {
        $this->requireAdmin();
        $views = [
            'dashboard' => 'admin_mobile/dashboard',
            'users' => 'admin_mobile/users',
            'files' => 'admin_mobile/files',
            'orders' => 'admin_mobile/orders',
            'packages' => 'admin_mobile/packages',
            'coupons' => 'admin_mobile/coupons',
            'cards' => 'admin_mobile/cards',
            'payments' => 'admin_mobile/payments',
            'storages' => 'admin_mobile/storages',
            'storage_backups' => 'admin_mobile/storage_backups',
            'repositories' => 'admin_mobile/repositories',
            'subsites' => 'admin_mobile/subsites',
            'servers' => 'admin_mobile/servers',
            'logs' => 'admin_mobile/logs',
            'incidents' => 'admin_mobile/incidents',
            'announcements' => 'admin_mobile/announcements',
            'upload_limits' => 'admin_mobile/upload_limits',
            'settings' => 'admin_mobile/settings',
            'schema_audit' => 'admin_mobile/schema_audit',
            'menu' => 'admin_mobile/menu',
        ];
        $this->view(isset($views[$view]) ? $views[$view] : 'admin_mobile/dashboard', $data, 'layouts/mobile_admin');
    }

    public function dashboard()
    {
        $this->prepareSchemas();
        $this->mobileView('dashboard', [
            'title' => '移动运营台',
            'stats' => $this->dashboardStats(),
            'todos' => $this->todos(),
            'opsAlerts' => $this->mobileOpsAlerts(),
            'recentOrders' => $this->safeRows('SELECT o.*, u.username, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC LIMIT 8'),
        ]);
    }

    public function users()
    {
        $this->mobileView('users', [
            'title' => '用户',
            'users' => $this->safeRows('SELECT u.*, p.name AS package_name FROM ' . Database::table('users') . ' u LEFT JOIN ' . Database::table('packages') . ' p ON u.package_id = p.id ORDER BY u.id DESC LIMIT 80'),
            'packages' => $this->safeRows('SELECT id, name, storage_limit, traffic_limit, duration_type, duration_days FROM ' . Database::table('packages') . ' ORDER BY sort_order ASC, id ASC LIMIT 100'),
            'stats' => [
                'total' => $this->safeCount('users'),
                'today' => $this->safeCount('users', 'DATE(created_at) = CURDATE()'),
                'disabled' => $this->safeCount('users', 'status = 0'),
            ],
        ]);
    }

    public function files()
    {
        $this->mobileView('files', [
            'title' => '文件',
            'files' => $this->safeRows('SELECT f.*, u.username FROM ' . Database::table('files') . ' f LEFT JOIN ' . Database::table('users') . ' u ON f.user_id = u.id ORDER BY f.id DESC LIMIT 80'),
            'stats' => [
                'total' => $this->safeCount('files'),
                'images' => $this->safeCount('files', "file_type = 'image'"),
                'netdisk' => $this->safeCount('files', "file_type = 'file'"),
                'size' => $this->safeScalar('SELECT COALESCE(SUM(file_size),0) AS v FROM ' . Database::table('files')),
            ],
        ]);
    }

    public function orders()
    {
        $this->mobileView('orders', [
            'title' => '订单',
            'orders' => $this->safeRows('SELECT o.*, u.username, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC LIMIT 80'),
            'recharges' => $this->safeRows('SELECT r.*, u.username FROM ' . Database::table('recharges') . ' r LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id ORDER BY r.id DESC LIMIT 40'),
            'stats' => [
                'pending_orders' => $this->safeCount('orders', "status = 'pending'"),
                'paid_orders' => $this->safeCount('orders', "status = 'paid'"),
                'pending_recharges' => $this->safeCount('recharges', "status = 'pending'"),
            ],
        ]);
    }

    public function packages()
    {
        $schemaReady = $this->ensureMobileSubsiteSchema();
        if (!$schemaReady) {
            $this->mobileSchemaFlash('套餐分站权益');
        }
        $this->mobileView('packages', [
            'title' => '套餐',
            'packages' => $this->safeRows('SELECT * FROM ' . Database::table('packages') . ' ORDER BY sort_order ASC, id ASC LIMIT 120'),
            'stats' => [
                'total' => $this->safeCount('packages'),
                'enabled' => $this->safeCount('packages', 'status = 1'),
                'paid' => $this->safeCount('packages', 'price > 0'),
            ],
        ]);
    }

    public function coupons()
    {
        if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动')) {
            $this->mobileSchemaFlash('营销活动');
        }
        $this->mobileView('coupons', [
            'title' => '营销活动',
            'coupons' => $this->safeRows('SELECT * FROM ' . Database::table('coupons') . ' ORDER BY sort_order ASC, id DESC LIMIT 80'),
            'packages' => $this->safeRows('SELECT id, name FROM ' . Database::table('packages') . ' ORDER BY sort_order ASC, id ASC LIMIT 100'),
            'redemptions' => $this->safeRows('SELECT r.*, c.title AS coupon_title, c.code AS coupon_code, u.username, o.order_no, p.name AS package_name FROM ' . Database::table('coupon_redemptions') . ' r LEFT JOIN ' . Database::table('coupons') . ' c ON r.coupon_id = c.id LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id LEFT JOIN ' . Database::table('orders') . ' o ON r.order_id = o.id LEFT JOIN ' . Database::table('packages') . ' p ON r.package_id = p.id ORDER BY r.id DESC LIMIT 20'),
            'stats' => [
                'total' => $this->safeCount('coupons'),
                'enabled' => $this->safeCount('coupons', 'status = 1'),
                'used' => $this->safeCount('coupon_redemptions'),
                'discount' => $this->safeScalar('SELECT COALESCE(SUM(discount_amount),0) AS v FROM ' . Database::table('coupon_redemptions')),
            ],
        ]);
    }

    public function cards()
    {
        if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理')) {
            $this->mobileSchemaFlash('卡密管理');
        }
        $generated = flash('admin_mobile_generated_cards', null);
        $this->mobileView('cards', [
            'title' => '卡密',
            'cards' => $this->safeRows('SELECT c.*, u.username, p.name AS package_name FROM ' . Database::table('redeem_cards') . ' c LEFT JOIN ' . Database::table('users') . ' u ON c.used_by = u.id LEFT JOIN ' . Database::table('packages') . ' p ON c.package_id = p.id ORDER BY c.id DESC LIMIT 80'),
            'packages' => $this->safeRows('SELECT id, name FROM ' . Database::table('packages') . ' WHERE status = 1 ORDER BY sort_order ASC, id ASC LIMIT 100'),
            'stats' => (new RedeemCardService())->stats(),
            'generatedCards' => $generated,
        ]);
    }

    public function payments()
    {
        $rows = $this->safeRows('SELECT * FROM ' . Database::table('payment_config') . ' ORDER BY sort_order ASC, id ASC');
        $paymentStats = $this->mobilePaymentStats($rows);
        $this->mobileView('payments', [
            'title' => '支付配置',
            'payments' => $rows,
            'paymentStats' => $paymentStats,
        ]);
    }

    public function storages()
    {
        $this->ensureMobileStorageDriverSchema();
        $editId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        $editStorage = $editId > 0 ? (new StorageDriver())->find($editId) : null;
        $this->mobileView('storages', [
            'title' => '存储',
            'storages' => $this->safeRows('SELECT * FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, id DESC LIMIT 80'),
            'editStorage' => $editStorage,
            'failedBackups' => $this->safeCount('file_storage_backups', "status = 'failed'"),
            'testResult' => flash('admin_mobile_storage_test', null),
        ]);
    }

    public function storageBackups()
    {
        $schemaReady = $this->ensureMobileStorageBackupSchema();
        if (!$schemaReady) {
            $this->mobileSchemaFlash('多存储备份');
        }

        $service = new StorageBackupService();
        $storages = $this->safeRows('SELECT id, name, type, is_enabled, is_default FROM ' . Database::table('storage_drivers') . ' ORDER BY is_default DESC, is_enabled DESC, id DESC LIMIT 120');
        $policies = $schemaReady ? $this->safeRows('SELECT * FROM ' . Database::table('storage_backup_policies') . ' ORDER BY sort_order ASC, id DESC LIMIT 80') : [];
        foreach ($policies as &$policy) {
            $policy['backup_names'] = $service->policyStorageNames($policy, $storages);
            $policy['backup_storage_id_list'] = $service->policyStorageIds($policy);
        }
        unset($policy);

        $tasks = $schemaReady ? $this->safeRows(
            'SELECT b.*, f.original_name, f.file_type, f.file_size, s.name AS storage_name, s.type AS storage_type, p.name AS policy_name
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON b.storage_id = s.id
             LEFT JOIN ' . Database::table('storage_backup_policies') . ' p ON b.policy_id = p.id
             ORDER BY b.id DESC LIMIT 50'
        ) : [];
        $migrationPlan = null;
        $migrationTasks = [];
        if ($schemaReady) {
            try {
                $migrationService = new StorageMigrationService();
                $migrationPlan = $migrationService->plan([
                    'target_storage_id' => isset($_GET['target_storage_id']) ? max(0, (int) $_GET['target_storage_id']) : 0,
                    'file_scope' => isset($_GET['file_scope']) && in_array($_GET['file_scope'], ['image', 'file'], true) ? $_GET['file_scope'] : '',
                ]);
                $migrationTasks = $migrationService->recentTasks(20);
            } catch (\Throwable $e) {
                Logger::error('移动端存储迁移计划读取失败：' . $e->getMessage());
            }
        }

        $this->mobileView('storage_backups', [
            'title' => '存储备份',
            'storages' => $storages,
            'policies' => $policies,
            'tasks' => $tasks,
            'migrationPlan' => $migrationPlan,
            'migrationTasks' => $migrationTasks,
            'stats' => [
                'policies' => $this->safeCount('storage_backup_policies'),
                'enabled_policies' => $this->safeCount('storage_backup_policies', 'is_enabled = 1'),
                'success' => $this->safeCount('file_storage_backups', "status = 'success'"),
                'failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
                'pending' => $this->safeCount('file_storage_backups', "status = 'pending'"),
            ],
        ]);
    }

    public function repositories()
    {
        $service = new RepositoryService();
        $schemaReady = $this->ensureMobileRepositorySchema();
        if ($schemaReady) {
            $stats = $service->adminStats();
            $repositories = $service->adminRepositories(['keyword' => '', 'status' => '', 'access_type' => '']);
        } else {
            $this->mobileSchemaFlash('分享仓库');
            $stats = ['total' => 0, 'enabled' => 0, 'disabled' => 0, 'today_views' => 0, 'today_downloads' => 0, 'blocked_today' => 0];
            $repositories = [];
        }
        $this->mobileView('repositories', [
            'title' => '分享仓库',
            'repositories' => array_slice($repositories, 0, 80),
            'stats' => $stats,
        ]);
    }

    public function subsites()
    {
        $schemaReady = $this->ensureMobileSubsiteSchema();
        if (!$schemaReady) {
            $this->mobileSchemaFlash('分站管理');
        }
        $service = new SubsiteService();
        $this->mobileView('subsites', [
            'title' => '分站',
            'subsites' => $schemaReady ? $this->safeRows('SELECT s.*, u.username FROM ' . Database::table('subsites') . ' s LEFT JOIN ' . Database::table('users') . ' u ON s.user_id = u.id ORDER BY FIELD(s.status, \'pending\', \'active\', \'suspended\', \'rejected\'), s.id DESC LIMIT 80') : [],
            'service' => $service,
            'domainConfig' => $service->domainConfigSummary(),
            'schemaReady' => $schemaReady,
        ]);
    }

    public function servers()
    {
        $schemaReady = $this->ensureMobileMonitorSchema();
        if (!$schemaReady) {
            $this->mobileSchemaFlash('服务器监控');
        }
        $this->mobileView('servers', [
            'title' => '服务器',
            'servers' => $schemaReady ? $this->safeRows('SELECT * FROM ' . Database::table('monitor_servers') . ' ORDER BY id DESC LIMIT 80') : [],
            'stats' => [
                'bt_online' => $this->safeCount('monitor_servers', "monitor_type = 'bt' AND status = 'online'"),
                'bt_offline' => $this->safeCount('monitor_servers', "monitor_type = 'bt' AND status = 'offline'"),
                'user_servers' => $this->safeCount('monitor_servers', "monitor_type IN ('ssh','agent')"),
                'alerts' => $this->safeCount('monitor_alerts', "status = 'unread'"),
            ],
            'schemaReady' => $schemaReady,
        ]);
    }

    public function logs()
    {
        $this->mobileView('logs', [
            'title' => '审计日志',
            'adminLogs' => $this->safeRows('SELECT l.*, u.username, u.email FROM ' . Database::table('admin_logs') . ' l LEFT JOIN ' . Database::table('users') . ' u ON l.admin_id = u.id ORDER BY l.id DESC LIMIT 80'),
            'apiLogs' => $this->mobileApiLogRows(40),
            'balanceLogs' => $this->safeRows('SELECT l.*, u.username FROM ' . Database::table('balance_logs') . ' l LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id ORDER BY l.id DESC LIMIT 40'),
            'commandLogs' => $this->safeRows('SELECT cl.*, u.username, s.name AS server_name FROM ' . Database::table('server_command_logs') . ' cl LEFT JOIN ' . Database::table('users') . ' u ON cl.user_id = u.id LEFT JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id ORDER BY cl.id DESC LIMIT 40'),
            'uploadFailures' => $this->mobileIncidentUploadFailureRows(60),
            'stats' => [
                'admin_today' => $this->safeCount('admin_logs', 'DATE(created_at) = CURDATE()'),
                'api_failed' => $this->safeCount('api_logs', 'is_success = 0'),
                'balance_today' => $this->safeCount('balance_logs', 'DATE(created_at) = CURDATE()'),
                'commands_danger' => $this->safeCount('server_command_logs', "risk_level = 'danger'"),
                'upload_failed_today' => $this->safeCount('upload_failures', 'DATE(created_at) = CURDATE()'),
            ],
        ]);
    }

    public function incidents()
    {
        $items = [];
        foreach ($this->mobileIncidentApiRows() as $row) {
            $items[] = ['level' => 'warning', 'icon' => 'terminal', 'title' => 'API 请求失败', 'desc' => ($row['endpoint'] ?: '-') . ' · HTTP ' . (int) $row['status_code'] . ' · ' . ($row['message'] ?: '无返回信息'), 'time' => $row['created_at'], 'url' => 'admin/m/logs'];
        }
        foreach ($this->mobileIncidentBackupRows() as $row) {
            $items[] = ['level' => 'danger', 'icon' => 'database-backup', 'title' => '备份任务失败', 'desc' => ($row['original_name'] ?: ('文件 #' . $row['file_id'])) . ' · ' . ($row['storage_name'] ?: ('存储 #' . $row['storage_id'])) . ' · ' . ($row['error_message'] ?: '无错误信息'), 'time' => $row['updated_at'] ?: $row['created_at'], 'url' => 'admin/m/storage-backups'];
        }
        foreach ($this->mobileIncidentCommandRows() as $row) {
            $items[] = ['level' => $row['risk_level'] === 'danger' ? 'danger' : 'warning', 'icon' => 'square-terminal', 'title' => '命令审计标记', 'desc' => text_limit($row['command'], 110) . ' · ' . text_limit($row['output_summary'], 100), 'time' => $row['created_at'], 'url' => 'admin/m/logs'];
        }
        foreach ($this->mobileIncidentUploadFailureRows() as $row) {
            $errorType = isset($row['error_type']) ? (string) $row['error_type'] : 'upload';
            $storageDanger = in_array($errorType, ['storage', 'storage_config', 'storage_upload', 'storage_url', 'storage_delete', 'storage_db'], true);
            $stageLabel = $this->uploadFailureStageLabel($errorType);
            $items[] = [
                'level' => $storageDanger ? 'danger' : 'warning',
                'icon' => 'cloud-alert',
                'title' => $stageLabel ? ('上传失败：' . $stageLabel) : '上传失败',
                'desc' => ($row['file_name'] ?: '未进入文件处理') . ' · ' . $errorType . ' · ' . text_limit($row['suggestion'] ?: $row['message'], 140),
                'time' => $row['created_at'],
                'url' => 'admin/m/logs',
            ];
        }
        usort($items, function ($a, $b) {
            return strcmp((string) $b['time'], (string) $a['time']);
        });
        $this->mobileView('incidents', [
            'title' => '异常事件',
            'items' => array_slice($items, 0, 50),
            'stats' => [
                'api_failed_today' => $this->safeCount('api_logs', 'is_success = 0 AND DATE(created_at) = CURDATE()'),
                'backup_failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
                'command_risky_today' => $this->safeCount('server_command_logs', "risk_level IN ('warning','danger') AND DATE(created_at) = CURDATE()"),
                'upload_failed_today' => $this->safeCount('upload_failures', 'DATE(created_at) = CURDATE()'),
            ],
        ]);
    }

    public function announcements()
    {
        $schemaReady = $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureAnnouncementSchema'], '公告管理');
        if (!$schemaReady) {
            $this->mobileSchemaFlash('公告管理');
        }
        $categories = Announcement::categories();
        $this->mobileView('announcements', [
            'title' => '公告',
            'announcements' => $schemaReady ? $this->safeRows('SELECT * FROM ' . Database::table('announcements') . ' ORDER BY is_top DESC, id DESC LIMIT 80') : [],
            'categories' => $categories,
            'stats' => [
                'total' => $this->safeCount('announcements'),
                'visible' => $this->safeCount('announcements', 'status = 1'),
                'home' => $this->safeCount('announcements', 'status = 1 AND show_home = 1'),
            ],
            'schemaReady' => $schemaReady,
        ]);
    }

    public function uploadLimits()
    {
        $service = new UploadLimitService();
        $this->mobileView('upload_limits', [
            'title' => '上传限制',
            'limits' => $service->frontendConfig(),
            'serverUploadLimits' => [
                'upload_max_filesize' => ini_get('upload_max_filesize') ?: '-',
                'post_max_size' => ini_get('post_max_size') ?: '-',
                'max_file_uploads' => ini_get('max_file_uploads') ?: '-',
                'max_execution_time' => ini_get('max_execution_time') ?: '-',
            ],
        ]);
    }

    public function settings()
    {
        try {
            DatabaseUpgradeService::ensureSensitiveSettingsEncrypted();
        } catch (\Throwable $e) {
            Logger::error('移动端设置页敏感配置加密检查失败：' . $e->getMessage());
        }
        $settings = $this->settingsMap();
        $this->mobileView('settings', [
            'title' => '系统',
            'health' => [
                'schema' => DatabaseUpgradeService::standardSchemaReady(),
                'php' => PHP_VERSION,
                'upload' => ini_get('upload_max_filesize'),
                'time' => now(),
                'maintenance' => (string) $this->settingValue($settings, 'site_maintenance', '0') === '1',
                'maintenance_message' => $this->settingValue($settings, 'maintenance_message', '系统正在维护升级，请稍后再访问。'),
            ],
            'settings' => $settings,
            'packages' => $this->safeRows('SELECT id, name FROM ' . Database::table('packages') . ' ORDER BY sort_order ASC, id ASC LIMIT 100'),
            'theme' => [
                'admin' => $this->adminThemeValue(),
                'frontend' => $this->themeStyle($this->settingValue($settings, 'frontend_theme_style', 'anime')),
                'home' => $this->frontendHomeStyle($this->settingValue($settings, 'frontend_home_style', 'default')),
            ],
            'schemaRepairResult' => flash('schema_repair_result', null),
        ]);
    }

    public function menu()
    {
        $this->mobileView('menu', [
            'title' => '功能中心',
            'stats' => $this->dashboardStats(),
        ]);
    }

    public function schemaAudit()
    {
        $this->mobileView('schema_audit', [
            'title' => '数据库巡检',
            'schemaAudit' => DatabaseUpgradeService::inspectLiveSchema(),
            'schemaRepairResult' => flash('schema_repair_result', null),
        ]);
    }

    public function createUser()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema'], '用户权限');
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'], 'API 安全');
            $username = trim((string) (isset($_POST['username']) ? $_POST['username'] : ''));
            $nickname = trim((string) (isset($_POST['nickname']) ? $_POST['nickname'] : ''));
            $email = trim((string) (isset($_POST['email']) ? $_POST['email'] : ''));
            $password = (string) (isset($_POST['password']) ? $_POST['password'] : '');
            $role = isset($_POST['role']) && $_POST['role'] === 'admin' ? 'admin' : 'user';
            $status = isset($_POST['status']) && (string) $_POST['status'] === '0' ? 0 : 1;
            $package = $this->mobilePackageById(isset($_POST['package_id']) ? (int) $_POST['package_id'] : 0);
            $balance = round((float) (isset($_POST['balance']) ? $_POST['balance'] : 0), 2);

            $userModel = new User();
            if (!Validator::username($username)) {
                throw new \RuntimeException('用户名必须为 3-32 位字母、数字或下划线。');
            }
            if (!Validator::email($email)) {
                throw new \RuntimeException('邮箱格式不正确。');
            }
            if (!Validator::password($password)) {
                throw new \RuntimeException('密码至少需要 6 位。');
            }
            if ($userModel->existsUsername($username)) {
                throw new \RuntimeException('用户名已存在，请换一个。');
            }
            if ($userModel->existsEmail($email)) {
                throw new \RuntimeException('邮箱已存在，请换一个。');
            }

            $quota = $this->mobilePackageQuota($package);
            $apiToken = bin2hex(random_bytes(24));
            $data = [
                'username' => $username,
                'nickname' => $nickname !== '' ? $nickname : $username,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'avatar' => '',
                'role' => $role,
                'balance' => $balance,
                'package_id' => $package ? (int) $package['id'] : null,
                'package_expire_time' => $quota['package_expire_time'],
                'used_storage' => 0,
                'total_storage' => $quota['total_storage'],
                'used_traffic' => 0,
                'total_traffic' => $quota['total_traffic'],
                'status' => $status,
                'email_verified_at' => isset($_POST['email_verified']) ? now() : null,
                'remember_token' => null,
                'api_token' => $apiToken,
                'created_at' => now(),
                'updated_at' => now(),
            ];
            $userTable = Database::table('users');
            if ($this->columnExists($userTable, 'allow_image_override')) {
                $data['allow_image_override'] = -1;
            }
            if ($this->columnExists($userTable, 'allow_netdisk_override')) {
                $data['allow_netdisk_override'] = -1;
            }
            if ($this->columnExists($userTable, 'api_token_hash')) {
                $data['api_token'] = CryptoService::encrypt($apiToken);
                $data['api_token_hash'] = hash('sha256', $apiToken);
            }
            if ($this->columnExists($userTable, 'api_allowed_ips')) {
                $data['api_allowed_ips'] = '';
            }
            if ($this->columnExists($userTable, 'frontend_theme_style')) {
                $data['frontend_theme_style'] = '';
            }
            if ($this->columnExists($userTable, 'admin_theme_style')) {
                $data['admin_theme_style'] = '';
            }
            if ($this->columnExists($userTable, 'server_ops_cron_token')) {
                $data['server_ops_cron_token'] = null;
            }
            $id = $userModel->create($data);
            if ($balance != 0.0) {
                (new BalanceService())->log($id, 'adjust', $balance, 0, $balance, 'admin', Auth::id(), '移动后台创建用户初始余额');
            }
            $this->mobileAdminLog('移动端创建用户', 'user', $id);
            set_flash('success', '用户已创建。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '创建用户失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/users');
    }

    public function updateUser()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema'], '用户权限');
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'], 'API 安全');
            $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
            $userModel = new User();
            $oldUser = $userModel->find($id);
            if (!$oldUser) {
                throw new \RuntimeException('用户不存在。');
            }

            $role = isset($_POST['role']) && $_POST['role'] === 'admin' ? 'admin' : 'user';
            $status = isset($_POST['status']) && (string) $_POST['status'] === '0' ? 0 : 1;
            if ($id === (int) Auth::id() && ($role !== 'admin' || $status !== 1)) {
                throw new \RuntimeException('不能把当前登录的管理员降级或禁用。');
            }

            $package = $this->mobilePackageById(isset($_POST['package_id']) ? (int) $_POST['package_id'] : 0);
            $quota = $this->mobilePackageQuota($package, $oldUser);
            $balance = round((float) (isset($_POST['balance']) ? $_POST['balance'] : $oldUser['balance']), 2);

            $data = [
                'role' => $role,
                'status' => $status,
                'balance' => $balance,
                'package_id' => $package ? (int) $package['id'] : null,
                'package_expire_time' => $quota['package_expire_time'],
                'total_storage' => $quota['total_storage'],
                'total_traffic' => $quota['total_traffic'],
                'updated_at' => now(),
            ];
            if (!empty($_POST['password'])) {
                if (!Validator::password($_POST['password'])) {
                    throw new \RuntimeException('新密码至少需要 6 位。');
                }
                $data['password'] = password_hash((string) $_POST['password'], PASSWORD_DEFAULT);
            }

            $userModel->update($id, $data);
            if ((float) $oldUser['balance'] !== (float) $balance) {
                (new BalanceService())->log($id, 'adjust', round($balance - (float) $oldUser['balance'], 2), $oldUser['balance'], $balance, 'admin', Auth::id(), '移动后台调整余额');
            }
            $this->mobileAdminLog('移动端更新用户', 'user', $id);
            set_flash('success', '用户已更新。');
        } catch (\Throwable $e) {
            set_flash('error', '更新用户失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/users');
    }

    public function savePackage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->ensureMobileSubsiteSchema()) {
                throw new \RuntimeException('套餐分站权益结构未准备完成，请进入系统状态执行数据库修复。');
            }
            $name = trim((string) (isset($_POST['name']) ? $_POST['name'] : ''));
            if ($name === '') {
                throw new \RuntimeException('请填写套餐名称。');
            }
            $data = [
                'name' => text_limit($name, 80),
                'price' => round((float) (isset($_POST['price']) ? $_POST['price'] : 0), 2),
                'duration_type' => isset($_POST['duration_type']) && in_array($_POST['duration_type'], ['month', 'quarter', 'year', 'forever'], true) ? $_POST['duration_type'] : 'month',
                'duration_days' => max(0, (int) (isset($_POST['duration_days']) ? $_POST['duration_days'] : 30)),
                'storage_limit' => max(0, (int) (isset($_POST['storage_limit']) ? $_POST['storage_limit'] : 0)),
                'traffic_limit' => max(0, (int) (isset($_POST['traffic_limit']) ? $_POST['traffic_limit'] : 0)),
                'single_file_limit' => max(0, (int) (isset($_POST['single_file_limit']) ? $_POST['single_file_limit'] : 0)),
                'allow_image' => isset($_POST['allow_image']) ? 1 : 0,
                'allow_netdisk' => isset($_POST['allow_netdisk']) ? 1 : 0,
                'allow_api' => isset($_POST['allow_api']) ? 1 : 0,
                'allow_monitor' => isset($_POST['allow_monitor']) ? 1 : 0,
                'allow_multi_storage' => isset($_POST['allow_multi_storage']) ? 1 : 0,
                'allow_share' => isset($_POST['allow_share']) ? 1 : 0,
                'allow_subsite' => isset($_POST['allow_subsite']) ? 1 : 0,
                'subsite_limit' => max(0, (int) (isset($_POST['subsite_limit']) ? $_POST['subsite_limit'] : 1)),
                'allow_video_preview' => isset($_POST['allow_video_preview']) ? 1 : 0,
                'allow_external_link' => isset($_POST['allow_external_link']) ? 1 : 0,
                'status' => isset($_POST['status']) && (string) $_POST['status'] === '0' ? 0 : 1,
                'sort_order' => (int) (isset($_POST['sort_order']) ? $_POST['sort_order'] : 0),
                'description' => text_limit(trim((string) (isset($_POST['description']) ? $_POST['description'] : '')), 1000),
                'updated_at' => now(),
            ];
            $model = new Package();
            if (!empty($_POST['id'])) {
                $id = (int) $_POST['id'];
                if (!$model->find($id)) {
                    throw new \RuntimeException('套餐不存在。');
                }
                $model->update($id, $data);
            } else {
                $data['created_at'] = now();
                $id = $model->create($data);
            }
            $this->mobileAdminLog('移动端保存套餐', 'package', $id);
            set_flash('success', '套餐已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存套餐失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/packages');
    }

    public function deletePackage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            (new Package())->delete($id);
            $this->mobileAdminLog('移动端删除套餐', 'package', $id);
            set_flash('success', '套餐已删除。');
        } catch (\Throwable $e) {
            set_flash('error', '删除套餐失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/packages');
    }

    public function saveCoupon()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动')) {
                throw new \RuntimeException('营销活动数据结构未准备完成，请先执行数据库修复。');
            }
            $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
            $title = trim((string) (isset($_POST['title']) ? $_POST['title'] : ''));
            $code = strtoupper(trim((string) (isset($_POST['code']) ? $_POST['code'] : '')));
            if ($title === '' || $code === '') {
                throw new \RuntimeException('请填写活动名称和优惠码。');
            }
            if (!preg_match('/^[A-Z0-9_-]{3,40}$/', $code)) {
                throw new \RuntimeException('优惠码只能使用 3-40 位字母、数字、下划线或中划线。');
            }
            $discountType = isset($_POST['discount_type']) && $_POST['discount_type'] === 'percent' ? 'percent' : 'fixed';
            $discountValue = round((float) (isset($_POST['discount_value']) ? $_POST['discount_value'] : 0), 2);
            if ($discountValue <= 0) {
                throw new \RuntimeException('优惠力度必须大于 0。');
            }
            if ($discountType === 'percent' && $discountValue > 100) {
                throw new \RuntimeException('折扣比例不能超过 100%。');
            }
            $packageScope = isset($_POST['package_scope']) && in_array($_POST['package_scope'], ['all', 'include', 'exclude'], true) ? $_POST['package_scope'] : 'all';
            $packageIds = isset($_POST['package_ids']) && is_array($_POST['package_ids']) ? implode(',', array_map('intval', $_POST['package_ids'])) : '';
            $exists = Database::fetch('SELECT id FROM ' . Database::table('coupons') . ' WHERE code = ? AND id <> ? LIMIT 1', [$code, $id]);
            if ($exists) {
                throw new \RuntimeException('优惠码已存在，请换一个。');
            }
            $data = [
                'title' => text_limit($title, 120),
                'code' => $code,
                'discount_type' => $discountType,
                'discount_value' => $discountValue,
                'min_amount' => round((float) (isset($_POST['min_amount']) ? $_POST['min_amount'] : 0), 2),
                'package_scope' => $packageScope,
                'package_ids' => $packageIds,
                'start_at' => $this->mobileNormalizeDateTime(isset($_POST['start_at']) ? $_POST['start_at'] : ''),
                'end_at' => $this->mobileNormalizeDateTime(isset($_POST['end_at']) ? $_POST['end_at'] : ''),
                'total_limit' => max(0, (int) (isset($_POST['total_limit']) ? $_POST['total_limit'] : 0)),
                'user_limit' => max(0, (int) (isset($_POST['user_limit']) ? $_POST['user_limit'] : 1)),
                'first_order_only' => isset($_POST['first_order_only']) ? 1 : 0,
                'status' => isset($_POST['status']) && (string) $_POST['status'] === '0' ? 0 : 1,
                'sort_order' => (int) (isset($_POST['sort_order']) ? $_POST['sort_order'] : 0),
                'description' => text_limit(trim((string) (isset($_POST['description']) ? $_POST['description'] : '')), 500),
                'updated_at' => now(),
            ];
            if ($id > 0) {
                (new Coupon())->update($id, $data);
            } else {
                $data['created_at'] = now();
                $id = (new Coupon())->create($data);
            }
            $this->mobileAdminLog('移动端保存营销活动', 'coupon', $id);
            set_flash('success', '营销活动已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存营销活动失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/coupons');
    }

    public function deleteCoupon()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema'], '营销活动')) {
                throw new \RuntimeException('营销活动数据结构未准备完成，请先执行数据库修复。');
            }
            $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('coupon_redemptions') . ' WHERE coupon_id = ?', [$id]);
            if ($used && (int) $used['c'] > 0) {
                Database::execute('UPDATE ' . Database::table('coupons') . ' SET status = 0, updated_at = ? WHERE id = ?', [now(), $id]);
                set_flash('success', '该活动已有使用记录，已改为停用。');
            } else {
                (new Coupon())->delete($id);
                set_flash('success', '营销活动已删除。');
            }
            $this->mobileAdminLog('移动端删除营销活动', 'coupon', $id);
        } catch (\Throwable $e) {
            set_flash('error', '删除营销活动失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/coupons');
    }

    public function generateCards()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $result = (new RedeemCardService())->generate([
                'type' => isset($_POST['type']) ? $_POST['type'] : 'balance',
                'title' => isset($_POST['title']) ? $_POST['title'] : '',
                'amount' => isset($_POST['amount']) ? $_POST['amount'] : 0,
                'package_id' => isset($_POST['package_id']) ? $_POST['package_id'] : 0,
                'duration_days' => isset($_POST['duration_days']) ? $_POST['duration_days'] : 0,
                'count' => isset($_POST['count']) ? $_POST['count'] : 1,
                'prefix' => isset($_POST['prefix']) ? $_POST['prefix'] : 'BM',
                'channel' => isset($_POST['channel']) ? $_POST['channel'] : '',
                'expire_at' => isset($_POST['expire_at']) ? $_POST['expire_at'] : '',
                'remark' => isset($_POST['remark']) ? $_POST['remark'] : '',
                'created_by' => Auth::id(),
            ]);
            set_flash('admin_mobile_generated_cards', $result);
            $this->mobileAdminLog('移动端生成卡密', 'redeem_card', null);
            set_flash('success', '卡密已生成，请在当前页面复制明文。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '生成卡密失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/cards');
    }

    public function updateCardStatus()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $action = isset($_POST['action']) ? (string) $_POST['action'] : '';
        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理')) {
                throw new \RuntimeException('卡密数据结构未准备完成，请先执行数据库修复。');
            }
            $card = Database::fetch('SELECT * FROM ' . Database::table('redeem_cards') . ' WHERE id = ? LIMIT 1', [$id]);
            if (!$card) {
                throw new \RuntimeException('卡密不存在。');
            }
            if ($card['status'] === 'used') {
                throw new \RuntimeException('已兑换卡密不能修改状态。');
            }
            $status = $action === 'restore' ? 'unused' : 'disabled';
            Database::execute('UPDATE ' . Database::table('redeem_cards') . ' SET status = ?, updated_at = ? WHERE id = ?', [$status, now(), $id]);
            $this->mobileAdminLog($status === 'unused' ? '移动端恢复卡密' : '移动端停用卡密', 'redeem_card', $id);
            set_flash('success', $status === 'unused' ? '卡密已恢复。' : '卡密已停用。');
        } catch (\Throwable $e) {
            set_flash('error', '更新卡密失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/cards');
    }

    public function deleteCard()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema'], '卡密管理')) {
                throw new \RuntimeException('卡密数据结构未准备完成，请先执行数据库修复。');
            }
            $card = Database::fetch('SELECT * FROM ' . Database::table('redeem_cards') . ' WHERE id = ? LIMIT 1', [$id]);
            if (!$card) {
                throw new \RuntimeException('卡密不存在。');
            }
            if ($card['status'] === 'used') {
                throw new \RuntimeException('已兑换卡密需要保留财务记录，不能删除。');
            }
            Database::execute('DELETE FROM ' . Database::table('redeem_cards') . ' WHERE id = ?', [$id]);
            $this->mobileAdminLog('移动端删除未兑换卡密', 'redeem_card', $id);
            set_flash('success', '未兑换卡密已删除。');
        } catch (\Throwable $e) {
            set_flash('error', '删除卡密失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/cards');
    }

    public function savePayment()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $code = trim((string) (isset($_POST['code']) ? $_POST['code'] : ''));
        try {
            $row = Database::fetch('SELECT * FROM ' . Database::table('payment_config') . ' WHERE id = ? AND code = ? LIMIT 1', [$id, $code]);
            if (!$row) {
                throw new \RuntimeException('支付通道不存在。');
            }
            $config = [];
            if ($code === 'alipay') {
                $config = [
                    'app_id' => trim((string) (isset($_POST['app_id']) ? $_POST['app_id'] : '')),
                    'private_key' => trim((string) (isset($_POST['private_key']) ? $_POST['private_key'] : '')),
                    'alipay_public_key' => trim((string) (isset($_POST['alipay_public_key']) ? $_POST['alipay_public_key'] : '')),
                    'sandbox' => !empty($_POST['sandbox']),
                    'notify_url' => trim((string) (isset($_POST['notify_url']) ? $_POST['notify_url'] : '')),
                    'timeout_express' => trim((string) (isset($_POST['timeout_express']) ? $_POST['timeout_express'] : '10m')),
                ];
            } elseif ($code === 'manual') {
                $config = [
                    'instructions' => trim((string) (isset($_POST['instructions']) ? $_POST['instructions'] : '')),
                    'contact' => trim((string) (isset($_POST['contact']) ? $_POST['contact'] : '')),
                ];
            } elseif (!empty($_POST['config_json'])) {
                $decoded = json_decode((string) $_POST['config_json'], true);
                if (!is_array($decoded)) {
                    throw new \RuntimeException('扩展配置 JSON 格式错误。');
                }
                $config = $decoded;
            }

            $name = trim((string) (isset($_POST['name']) ? $_POST['name'] : $row['name']));
            if ($name === '') {
                $name = (string) $row['name'];
            }
            Database::execute(
                'UPDATE ' . Database::table('payment_config') . ' SET name = ?, config = ?, is_enabled = ?, sort_order = ?, updated_at = ? WHERE id = ?',
                [text_limit($name, 80), json_encode($config, JSON_UNESCAPED_UNICODE), isset($_POST['is_enabled']) && (string) $_POST['is_enabled'] === '1' ? 1 : 0, (int) (isset($_POST['sort_order']) ? $_POST['sort_order'] : 0), now(), $id]
            );
            $this->mobileAdminLog('移动端保存支付配置', 'payment', $id);
            set_flash('success', '支付配置已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存支付配置失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/payments');
    }

    public function deleteFile()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $file = Database::fetch('SELECT * FROM ' . Database::table('files') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$file) {
            set_flash('error', '文件不存在。');
            $this->redirect('admin/m/files');
        }

        try {
            $storage = !empty($file['storage_id']) ? (new StorageDriver())->find((int) $file['storage_id']) : null;
            if ($storage) {
                (new StorageBackupService())->deleteBackupsForFile($file);
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Throwable $e) {
            Logger::error('移动后台远程文件删除失败：' . $e->getMessage(), ['file_id' => $id]);
        }

        Database::execute('DELETE FROM ' . Database::table('files') . ' WHERE id = ?', [$id]);
        $this->mobileAdminLog('移动端删除文件', 'file', $id);
        set_flash('success', '文件记录已删除。');
        $this->redirect('admin/m/files');
    }

    public function saveStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->ensureMobileStorageDriverSchema()) {
                throw new \RuntimeException('存储数据结构未准备完成，请进入数据库巡检执行修复。');
            }
            $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
            $type = isset($_POST['type']) ? (string) $_POST['type'] : 'local';
            if (!in_array($type, ['local', 'oss', 'cos', 'kodo', 's3', 'minio', 'r2', 'webdav', 'bmtools'], true)) {
                throw new \RuntimeException('不支持的存储类型。');
            }
            $model = new StorageDriver();
            $old = $id > 0 ? $model->find($id) : null;
            if ($id > 0 && !$old) {
                throw new \RuntimeException('存储源不存在。');
            }

            $secretInput = trim((string) (isset($_POST['secret_key']) ? $_POST['secret_key'] : ''));
            $plainSecret = $secretInput;
            $storedSecret = $secretInput !== '' ? CryptoService::encrypt($secretInput) : '';
            if ($old && $secretInput === '') {
                $plainSecret = CryptoService::decrypt($old['secret_key']);
                $storedSecret = $old['secret_key'];
            }

            $data = $this->mobileNormalizeStorageInput([
                'name' => trim((string) (isset($_POST['name']) ? $_POST['name'] : '')),
                'type' => $type,
                'access_key' => trim((string) (isset($_POST['access_key']) ? $_POST['access_key'] : '')),
                'secret_key' => $storedSecret,
                'bucket' => trim((string) (isset($_POST['bucket']) ? $_POST['bucket'] : '')),
                'region' => trim((string) (isset($_POST['region']) ? $_POST['region'] : '')),
                'endpoint' => trim((string) (isset($_POST['endpoint']) ? $_POST['endpoint'] : '')),
                'domain' => trim((string) (isset($_POST['domain']) ? $_POST['domain'] : '')),
                'prefix' => trim(trim((string) (isset($_POST['prefix']) ? $_POST['prefix'] : '')), '/'),
                'is_enabled' => isset($_POST['is_enabled']) && (string) $_POST['is_enabled'] === '0' ? 0 : 1,
                'is_default' => isset($_POST['is_default']) ? 1 : 0,
                'is_public' => isset($_POST['is_public']) ? 1 : 0,
                'updated_at' => now(),
            ]);
            $error = $this->mobileValidateStorageInput($data, $plainSecret);
            if ($error !== '') {
                throw new \RuntimeException($error);
            }

            Database::begin();
            try {
                if (!empty($data['is_default'])) {
                    Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 0');
                }
                if ($id > 0) {
                    $model->update($id, $data);
                } else {
                    $data['created_at'] = now();
                    $id = $model->create($data);
                }
                Database::commit();
            } catch (\Throwable $e) {
                Database::rollBack();
                throw $e;
            }

            $this->mobileAdminLog('移动端保存存储源', 'storage', $id);
            set_flash('success', '存储源已保存。建议立即执行真实测试。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存存储源失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storages');
    }

    public function testStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $driver = (new StorageDriver())->find($id);
        if (!$driver) {
            set_flash('error', '存储源不存在。');
            $this->redirect('admin/m/storages');
        }

        try {
            $result = (new StorageTestService())->run($driver);
            set_flash('admin_mobile_storage_test', $result);
            set_flash(!empty($result['success']) ? 'success' : 'error', !empty($result['message']) ? $result['message'] : '存储测试已执行。');
            $this->mobileAdminLog('移动端测试存储源', 'storage', $id);
        } catch (\Throwable $e) {
            $result = [
                'success' => false,
                'message' => '存储测试失败：' . $e->getMessage(),
                'failed_stage' => 'request',
                'failed_stage_label' => '测试接口',
                'failed_stage_hint' => '测试接口执行异常，请检查后台登录状态、数据库结构、PHP 扩展和运行日志。',
                'technical_message' => $e->getMessage(),
                'checks' => [
                    [
                        'label' => '测试接口',
                        'status' => 'fail',
                        'message' => $e->getMessage(),
                        'hint' => '进入移动后台「数据库巡检」查看环境、数据库和日志提示。',
                    ],
                ],
                'repair_url' => url('admin/m/schema-audit'),
                'error_type' => 'request',
            ];
            set_flash('admin_mobile_storage_test', $result);
            set_flash('error', $result['message']);
        }

        $this->redirect('admin/m/storages');
    }

    public function deleteStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if (!$this->ensureMobileStorageDriverSchema()) {
                throw new \RuntimeException('存储数据结构未准备完成，请进入数据库巡检执行修复。');
            }
            $driver = (new StorageDriver())->find($id);
            if (!$driver) {
                throw new \RuntimeException('存储源不存在。');
            }
            if (!empty($driver['is_default'])) {
                throw new \RuntimeException('默认存储源不能删除，请先设置其他默认存储。');
            }
            $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE storage_id = ?', [$id]);
            if ($used && (int) $used['c'] > 0) {
                throw new \RuntimeException('该存储源已有文件使用，不能直接删除。');
            }
            (new StorageDriver())->delete($id);
            $this->mobileAdminLog('移动端删除存储源', 'storage', $id);
            set_flash('success', '存储源已删除。');
        } catch (\Throwable $e) {
            set_flash('error', '删除存储源失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storages');
    }

    public function setDefaultStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $driver = (new StorageDriver())->find($id);
        if (!$driver) {
            set_flash('error', '存储源不存在。');
            $this->redirect('admin/m/storages');
        }
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 0');
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 1, is_enabled = 1, updated_at = ? WHERE id = ?', [now(), $id]);
        $this->mobileAdminLog('移动端设置默认存储源', 'storage', $id);
        set_flash('success', '默认存储源已更新。');
        $this->redirect('admin/m/storages');
    }

    public function toggleStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $driver = (new StorageDriver())->find($id);
        if (!$driver) {
            set_flash('error', '存储源不存在。');
            $this->redirect('admin/m/storages');
        }
        $enabled = !empty($driver['is_enabled']) ? 0 : 1;
        if (!empty($driver['is_default']) && $enabled === 0) {
            set_flash('error', '默认存储源不能直接停用，请先设置其他默认存储。');
            $this->redirect('admin/m/storages');
        }
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_enabled = ?, updated_at = ? WHERE id = ?', [$enabled, now(), $id]);
        $this->mobileAdminLog('移动端切换存储源状态', 'storage', $id);
        set_flash('success', $enabled ? '存储源已启用。' : '存储源已停用。');
        $this->redirect('admin/m/storages');
    }

    public function saveStorageBackupPolicy()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->ensureMobileStorageBackupSchema()) {
                throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入系统状态执行数据库修复。');
            }
            $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
            $name = trim((string) (isset($_POST['name']) ? $_POST['name'] : ''));
            $primaryStorageId = max(0, (int) (isset($_POST['primary_storage_id']) ? $_POST['primary_storage_id'] : 0));
            $fileScope = isset($_POST['file_scope']) && in_array($_POST['file_scope'], ['all', 'image', 'file'], true) ? $_POST['file_scope'] : 'all';
            $failureStrategy = isset($_POST['failure_strategy']) && in_array($_POST['failure_strategy'], ['ignore', 'warn', 'strict'], true) ? $_POST['failure_strategy'] : 'warn';
            $backupIds = isset($_POST['backup_storage_ids']) ? (array) $_POST['backup_storage_ids'] : [];
            $cleanBackupIds = [];
            foreach ($backupIds as $storageId) {
                $storageId = (int) $storageId;
                if ($storageId > 0 && $storageId !== $primaryStorageId) {
                    $storage = Database::fetch('SELECT id FROM ' . Database::table('storage_drivers') . ' WHERE id = ? AND is_enabled = 1 LIMIT 1', [$storageId]);
                    if ($storage) {
                        $cleanBackupIds[$storageId] = $storageId;
                    }
                }
            }
            if ($name === '') {
                throw new \RuntimeException('请填写备份策略名称。');
            }
            if (!$cleanBackupIds) {
                throw new \RuntimeException('请至少选择一个已启用、且不等于主存储的备份目标。');
            }

            $data = [
                'name' => text_limit($name, 120),
                'primary_storage_id' => $primaryStorageId,
                'backup_storage_ids' => json_encode(array_values($cleanBackupIds)),
                'file_scope' => $fileScope,
                'mode' => 'sync',
                'failure_strategy' => $failureStrategy,
                'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
                'sort_order' => (int) (isset($_POST['sort_order']) ? $_POST['sort_order'] : 0),
                'updated_at' => now(),
            ];
            if ($id > 0) {
                Database::execute(
                    'UPDATE ' . Database::table('storage_backup_policies') . ' SET name = ?, primary_storage_id = ?, backup_storage_ids = ?, file_scope = ?, mode = ?, failure_strategy = ?, is_enabled = ?, sort_order = ?, updated_at = ? WHERE id = ?',
                    [$data['name'], $data['primary_storage_id'], $data['backup_storage_ids'], $data['file_scope'], $data['mode'], $data['failure_strategy'], $data['is_enabled'], $data['sort_order'], $data['updated_at'], $id]
                );
            } else {
                $data['created_at'] = now();
                Database::execute(
                    'INSERT INTO ' . Database::table('storage_backup_policies') . ' (name, primary_storage_id, backup_storage_ids, file_scope, mode, failure_strategy, is_enabled, sort_order, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [$data['name'], $data['primary_storage_id'], $data['backup_storage_ids'], $data['file_scope'], $data['mode'], $data['failure_strategy'], $data['is_enabled'], $data['sort_order'], $data['created_at'], $data['updated_at']]
                );
                $id = (int) Database::lastInsertId();
            }
            $this->mobileAdminLog('移动端保存多存储备份策略', 'storage_backup_policy', $id);
            set_flash('success', '多存储备份策略已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存备份策略失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storage-backups');
    }

    public function deleteStorageBackupPolicy()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if (!$this->ensureMobileStorageBackupSchema()) {
                throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入系统状态执行数据库修复。');
            }
            Database::execute('DELETE FROM ' . Database::table('storage_backup_policies') . ' WHERE id = ?', [$id]);
            $this->mobileAdminLog('移动端删除多存储备份策略', 'storage_backup_policy', $id);
            set_flash('success', '备份策略已删除，历史任务记录保留。');
        } catch (\Throwable $e) {
            set_flash('error', '删除备份策略失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storage-backups');
    }

    public function retryStorageBackup()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if (!$this->ensureMobileStorageBackupSchema()) {
                throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入系统状态执行数据库修复。');
            }
            (new StorageBackupService())->retryBackup($id);
            $this->mobileAdminLog('移动端重试多存储备份任务', 'storage_backup_task', $id);
            set_flash('success', '备份任务已重试成功。');
        } catch (\Throwable $e) {
            set_flash('error', '备份重试失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storage-backups');
    }

    public function retryFailedStorageBackups()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->ensureMobileStorageBackupSchema()) {
                throw new \RuntimeException('多存储备份数据结构未准备完成，请先进入系统状态执行数据库修复。');
            }
            $summary = (new StorageBackupService())->retryFailedBackups([
                'limit' => isset($_POST['limit']) ? (int) $_POST['limit'] : 20,
                'policy_id' => isset($_POST['policy_id']) ? (int) $_POST['policy_id'] : 0,
                'storage_id' => isset($_POST['storage_id']) ? (int) $_POST['storage_id'] : 0,
                'file_scope' => isset($_POST['file_scope']) ? (string) $_POST['file_scope'] : '',
            ]);
            $message = '批量重试完成：成功 ' . (int) $summary['success'] . ' 个，失败 ' . (int) $summary['failed'] . ' 个。';
            if (!empty($summary['errors'])) {
                $message .= ' 示例错误：' . implode('；', $summary['errors']);
            }
            $this->mobileAdminLog('移动端批量重试多存储备份任务', 'storage_backup_task', null);
            set_flash($summary['failed'] > 0 ? 'error' : 'success', $message);
        } catch (\Throwable $e) {
            set_flash('error', '批量重试失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storage-backups');
    }

    public function runStorageMigration()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->ensureMobileStorageBackupSchema()) {
                throw new \RuntimeException('存储迁移数据结构未准备完成，请先执行数据库修复。');
            }
            $options = [
                'source_storage_id' => isset($_POST['source_storage_id']) ? max(0, (int) $_POST['source_storage_id']) : 0,
                'target_storage_id' => isset($_POST['target_storage_id']) ? max(0, (int) $_POST['target_storage_id']) : 0,
                'file_scope' => isset($_POST['file_scope']) && in_array($_POST['file_scope'], ['image', 'file'], true) ? $_POST['file_scope'] : '',
                'limit' => isset($_POST['limit']) ? (int) $_POST['limit'] : 10,
                'switch_primary' => isset($_POST['switch_primary']) ? 1 : 0,
            ];
            if ($options['target_storage_id'] <= 0) {
                throw new \RuntimeException('请选择目标存储。');
            }
            if ($options['source_storage_id'] > 0 && $options['source_storage_id'] === $options['target_storage_id']) {
                throw new \RuntimeException('源存储和目标存储不能相同。');
            }
            $summary = (new StorageMigrationService())->migrate($options);
            $this->mobileAdminLog('移动端执行存储迁移', 'storage_migration', $options['target_storage_id']);
            set_flash('success', '迁移批次已执行：扫描 ' . (int) $summary['scanned'] . ' 个，上传 ' . (int) $summary['uploaded'] . ' 个，切换 ' . (int) $summary['switched'] . ' 个。');
        } catch (\Throwable $e) {
            set_flash('error', '执行存储迁移失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/storage-backups');
    }

    public function repositoryStatus()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $enabled = isset($_POST['admin_status']) && (string) $_POST['admin_status'] === '1';
        $remark = trim((string) (isset($_POST['admin_remark']) ? $_POST['admin_remark'] : ''));
        try {
            (new RepositoryService())->updateAdminStatus($id, $enabled, $remark);
            $this->mobileAdminLog($enabled ? '移动端恢复分享仓库' : '移动端下架分享仓库', 'repository', $id);
            set_flash('success', $enabled ? '分享仓库已恢复。' : '分享仓库已下架。');
        } catch (\Throwable $e) {
            set_flash('error', '更新分享仓库失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/repositories');
    }

    public function deleteRepository()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if ((new RepositoryService())->adminDeleteRepository($id)) {
                $this->mobileAdminLog('移动端删除分享仓库', 'repository', $id);
                set_flash('success', '分享仓库已删除。');
            } else {
                set_flash('error', '分享仓库不存在或已被删除。');
            }
        } catch (\Throwable $e) {
            set_flash('error', '删除分享仓库失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/repositories');
    }

    public function toggleMaintenance()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $maintenance = isset($_POST['site_maintenance']) ? '1' : '0';
        $message = trim((string) (isset($_POST['maintenance_message']) ? $_POST['maintenance_message'] : ''));
        if ($message === '') {
            $message = '系统正在维护升级，请稍后再访问。';
        }
        $this->saveSettingValue('site_maintenance', $maintenance);
        $this->saveSettingValue('maintenance_message', $message);
        $this->mobileAdminLog($maintenance === '1' ? '移动端开启维护模式' : '移动端关闭维护模式', 'maintenance', null);
        set_flash('success', $maintenance === '1' ? '维护模式已开启。' : '维护模式已关闭。');
        $this->redirect('admin/m/settings');
    }

    public function repairSchema()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $result = DatabaseUpgradeService::repairAll();
            set_flash('schema_repair_result', $result);
            $successCount = isset($result['success_count']) ? (int) $result['success_count'] : 0;
            $failCount = isset($result['fail_count']) ? (int) $result['fail_count'] : 0;
            $createdTables = isset($result['schema']['created_count']) ? (int) $result['schema']['created_count'] : 0;
            $createdRows = isset($result['defaults']['created_count']) ? (int) $result['defaults']['created_count'] : 0;
            if (!empty($result['ok'])) {
                set_flash('success', '数据库结构修复完成：检查 ' . $successCount . ' 项，补齐 ' . $createdTables . ' 张表，补齐 ' . $createdRows . ' 条配置。');
            } else {
                set_flash('error', '数据库结构修复已执行，但仍有 ' . $failCount . ' 项未完成。请进入移动数据库巡检查看待执行 SQL 和权限提示。');
            }
            $this->mobileAdminLog('移动端一键修复数据库结构', 'maintenance', null);
        } catch (\Throwable $e) {
            Logger::error('移动端一键修复数据库结构失败：' . $e->getMessage());
            set_flash('error', '数据库结构修复失败：' . $e->getMessage());
        }

        $returnTo = isset($_POST['return_to']) ? (string) $_POST['return_to'] : '';
        $this->redirect($returnTo === 'schema-audit' ? 'admin/m/schema-audit' : 'admin/m/settings');
    }

    public function repairSchemaWithTemporaryAdmin()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $username = trim((string) (isset($_POST['db_admin_user']) ? $_POST['db_admin_user'] : ''));
        $password = (string) (isset($_POST['db_admin_pass']) ? $_POST['db_admin_pass'] : '');
        if ($username === '') {
            set_flash('error', '请填写临时数据库管理员账号。');
            $this->redirect('admin/m/schema-audit');
        }

        $originalPdo = null;
        try {
            $originalPdo = Database::getInstance();
            $temporaryPdo = Database::connectionFromConfig([
                'username' => $username,
                'password' => $password,
            ]);
            Database::swapConnection($temporaryPdo);

            $result = DatabaseUpgradeService::repairAll();
            $result['temporary_admin_repair'] = true;
            set_flash('schema_repair_result', $result);

            if (!empty($result['ok'])) {
                $executed = !empty($result['auto_sql_repair']) && is_array($result['auto_sql_repair'])
                    ? (int) (isset($result['auto_sql_repair']['executed_count']) ? $result['auto_sql_repair']['executed_count'] : 0)
                    : 0;
                set_flash('success', '已使用临时高权限账号完成数据库结构修复，自动执行 SQL ' . $executed . ' 条。');
            } else {
                set_flash('error', '临时高权限账号已执行修复，但仍有未完成项，请查看失败项和待执行 SQL。');
            }

            try {
                $this->mobileAdminLog('移动端使用临时数据库账号修复结构', 'maintenance', null);
            } catch (\Throwable $logException) {
                Logger::error('移动端记录临时数据库修复日志失败：' . $logException->getMessage());
            }
        } catch (\Throwable $e) {
            Logger::error('移动端临时数据库账号修复失败：' . $e->getMessage());
            set_flash('error', '临时数据库管理员账号修复失败：' . $e->getMessage());
        }

        if ($originalPdo) {
            Database::swapConnection($originalPdo);
        } else {
            Database::resetConnection();
        }
        $this->redirect('admin/m/schema-audit');
    }

    public function manualPaidOrder()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $orderNo = trim(isset($_POST['order_no']) ? (string) $_POST['order_no'] : '');
            $order = $orderNo !== ''
                ? Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1', [$orderNo])
                : null;

            if (!$order || $order['status'] !== 'pending' || !in_array($order['type'], ['recharge', 'package'], true)) {
                set_flash('error', '仅支持处理待支付的充值或套餐订单。');
                $this->redirect('admin/m/orders');
            }

            (new PaymentService())->markOrderPaid($orderNo, 'MOBILE-MANUAL-' . date('YmdHis'), $order['pay_amount']);
            $this->mobileAdminLog('移动端手动补单', 'order', $order['id']);
            set_flash('success', $order['type'] === 'package' ? '补单成功，套餐已开通。' : '补单成功，余额已入账。');
        } catch (\Throwable $e) {
            set_flash('error', '补单失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/orders');
    }

    public function auditRecharge()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
            $action = isset($_POST['action']) ? (string) $_POST['action'] : '';
            $remark = trim(isset($_POST['remark']) ? (string) $_POST['remark'] : '');
            $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE id = ? LIMIT 1', [$id]);

            if (!$recharge || $recharge['status'] !== 'pending') {
                set_flash('error', '充值记录不存在或已经处理。');
                $this->redirect('admin/m/orders');
            }

            if ($action === 'approve') {
                Database::begin();
                try {
                    Database::execute(
                        'UPDATE ' . Database::table('recharges') . ' SET status = ?, auditor_id = ?, audit_remark = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                        ['paid', Auth::id(), $remark, now(), now(), $id]
                    );
                    Database::execute(
                        'UPDATE ' . Database::table('orders') . ' SET status = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                        ['paid', now(), now(), $recharge['order_id']]
                    );
                    (new BalanceService())->add($recharge['user_id'], $recharge['amount'], 'recharge', 'recharge', $id, '移动端人工充值审核通过');
                    (new NotificationService())->send($recharge['user_id'], 'recharge', '充值成功', '你的账户已充值 ' . $recharge['amount'] . ' 元。');
                    Database::commit();
                    set_flash('success', '充值审核已通过。');
                } catch (\Throwable $e) {
                    Database::rollBack();
                    set_flash('error', $e->getMessage());
                }
            } else {
                Database::execute(
                    'UPDATE ' . Database::table('recharges') . ' SET status = ?, auditor_id = ?, audit_remark = ?, updated_at = ? WHERE id = ?',
                    ['rejected', Auth::id(), $remark, now(), $id]
                );
                Database::execute(
                    'UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?',
                    ['closed', now(), $recharge['order_id']]
                );
                set_flash('success', '充值审核已拒绝。');
            }

            $this->mobileAdminLog('移动端审核充值', 'recharge', $id);
        } catch (\Throwable $e) {
            set_flash('error', '充值审核失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/orders');
    }

    public function updateSubsiteStatus()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        if (!$this->ensureMobileSubsiteSchema()) {
            set_flash('error', '分站数据结构未准备完成，请先执行数据库修复。');
            $this->redirect('admin/m/subsites');
        }

        $service = new SubsiteService();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $subsite = $service->find($id);
        if (!$subsite) {
            set_flash('error', '分站不存在。');
            $this->redirect('admin/m/subsites');
        }

        $status = isset($_POST['status']) ? (string) $_POST['status'] : $subsite['status'];
        if (!in_array($status, ['pending', 'active', 'suspended', 'rejected'], true)) {
            $status = $subsite['status'];
        }

        $domainStatus = null;
        if (isset($_POST['custom_domain_status']) && in_array($_POST['custom_domain_status'], ['none', 'pending', 'verified', 'failed'], true)) {
            $domainStatus = $_POST['custom_domain_status'];
        }

        try {
            $service->setAdminStatus($id, $status, $domainStatus, trim(isset($_POST['admin_remark']) ? (string) $_POST['admin_remark'] : ''));
            $this->mobileAdminLog('移动端更新分站状态', 'subsite', $id);
            set_flash('success', '分站状态已更新。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        $this->redirect('admin/m/subsites');
    }

    public function checkSubsiteDomain()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        if (!$this->ensureMobileSubsiteSchema()) {
            set_flash('error', '分站数据结构未准备完成，请先执行数据库修复。');
            $this->redirect('admin/m/subsites');
        }

        $service = new SubsiteService();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $subsite = $service->find($id);
        if (!$subsite) {
            set_flash('error', '分站不存在。');
            $this->redirect('admin/m/subsites');
        }

        try {
            $diagnostic = $service->domainDiagnostic($subsite);
            $service->setAdminStatus(
                $id,
                $subsite['status'],
                isset($diagnostic['custom_domain_status']) ? $diagnostic['custom_domain_status'] : null,
                isset($subsite['admin_remark']) ? $subsite['admin_remark'] : ''
            );
            $diagnostic['site'] = [
                'id' => $subsite['id'],
                'name' => $subsite['name'],
                'platform_domain' => $subsite['platform_domain'],
                'custom_domain' => $subsite['custom_domain'],
            ];
            $service->saveDomainDiagnostic($id, $diagnostic);
            set_flash('subsite_domain_diagnostic', $diagnostic);
            $this->mobileAdminLog('移动端检测分站域名', 'subsite', $id);
            set_flash($diagnostic['ok'] ? 'success' : 'error', $diagnostic['ok'] ? '域名接入检测通过。' : '域名接入检测完成，仍有步骤未通过。');
        } catch (\Throwable $e) {
            set_flash('error', '域名接入检测失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/subsites');
    }

    public function deleteSubsite()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        if (!$this->ensureMobileSubsiteSchema()) {
            set_flash('error', '分站数据结构未准备完成，请先执行数据库修复。');
            $this->redirect('admin/m/subsites');
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if ((new SubsiteService())->deleteByAdmin($id)) {
                $this->mobileAdminLog('移动端删除分站', 'subsite', $id);
                set_flash('success', '分站已删除。');
            } else {
                set_flash('error', '分站不存在或已被删除。');
            }
        } catch (\Throwable $e) {
            set_flash('error', '删除分站失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/subsites');
    }

    public function toggleMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        if (!$this->ensureMobileMonitorSchema()) {
            set_flash('error', '监控数据结构未准备完成，请先执行数据库修复。');
            $this->redirect('admin/m/servers');
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$server) {
            set_flash('error', '本站监控服务器不存在。');
            $this->redirect('admin/m/servers');
        }

        Database::execute(
            'UPDATE ' . Database::table('monitor_servers') . ' SET is_enabled = ?, updated_at = ? WHERE id = ? AND monitor_type = ?',
            [(int) !$server['is_enabled'], now(), $id, 'bt']
        );
        $this->mobileAdminLog('移动端切换监控状态', 'monitor_server', $id);
        set_flash('success', '监控状态已更新。');
        $this->redirect('admin/m/servers');
    }

    public function collectMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        if (!$this->ensureMobileMonitorSchema()) {
            set_flash('error', '监控数据结构未准备完成，请先执行数据库修复。');
            $this->redirect('admin/m/servers');
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$server) {
            set_flash('error', '本站监控服务器不存在。');
            $this->redirect('admin/m/servers');
        }

        try {
            (new MonitorService())->collect($server);
            $this->mobileAdminLog('移动端立即采集监控', 'monitor_server', $id);
            set_flash('success', '服务器状态已采集。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        $this->redirect('admin/m/servers');
    }

    public function deleteMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        if (!$this->ensureMobileMonitorSchema()) {
            set_flash('error', '监控数据结构未准备完成，请先执行数据库修复。');
            $this->redirect('admin/m/servers');
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? LIMIT 1', [$id, 'bt']);
        if (!$server) {
            set_flash('error', '本站监控服务器不存在。');
            $this->redirect('admin/m/servers');
        }

        try {
            Database::begin();
            Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$id]);
            Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$id]);
            try {
                Database::execute('DELETE FROM ' . Database::table('server_command_logs') . ' WHERE server_id = ?', [$id]);
                Database::execute('DELETE FROM ' . Database::table('server_ssh_sessions') . ' WHERE server_id = ?', [$id]);
                Database::execute('DELETE FROM ' . Database::table('server_monitor_pages') . ' WHERE server_id = ?', [$id]);
                $probeRows = Database::fetchAll('SELECT id FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ?', [$id]);
                foreach ($probeRows as $probeRow) {
                    Database::execute('DELETE FROM ' . Database::table('server_service_check_logs') . ' WHERE check_id = ?', [$probeRow['id']]);
                }
                Database::execute('DELETE FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ?', [$id]);
            } catch (\Throwable $ignored) {
                Logger::error('移动端删除监控附属记录失败：' . $ignored->getMessage());
            }
            Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ?', [$id, 'bt']);
            Database::commit();
            $this->mobileAdminLog('移动端删除本站监控服务器', 'monitor_server', $id);
            set_flash('success', '本站监控服务器已删除。');
        } catch (\Throwable $e) {
            Database::rollBack();
            set_flash('error', '删除服务器失败：' . $e->getMessage());
        }

        $this->redirect('admin/m/servers');
    }

    public function saveAnnouncement()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureAnnouncementSchema'], '公告管理')) {
                throw new \RuntimeException('公告数据结构未准备完成，请进入系统状态执行数据库修复。');
            }
            $title = trim((string) (isset($_POST['title']) ? $_POST['title'] : ''));
            $content = trim((string) (isset($_POST['content']) ? $_POST['content'] : ''));
            if ($title === '') {
                throw new \RuntimeException('请填写公告标题。');
            }
            if ($content === '') {
                throw new \RuntimeException('请填写公告内容。');
            }
            $categories = Announcement::categories();
            $category = isset($_POST['category']) && isset($categories[$_POST['category']]) ? $_POST['category'] : 'platform';
            $data = [
                'title' => text_limit($title, 150),
                'content' => $content,
                'category' => $category,
                'summary' => text_limit(trim((string) (isset($_POST['summary']) ? $_POST['summary'] : '')), 300),
                'cover_image' => text_limit(trim((string) (isset($_POST['cover_image']) ? $_POST['cover_image'] : '')), 255),
                'tags' => text_limit(trim((string) (isset($_POST['tags']) ? $_POST['tags'] : '')), 255),
                'content_format' => isset($_POST['content_format']) && $_POST['content_format'] === 'html' ? 'html' : 'plain',
                'is_top' => isset($_POST['is_top']) ? 1 : 0,
                'show_home' => isset($_POST['show_home']) ? 1 : 0,
                'status' => isset($_POST['status']) && (string) $_POST['status'] === '0' ? 0 : 1,
                'published_at' => trim((string) (isset($_POST['published_at']) ? $_POST['published_at'] : '')) ?: now(),
                'updated_at' => now(),
            ];
            if (!empty($_POST['id'])) {
                $id = (int) $_POST['id'];
                Database::execute(
                    'UPDATE ' . Database::table('announcements') . ' SET title=?, content=?, category=?, summary=?, cover_image=?, tags=?, content_format=?, is_top=?, show_home=?, status=?, published_at=?, updated_at=? WHERE id=?',
                    [$data['title'], $data['content'], $data['category'], $data['summary'], $data['cover_image'], $data['tags'], $data['content_format'], $data['is_top'], $data['show_home'], $data['status'], $data['published_at'], $data['updated_at'], $id]
                );
            } else {
                Database::execute(
                    'INSERT INTO ' . Database::table('announcements') . ' (title, content, category, summary, cover_image, tags, content_format, is_top, show_home, status, published_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [$data['title'], $data['content'], $data['category'], $data['summary'], $data['cover_image'], $data['tags'], $data['content_format'], $data['is_top'], $data['show_home'], $data['status'], $data['published_at'], now(), now()]
                );
                $id = (int) Database::lastInsertId();
            }
            $this->mobileAdminLog('移动端保存公告', 'announcement', $id);
            set_flash('success', '公告已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存公告失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/announcements');
    }

    public function deleteAnnouncement()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureAnnouncementSchema'], '公告管理')) {
                throw new \RuntimeException('公告数据结构未准备完成，请进入系统状态执行数据库修复。');
            }
            Database::execute('DELETE FROM ' . Database::table('announcements') . ' WHERE id = ?', [$id]);
            $this->mobileAdminLog('移动端删除公告', 'announcement', $id);
            set_flash('success', '公告已删除。');
        } catch (\Throwable $e) {
            set_flash('error', '删除公告失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/announcements');
    }

    public function saveUploadLimits()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $rules = [
            'upload_max_concurrency' => [1, 8],
            'upload_image_batch_limit' => [1, 500],
            'upload_file_batch_limit' => [1, 300],
            'upload_image_daily_limit' => [0, 1000000],
            'upload_file_daily_limit' => [0, 1000000],
        ];
        foreach ($rules as $key => $range) {
            $value = isset($_POST[$key]) ? (int) $_POST[$key] : 0;
            $value = max((int) $range[0], min((int) $range[1], $value));
            $this->saveSettingValue($key, (string) $value);
        }
        $this->mobileAdminLog('移动端保存上传限制', 'setting', null);
        set_flash('success', '上传限制已保存。');
        $this->redirect('admin/m/upload-limits');
    }

    public function saveSettingsSite()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->saveSettingsValues([
                'site_name',
                'site_public_url',
                'site_logo',
                'seo_keywords',
                'seo_description',
                'file_naming_strategy',
                'default_free_package_id',
                'default_theme',
            ]);
            $this->mobileAdminLog('移动端保存站点设置', 'setting', null);
            set_flash('success', '站点设置已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存站点设置失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    public function saveSettingsSecurity()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->saveSettingsValues([
                'register_enabled',
                'register_email_code_enabled',
                'security_login_max_attempts',
                'security_login_window_minutes',
                'security_login_lock_minutes',
                'security_email_code_max_per_hour',
                'security_email_code_ip_max_per_hour',
            ]);
            $this->mobileAdminLog('移动端保存安全设置', 'setting', null);
            set_flash('success', '安全与注册设置已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存安全设置失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    public function saveSettingsUpload()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->saveSettingsValues([
                'user_image_upload_enabled',
                'user_netdisk_enabled',
                'guest_image_upload_enabled',
                'guest_image_upload_user_id',
                'guest_image_upload_max_size',
                'guest_image_upload_daily_ip_limit',
            ]);
            $this->mobileAdminLog('移动端保存上传权限设置', 'setting', null);
            set_flash('success', '上传权限设置已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存上传权限失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    public function saveSettingsApi()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->saveSettingsValues(['api_rate_limit_per_minute', 'api_rate_limit_per_day']);
            $this->mobileAdminLog('移动端保存 API 限制设置', 'setting', null);
            set_flash('success', 'API 限制已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存 API 限制失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    public function saveSettingsEmail()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $this->saveSettingsValues(['email_host', 'email_port', 'email_username', 'email_password', 'email_from']);
            $this->mobileAdminLog('移动端保存邮件设置', 'setting', null);
            set_flash('success', '邮件服务设置已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存邮件设置失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    public function saveSettingsNotify()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            $settings = [
                'alert_webhook_enabled' => isset($_POST['alert_webhook_enabled']) && (string) $_POST['alert_webhook_enabled'] === '1' ? '1' : '0',
                'alert_wecom_webhook' => trim((string) (isset($_POST['alert_wecom_webhook']) ? $_POST['alert_wecom_webhook'] : '')),
                'alert_dingtalk_webhook' => trim((string) (isset($_POST['alert_dingtalk_webhook']) ? $_POST['alert_dingtalk_webhook'] : '')),
                'alert_dingtalk_secret' => trim((string) (isset($_POST['alert_dingtalk_secret']) ? $_POST['alert_dingtalk_secret'] : '')),
                'alert_telegram_bot_token' => trim((string) (isset($_POST['alert_telegram_bot_token']) ? $_POST['alert_telegram_bot_token'] : '')),
                'alert_telegram_chat_id' => trim((string) (isset($_POST['alert_telegram_chat_id']) ? $_POST['alert_telegram_chat_id'] : '')),
            ];
            $errors = (new AlertWebhookService())->validateSettings($settings);
            if ($errors) {
                throw new \RuntimeException(implode(' ', $errors));
            }

            $existing = $this->settingsMap();
            foreach ($settings as $key => $value) {
                if (in_array($key, ['alert_wecom_webhook', 'alert_dingtalk_webhook', 'alert_dingtalk_secret', 'alert_telegram_bot_token'], true)) {
                    if ($value === '' && isset($existing[$key]) && (string) $existing[$key] !== '') {
                        $value = (string) $existing[$key];
                    } elseif ($value !== '') {
                        $value = CryptoService::encrypt($value);
                    }
                }
                $this->saveSettingValue($key, $value);
            }
            $this->mobileAdminLog('移动端保存告警通知通道', 'setting', null);
            set_flash('success', '告警通知通道已保存。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '保存告警通知通道失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    public function testNotifyChannel()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        $service = new AlertWebhookService();
        $channel = $service->normalizeChannel(isset($_POST['channel']) ? $_POST['channel'] : '');
        if ($channel === '') {
            set_flash('error', '请选择要测试的告警通知通道。');
            $this->redirect('admin/m/settings');
        }
        $result = $service->test($channel);
        set_flash(!empty($result['success']) ? 'success' : 'error', !empty($result['success']) ? '测试消息已发送。' : ('测试发送失败：' . (isset($result['message']) ? $result['message'] : '未知错误')));
        $this->redirect('admin/m/settings');
    }

    public function saveThemes()
    {
        $this->requireAdmin();
        $this->verifyCsrf();

        try {
            if (!$this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserThemeSchema'], '主题设置') && !DatabaseUpgradeService::standardSchemaReady()) {
                throw new \RuntimeException('主题偏好字段未准备完成，请先执行数据库修复。');
            }
            $adminStyle = $this->themeStyle(isset($_POST['admin_theme_style']) ? $_POST['admin_theme_style'] : 'anime');
            $frontendStyle = $this->themeStyle(isset($_POST['frontend_theme_style']) ? $_POST['frontend_theme_style'] : 'anime');
            $homeStyle = $this->frontendHomeStyle(isset($_POST['frontend_home_style']) ? $_POST['frontend_home_style'] : 'default');
            Database::execute('UPDATE ' . Database::table('users') . ' SET admin_theme_style = ?, updated_at = ? WHERE id = ?', [$adminStyle, now(), Auth::id()]);
            $this->saveSettingValue('frontend_theme_style', $frontendStyle);
            $this->saveSettingValue('frontend_home_style', $homeStyle);
            $this->mobileAdminLog('移动端保存主题设置', 'setting', null);
            set_flash('success', '主题切换成功～');
        } catch (\Throwable $e) {
            set_flash('error', '保存主题设置失败：' . $e->getMessage());
        }
        $this->redirect('admin/m/settings');
    }

    protected function prepareSchemas()
    {
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureRuntimeSchema'], '运行时结构');
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理');
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'], '服务器运维');
    }

    protected function dashboardStats()
    {
        return [
            'users' => $this->safeCount('users'),
            'today_users' => $this->safeCount('users', 'DATE(created_at) = CURDATE()'),
            'files' => $this->safeCount('files'),
            'storage' => $this->safeScalar('SELECT COALESCE(SUM(file_size),0) AS v FROM ' . Database::table('files')),
            'orders_pending' => $this->safeCount('orders', "status = 'pending'"),
            'recharges_pending' => $this->safeCount('recharges', "status = 'pending'"),
            'offline_servers' => $this->safeCount('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'"),
            'subsites_pending' => $this->safeCount('subsites', "status = 'pending'"),
            'backup_failed' => $this->safeCount('file_storage_backups', "status = 'failed'"),
        ];
    }

    protected function todos()
    {
        return [
            ['label' => '待处理订单', 'value' => $this->safeCount('orders', "status = 'pending'"), 'url' => 'admin/m/orders', 'icon' => 'receipt-text'],
            ['label' => '充值审核', 'value' => $this->safeCount('recharges', "status = 'pending'"), 'url' => 'admin/m/orders', 'icon' => 'wallet-cards'],
            ['label' => '离线服务器', 'value' => $this->safeCount('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'"), 'url' => 'admin/m/servers', 'icon' => 'activity'],
            ['label' => '分站审核', 'value' => $this->safeCount('subsites', "status = 'pending'"), 'url' => 'admin/m/subsites', 'icon' => 'globe-2'],
        ];
    }

    protected function mobileOpsAlerts()
    {
        $alerts = [];
        $schemaOk = true;
        try {
            $schemaOk = DatabaseUpgradeService::standardSchemaReady();
        } catch (\Throwable $e) {
            $schemaOk = false;
        }
        if (!$schemaOk) {
            $alerts[] = ['level' => 'danger', 'icon' => 'database-zap', 'title' => '数据库结构待修复', 'desc' => '部分表或字段未匹配当前程序。', 'value' => '待修复', 'url' => 'admin/m/settings'];
        }

        $defaultStorage = $this->safeCount('storage_drivers', 'is_default = 1 AND is_enabled = 1');
        $enabledStorage = $this->safeCount('storage_drivers', 'is_enabled = 1');
        if ($defaultStorage <= 0 || $enabledStorage <= 0) {
            $alerts[] = ['level' => 'danger', 'icon' => 'database', 'title' => '默认存储不可用', 'desc' => '上传会失败，请配置并测试存储源。', 'value' => $enabledStorage . ' 个启用', 'url' => 'admin/m/storages'];
        }

        $failedBackups = $this->safeCount('file_storage_backups', "status = 'failed'");
        if ($failedBackups > 0) {
            $alerts[] = ['level' => 'warning', 'icon' => 'database-backup', 'title' => '备份任务失败', 'desc' => '请检查备份目标权限或重试失败任务。', 'value' => $failedBackups, 'url' => 'admin/m/storage-backups'];
        }

        $pendingRecharges = $this->safeCount('recharges', "status = 'pending'");
        if ($pendingRecharges > 0) {
            $alerts[] = ['level' => 'warning', 'icon' => 'wallet-cards', 'title' => '充值待审核', 'desc' => '人工充值需要及时处理。', 'value' => $pendingRecharges, 'url' => 'admin/m/orders'];
        }

        $offlineServers = $this->safeCount('monitor_servers', "monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'");
        if ($offlineServers > 0) {
            $alerts[] = ['level' => 'danger', 'icon' => 'activity', 'title' => '服务器监控离线', 'desc' => '请检查面板 API、定时采集和网络。', 'value' => $offlineServers, 'url' => 'admin/m/servers'];
        }

        $apiFailures = $this->safeCount('api_logs', 'is_success = 0 AND DATE(created_at) = CURDATE()');
        if ($apiFailures > 0) {
            $alerts[] = ['level' => 'warning', 'icon' => 'shield-alert', 'title' => 'API 异常请求', 'desc' => '今日有接口鉴权或上传失败记录。', 'value' => $apiFailures, 'url' => 'admin/m/logs'];
        }

        $fileUploads = strtolower((string) ini_get('file_uploads'));
        if (in_array($fileUploads, ['0', 'off', 'false'], true)) {
            $alerts[] = ['level' => 'danger', 'icon' => 'upload-cloud', 'title' => 'PHP 上传未开启', 'desc' => 'file_uploads 关闭会阻断所有上传。', 'value' => $fileUploads, 'url' => 'admin/m/settings'];
        }

        $postBytes = $this->iniBytes(ini_get('post_max_size'));
        $uploadBytes = $this->iniBytes(ini_get('upload_max_filesize'));
        if ($postBytes > 0 && $uploadBytes > 0 && $postBytes < $uploadBytes) {
            $alerts[] = ['level' => 'danger', 'icon' => 'upload-cloud', 'title' => '上传限制不匹配', 'desc' => 'post_max_size 小于 upload_max_filesize。', 'value' => (ini_get('post_max_size') ?: '-') . ' / ' . (ini_get('upload_max_filesize') ?: '-'), 'url' => 'admin/m/upload-limits'];
        }

        if (!$alerts) {
            $alerts[] = ['level' => 'ok', 'icon' => 'circle-check', 'title' => '核心状态正常', 'desc' => '数据库、存储、上传和待办暂无阻断项。', 'value' => '正常', 'url' => 'admin/m/menu'];
        }

        return array_slice($alerts, 0, 6);
    }

    protected function safeRows($sql, array $params = [])
    {
        try {
            return Database::fetchAll($sql, $params);
        } catch (\Throwable $e) {
            return [];
        }
    }

    protected function mobileIncidentApiRows()
    {
        return $this->mobileApiLogRows(20, true);
    }

    protected function mobileApiLogRows($limit = 40, $failedOnly = false)
    {
        $hasApiAppLog = $this->mobileTableExists('api_apps') && $this->columnExists(Database::table('api_logs'), 'app_id');
        $appSelect = $hasApiAppLog ? ', a.name AS api_app_name' : ", '' AS api_app_name";
        $appJoin = $hasApiAppLog ? ' LEFT JOIN ' . Database::table('api_apps') . ' a ON l.app_id = a.id' : '';
        $where = $failedOnly ? ' WHERE l.is_success = 0' : '';
        return $this->safeRows(
            'SELECT l.*, u.username' . $appSelect . '
             FROM ' . Database::table('api_logs') . ' l
             LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id
             ' . $appJoin . '
             ' . $where . '
             ORDER BY l.id DESC' . Database::limitClause($limit, 1, 80)
        );
    }

    protected function mobileIncidentBackupRows()
    {
        return $this->safeRows(
            'SELECT b.*, f.original_name, s.name AS storage_name
             FROM ' . Database::table('file_storage_backups') . ' b
             LEFT JOIN ' . Database::table('files') . ' f ON b.file_id = f.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON b.storage_id = s.id
             WHERE b.status = \'failed\'
             ORDER BY b.updated_at DESC, b.id DESC LIMIT 20'
        );
    }

    protected function mobileIncidentCommandRows()
    {
        return $this->safeRows(
            'SELECT cl.*, u.username
             FROM ' . Database::table('server_command_logs') . ' cl
             LEFT JOIN ' . Database::table('users') . ' u ON cl.user_id = u.id
             WHERE cl.risk_level IN (\'warning\',\'danger\')
             ORDER BY cl.id DESC LIMIT 20'
        );
    }

    protected function mobileIncidentUploadFailureRows($limit = 20)
    {
        $limitClause = Database::limitClause((int) $limit, 1, 100, 20);
        return $this->safeRows(
            'SELECT uf.*, u.username, s.name AS storage_name
             FROM ' . Database::table('upload_failures') . ' uf
             LEFT JOIN ' . Database::table('users') . ' u ON uf.user_id = u.id
             LEFT JOIN ' . Database::table('storage_drivers') . ' s ON uf.storage_id = s.id
             ORDER BY uf.id DESC' . $limitClause
        );
    }

    protected function uploadFailureStageLabel($errorType)
    {
        $labels = [
            'php_upload_limit' => 'PHP 上传环境',
            'quota_or_permission' => '套餐或权限',
            'storage' => '对象存储',
            'storage_config' => '存储配置',
            'storage_upload' => '对象写入',
            'storage_url' => '外链访问',
            'storage_delete' => '删除清理',
            'storage_db' => '数据库入库',
            'schema' => '数据库结构',
        ];
        return isset($labels[$errorType]) ? $labels[$errorType] : '';
    }

    protected function safeCount($table, $where = '', array $params = [])
    {
        try {
            $sql = 'SELECT COUNT(*) AS c FROM ' . Database::table($table);
            if ($where !== '') {
                $sql .= ' WHERE ' . $where;
            }
            $row = Database::fetch($sql, $params);
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function ensureMobileSubsiteSchema()
    {
        return $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'], '分站管理');
    }

    protected function ensureMobileMonitorSchema()
    {
        return $this->combinedSchemaReady([
            [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
            [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
        ], '服务器监控');
    }

    protected function ensureMobileRepositorySchema()
    {
        return $this->combinedSchemaReady([
            [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
            [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
        ], '分享仓库');
    }

    protected function ensureMobileStorageBackupSchema()
    {
        return $this->combinedSchemaReady([
            [DatabaseUpgradeService::class, 'ensureStorageDriverTypes'],
            [DatabaseUpgradeService::class, 'ensureStorageSecretEncryption'],
            [DatabaseUpgradeService::class, 'ensureStorageBackupSchema'],
        ], '多存储备份');
    }

    protected function ensureMobileStorageDriverSchema()
    {
        return $this->combinedSchemaReady([
            [DatabaseUpgradeService::class, 'ensureStorageDriverTypes'],
            [DatabaseUpgradeService::class, 'ensureStorageSecretEncryption'],
        ], '资源功能管理') || DatabaseUpgradeService::standardSchemaReady();
    }

    protected function safeSchemaReady(callable $callback, $featureLabel = '')
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            Logger::error('移动端结构检查失败：' . $featureLabel . ' / ' . $e->getMessage());
            return false;
        }
    }

    protected function combinedSchemaReady(array $callbacks, $featureLabel = '')
    {
        foreach ($callbacks as $callback) {
            if (!$this->safeSchemaReady($callback, $featureLabel)) {
                return false;
            }
        }
        return true;
    }

    protected function mobileSchemaFlash($featureLabel)
    {
        set_flash('error', $featureLabel . '数据结构未准备完成，当前页面已降级显示。请进入系统状态执行数据库修复，或打开移动数据库巡检查看待执行 SQL。');
    }

    protected function mobilePaymentStats(array $rows)
    {
        $stats = [
            'total' => count($rows),
            'enabled' => 0,
            'manual' => 0,
            'online' => 0,
            'configured' => 0,
        ];
        foreach ($rows as $row) {
            $config = json_decode((string) (isset($row['config']) ? $row['config'] : ''), true);
            $config = is_array($config) ? $config : [];
            if (!empty($row['is_enabled'])) {
                $stats['enabled']++;
            }
            if (isset($row['code']) && $row['code'] === 'manual') {
                $stats['manual']++;
            } else {
                $stats['online']++;
            }
            if (isset($row['code']) && $row['code'] === 'alipay') {
                if (!empty($config['app_id']) && !empty($config['private_key']) && !empty($config['alipay_public_key'])) {
                    $stats['configured']++;
                }
            } elseif (isset($row['code']) && $row['code'] === 'manual') {
                if (!empty($config['instructions']) || !empty($config['contact'])) {
                    $stats['configured']++;
                }
            } elseif (!empty($config) || (isset($row['code']) && $row['code'] === 'balance')) {
                $stats['configured']++;
            }
        }
        return $stats;
    }

    protected function mobileNormalizeStorageInput(array $data)
    {
        foreach (['access_key', 'secret_key', 'bucket', 'region', 'endpoint', 'domain', 'prefix'] as $field) {
            $data[$field] = trim((string) $data[$field]);
        }
        $data['endpoint'] = rtrim($data['endpoint'], '/');
        $data['domain'] = rtrim($data['domain'], '/');
        if ($data['type'] === 'oss') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
            $data['endpoint'] = preg_replace('#/.*$#', '', $data['endpoint']);
            if ($data['bucket'] !== '') {
                $data['endpoint'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#', '', $data['endpoint']);
            }
        }
        if ($data['type'] === 'cos' && $data['endpoint'] !== '') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
            $data['endpoint'] = preg_replace('#/.*$#', '', $data['endpoint']);
            if ($data['bucket'] !== '') {
                $data['endpoint'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#', '', $data['endpoint']);
            }
        }
        if ($data['type'] === 'kodo') {
            $data['region'] = $this->mobileNormalizeKodoRegion($data['region']);
            if ($data['endpoint'] !== '') {
                $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
                $data['endpoint'] = preg_replace('#/.*$#', '', $data['endpoint']);
            }
        }
        if (in_array($data['type'], ['s3', 'minio', 'r2'], true) && $data['endpoint'] !== '') {
            if (!preg_match('#^https?://#i', $data['endpoint'])) {
                $data['endpoint'] = 'https://' . $data['endpoint'];
            }
            $parts = parse_url($data['endpoint']);
            if ($parts && !empty($parts['host'])) {
                $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
                $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
                $path = isset($parts['path']) ? trim($parts['path'], '/') : '';
                if ($data['bucket'] !== '' && ($path === $data['bucket'] || strpos($path, $data['bucket'] . '/') === 0)) {
                    $path = trim(substr($path, strlen($data['bucket'])), '/');
                }
                if ($data['type'] === 'r2') {
                    $path = '';
                }
                if ($data['bucket'] !== '' && stripos($parts['host'], $data['bucket'] . '.') === 0) {
                    $parts['host'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#i', '', $parts['host']);
                    $path = '';
                }
                $data['endpoint'] = rtrim($scheme . '://' . $parts['host'] . $port . ($path !== '' ? '/' . $path : ''), '/');
            }
        }
        if ($data['type'] === 'webdav') {
            if ($data['endpoint'] !== '' && !preg_match('#^https?://#i', $data['endpoint'])) {
                $data['endpoint'] = 'https://' . $data['endpoint'];
            }
            $data['bucket'] = trim($data['bucket'], '/');
            $data['region'] = '';
        }
        if ($data['domain'] !== '' && !preg_match('#^https?://#i', $data['domain'])) {
            $data['domain'] = 'https://' . $data['domain'];
        }
        if ($data['endpoint'] !== '' && in_array($data['type'], ['kodo', 'bmtools'], true) && !preg_match('#^https?://#i', $data['endpoint'])) {
            $data['endpoint'] = 'https://' . $data['endpoint'];
        }
        if ($data['type'] === 'bmtools') {
            $data['access_key'] = '';
            $data['bucket'] = '';
            $data['region'] = '';
            $data['domain'] = '';
        }
        return $data;
    }

    protected function mobileValidateStorageInput(array $data, $secret)
    {
        if ($data['name'] === '') {
            return '请填写存储名称。';
        }
        if ($data['type'] === 'local') {
            return '';
        }
        if ($data['type'] === 'bmtools') {
            if ($data['endpoint'] === '') {
                return '请填写同系统站点地址。';
            }
            if (!preg_match('#^https://#i', $data['endpoint'])) {
                return '同系统站点地址必须使用 HTTPS。';
            }
            $parts = parse_url($data['endpoint']);
            if (!$parts || empty($parts['host']) || !empty($parts['user']) || !empty($parts['pass']) || !empty($parts['query']) || !empty($parts['fragment'])) {
                return '同系统站点地址格式不正确，请只填写站点根地址。';
            }
            if ($this->mobileIsCurrentSiteEndpoint($data['endpoint'])) {
                return '同系统站点不能填写当前站点自身地址。';
            }
            if ($secret === '') {
                return '请填写同系统对接 Token。';
            }
            return '';
        }
        if ($data['type'] === 'webdav') {
            if ($data['endpoint'] === '') {
                return '请填写 WebDAV 地址。';
            }
            $parts = parse_url($data['endpoint']);
            if (!$parts || empty($parts['host']) || !in_array(strtolower(isset($parts['scheme']) ? $parts['scheme'] : ''), ['http', 'https'], true)) {
                return 'WebDAV 地址格式不正确。';
            }
            if ($data['access_key'] === '') {
                return '请填写 WebDAV 用户名。';
            }
            if ($secret === '') {
                return '请填写 WebDAV 密码。';
            }
            return '';
        }
        if ($data['access_key'] === '') {
            return $data['type'] === 'cos' ? '请填写腾讯云 SecretId。' : '请填写 AccessKey。';
        }
        if ($secret === '') {
            return $data['type'] === 'cos' ? '请填写腾讯云 SecretKey。' : '请填写 SecretKey。';
        }
        if ($data['bucket'] === '') {
            return '请填写 Bucket 名称。';
        }
        if ($data['type'] === 'oss' && $data['endpoint'] === '') {
            return '请填写阿里云 OSS Endpoint。';
        }
        if ($data['type'] === 'cos' && $data['region'] === '' && $data['endpoint'] === '') {
            return '请填写腾讯云 COS 地域或 Endpoint。';
        }
        if ($data['type'] === 'kodo' && $data['domain'] === '') {
            return '请填写七牛云访问域名。';
        }
        if ($data['type'] === 'kodo' && $data['region'] !== '' && !in_array($data['region'], ['z0', 'z1', 'z2', 'na0', 'as0', 'cn-east-2', 'ap-southeast-2', 'ap-southeast-3'], true)) {
            return '七牛云区域不正确，请选择华东、华东浙江2、华北、华南、北美、亚太新加坡、亚太河内或亚太胡志明。';
        }
        if ($data['type'] === 's3' && $data['endpoint'] === '' && $data['region'] === '') {
            return '请填写 S3 Endpoint 或 Region。';
        }
        if ($data['type'] === 'minio' && $data['endpoint'] === '') {
            return '请填写 MinIO Endpoint。';
        }
        if ($data['type'] === 'r2' && $data['endpoint'] === '') {
            return '请填写 Cloudflare R2 Endpoint。';
        }
        return '';
    }

    protected function mobileNormalizeKodoRegion($region)
    {
        $region = strtolower(trim((string) $region));
        $aliases = [
            'huadong' => 'z0',
            'east' => 'z0',
            'cn-east-1' => 'z0',
            '华东' => 'z0',
            '华东-浙江' => 'z0',
            'zhejiang' => 'z0',
            'huabei' => 'z1',
            'north' => 'z1',
            'cn-north-1' => 'z1',
            '华北' => 'z1',
            '华北-河北' => 'z1',
            'hebei' => 'z1',
            'huanan' => 'z2',
            'south' => 'z2',
            'cn-south-1' => 'z2',
            '华南' => 'z2',
            '华南-广东' => 'z2',
            'guangdong' => 'z2',
            'beimei' => 'na0',
            'north-america' => 'na0',
            'america' => 'na0',
            'us-north-1' => 'na0',
            '北美' => 'na0',
            '亚太' => 'as0',
            '亚太-新加坡' => 'as0',
            'singapore' => 'as0',
            'ap-southeast' => 'as0',
            'ap-southeast-1' => 'as0',
            '华东-浙江2' => 'cn-east-2',
            'zhejiang2' => 'cn-east-2',
            '亚太-河内' => 'ap-southeast-2',
            'hanoi' => 'ap-southeast-2',
            'vietnam' => 'ap-southeast-2',
            '亚太-胡志明' => 'ap-southeast-3',
            'ho-chi-minh' => 'ap-southeast-3',
            'hcm' => 'ap-southeast-3',
            'up.qiniup.com' => 'z0',
            'upload.qiniup.com' => 'z0',
            'up-z0.qiniup.com' => 'z0',
            'upload-z0.qiniup.com' => 'z0',
            'up-cn-east-2.qiniup.com' => 'cn-east-2',
            'upload-cn-east-2.qiniup.com' => 'cn-east-2',
            'up-z1.qiniup.com' => 'z1',
            'upload-z1.qiniup.com' => 'z1',
            'up-z2.qiniup.com' => 'z2',
            'upload-z2.qiniup.com' => 'z2',
            'up-na0.qiniup.com' => 'na0',
            'upload-na0.qiniup.com' => 'na0',
            'up-as0.qiniup.com' => 'as0',
            'upload-as0.qiniup.com' => 'as0',
            'up-ap-southeast-2.qiniup.com' => 'ap-southeast-2',
            'upload-ap-southeast-2.qiniup.com' => 'ap-southeast-2',
            'up-ap-southeast-3.qiniup.com' => 'ap-southeast-3',
            'upload-ap-southeast-3.qiniup.com' => 'ap-southeast-3',
        ];
        return isset($aliases[$region]) ? $aliases[$region] : $region;
    }

    protected function mobileIsCurrentSiteEndpoint($endpoint)
    {
        $host = parse_url($endpoint, PHP_URL_HOST);
        if (!$host) {
            return false;
        }
        $current = !empty($_SERVER['HTTP_HOST']) ? parse_url('https://' . $_SERVER['HTTP_HOST'], PHP_URL_HOST) : '';
        if ($current && strtolower($host) === strtolower($current)) {
            return true;
        }
        $publicHost = parse_url(public_url('/'), PHP_URL_HOST);
        return $publicHost && strtolower($host) === strtolower($publicHost);
    }

    protected function mobilePackageById($id)
    {
        $id = (int) $id;
        if ($id <= 0) {
            return null;
        }
        return Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$id]);
    }

    protected function mobilePackageQuota($package, array $oldUser = null)
    {
        if (!$package) {
            return [
                'total_storage' => $oldUser && isset($oldUser['total_storage']) ? (int) $oldUser['total_storage'] : 0,
                'total_traffic' => $oldUser && isset($oldUser['total_traffic']) ? (int) $oldUser['total_traffic'] : 0,
                'package_expire_time' => null,
            ];
        }
        $expire = null;
        if (isset($package['duration_type']) && $package['duration_type'] !== 'forever') {
            $days = max(1, (int) (isset($package['duration_days']) ? $package['duration_days'] : 30));
            $expire = date('Y-m-d H:i:s', time() + $days * 86400);
        }
        return [
            'total_storage' => (int) (isset($package['storage_limit']) ? $package['storage_limit'] : ($oldUser && isset($oldUser['total_storage']) ? $oldUser['total_storage'] : 0)),
            'total_traffic' => (int) (isset($package['traffic_limit']) ? $package['traffic_limit'] : ($oldUser && isset($oldUser['total_traffic']) ? $oldUser['total_traffic'] : 0)),
            'package_expire_time' => $expire,
        ];
    }

    protected function settingsMap()
    {
        $settings = [];
        try {
            foreach (Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings')) as $row) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
        } catch (\Throwable $e) {
            Logger::error('移动端读取系统设置失败：' . $e->getMessage());
        }
        return $settings;
    }

    protected function settingValue(array $settings, $key, $default = '')
    {
        return array_key_exists($key, $settings) ? $settings[$key] : $default;
    }

    protected function saveSettingsValues(array $keys)
    {
        $existingSettings = $this->settingsMap();
        foreach ($keys as $key) {
            if (!array_key_exists($key, $_POST)) {
                continue;
            }
            $value = $_POST[$key];
            if ($key === 'email_password') {
                $value = trim((string) $value);
                if ($value === '' && array_key_exists($key, $existingSettings)) {
                    $value = $existingSettings[$key];
                } elseif ($value !== '') {
                    $value = CryptoService::encrypt($value);
                }
            }
            if ($key === 'site_public_url') {
                $value = trim((string) $value);
                if ($value !== '' && !preg_match('#^https?://#i', $value)) {
                    $value = 'https://' . $value;
                }
                $value = rtrim($value, '/');
            }
            if ($key === 'file_naming_strategy') {
                $value = in_array((string) $value, ['random', 'timestamp', 'hash', 'original'], true) ? (string) $value : 'random';
            }
            if ($key === 'default_theme') {
                $value = $this->themeMode($value);
            }
            if (in_array($key, ['register_enabled', 'register_email_code_enabled', 'user_image_upload_enabled', 'user_netdisk_enabled', 'guest_image_upload_enabled'], true)) {
                $value = (string) ((string) $value === '1' ? 1 : 0);
            }
            if (in_array($key, ['guest_image_upload_user_id', 'guest_image_upload_max_size', 'guest_image_upload_daily_ip_limit', 'security_login_max_attempts', 'security_login_window_minutes', 'security_login_lock_minutes', 'security_email_code_max_per_hour', 'security_email_code_ip_max_per_hour', 'default_free_package_id', 'api_rate_limit_per_minute', 'api_rate_limit_per_day', 'email_port'], true)) {
                $value = (string) max(0, (int) $value);
            }
            $this->saveSettingValue($key, (string) $value);
        }
    }

    protected function themeStyle($value)
    {
        return (string) $value === 'anime' ? 'anime' : 'anime';
    }

    protected function frontendHomeStyle($value)
    {
        $value = (string) $value;
        return in_array($value, ['default', 'terminal', 'technology', 'anime', 'business', 'blog'], true) ? $value : 'default';
    }

    protected function themeMode($value)
    {
        $value = (string) $value;
        return in_array($value, ['auto', 'light', 'dark'], true) ? $value : 'auto';
    }

    protected function adminThemeValue()
    {
        $user = Auth::user();
        return $user && isset($user['admin_theme_style']) ? $this->themeStyle($user['admin_theme_style']) : 'anime';
    }

    protected function saveSettingValue($key, $value)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('settings') . ' (setting_key, setting_value, created_at, updated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
            [$key, (string) $value, now(), now()]
        );
    }

    protected function mobileNormalizeDateTime($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace('T', ' ', $value);
        if (strlen($value) === 16) {
            $value .= ':00';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value) || strtotime($value) === false) {
            throw new \RuntimeException('时间格式不正确。');
        }
        return $value;
    }

    protected function columnExists($table, $column)
    {
        try {
            return (bool) Database::columnExists($table, $column);
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function mobileTableExists($table)
    {
        try {
            return Database::tableExists(Database::table($table));
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function mobileAdminLog($action, $targetType = null, $targetId = null)
    {
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('admin_logs') . ' (admin_id, action, target_type, target_id, ip, detail, created_at) VALUES (?,?,?,?,?,?,?)',
                [Auth::id(), $action, $targetType, $targetId, Auth::ip(), json_encode($this->redactLogData($_POST), JSON_UNESCAPED_UNICODE), now()]
            );
        } catch (\Throwable $e) {
            // Mobile operations should not fail because logging is unavailable.
        }
    }

    protected function redactLogData(array $data)
    {
        foreach ($data as $key => $value) {
            if (preg_match('/(password|secret|token|key|api_key)/i', (string) $key)) {
                $data[$key] = $value === '' ? '' : '******';
            } elseif (is_array($value)) {
                $data[$key] = $this->redactLogData($value);
            }
        }
        return $data;
    }

    protected function safeScalar($sql, array $params = [])
    {
        try {
            $row = Database::fetch($sql, $params);
            return $row ? (float) $row['v'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
