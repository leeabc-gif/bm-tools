<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Services\Payment\AlipayF2FGateway;
use App\Services\Payment\PaymentService;

class PaymentController extends Controller
{
    public function alipayPage()
    {
        $this->requireLogin();
        $orderNo = isset($_GET['order_no']) ? trim($_GET['order_no']) : '';
        $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? AND user_id = ? LIMIT 1', [$orderNo, Auth::id()]);
        if (!$order) {
            http_response_code(404);
            echo '订单不存在';
            return;
        }
        $qrCode = isset($_SESSION['alipay_qr'][$orderNo]) ? $_SESSION['alipay_qr'][$orderNo] : '';
        $this->view('recharge/alipay', [
            'title' => '支付宝扫码支付',
            'order' => $order,
            'qrCode' => $qrCode,
        ]);
    }

    public function alipayNotify()
    {
        $payload = $_POST;
        Logger::info('支付宝异步通知', $this->redactPayload($payload));
        $gateway = new AlipayF2FGateway(AlipayF2FGateway::config());
        if (!$gateway->verifyNotify($payload)) {
            echo 'failure';
            return;
        }

        $status = isset($payload['trade_status']) ? $payload['trade_status'] : '';
        if (!in_array($status, ['TRADE_SUCCESS', 'TRADE_FINISHED'], true)) {
            echo 'success';
            return;
        }

        try {
            (new PaymentService())->markOrderPaid(
                $payload['out_trade_no'],
                isset($payload['trade_no']) ? $payload['trade_no'] : '',
                isset($payload['total_amount']) ? $payload['total_amount'] : null
            );
            echo 'success';
        } catch (\Throwable $e) {
            Logger::error('支付宝入账失败：' . $e->getMessage(), $this->redactPayload($payload));
            echo 'failure';
        }
    }

    public function alipayQuery()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $orderNo = isset($_POST['order_no']) ? trim($_POST['order_no']) : '';
        $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? AND user_id = ? LIMIT 1', [$orderNo, Auth::id()]);
        if (!$order) {
            set_flash('error', '订单不存在。');
            $this->redirect('recharge');
        }
        if ($order['status'] === 'paid') {
            set_flash('success', '订单已支付，余额已入账。');
            $this->redirect('recharge');
        }
        if ($order['status'] !== 'pending') {
            set_flash('error', '当前订单状态不可继续支付：' . $order['status']);
            $this->redirect('orders');
        }

        try {
            $gateway = new AlipayF2FGateway(AlipayF2FGateway::config());
            $result = $gateway->query($orderNo);
            $status = isset($result['trade_status']) ? $result['trade_status'] : '';
            if (in_array($status, ['TRADE_SUCCESS', 'TRADE_FINISHED'], true)) {
                (new PaymentService())->markOrderPaid(
                    $orderNo,
                    isset($result['trade_no']) ? $result['trade_no'] : '',
                    isset($result['total_amount']) ? $result['total_amount'] : null
                );
                set_flash('success', $order['type'] === 'package' ? '支付成功，套餐已开通。' : '支付成功，余额已入账。');
                $this->redirect($order['type'] === 'package' ? 'packages' : 'recharge');
            }
            set_flash('error', '支付宝订单当前状态：' . ($status ?: '未支付'));
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('pay/alipay/' . $orderNo);
    }

    protected function redactPayload(array $payload)
    {
        foreach (['sign', 'buyer_logon_id', 'buyer_id'] as $key) {
            if (isset($payload[$key])) {
                $payload[$key] = '******';
            }
        }
        return $payload;
    }
}
