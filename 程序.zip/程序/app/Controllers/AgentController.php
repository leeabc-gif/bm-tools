<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Services\DatabaseUpgradeService;
use App\Services\Monitor\AgentMonitorCollector;
use App\Services\Monitor\MonitorService;

class AgentController extends Controller
{
    public function report()
    {
        if (!$this->ensureFeatureReady(
            $this->schemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema']),
            'Agent 监控上报',
            '/',
            'Agent 监控数据结构未准备完成，请管理员执行数据库一键修复。'
        )) {
            return;
        }
        $payload = $this->requestPayload();
        $token = trim((string) (isset($payload['token']) ? $payload['token'] : ''));
        if ($token === '') {
            $this->json(['success' => false, 'message' => 'Agent Token 不能为空。'], 422);
        }

        $server = Database::fetch(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type = ? AND agent_token = ? AND is_enabled = 1 LIMIT 1',
            ['agent', $token]
        );
        if (!$server || !hash_equals((string) $server['agent_token'], $token)) {
            $this->json(['success' => false, 'message' => 'Agent Token 无效或服务器未启用。'], 403);
        }

        $payload['success'] = true;
        $payload['source'] = isset($payload['source']) ? $payload['source'] : 'bmtools-agent-push';
        $payload['report_ip'] = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        try {
            $metric = (new AgentMonitorCollector())->normalizePayload($server, $payload);
            $metricId = (new MonitorService())->storeMetric($server, $metric);
            $this->json([
                'success' => true,
                'message' => 'Agent 上报成功。',
                'server_id' => (int) $server['id'],
                'metric_id' => (int) $metricId,
                'time' => now(),
            ]);
        } catch (\Throwable $e) {
            Database::execute(
                'UPDATE ' . Database::table('monitor_servers') . ' SET status = ?, last_error = ?, last_checked_at = ?, updated_at = ? WHERE id = ?',
                ['offline', $e->getMessage(), now(), now(), $server['id']]
            );
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function installScript()
    {
        if (!$this->ensureFeatureReady(
            $this->schemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema']),
            'Agent 安装脚本',
            '/',
            'Agent 安装脚本依赖的监控数据结构未准备完成，请管理员执行数据库一键修复。'
        )) {
            return;
        }
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $token = trim((string) (isset($_GET['token']) ? $_GET['token'] : ''));
        $server = Database::fetch(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND monitor_type = ? AND agent_token = ? LIMIT 1',
            [$id, 'agent', $token]
        );
        if (!$server || !hash_equals((string) $server['agent_token'], $token)) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Agent install script not found.';
            return;
        }

        $endpoint = public_url('agent/report');
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo $this->shellInstaller($server, $endpoint, $token);
    }

    protected function requestPayload()
    {
        $payload = $_POST;
        $raw = file_get_contents('php://input');
        if ($raw !== '') {
            $json = json_decode($raw, true);
            if (is_array($json)) {
                $payload = array_merge($payload, $json);
            }
        }
        return is_array($payload) ? $payload : [];
    }

    protected function shellInstaller(array $server, $endpoint, $token)
    {
        $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', (string) $server['name']);
        $name = trim($name, '-');
        if ($name === '') {
            $name = 'server-' . (int) $server['id'];
        }
        $agentPath = '/usr/local/bin/bmtools-agent-' . (int) $server['id'] . '.sh';
        $cronPath = '/etc/cron.d/bmtools-agent-' . (int) $server['id'];
        $endpointQuoted = $this->shQuote($endpoint);
        $tokenQuoted = $this->shQuote($token);
        $agentPathQuoted = $this->shQuote($agentPath);
        $cronPathQuoted = $this->shQuote($cronPath);

        return <<<SH
#!/bin/sh
set -eu

BM_ENDPOINT={$endpointQuoted}
BM_TOKEN={$tokenQuoted}
BM_AGENT_PATH={$agentPathQuoted}
BM_CRON_PATH={$cronPathQuoted}

write_agent() {
cat > "\$BM_AGENT_PATH" <<'AGENT'
#!/bin/sh
set -eu

BM_ENDPOINT={$endpointQuoted}
BM_TOKEN={$tokenQuoted}

read_cpu() {
    a=\$(awk '/^cpu / {print \$2+\$3+\$4+\$5+\$6+\$7+\$8" "\$5+\$6}' /proc/stat 2>/dev/null || echo "0 0")
    sleep 1
    b=\$(awk '/^cpu / {print \$2+\$3+\$4+\$5+\$6+\$7+\$8" "\$5+\$6}' /proc/stat 2>/dev/null || echo "0 0")
    at=\$(echo "\$a" | awk '{print \$1}')
    ai=\$(echo "\$a" | awk '{print \$2}')
    bt=\$(echo "\$b" | awk '{print \$1}')
    bi=\$(echo "\$b" | awk '{print \$2}')
    awk -v at="\$at" -v ai="\$ai" -v bt="\$bt" -v bi="\$bi" 'BEGIN{total=bt-at; idle=bi-ai; if(total>0){printf "%.2f", (total-idle)/total*100}else{printf "0"}}'
}

cpu_usage=\$(read_cpu)
memory_total=\$(awk '/MemTotal/ {print \$2*1024}' /proc/meminfo 2>/dev/null || echo 0)
memory_available=\$(awk '/MemAvailable/ {print \$2*1024}' /proc/meminfo 2>/dev/null || echo 0)
memory_used=\$(awk -v t="\$memory_total" -v a="\$memory_available" 'BEGIN{u=t-a; if(u<0)u=0; printf "%.0f", u}')
memory_usage=\$(awk -v t="\$memory_total" -v u="\$memory_used" 'BEGIN{if(t>0){printf "%.2f", u/t*100}else{printf "0"}}')
disk_total=\$(df -B1 -P / 2>/dev/null | awk 'NR==2 {print \$2+0}' || echo 0)
disk_used=\$(df -B1 -P / 2>/dev/null | awk 'NR==2 {print \$3+0}' || echo 0)
disk_usage=\$(awk -v t="\$disk_total" -v u="\$disk_used" 'BEGIN{if(t>0){printf "%.2f", u/t*100}else{printf "0"}}')
load_avg=\$(cat /proc/loadavg 2>/dev/null | awk '{print \$1","\$2","\$3}' || echo "")
uptime_text=\$(awk '{s=int(\$1); d=int(s/86400); h=int((s%86400)/3600); m=int((s%3600)/60); printf "%sd %sh %sm", d,h,m}' /proc/uptime 2>/dev/null || echo "")
hostname_text=\$(hostname 2>/dev/null || echo "")
os_text=\$(uname -sr 2>/dev/null || echo "")

curl -fsS -m 20 -X POST "\$BM_ENDPOINT" \\
  --data-urlencode "token=\$BM_TOKEN" \\
  --data-urlencode "source=bmtools-shell-agent" \\
  --data-urlencode "hostname=\$hostname_text" \\
  --data-urlencode "os=\$os_text" \\
  --data-urlencode "cpu_usage=\$cpu_usage" \\
  --data-urlencode "memory_total=\$memory_total" \\
  --data-urlencode "memory_used=\$memory_used" \\
  --data-urlencode "memory_usage=\$memory_usage" \\
  --data-urlencode "disk_total=\$disk_total" \\
  --data-urlencode "disk_used=\$disk_used" \\
  --data-urlencode "disk_usage=\$disk_usage" \\
  --data-urlencode "load_avg=\$load_avg" \\
  --data-urlencode "uptime=\$uptime_text" >/dev/null
AGENT
chmod 700 "\$BM_AGENT_PATH"
}

install_cron() {
    if [ "\$(id -u)" = "0" ]; then
        printf '* * * * * root %s >/dev/null 2>&1\\n' "\$BM_AGENT_PATH" > "\$BM_CRON_PATH"
        chmod 644 "\$BM_CRON_PATH"
    else
        tmp="\$(mktemp)"
        crontab -l 2>/dev/null | grep -v "\$BM_AGENT_PATH" > "\$tmp" || true
        printf '* * * * * %s >/dev/null 2>&1\\n' "\$BM_AGENT_PATH" >> "\$tmp"
        crontab "\$tmp"
        rm -f "\$tmp"
    fi
}

if [ "\${1:-}" = "--once" ]; then
    sh "\$BM_AGENT_PATH"
    exit 0
fi

write_agent
install_cron
sh "\$BM_AGENT_PATH" || true
echo "BM TOOLS Agent installed for {$name}."
echo "Report endpoint: \$BM_ENDPOINT"
SH;
    }

    protected function shQuote($value)
    {
        return "'" . str_replace("'", "'\"'\"'", (string) $value) . "'";
    }

    protected function schemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }
}
