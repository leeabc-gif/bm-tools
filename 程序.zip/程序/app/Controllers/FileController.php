<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Models\FileItem;
use App\Models\StorageDriver;
use App\Services\DatabaseUpgradeService;
use App\Services\FileService;
use App\Services\FileLogService;
use App\Services\FileTrashService;
use App\Services\PermissionService;
use App\Services\RateLimitService;
use App\Services\StorageBackupService;
use App\Services\Storage\StorageManager;
use App\Services\UploadFailureService;
use App\Services\UploadLimitService;

class FileController extends Controller
{
    protected function ensureFileLogsReady($back = 'files')
    {
        return $this->ensureFeatureReady(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureFileLogSchema']),
            '文件记录',
            $back,
            '文件上传下载记录表未准备完成，请联系管理员进入后台「系统维护」执行数据库一键修复。'
        );
    }

    public function index()
    {
        $this->requireLogin();
        if (!$this->imageAllowed()) {
            set_flash('error', (new PermissionService())->message('image'));
            $this->redirect('dashboard');
        }
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $dateStart = trim(isset($_GET['date_start']) ? $_GET['date_start'] : '');
        $dateEnd = trim(isset($_GET['date_end']) ? $_GET['date_end'] : '');
        $user = Auth::user();
        $this->view('files/index', [
            'title' => '图片管理',
            'files' => (new FileItem())->searchUserFiles(Auth::id(), 'image', null, $keyword, $dateStart, $dateEnd),
            'keyword' => $keyword,
            'dateStart' => $dateStart,
            'dateEnd' => $dateEnd,
            'usage' => $this->usageSummary($user, 'image'),
        ]);
    }

    public function upload()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $wantsJson = $this->wantsJson();
        if (!$this->imageAllowed()) {
            $message = (new PermissionService())->message('image');
            if ($wantsJson) {
                $this->json(['success' => false, 'message' => $message], 403);
            }
            set_flash('error', $message);
            $this->redirect('dashboard');
        }
        $uploaded = [];
        $failureRecorder = new UploadFailureService();
        try {
            if (empty($_FILES['images'])) {
                throw new \RuntimeException('请选择图片。');
            }
            $files = $this->normalizeFiles($_FILES['images']);
            $limits = new UploadLimitService();
            $limits->assertBatchLimit('image', count($files));
            $service = new FileService();
            $failed = [];
            foreach ($files as $file) {
                $lock = null;
                $dailyLock = null;
                try {
                    $dailyLock = $limits->acquireDailyLimitSlot(Auth::id(), 'image');
                    $lock = $limits->acquireConcurrency(Auth::id());
                    $uploaded[] = $service->uploadForUser(Auth::user(), $file, 'image', 0);
                } catch (\Throwable $itemError) {
                    $failureRecorder->record(Auth::id(), 'image', $file, $itemError->getMessage());
                    $failed[] = $file['name'] . '：' . $itemError->getMessage();
                    Logger::error('图床上传失败：' . $itemError->getMessage(), [
                        'user_id' => Auth::id(),
                        'file' => isset($file['name']) ? $file['name'] : '',
                        'size' => isset($file['size']) ? (int) $file['size'] : 0,
                    ]);
                    if ($wantsJson) {
                        break;
                    }
                } finally {
                    $limits->releaseConcurrency($lock);
                    $limits->releaseConcurrency($dailyLock);
                }
            }
            if ($wantsJson) {
                if ($uploaded) {
                    $this->json([
                        'success' => true,
                        'message' => '上传成功',
                        'files' => array_map([$this, 'uploadResponseFile'], $uploaded),
                    ]);
                }
                $message = $failed ? implode('；', $failed) : '上传没有返回成功结果，请检查上传限制、对象存储配置和运行日志。';
                $this->json([
                    'success' => false,
                ] + $this->uploadErrorPayload($message), 422);
            }
            if ($uploaded) {
                set_flash('success', '成功上传 ' . count($uploaded) . ' 个文件。');
            }
            if ($failed) {
                set_flash('error', '有 ' . count($failed) . ' 个文件上传失败：' . implode('；', array_slice($failed, 0, 3)) . (count($failed) > 3 ? '；更多失败请分批重试。' : ''));
            }
            if (!$uploaded && $failed) {
                $this->redirect('files');
            }
        } catch (\Throwable $e) {
            $failureRecorder->record(Auth::id(), 'image', $this->emptyUploadFailureFile(), $e->getMessage());
            Logger::error('图床上传请求失败：' . $e->getMessage(), ['user_id' => Auth::id()]);
            if ($wantsJson) {
                $this->json(['success' => false] + $this->uploadErrorPayload($e->getMessage()), 422);
            }
            set_flash('error', $e->getMessage());
        }
        $this->redirect('files');
    }

    public function downloadImage()
    {
        $this->requireLogin();
        if (!$this->imageAllowed()) {
            set_flash('error', (new PermissionService())->message('image'));
            $this->redirect('dashboard');
        }

        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $file = (new FileItem())->find($id);
        if (!$file || (int) $file['user_id'] !== Auth::id() || $file['file_type'] !== 'image') {
            set_flash('error', '图片不存在或无权下载。');
            $this->redirect('files');
        }

        $location = $this->publicFileLocation($file);
        if ($location === '') {
            set_flash('error', '图片链接不可用，请检查存储配置。');
            $this->redirect('files');
        }

        Database::execute('UPDATE ' . Database::table('files') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $id]);
        (new FileLogService())->log(Auth::id(), $id, 'image_download', $file['original_name'], (int) $file['file_size'], [
            'source' => 'image_host',
        ]);

        header('Location: ' . $location);
        exit;
    }

    public function detail()
    {
        $this->requireLogin();
        if (!$this->imageAllowed()) {
            set_flash('error', (new PermissionService())->message('image'));
            $this->redirect('dashboard');
        }
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $file = (new FileItem())->find($id);
        if (!$file || (int) $file['user_id'] !== Auth::id() || $file['file_type'] !== 'image') {
            http_response_code(404);
            echo '图片不存在';
            return;
        }
        $this->view('files/detail', ['title' => '图片详情', 'file' => $file]);
    }

    public function logs()
    {
        $this->requireLogin();
        if (!$this->ensureFileLogsReady()) {
            return;
        }

        $filters = $this->fileLogFiltersFromRequest();
        $query = $this->fileLogQuery($filters);
        $logs = Database::fetchAll(
            'SELECT l.*, f.file_type, f.file_url
             FROM ' . Database::table('file_logs') . ' l
             LEFT JOIN ' . Database::table('files') . ' f ON l.file_id = f.id
             WHERE ' . implode(' AND ', $query['where']) . '
             ORDER BY l.id DESC LIMIT 200',
            $query['params']
        );

        $stats = [
            'total' => $this->countFileLogs(),
            'uploads' => $this->countFileLogs("action IN ('image_upload','file_upload')"),
            'downloads' => $this->countFileLogs("action IN ('image_download','file_download')"),
            'today' => $this->countFileLogs('DATE(created_at) = CURDATE()'),
        ];

        $this->view('files/logs', [
            'title' => '文件记录',
            'logs' => $logs,
            'stats' => $stats,
            'scope' => $filters['scope'],
            'action' => $filters['action'],
            'keyword' => $filters['keyword'],
            'dateStart' => $filters['date_start'],
            'dateEnd' => $filters['date_end'],
            'actionLabels' => $this->fileLogActionLabels(),
        ]);
    }

    public function exportLogs()
    {
        $this->requireLogin();
        if (!$this->ensureFileLogsReady('files/logs')) {
            return;
        }
        $filters = $this->fileLogFiltersFromRequest();
        $query = $this->fileLogQuery($filters);
        $rows = Database::fetchAll(
            'SELECT l.*, f.file_type, f.file_url
             FROM ' . Database::table('file_logs') . ' l
             LEFT JOIN ' . Database::table('files') . ' f ON l.file_id = f.id
             WHERE ' . implode(' AND ', $query['where']) . '
             ORDER BY l.id DESC LIMIT 5000',
            $query['params']
        );
        $labels = $this->fileLogActionLabels();

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=file-logs-' . date('YmdHis') . '.csv');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        fputcsv($out, ['时间', '动作', '文件名', '大小', 'IP', '来源', '文件类型', '文件ID']);
        foreach ($rows as $row) {
            $detail = json_decode((string) (isset($row['detail']) ? $row['detail'] : ''), true);
            $detail = is_array($detail) ? $detail : [];
            $source = isset($detail['source']) ? $detail['source'] : 'console';
            $action = isset($row['action']) ? (string) $row['action'] : '';
            fputcsv($out, [
                isset($row['created_at']) ? $row['created_at'] : '',
                isset($labels[$action]) ? $labels[$action] : $action,
                isset($row['file_name']) ? $row['file_name'] : '',
                format_bytes((int) (isset($row['file_size']) ? $row['file_size'] : 0)),
                isset($row['ip']) ? $row['ip'] : '',
                $source,
                isset($row['file_type']) ? $row['file_type'] : '',
                isset($row['file_id']) ? (int) $row['file_id'] : '',
            ]);
        }
        fclose($out);
        exit;
    }

    public function fetchUrl()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->imageAllowed()) {
            set_flash('error', (new PermissionService())->message('image'));
            $this->redirect('dashboard');
        }
        $url = trim(isset($_POST['remote_url']) ? $_POST['remote_url'] : '');
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            set_flash('error', '请输入正确的远程图片地址。');
            $this->redirect('files');
        }

        $tmp = tempnam(sys_get_temp_dir(), 'ss_fetch_');
        try {
            $this->assertPublicRemoteUrl($url);
            $maxBytes = $this->remoteFetchMaxBytes(Auth::user());
            $body = $this->download($url, $maxBytes);
            file_put_contents($tmp, $body);
            $name = basename(parse_url($url, PHP_URL_PATH));
            $name = preg_replace('/[\x00-\x1F\x7F]+/', '', (string) $name);
            if (!$name || strpos($name, '.') === false) {
                $name = 'remote-' . time() . '.jpg';
            }
            $mime = mime_content_type($tmp);
            if (strpos((string) $mime, 'image/') !== 0 || !@getimagesize($tmp)) {
                throw new \RuntimeException('远程地址返回的不是有效图片。');
            }
            $file = [
                'name' => $name,
                'type' => $mime,
                'tmp_name' => $tmp,
                'error' => UPLOAD_ERR_OK,
                'size' => filesize($tmp),
            ];
            (new FileService())->uploadForUser(Auth::user(), $file, 'image', 0);
            set_flash('success', '远程图片已保存。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        if (is_file($tmp)) {
            unlink($tmp);
        }
        $this->redirect('files');
    }

    public function guestUpload()
    {
        $this->verifyCsrf();
        if ((string) setting('guest_image_upload_enabled', '0') !== '1') {
            set_flash('error', '游客图床上传未开放，请先登录账号后上传。');
            $this->redirect('login');
        }

        $uploaded = [];
        $failed = [];
        $failureRecorder = new UploadFailureService();
        try {
            if (empty($_FILES['images'])) {
                throw new \RuntimeException('请选择图片。');
            }
            $files = $this->normalizeFiles($_FILES['images']);
            $owner = $this->guestUploadOwner();
            if (!$owner) {
                throw new \RuntimeException('游客上传暂未配置接收账号，请联系管理员。');
            }
            $maxSize = max(1, (int) setting('guest_image_upload_max_size', 5242880));
            $dailyLimit = max(0, (int) setting('guest_image_upload_daily_ip_limit', 20));
            $limiter = new RateLimitService();
            $uploadLimits = new UploadLimitService();
            $uploadLimits->assertBatchLimit('image', count($files));
            $service = new FileService();
            foreach ($files as $file) {
                $dailyLock = null;
                $concurrencyLock = null;
                try {
                    if ($dailyLimit > 0) {
                        $check = $limiter->check('guest_image_upload_ip', Auth::ip(), 86400);
                        if (!empty($check['limited'])) {
                            throw new \RuntimeException('游客上传今日次数已达上限，请明天再试。');
                        }
                    }
                    if ((int) $file['size'] > $maxSize) {
                        throw new \RuntimeException('游客上传单张图片不能超过 ' . format_bytes($maxSize) . '。');
                    }
                    $dailyLock = $uploadLimits->acquireDailyLimitSlot((int) $owner['id'], 'image');
                    $concurrencyLock = $uploadLimits->acquireConcurrency((int) $owner['id']);
                    $uploaded[] = $service->uploadForUser($owner, $file, 'image', 0, ['bypass_feature_gate' => true]);
                    if ($dailyLimit > 0) {
                        $limiter->hit('guest_image_upload_ip', Auth::ip(), $dailyLimit, 86400, 86400, Auth::ip(), Auth::ip());
                    }
                } catch (\Throwable $itemError) {
                    $failureRecorder->record(isset($owner['id']) ? (int) $owner['id'] : null, 'guest', $file, $itemError->getMessage());
                    $failed[] = $file['name'] . '：' . $itemError->getMessage();
                } finally {
                    $uploadLimits->releaseConcurrency($concurrencyLock);
                    $uploadLimits->releaseConcurrency($dailyLock);
                }
            }
        } catch (\Throwable $e) {
            $failureRecorder->record(null, 'guest', $this->emptyUploadFailureFile(), $e->getMessage());
            set_flash('error', $e->getMessage());
            $this->redirect('/');
        }

        if ($uploaded) {
            $_SESSION['guest_upload_results'] = array_map(function ($file) {
                $url = public_url($file['file_url']);
                return [
                    'name' => $file['original_name'],
                    'size' => (int) $file['file_size'],
                    'url' => $url,
                    'markdown' => '![' . $file['original_name'] . '](' . $url . ')',
                    'html' => '<img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($file['original_name'], ENT_QUOTES, 'UTF-8') . '">',
                ];
            }, $uploaded);
            set_flash('success', '游客上传成功 ' . count($uploaded) . ' 张图片。');
            if ($failed) {
                set_flash('error', '部分图片失败：' . implode('；', array_slice($failed, 0, 3)));
            }
            $this->redirect('guest/upload/result');
        }

        set_flash('error', $failed ? implode('；', array_slice($failed, 0, 3)) : '上传没有返回成功结果，请检查上传限制、对象存储配置和运行日志。');
        $this->redirect('/');
    }

    public function guestUploadResult()
    {
        $items = isset($_SESSION['guest_upload_results']) && is_array($_SESSION['guest_upload_results']) ? $_SESSION['guest_upload_results'] : [];
        $this->view('files/guest_result', [
            'title' => '游客上传结果',
            'items' => $items,
        ]);
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->imageAllowed()) {
            set_flash('error', (new PermissionService())->message('image'));
            $this->redirect('dashboard');
        }
        $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
        if (!$ids) {
            set_flash('error', '请选择要删除的图片。');
            $this->redirect('files');
        }
        foreach ($ids as $id) {
            $file = (new FileItem())->find((int) $id);
            if ($file && (int) $file['user_id'] === Auth::id()) {
                (new FileTrashService())->moveToTrash($file, 'image_trash');
            }
        }
        set_flash('success', '已移入回收站，可在网盘回收站中恢复或彻底删除。');
        $this->redirect('files');
    }

    protected function normalizeFiles(array $files)
    {
        $normalized = [];
        if (is_array($files['name'])) {
            foreach ($files['name'] as $i => $name) {
                $normalized[] = [
                    'name' => $name,
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i],
                ];
            }
        } else {
            $normalized[] = $files;
        }
        return $normalized;
    }

    protected function wantsJson()
    {
        $accept = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
        $xhr = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) : '';
        return $xhr === 'xmlhttprequest' || stripos($accept, 'application/json') !== false || !empty($_POST['ajax_upload']);
    }

    protected function uploadResponseFile(array $file)
    {
        $url = public_url(isset($file['file_url']) ? $file['file_url'] : '');
        $thumbnailUrl = public_url(isset($file['thumbnail_url']) && $file['thumbnail_url'] ? $file['thumbnail_url'] : (isset($file['file_url']) ? $file['file_url'] : ''));
        return [
            'id' => (int) (isset($file['id']) ? $file['id'] : 0),
            'name' => isset($file['original_name']) ? $file['original_name'] : '',
            'size' => (int) (isset($file['file_size']) ? $file['file_size'] : 0),
            'type' => isset($file['file_type']) ? $file['file_type'] : 'image',
            'url' => $url,
            'thumbnail_url' => $thumbnailUrl,
            'markdown' => '![' . (isset($file['original_name']) ? $file['original_name'] : '') . '](' . $url . ')',
        ];
    }

    protected function uploadErrorPayload($message)
    {
        $payload = (new UploadFailureService())->payload($message);
        if ($payload['error_type'] === 'php_upload_limit') {
            $payload['repair_url'] = url('admin/maintenance/environment');
        } elseif ($payload['error_type'] === 'quota_or_permission') {
            $payload['repair_url'] = url('packages');
        } elseif (in_array($payload['error_type'], ['storage_config', 'storage_upload', 'storage_url', 'storage_delete'], true)) {
            $payload['storage_url'] = url('admin/storages');
            $payload['repair_url'] = url('admin/storages');
        } elseif (in_array($payload['error_type'], ['schema', 'storage_db'], true)) {
            $payload['repair_url'] = url('admin/maintenance/schema-audit');
        }
        return $payload;
    }

    protected function emptyUploadFailureFile()
    {
        return [
            'name' => '',
            'size' => 0,
            'type' => '',
            'tmp_name' => '',
            'error' => 0,
        ];
    }

    protected function publicFileLocation(array $file)
    {
        $url = public_url(isset($file['file_url']) ? $file['file_url'] : '');
        if ($url === '' || preg_match('/[\r\n]/', $url) || !preg_match('#^https?://#i', $url)) {
            return '';
        }
        return $url;
    }

    protected function fileLogFiltersFromRequest()
    {
        $scope = isset($_GET['scope']) ? trim((string) $_GET['scope']) : '';
        $action = isset($_GET['action']) ? trim((string) $_GET['action']) : '';
        $allowedScopes = ['', 'upload', 'download', 'delete', 'restore'];
        $allowedActions = array_keys($this->fileLogActionLabels());
        if (!in_array($scope, $allowedScopes, true)) {
            $scope = '';
        }
        if ($action !== '' && !in_array($action, $allowedActions, true)) {
            $action = '';
        }
        return [
            'scope' => $scope,
            'action' => $action,
            'keyword' => trim(isset($_GET['keyword']) ? (string) $_GET['keyword'] : ''),
            'date_start' => trim(isset($_GET['date_start']) ? (string) $_GET['date_start'] : ''),
            'date_end' => trim(isset($_GET['date_end']) ? (string) $_GET['date_end'] : ''),
        ];
    }

    protected function fileLogQuery(array $filters)
    {
        $where = ['l.user_id = ?'];
        $params = [Auth::id()];
        if (!empty($filters['scope'])) {
            $scopeActions = $this->fileLogScopeActions($filters['scope']);
            if ($scopeActions) {
                $where[] = 'l.action IN (' . implode(',', array_fill(0, count($scopeActions), '?')) . ')';
                foreach ($scopeActions as $scopeAction) {
                    $params[] = $scopeAction;
                }
            }
        }
        if (!empty($filters['action'])) {
            $where[] = 'l.action = ?';
            $params[] = $filters['action'];
        }
        if (!empty($filters['keyword'])) {
            $where[] = '(l.file_name LIKE ? OR l.action LIKE ? OR l.ip LIKE ?)';
            $params[] = '%' . $filters['keyword'] . '%';
            $params[] = '%' . $filters['keyword'] . '%';
            $params[] = '%' . $filters['keyword'] . '%';
        }
        if (!empty($filters['date_start'])) {
            $where[] = 'l.created_at >= ?';
            $params[] = $filters['date_start'] . ' 00:00:00';
        }
        if (!empty($filters['date_end'])) {
            $where[] = 'l.created_at <= ?';
            $params[] = $filters['date_end'] . ' 23:59:59';
        }
        return ['where' => $where, 'params' => $params];
    }

    protected function fileLogActionLabels()
    {
        return [
            'image_upload' => '图片上传',
            'file_upload' => '文件上传',
            'image_download' => '图片下载',
            'file_download' => '文件下载',
            'image_trash' => '图片移入回收站',
            'file_trash' => '文件移入回收站',
            'file_restore' => '文件恢复',
            'file_purge' => '彻底删除',
            'api_delete' => 'API 删除',
            'folder_delete' => '文件夹删除',
        ];
    }

    protected function fileLogScopeActions($scope)
    {
        $map = [
            'upload' => ['image_upload', 'file_upload'],
            'download' => ['image_download', 'file_download'],
            'delete' => ['image_trash', 'file_trash', 'file_purge', 'api_delete', 'folder_delete'],
            'restore' => ['file_restore'],
        ];
        return isset($map[$scope]) ? $map[$scope] : [];
    }

    protected function countFileLogs($condition = '')
    {
        $sql = 'SELECT COUNT(*) AS c FROM ' . Database::table('file_logs') . ' WHERE user_id = ?';
        if ($condition !== '') {
            $sql .= ' AND ' . $condition;
        }
        $row = Database::fetch($sql, [Auth::id()]);
        return $row ? (int) $row['c'] : 0;
    }

    protected function imageAllowed()
    {
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema']);
        return (new PermissionService())->featureAllowed(Auth::user(), 'image');
    }

    protected function safeSchemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function guestUploadOwner()
    {
        $id = (int) setting('guest_image_upload_user_id', 0);
        if ($id > 0) {
            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$id]);
            if ($user) {
                return $user;
            }
        }
        $user = Database::fetch("SELECT * FROM " . Database::table('users') . " WHERE role = 'admin' AND status = 1 ORDER BY id ASC LIMIT 1");
        if ($user) {
            return $user;
        }
        return Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE status = 1 ORDER BY id ASC LIMIT 1');
    }

    protected function download($url, $maxBytes, $redirects = 0)
    {
        if ($redirects > 3) {
            throw new \RuntimeException('远程拉取失败：跳转次数过多。');
        }
        if (!function_exists('curl_init')) {
            throw new \RuntimeException('远程拉取需要 PHP curl 扩展，当前服务器未启用，请在 PHP 扩展中开启 curl 后重试。');
        }
        $this->assertPublicRemoteUrl($url);
        $raw = '';
        $transferLimit = $maxBytes + 65536;
        $ch = curl_init($url);
        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HEADER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'BMTOOLS Fetcher',
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$raw, $transferLimit) {
                $raw .= $chunk;
                return strlen($raw) > $transferLimit ? 0 : strlen($chunk);
            },
        ];
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            $options[CURLOPT_REDIR_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        }
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        if ($response === false || $error) {
            if (strlen($raw) > $transferLimit) {
                throw new \RuntimeException('远程文件超过允许大小。');
            }
            throw new \RuntimeException('远程拉取失败：' . ($error ?: ('HTTP ' . $code)));
        }
        if ($raw === '' && is_string($response)) {
            $raw = $response;
        }
        $headers = substr($raw, 0, $headerSize);
        $content = substr($raw, $headerSize);
        if (in_array($code, [301, 302, 303, 307, 308], true)) {
            if (!preg_match('/^Location:\s*(.+)$/mi', $headers, $m)) {
                throw new \RuntimeException('远程拉取失败：跳转地址缺失。');
            }
            $next = trim($m[1]);
            if (!preg_match('#^https?://#i', $next)) {
                $parts = parse_url($url);
                $base = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
                $next = $base . '/' . ltrim($next, '/');
            }
            return $this->download($next, $maxBytes, $redirects + 1);
        }
        if ($code >= 400) {
            throw new \RuntimeException('远程拉取失败：HTTP ' . $code);
        }
        if (strlen($content) > $maxBytes) {
            throw new \RuntimeException('远程文件超过允许大小。');
        }
        return $content;
    }

    protected function remoteFetchMaxBytes(array $user)
    {
        $package = Database::fetch('SELECT single_file_limit FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        $limits = [];
        if ($package && (int) $package['single_file_limit'] > 0) {
            $limits[] = (int) $package['single_file_limit'];
        }
        if ((int) $user['total_storage'] > 0) {
            $limits[] = max(0, (int) $user['total_storage'] - (int) $user['used_storage']);
        }
        $limits[] = 50 * 1024 * 1024;
        return max(1, min($limits));
    }

    protected function assertPublicRemoteUrl($url)
    {
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
            throw new \RuntimeException('仅支持 http 或 https 图片地址。');
        }
        if (!empty($parts['user']) || !empty($parts['pass'])) {
            throw new \RuntimeException('远程图片地址不能包含账号密码。');
        }
        $port = isset($parts['port']) ? (int) $parts['port'] : (strtolower($parts['scheme']) === 'https' ? 443 : 80);
        if (!in_array($port, [80, 443], true)) {
            throw new \RuntimeException('远程图片地址仅允许使用 80 或 443 端口。');
        }
        $host = $parts['host'];
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $ips = [$host];
        } else {
            $ips = gethostbynamel($host);
            if (!$ips) {
                throw new \RuntimeException('远程域名无法解析。');
            }
        }
        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                throw new \RuntimeException('不允许拉取内网或保留地址资源。');
            }
        }
    }

    protected function usageSummary(array $user, $type = null)
    {
        $where = 'user_id = ?';
        $params = [$user['id']];
        if ($type) {
            $where .= ' AND file_type = ?';
            $params[] = $type;
        }
        $count = Database::fetch('SELECT COUNT(*) AS c, COALESCE(SUM(file_size),0) AS s FROM ' . Database::table('files') . ' WHERE ' . $where, $params);
        $package = Database::fetch('SELECT name, single_file_limit, allow_image, allow_netdisk, allow_api, allow_share FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        $storage = (new StorageDriver())->defaultDriver();
        $total = (int) $user['total_storage'];
        $used = (int) $user['used_storage'];
        $percent = $total > 0 ? min(100, round($used / $total * 100, 2)) : 0;
        return [
            'package' => $package ?: ['name' => '默认套餐', 'single_file_limit' => 0, 'allow_api' => 0, 'allow_share' => 0],
            'file_count' => (int) $count['c'],
            'file_size' => (int) $count['s'],
            'used_storage' => $used,
            'total_storage' => $total,
            'free_storage' => max(0, $total - $used),
            'storage_percent' => $percent,
            'is_near_limit' => $total > 0 && $percent >= 80,
            'storage' => $storage,
        ];
    }

    protected function deleteRemoteObject(array $file)
    {
        if (empty($file['storage_id'])) {
            return;
        }
        try {
            $storage = (new StorageDriver())->find((int) $file['storage_id']);
            if ($storage) {
                (new StorageBackupService())->deleteBackupsForFile($file);
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Throwable $e) {
            \App\Core\Logger::error('远程文件删除失败：' . $e->getMessage(), ['file_id' => $file['id']]);
        }
    }
}
