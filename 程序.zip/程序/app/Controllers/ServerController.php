<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Models\MonitorMetric;
use App\Services\CryptoService;
use App\Services\DatabaseUpgradeService;
use App\Services\Monitor\MonitorService;
use App\Services\Monitor\ServiceProbeService;
use App\Services\Monitor\SshMonitorClient;
use App\Services\PermissionService;

class ServerController extends Controller
{
    protected function ensureServerOpsReady($back = 'servers')
    {
        return $this->ensureFeatureReady(
            $this->schemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema']),
            '服务器管家',
            $back,
            '服务器管家数据结构未准备完成，请联系管理员进入后台「系统维护」执行数据库一键修复。'
        );
    }

    protected function schemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function index()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();

        $servers = Database::fetchAll(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE user_id = ? AND monitor_type IN (?, ?) ORDER BY id DESC',
            [Auth::id(), 'ssh', 'agent']
        );
        $metricModel = new MonitorMetric();
        $probeService = new ServiceProbeService();
        foreach ($servers as &$server) {
            $server['latest'] = $metricModel->latest($server['id']);
            $server['monitor_page'] = $this->monitorPageForServer($server['id'], Auth::id());
            $server['probe_stats'] = $probeService->statsForServer($server['id']);
            $server['is_stale'] = $this->serverIsStale($server);
        }
        unset($server);

        $stats = [
            'total' => count($servers),
            'online' => 0,
            'offline' => 0,
            'commands_today' => $this->countRows('server_command_logs', 'user_id = ? AND DATE(created_at) = CURDATE()', [Auth::id()]),
            'checks' => 0,
            'down_checks' => 0,
        ];
        foreach ($servers as $server) {
            if ($server['status'] === 'online') {
                $stats['online']++;
            } elseif ($server['status'] === 'offline') {
                $stats['offline']++;
            }
            $stats['checks'] += isset($server['probe_stats']['total']) ? (int) $server['probe_stats']['total'] : 0;
            $stats['down_checks'] += isset($server['probe_stats']['down']) ? (int) $server['probe_stats']['down'] : 0;
        }

        $this->view('servers/index', [
            'title' => '服务器管家',
            'servers' => $servers,
            'stats' => $stats,
            'limit' => $this->serverLimit(),
            'userCronUrl' => public_url('cron/user-servers/collect?user_id=' . Auth::id() . '&token=' . $this->userCronToken()),
            'userCronForceUrl' => public_url('cron/user-servers/collect?force=1&user_id=' . Auth::id() . '&token=' . $this->userCronToken()),
        ]);
    }

    public function create()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = null;
        if (!empty($_GET['id'])) {
            $server = $this->serverForUser((int) $_GET['id']);
        }
        $this->view('servers/form', [
            'title' => $server ? '编辑服务器' : '添加服务器',
            'server' => $server,
            'limit' => $this->serverLimit(),
        ]);
    }

    public function show()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_GET['id']);
        $server['is_stale'] = $this->serverIsStale($server);
        $latest = (new MonitorMetric())->latest($server['id']);
        $history = Database::fetchAll(
            'SELECT * FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 24',
            [$server['id']]
        );
        $commands = Database::fetchAll(
            'SELECT * FROM ' . Database::table('server_command_logs') . ' WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT 12',
            [Auth::id(), $server['id']]
        );
        $page = $this->monitorPageForServer($server['id'], Auth::id());
        $probeService = new ServiceProbeService();
        $probeStats = $probeService->statsForServer($server['id']);
        $probeLogs = $probeService->latestLogsForServer($server['id'], 8);

        $this->view('servers/show', [
            'title' => $server['name'],
            'server' => $server,
            'latest' => $latest,
            'history' => array_reverse($history),
            'commands' => $commands,
            'page' => $page,
            'probeStats' => $probeStats,
            'probeLogs' => $probeLogs,
        ]);
    }

    public function terminal()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_GET['id']);
        if ($server['monitor_type'] !== 'ssh') {
            set_flash('error', 'Agent 模式不支持在线 SSH 终端。');
            $this->redirect('servers/' . $server['id']);
        }
        $commands = Database::fetchAll(
            'SELECT * FROM ' . Database::table('server_command_logs') . ' WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT 20',
            [Auth::id(), $server['id']]
        );
        $servers = Database::fetchAll(
            'SELECT id, name, ssh_host, server_ip, ssh_port, status FROM ' . Database::table('monitor_servers') . ' WHERE user_id = ? AND monitor_type = ? ORDER BY name ASC, id DESC',
            [Auth::id(), 'ssh']
        );
        $this->view('servers/terminal', [
            'title' => '在线终端 - ' . $server['name'],
            'server' => $server,
            'servers' => $servers,
            'commands' => $commands,
            'terminalEnabled' => (string) setting('ssh_terminal_enabled', '1') === '1',
            'gatewayUrl' => trim((string) setting('ssh_terminal_gateway_url', '')),
            'commandTimeout' => max(5, min(300, (int) setting('ssh_terminal_command_timeout', '30'))),
        ]);
    }

    public function commandLogs()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();

        $userId = Auth::id();
        $serverId = max(0, (int) (isset($_GET['server_id']) ? $_GET['server_id'] : 0));
        $keyword = trim((string) (isset($_GET['keyword']) ? $_GET['keyword'] : ''));
        $keyword = function_exists('mb_substr') ? mb_substr($keyword, 0, 80, 'UTF-8') : substr($keyword, 0, 80);
        $dateStart = trim((string) (isset($_GET['date_start']) ? $_GET['date_start'] : ''));
        $dateEnd = trim((string) (isset($_GET['date_end']) ? $_GET['date_end'] : ''));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStart)) {
            $dateStart = '';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateEnd)) {
            $dateEnd = '';
        }

        $servers = Database::fetchAll(
            'SELECT id, name, monitor_type, ssh_host, server_ip
             FROM ' . Database::table('monitor_servers') . '
             WHERE user_id = ? AND monitor_type IN (?, ?)
             ORDER BY name ASC, id DESC',
            [$userId, 'ssh', 'agent']
        );

        $where = ['cl.user_id = ?', 's.user_id = ?', 's.monitor_type IN (?, ?)'];
        $params = [$userId, $userId, 'ssh', 'agent'];
        if ($serverId > 0) {
            $where[] = 's.id = ?';
            $params[] = $serverId;
        }
        if ($keyword !== '') {
            $where[] = '(cl.command LIKE ? OR cl.output_summary LIKE ? OR s.name LIKE ? OR s.ssh_host LIKE ? OR s.server_ip LIKE ?)';
            for ($i = 0; $i < 5; $i++) {
                $params[] = '%' . $keyword . '%';
            }
        }
        if ($dateStart !== '') {
            $where[] = 'cl.created_at >= ?';
            $params[] = $dateStart . ' 00:00:00';
        }
        if ($dateEnd !== '') {
            $where[] = 'cl.created_at <= ?';
            $params[] = $dateEnd . ' 23:59:59';
        }

        $baseSql = 'FROM ' . Database::table('server_command_logs') . ' cl
             INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
             WHERE ' . implode(' AND ', $where);
        $logs = Database::fetchAll(
            'SELECT cl.*, s.name AS server_name, s.monitor_type, s.ssh_host, s.server_ip
             ' . $baseSql . '
             ORDER BY cl.id DESC
             LIMIT 300',
            $params
        );

        $filteredRow = Database::fetch('SELECT COUNT(*) AS c ' . $baseSql, $params);
        $totalRow = Database::fetch(
            'SELECT COUNT(*) AS c
             FROM ' . Database::table('server_command_logs') . ' cl
             INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
             WHERE cl.user_id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?)',
            [$userId, $userId, 'ssh', 'agent']
        );
        $todayRow = Database::fetch(
            'SELECT COUNT(*) AS c
             FROM ' . Database::table('server_command_logs') . ' cl
             INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
             WHERE cl.user_id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?) AND DATE(cl.created_at) = CURDATE()',
            [$userId, $userId, 'ssh', 'agent']
        );
        $serverRow = Database::fetch(
            'SELECT COUNT(DISTINCT cl.server_id) AS c
             FROM ' . Database::table('server_command_logs') . ' cl
             INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id
             WHERE cl.user_id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?)',
            [$userId, $userId, 'ssh', 'agent']
        );

        $this->view('servers/commands', [
            'title' => '命令审计',
            'logs' => $logs,
            'servers' => $servers,
            'filters' => [
                'server_id' => $serverId,
                'keyword' => $keyword,
                'date_start' => $dateStart,
                'date_end' => $dateEnd,
            ],
            'stats' => [
                'total' => $totalRow ? (int) $totalRow['c'] : 0,
                'today' => $todayRow ? (int) $todayRow['c'] : 0,
                'filtered' => $filteredRow ? (int) $filteredRow['c'] : 0,
                'servers' => $serverRow ? (int) $serverRow['c'] : 0,
            ],
        ]);
    }

    public function share()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_GET['id']);
        $page = $this->monitorPageForServer($server['id'], Auth::id());
        $this->view('servers/share', [
            'title' => '监控页面配置 - ' . $server['name'],
            'server' => $server,
            'page' => $page,
        ]);
    }

    public function probes()
    {
        $this->requireLogin();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_GET['id']);
        $service = new ServiceProbeService();
        $checks = $service->checksForServer($server['id'], Auth::id());
        $editCheck = null;
        if (!empty($_GET['check_id'])) {
            $editCheck = $service->checkForUser((int) $_GET['check_id'], Auth::id());
            if ($editCheck && (int) $editCheck['server_id'] !== (int) $server['id']) {
                $editCheck = null;
            }
        }
        $this->view('servers/probes', [
            'title' => '站点探针 - ' . $server['name'],
            'server' => $server,
            'checks' => $checks,
            'editCheck' => $editCheck,
            'stats' => $service->statsForServer($server['id']),
            'logs' => $service->latestLogsForServer($server['id'], 12),
            'limit' => $this->probeLimit(),
        ]);
    }

    public function save()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $existing = $id > 0 ? $this->serverForUser($id) : null;
        if (!$existing && $this->serverLimit() > 0 && $this->countUserServers() >= $this->serverLimit()) {
            set_flash('error', '当前套餐最多可保存 ' . $this->serverLimit() . ' 台服务器，请升级后再添加。');
            $this->redirect('servers');
        }

        $data = $this->serverPayload($existing);
        if ($data['name'] === '') {
            set_flash('error', '请填写服务器名称。');
            remember_old();
            $this->back();
        }
        if ($data['monitor_type'] === 'ssh' && ($data['ssh_host'] === '' || $data['ssh_username'] === '')) {
            set_flash('error', 'SSH 模式请填写 SSH 主机和 SSH 用户名。');
            remember_old();
            $this->back();
        }
        if ($data['monitor_type'] === 'agent' && $data['agent_token'] === '') {
            set_flash('error', 'Agent 模式需要生成或填写 Agent Token。');
            remember_old();
            $this->back();
        }
        if ($data['monitor_type'] === 'agent' && !preg_match('/^[A-Za-z0-9_-]{24,128}$/', $data['agent_token'])) {
            set_flash('error', 'Agent Token 只能包含字母、数字、下划线或短横线，长度 24-128 位。');
            remember_old();
            $this->back();
        }
        if ($data['monitor_type'] === 'ssh' && $this->blockedSshHost($data['ssh_host'])) {
            set_flash('error', 'SSH 主机不能填写本机、回环地址或云厂商元数据地址。');
            remember_old();
            $this->back();
        }
        if ($data['monitor_type'] === 'ssh' && !$existing && !$this->hasNewCredential($data)) {
            set_flash('error', '请填写 SSH 密码，或粘贴 SSH 私钥。');
            remember_old();
            $this->back();
        }

        if ($existing) {
            $set = [];
            $params = [];
            foreach ($data as $key => $value) {
                $set[] = $key . ' = ?';
                $params[] = $value;
            }
            $params[] = $existing['id'];
            Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
            $serverId = (int) $existing['id'];
        } else {
            $data['created_at'] = now();
            $columns = array_keys($data);
            Database::execute(
                'INSERT INTO ' . Database::table('monitor_servers') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')',
                array_values($data)
            );
            $serverId = (int) Database::lastInsertId();
        }

        set_flash('success', $existing ? '服务器信息已更新。' : '服务器已保存，建议先执行一次连接测试或立即采集。');
        $this->redirect('servers/' . $serverId);
    }

    public function test()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps(true);
        $server = !empty($_POST['id']) ? $this->serverForUser((int) $_POST['id']) : $this->serverPayload(null);
        if (!empty($_POST['id'])) {
            $server = array_merge($server, $this->serverPayload($server));
        }
        if ((isset($server['monitor_type']) ? $server['monitor_type'] : 'ssh') === 'agent' && trim((string) (isset($server['agent_url']) ? $server['agent_url'] : '')) === '') {
            $this->json([
                'success' => true,
                'message' => 'Agent 主动上报模式配置正常。目标服务器安装脚本后会自动上报，未填写 Agent URL 时无需后台主动连接测试。',
                'steps' => [
                    ['label' => 'Agent Token', 'status' => 'ok', 'message' => '已生成上报 Token。'],
                    ['label' => '上报接口', 'status' => 'ok', 'message' => public_url('agent/report')],
                    ['label' => '安装脚本', 'status' => 'pending', 'message' => '保存后在服务器详情页复制安装命令到目标服务器执行。'],
                ],
            ]);
        }
        if ($this->blockedSshHost(isset($server['ssh_host']) ? $server['ssh_host'] : '')) {
            $this->json([
                'success' => false,
                'message' => 'SSH 主机不能填写本机、回环地址或云厂商元数据地址。',
                'steps' => [
                    ['label' => '表单配置', 'status' => 'fail', 'message' => '请改用真实服务器公网 IP 或可信域名。'],
                ],
            ], 422);
        }

        try {
            (new MonitorService())->test($server);
            $this->json([
                'success' => true,
                'message' => '连接成功：SSH 登录和基础命令执行正常。',
                'steps' => ['端口可达', '账号认证通过', '测试命令返回正常'],
            ]);
        } catch (\Throwable $e) {
            $this->json([
                'success' => false,
                'message' => $this->connectionHint($e->getMessage()),
                'raw' => $e->getMessage(),
                'steps' => $this->connectionChecks($e->getMessage()),
            ], 422);
        }
    }

    public function collect()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps(true);
        $server = $this->serverForUser((int) $_POST['id']);
        try {
            if ($server['monitor_type'] === 'agent' && trim((string) $server['agent_url']) === '') {
                $this->json(['success' => false, 'message' => '当前为 Agent 主动上报模式，不需要手动拉取采集；请等待目标服务器定时上报，或在服务器上执行安装脚本。'], 422);
            }
            (new MonitorService())->collect($server);
            $probes = (new ServiceProbeService())->collectForServer($server, true);
            $message = '采集完成，服务器状态已刷新。';
            if ($probes['total'] > 0) {
                $message .= ' 同步检测探针 ' . $probes['total'] . ' 个，异常 ' . $probes['down'] . ' 个。';
            }
            $this->json(['success' => true, 'message' => $message, 'probes' => $probes]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $this->connectionHint($e->getMessage())], 422);
        }
    }

    public function saveProbe()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_POST['server_id']);
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $existing = $id > 0 ? (new ServiceProbeService())->checkForUser($id, Auth::id()) : null;
        if ($existing && (int) $existing['server_id'] !== (int) $server['id']) {
            $existing = null;
        }
        if (!$existing && $this->probeLimit() > 0 && $this->countUserProbes() >= $this->probeLimit()) {
            set_flash('error', '当前最多可保存 ' . $this->probeLimit() . ' 个站点探针，请升级套餐或删除旧探针后再添加。');
            $this->redirect('servers/' . $server['id'] . '/probes');
        }

        try {
            $data = $this->probePayload($server);
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
            remember_old();
            $this->redirect('servers/' . $server['id'] . '/probes' . ($id > 0 ? '?check_id=' . $id : ''));
        }

        if ($existing) {
            $set = [];
            $params = [];
            foreach ($data as $key => $value) {
                $set[] = $key . ' = ?';
                $params[] = $value;
            }
            $params[] = $existing['id'];
            Database::execute('UPDATE ' . Database::table('server_service_checks') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
            $probeId = (int) $existing['id'];
        } else {
            $data['user_id'] = Auth::id();
            $data['server_id'] = $server['id'];
            $data['status'] = 'unknown';
            $data['created_at'] = now();
            $columns = array_keys($data);
            Database::execute(
                'INSERT INTO ' . Database::table('server_service_checks') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')',
                array_values($data)
            );
            $probeId = (int) Database::lastInsertId();
        }

        if (!empty($_POST['test_after_save'])) {
            $check = (new ServiceProbeService())->checkForUser($probeId, Auth::id());
            if ($check) {
                try {
                    (new ServiceProbeService())->collectCheck($check, $server);
                } catch (\Throwable $e) {
                    set_flash('error', '探针已保存，但立即检测失败：' . $e->getMessage());
                    $this->redirect('servers/' . $server['id'] . '/probes');
                }
            }
        }
        set_flash('success', $existing ? '站点探针已更新。' : '站点探针已添加。');
        $this->redirect('servers/' . $server['id'] . '/probes');
    }

    public function testProbe()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps(true);
        $server = $this->serverForUser((int) $_POST['server_id']);
        $service = new ServiceProbeService();
        if (!empty($_POST['id']) && empty($_POST['payload_test'])) {
            $check = $service->checkForUser((int) $_POST['id'], Auth::id());
            if (!$check || (int) $check['server_id'] !== (int) $server['id']) {
                $this->json(['success' => false, 'message' => '探针不存在或无权操作。'], 404);
            }
            $result = $service->collectCheck($check, $server);
            $ok = $result['status'] === 'up';
            $this->json(['success' => $ok, 'message' => $result['message'], 'data' => $result], $ok ? 200 : 422);
        }
        try {
            $payload = $this->probePayload($server);
            $payload['user_id'] = Auth::id();
            $payload['server_id'] = $server['id'];
            $result = $service->testPayload($payload);
            $this->json(['success' => $result['success'], 'message' => $result['message'], 'data' => $result], $result['success'] ? 200 : 422);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function deleteProbe()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_POST['server_id']);
        $check = (new ServiceProbeService())->checkForUser((int) $_POST['id'], Auth::id());
        if (!$check || (int) $check['server_id'] !== (int) $server['id']) {
            set_flash('error', '探针不存在或无权删除。');
            $this->redirect('servers/' . $server['id'] . '/probes');
        }
        Database::execute('DELETE FROM ' . Database::table('server_service_check_logs') . ' WHERE check_id = ?', [$check['id']]);
        Database::execute('DELETE FROM ' . Database::table('server_service_checks') . ' WHERE id = ? AND user_id = ?', [$check['id'], Auth::id()]);
        set_flash('success', '站点探针已删除。');
        $this->redirect('servers/' . $server['id'] . '/probes');
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_POST['id']);
        $probeIds = Database::fetchAll('SELECT id FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
        foreach ($probeIds as $probe) {
            Database::execute('DELETE FROM ' . Database::table('server_service_check_logs') . ' WHERE check_id = ?', [$probe['id']]);
        }
        Database::execute('DELETE FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
        Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$server['id']]);
        Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$server['id']]);
        Database::execute('DELETE FROM ' . Database::table('server_command_logs') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
        Database::execute('DELETE FROM ' . Database::table('server_ssh_sessions') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
        Database::execute('DELETE FROM ' . Database::table('server_monitor_pages') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
        Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND user_id = ? AND monitor_type IN (?, ?)', [$server['id'], Auth::id(), 'ssh', 'agent']);
        set_flash('success', '服务器已删除，相关终端记录和监控页面已清理。');
        $this->redirect('servers');
    }

    public function command()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps(true);
        if ((string) setting('ssh_terminal_enabled', '1') !== '1') {
            $this->json(['success' => false, 'message' => '管理员已关闭在线终端功能。'], 403);
        }

        $server = $this->serverForUser((int) $_POST['id']);
        if ($server['monitor_type'] !== 'ssh') {
            $this->json(['success' => false, 'message' => 'Agent 模式不支持在线 SSH 命令，请使用状态采集和主动上报。'], 422);
        }
        $command = (string) (isset($_POST['command']) ? $_POST['command'] : '');
        if (trim($command) === '') {
            $this->json(['success' => false, 'message' => '命令不能为空。'], 422);
        }
        if (strlen($command) > 20000) {
            $this->json(['success' => false, 'message' => '命令内容过长，请拆分后执行。'], 422);
        }
        $risk = 'normal';

        $timeout = max(5, min(3600, (int) setting('ssh_terminal_command_timeout', '30')));
        $startedAt = microtime(true);
        try {
            $output = (new SshMonitorClient($server))->runCommand($command, $timeout);
            $durationMs = (int) round((microtime(true) - $startedAt) * 1000);
            $this->logCommand($server, $command, $output, $risk, null);
            $this->json([
                'success' => true,
                'message' => '命令执行完成。',
                'output' => $output,
                'risk_level' => $risk,
                'duration_ms' => $durationMs,
                'time' => now(),
            ]);
        } catch (\Throwable $e) {
            $durationMs = (int) round((microtime(true) - $startedAt) * 1000);
            $this->logCommand($server, $command, $e->getMessage(), 'normal', null);
            $this->json([
                'success' => false,
                'message' => $this->connectionHint($e->getMessage()),
                'raw' => $e->getMessage(),
                'duration_ms' => $durationMs,
                'steps' => $this->connectionChecks($e->getMessage()),
            ], 422);
        }
    }

    public function terminalToken()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps(true);
        if ((string) setting('ssh_terminal_enabled', '1') !== '1') {
            $this->json(['success' => false, 'message' => '管理员已关闭在线终端功能。'], 403);
        }
        $server = $this->serverForUser((int) $_POST['id']);
        if ($server['monitor_type'] !== 'ssh') {
            $this->json(['success' => false, 'message' => 'Agent 模式不需要签发 SSH 网关令牌。'], 422);
        }
        $token = bin2hex(random_bytes(32));
        $gatewayUrl = trim((string) setting('ssh_terminal_gateway_url', ''));
        $expiresAt = date('Y-m-d H:i:s', time() + max(60, min(86400, (int) setting('ssh_terminal_session_timeout', '600'))));
        Database::execute(
            'INSERT INTO ' . Database::table('server_ssh_sessions') . ' (user_id, server_id, token_hash, gateway_url, ip, user_agent, status, expires_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
            [Auth::id(), $server['id'], hash('sha256', $token), $gatewayUrl, $this->ip(), $this->userAgent(), 'issued', $expiresAt, now(), now()]
        );
        $this->json([
            'success' => true,
            'message' => $gatewayUrl === '' ? '已签发终端令牌。未配置 WebSocket 网关时，请使用命令模式。' : '终端令牌已签发。',
            'token' => $token,
            'gateway_url' => $gatewayUrl,
            'expires_at' => $expiresAt,
        ]);
    }

    public function saveShare()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();
        $server = $this->serverForUser((int) $_POST['server_id']);
        $page = $this->monitorPageForServer($server['id'], Auth::id());
        $visibility = isset($_POST['visibility']) && in_array($_POST['visibility'], ['private', 'public', 'password'], true) ? $_POST['visibility'] : 'private';
        $password = (string) (isset($_POST['password']) ? $_POST['password'] : '');
        if ($visibility === 'password' && $password === '' && (!$page || empty($page['password_hash']))) {
            set_flash('error', '密码访问模式需要设置访问密码。');
            $this->back();
        }
        $data = [
            'title' => trim((string) (isset($_POST['title']) ? $_POST['title'] : '')),
            'visibility' => $visibility,
            'show_metrics' => isset($_POST['show_metrics']) ? 1 : 0,
            'show_services' => isset($_POST['show_services']) ? 1 : 0,
            'expires_at' => $this->dateOrNull(isset($_POST['expires_at']) ? $_POST['expires_at'] : ''),
            'updated_at' => now(),
        ];
        if ($password !== '') {
            $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
        } elseif ($visibility !== 'password') {
            $data['password_hash'] = null;
        }

        if ($page) {
            $set = [];
            $params = [];
            foreach ($data as $key => $value) {
                $set[] = $key . ' = ?';
                $params[] = $value;
            }
            $params[] = $page['id'];
            Database::execute('UPDATE ' . Database::table('server_monitor_pages') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
        } else {
            $data['user_id'] = Auth::id();
            $data['server_id'] = $server['id'];
            $data['token'] = $this->uniquePageToken();
            $data['created_at'] = now();
            $columns = array_keys($data);
            Database::execute(
                'INSERT INTO ' . Database::table('server_monitor_pages') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')',
                array_values($data)
            );
        }
        set_flash('success', '监控页面配置已保存。');
        $this->redirect('servers/' . $server['id'] . '/share');
    }

    public function resetCronToken()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureServerOpsReady()) {
            return;
        }
        $this->requireServerOps();

        Database::execute(
            'UPDATE ' . Database::table('users') . ' SET server_ops_cron_token = ?, updated_at = ? WHERE id = ?',
            [$this->newCronToken(), now(), Auth::id()]
        );
        set_flash('success', '个人采集链接已重置，旧链接会立即失效。');
        $this->redirect('servers');
    }

    public function publicStatus()
    {
        if (!$this->ensureServerOpsReady('/')) {
            return;
        }
        $token = trim((string) $_GET['token']);
        $page = Database::fetch('SELECT * FROM ' . Database::table('server_monitor_pages') . ' WHERE token = ? LIMIT 1', [$token]);
        if (!$page || $page['visibility'] === 'private' || ($page['expires_at'] && strtotime($page['expires_at']) < time())) {
            http_response_code(404);
            echo '监控页面不存在或已过期';
            return;
        }
        $authedKey = 'server_page_auth_' . $page['id'];
        if ($page['visibility'] === 'password' && empty($_SESSION[$authedKey])) {
            $error = '';
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->verifyCsrf();
                $password = (string) (isset($_POST['password']) ? $_POST['password'] : '');
                if (!empty($page['password_hash']) && password_verify($password, $page['password_hash'])) {
                    $_SESSION[$authedKey] = 1;
                } else {
                    $error = '访问密码不正确。';
                }
            }
            if (empty($_SESSION[$authedKey])) {
                $this->view('servers/public_password', ['title' => '访问监控页面', 'page' => $page, 'error' => $error], 'layouts/announcement');
                return;
            }
        }

        $server = Database::fetch(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND user_id = ? AND monitor_type IN (?, ?) LIMIT 1',
            [$page['server_id'], $page['user_id'], 'ssh', 'agent']
        );
        if (
            !$server
            || (int) $server['user_id'] !== (int) $page['user_id']
            || !in_array(isset($server['monitor_type']) ? $server['monitor_type'] : '', ['ssh', 'agent'], true)
        ) {
            http_response_code(404);
            echo '服务器不存在';
            return;
        }
        Database::execute('UPDATE ' . Database::table('server_monitor_pages') . ' SET view_count = view_count + 1, last_viewed_at = ? WHERE id = ?', [now(), $page['id']]);
        $server['is_stale'] = $this->serverIsStale($server);
        $this->view('servers/public_status', [
            'title' => $page['title'] ?: $server['name'],
            'page' => $page,
            'server' => $server,
            'latest' => (new MonitorMetric())->latest($server['id']),
            'history' => array_reverse(Database::fetchAll('SELECT * FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 24', [$server['id']])),
            'checks' => (new ServiceProbeService())->checksForServer($server['id']),
        ], 'layouts/announcement');
    }

    public function cronCollect()
    {
        if (!$this->ensureServerOpsReady()) {
            return;
        }

        $token = trim(isset($_GET['token']) ? $_GET['token'] : '');
        $saved = trim((string) setting('monitor_cron_token', ''));
        if ($saved === '' || $token === '' || !hash_equals($saved, $token)) {
            $this->json(['success' => false, 'message' => '服务器管家采集密钥不正确。'], 403);
        }

        $force = isset($_GET['force']) && (string) $_GET['force'] === '1';
        $limit = max(1, min(80, (int) (isset($_GET['limit']) ? $_GET['limit'] : 30)));
        $userId = isset($_GET['user_id']) ? max(0, (int) $_GET['user_id']) : 0;
        $params = ['ssh', 'agent'];
        $where = 'monitor_type IN (?, ?) AND is_enabled = 1';
        if ($userId > 0) {
            $where .= ' AND user_id = ?';
            $params[] = $userId;
        }
        if (!$force) {
            $where .= ' AND (last_checked_at IS NULL OR TIMESTAMPDIFF(SECOND, last_checked_at, NOW()) >= frequency)';
        }

        $servers = Database::fetchAll(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE ' . $where . ' ORDER BY last_checked_at IS NULL DESC, last_checked_at ASC, id ASC' . Database::limitClause($limit, 1, 80),
            $params
        );

        $this->json($this->collectServerOpsRows($servers, $force, '服务器管家采集任务已执行。'));
    }

    public function userCronCollect()
    {
        if (!$this->ensureServerOpsReady()) {
            return;
        }

        $userId = max(0, (int) (isset($_GET['user_id']) ? $_GET['user_id'] : 0));
        $token = trim(isset($_GET['token']) ? $_GET['token'] : '');
        $user = $userId > 0 ? Database::fetch(
            'SELECT id, role, package_id, server_ops_cron_token, status FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1',
            [$userId]
        ) : null;
        $saved = $user && isset($user['server_ops_cron_token']) ? trim((string) $user['server_ops_cron_token']) : '';
        if (!$user || (int) $user['status'] !== 1 || $saved === '' || $token === '' || !hash_equals($saved, $token)) {
            $this->json(['success' => false, 'message' => '个人服务器采集链接无效或已重置。'], 403);
        }
        if (!$this->serverOpsAllowedForUser($user)) {
            $this->json(['success' => false, 'message' => '当前账号没有服务器运维权限，采集任务已拒绝。'], 403);
        }

        $force = isset($_GET['force']) && (string) $_GET['force'] === '1';
        $limit = max(1, min(30, (int) (isset($_GET['limit']) ? $_GET['limit'] : 10)));
        $params = [$userId, 'ssh', 'agent'];
        $where = 'user_id = ? AND monitor_type IN (?, ?) AND is_enabled = 1';
        if (!$force) {
            $where .= ' AND (last_checked_at IS NULL OR TIMESTAMPDIFF(SECOND, last_checked_at, NOW()) >= frequency)';
        }

        $servers = Database::fetchAll(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE ' . $where . ' ORDER BY last_checked_at IS NULL DESC, last_checked_at ASC, id ASC' . Database::limitClause($limit, 1, 30),
            $params
        );

        $this->json($this->collectServerOpsRows($servers, $force, '个人服务器采集任务已执行。'));
    }

    protected function requireServerOps($json = false)
    {
        if ($this->serverOpsAllowed()) {
            return;
        }

        $message = '当前账号没有服务器运维权限，请升级套餐或联系管理员开通。';
        if ($json || $this->expectsJson()) {
            $this->json(['success' => false, 'message' => $message], 403);
        }

        set_flash('error', $message);
        $this->redirect('packages');
    }

    protected function serverOpsAllowed()
    {
        $user = Auth::user();
        if (!$user) {
            return false;
        }
        return $this->serverOpsAllowedForUser($user);
    }

    protected function serverOpsAllowedForUser(array $user)
    {
        if (isset($user['role']) && $user['role'] === 'admin') {
            return true;
        }

        try {
            $package = Database::fetch(
                'SELECT allow_monitor FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1',
                [isset($user['package_id']) ? (int) $user['package_id'] : 0]
            );
            return (new PermissionService())->featureAllowed($user, 'monitor', $package ?: []);
        } catch (\Throwable $e) {
            Logger::error('服务器运维权限检查失败：' . $e->getMessage(), ['user_id' => isset($user['id']) ? $user['id'] : 0]);
            return false;
        }
    }

    protected function collectServerOpsRows(array $servers, $force, $message)
    {
        $monitorService = new MonitorService();
        $probeService = new ServiceProbeService();
        $result = [
            'success' => true,
            'message' => $message,
            'time' => now(),
            'force' => (bool) $force,
            'total' => count($servers),
            'success_count' => 0,
            'failed_count' => 0,
            'skipped_count' => 0,
            'probe_total' => 0,
            'probe_down' => 0,
            'items' => [],
        ];

        foreach ($servers as $server) {
            $item = [
                'id' => (int) $server['id'],
                'user_id' => (int) $server['user_id'],
                'name' => $server['name'],
                'type' => $server['monitor_type'],
                'status' => 'pending',
                'message' => '',
                'probes' => ['total' => 0, 'down' => 0],
            ];

            try {
                if ($server['monitor_type'] === 'agent' && trim((string) $server['agent_url']) === '') {
                    $item['status'] = 'skipped';
                    $item['message'] = 'Agent 主动上报模式等待客户端推送。';
                    $result['skipped_count']++;
                } else {
                    $monitorService->collect($server);
                    $item['status'] = 'online';
                    $item['message'] = '服务器指标采集成功。';
                    $result['success_count']++;
                }

                $probes = $probeService->collectForServer($server, (bool) $force);
                $item['probes'] = $probes;
                $result['probe_total'] += isset($probes['total']) ? (int) $probes['total'] : 0;
                $result['probe_down'] += isset($probes['down']) ? (int) $probes['down'] : 0;
            } catch (\Throwable $e) {
                $result['failed_count']++;
                $item['status'] = 'offline';
                $item['message'] = $this->connectionHint($e->getMessage());
            }

            $result['items'][] = $item;
        }

        return $result;
    }

    protected function userCronToken()
    {
        $userId = Auth::id();
        $row = Database::fetch('SELECT server_ops_cron_token FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [$userId]);
        $token = $row && !empty($row['server_ops_cron_token']) ? (string) $row['server_ops_cron_token'] : '';
        if ($token === '') {
            $token = $this->newCronToken();
            Database::execute(
                'UPDATE ' . Database::table('users') . ' SET server_ops_cron_token = ?, updated_at = ? WHERE id = ?',
                [$token, now(), $userId]
            );
        }
        return $token;
    }

    protected function newCronToken()
    {
        return bin2hex(random_bytes(32));
    }

    protected function serverPayload(array $existing = null)
    {
        $monitorType = isset($_POST['monitor_type']) && $_POST['monitor_type'] === 'agent' ? 'agent' : 'ssh';
        $authType = isset($_POST['ssh_auth_type']) && $_POST['ssh_auth_type'] === 'key' ? 'key' : 'password';
        $host = trim((string) (isset($_POST['ssh_host']) ? $_POST['ssh_host'] : ''));
        $agentToken = trim((string) (isset($_POST['agent_token']) ? $_POST['agent_token'] : ''));
        if ($monitorType === 'agent' && $agentToken === '' && $existing && !empty($existing['agent_token'])) {
            $agentToken = $existing['agent_token'];
        }
        if ($monitorType === 'agent' && $agentToken === '') {
            $agentToken = bin2hex(random_bytes(24));
        }
        $data = [
            'user_id' => Auth::id(),
            'monitor_type' => $monitorType,
            'name' => trim((string) (isset($_POST['name']) ? $_POST['name'] : '')),
            'remark' => trim((string) (isset($_POST['remark']) ? $_POST['remark'] : '')),
            'panel_url' => '',
            'api_key' => '',
            'panel_port' => 0,
            'server_ip' => trim((string) (isset($_POST['server_ip']) ? $_POST['server_ip'] : $host)),
            'ssh_host' => $host,
            'ssh_port' => max(1, min(65535, (int) (isset($_POST['ssh_port']) ? $_POST['ssh_port'] : 22))),
            'ssh_username' => trim((string) (isset($_POST['ssh_username']) ? $_POST['ssh_username'] : '')),
            'ssh_auth_type' => $authType,
            'agent_url' => trim((string) (isset($_POST['agent_url']) ? $_POST['agent_url'] : ($existing && isset($existing['agent_url']) ? $existing['agent_url'] : ''))),
            'agent_token' => $agentToken,
            'group_name' => trim((string) (isset($_POST['group_name']) ? $_POST['group_name'] : '个人服务器')),
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'frequency' => max(60, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 300)),
            'threshold_config' => json_encode([
                'cpu' => (float) (isset($_POST['cpu_threshold']) ? $_POST['cpu_threshold'] : 90),
                'memory' => (float) (isset($_POST['memory_threshold']) ? $_POST['memory_threshold'] : 90),
                'disk' => (float) (isset($_POST['disk_threshold']) ? $_POST['disk_threshold'] : 90),
            ], JSON_UNESCAPED_UNICODE),
            'status' => $existing ? $existing['status'] : 'unknown',
            'updated_at' => now(),
        ];
        foreach (['ssh_password', 'ssh_private_key', 'ssh_key_passphrase'] as $field) {
            $plain = (string) (isset($_POST[$field]) ? $_POST[$field] : '');
            if ($plain !== '') {
                $data[$field] = CryptoService::encrypt($plain);
            } elseif ($existing && isset($existing[$field])) {
                $data[$field] = $existing[$field];
            } else {
                $data[$field] = '';
            }
        }
        return $data;
    }

    protected function probePayload(array $server)
    {
        $type = isset($_POST['type']) && in_array($_POST['type'], ['http', 'tcp', 'ssl'], true) ? $_POST['type'] : 'http';
        $name = trim((string) (isset($_POST['name']) ? $_POST['name'] : ''));
        $target = trim((string) (isset($_POST['target']) ? $_POST['target'] : ''));
        if ($name === '') {
            throw new \RuntimeException('请填写探针名称。');
        }
        if ($target === '') {
            throw new \RuntimeException('请填写检测目标。');
        }
        $method = isset($_POST['method']) && strtoupper($_POST['method']) === 'GET' ? 'GET' : 'HEAD';
        $port = (int) (isset($_POST['port']) ? $_POST['port'] : 0);
        if ($type === 'http') {
            $parts = parse_url($target);
            if (!$parts || empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
                throw new \RuntimeException('HTTP 检测目标必须填写完整 http:// 或 https:// 地址。');
            }
            $port = $port > 0 ? $port : (isset($parts['port']) ? (int) $parts['port'] : 0);
        } else {
            $targetParts = $this->normalizeProbeHostPort($target, $type === 'ssl' ? 443 : 80);
            $target = $targetParts['host'];
            $port = $port > 0 ? $port : $targetParts['port'];
        }
        if ($port < 0 || $port > 65535) {
            throw new \RuntimeException('端口范围必须在 1-65535 之间。');
        }
        return [
            'type' => $type,
            'name' => text_limit($name, 120, ''),
            'target' => $target,
            'port' => $port,
            'method' => $method,
            'expected_status' => text_limit(trim((string) (isset($_POST['expected_status']) ? $_POST['expected_status'] : '200-399')), 80, ''),
            'keyword' => text_limit(trim((string) (isset($_POST['keyword']) ? $_POST['keyword'] : '')), 255, ''),
            'timeout_seconds' => max(2, min(15, (int) (isset($_POST['timeout_seconds']) ? $_POST['timeout_seconds'] : 5))),
            'frequency' => max(60, min(86400, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 300))),
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'updated_at' => now(),
        ];
    }

    protected function normalizeProbeHostPort($target, $defaultPort)
    {
        $target = trim((string) $target);
        $parts = parse_url(strpos($target, '://') === false ? 'tcp://' . $target : $target);
        $host = isset($parts['host']) ? $parts['host'] : $target;
        $host = trim($host, " \t\n\r\0\x0B[]");
        $port = !empty($parts['port']) ? (int) $parts['port'] : (int) $defaultPort;
        if ($host === '') {
            throw new \RuntimeException('检测目标主机不能为空。');
        }
        return ['host' => $host, 'port' => $port];
    }

    protected function serverForUser($id)
    {
        $server = Database::fetch(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND user_id = ? AND monitor_type IN (?, ?) LIMIT 1',
            [$id, Auth::id(), 'ssh', 'agent']
        );
        if (!$server) {
            if ($this->expectsJson()) {
                $this->json(['success' => false, 'message' => '服务器不存在或无权访问。'], 404);
            }
            http_response_code(404);
            echo '服务器不存在或无权访问';
            exit;
        }
        return $server;
    }

    protected function monitorPageForServer($serverId, $userId)
    {
        return Database::fetch('SELECT * FROM ' . Database::table('server_monitor_pages') . ' WHERE server_id = ? AND user_id = ? LIMIT 1', [$serverId, $userId]);
    }

    protected function hasNewCredential(array $data)
    {
        return !empty($data['ssh_password']) || !empty($data['ssh_private_key']);
    }

    protected function countUserServers()
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('monitor_servers') . ' WHERE user_id = ? AND monitor_type IN (?, ?)', [Auth::id(), 'ssh', 'agent']);
        return $row ? (int) $row['c'] : 0;
    }

    protected function serverLimit()
    {
        return max(0, (int) setting('ssh_terminal_user_server_limit', '5'));
    }

    protected function probeLimit()
    {
        return max(0, (int) setting('server_probe_user_check_limit', '20'));
    }

    protected function countUserProbes()
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('server_service_checks') . ' WHERE user_id = ?', [Auth::id()]);
        return $row ? (int) $row['c'] : 0;
    }

    protected function serverIsStale(array $server)
    {
        if (empty($server['last_checked_at'])) {
            return false;
        }
        $last = strtotime($server['last_checked_at']);
        if (!$last) {
            return false;
        }
        $frequency = max(60, (int) (isset($server['frequency']) ? $server['frequency'] : 300));
        return (time() - $last) > max(600, $frequency * 2);
    }

    protected function logCommand(array $server, $command, $output, $risk, $sessionId = null)
    {
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('server_command_logs') . ' (user_id, server_id, session_id, command, output_summary, exit_status, risk_level, ip, user_agent, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [Auth::id(), $server['id'], $sessionId, $command, text_limit((string) $output, 4000), null, $risk, $this->ip(), $this->userAgent(), now()]
            );
        } catch (\Throwable $e) {
            Logger::error('SSH 命令审计日志写入失败：' . $e->getMessage(), [
                'user_id' => Auth::id(),
                'server_id' => isset($server['id']) ? $server['id'] : 0,
            ]);
        }
    }

    protected function connectionHint($message)
    {
        $message = (string) $message;
        if (stripos($message, 'connect') !== false || strpos($message, '连接') !== false) {
            return '连接失败：请检查服务器 IP、SSH 端口、防火墙、安全组是否放行。原始提示：' . $message;
        }
        if (stripos($message, 'login') !== false || strpos($message, '登录') !== false) {
            return '认证失败：请检查 SSH 用户名、密码/私钥、root 登录策略。原始提示：' . $message;
        }
        if (stripos($message, 'phpseclib') !== false || stripos($message, 'ssh2') !== false || strpos($message, '扩展') !== false) {
            return '环境不通：当前站点服务器缺少 SSH 客户端能力，请安装 phpseclib 或 PHP ssh2 扩展。原始提示：' . $message;
        }
        return '执行失败：' . $message;
    }

    protected function connectionChecks($message)
    {
        $message = (string) $message;
        $stage = 'command';
        if (stripos($message, 'phpseclib') !== false || stripos($message, 'ssh2') !== false || strpos($message, '扩展') !== false || strpos($message, '客户端') !== false) {
            $stage = 'environment';
        } elseif (stripos($message, 'connect') !== false || strpos($message, '连接') !== false || stripos($message, 'timed out') !== false) {
            $stage = 'network';
        } elseif (stripos($message, 'login') !== false || strpos($message, '登录') !== false || strpos($message, '认证') !== false) {
            $stage = 'auth';
        }

        $rows = [
            ['key' => 'config', 'label' => '表单配置', 'status' => 'ok', 'message' => '已读取 SSH 主机、端口、用户和认证方式。'],
            ['key' => 'environment', 'label' => 'PHP SSH 能力', 'status' => 'pending', 'message' => '检查 phpseclib 或 ssh2 扩展是否可用。'],
            ['key' => 'network', 'label' => '网络与端口', 'status' => 'pending', 'message' => '检查目标 IP、22/自定义端口、防火墙和安全组。'],
            ['key' => 'auth', 'label' => '账号认证', 'status' => 'pending', 'message' => '检查用户名、密码、私钥、root 登录策略。'],
            ['key' => 'command', 'label' => '测试命令', 'status' => 'pending', 'message' => '执行基础命令确认 Shell 可用。'],
        ];
        $order = ['config' => 0, 'environment' => 1, 'network' => 2, 'auth' => 3, 'command' => 4];
        $failedIndex = isset($order[$stage]) ? $order[$stage] : 4;
        foreach ($rows as &$row) {
            $index = $order[$row['key']];
            if ($index < $failedIndex) {
                $row['status'] = 'ok';
            } elseif ($index === $failedIndex) {
                $row['status'] = 'fail';
                $row['message'] .= ' 当前卡在这一步：' . $message;
            }
        }
        unset($row);
        return $rows;
    }

    protected function blockedSshHost($host)
    {
        $host = trim(strtolower((string) $host), " \t\n\r\0\x0B[]");
        if ($host === '' || in_array($host, ['localhost', 'localhost.localdomain'], true)) {
            return $host !== '';
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            if ($host === '0.0.0.0' || $host === '::' || $host === '::1' || strpos($host, '127.') === 0) {
                return true;
            }
            if ($host === '169.254.169.254') {
                return true;
            }
        }
        return false;
    }

    protected function uniquePageToken()
    {
        do {
            $token = bin2hex(random_bytes(16));
            $exists = Database::fetch('SELECT id FROM ' . Database::table('server_monitor_pages') . ' WHERE token = ? LIMIT 1', [$token]);
        } while ($exists);
        return $token;
    }

    protected function dateOrNull($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $time = strtotime($value);
        return $time ? date('Y-m-d H:i:s', $time) : null;
    }

    protected function countRows($table, $where, array $params)
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table($table) . ' WHERE ' . $where, $params);
        return $row ? (int) $row['c'] : 0;
    }

    protected function ip()
    {
        return isset($_SERVER['REMOTE_ADDR']) ? substr((string) $_SERVER['REMOTE_ADDR'], 0, 45) : '';
    }

    protected function userAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 255) : '';
    }
}
