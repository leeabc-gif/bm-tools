<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Validator;
use App\Models\Coupon;
use App\Models\FileItem;
use App\Models\Folder;
use App\Models\MonitorMetric;
use App\Models\Package;
use App\Models\Order;
use App\Models\Recharge;
use App\Models\User;
use App\Services\ApiAppService;
use App\Services\DatabaseUpgradeService;
use App\Services\FileLogService;
use App\Services\FileTrashService;
use App\Services\Monitor\MonitorService;
use App\Services\Monitor\ServiceProbeService;
use App\Services\Monitor\SshMonitorClient;
use App\Services\CryptoService;
use App\Services\PackageService;
use App\Services\Payment\PaymentManager;
use App\Services\PermissionService;
use App\Services\RedeemCardService;
use App\Services\RepositoryService;
use App\Services\SubsiteService;
use App\Services\TeamSpaceService;
use App\Services\UploadLimitService;

class MobileController extends Controller
{
    protected function mobileView($view, array $data = [])
    {
        $this->requireLogin();
        $views = [
            'dashboard' => 'mobile/dashboard',
            'files' => 'mobile/files',
            'file_detail' => 'mobile/file_detail',
            'netdisk' => 'mobile/netdisk',
            'repositories' => 'mobile/repositories',
            'subsites' => 'mobile/subsites',
            'teams' => 'mobile/teams',
            'servers' => 'mobile/servers',
            'server_detail' => 'mobile/server_detail',
            'server_form' => 'mobile/server_form',
            'server_terminal' => 'mobile/server_terminal',
            'server_probes' => 'mobile/server_probes',
            'server_share' => 'mobile/server_share',
            'server_commands' => 'mobile/server_commands',
            'orders' => 'mobile/orders',
            'balance_logs' => 'mobile/balance_logs',
            'recharge' => 'mobile/recharge',
            'cards' => 'mobile/cards',
            'packages' => 'mobile/packages',
            'api' => 'mobile/api',
            'alerts' => 'mobile/alerts',
            'notifications' => 'mobile/notifications',
            'profile' => 'mobile/profile',
            'profile_edit' => 'mobile/profile_edit',
            'password' => 'mobile/password',
            'menu' => 'mobile/menu',
        ];
        $this->view(isset($views[$view]) ? $views[$view] : 'mobile/dashboard', $data, 'layouts/mobile_user');
    }

    public function dashboard()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $this->mobileView('dashboard', [
            'title' => '移动工作台',
            'user' => $user,
            'stats' => $this->dashboardStats($user),
            'recentFiles' => $this->recentFiles((int) $user['id'], 6),
            'notices' => $this->recentNotifications((int) $user['id'], 5),
        ]);
    }

    public function files()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $uploadLimits = new UploadLimitService();
        $schemaReady = $this->mobileTablesReady(['files'], '图片与上传');
        $this->mobileView('files', [
            'title' => '图片与上传',
            'user' => $user,
            'files' => $schemaReady ? $this->filesByType((int) $user['id'], 'image', 30) : [],
            'usage' => $schemaReady ? $this->usage((int) $user['id'], 'image') : ['count' => 0, 'size' => 0],
            'uploadLimits' => $this->mobileUploadLimitSummary($uploadLimits, (int) $user['id'], 'image'),
            'uploadAction' => url('files/upload'),
            'schemaReady' => $schemaReady,
        ]);
    }

    public function fileDetail()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $file = $id > 0 ? $this->safeRow('SELECT * FROM ' . Database::table('files') . ' WHERE id = ? AND user_id = ? LIMIT 1', [$id, (int) $user['id']]) : null;
        if (!$file) {
            set_flash('error', '文件不存在或无权访问。');
            $this->redirect('m/files');
        }
        $this->mobileView('file_detail', [
            'title' => '文件详情',
            'file' => $file,
            'fileUrl' => public_url($file['file_url']),
        ]);
    }

    public function netdisk()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $uploadLimits = new UploadLimitService();
        $schemaReady = $this->mobileTablesReady(['files', 'file_folders'], '个人网盘');
        if (!$schemaReady) {
            $this->mobileView('netdisk', [
                'title' => '个人网盘',
                'user' => $user,
                'folderId' => 0,
                'currentFolder' => null,
                'parentFolderId' => 0,
                'files' => [],
                'folders' => [],
                'usage' => ['count' => 0, 'size' => 0],
                'uploadLimits' => $this->mobileUploadLimitSummary($uploadLimits, (int) $user['id'], 'file'),
                'uploadAction' => url('netdisk/upload'),
                'schemaReady' => false,
            ]);
            return;
        }

        $folderId = max(0, (int) (isset($_GET['folder_id']) ? $_GET['folder_id'] : 0));
        if (!$this->folderBelongsToUser($folderId, (int) $user['id'])) {
            set_flash('error', '文件夹不存在或无权访问。');
            $this->redirect('m/netdisk');
        }

        $currentFolder = $folderId > 0
            ? $this->safeRow('SELECT * FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ? LIMIT 1', [$folderId, (int) $user['id']])
            : null;

        $this->mobileView('netdisk', [
            'title' => '个人网盘',
            'user' => $user,
            'folderId' => $folderId,
            'currentFolder' => $currentFolder,
            'parentFolderId' => $currentFolder ? (int) $currentFolder['parent_id'] : 0,
            'files' => $this->filesForFolder((int) $user['id'], $folderId, 50),
            'folders' => $this->foldersForParent((int) $user['id'], $folderId, 60),
            'usage' => $this->usage((int) $user['id'], ''),
            'uploadLimits' => $this->mobileUploadLimitSummary($uploadLimits, (int) $user['id'], 'file'),
            'uploadAction' => url('netdisk/upload'),
            'schemaReady' => true,
        ]);
    }

    public function repositories()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $schemaReady = $this->mobileTablesReady(['file_repositories'], '分享仓库');
        $service = new RepositoryService();
        $repositories = [];
        if ($schemaReady) {
            try {
                $repositories = $service->repositoriesForUser((int) $user['id']);
            } catch (\Throwable $e) {
                $repositories = [];
            }
        }
        $this->mobileView('repositories', [
            'title' => '分享仓库',
            'repositories' => $repositories,
            'statsByRepo' => $schemaReady ? $this->mobileRepositoryStats($repositories, $service) : [],
            'schemaReady' => $schemaReady,
        ]);
    }

    public function subsites()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $service = new SubsiteService();
        $subsites = [];
        $packageInfo = ['allow' => false, 'limit' => 0, 'name' => '当前套餐'];
        try {
            $subsites = $service->userSubsites((int) $user['id']);
            $packageInfo = $service->packageInfo($user);
        } catch (\Throwable $e) {
            $subsites = [];
        }
        $used = count($subsites);
        $limit = (int) (isset($packageInfo['limit']) ? $packageInfo['limit'] : 0);

        $this->mobileView('subsites', [
            'title' => '我的分站',
            'subsites' => $subsites,
            'service' => $service,
            'domainConfig' => $service->domainConfigSummary(),
            'suffixes' => $service->suffixes(),
            'defaultSuffix' => $service->defaultSuffix(),
            'packageInfo' => $packageInfo,
            'usedCount' => $used,
            'limitCount' => $limit,
            'canCreate' => $service->enabled() && !empty($packageInfo['allow']) && ($limit <= 0 || $used < $limit),
            'customDomainEnabled' => $service->customDomainEnabled(),
        ]);
    }

    public function teams()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileTeamSpaceReady()) {
            $this->mobileView('teams', [
                'title' => '团队空间',
                'teams' => [],
                'currentTeam' => null,
                'members' => [],
                'pendingInvites' => [],
                'myInvites' => [],
                'summary' => ['team_count' => 0, 'owned_count' => 0, 'member_count' => 0, 'pending_invites' => 0],
                'roleLabels' => [],
                'roleDescriptions' => [],
                'canManage' => false,
                'schemaReady' => false,
            ]);
            return;
        }

        $service = new TeamSpaceService();
        $user = $this->currentUser();
        $teams = [];
        $currentTeam = null;
        $members = [];
        $pendingInvites = [];
        $myInvites = [];
        $summary = ['team_count' => 0, 'owned_count' => 0, 'member_count' => 0, 'pending_invites' => 0];
        try {
            $teams = $service->teamsForUser((int) $user['id']);
            $summary = $service->overviewForUser((int) $user['id']);
            $myInvites = $service->invitesForUser((int) $user['id']);
            $teamId = max(0, (int) (isset($_GET['id']) ? $_GET['id'] : 0));
            if ($teamId > 0) {
                $currentTeam = $service->findTeamForUser($teamId, (int) $user['id']);
            }
            if (!$currentTeam && $teams) {
                $currentTeam = $teams[0];
            }
            if ($currentTeam) {
                $members = $service->members((int) $currentTeam['id']);
                $pendingInvites = $service->pendingInvites((int) $currentTeam['id']);
            }
        } catch (\Throwable $e) {
            set_flash('error', '团队空间读取失败：' . $e->getMessage());
        }

        $this->mobileView('teams', [
            'title' => '团队空间',
            'teams' => $teams,
            'currentTeam' => $currentTeam,
            'members' => $members,
            'pendingInvites' => $pendingInvites,
            'myInvites' => $myInvites,
            'summary' => $summary,
            'roleLabels' => $service->roleLabels(),
            'roleDescriptions' => $service->roleDescriptions(),
            'canManage' => $currentTeam ? $service->canManageMembers($currentTeam) : false,
            'schemaReady' => true,
        ]);
    }

    public function servers()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $schemaReady = $this->mobileTablesReady(['monitor_servers'], '服务器管家');
        $servers = $schemaReady
            ? $this->safeRows(
                'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE user_id = ? AND monitor_type IN (?, ?) ORDER BY id DESC LIMIT 40',
                [(int) $user['id'], 'ssh', 'agent']
            )
            : [];

        $metricModel = new MonitorMetric();
        $probeService = new ServiceProbeService();
        $stats = ['total' => count($servers), 'online' => 0, 'offline' => 0, 'stale' => 0, 'checks' => 0, 'down_checks' => 0];
        foreach ($servers as &$server) {
            try {
                $server['latest'] = $metricModel->latest($server['id']);
                $server['probe_stats'] = $probeService->statsForServer($server['id']);
            } catch (\Throwable $e) {
                $server['latest'] = null;
                $server['probe_stats'] = ['total' => 0, 'down' => 0];
            }
            $server['is_stale'] = $this->serverIsStale($server);
            if ((isset($server['status']) ? $server['status'] : '') === 'online') {
                $stats['online']++;
            } elseif ((isset($server['status']) ? $server['status'] : '') === 'offline') {
                $stats['offline']++;
            }
            if (!empty($server['is_stale'])) {
                $stats['stale']++;
            }
            $stats['checks'] += (int) (isset($server['probe_stats']['total']) ? $server['probe_stats']['total'] : 0);
            $stats['down_checks'] += (int) (isset($server['probe_stats']['down']) ? $server['probe_stats']['down'] : 0);
        }
        unset($server);

        $this->mobileView('servers', [
            'title' => '服务器管家',
            'servers' => $servers,
            'stats' => $stats,
            'commandsToday' => $schemaReady && $this->mobileTableExists('server_command_logs') ? $this->safeCount('server_command_logs', 'user_id = ? AND DATE(created_at) = CURDATE()', [(int) $user['id']]) : 0,
            'schemaReady' => $schemaReady,
        ]);
    }

    public function serverForm()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }
        $server = null;
        if (!empty($_GET['id'])) {
            $server = $this->mobileServerForUser((int) $_GET['id']);
            if (!$server) {
                set_flash('error', '服务器不存在或无权编辑。');
                $this->redirect('m/servers');
            }
        }
        $this->mobileView('server_form', [
            'title' => $server ? '编辑服务器' : '添加服务器',
            'server' => $server,
            'limit' => $this->mobileServerLimit(),
            'used' => $this->mobileServerCount(),
        ]);
    }

    public function serverCommands()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileTablesReady(['monitor_servers', 'server_command_logs'], '命令记录')) {
            $this->mobileView('server_commands', [
                'title' => '命令记录',
                'logs' => [],
                'servers' => [],
                'filters' => ['server_id' => 0, 'keyword' => ''],
                'stats' => ['total' => 0, 'today' => 0],
                'schemaReady' => false,
            ]);
            return;
        }
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }

        $userId = (int) Auth::id();
        $serverId = max(0, (int) (isset($_GET['server_id']) ? $_GET['server_id'] : 0));
        $keyword = text_limit(trim((string) (isset($_GET['keyword']) ? $_GET['keyword'] : '')), 80, '');
        $servers = $this->safeRows(
            'SELECT id, name, monitor_type, ssh_host, server_ip FROM ' . Database::table('monitor_servers') . ' WHERE user_id = ? AND monitor_type IN (?, ?) ORDER BY name ASC, id DESC',
            [$userId, 'ssh', 'agent']
        );
        $where = ['cl.user_id = ?', 's.user_id = ?', 's.monitor_type IN (?, ?)'];
        $params = [$userId, $userId, 'ssh', 'agent'];
        if ($serverId > 0) {
            $where[] = 's.id = ?';
            $params[] = $serverId;
        }
        if ($keyword !== '') {
            $where[] = '(cl.command LIKE ? OR cl.output_summary LIKE ? OR s.name LIKE ? OR s.ssh_host LIKE ? OR s.server_ip LIKE ?)';
            for ($i = 0; $i < 5; $i++) {
                $params[] = '%' . $keyword . '%';
            }
        }
        $baseSql = 'FROM ' . Database::table('server_command_logs') . ' cl INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id WHERE ' . implode(' AND ', $where);
        $logs = $this->safeRows(
            'SELECT cl.*, s.name AS server_name, s.monitor_type, s.ssh_host, s.server_ip ' . $baseSql . ' ORDER BY cl.id DESC LIMIT 80',
            $params
        );
        $total = $this->safeRow('SELECT COUNT(*) AS c FROM ' . Database::table('server_command_logs') . ' cl INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id WHERE cl.user_id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?)', [$userId, $userId, 'ssh', 'agent']);
        $today = $this->safeRow('SELECT COUNT(*) AS c FROM ' . Database::table('server_command_logs') . ' cl INNER JOIN ' . Database::table('monitor_servers') . ' s ON cl.server_id = s.id WHERE cl.user_id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?) AND DATE(cl.created_at) = CURDATE()', [$userId, $userId, 'ssh', 'agent']);

        $this->mobileView('server_commands', [
            'title' => '命令记录',
            'logs' => $logs,
            'servers' => $servers,
            'filters' => ['server_id' => $serverId, 'keyword' => $keyword],
            'stats' => ['total' => $total ? (int) $total['c'] : 0, 'today' => $today ? (int) $today['c'] : 0],
            'schemaReady' => true,
        ]);
    }

    public function serverDetail()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_GET['id']) ? $_GET['id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权访问。');
            $this->redirect('m/servers');
        }
        $metricModel = new MonitorMetric();
        $probeService = new ServiceProbeService();
        try {
            $latest = $metricModel->latest($server['id']);
        } catch (\Throwable $e) {
            $latest = null;
        }
        $commands = $this->mobileTableExists('server_command_logs')
            ? $this->safeRows('SELECT * FROM ' . Database::table('server_command_logs') . ' WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT 8', [(int) Auth::id(), (int) $server['id']])
            : [];
        $page = $this->mobileTableExists('server_monitor_pages') ? $this->mobileMonitorPageForServer((int) $server['id'], (int) Auth::id()) : null;
        $probeStats = ['total' => 0, 'up' => 0, 'down' => 0, 'expiring_ssl' => 0];
        $probeLogs = [];
        if ($this->mobileTableExists('server_service_checks')) {
            $probeStats = $probeService->statsForServer((int) $server['id']);
            $probeLogs = $this->mobileTableExists('server_service_check_logs') ? $probeService->latestLogsForServer((int) $server['id'], 6) : [];
        }
        $server['is_stale'] = $this->serverIsStale($server);
        $this->mobileView('server_detail', [
            'title' => isset($server['name']) ? $server['name'] : '服务器详情',
            'server' => $server,
            'latest' => $latest,
            'commands' => $commands,
            'page' => $page,
            'probeStats' => $probeStats,
            'probeLogs' => $probeLogs,
        ]);
    }

    public function serverTerminal()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_GET['id']) ? $_GET['id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权访问。');
            $this->redirect('m/servers');
        }
        if ((isset($server['monitor_type']) ? $server['monitor_type'] : 'ssh') !== 'ssh') {
            set_flash('error', 'Agent 模式不支持在线 SSH 终端。');
            $this->redirect('m/servers/' . (int) $server['id']);
        }
        $commands = $this->mobileTableExists('server_command_logs')
            ? $this->safeRows('SELECT * FROM ' . Database::table('server_command_logs') . ' WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT 12', [(int) Auth::id(), (int) $server['id']])
            : [];
        $this->mobileView('server_terminal', [
            'title' => '在线终端',
            'server' => $server,
            'commands' => $commands,
            'terminalEnabled' => (string) setting('ssh_terminal_enabled', '1') === '1',
            'commandTimeout' => max(5, min(300, (int) setting('ssh_terminal_command_timeout', '30'))),
        ]);
    }

    public function runServerCommand()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->json(['success' => false, 'message' => '当前账号没有服务器运维权限。'], 403);
        }
        if ((string) setting('ssh_terminal_enabled', '1') !== '1') {
            $this->json(['success' => false, 'message' => '管理员已关闭在线终端功能。'], 403);
        }
        $server = $this->mobileServerForUser((int) (isset($_POST['id']) ? $_POST['id'] : 0));
        if (!$server) {
            $this->json(['success' => false, 'message' => '服务器不存在或无权访问。'], 404);
        }
        if ((isset($server['monitor_type']) ? $server['monitor_type'] : 'ssh') !== 'ssh') {
            $this->json(['success' => false, 'message' => 'Agent 模式不支持在线 SSH 命令。'], 422);
        }
        $command = (string) (isset($_POST['command']) ? $_POST['command'] : '');
        if (trim($command) === '') {
            $this->json(['success' => false, 'message' => '命令不能为空。'], 422);
        }
        if (strlen($command) > 20000) {
            $this->json(['success' => false, 'message' => '命令内容过长，请拆分后执行。'], 422);
        }
        $timeout = max(5, min(3600, (int) setting('ssh_terminal_command_timeout', '30')));
        $startedAt = microtime(true);
        try {
            $output = (new SshMonitorClient($server))->runCommand($command, $timeout);
            $durationMs = (int) round((microtime(true) - $startedAt) * 1000);
            $this->mobileLogCommand($server, $command, $output, 'normal');
            $this->json(['success' => true, 'message' => '命令执行完成。', 'output' => $output, 'duration_ms' => $durationMs, 'time' => now()]);
        } catch (\Throwable $e) {
            $durationMs = (int) round((microtime(true) - $startedAt) * 1000);
            $this->mobileLogCommand($server, $command, $e->getMessage(), 'normal');
            $this->json(['success' => false, 'message' => $this->mobileConnectionHint($e->getMessage()), 'raw' => $e->getMessage(), 'duration_ms' => $durationMs, 'steps' => $this->mobileConnectionChecks($e->getMessage())], 422);
        }
    }

    public function serverProbes()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }
        if (!$this->mobileTablesReady(['server_service_checks', 'server_service_check_logs'], '站点探针', true)) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_GET['id']) ? $_GET['id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权访问。');
            $this->redirect('m/servers');
        }
        $service = new ServiceProbeService();
        $editCheck = null;
        if (!empty($_GET['check_id'])) {
            $editCheck = $service->checkForUser((int) $_GET['check_id'], (int) Auth::id());
            if ($editCheck && (int) $editCheck['server_id'] !== (int) $server['id']) {
                $editCheck = null;
            }
        }
        $this->mobileView('server_probes', [
            'title' => '站点探针',
            'server' => $server,
            'checks' => $service->checksForServer((int) $server['id'], (int) Auth::id()),
            'editCheck' => $editCheck,
            'stats' => $service->statsForServer((int) $server['id']),
            'logs' => $service->latestLogsForServer((int) $server['id'], 8),
            'limit' => $this->mobileProbeLimit(),
        ]);
    }

    public function saveServerProbe()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['server_service_checks', 'server_service_check_logs'], '站点探针', true)) {
            $this->redirect('m/servers');
        }
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_POST['server_id']) ? $_POST['server_id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权访问。');
            $this->redirect('m/servers');
        }
        $service = new ServiceProbeService();
        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        $existing = $id > 0 ? $service->checkForUser($id, (int) Auth::id()) : null;
        if ($existing && (int) $existing['server_id'] !== (int) $server['id']) {
            $existing = null;
        }
        if (!$existing && $this->mobileProbeLimit() > 0 && $this->mobileProbeCount() >= $this->mobileProbeLimit()) {
            set_flash('error', '当前最多可保存 ' . $this->mobileProbeLimit() . ' 个站点探针。');
            $this->redirect('m/servers/' . (int) $server['id'] . '/probes');
        }
        try {
            $data = $this->mobileProbePayload($server);
            if ($existing) {
                $set = [];
                $params = [];
                foreach ($data as $key => $value) {
                    $set[] = $key . ' = ?';
                    $params[] = $value;
                }
                $params[] = (int) $existing['id'];
                Database::execute('UPDATE ' . Database::table('server_service_checks') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
                $probeId = (int) $existing['id'];
            } else {
                $data['user_id'] = (int) Auth::id();
                $data['server_id'] = (int) $server['id'];
                $data['status'] = 'unknown';
                $data['created_at'] = now();
                $columns = array_keys($data);
                Database::execute(
                    'INSERT INTO ' . Database::table('server_service_checks') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')',
                    array_values($data)
                );
                $probeId = (int) Database::lastInsertId();
            }
            if (!empty($_POST['test_after_save'])) {
                $check = $service->checkForUser($probeId, (int) Auth::id());
                if ($check) {
                    $service->collectCheck($check, $server);
                }
            }
            set_flash('success', $existing ? '站点探针已更新。' : '站点探针已添加。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', '探针保存失败：' . $this->mobileSchemaHint($e->getMessage(), '站点探针'));
        }
        $this->redirect('m/servers/' . (int) $server['id'] . '/probes');
    }

    public function testServerProbe()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['server_service_checks', 'server_service_check_logs'], '站点探针', true)) {
            $this->json(['success' => false, 'message' => '站点探针数据结构未准备完成。'], 503);
        }
        $server = $this->mobileServerForUser((int) (isset($_POST['server_id']) ? $_POST['server_id'] : 0));
        if (!$server) {
            $this->json(['success' => false, 'message' => '服务器不存在或无权访问。'], 404);
        }
        $service = new ServiceProbeService();
        try {
            if (!empty($_POST['id']) && empty($_POST['payload_test'])) {
                $check = $service->checkForUser((int) $_POST['id'], (int) Auth::id());
                if (!$check || (int) $check['server_id'] !== (int) $server['id']) {
                    $this->json(['success' => false, 'message' => '探针不存在或无权操作。'], 404);
                }
                $result = $service->collectCheck($check, $server);
                $this->json(['success' => $result['status'] === 'up', 'message' => $result['message'], 'data' => $result], $result['status'] === 'up' ? 200 : 422);
            }
            $payload = $this->mobileProbePayload($server);
            $payload['user_id'] = (int) Auth::id();
            $payload['server_id'] = (int) $server['id'];
            $result = $service->testPayload($payload);
            $this->json(['success' => !empty($result['success']), 'message' => $result['message'], 'data' => $result], !empty($result['success']) ? 200 : 422);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function deleteServerProbe()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['server_service_checks', 'server_service_check_logs'], '站点探针', true)) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_POST['server_id']) ? $_POST['server_id'] : 0));
        $check = (new ServiceProbeService())->checkForUser((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
        if (!$server || !$check || (int) $check['server_id'] !== (int) $server['id']) {
            set_flash('error', '探针不存在或无权删除。');
            $this->redirect('m/servers');
        }
        try {
            Database::execute('DELETE FROM ' . Database::table('server_service_check_logs') . ' WHERE check_id = ?', [(int) $check['id']]);
            Database::execute('DELETE FROM ' . Database::table('server_service_checks') . ' WHERE id = ? AND user_id = ?', [(int) $check['id'], (int) Auth::id()]);
            set_flash('success', '站点探针已删除。');
        } catch (\Throwable $e) {
            set_flash('error', '删除失败：' . $e->getMessage());
        }
        $this->redirect('m/servers/' . (int) $server['id'] . '/probes');
    }

    public function serverShare()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }
        if (!$this->mobileTablesReady(['server_monitor_pages'], '监控分享页', true)) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_GET['id']) ? $_GET['id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权访问。');
            $this->redirect('m/servers');
        }
        $this->mobileView('server_share', [
            'title' => '监控分享页',
            'server' => $server,
            'page' => $this->mobileMonitorPageForServer((int) $server['id'], (int) Auth::id()),
        ]);
    }

    public function saveServerShare()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['server_monitor_pages'], '监控分享页', true)) {
            $this->redirect('m/servers');
        }
        $server = $this->mobileServerForUser((int) (isset($_POST['server_id']) ? $_POST['server_id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权访问。');
            $this->redirect('m/servers');
        }
        $page = $this->mobileMonitorPageForServer((int) $server['id'], (int) Auth::id());
        $visibility = isset($_POST['visibility']) && in_array($_POST['visibility'], ['private', 'public', 'password'], true) ? $_POST['visibility'] : 'private';
        $password = (string) (isset($_POST['password']) ? $_POST['password'] : '');
        if ($visibility === 'password' && $password === '' && (!$page || empty($page['password_hash']))) {
            set_flash('error', '密码访问模式需要设置访问密码。');
            $this->redirect('m/servers/' . (int) $server['id'] . '/share');
        }
        $data = [
            'title' => text_limit(trim((string) (isset($_POST['title']) ? $_POST['title'] : '')), 120, ''),
            'visibility' => $visibility,
            'show_metrics' => isset($_POST['show_metrics']) ? 1 : 0,
            'show_services' => isset($_POST['show_services']) ? 1 : 0,
            'expires_at' => $this->mobileDateOrNull(isset($_POST['expires_at']) ? $_POST['expires_at'] : ''),
            'updated_at' => now(),
        ];
        if ($password !== '') {
            $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
        } elseif ($visibility !== 'password') {
            $data['password_hash'] = null;
        }
        try {
            if ($page) {
                $set = [];
                $params = [];
                foreach ($data as $key => $value) {
                    $set[] = $key . ' = ?';
                    $params[] = $value;
                }
                $params[] = (int) $page['id'];
                Database::execute('UPDATE ' . Database::table('server_monitor_pages') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
            } else {
                $data['user_id'] = (int) Auth::id();
                $data['server_id'] = (int) $server['id'];
                $data['token'] = $this->mobileUniquePageToken();
                $data['created_at'] = now();
                $columns = array_keys($data);
                Database::execute(
                    'INSERT INTO ' . Database::table('server_monitor_pages') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')',
                    array_values($data)
                );
            }
            set_flash('success', '监控分享页配置已保存。');
        } catch (\Throwable $e) {
            set_flash('error', '保存失败：' . $this->mobileSchemaHint($e->getMessage(), '监控分享页'));
        }
        $this->redirect('m/servers/' . (int) $server['id'] . '/share');
    }

    public function orders()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $schemaReady = $this->mobileTablesReady(['orders', 'recharges'], '订单与余额');
        $orderSql = $this->mobileTableExists('packages')
            ? 'SELECT o.*, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id WHERE o.user_id = ? ORDER BY o.id DESC LIMIT 40'
            : "SELECT o.*, '' AS package_name FROM " . Database::table('orders') . ' o WHERE o.user_id = ? ORDER BY o.id DESC LIMIT 40';
        $this->mobileView('orders', [
            'title' => '订单与余额',
            'orders' => $schemaReady ? $this->safeRows($orderSql, [(int) $user['id']]) : [],
            'recharges' => $schemaReady ? $this->safeRows('SELECT * FROM ' . Database::table('recharges') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 20', [(int) $user['id']]) : [],
            'user' => $user,
            'schemaReady' => $schemaReady,
        ]);
    }

    public function balanceLogs()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $schemaReady = $this->mobileTablesReady(['balance_logs'], '余额流水');
        $logs = $schemaReady
            ? $this->safeRows('SELECT * FROM ' . Database::table('balance_logs') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 120', [(int) Auth::id()])
            : [];
        $stats = [
            'total' => count($logs),
            'recharge' => 0.0,
            'consume' => 0.0,
            'refund' => 0.0,
            'adjust' => 0.0,
        ];
        foreach ($logs as $log) {
            $type = isset($log['type']) ? (string) $log['type'] : '';
            if (array_key_exists($type, $stats)) {
                $stats[$type] += (float) (isset($log['amount']) ? $log['amount'] : 0);
            }
        }

        $this->mobileView('balance_logs', [
            'title' => '余额流水',
            'user' => $user,
            'logs' => $logs,
            'stats' => $stats,
            'schemaReady' => $schemaReady,
        ]);
    }

    public function recharge()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $schemaReady = $this->mobileTablesReady(['orders', 'recharges', 'payment_config'], '账户充值');
        $payments = [];
        foreach ($this->mobilePayments() as $payment) {
            if (in_array(isset($payment['code']) ? $payment['code'] : '', ['manual', 'alipay'], true)) {
                $payments[] = $payment;
            }
        }
        $this->mobileView('recharge', [
            'title' => '账户充值',
            'user' => $user,
            'payments' => $payments,
            'recharges' => $schemaReady ? $this->safeRows('SELECT * FROM ' . Database::table('recharges') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 12', [(int) $user['id']]) : [],
            'schemaReady' => $schemaReady,
        ]);
    }

    public function createRecharge()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['orders', 'recharges', 'payment_config'], '账户充值', true)) {
            $this->redirect('m/recharge');
        }

        $amount = round((float) (isset($_POST['amount']) ? $_POST['amount'] : 0), 2);
        $method = isset($_POST['payment_method']) ? (string) $_POST['payment_method'] : 'manual';
        if ($amount <= 0 || $amount > 99999) {
            set_flash('error', '充值金额必须在 1 到 99999 元之间。');
            $this->redirect('m/recharge');
        }
        if (!in_array($method, ['manual', 'alipay'], true)) {
            set_flash('error', '手机端充值仅支持人工充值或支付宝当面付。');
            $this->redirect('m/recharge');
        }
        $payment = $this->mobileEnabledPayment($method);
        if (!$payment) {
            set_flash('error', '该支付方式未启用，请选择可用支付方式。');
            $this->redirect('m/recharge');
        }

        try {
            $order = (new Order())->createOrder(Auth::id(), 'recharge', $amount, $method, null, '手机端账户充值');
            (new Recharge())->create([
                'user_id' => Auth::id(),
                'order_id' => $order['id'],
                'amount' => $amount,
                'payment_method' => $method,
                'status' => 'pending',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $result = PaymentManager::driver($method)->create($order);
            if ($method === 'alipay' && !empty($result['qr_code'])) {
                $_SESSION['alipay_qr'][$order['order_no']] = $result['qr_code'];
                $this->redirect('pay/alipay/' . $order['order_no']);
            }
            set_flash('success', isset($result['message']) ? $result['message'] : '充值订单已创建。');
        } catch (\Throwable $e) {
            if (!empty($order['id'])) {
                try {
                    Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?', ['closed', now(), $order['id']]);
                    Database::execute('UPDATE ' . Database::table('recharges') . ' SET audit_remark = ?, updated_at = ? WHERE order_id = ?', ['支付创建失败：' . text_limit($e->getMessage(), 230), now(), $order['id']]);
                } catch (\Throwable $ignored) {
                    // The original payment error is more useful to the user here.
                }
            }
            set_flash('error', '充值订单创建失败：' . $e->getMessage());
            $this->redirect('m/recharge');
        }
        $this->redirect('m/orders');
    }

    public function cards()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $service = new RedeemCardService();
        $this->mobileView('cards', [
            'title' => '卡密兑换',
            'records' => $service->recentForUser(Auth::id(), 20),
            'schemaReady' => $this->schemaReady([DatabaseUpgradeService::class, 'ensureRedeemCardSchema']),
        ]);
    }

    public function redeemCard()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $code = isset($_POST['code']) ? $_POST['code'] : '';
        try {
            $result = (new RedeemCardService())->redeem(Auth::id(), $code);
            set_flash('success', isset($result['message']) ? $result['message'] : '卡密兑换成功。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('m/cards');
    }

    public function closeOrder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['orders'], '订单关闭', true)) {
            $this->redirect('m/orders');
        }

        $orderNo = trim((string) (isset($_POST['order_no']) ? $_POST['order_no'] : ''));
        $order = $orderNo !== ''
            ? $this->safeRow('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? AND user_id = ? LIMIT 1', [$orderNo, Auth::id()])
            : null;
        if (!$order) {
            set_flash('error', '订单不存在或无权操作。');
            $this->redirect('m/orders');
        }
        if ((isset($order['status']) ? $order['status'] : '') !== 'pending') {
            set_flash('error', '当前订单状态不可关闭。');
            $this->redirect('m/orders');
        }
        if (!in_array(isset($order['payment_method']) ? $order['payment_method'] : '', ['manual', 'alipay'], true)) {
            set_flash('error', '当前支付方式不支持手动关闭。');
            $this->redirect('m/orders');
        }

        try {
            Database::begin();
            Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?', ['closed', now(), $order['id']]);
            if ((isset($order['type']) ? $order['type'] : '') === 'recharge' && $this->mobileTableExists('recharges')) {
                Database::execute('UPDATE ' . Database::table('recharges') . ' SET audit_remark = ?, updated_at = ? WHERE order_id = ?', ['用户已主动关闭订单', now(), $order['id']]);
            }
            Database::commit();
            set_flash('success', '订单已关闭。');
        } catch (\Throwable $e) {
            Database::rollBack();
            set_flash('error', '关闭失败：' . $e->getMessage());
        }
        $this->redirect('m/orders');
    }

    public function packages()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $this->schemaReady([DatabaseUpgradeService::class, 'ensureMarketingSchema']);
        $user = $this->currentUser();
        $schemaReady = $this->mobileTablesReady(['packages'], '套餐升级');
        $packages = $schemaReady ? (new Package())->enabled() : [];
        $payments = $this->mobilePayments();
        $coupons = [];
        try {
            $coupons = $this->mobileTableExists('coupons') ? (new Coupon())->activeList() : [];
        } catch (\Throwable $e) {
            $coupons = [];
        }
        foreach ($packages as &$package) {
            $package['display_price'] = $this->mobilePackageDisplayPrice($user, $package);
            $package['features'] = $this->mobilePackageFeatures($package);
            $package['is_current'] = !empty($user['package_id']) && (int) $user['package_id'] === (int) $package['id'];
        }
        unset($package);
        $this->mobileView('packages', [
            'title' => '套餐升级',
            'user' => $user,
            'packages' => $packages,
            'payments' => $payments,
            'coupons' => $coupons,
            'schemaReady' => $schemaReady,
        ]);
    }

    public function buyPackage()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        try {
            $result = (new PackageService())->buy(
                Auth::id(),
                (int) (isset($_POST['package_id']) ? $_POST['package_id'] : 0),
                isset($_POST['payment_method']) ? (string) $_POST['payment_method'] : 'balance',
                isset($_POST['coupon_code']) ? $_POST['coupon_code'] : ''
            );
            if (!empty($result['mode']) && $result['mode'] === 'paid') {
                set_flash('success', '套餐购买成功。');
            } elseif (!empty($result['gateway']['redirect'])) {
                $_SESSION['alipay_qr'][$result['order']['order_no']] = isset($result['gateway']['qr_code']) ? $result['gateway']['qr_code'] : '';
                $this->redirect('pay/alipay/' . $result['order']['order_no']);
            } else {
                set_flash('success', isset($result['gateway']['message']) ? $result['gateway']['message'] : '套餐订单已创建，请继续完成支付。');
            }
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('m/packages');
    }

    public function apiConsole()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $schemaReady = $this->mobileTablesReady(['users', 'api_logs', 'api_apps', 'packages'], 'API 管理');
        $user = $this->mobileApiUser();
        $allowed = $schemaReady ? $this->mobileApiAllowed($user) : false;
        $apiAppService = new ApiAppService();
        $logs = ($schemaReady && $allowed)
            ? $apiAppService->logsForUser((int) $user['id'], 30)
            : [];
        $oneTimeToken = isset($_SESSION['api_app_plain_token']) && is_array($_SESSION['api_app_plain_token'])
            ? $_SESSION['api_app_plain_token']
            : null;
        unset($_SESSION['api_app_plain_token']);
        $this->mobileView('api', [
            'title' => 'API 管理',
            'user' => $user,
            'logs' => $logs,
            'endpoints' => $this->mobileApiEndpoints(),
            'sharexConfig' => $this->mobileSharexConfigPayload($user),
            'picgoConfig' => $this->mobilePicgoConfigPayload($user),
            'apiApps' => $schemaReady ? $apiAppService->appsWithStatsForUser((int) $user['id']) : [],
            'apiScopes' => $apiAppService->scopeLabels(),
            'apiAppOneTimeToken' => $oneTimeToken,
            'apiUsageSummary' => $schemaReady ? $apiAppService->usageSummaryForUser((int) $user['id']) : [],
            'apiAppService' => $apiAppService,
            'allowed' => $allowed,
            'schemaReady' => $schemaReady,
        ]);
    }

    public function resetApiToken()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['users'], 'API Token', true)) {
            $this->redirect('m/api');
        }
        $token = bin2hex(random_bytes(24));
        $hasTokenHash = $this->mobileColumnExists('users', 'api_token_hash');
        $data = [
            'api_token = ?',
            'updated_at = ?',
        ];
        $params = [
            $hasTokenHash ? CryptoService::encrypt($token) : $token,
            now(),
        ];
        if ($hasTokenHash) {
            $data[] = 'api_token_hash = ?';
            $params[] = hash('sha256', $token);
        }
        $params[] = (int) Auth::id();
        try {
            Database::execute('UPDATE ' . Database::table('users') . ' SET ' . implode(',', $data) . ' WHERE id = ?', $params);
            set_flash('success', 'API Token 已重置，请同步更新 PicGo、ShareX 或脚本配置。');
        } catch (\Throwable $e) {
            set_flash('error', 'API Token 重置失败：' . $this->mobileSchemaHint($e->getMessage(), 'API 管理'));
        }
        $this->redirect('m/api');
    }

    public function alerts()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $schemaReady = $this->mobileTablesReady(['monitor_servers', 'monitor_alerts'], '监控告警');
        if (!$schemaReady) {
            $this->mobileView('alerts', [
                'title' => '监控告警',
                'alerts' => [],
                'servers' => [],
                'stats' => ['total' => 0, 'unread' => 0, 'read' => 0, 'resolved' => 0],
                'filters' => ['status' => '', 'level' => '', 'server_id' => 0],
                'schemaReady' => false,
            ]);
            return;
        }

        $status = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
        $level = isset($_GET['level']) ? trim((string) $_GET['level']) : '';
        $serverId = max(0, (int) (isset($_GET['server_id']) ? $_GET['server_id'] : 0));
        if (!in_array($status, ['', 'unread', 'read', 'resolved'], true)) {
            $status = '';
        }
        if (!in_array($level, ['', 'info', 'warning', 'danger'], true)) {
            $level = '';
        }

        $where = ['s.user_id = ?', 's.monitor_type IN (?, ?)'];
        $params = [(int) Auth::id(), 'ssh', 'agent'];
        if ($status !== '') {
            $where[] = 'a.status = ?';
            $params[] = $status;
        }
        if ($level !== '') {
            $where[] = 'a.level = ?';
            $params[] = $level;
        }
        if ($serverId > 0) {
            $where[] = 'a.server_id = ?';
            $params[] = $serverId;
        }

        $alerts = $this->safeRows(
            'SELECT a.*, s.name AS server_name, s.monitor_type FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE ' . implode(' AND ', $where) . " ORDER BY FIELD(a.status, 'unread', 'read', 'resolved'), a.id DESC LIMIT 100",
            $params
        );
        $servers = $this->safeRows(
            'SELECT id, name, monitor_type FROM ' . Database::table('monitor_servers') . ' WHERE user_id = ? AND monitor_type IN (?, ?) ORDER BY name ASC, id DESC',
            [(int) Auth::id(), 'ssh', 'agent']
        );
        $this->mobileView('alerts', [
            'title' => '监控告警',
            'alerts' => $alerts,
            'servers' => $servers,
            'stats' => $this->mobileAlertStats((int) Auth::id()),
            'filters' => ['status' => $status, 'level' => $level, 'server_id' => $serverId],
            'schemaReady' => true,
        ]);
    }

    public function markAlertRead()
    {
        $this->updateMobileAlertStatus('read', null, '告警已标记为已读。');
    }

    public function resolveAlert()
    {
        $this->updateMobileAlertStatus('resolved', now(), '告警已标记为已处理。');
    }

    public function notifications()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $schemaReady = $this->mobileTablesReady(['notifications'], '消息通知');
        $this->mobileView('notifications', [
            'title' => '消息通知',
            'notifications' => $schemaReady ? $this->recentNotifications((int) Auth::id(), 80) : [],
            'schemaReady' => $schemaReady,
        ]);
    }

    public function readNotifications()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['notifications'], '消息通知', true)) {
            $this->redirect('m/notifications');
        }
        try {
            Database::execute('UPDATE ' . Database::table('notifications') . ' SET is_read = 1, read_at = ? WHERE user_id = ?', [now(), (int) Auth::id()]);
            set_flash('success', '消息已全部标记为已读。');
        } catch (\Throwable $e) {
            set_flash('error', '消息处理失败：' . $this->mobileSchemaHint($e->getMessage(), '消息通知'));
        }
        $this->redirect('m/notifications');
    }

    public function profile()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $this->mobileView('profile', [
            'title' => '账户',
            'user' => $this->currentUser(),
        ]);
    }

    public function editProfile()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $this->mobileView('profile_edit', [
            'title' => '资料设置',
            'user' => $this->mobileApiUser(),
        ]);
    }

    public function saveProfile()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $user = $this->currentUser();
        $nickname = trim((string) (isset($_POST['nickname']) ? $_POST['nickname'] : ''));
        $email = trim((string) (isset($_POST['email']) ? $_POST['email'] : ''));
        $apiAllowedIps = $this->mobileNormalizeApiAllowedIps(isset($_POST['api_allowed_ips']) ? $_POST['api_allowed_ips'] : '');
        if ($nickname === '' || !Validator::email($email)) {
            set_flash('error', '昵称或邮箱格式不正确。');
            $this->redirect('m/profile/edit');
        }
        if ($apiAllowedIps === false) {
            set_flash('error', 'API 白名单格式不正确。每行填写一个 IPv4 或 IPv6，留空表示不限制。');
            $this->redirect('m/profile/edit');
        }
        $userModel = new User();
        if ($userModel->existsEmail($email, (int) $user['id'])) {
            set_flash('error', '邮箱已被占用。');
            $this->redirect('m/profile/edit');
        }
        $data = [
            'nickname' => $nickname,
            'email' => $email,
            'avatar' => $this->mobileCleanPublicImageUrl(isset($_POST['avatar']) ? $_POST['avatar'] : ''),
            'updated_at' => now(),
        ];
        if ($this->schemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'])) {
            $data['api_allowed_ips'] = $apiAllowedIps;
        }
        try {
            $userModel->update((int) $user['id'], $data);
            set_flash('success', '资料已更新。');
        } catch (\Throwable $e) {
            set_flash('error', '资料保存失败：' . $this->mobileSchemaHint($e->getMessage(), '账户资料'));
            $this->redirect('m/profile/edit');
        }
        $this->redirect('m/profile');
    }

    public function password()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $this->mobileView('password', [
            'title' => '修改密码',
        ]);
    }

    public function updatePassword()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $user = $this->currentUser();
        $old = isset($_POST['old_password']) ? $_POST['old_password'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
        if (!password_verify($old, isset($user['password']) ? $user['password'] : '') || !Validator::password($password) || $password !== $confirm) {
            set_flash('error', '原密码错误，或新密码不符合要求。');
            $this->redirect('m/password');
        }
        try {
            (new User())->update((int) Auth::id(), ['password' => password_hash($password, PASSWORD_DEFAULT), 'updated_at' => now()]);
            set_flash('success', '密码已修改，请妥善保存新密码。');
        } catch (\Throwable $e) {
            set_flash('error', '密码修改失败：' . $this->mobileSchemaHint($e->getMessage(), '账户安全'));
            $this->redirect('m/password');
        }
        $this->redirect('m/profile');
    }

    public function menu()
    {
        $this->requireLogin();
        $this->prepareSchemas();
        $user = $this->currentUser();
        $this->mobileView('menu', [
            'title' => '功能中心',
            'user' => $user,
            'stats' => $this->dashboardStats($user),
        ]);
    }

    public function saveTeam()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        $service = new TeamSpaceService();
        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        try {
            if ($id > 0) {
                $team = $service->updateTeam($id, (int) Auth::id(), $_POST);
                $id = $team ? (int) $team['id'] : $id;
                set_flash('success', '团队信息已更新。');
            } else {
                $id = $service->createTeam((int) Auth::id(), $_POST);
                set_flash('success', '团队已创建。');
            }
            clear_old();
            $this->redirect('m/teams?id=' . $id);
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
            $this->redirect($id > 0 ? 'm/teams?id=' . $id : 'm/teams');
        }
    }

    public function deleteTeam()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        try {
            (new TeamSpaceService())->deleteTeam((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '团队已删除。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('m/teams');
    }

    public function createTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->createInvite($teamId, (int) Auth::id(), $_POST);
            set_flash('success', '邀请已创建。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'm/teams?id=' . $teamId : 'm/teams');
    }

    public function cancelTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->cancelInvite((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '邀请已取消。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'm/teams?id=' . $teamId : 'm/teams');
    }

    public function acceptTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        try {
            $teamId = (new TeamSpaceService())->acceptInvite((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '已加入团队。');
            $this->redirect('m/teams?id=' . (int) $teamId);
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
            $this->redirect('m/teams');
        }
    }

    public function declineTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        try {
            (new TeamSpaceService())->declineInvite((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '邀请已拒绝。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('m/teams');
    }

    public function updateTeamMember()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->updateMember($teamId, (int) (isset($_POST['user_id']) ? $_POST['user_id'] : 0), (int) Auth::id(), $_POST);
            set_flash('success', '成员权限已更新。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'm/teams?id=' . $teamId : 'm/teams');
    }

    public function removeTeamMember()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->removeMember($teamId, (int) (isset($_POST['user_id']) ? $_POST['user_id'] : 0), (int) Auth::id());
            set_flash('success', '成员已移除。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'm/teams?id=' . $teamId : 'm/teams');
    }

    public function leaveTeam()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTeamSpaceReady()) {
            $this->redirect('m/teams');
        }
        try {
            (new TeamSpaceService())->leaveTeam((int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0), (int) Auth::id());
            set_flash('success', '已退出团队。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('m/teams');
    }

    public function createFolder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['files', 'file_folders'], '个人网盘', true)) {
            $this->redirect('m/netdisk');
        }
        if (!$this->mobileNetdiskAllowed()) {
            $this->redirect('m');
        }

        $userId = (int) Auth::id();
        $parentId = max(0, (int) (isset($_POST['parent_id']) ? $_POST['parent_id'] : 0));
        $name = text_limit(trim((string) (isset($_POST['name']) ? $_POST['name'] : '')), 120);

        if ($name === '') {
            set_flash('error', '请填写文件夹名称。');
            $this->redirect($this->mobileNetdiskBack($parentId));
        }
        if (!$this->folderBelongsToUser($parentId, $userId)) {
            set_flash('error', '父级文件夹不存在或无权访问。');
            $this->redirect('m/netdisk');
        }

        try {
            (new Folder())->create([
                'user_id' => $userId,
                'parent_id' => $parentId,
                'name' => $name,
                'path' => '',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            set_flash('success', '文件夹已创建。');
        } catch (\Throwable $e) {
            set_flash('error', '创建文件夹失败：' . $this->mobileSchemaHint($e->getMessage(), '个人网盘'));
        }
        $this->redirect($this->mobileNetdiskBack($parentId));
    }

    public function deleteFolder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['files', 'file_folders', 'file_recycle_bin'], '个人网盘', true)) {
            $this->redirect('m/netdisk');
        }
        if (!$this->mobileNetdiskAllowed()) {
            $this->redirect('m');
        }

        $userId = (int) Auth::id();
        $folderId = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        try {
            $folder = (new Folder())->find($folderId);
        } catch (\Throwable $e) {
            set_flash('error', '读取文件夹失败：' . $this->mobileSchemaHint($e->getMessage(), '个人网盘'));
            $this->redirect('m/netdisk');
        }
        if (!$folder || (int) $folder['user_id'] !== $userId) {
            set_flash('error', '文件夹不存在或无权删除。');
            $this->redirect('m/netdisk');
        }

        $parentId = (int) (isset($folder['parent_id']) ? $folder['parent_id'] : 0);
        $childCount = $this->safeRow('SELECT COUNT(*) AS c FROM ' . Database::table('file_folders') . ' WHERE user_id = ? AND parent_id = ?', [$userId, $folderId]);
        if ($childCount && (int) $childCount['c'] > 0) {
            set_flash('error', '该文件夹还有子文件夹，请先处理子文件夹。');
            $this->redirect($this->mobileNetdiskBack($parentId));
        }

        $files = $this->safeRows('SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? AND folder_id = ?', [$userId, $folderId]);
        try {
            foreach ($files as $file) {
                (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
            }
            Database::execute('DELETE FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ?', [$folderId, $userId]);
            (new FileLogService())->log($userId, null, 'folder_delete', $folder['name'], 0, ['folder_id' => $folderId, 'files' => count($files), 'mobile' => true]);
            set_flash('success', '文件夹已删除，里面的文件已移入回收站。');
        } catch (\Throwable $e) {
            set_flash('error', '删除失败：' . $e->getMessage());
        }
        $this->redirect($this->mobileNetdiskBack($parentId));
    }

    public function deleteFile()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['files', 'file_recycle_bin'], '文件删除', true)) {
            $this->redirect($this->mobileNetdiskBack(isset($_POST['current_folder_id']) ? (int) $_POST['current_folder_id'] : 0));
        }
        if (!$this->mobileNetdiskAllowed()) {
            $this->redirect('m');
        }

        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        try {
            $file = (new FileItem())->find($id);
        } catch (\Throwable $e) {
            set_flash('error', '读取文件失败：' . $this->mobileSchemaHint($e->getMessage(), '文件管理'));
            $this->redirect($this->mobileNetdiskBack(max(0, (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0))));
        }
        $folderId = $file ? (int) (isset($file['folder_id']) ? $file['folder_id'] : 0) : max(0, (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0));
        if (!$file || (int) $file['user_id'] !== (int) Auth::id()) {
            set_flash('error', '文件不存在或无权删除。');
            $this->redirect($this->mobileNetdiskBack($folderId));
        }

        try {
            (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
            set_flash('success', '文件已移入回收站。');
        } catch (\Throwable $e) {
            set_flash('error', '删除失败：' . $e->getMessage());
        }
        $this->redirect($this->mobileNetdiskBack($folderId));
    }

    public function saveRepository()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['file_repositories'], '分享仓库', true)) {
            $this->redirect('m/repository');
        }
        if (!$this->mobileNetdiskAllowed()) {
            $this->redirect('m');
        }

        $service = new RepositoryService();
        $user = $this->currentUser();
        $repo = null;
        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        $payload = $this->mobileRepositoryPayload();

        try {
            if ($id > 0) {
                $repo = $service->findUserRepository((int) $user['id'], $id);
                if (!$repo) {
                    throw new \RuntimeException('分享仓库不存在或无权编辑。');
                }
                $service->saveRepository($repo, $payload);
                unset($_SESSION['repository_auth'][$repo['id']]);
                clear_old();
                set_flash('success', '分享仓库已保存。');
            } else {
                Database::begin();
                $repo = $service->createRepository($user, $payload);
                $service->saveRepository($repo, $payload);
                Database::commit();
                clear_old();
                set_flash('success', '分享仓库已创建。');
            }
        } catch (\Throwable $e) {
            Database::rollBack();
            remember_old();
            set_flash('error', '分享仓库保存失败：' . $this->mobileSchemaHint($e->getMessage(), '分享仓库'));
        }

        $this->redirect('m/repository');
    }

    public function deleteRepository()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['file_repositories'], '分享仓库', true)) {
            $this->redirect('m/repository');
        }
        if (!$this->mobileNetdiskAllowed()) {
            $this->redirect('m');
        }

        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        $service = new RepositoryService();
        try {
            $repo = $service->findUserRepository((int) Auth::id(), $id);
            if (!$repo) {
                throw new \RuntimeException('分享仓库不存在或无权删除。');
            }
            $service->deleteRepository($repo);
            unset($_SESSION['repository_auth'][$repo['id']]);
            set_flash('success', '分享仓库已删除，原网盘文件仍然保留。');
        } catch (\Throwable $e) {
            set_flash('error', '删除失败：' . $this->mobileSchemaHint($e->getMessage(), '分享仓库'));
        }
        $this->redirect('m/repository');
    }

    public function saveSubsite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileSubsiteReady()) {
            $this->redirect('m/subsites');
        }

        $service = new SubsiteService();
        $user = $this->currentUser();
        $existing = null;
        if (!empty($_POST['id'])) {
            $existing = $service->findUserSubsite((int) $_POST['id'], (int) $user['id']);
            if (!$existing) {
                set_flash('error', '分站不存在或无权编辑。');
                $this->redirect('m/subsites');
            }
        }

        try {
            $service->saveForUser($user, $_POST, $existing);
            clear_old();
            set_flash('success', $existing ? '分站已更新。' : '分站已创建。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
        }
        $this->redirect('m/subsites');
    }

    public function checkSubsiteDomain()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileSubsiteReady()) {
            $this->redirect('m/subsites');
        }

        $service = new SubsiteService();
        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        $subsite = $service->findUserSubsite($id, (int) Auth::id());
        if (!$subsite) {
            set_flash('error', '分站不存在或无权检测。');
            $this->redirect('m/subsites');
        }

        try {
            $diagnostic = $service->domainDiagnostic($subsite);
            $service->saveDomainDiagnostic($id, $diagnostic);
            $diagnostic['site'] = [
                'id' => $subsite['id'],
                'name' => $subsite['name'],
                'platform_domain' => $subsite['platform_domain'],
                'custom_domain' => $subsite['custom_domain'],
            ];
            set_flash('subsite_domain_diagnostic', $diagnostic);
            set_flash(!empty($diagnostic['ok']) ? 'success' : 'error', !empty($diagnostic['ok']) ? '域名接入检测通过。' : '检测完成，仍有步骤未通过。');
        } catch (\Throwable $e) {
            set_flash('error', '域名检测失败：' . $e->getMessage());
        }
        $this->redirect('m/subsites');
    }

    public function deleteSubsite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileSubsiteReady()) {
            $this->redirect('m/subsites');
        }

        try {
            $deleted = (new SubsiteService())->deleteForUser((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash($deleted ? 'success' : 'error', $deleted ? '分站已删除。' : '分站不存在或删除失败。');
        } catch (\Throwable $e) {
            set_flash('error', '删除失败：' . $e->getMessage());
        }
        $this->redirect('m/subsites');
    }

    public function saveServer()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['monitor_servers'], '服务器管家', true)) {
            $this->redirect('m/servers');
        }
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }

        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        $existing = $id > 0 ? $this->mobileServerForUser($id) : null;
        if ($id > 0 && !$existing) {
            set_flash('error', '服务器不存在或无权编辑。');
            $this->redirect('m/servers');
        }
        $limit = $this->mobileServerLimit();
        if (!$existing && $limit > 0 && $this->mobileServerCount() >= $limit) {
            set_flash('error', '当前套餐最多可保存 ' . $limit . ' 台服务器，请升级后再添加。');
            $this->redirect('m/servers');
        }

        $data = $this->mobileServerPayload($existing);
        if ($data['name'] === '') {
            set_flash('error', '请填写服务器名称。');
            $this->redirect($existing ? 'm/servers/create?id=' . (int) $existing['id'] : 'm/servers/create');
        }
        if ($data['monitor_type'] === 'ssh' && ($data['ssh_host'] === '' || $data['ssh_username'] === '')) {
            set_flash('error', 'SSH 模式请填写主机和用户名。');
            $this->redirect($existing ? 'm/servers/create?id=' . (int) $existing['id'] : 'm/servers/create');
        }
        if ($data['monitor_type'] === 'ssh' && !$existing && empty($data['ssh_password']) && empty($data['ssh_private_key'])) {
            set_flash('error', '请填写 SSH 密码，或粘贴 SSH 私钥。');
            $this->redirect('m/servers/create');
        }
        if ($data['monitor_type'] === 'agent' && !preg_match('/^[A-Za-z0-9_-]{24,128}$/', $data['agent_token'])) {
            set_flash('error', 'Agent Token 只能包含字母、数字、下划线或短横线，长度 24-128 位。');
            $this->redirect($existing ? 'm/servers/create?id=' . (int) $existing['id'] : 'm/servers/create');
        }
        if ($data['monitor_type'] === 'ssh' && $this->mobileBlockedSshHost($data['ssh_host'])) {
            set_flash('error', 'SSH 主机不能填写本机、回环地址或云厂商元数据地址。');
            $this->redirect($existing ? 'm/servers/create?id=' . (int) $existing['id'] : 'm/servers/create');
        }

        try {
            if ($existing) {
                $set = [];
                $params = [];
                foreach ($data as $key => $value) {
                    $set[] = $key . ' = ?';
                    $params[] = $value;
                }
                $params[] = (int) $existing['id'];
                Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
                set_flash('success', '服务器信息已更新。');
            } else {
                $data['created_at'] = now();
                $columns = array_keys($data);
                Database::execute(
                    'INSERT INTO ' . Database::table('monitor_servers') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')',
                    array_values($data)
                );
                set_flash('success', '服务器已保存，建议立即采集一次状态。');
            }
        } catch (\Throwable $e) {
            set_flash('error', '保存服务器失败：' . $this->mobileSchemaHint($e->getMessage(), '服务器管家'));
            $this->redirect($existing ? 'm/servers/create?id=' . (int) $existing['id'] : 'm/servers/create');
        }
        $this->redirect('m/servers');
    }

    public function collectServer()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $returnTo = trim((string) (isset($_POST['return_to']) ? $_POST['return_to'] : ''));
        if ($returnTo === '') {
            $returnTo = 'm/servers';
        }
        if (!$this->mobileTablesReady(['monitor_servers'], '服务器管家', true)) {
            $this->redirect($returnTo);
        }
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect($returnTo);
        }

        $server = $this->mobileServerForUser((int) (isset($_POST['id']) ? $_POST['id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权操作。');
            $this->redirect($returnTo);
        }

        try {
            $probeStats = ['total' => 0, 'down' => 0];
            if ((isset($server['monitor_type']) ? $server['monitor_type'] : '') === 'agent' && trim((string) (isset($server['agent_url']) ? $server['agent_url'] : '')) === '') {
                $probeStats = (new ServiceProbeService())->collectForServer($server, true);
                $message = 'Agent 主动上报模式无需手动拉取，请等待目标服务器上报。';
                if (!empty($probeStats['total'])) {
                    $message .= ' 已同步检测探针 ' . (int) $probeStats['total'] . ' 个。';
                }
                set_flash('success', $message);
                $this->redirect($returnTo);
            }

            (new MonitorService())->collect($server);
            $probeStats = (new ServiceProbeService())->collectForServer($server, true);
            $message = '服务器状态已刷新。';
            if (!empty($probeStats['total'])) {
                $message .= ' 探针 ' . (int) $probeStats['total'] . ' 个，异常 ' . (int) $probeStats['down'] . ' 个。';
            }
            set_flash('success', $message);
        } catch (\Throwable $e) {
            set_flash('error', $this->mobileConnectionHint($e->getMessage()));
        }
        $this->redirect($returnTo);
    }

    public function deleteServer()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['monitor_servers'], '服务器管家', true)) {
            $this->redirect('m/servers');
        }
        if (!$this->mobileServerOpsReady() || !$this->mobileServerOpsAllowed()) {
            $this->redirect('m/servers');
        }

        $server = $this->mobileServerForUser((int) (isset($_POST['id']) ? $_POST['id'] : 0));
        if (!$server) {
            set_flash('error', '服务器不存在或无权删除。');
            $this->redirect('m/servers');
        }

        try {
            Database::begin();
            if ($this->mobileTableExists('server_service_checks')) {
                $probeIds = Database::fetchAll('SELECT id FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
                if ($this->mobileTableExists('server_service_check_logs')) {
                    foreach ($probeIds as $probe) {
                        Database::execute('DELETE FROM ' . Database::table('server_service_check_logs') . ' WHERE check_id = ?', [$probe['id']]);
                    }
                }
                Database::execute('DELETE FROM ' . Database::table('server_service_checks') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
            }
            if ($this->mobileTableExists('monitor_metrics')) {
                Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$server['id']]);
            }
            if ($this->mobileTableExists('monitor_alerts')) {
                Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$server['id']]);
            }
            if ($this->mobileTableExists('server_command_logs')) {
                Database::execute('DELETE FROM ' . Database::table('server_command_logs') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
            }
            if ($this->mobileTableExists('server_ssh_sessions')) {
                Database::execute('DELETE FROM ' . Database::table('server_ssh_sessions') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
            }
            if ($this->mobileTableExists('server_monitor_pages')) {
                Database::execute('DELETE FROM ' . Database::table('server_monitor_pages') . ' WHERE server_id = ? AND user_id = ?', [$server['id'], Auth::id()]);
            }
            Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND user_id = ? AND monitor_type IN (?, ?)', [$server['id'], Auth::id(), 'ssh', 'agent']);
            Database::commit();
            set_flash('success', '服务器已删除，相关监控与终端记录已清理。');
        } catch (\Throwable $e) {
            Database::rollBack();
            set_flash('error', '删除失败：' . $e->getMessage());
        }
        $this->redirect('m/servers');
    }

    protected function prepareSchemas()
    {
        $callbacks = [
            [DatabaseUpgradeService::class, 'ensureUserPermissionSchema'],
            [DatabaseUpgradeService::class, 'ensureApiSecuritySchema'],
            [DatabaseUpgradeService::class, 'ensureApiAppSchema'],
            [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
            [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
            [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            [DatabaseUpgradeService::class, 'ensureSubsiteSchema'],
            [DatabaseUpgradeService::class, 'ensureTeamSpaceSchema'],
        ];
        foreach ($callbacks as $callback) {
            $this->schemaReady($callback);
        }
    }

    protected function currentUser()
    {
        try {
            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [Auth::id()]);
            if ($user) {
                return $user;
            }
        } catch (\Throwable $e) {
            // Keep the mobile shell usable even when a schema repair is pending.
        }
        $fallback = Auth::user();
        return is_array($fallback) ? $fallback : [];
    }

    protected function dashboardStats(array $user)
    {
        $userId = (int) $user['id'];
        $usedStorage = (int) (isset($user['used_storage']) ? $user['used_storage'] : 0);
        $totalStorage = (int) (isset($user['total_storage']) ? $user['total_storage'] : 0);
        return [
            'files' => $this->safeCount('files', 'user_id = ?', [$userId]),
            'images' => $this->safeCount('files', 'user_id = ? AND file_type = ?', [$userId, 'image']),
            'netdisk' => $this->safeCount('files', 'user_id = ? AND file_type = ?', [$userId, 'file']),
            'repositories' => $this->safeCount('file_repositories', 'user_id = ?', [$userId]),
            'servers' => $this->safeCount('monitor_servers', 'user_id = ? AND monitor_type IN (\'ssh\',\'agent\')', [$userId]),
            'subsites' => $this->safeCount('subsites', 'user_id = ?', [$userId]),
            'teams' => $this->safeCount('team_members', 'user_id = ?', [$userId]),
            'orders' => $this->safeCount('orders', 'user_id = ?', [$userId]),
            'notifications' => $this->safeCount('notifications', 'user_id = ? AND is_read = 0', [$userId]),
            'storage_used' => $usedStorage,
            'storage_total' => $totalStorage,
            'storage_percent' => $totalStorage > 0 ? min(100, round($usedStorage / $totalStorage * 100, 1)) : 0,
        ];
    }

    protected function recentFiles($userId, $limit = 8)
    {
        return $this->safeRows(
            'SELECT id, original_name, file_type, file_size, file_url, created_at FROM ' . Database::table('files') . ' WHERE user_id = ? ORDER BY id DESC' . Database::limitClause($limit, 1, 30),
            [(int) $userId]
        );
    }

    protected function filesByType($userId, $type = '', $limit = 30)
    {
        if ($type !== '') {
            return $this->safeRows('SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? AND file_type = ? ORDER BY id DESC' . Database::limitClause($limit, 1, 80), [(int) $userId, $type]);
        }
        return $this->safeRows('SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? ORDER BY id DESC' . Database::limitClause($limit, 1, 80), [(int) $userId]);
    }

    protected function filesForFolder($userId, $folderId, $limit = 50)
    {
        return $this->safeRows(
            'SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? AND folder_id = ? ORDER BY id DESC' . Database::limitClause($limit, 1, 100),
            [(int) $userId, (int) $folderId]
        );
    }

    protected function foldersForParent($userId, $parentId, $limit = 60)
    {
        return $this->safeRows(
            'SELECT * FROM ' . Database::table('file_folders') . ' WHERE user_id = ? AND parent_id = ? ORDER BY name ASC' . Database::limitClause($limit, 1, 100),
            [(int) $userId, (int) $parentId]
        );
    }

    protected function usage($userId, $type = '')
    {
        $where = 'user_id = ?';
        $params = [(int) $userId];
        if ($type !== '') {
            $where .= ' AND file_type = ?';
            $params[] = $type;
        }
        try {
            $row = Database::fetch('SELECT COUNT(*) AS c, COALESCE(SUM(file_size),0) AS s FROM ' . Database::table('files') . ' WHERE ' . $where, $params);
            return ['count' => $row ? (int) $row['c'] : 0, 'size' => $row ? (int) $row['s'] : 0];
        } catch (\Throwable $e) {
            return ['count' => 0, 'size' => 0];
        }
    }

    protected function mobileUploadLimitSummary(UploadLimitService $service, $userId, $scope)
    {
        $scope = $scope === 'image' ? 'image' : 'file';
        try {
            $batchLimit = $scope === 'image' ? $service->imageBatchLimit() : $service->fileBatchLimit();
            $dailyLimit = $scope === 'image' ? $service->imageDailyLimit() : $service->fileDailyLimit();
            $concurrency = $service->maxConcurrency();
        } catch (\Throwable $e) {
            $batchLimit = $scope === 'image' ? 20 : 10;
            $dailyLimit = 0;
            $concurrency = 2;
        }
        try {
            $usedToday = $service->todayCount((int) $userId, $scope);
        } catch (\Throwable $e) {
            $usedToday = 0;
        }
        $user = $this->currentUser();
        $package = null;
        if (!empty($user['package_id']) && $this->mobileTableExists('packages')) {
            $package = $this->safeRow('SELECT single_file_limit FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [(int) $user['package_id']]);
        }
        $singleLimit = $package && isset($package['single_file_limit']) ? (int) $package['single_file_limit'] : 0;
        $totalStorage = isset($user['total_storage']) ? (int) $user['total_storage'] : 0;
        $usedStorage = isset($user['used_storage']) ? (int) $user['used_storage'] : 0;
        return [
            'scope' => $scope,
            'batch' => $batchLimit,
            'daily' => $dailyLimit,
            'used_today' => $usedToday,
            'remaining_today' => $dailyLimit > 0 ? max(0, $dailyLimit - $usedToday) : null,
            'concurrency' => $concurrency,
            'single_file_limit' => $singleLimit,
            'storage_total' => $totalStorage,
            'storage_used' => $usedStorage,
            'storage_remaining' => $totalStorage > 0 ? max(0, $totalStorage - $usedStorage) : null,
        ];
    }

    protected function recentNotifications($userId, $limit = 5)
    {
        return $this->safeRows(
            'SELECT * FROM ' . Database::table('notifications') . ' WHERE user_id = ? ORDER BY id DESC' . Database::limitClause($limit, 1, 20),
            [(int) $userId]
        );
    }

    protected function mobileNetdiskAllowed()
    {
        if (!$this->mobileTablesReady(['users'], '网盘权限', true)) {
            return false;
        }
        try {
            if ((new PermissionService())->featureAllowed($this->currentUser(), 'netdisk')) {
                return true;
            }
            set_flash('error', (new PermissionService())->message('netdisk'));
        } catch (\Throwable $e) {
            set_flash('error', '网盘权限检查失败：' . $e->getMessage());
        }
        return false;
    }

    protected function mobileRepositoryPayload()
    {
        return [
            'title' => isset($_POST['title']) ? $_POST['title'] : '',
            'slug' => isset($_POST['slug']) ? $_POST['slug'] : '',
            'description' => isset($_POST['description']) ? $_POST['description'] : '',
            'cover_image' => isset($_POST['cover_image']) ? $_POST['cover_image'] : '',
            'tags' => isset($_POST['tags']) ? $_POST['tags'] : '',
            'access_type' => isset($_POST['access_type']) ? $_POST['access_type'] : 'public',
            'password' => isset($_POST['password']) ? $_POST['password'] : '',
            'expire_at' => isset($_POST['expire_at']) ? $_POST['expire_at'] : '',
            'max_views' => isset($_POST['max_views']) ? $_POST['max_views'] : 0,
            'max_downloads' => isset($_POST['max_downloads']) ? $_POST['max_downloads'] : 0,
            'ip_daily_view_limit' => isset($_POST['ip_daily_view_limit']) ? $_POST['ip_daily_view_limit'] : 0,
            'ip_daily_download_limit' => isset($_POST['ip_daily_download_limit']) ? $_POST['ip_daily_download_limit'] : 0,
            'allow_download' => isset($_POST['allow_download']) ? $_POST['allow_download'] : 0,
            'show_owner' => isset($_POST['show_owner']) ? $_POST['show_owner'] : 0,
            'status' => isset($_POST['status']) ? $_POST['status'] : 0,
        ];
    }

    protected function mobileRepositoryStats(array $repositories, RepositoryService $service)
    {
        $stats = [];
        foreach ($repositories as $repo) {
            if (empty($repo['id'])) {
                continue;
            }
            try {
                $stats[$repo['id']] = $service->stats($repo);
            } catch (\Throwable $e) {
                $stats[$repo['id']] = [
                    'items' => 0,
                    'public_items' => 0,
                    'private_items' => 0,
                    'logs' => 0,
                    'views' => (int) (isset($repo['view_count']) ? $repo['view_count'] : 0),
                    'downloads' => (int) (isset($repo['download_count']) ? $repo['download_count'] : 0),
                    'today_views' => 0,
                    'today_downloads' => 0,
                ];
            }
        }
        return $stats;
    }

    protected function mobileSubsiteReady()
    {
        if ($this->schemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'])) {
            return true;
        }
        set_flash('error', '分站数据结构未准备完成，请联系管理员执行数据库修复。');
        return false;
    }

    protected function mobileTeamSpaceReady()
    {
        if ($this->schemaReady([DatabaseUpgradeService::class, 'ensureTeamSpaceSchema'])) {
            return true;
        }
        set_flash('error', '团队空间数据表尚未准备完成，请进入后台系统维护执行数据库一键修复。');
        return false;
    }

    protected function mobileServerOpsReady()
    {
        if ($this->schemaReady([DatabaseUpgradeService::class, 'ensureServerOpsSchema'])) {
            return true;
        }
        set_flash('error', '服务器管家数据结构未准备完成，请联系管理员执行数据库修复。');
        return false;
    }

    protected function mobileServerOpsAllowed()
    {
        if (!$this->mobileTablesReady(['users'], '服务器管家权限', true)) {
            return false;
        }
        try {
            if ((new PermissionService())->featureAllowed($this->currentUser(), 'monitor')) {
                return true;
            }
            set_flash('error', (new PermissionService())->message('monitor'));
        } catch (\Throwable $e) {
            set_flash('error', '服务器管家权限检查失败：' . $e->getMessage());
        }
        return false;
    }

    protected function mobileServerForUser($id)
    {
        if ((int) $id <= 0) {
            return null;
        }
        if (!$this->mobileTableExists('monitor_servers')) {
            return null;
        }
        return $this->safeRow(
            'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? AND user_id = ? AND monitor_type IN (?, ?) LIMIT 1',
            [(int) $id, (int) Auth::id(), 'ssh', 'agent']
        );
    }

    protected function mobileServerCount()
    {
        return $this->safeCount('monitor_servers', 'user_id = ? AND monitor_type IN (\'ssh\',\'agent\')', [(int) Auth::id()]);
    }

    protected function mobileServerLimit()
    {
        return max(0, (int) setting('ssh_terminal_user_server_limit', '5'));
    }

    protected function mobileServerPayload(array $existing = null)
    {
        $monitorType = isset($_POST['monitor_type']) && $_POST['monitor_type'] === 'agent' ? 'agent' : 'ssh';
        $authType = isset($_POST['ssh_auth_type']) && $_POST['ssh_auth_type'] === 'key' ? 'key' : 'password';
        $host = trim((string) (isset($_POST['ssh_host']) ? $_POST['ssh_host'] : ''));
        $agentToken = trim((string) (isset($_POST['agent_token']) ? $_POST['agent_token'] : ''));
        if ($monitorType === 'agent' && $agentToken === '' && $existing && !empty($existing['agent_token'])) {
            $agentToken = $existing['agent_token'];
        }
        if ($monitorType === 'agent' && $agentToken === '') {
            $agentToken = bin2hex(random_bytes(24));
        }
        $data = [
            'user_id' => (int) Auth::id(),
            'monitor_type' => $monitorType,
            'name' => text_limit(trim((string) (isset($_POST['name']) ? $_POST['name'] : '')), 120, ''),
            'remark' => text_limit(trim((string) (isset($_POST['remark']) ? $_POST['remark'] : '')), 500, ''),
            'panel_url' => '',
            'api_key' => '',
            'panel_port' => 0,
            'server_ip' => text_limit(trim((string) (isset($_POST['server_ip']) ? $_POST['server_ip'] : $host)), 120, ''),
            'ssh_host' => text_limit($host, 180, ''),
            'ssh_port' => max(1, min(65535, (int) (isset($_POST['ssh_port']) ? $_POST['ssh_port'] : 22))),
            'ssh_username' => text_limit(trim((string) (isset($_POST['ssh_username']) ? $_POST['ssh_username'] : '')), 120, ''),
            'ssh_auth_type' => $authType,
            'agent_url' => text_limit(trim((string) (isset($_POST['agent_url']) ? $_POST['agent_url'] : ($existing && isset($existing['agent_url']) ? $existing['agent_url'] : ''))), 500, ''),
            'agent_token' => $agentToken,
            'group_name' => text_limit(trim((string) (isset($_POST['group_name']) ? $_POST['group_name'] : '个人服务器')), 120, ''),
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'frequency' => max(60, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 300)),
            'threshold_config' => json_encode([
                'cpu' => (float) (isset($_POST['cpu_threshold']) ? $_POST['cpu_threshold'] : 90),
                'memory' => (float) (isset($_POST['memory_threshold']) ? $_POST['memory_threshold'] : 90),
                'disk' => (float) (isset($_POST['disk_threshold']) ? $_POST['disk_threshold'] : 90),
            ], JSON_UNESCAPED_UNICODE),
            'status' => $existing && isset($existing['status']) ? $existing['status'] : 'unknown',
            'updated_at' => now(),
        ];
        foreach (['ssh_password', 'ssh_private_key', 'ssh_key_passphrase'] as $field) {
            $plain = (string) (isset($_POST[$field]) ? $_POST[$field] : '');
            if ($plain !== '') {
                $data[$field] = CryptoService::encrypt($plain);
            } elseif ($existing && isset($existing[$field])) {
                $data[$field] = $existing[$field];
            } else {
                $data[$field] = '';
            }
        }
        return $data;
    }

    protected function mobileBlockedSshHost($host)
    {
        $host = trim(strtolower((string) $host), " \t\n\r\0\x0B[]");
        if ($host === '' || in_array($host, ['localhost', 'localhost.localdomain'], true)) {
            return $host !== '';
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $host === '0.0.0.0'
                || $host === '::'
                || $host === '::1'
                || strpos($host, '127.') === 0
                || $host === '169.254.169.254';
        }
        return false;
    }

    protected function mobileProbePayload(array $server)
    {
        $type = isset($_POST['type']) && in_array($_POST['type'], ['http', 'tcp', 'ssl'], true) ? $_POST['type'] : 'http';
        $name = trim((string) (isset($_POST['name']) ? $_POST['name'] : ''));
        $target = trim((string) (isset($_POST['target']) ? $_POST['target'] : ''));
        if ($name === '') {
            throw new \RuntimeException('请填写探针名称。');
        }
        if ($target === '') {
            throw new \RuntimeException('请填写检测目标。');
        }
        $method = isset($_POST['method']) && strtoupper((string) $_POST['method']) === 'GET' ? 'GET' : 'HEAD';
        $port = max(0, min(65535, (int) (isset($_POST['port']) ? $_POST['port'] : 0)));
        if ($type === 'http') {
            $parts = parse_url($target);
            if (!$parts || empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
                throw new \RuntimeException('HTTP 检测目标必须填写完整 http:// 或 https:// 地址。');
            }
            $port = $port > 0 ? $port : (isset($parts['port']) ? (int) $parts['port'] : 0);
        } else {
            $targetParts = $this->mobileNormalizeProbeHostPort($target, $type === 'ssl' ? 443 : 80);
            $target = $targetParts['host'];
            $port = $port > 0 ? $port : $targetParts['port'];
        }
        return [
            'type' => $type,
            'name' => text_limit($name, 120, ''),
            'target' => $target,
            'port' => $port,
            'method' => $method,
            'expected_status' => text_limit(trim((string) (isset($_POST['expected_status']) ? $_POST['expected_status'] : '200-399')), 80, ''),
            'keyword' => text_limit(trim((string) (isset($_POST['keyword']) ? $_POST['keyword'] : '')), 255, ''),
            'timeout_seconds' => max(2, min(15, (int) (isset($_POST['timeout_seconds']) ? $_POST['timeout_seconds'] : 5))),
            'frequency' => max(60, min(86400, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 300))),
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'updated_at' => now(),
        ];
    }

    protected function mobileNormalizeProbeHostPort($target, $defaultPort)
    {
        $target = trim((string) $target);
        $parts = parse_url(strpos($target, '://') === false ? 'tcp://' . $target : $target);
        $host = isset($parts['host']) ? $parts['host'] : $target;
        $host = trim($host, " \t\n\r\0\x0B[]");
        if ($host === '') {
            throw new \RuntimeException('检测目标主机不能为空。');
        }
        return ['host' => $host, 'port' => !empty($parts['port']) ? (int) $parts['port'] : (int) $defaultPort];
    }

    protected function mobileProbeLimit()
    {
        return max(0, (int) setting('server_probe_user_check_limit', '20'));
    }

    protected function mobileProbeCount()
    {
        return $this->safeCount('server_service_checks', 'user_id = ?', [(int) Auth::id()]);
    }

    protected function mobileMonitorPageForServer($serverId, $userId)
    {
        return $this->safeRow('SELECT * FROM ' . Database::table('server_monitor_pages') . ' WHERE server_id = ? AND user_id = ? LIMIT 1', [(int) $serverId, (int) $userId]);
    }

    protected function mobileUniquePageToken()
    {
        do {
            $token = bin2hex(random_bytes(16));
            $exists = $this->safeRow('SELECT id FROM ' . Database::table('server_monitor_pages') . ' WHERE token = ? LIMIT 1', [$token]);
        } while ($exists);
        return $token;
    }

    protected function mobileDateOrNull($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $time = strtotime($value);
        return $time ? date('Y-m-d H:i:s', $time) : null;
    }

    protected function mobileLogCommand(array $server, $command, $output, $risk)
    {
        if (!$this->mobileTableExists('server_command_logs')) {
            return;
        }
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('server_command_logs') . ' (user_id, server_id, session_id, command, output_summary, exit_status, risk_level, ip, user_agent, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [(int) Auth::id(), (int) $server['id'], null, (string) $command, text_limit((string) $output, 4000), null, $risk, $this->mobileIp(), $this->mobileUserAgent(), now()]
            );
        } catch (\Throwable $e) {
            // Terminal audit failures should not hide the command result from the user.
        }
    }

    protected function mobileIp()
    {
        return isset($_SERVER['REMOTE_ADDR']) ? substr((string) $_SERVER['REMOTE_ADDR'], 0, 45) : '';
    }

    protected function mobileUserAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 255) : '';
    }

    protected function mobilePayments()
    {
        if (!$this->mobileTableExists('payment_config')) {
            return [];
        }
        return $this->safeRows("SELECT * FROM " . Database::table('payment_config') . " WHERE is_enabled = 1 AND code IN ('balance','manual','alipay') ORDER BY sort_order ASC, id ASC");
    }

    protected function mobileEnabledPayment($code)
    {
        if (!preg_match('/^[a-z0-9_]+$/', (string) $code)) {
            return null;
        }
        return $this->safeRow('SELECT * FROM ' . Database::table('payment_config') . ' WHERE code = ? AND is_enabled = 1 LIMIT 1', [(string) $code]);
    }

    protected function mobilePackageDisplayPrice(array $user, array $package)
    {
        $displayPrice = (float) (isset($package['price']) ? $package['price'] : 0);
        if (empty($user['package_id']) || (int) $user['package_id'] === (int) $package['id']) {
            return $displayPrice;
        }
        if (empty($user['package_expire_time']) || strtotime($user['package_expire_time']) <= time()) {
            return $displayPrice;
        }
        $old = $this->safeRow('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [(int) $user['package_id']]);
        if (!$old || (float) $old['price'] <= 0 || (int) $old['duration_days'] <= 0) {
            return $displayPrice;
        }
        $remainingDays = max(0, (strtotime($user['package_expire_time']) - time()) / 86400);
        $credit = ((float) $old['price']) * min(1, $remainingDays / max(1, (int) $old['duration_days']));
        return round(max(0, $displayPrice - $credit), 2);
    }

    protected function mobilePackageFeatures(array $package)
    {
        return [
            '时长：' . ((isset($package['duration_type']) && $package['duration_type'] === 'forever') ? '永久' : ((int) (isset($package['duration_days']) ? $package['duration_days'] : 0) . ' 天')),
            '空间：' . format_bytes((int) (isset($package['storage_limit']) ? $package['storage_limit'] : 0)),
            '月流量：' . format_bytes((int) (isset($package['traffic_limit']) ? $package['traffic_limit'] : 0)),
            '单文件：' . ((int) (isset($package['single_file_limit']) ? $package['single_file_limit'] : 0) > 0 ? format_bytes((int) $package['single_file_limit']) : '不限'),
            !empty($package['allow_image']) ? '图床上传' : '不含图床上传',
            !empty($package['allow_netdisk']) ? '个人网盘' : '不含个人网盘',
            !empty($package['allow_api']) ? 'API / PicGo / ShareX' : '不含 API 上传',
            !empty($package['allow_monitor']) ? '服务器管家' : '不含服务器管家',
            !empty($package['allow_share']) ? '分享仓库' : '不含分享仓库',
            !empty($package['allow_subsite']) ? '个人分站 ' . (int) (isset($package['subsite_limit']) ? $package['subsite_limit'] : 0) . ' 个' : '不含个人分站',
        ];
    }

    protected function mobileApiUser()
    {
        $user = $this->currentUser();
        if ($user && isset($user['api_token'])) {
            $user['api_token'] = CryptoService::decrypt($user['api_token']);
        }
        return $user;
    }

    protected function mobileApiAllowed(array $user)
    {
        if (empty($user['package_id']) || !$this->mobileTableExists('packages')) {
            return false;
        }
        $package = $this->safeRow('SELECT allow_api FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [(int) $user['package_id']]);
        return $package && (int) (isset($package['allow_api']) ? $package['allow_api'] : 0) === 1;
    }

    protected function mobileApiEndpoints()
    {
        return [
            'upload' => public_url('api/upload'),
            'files' => public_url('api/files'),
            'delete' => public_url('api/delete'),
            'quota' => public_url('api/quota'),
        ];
    }

    protected function mobileSharexConfigPayload(array $user)
    {
        $endpoints = $this->mobileApiEndpoints();
        return [
            'Version' => '17.0.0',
            'Name' => app_brand_name() . ' Upload',
            'DestinationType' => 'ImageUploader, FileUploader',
            'RequestMethod' => 'POST',
            'RequestURL' => $endpoints['upload'],
            'Headers' => ['X-API-Token' => isset($user['api_token']) ? (string) $user['api_token'] : ''],
            'Body' => 'MultipartFormData',
            'FileFormName' => 'file',
            'Arguments' => ['type' => 'image'],
            'URL' => '$json:data.url$',
            'ThumbnailURL' => '$json:data.url$',
            'DeletionURL' => '',
            'ErrorMessage' => '$json:message$',
        ];
    }

    protected function mobilePicgoConfigPayload(array $user)
    {
        $endpoints = $this->mobileApiEndpoints();
        return [
            'name' => app_brand_name() . ' PicGo',
            'type' => 'customUploader',
            'request' => [
                'url' => $endpoints['upload'],
                'method' => 'POST',
                'headers' => ['X-API-Token' => isset($user['api_token']) ? (string) $user['api_token'] : ''],
                'formData' => ['type' => 'image'],
                'fileName' => 'file',
            ],
            'response' => [
                'successPath' => 'success',
                'urlPath' => 'data.url',
                'messagePath' => 'message',
            ],
        ];
    }

    protected function mobileNormalizeApiAllowedIps($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $parts = preg_split('/[\s,;]+/', $value);
        $ips = [];
        foreach ($parts as $ip) {
            $ip = trim($ip);
            if ($ip === '') {
                continue;
            }
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                return false;
            }
            $ips[$ip] = true;
        }
        return implode("\n", array_keys($ips));
    }

    protected function mobileCleanPublicImageUrl($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $value = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', '', $value);
        if (strpos($value, '//') === 0) {
            return '';
        }
        if (preg_match('#^https?://#i', $value)) {
            return text_limit($value, 800);
        }
        if (strpos($value, '/') === 0) {
            return text_limit($value, 800);
        }
        return '';
    }

    protected function mobileAlertStats($userId)
    {
        return [
            'total' => $this->mobileAlertCount((int) $userId),
            'unread' => $this->mobileAlertCount((int) $userId, "a.status = 'unread'"),
            'read' => $this->mobileAlertCount((int) $userId, "a.status = 'read'"),
            'resolved' => $this->mobileAlertCount((int) $userId, "a.status = 'resolved'"),
        ];
    }

    protected function mobileAlertCount($userId, $extraWhere = '')
    {
        $where = 's.user_id = ? AND s.monitor_type IN (?, ?)';
        if ($extraWhere !== '') {
            $where .= ' AND ' . $extraWhere;
        }
        $row = $this->safeRow(
            'SELECT COUNT(*) AS c FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE ' . $where,
            [(int) $userId, 'ssh', 'agent']
        );
        return $row ? (int) $row['c'] : 0;
    }

    protected function updateMobileAlertStatus($status, $resolvedAt, $message)
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->mobileTablesReady(['monitor_servers', 'monitor_alerts'], '监控告警', true)) {
            $this->redirect('m/alerts');
        }
        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        $alert = $this->safeRow(
            'SELECT a.id FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE a.id = ? AND s.user_id = ? AND s.monitor_type IN (?, ?) LIMIT 1',
            [$id, (int) Auth::id(), 'ssh', 'agent']
        );
        if (!$alert) {
            set_flash('error', '告警不存在或无权操作。');
            $this->redirect('m/alerts');
        }
        try {
            if ($status === 'resolved') {
                Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ?, resolved_at = ? WHERE id = ?', [$status, $resolvedAt, $id]);
            } else {
                Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ? WHERE id = ?', [$status, $id]);
            }
            set_flash('success', $message);
        } catch (\Throwable $e) {
            set_flash('error', '告警处理失败：' . $this->mobileSchemaHint($e->getMessage(), '监控告警'));
        }
        $this->redirect('m/alerts');
    }

    protected function folderBelongsToUser($folderId, $userId)
    {
        $folderId = (int) $folderId;
        if ($folderId === 0) {
            return true;
        }
        if (!$this->mobileTableExists('file_folders')) {
            return false;
        }
        return $this->safeRow('SELECT id FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ? LIMIT 1', [$folderId, (int) $userId]) !== null;
    }

    protected function mobileNetdiskBack($folderId = 0)
    {
        $folderId = max(0, (int) $folderId);
        return $folderId > 0 ? 'm/netdisk?folder_id=' . $folderId : 'm/netdisk';
    }

    protected function serverIsStale(array $server)
    {
        if (empty($server['last_checked_at'])) {
            return false;
        }
        $last = strtotime($server['last_checked_at']);
        if (!$last) {
            return false;
        }
        $frequency = max(60, (int) (isset($server['frequency']) ? $server['frequency'] : 300));
        return (time() - $last) > max(600, $frequency * 2);
    }

    protected function mobileConnectionHint($message)
    {
        $message = (string) $message;
        if (stripos($message, 'connect') !== false || strpos($message, '连接') !== false || stripos($message, 'timed out') !== false) {
            return '连接失败：请检查服务器 IP、SSH 端口、防火墙和安全组。原始提示：' . $message;
        }
        if (stripos($message, 'login') !== false || strpos($message, '认证') !== false || strpos($message, '登录') !== false) {
            return '认证失败：请检查 SSH 用户名、密码或私钥。原始提示：' . $message;
        }
        if (stripos($message, 'phpseclib') !== false || stripos($message, 'ssh2') !== false || strpos($message, '扩展') !== false) {
            return '运行环境缺少 SSH 客户端能力，请安装 phpseclib 或 PHP ssh2 扩展。原始提示：' . $message;
        }
        return '采集失败：' . $message;
    }

    protected function mobileConnectionChecks($message)
    {
        $message = (string) $message;
        $stage = 'command';
        if (stripos($message, 'phpseclib') !== false || stripos($message, 'ssh2') !== false || strpos($message, '扩展') !== false || strpos($message, '客户端') !== false) {
            $stage = 'environment';
        } elseif (stripos($message, 'connect') !== false || strpos($message, '连接') !== false || stripos($message, 'timed out') !== false) {
            $stage = 'network';
        } elseif (stripos($message, 'login') !== false || strpos($message, '登录') !== false || strpos($message, '认证') !== false) {
            $stage = 'auth';
        }

        $rows = [
            ['key' => 'config', 'label' => '服务器配置', 'status' => 'ok', 'message' => '已读取 SSH 主机、端口、用户和认证方式。'],
            ['key' => 'environment', 'label' => 'PHP SSH 能力', 'status' => 'pending', 'message' => '检查 phpseclib 或 ssh2 扩展是否可用。'],
            ['key' => 'network', 'label' => '网络与端口', 'status' => 'pending', 'message' => '检查目标 IP、SSH 端口、防火墙和安全组。'],
            ['key' => 'auth', 'label' => '账号认证', 'status' => 'pending', 'message' => '检查用户名、密码、私钥和 root 登录策略。'],
            ['key' => 'command', 'label' => '命令执行', 'status' => 'pending', 'message' => '连接已建立后执行命令。'],
        ];
        $order = ['config' => 0, 'environment' => 1, 'network' => 2, 'auth' => 3, 'command' => 4];
        $failedIndex = isset($order[$stage]) ? $order[$stage] : 4;
        foreach ($rows as &$row) {
            $index = $order[$row['key']];
            if ($index < $failedIndex) {
                $row['status'] = 'ok';
            } elseif ($index === $failedIndex) {
                $row['status'] = 'fail';
                $row['message'] .= ' 当前卡在这一步：' . $message;
            }
        }
        unset($row);
        return $rows;
    }

    protected function safeRows($sql, array $params = [])
    {
        try {
            return Database::fetchAll($sql, $params);
        } catch (\Throwable $e) {
            return [];
        }
    }

    protected function safeRow($sql, array $params = [])
    {
        try {
            return Database::fetch($sql, $params);
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function safeCount($table, $where, array $params)
    {
        try {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table($table) . ' WHERE ' . $where, $params);
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function mobileTableExists($table)
    {
        try {
            return Database::tableExists(Database::table($table));
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function mobileColumnExists($table, $column)
    {
        try {
            return Database::columnExists(Database::table($table), $column);
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function mobileTablesReady(array $tables, $featureLabel, $flash = false)
    {
        $missing = [];
        foreach ($tables as $table) {
            if (!$this->mobileTableExists($table)) {
                $missing[] = $table;
            }
        }
        if (!$missing) {
            return true;
        }

        if ($flash) {
            set_flash('error', $this->mobileSchemaHint('缺失表：' . implode(', ', $missing), $featureLabel));
        } else {
            set_flash('error', $featureLabel . '数据结构未准备完成，当前页面已降级显示空状态。请管理员进入后台「数据库巡检」执行一键修复。缺失表：' . implode(', ', $missing));
        }
        return false;
    }

    protected function mobileSchemaHint($message, $featureLabel)
    {
        $message = trim((string) $message);
        $schemaKeywords = ['Base table or view not found', 'Unknown column', '缺失表', 'Table', 'Column'];
        foreach ($schemaKeywords as $keyword) {
            if ($message !== '' && stripos($message, $keyword) !== false) {
                return $featureLabel . '数据结构未准备完成，请管理员进入后台「数据库巡检」执行一键修复。原始提示：' . $message;
            }
        }
        return $message !== '' ? $message : ($featureLabel . '处理失败：服务器没有返回明确原因，请进入后台「异常事件」或「数据库巡检」查看最近错误。');
    }

    protected function schemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }
}
