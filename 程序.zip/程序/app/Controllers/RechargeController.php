<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\Order;
use App\Models\Recharge;
use App\Services\Payment\PaymentManager;

class RechargeController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        $this->view('recharge/index', [
            'title' => '账户充值',
            'recharges' => (new Recharge())->userRecharges(Auth::id()),
            'payments' => $this->enabledPayments(),
        ]);
    }

    public function create()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $amount = round((float) (isset($_POST['amount']) ? $_POST['amount'] : 0), 2);
        $method = isset($_POST['payment_method']) ? $_POST['payment_method'] : 'manual';
        if ($amount <= 0) {
            set_flash('error', '充值金额必须大于 0。');
            $this->redirect('recharge');
        }
        $payment = $this->enabledPayment($method);
        if (!$payment) {
            set_flash('error', '该支付方式未启用或不存在，请选择可用支付方式。');
            $this->redirect('recharge');
        }
        if (in_array($method, ['wechat', 'epay', 'balance'], true)) {
            set_flash('error', '该支付方式当前未完成生产接入，请联系管理员配置真实支付网关。');
            $this->redirect('recharge');
        }

        $order = (new Order())->createOrder(Auth::id(), 'recharge', $amount, $method, null, '账户充值');
        (new Recharge())->create([
            'user_id' => Auth::id(),
            'order_id' => $order['id'],
            'amount' => $amount,
            'payment_method' => $method,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $gateway = PaymentManager::driver($method);
        try {
            $result = $gateway->create($order);
        } catch (\Throwable $e) {
            Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?', ['closed', now(), $order['id']]);
            Database::execute('UPDATE ' . Database::table('recharges') . ' SET audit_remark = ?, updated_at = ? WHERE order_id = ?', ['支付创建失败：' . text_limit($e->getMessage(), 230), now(), $order['id']]);
            set_flash('error', $e->getMessage());
            $this->redirect('recharge');
        }
        if ($method === 'alipay' && !empty($result['qr_code'])) {
            $_SESSION['alipay_qr'][$order['order_no']] = $result['qr_code'];
            $this->redirect('pay/alipay/' . $order['order_no']);
        }
        set_flash('success', $result['message']);
        $this->redirect('recharge');
    }

    public function orders()
    {
        $this->requireLogin();
        $orders = (new Order())->userOrders(Auth::id());
        $stats = [
            'total' => count($orders),
            'paid' => 0,
            'pending' => 0,
            'amount' => 0,
        ];
        foreach ($orders as $order) {
            if ($order['status'] === 'paid') {
                $stats['paid']++;
                $stats['amount'] += (float) $order['pay_amount'];
            } elseif ($order['status'] === 'pending') {
                $stats['pending']++;
            }
        }
        $this->view('recharge/orders', [
            'title' => '订单记录',
            'orders' => $orders,
            'stats' => $stats,
        ]);
    }

    public function closeOrder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $orderNo = trim(isset($_POST['order_no']) ? $_POST['order_no'] : '');
        $order = Database::fetch(
            'SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? AND user_id = ? LIMIT 1',
            [$orderNo, Auth::id()]
        );
        if (!$order) {
            set_flash('error', '订单不存在。');
            $this->redirect('orders');
        }
        if ($order['status'] !== 'pending') {
            set_flash('error', '当前订单状态不可关闭。');
            $this->redirect('orders');
        }
        if (!in_array($order['payment_method'], ['manual', 'alipay'], true)) {
            set_flash('error', '当前支付方式不支持手动关闭。');
            $this->redirect('orders');
        }

        Database::begin();
        try {
            Database::execute(
                'UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?',
                ['closed', now(), $order['id']]
            );
            if ($order['type'] === 'recharge') {
                Database::execute(
                    'UPDATE ' . Database::table('recharges') . ' SET audit_remark = ?, updated_at = ? WHERE order_id = ?',
                    ['用户已主动关闭订单', now(), $order['id']]
                );
            }
            Database::commit();
            set_flash('success', '订单已关闭，如仍需购买可重新创建。');
        } catch (\Throwable $e) {
            Database::rollBack();
            set_flash('error', $e->getMessage());
        }
        $this->redirect('orders');
    }

    public function balanceLogs()
    {
        $this->requireLogin();
        $logs = Database::fetchAll('SELECT * FROM ' . Database::table('balance_logs') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 200', [Auth::id()]);
        $stats = [
            'total' => count($logs),
            'recharge' => 0,
            'consume' => 0,
            'refund' => 0,
            'adjust' => 0,
        ];
        foreach ($logs as $log) {
            if (isset($stats[$log['type']])) {
                $stats[$log['type']] += (float) $log['amount'];
            }
        }
        $this->view('recharge/balance_logs', [
            'title' => '余额流水',
            'logs' => $logs,
            'stats' => $stats,
        ]);
    }

    protected function enabledPayments()
    {
        $rows = Database::fetchAll('SELECT * FROM ' . Database::table('payment_config') . ' WHERE is_enabled = 1 ORDER BY sort_order ASC, id ASC');
        $allowed = [];
        foreach ($rows as $row) {
            if (in_array($row['code'], ['manual', 'alipay'], true)) {
                $allowed[] = $row;
            }
        }
        return $allowed;
    }

    protected function enabledPayment($code)
    {
        if (!preg_match('/^[a-z0-9_]+$/', (string) $code)) {
            return null;
        }
        return Database::fetch('SELECT * FROM ' . Database::table('payment_config') . ' WHERE code = ? AND is_enabled = 1 LIMIT 1', [$code]);
    }
}
