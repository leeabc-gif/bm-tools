<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Validator;
use App\Models\User;
use App\Services\CryptoService;
use App\Services\DatabaseUpgradeService;
use App\Services\PermissionService;
use App\Services\SubsiteService;
use App\Services\TeamSpaceService;

class UserController extends Controller
{
    protected function ensureUserApiReady($back = 'user')
    {
        return $this->ensureFeatureReady(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema']),
            '账号 API 安全配置',
            $back,
            '账号 API 安全字段未准备完成，请联系管理员进入后台「系统维护」执行数据库一键修复。'
        );
    }

    protected function ensureUserSubsiteReady($back = 'user')
    {
        return $this->ensureFeatureReady(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema']),
            '我的分站',
            $back,
            '分站数据结构未准备完成，请联系管理员进入后台「系统维护」执行数据库一键修复。'
        );
    }

    protected function ensureUserTeamSpaceReady($back = 'user')
    {
        return $this->ensureFeatureReady(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureTeamSpaceSchema']),
            '团队空间',
            $back,
            '团队空间数据表尚未准备完成，请进入后台「系统维护」执行数据库一键修复后再使用。'
        );
    }

    protected function ensureUserThemeReady($back = 'user')
    {
        return $this->ensureFeatureReady(
            $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserThemeSchema']),
            '界面主题',
            $back,
            '主题偏好字段未准备完成，请联系管理员进入后台「系统维护」执行数据库一键修复。'
        );
    }

    public function dashboard()
    {
        $this->requireLogin();
        $this->ensureDashboardSchemas();
        $user = $this->currentUserForDashboard();
        $permissions = $this->permissionSummary($user);
        $this->view('user/dashboard', [
            'title' => '用户中心',
            'user' => $user,
            'package' => $this->safePackageInfo((int) $user['id']),
            'dashboardStats' => $this->dashboardStats($user),
            'dashboardCounters' => $this->dashboardCounters($user),
            'permissions' => $permissions,
        ]);
    }

    protected function ensureDashboardSchemas()
    {
        $callbacks = [
            [DatabaseUpgradeService::class, 'ensureUserPermissionSchema'],
            [DatabaseUpgradeService::class, 'ensureApiSecuritySchema'],
            [DatabaseUpgradeService::class, 'ensureRepositorySchema'],
            [DatabaseUpgradeService::class, 'ensureShareLogSchema'],
            [DatabaseUpgradeService::class, 'ensureMonitorSchema'],
            [DatabaseUpgradeService::class, 'ensureServerOpsSchema'],
            [DatabaseUpgradeService::class, 'ensureRedeemCardSchema'],
            [DatabaseUpgradeService::class, 'ensureSubsiteSchema'],
            [DatabaseUpgradeService::class, 'ensureTeamSpaceSchema'],
        ];
        foreach ($callbacks as $callback) {
            $this->safeSchemaReady($callback);
        }
    }

    protected function currentUserForDashboard()
    {
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [Auth::id()]);
        return $user ?: Auth::user();
    }

    protected function safePackageInfo($userId)
    {
        try {
            return (new User())->packageInfo($userId);
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function dashboardStats(array $user)
    {
        $storageTotal = (int) (isset($user['total_storage']) ? $user['total_storage'] : 0);
        $storageUsed = (int) (isset($user['used_storage']) ? $user['used_storage'] : 0);
        $trafficTotal = (int) (isset($user['total_traffic']) ? $user['total_traffic'] : 0);
        $trafficUsed = (int) (isset($user['used_traffic']) ? $user['used_traffic'] : 0);
        $fileStats = [
            'total' => 0,
            'images' => 0,
            'files' => 0,
            'size' => 0,
        ];
        $recent = [];
        try {
            $fileStats = Database::fetch(
                "SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN file_type = 'image' THEN 1 ELSE 0 END),0) AS images, COALESCE(SUM(CASE WHEN file_type = 'file' THEN 1 ELSE 0 END),0) AS files, COALESCE(SUM(file_size),0) AS size FROM " . Database::table('files') . " WHERE user_id = ?",
                [$user['id']]
            ) ?: $fileStats;
            $recent = Database::fetchAll('SELECT id, original_name, file_type, file_size, created_at FROM ' . Database::table('files') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 5', [$user['id']]);
        } catch (\Throwable $e) {
            $recent = [];
        }
        $storagePercent = $storageTotal > 0 ? min(100, round($storageUsed / $storageTotal * 100, 2)) : 0;
        $trafficPercent = $trafficTotal > 0 ? min(100, round($trafficUsed / $trafficTotal * 100, 2)) : 0;
        $tips = [];
        if ((float) (isset($user['balance']) ? $user['balance'] : 0) <= 0) {
            $tips[] = ['title' => '充值余额', 'desc' => '余额不足时无法购买套餐或续费。', 'url' => url('recharge'), 'icon' => 'wallet'];
        }
        if ($storagePercent >= 80) {
            $tips[] = ['title' => '升级容量', 'desc' => '存储空间接近上限，建议升级套餐或清理回收站。', 'url' => url('packages'), 'icon' => 'arrow-up-right'];
        }
        $permissions = $this->permissionSummary($user);
        if ((int) $fileStats['total'] === 0 && !empty($permissions['image'])) {
            $tips[] = ['title' => '上传第一张图片', 'desc' => '开始使用图床并复制 Markdown/HTML 外链。', 'url' => url('files'), 'icon' => 'upload-cloud'];
        }
        if (!$tips && !empty($permissions['netdisk'])) {
            $tips[] = ['title' => '整理网盘', 'desc' => '按项目建立文件夹，让资料和分享更容易管理。', 'url' => url('netdisk'), 'icon' => 'folder-open'];
        }
        if (!$tips) {
            $tips[] = ['title' => '查看套餐权限', 'desc' => '当前账号部分功能未开放，可通过套餐或管理员单独授权。', 'url' => url('packages'), 'icon' => 'badge-dollar-sign'];
        }
        return [
            'storage_percent' => $storagePercent,
            'traffic_percent' => $trafficPercent,
            'file_total' => (int) $fileStats['total'],
            'image_total' => (int) $fileStats['images'],
            'netdisk_total' => (int) $fileStats['files'],
            'file_size' => (int) $fileStats['size'],
            'recent' => $recent,
            'tips' => $tips,
        ];
    }

    protected function dashboardCounters(array $user)
    {
        $userId = (int) $user['id'];
        return [
            'repositories' => $this->safeCount('file_repositories', 'user_id = ?', [$userId]),
            'shares' => $this->safeCount('file_shares', 'user_id = ?', [$userId]),
            'servers' => $this->safeCount('monitor_servers', 'user_id = ? AND monitor_type IN (\'ssh\',\'agent\')', [$userId]),
            'ssh_servers' => $this->safeCount('monitor_servers', 'user_id = ? AND monitor_type IN (\'ssh\',\'agent\')', [$userId]),
            'alerts' => $this->safeUserMonitorAlertCount($userId),
            'notifications' => $this->safeCount('notifications', 'user_id = ? AND is_read = 0', [$userId]),
            'orders' => $this->safeCount('orders', 'user_id = ?', [$userId]),
            'pending_orders' => $this->safeCount('orders', 'user_id = ? AND status = \'pending\'', [$userId]),
            'subsites' => $this->safeCount('subsites', 'user_id = ?', [$userId]),
            'active_subsites' => $this->safeCount('subsites', 'user_id = ? AND status = \'active\'', [$userId]),
            'teams' => $this->safeCount('team_members', 'user_id = ?', [$userId]),
        ];
    }

    protected function safeCount($table, $where, array $params)
    {
        try {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table($table) . ' WHERE ' . $where, $params);
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function safeUserMonitorAlertCount($userId)
    {
        try {
            $row = Database::fetch(
                'SELECT COUNT(*) AS c FROM ' . Database::table('monitor_alerts') . ' a
                 INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id
                 WHERE a.user_id = ? AND s.monitor_type IN (?, ?) AND a.status IN (\'unread\',\'read\')',
                [(int) $userId, 'ssh', 'agent']
            );
            return $row ? (int) $row['c'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    protected function permissionSummary(array $user)
    {
        $this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureUserPermissionSchema']);
        $package = null;
        try {
            $package = Database::fetch('SELECT allow_image, allow_netdisk, allow_api, allow_monitor FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [isset($user['package_id']) ? $user['package_id'] : 0]);
        } catch (\Throwable $e) {
            $package = null;
        }
        $permission = new PermissionService();
        return [
            'image' => $permission->featureAllowed($user, 'image', $package ?: []),
            'netdisk' => $permission->featureAllowed($user, 'netdisk', $package ?: []),
            'api' => $permission->featureAllowed($user, 'api', $package ?: []),
            'monitor' => $permission->featureAllowed($user, 'monitor', $package ?: []),
        ];
    }

    public function profile()
    {
        $this->requireLogin();
        if (!$this->ensureUserApiReady()) {
            return;
        }
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [Auth::id()]);
        $this->view('user/profile', ['title' => '个人资料', 'user' => $this->userForView($user ?: Auth::user())]);
    }

    public function subsites()
    {
        $this->requireLogin();
        if (!$this->ensureUserSubsiteReady()) {
            return;
        }
        $service = new SubsiteService();
        $user = $this->currentUserForDashboard();
        $subsites = $service->userSubsites((int) $user['id']);
        $edit = null;
        if (!empty($_GET['id'])) {
            $edit = $service->findUserSubsite((int) $_GET['id'], (int) $user['id']);
        }
        $packageInfo = $service->packageInfo($user);
        $limit = (int) $packageInfo['limit'];
        $used = count($subsites);
        $this->view('user/subsites', [
            'title' => '我的分站',
            'user' => $user,
            'subsites' => $subsites,
            'accessLogs' => $service->recentAccessLogs(12, (int) $user['id']),
            'editSubsite' => $edit,
            'packageInfo' => $packageInfo,
            'canCreate' => $service->enabled() && !empty($packageInfo['allow']) && ($edit || $used < $limit),
            'usedCount' => $used,
            'limitCount' => $limit,
            'suffixes' => $service->suffixes(),
            'defaultSuffix' => $service->defaultSuffix(),
            'domainConfig' => $service->domainConfigSummary(),
            'customDomainEnabled' => $service->customDomainEnabled(),
            'requiresReview' => $service->requiresReview(),
            'service' => $service,
        ]);
    }

    public function teams()
    {
        $this->requireLogin();
        if (!$this->ensureUserTeamSpaceReady()) {
            return;
        }
        $service = new TeamSpaceService();
        $user = $this->currentUserForDashboard();
        $teams = [];
        $currentTeam = null;
        $members = [];
        $pendingInvites = [];
        $myInvites = [];
        $summary = ['team_count' => 0, 'owned_count' => 0, 'member_count' => 0, 'pending_invites' => 0];

        try {
            $teams = $service->teamsForUser((int) $user['id']);
            $summary = $service->overviewForUser((int) $user['id']);
            $myInvites = $service->invitesForUser((int) $user['id']);
            $teamId = max(0, (int) (isset($_GET['id']) ? $_GET['id'] : 0));
            if ($teamId > 0) {
                $currentTeam = $service->findTeamForUser($teamId, (int) $user['id']);
            }
            if (!$currentTeam && $teams) {
                $currentTeam = $teams[0];
            }
            if ($currentTeam) {
                $members = $service->members((int) $currentTeam['id']);
                $pendingInvites = $service->pendingInvites((int) $currentTeam['id']);
            }
        } catch (\Throwable $e) {
            set_flash('error', '团队空间读取失败：' . $e->getMessage());
        }

        $this->view('user/teams', [
            'title' => '团队空间',
            'user' => $user,
            'teams' => $teams,
            'currentTeam' => $currentTeam,
            'members' => $members,
            'pendingInvites' => $pendingInvites,
            'myInvites' => $myInvites,
            'summary' => $summary,
            'roleLabels' => $service->roleLabels(),
            'roleDescriptions' => $service->roleDescriptions(),
            'canManage' => $currentTeam ? $service->canManageMembers($currentTeam) : false,
            'service' => $service,
        ]);
    }

    public function saveTeam()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        $service = new TeamSpaceService();
        $userId = (int) Auth::id();
        $id = max(0, (int) (isset($_POST['id']) ? $_POST['id'] : 0));
        try {
            if ($id > 0) {
                $team = $service->updateTeam($id, $userId, $_POST);
                $id = $team ? (int) $team['id'] : $id;
                set_flash('success', '团队信息已更新。');
            } else {
                $id = $service->createTeam($userId, $_POST);
                set_flash('success', '团队已创建，可以邀请成员协作了。');
            }
            clear_old();
            $this->redirect('teams?id=' . $id);
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
            $this->redirect($id > 0 ? 'teams?id=' . $id : 'teams');
        }
    }

    public function deleteTeam()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        try {
            (new TeamSpaceService())->deleteTeam((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '团队已删除，未处理邀请也已取消。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('teams');
    }

    public function createTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->createInvite($teamId, (int) Auth::id(), $_POST);
            set_flash('success', '邀请已创建，对方登录后可在团队空间处理。');
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'teams?id=' . $teamId : 'teams');
    }

    public function cancelTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->cancelInvite((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '邀请已取消。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'teams?id=' . $teamId : 'teams');
    }

    public function acceptTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        try {
            $teamId = (new TeamSpaceService())->acceptInvite((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '已加入团队。');
            $this->redirect('teams?id=' . (int) $teamId);
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
            $this->redirect('teams');
        }
    }

    public function declineTeamInvite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        try {
            (new TeamSpaceService())->declineInvite((int) (isset($_POST['id']) ? $_POST['id'] : 0), (int) Auth::id());
            set_flash('success', '邀请已拒绝。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('teams');
    }

    public function updateTeamMember()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->updateMember($teamId, (int) (isset($_POST['user_id']) ? $_POST['user_id'] : 0), (int) Auth::id(), $_POST);
            set_flash('success', '成员权限已更新。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'teams?id=' . $teamId : 'teams');
    }

    public function removeTeamMember()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        $teamId = max(0, (int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0));
        try {
            (new TeamSpaceService())->removeMember($teamId, (int) (isset($_POST['user_id']) ? $_POST['user_id'] : 0), (int) Auth::id());
            set_flash('success', '成员已移除。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect($teamId > 0 ? 'teams?id=' . $teamId : 'teams');
    }

    public function leaveTeam()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserTeamSpaceReady('teams')) {
            return;
        }
        try {
            (new TeamSpaceService())->leaveTeam((int) (isset($_POST['team_id']) ? $_POST['team_id'] : 0), (int) Auth::id());
            set_flash('success', '已退出团队。');
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('teams');
    }

    public function saveSubsite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserSubsiteReady('subsites')) {
            return;
        }
        $service = new SubsiteService();
        $user = $this->currentUserForDashboard();
        $existing = null;
        if (!empty($_POST['id'])) {
            $existing = $service->findUserSubsite((int) $_POST['id'], (int) $user['id']);
            if (!$existing) {
                set_flash('error', '分站不存在或无权编辑。');
                $this->redirect('subsites');
            }
        }
        try {
            $id = $service->saveForUser($user, $_POST, $existing);
            clear_old();
            set_flash('success', $existing ? '分站已更新。' : '分站已开通。');
            $this->redirect('subsites?id=' . $id);
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
            $target = !empty($_POST['id']) ? 'subsites?id=' . (int) $_POST['id'] : 'subsites';
            $this->redirect($target);
        }
    }

    public function deleteSubsite()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserSubsiteReady('subsites')) {
            return;
        }
        $service = new SubsiteService();
        $user = Auth::user();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        if ($id > 0 && $service->deleteForUser($id, (int) $user['id'])) {
            set_flash('success', '分站已删除。');
        } else {
            set_flash('error', '分站不存在或删除失败。');
        }
        $this->redirect('subsites');
    }

    public function checkSubsiteDomain()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserSubsiteReady('subsites')) {
            return;
        }

        $service = new SubsiteService();
        $user = Auth::user();
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $subsite = $service->findUserSubsite($id, (int) $user['id']);
        if (!$subsite) {
            set_flash('error', '分站不存在或无权检测。');
            $this->redirect('subsites');
        }

        try {
            $diagnostic = $service->domainDiagnostic($subsite);
            $service->saveDomainDiagnostic($id, $diagnostic);
            set_flash('subsite_domain_diagnostic', [
                'site' => [
                    'id' => $subsite['id'],
                    'name' => $subsite['name'],
                    'platform_domain' => $subsite['platform_domain'],
                    'custom_domain' => $subsite['custom_domain'],
                ],
                'checks' => isset($diagnostic['checks']) ? $diagnostic['checks'] : [],
                'checked_at' => isset($diagnostic['checked_at']) ? $diagnostic['checked_at'] : now(),
                'public_url' => isset($diagnostic['public_url']) ? $diagnostic['public_url'] : '',
            ]);
            set_flash(!empty($diagnostic['ok']) ? 'success' : 'error', !empty($diagnostic['ok']) ? '域名接入检测通过。' : '域名接入仍有未通过项目，请按检测结果处理。');
        } catch (\Throwable $e) {
            set_flash('error', '域名检测失败：' . $e->getMessage());
        }

        $this->redirect('subsites?id=' . $id);
    }

    public function theme()
    {
        $this->requireLogin();
        if (!$this->ensureUserThemeReady()) {
            return;
        }
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [Auth::id()]);
        $this->view('user/theme', [
            'title' => '主题设置',
            'user' => $user ?: Auth::user(),
            'defaultStyle' => setting('frontend_theme_style', 'classic'),
        ]);
    }

    public function saveTheme()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserThemeReady('theme')) {
            return;
        }
        $style = isset($_POST['frontend_theme_style']) ? (string) $_POST['frontend_theme_style'] : 'classic';
        $style = in_array($style, ['classic', 'anime'], true) ? $style : 'classic';
        Database::execute('UPDATE ' . Database::table('users') . ' SET frontend_theme_style = ?, updated_at = ? WHERE id = ?', [$style, now(), Auth::id()]);
        set_flash('success', '主题偏好已保存，刷新页面和换设备登录都会自动沿用。');
        $this->redirect('theme');
    }

    public function updateProfile()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $user = Auth::user();
        $nickname = trim(isset($_POST['nickname']) ? $_POST['nickname'] : '');
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        $apiAllowedIps = $this->normalizeApiAllowedIps(isset($_POST['api_allowed_ips']) ? $_POST['api_allowed_ips'] : '');
        if (!$nickname || !Validator::email($email)) {
            set_flash('error', '昵称或邮箱格式不正确。');
            $this->redirect('profile');
        }
        if ($apiAllowedIps === false) {
            set_flash('error', 'API 白名单格式不正确。每行填写一个 IPv4 或 IPv6，留空表示不限制。');
            $this->redirect('profile');
        }
        $userModel = new User();
        if ($userModel->existsEmail($email, $user['id'])) {
            set_flash('error', '邮箱已被占用。');
            $this->redirect('profile');
        }
        $data = [
            'nickname' => $nickname,
            'email' => $email,
            'avatar' => $this->cleanPublicImageUrl(isset($_POST['avatar']) ? $_POST['avatar'] : ''),
            'updated_at' => now(),
        ];
        if ($this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'])) {
            $data['api_allowed_ips'] = $apiAllowedIps;
        }
        $userModel->update($user['id'], $data);
        set_flash('success', '资料已更新。');
        $this->redirect('profile');
    }

    public function resetApiToken()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureUserApiReady('profile')) {
            return;
        }
        $token = bin2hex(random_bytes(24));
        $data = [
            'api_token' => $token,
            'updated_at' => now(),
        ];
        if ($this->safeSchemaReady([DatabaseUpgradeService::class, 'ensureApiSecuritySchema'])) {
            $data['api_token'] = CryptoService::encrypt($token);
            $data['api_token_hash'] = hash('sha256', $token);
        }
        (new User())->update(Auth::id(), $data);
        set_flash('success', 'API Token 已重置，旧 Token 将立即失效，请同步更新 PicGo、ShareX 或脚本配置。');
        $this->redirect('profile');
    }

    public function password()
    {
        $this->requireLogin();
        $this->view('user/password', ['title' => '修改密码']);
    }

    protected function normalizeApiAllowedIps($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $parts = preg_split('/[\s,;]+/', $value);
        $ips = [];
        foreach ($parts as $ip) {
            $ip = trim($ip);
            if ($ip === '') {
                continue;
            }
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                return false;
            }
            $ips[$ip] = true;
        }
        return implode("\n", array_keys($ips));
    }

    protected function cleanPublicImageUrl($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        $value = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', '', $value);
        if (strpos($value, '//') === 0) {
            return '';
        }
        if (preg_match('#^https?://#i', $value)) {
            return text_limit($value, 800);
        }
        if (strpos($value, '/') === 0) {
            return text_limit($value, 800);
        }
        return '';
    }

    protected function userForView($user)
    {
        if (!$user) {
            return $user;
        }
        if (isset($user['api_token'])) {
            $user['api_token'] = CryptoService::decrypt($user['api_token']);
        }
        return $user;
    }

    protected function safeSchemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function updatePassword()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $user = Auth::user();
        $old = isset($_POST['old_password']) ? $_POST['old_password'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
        if (!password_verify($old, $user['password']) || !Validator::password($password) || $password !== $confirm) {
            set_flash('error', '原密码错误，或新密码不符合要求。');
            $this->redirect('password');
        }
        (new User())->update($user['id'], ['password' => password_hash($password, PASSWORD_DEFAULT), 'updated_at' => now()]);
        set_flash('success', '密码已修改。');
        $this->redirect('password');
    }
}
