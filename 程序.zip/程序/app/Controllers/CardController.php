<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Services\RedeemCardService;

class CardController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        $service = new RedeemCardService();
        $this->view('cards/index', [
            'title' => '卡密兑换',
            'records' => $service->recentForUser(Auth::id(), 30),
        ]);
    }

    public function redeem()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $code = isset($_POST['code']) ? $_POST['code'] : '';
        try {
            $result = (new RedeemCardService())->redeem(Auth::id(), $code);
            set_flash('success', $result['message']);
        } catch (\Throwable $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('cards');
    }
}
