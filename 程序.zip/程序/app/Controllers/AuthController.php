<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Validator;
use App\Models\User;
use App\Services\RateLimitService;
use App\Services\MailerService;
use App\Services\NotificationService;

class AuthController extends Controller
{
    public function login()
    {
        $this->view('auth/login', ['title' => '登录'], 'layouts/auth');
    }

    public function postLogin()
    {
        $this->verifyCsrf();
        $account = trim(isset($_POST['account']) ? $_POST['account'] : '');
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $remember = !empty($_POST['remember']);
        $limiter = new RateLimitService();
        $maxAttempts = max(1, (int) setting('security_login_max_attempts', 5));
        $window = max(1, (int) setting('security_login_window_minutes', 10)) * 60;
        $lock = max(1, (int) setting('security_login_lock_minutes', 15)) * 60;
        $ipIdentity = 'ip:' . Auth::ip();
        $accountIdentity = 'account:' . text_lower($account);

        foreach ([$limiter->check('login_ip', $ipIdentity, $window), $limiter->check('login_account', $accountIdentity, $window)] as $limit) {
            if (!empty($limit['limited'])) {
                set_flash('error', '登录尝试过于频繁，请约 ' . ceil($limit['retry_after'] / 60) . ' 分钟后再试。');
                remember_old();
                $this->redirect('login');
            }
        }

        if (!Auth::attempt($account, $password, $remember)) {
            $limiter->hit('login_ip', $ipIdentity, $maxAttempts, $window, $lock, Auth::ip(), Auth::ip());
            $limiter->hit('login_account', $accountIdentity, $maxAttempts, $window, $lock, $account, Auth::ip());
            set_flash('error', '账号或密码错误，或账号已被禁用。');
            remember_old();
            $this->redirect('login');
        }

        $limiter->clear('login_ip', $ipIdentity);
        $limiter->clear('login_account', $accountIdentity);
        clear_old();
        $user = Auth::user();
        $intendedUrl = isset($_SESSION['intended_url']) ? (string) $_SESSION['intended_url'] : '';
        unset($_SESSION['intended_url']);
        if ($intendedUrl !== '' && $this->isSafeRedirectUrl($intendedUrl)) {
            header('Location: ' . $this->mobileAwareLoginTarget($intendedUrl, $user));
            exit;
        }
        $this->redirect($this->defaultLoginTarget($user));
    }

    public function register()
    {
        if ((string) setting('register_enabled', '1') !== '1') {
            set_flash('error', '站点暂未开放注册。');
            $this->redirect('login');
        }
        $this->view('auth/register', ['title' => '注册'], 'layouts/auth');
    }

    public function postRegister()
    {
        $this->verifyCsrf();
        if ((string) setting('register_enabled', '1') !== '1') {
            set_flash('error', '站点暂未开放注册。');
            $this->redirect('login');
        }

        $username = trim(isset($_POST['username']) ? $_POST['username'] : '');
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
        $userModel = new User();
        $error = '';

        if (!Validator::username($username)) {
            $error = '用户名只能包含字母、数字、下划线，长度 3-32 位。';
        } elseif (!Validator::email($email)) {
            $error = '邮箱格式不正确。';
        } elseif (!Validator::password($password)) {
            $error = '密码长度至少 6 位。';
        } elseif ($password !== $confirm) {
            $error = '两次输入的密码不一致。';
        } elseif ($userModel->existsUsername($username)) {
            $error = '用户名已被注册。';
        } elseif ($userModel->existsEmail($email)) {
            $error = '邮箱已被注册。';
        } elseif ((string) setting('register_email_code_enabled', '0') === '1' && !$this->verifyEmailCode($email, 'register', trim(isset($_POST['email_code']) ? $_POST['email_code'] : ''))) {
            $error = '邮箱验证码错误或已过期。';
        }

        if ($error !== '') {
            set_flash('error', $error);
            remember_old();
            $this->redirect('register');
        }

        $id = $userModel->createUser($username, $email, $password);
        if ((string) setting('register_email_code_enabled', '0') === '1') {
            Database::execute('UPDATE ' . Database::table('email_codes') . ' SET is_used = 1 WHERE email = ? AND scene = ? AND code = ?', [$email, 'register', trim($_POST['email_code'])]);
        }
        $user = $userModel->find($id);
        Auth::login($user, true);
        (new NotificationService())->send($id, 'register', '注册成功', '欢迎加入 ' . setting('site_name', app_brand_name()) . '。');
        clear_old();
        $this->redirect($this->defaultLoginTarget($user));
    }

    public function sendEmailCode()
    {
        $this->verifyCsrf();
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        $scene = isset($_POST['scene']) && $_POST['scene'] === 'reset_password' ? 'reset_password' : 'register';
        if (!Validator::email($email)) {
            $this->json(['success' => false, 'message' => '邮箱格式不正确。'], 422);
        }
        $limit = $this->checkEmailCodeLimit($email, $scene);
        if (!empty($limit['limited'])) {
            $this->json(['success' => false, 'message' => '验证码发送过于频繁，请稍后再试。'], 429);
        }
        $code = (string) mt_rand(100000, 999999);
        Database::execute(
            'INSERT INTO ' . Database::table('email_codes') . ' (email, scene, code, is_used, expired_at, created_at) VALUES (?,?,?,?,?,?)',
            [$email, $scene, $code, 0, date('Y-m-d H:i:s', time() + 900), now()]
        );
        $mailSent = (new MailerService())->send($email, '邮箱验证码', '你的验证码是：' . $code . '，15 分钟内有效。');
        $this->hitEmailCodeLimit($email, $scene);
        if ($mailSent) {
            $message = '验证码已发送，请查收邮箱。';
        } elseif (trim((string) setting('email_host', '')) === '') {
            $message = '当前未配置邮件服务，验证码已生成，可在 email_codes 表查看测试验证码。';
        } else {
            $message = '邮件发送失败，但验证码已生成，可在 email_codes 表查看测试验证码或检查邮件配置。';
        }
        $this->json(['success' => true, 'message' => $message]);
    }

    public function forgot()
    {
        $this->view('auth/forgot', ['title' => '找回密码'], 'layouts/auth');
    }

    public function postForgot()
    {
        $this->verifyCsrf();
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        if (!Validator::email($email)) {
            set_flash('error', '请输入正确邮箱。');
            $this->redirect('forgot');
        }
        $limit = $this->checkEmailCodeLimit($email, 'reset_password');
        if (!empty($limit['limited'])) {
            set_flash('error', '验证码发送过于频繁，请稍后再试。');
            $this->redirect('forgot');
        }

        $user = (new User())->findByAccount($email);
        if ($user) {
            $code = (string) mt_rand(100000, 999999);
            Database::execute(
                'INSERT INTO ' . Database::table('email_codes') . ' (email, scene, code, is_used, expired_at, created_at) VALUES (?,?,?,?,?,?)',
                [$email, 'reset_password', $code, 0, date('Y-m-d H:i:s', time() + 900), now()]
            );
            $mailSent = (new MailerService())->send($email, '密码重置验证码', '你的验证码是：' . $code . '，15 分钟内有效。');
        }
        $this->hitEmailCodeLimit($email, 'reset_password');
        if (!empty($user) && isset($mailSent) && !$mailSent && trim((string) setting('email_host', '')) === '') {
            set_flash('success', '当前未配置邮件服务，验证码已生成，可在 email_codes 表查看测试验证码，并在 15 分钟内完成重置。');
        } elseif (!empty($user) && isset($mailSent) && !$mailSent) {
            set_flash('success', '验证码已生成，但邮件发送失败。可在 email_codes 表查看测试验证码，并检查邮件配置。');
        } else {
            set_flash('success', '如果邮箱存在，验证码已经发送，请在 15 分钟内完成验证。');
        }
        $_SESSION['reset_email'] = $email;
        $this->view('auth/reset', ['title' => '重置密码', 'email' => $email], 'layouts/auth');
    }

    public function postResetPassword()
    {
        $this->verifyCsrf();
        $email = isset($_SESSION['reset_email']) ? $_SESSION['reset_email'] : '';
        $code = trim(isset($_POST['code']) ? $_POST['code'] : '');
        $password = isset($_POST['password']) ? $_POST['password'] : '';

        if (!Validator::email($email)) {
            set_flash('error', '重置会话已过期，请重新获取验证码。');
            $this->redirect('forgot');
        }

        $limiter = new RateLimitService();
        $identity = 'reset:' . text_lower($email) . ':ip:' . Auth::ip();
        $limit = $limiter->check('reset_password_verify', $identity, 600);
        if (!empty($limit['limited'])) {
            set_flash('error', '验证码尝试过于频繁，请约 ' . ceil($limit['retry_after'] / 60) . ' 分钟后再试。');
            $this->redirect('forgot');
        }

        $record = Database::fetch(
            'SELECT * FROM ' . Database::table('email_codes') . ' WHERE email = ? AND scene = ? AND code = ? AND is_used = 0 AND expired_at >= ? ORDER BY id DESC LIMIT 1',
            [$email, 'reset_password', $code, now()]
        );
        if (!$record || !Validator::password($password)) {
            $limiter->hit('reset_password_verify', $identity, 6, 600, 900, $email, Auth::ip());
            set_flash('error', '验证码错误或密码不符合要求。');
            $this->redirect('forgot');
        }
        $limiter->clear('reset_password_verify', $identity);
        Database::execute('UPDATE ' . Database::table('users') . ' SET password = ?, updated_at = ? WHERE email = ?', [password_hash($password, PASSWORD_DEFAULT), now(), $email]);
        Database::execute('UPDATE ' . Database::table('email_codes') . ' SET is_used = 1 WHERE id = ?', [$record['id']]);
        unset($_SESSION['reset_email']);
        set_flash('success', '密码已重置，请重新登录。');
        $this->redirect('login');
    }

    public function logout()
    {
        Auth::logout();
        $this->redirect('login');
    }

    protected function checkEmailCodeLimit($email, $scene)
    {
        $limiter = new RateLimitService();
        $emailIdentity = $scene . ':email:' . text_lower($email);
        $ipIdentity = $scene . ':ip:' . Auth::ip();

        $emailCheck = $limiter->check('email_code_email', $emailIdentity, 3600);
        if (!empty($emailCheck['limited'])) {
            return $emailCheck;
        }
        $ipCheck = $limiter->check('email_code_ip', $ipIdentity, 3600);
        if (!empty($ipCheck['limited'])) {
            return $ipCheck;
        }
        return ['limited' => false];
    }

    protected function hitEmailCodeLimit($email, $scene)
    {
        $limiter = new RateLimitService();
        $emailLimit = max(1, (int) setting('security_email_code_max_per_hour', 5));
        $ipLimit = max(1, (int) setting('security_email_code_ip_max_per_hour', 20));
        $emailIdentity = $scene . ':email:' . text_lower($email);
        $ipIdentity = $scene . ':ip:' . Auth::ip();
        $limiter->hit('email_code_email', $emailIdentity, $emailLimit, 3600, 3600, $email, Auth::ip());
        $limiter->hit('email_code_ip', $ipIdentity, $ipLimit, 3600, 3600, Auth::ip(), Auth::ip());
    }

    protected function verifyEmailCode($email, $scene, $code)
    {
        if ($code === '') {
            return false;
        }
        return Database::fetch(
            'SELECT id FROM ' . Database::table('email_codes') . ' WHERE email = ? AND scene = ? AND code = ? AND is_used = 0 AND expired_at >= ? ORDER BY id DESC LIMIT 1',
            [$email, $scene, $code, now()]
        ) !== null;
    }

    protected function defaultLoginTarget(array $user)
    {
        if ($this->isMobileRequest()) {
            return isset($user['role']) && $user['role'] === 'admin' ? 'admin/m' : 'm';
        }
        return isset($user['role']) && $user['role'] === 'admin' ? 'admin' : 'dashboard';
    }

    protected function mobileAwareLoginTarget($target, array $user)
    {
        if (!$this->isMobileRequest()) {
            return $target;
        }

        $path = parse_url($target, PHP_URL_PATH);
        if (!$path) {
            return url($this->defaultLoginTarget($user));
        }
        $query = parse_url($target, PHP_URL_QUERY);
        $path = '/' . trim($path, '/');
        if ($path === '//') {
            $path = '/';
        }
        if (strpos($path, '/m') === 0 || strpos($path, '/admin/m') === 0) {
            return $target;
        }

        $adminMap = [
            '/admin' => 'admin/m',
            '/admin/users' => 'admin/m/users',
            '/admin/files' => 'admin/m/files',
            '/admin/packages' => 'admin/m/packages',
            '/admin/cards' => 'admin/m/cards',
            '/admin/coupons' => 'admin/m/coupons',
            '/admin/orders' => 'admin/m/orders',
            '/admin/recharges' => 'admin/m/orders',
            '/admin/payments' => 'admin/m/payments',
            '/admin/storages' => 'admin/m/storages',
            '/admin/storage-integrations' => 'admin/m/storages',
            '/admin/storage-backups' => 'admin/m/storage-backups',
            '/admin/storage-backups/tasks' => 'admin/m/storage-backups',
            '/admin/storage-backups/backfill' => 'admin/m/storage-backups',
            '/admin/repositories' => 'admin/m/repositories',
            '/admin/subsites' => 'admin/m/subsites',
            '/admin/monitors' => 'admin/m/servers',
            '/admin/user-servers' => 'admin/m/servers',
            '/admin/logs' => 'admin/m/logs',
            '/admin/api-logs' => 'admin/m/logs',
            '/admin/balance-logs' => 'admin/m/logs',
            '/admin/command-logs' => 'admin/m/logs',
            '/admin/ssh-sessions' => 'admin/m/logs',
            '/admin/announcements' => 'admin/m/announcements',
            '/admin/settings' => 'admin/m/settings',
            '/admin/settings/site' => 'admin/m/settings',
            '/admin/settings/security' => 'admin/m/settings',
            '/admin/settings/upload' => 'admin/m/settings',
            '/admin/settings/api' => 'admin/m/settings',
            '/admin/settings/email' => 'admin/m/settings',
            '/admin/maintenance' => 'admin/m/settings',
            '/admin/themes' => 'admin/m/settings',
            '/admin/upload-limits' => 'admin/m/upload-limits',
        ];
        $userMap = [
            '/user' => 'm',
            '/user/center' => 'm',
            '/user/dashboard' => 'm',
            '/console' => 'm',
            '/dashboard' => 'm',
            '/profile' => 'm/profile',
            '/password' => 'm/password',
            '/files' => 'm/files',
            '/netdisk' => 'm/netdisk',
            '/repository' => 'm/repository',
            '/subsites' => 'm/subsites',
            '/servers' => 'm/servers',
            '/servers/create' => 'm/servers/create',
            '/servers/commands' => 'm/servers/commands',
            '/orders' => 'm/orders',
            '/balance/logs' => 'm/balance',
            '/recharge' => 'm/recharge',
            '/cards' => 'm/cards',
            '/packages' => 'm/packages',
            '/api/console' => 'm/api',
            '/alerts' => 'm/alerts',
            '/notifications' => 'm/notifications',
        ];

        if (isset($adminMap[$path])) {
            return $this->appendQuery(url($adminMap[$path]), $query);
        }
        if (isset($userMap[$path])) {
            return $this->appendQuery(url($userMap[$path]), $query);
        }
        return url($this->defaultLoginTarget($user));
    }

    protected function appendQuery($url, $query)
    {
        $query = trim((string) $query);
        return $query !== '' ? $url . '?' . $query : $url;
    }

    protected function isMobileRequest()
    {
        if (isset($_SERVER['HTTP_SEC_CH_UA_MOBILE']) && trim((string) $_SERVER['HTTP_SEC_CH_UA_MOBILE']) === '?1') {
            return true;
        }
        $ua = strtolower(isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '');
        if ($ua === '') {
            return false;
        }
        return (bool) preg_match('/android|iphone|ipod|mobile|windows phone|blackberry|opera mini|micromessenger|mqqbrowser/i', $ua);
    }
}
