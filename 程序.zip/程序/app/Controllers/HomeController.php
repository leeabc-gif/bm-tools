<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Services\DatabaseUpgradeService;
use App\Services\SubsiteService;

class HomeController extends Controller
{
    public function index()
    {
        $subsiteService = new SubsiteService();
        try {
            if ($this->schemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'])) {
                $subsite = $subsiteService->resolveCurrentHost();
                if ($subsite) {
                    return $this->renderSubsite($subsite, $subsiteService);
                }
            }
        } catch (\Throwable $e) {
            // The main homepage must still render if subsite resolution is not ready.
        }
        $this->view($this->homeView(), [
            'title' => setting('site_name', app_brand_name()),
            'isCloudHome' => true,
            'stats' => $this->platformStats(),
        ]);
    }

    public function subsite()
    {
        if (!$this->schemaReady([DatabaseUpgradeService::class, 'ensureSubsiteSchema'])) {
            http_response_code(404);
            $this->view('home/subsite_404', [
                'title' => '分站暂不可用',
                'isCloudHome' => true,
            ]);
            return;
        }
        $subsiteService = new SubsiteService();
        $slug = isset($_GET['slug']) ? $_GET['slug'] : '';
        $subsite = $subsiteService->findBySlug($slug);
        if (!$subsite || $subsite['status'] !== 'active') {
            http_response_code(404);
            $this->view('home/subsite_404', [
                'title' => '分站不存在',
                'isCloudHome' => true,
            ]);
            return;
        }
        $this->renderSubsite($subsite, $subsiteService);
    }

    protected function renderSubsite(array $subsite, SubsiteService $subsiteService)
    {
        $data = $subsiteService->publicData($subsite);
        $subsiteService->logView($subsite);
        $this->view('home/subsite', [
            'title' => $subsite['title'] ?: $subsite['name'],
            'isCloudHome' => true,
            'subsite' => $subsite,
            'subsiteData' => $data,
        ]);
    }

    protected function homeView()
    {
        return 'home/default';
    }

    protected function platformStats()
    {
        try {
            return [
                'files' => (int) Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files'))['c'],
                'today_uploads' => (int) Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE DATE(created_at) = CURDATE()')['c'],
                'storage' => (int) Database::fetch('SELECT COALESCE(SUM(file_size),0) AS s FROM ' . Database::table('files'))['s'],
                'online_servers' => (int) Database::fetch("SELECT COUNT(*) AS c FROM " . Database::table('monitor_servers') . " WHERE monitor_type = 'bt' AND is_enabled = 1 AND status = 'online'")['c'],
                'offline_servers' => (int) Database::fetch("SELECT COUNT(*) AS c FROM " . Database::table('monitor_servers') . " WHERE monitor_type = 'bt' AND is_enabled = 1 AND status = 'offline'")['c'],
            ];
        } catch (\Throwable $e) {
            return ['files' => 0, 'today_uploads' => 0, 'storage' => 0, 'online_servers' => 0, 'offline_servers' => 0];
        }
    }

    public function status()
    {
        $error = '';
        if (!$this->schemaReady([DatabaseUpgradeService::class, 'ensureMonitorSchema'])) {
            $error = '服务器状态数据结构未准备完成，请管理员进入后台「数据库巡检」执行一键修复。';
            $servers = [];
        } else {
        try {
            $servers = Database::fetchAll(
                'SELECT s.*, m.cpu_usage, m.memory_total, m.memory_used, m.memory_usage, m.disk_total, m.disk_used, m.disk_usage, m.net_upload, m.net_download, m.load_avg, m.uptime, m.nginx_status, m.mysql_status, m.php_status, m.panel_status, m.raw_data, m.created_at AS metric_time
                 FROM ' . Database::table('monitor_servers') . ' s
                 LEFT JOIN ' . Database::table('monitor_metrics') . ' m ON m.id = (
                    SELECT id FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = s.id ORDER BY id DESC LIMIT 1
                 )
                 WHERE s.monitor_type = \'bt\' AND s.is_enabled = 1
                 ORDER BY CASE s.status WHEN \'online\' THEN 0 WHEN \'unknown\' THEN 1 ELSE 2 END, s.id DESC'
            );
        } catch (\Throwable $e) {
            $error = $this->statusError($e);
            try {
                $servers = Database::fetchAll('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE monitor_type = ? AND is_enabled = 1 ORDER BY id DESC', ['bt']);
                foreach ($servers as &$server) {
                    $server = array_merge([
                        'cpu_usage' => 0,
                        'memory_total' => 0,
                        'memory_used' => 0,
                        'memory_usage' => 0,
                        'disk_total' => 0,
                        'disk_used' => 0,
                        'disk_usage' => 0,
                        'net_upload' => 0,
                        'net_download' => 0,
                        'load_avg' => '',
                        'uptime' => '',
                        'nginx_status' => 'unknown',
                        'mysql_status' => 'unknown',
                        'php_status' => 'unknown',
                        'panel_status' => 'unknown',
                        'raw_data' => '',
                        'metric_time' => isset($server['last_checked_at']) ? $server['last_checked_at'] : '',
                    ], $server);
                }
                unset($server);
            } catch (\Throwable $inner) {
                $servers = [];
                if ($error === '') {
                    $error = $this->statusError($inner);
                }
            }
        }
        }

        try {
            $alerts = Database::fetchAll('SELECT a.*, s.name AS server_name FROM ' . Database::table('monitor_alerts') . ' a INNER JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE s.monitor_type = ? AND s.is_enabled = 1 ORDER BY a.id DESC LIMIT 20', ['bt']);
        } catch (\Throwable $e) {
            $alerts = [];
        }
        $metricHistory = $this->statusMetricHistory($servers);
        $statusSummary = $this->publicStatusSummary($servers);
        $this->view('home/status_page', [
            'title' => '平台运行状态',
            'servers' => $servers,
            'alerts' => $alerts,
            'stats' => $this->platformStats(),
            'statusSummary' => $statusSummary,
            'statusError' => $error,
            'metricHistory' => $metricHistory,
        ], 'layouts/status');
    }

    protected function publicStatusSummary(array $servers)
    {
        $summary = ['total' => count($servers), 'online' => 0, 'abnormal' => 0, 'stale' => 0];
        foreach ($servers as $server) {
            $time = !empty($server['metric_time']) ? $server['metric_time'] : (isset($server['last_checked_at']) ? $server['last_checked_at'] : '');
            $frequency = isset($server['frequency']) && (int) $server['frequency'] > 0 ? (int) $server['frequency'] : 300;
            $stale = !$time || (time() - strtotime($time)) > max(600, $frequency * 3);
            if ($stale) {
                $summary['stale']++;
            }
            if (isset($server['status']) && $server['status'] === 'online' && !$stale) {
                $summary['online']++;
            } else {
                $summary['abnormal']++;
            }
        }
        return $summary;
    }

    protected function statusMetricHistory(array $servers)
    {
        $history = [];
        foreach ($servers as $server) {
            $serverId = isset($server['id']) ? (int) $server['id'] : 0;
            if ($serverId <= 0) {
                continue;
            }
            try {
                $rows = Database::fetchAll(
                    'SELECT cpu_usage, memory_usage, disk_usage, net_upload, net_download, load_avg, created_at
                     FROM ' . Database::table('monitor_metrics') . '
                     WHERE server_id = ?
                     ORDER BY id DESC
                     LIMIT 60',
                    [$serverId]
                );
                $history[$serverId] = array_reverse($rows);
            } catch (\Throwable $e) {
                $history[$serverId] = [];
            }
        }
        return $history;
    }

    protected function schemaReady(callable $callback)
    {
        try {
            return (bool) call_user_func($callback);
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function statusError(\Exception $e)
    {
        $message = $e->getMessage();
        if (stripos($message, 'Unknown column') !== false) {
            return '监控表结构需要升级：请执行 database/upgrade_ssh_monitor.sql，或在后台重新运行数据库升级。';
        }
        if (stripos($message, 'Base table') !== false || stripos($message, 'doesn') !== false) {
            return '监控数据表不存在，请确认系统已完成安装并创建监控表。';
        }
        return APP_DEBUG ? $message : '监控数据读取异常，请稍后刷新或联系管理员。';
    }
}
