<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\FileItem;
use App\Models\StorageDriver;
use App\Services\ApiAppService;
use App\Services\CryptoService;
use App\Services\DatabaseUpgradeService;
use App\Services\FileService;
use App\Services\FileLogService;
use App\Services\RateLimitService;
use App\Services\StorageBackupService;
use App\Services\Storage\StorageManager;
use App\Services\UploadFailureService;
use App\Services\UploadLimitService;

class ApiController extends Controller
{
    public function console()
    {
        $this->requireLogin();
        if (!$this->ensureFeatureReady(
            $this->apiSchemaReady(),
            'API 管理',
            'dashboard',
            'API 安全与日志数据结构未准备完成，请管理员进入后台「数据库巡检」执行一键修复。'
        )) {
            return;
        }
        $user = Auth::user();
        $package = Database::fetch('SELECT allow_api FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        if (!$package || (int) $package['allow_api'] !== 1) {
            set_flash('error', '当前套餐不允许使用 API，请升级套餐或联系管理员。');
            $this->redirect('dashboard');
        }
        $apiUser = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [Auth::id()]) ?: Auth::user();
        if ($apiUser && isset($apiUser['api_token'])) {
            $apiUser['api_token'] = CryptoService::decrypt($apiUser['api_token']);
        }
        $apiAppService = new ApiAppService();
        $oneTimeToken = isset($_SESSION['api_app_plain_token']) && is_array($_SESSION['api_app_plain_token'])
            ? $_SESSION['api_app_plain_token']
            : null;
        unset($_SESSION['api_app_plain_token']);
        $this->view('user/api', [
            'title' => 'API 管理',
            'user' => $apiUser,
            'logs' => $apiAppService->logsForUser(Auth::id(), 100),
            'endpoints' => $this->integrationEndpoints(),
            'sharexConfig' => $this->sharexConfigPayload($apiUser),
            'picgoConfig' => $this->picgoConfigPayload($apiUser),
            'apiApps' => $apiAppService->appsWithStatsForUser(Auth::id()),
            'apiScopes' => $apiAppService->scopeLabels(),
            'apiAppOneTimeToken' => $oneTimeToken,
            'apiUsageSummary' => $apiAppService->usageSummaryForUser(Auth::id()),
            'apiAppService' => $apiAppService,
        ]);
    }

    public function createApp()
    {
        $this->handleAppMutation('create');
    }

    public function updateApp()
    {
        $this->handleAppMutation('update');
    }

    public function rotateApp()
    {
        $this->handleAppMutation('rotate');
    }

    public function deleteApp()
    {
        $this->handleAppMutation('delete');
    }

    public function picgoConfig()
    {
        $this->requireLogin();
        if (!$this->ensureFeatureReady(
            $this->apiSchemaReady(),
            'PicGo 配置',
            'profile',
            'API 安全配置未准备完成，请管理员进入后台「数据库巡检」执行一键修复。'
        )) {
            return;
        }
        $this->downloadJson('bmtools-picgo-config.json', $this->picgoConfigPayload($this->currentApiUserForDownload()));
    }

    public function sharexConfig()
    {
        $this->requireLogin();
        if (!$this->ensureFeatureReady(
            $this->apiSchemaReady(),
            'ShareX 配置',
            'profile',
            'API 安全配置未准备完成，请管理员进入后台「数据库巡检」执行一键修复。'
        )) {
            return;
        }
        $this->downloadJson('bmtools-sharex.sxcu', $this->sharexConfigPayload($this->currentApiUserForDownload()));
    }

    public function upload()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'upload');

        if (empty($_FILES['file'])) {
            $this->apiError($user, 'upload', '请选择 file 字段上传。', 422);
        }

        try {
            $type = isset($_POST['type']) && $_POST['type'] === 'file' ? 'file' : 'image';
            $limits = new UploadLimitService();
            $limits->assertBatchLimit($type, 1);
            $dailyLock = null;
            $concurrencyLock = null;
            try {
                $dailyLock = $limits->acquireDailyLimitSlot((int) $user['id'], $type);
                $concurrencyLock = $limits->acquireConcurrency((int) $user['id']);
                $file = (new FileService())->uploadForUser($user, $_FILES['file'], $type, 0);
            } finally {
                $limits->releaseConcurrency($concurrencyLock);
                $limits->releaseConcurrency($dailyLock);
            }
            $fileUrl = public_url($file['file_url']);
            $this->logApi($user, 'upload', 200, true, '上传成功');
            $this->json([
                'success' => true,
                'data' => [
                    'id' => $file['id'],
                    'name' => $file['original_name'],
                    'size' => (int) $file['file_size'],
                    'mime' => $file['mime_type'],
                    'url' => $fileUrl,
                    'markdown' => '![' . $file['original_name'] . '](' . $fileUrl . ')',
                    'html' => '<img src="' . $fileUrl . '" alt="' . htmlspecialchars($file['original_name'], ENT_QUOTES, 'UTF-8') . '">',
                    'bbcode' => '[img]' . $fileUrl . '[/img]',
                ],
            ]);
        } catch (\Throwable $e) {
            (new UploadFailureService())->record($user['id'], isset($type) ? $type : 'api', isset($_FILES['file']) ? $_FILES['file'] : [], $e->getMessage());
            $this->apiUploadError($user, $e->getMessage(), 422);
        }
    }

    public function files()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'files');
        $page = max(1, (int) (isset($_POST['page']) ? $_POST['page'] : 1));
        $limit = min(100, max(1, (int) (isset($_POST['limit']) ? $_POST['limit'] : 20)));
        $offset = ($page - 1) * $limit;
        $type = isset($_POST['type']) && in_array($_POST['type'], ['image', 'file'], true) ? $_POST['type'] : null;
        $keyword = trim(isset($_POST['keyword']) ? $_POST['keyword'] : '');

        $where = 'WHERE user_id = ?';
        $params = [$user['id']];
        if ($type) {
            $where .= ' AND file_type = ?';
            $params[] = $type;
        }
        if ($keyword !== '') {
            $where .= ' AND (original_name LIKE ? OR file_name LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        $rows = Database::fetchAll(
            'SELECT id, file_type, original_name, file_ext, mime_type, file_size, file_url, thumbnail_url, created_at
             FROM ' . Database::table('files') . ' ' . $where . '
             ORDER BY id DESC' . Database::offsetLimitClause($offset, $limit, 100),
            $params
        );
        foreach ($rows as &$row) {
            $row['file_url'] = public_url($row['file_url']);
            $row['thumbnail_url'] = $row['thumbnail_url'] ? public_url($row['thumbnail_url']) : '';
        }
        unset($row);
        $total = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' ' . $where, $params);
        $this->logApi($user, 'files', 200, true, '获取文件列表');
        $this->json(['success' => true, 'data' => ['page' => $page, 'limit' => $limit, 'total' => (int) $total['c'], 'items' => $rows]]);
    }

    public function delete()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'delete');
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $file = (new FileItem())->find($id);
        if (!$file || (int) $file['user_id'] !== (int) $user['id']) {
            $this->apiError($user, 'delete', '文件不存在。', 404);
        }
        try {
            (new StorageBackupService())->deleteBackupsForFile($file);
            if ($file['storage_id']) {
                $storage = (new StorageDriver())->find((int) $file['storage_id']);
                if ($storage) {
                    StorageManager::make($storage)->delete($file['file_path']);
                }
            }
            Database::execute('DELETE FROM ' . Database::table('files') . ' WHERE id = ?', [$id]);
            Database::execute('UPDATE ' . Database::table('users') . ' SET used_storage = IF(used_storage >= ?, used_storage - ?, 0), updated_at = ? WHERE id = ?', [$file['file_size'], $file['file_size'], now(), $user['id']]);
            (new FileLogService())->log($user['id'], $id, 'api_delete', $file['original_name'], $file['file_size']);
            $this->logApi($user, 'delete', 200, true, '删除文件');
            $this->json(['success' => true, 'message' => '文件已删除。']);
        } catch (\Throwable $e) {
            $this->apiError($user, 'delete', $e->getMessage(), 422);
        }
    }

    public function quota()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'quota');
        $count = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE user_id = ?', [$user['id']]);
        $this->logApi($user, 'quota', 200, true, '获取容量');
        $this->json([
            'success' => true,
            'data' => [
                'used_storage' => (int) $user['used_storage'],
                'total_storage' => (int) $user['total_storage'],
                'used_traffic' => (int) $user['used_traffic'],
                'total_traffic' => (int) $user['total_traffic'],
                'file_count' => (int) $count['c'],
                'balance' => $user['balance'],
            ],
        ]);
    }

    protected function apiUser()
    {
        $apiSchemaReady = $this->apiSchemaReady();
        $limiter = new RateLimitService();
        $ipIdentity = 'ip:' . Auth::ip();
        $limit = $limiter->check('api_auth_ip', $ipIdentity, 600);
        if (!empty($limit['limited'])) {
            $this->logApi(null, 'auth', 429, false, 'API Token 尝试过于频繁');
            $this->json(['success' => false, 'message' => 'API Token 尝试过于频繁，请稍后再试。'], 429);
        }

        $token = isset($_SERVER['HTTP_X_API_TOKEN']) ? trim((string) $_SERVER['HTTP_X_API_TOKEN']) : (isset($_POST['token']) ? trim((string) $_POST['token']) : '');
        if ($token === '') {
            $this->hitApiAuthLimit($limiter, $ipIdentity, 'missing');
            $this->logApi(null, 'auth', 401, false, 'API Token 缺失');
            $this->json(['success' => false, 'message' => 'API Token 缺失。'], 401);
        }
        if (!$this->validApiTokenFormat($token)) {
            $this->hitApiAuthLimit($limiter, $ipIdentity, 'malformed');
            $this->logApi(null, 'auth', 401, false, 'API Token format rejected');
            $this->json(['success' => false, 'message' => 'API Token format rejected.'], 401);
        }
        $tokenHash = $apiSchemaReady ? hash('sha256', $token) : '';
        $apiAppService = new ApiAppService();
        $appContext = $apiSchemaReady ? $this->apiAppContext($apiAppService, $token) : null;
        if ($appContext) {
            $user = $appContext['user'];
            $user['_api_app'] = $appContext['app'];
            $user['_api_app_id'] = (int) $appContext['app']['id'];
        } elseif ($apiSchemaReady) {
            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE (api_token_hash = ? OR api_token = ?) AND status = 1 LIMIT 1', [$tokenHash, $token]);
        } else {
            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE api_token = ? AND status = 1 LIMIT 1', [$token]);
        }
        if (!$user) {
            $this->hitApiAuthLimit($limiter, $ipIdentity, 'invalid');
            $this->logApi(null, 'auth', 401, false, 'API Token 无效');
            $this->json(['success' => false, 'message' => 'API Token 无效。'], 401);
        }
        if ($apiSchemaReady && !$appContext) {
            $this->protectApiToken($user, $token, $tokenHash);
        }
        $limiter->clear('api_auth_ip', $ipIdentity);
        if ($appContext) {
            if (!$apiAppService->ipAllowed($appContext['app'], Auth::ip())) {
                $this->apiError($user, 'auth', '当前 IP 不在应用 Token 白名单内。', 403);
            }
            $scope = $this->currentApiScope();
            if (!$apiAppService->scopeAllowed($appContext['app'], $scope)) {
                $this->apiError($user, $scope, '应用 Token 没有调用该接口的权限。', 403);
            }
            $apiAppService->touchLastUsed((int) $appContext['app']['id']);
        } elseif (!$this->apiIpAllowed($user)) {
            $this->apiError($user, 'auth', '当前 IP 不在 API 白名单。', 403);
        }
        return $user;
    }

    protected function apiAppContext(ApiAppService $service, $token)
    {
        try {
            return $service->findByToken($token);
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function currentApiScope()
    {
        $path = parse_url(isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
        $map = [
            '/api/upload' => 'upload',
            '/api/files' => 'files',
            '/api/delete' => 'delete',
            '/api/quota' => 'quota',
        ];
        return isset($map[$path]) ? $map[$path] : '';
    }

    protected function handleAppMutation($action)
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->ensureFeatureReady(
            $this->apiSchemaReady(),
            'API 应用 Token',
            $this->apiAppsBackPath(),
            'API 应用 Token 数据结构未准备完成，请管理员进入后台「数据库巡检」执行一键修复。'
        )) {
            return;
        }

        $service = new ApiAppService();
        $userId = (int) Auth::id();
        $back = $this->apiAppsBackPath();
        try {
            if ($action === 'create') {
                $result = $service->create(
                    $userId,
                    isset($_POST['name']) ? $_POST['name'] : '',
                    isset($_POST['scopes']) ? $_POST['scopes'] : [],
                    isset($_POST['allowed_ips']) ? $_POST['allowed_ips'] : ''
                );
                $_SESSION['api_app_plain_token'] = [
                    'name' => isset($result['app']['name']) ? $result['app']['name'] : '应用 Token',
                    'token' => $result['token'],
                    'created_at' => now(),
                ];
                set_flash('success', '应用 Token 已创建，请立即复制明文 Token。');
            } elseif ($action === 'update') {
                $service->update(
                    $userId,
                    isset($_POST['id']) ? (int) $_POST['id'] : 0,
                    isset($_POST['name']) ? $_POST['name'] : '',
                    isset($_POST['scopes']) ? $_POST['scopes'] : [],
                    isset($_POST['allowed_ips']) ? $_POST['allowed_ips'] : '',
                    !empty($_POST['status']) ? 1 : 0
                );
                set_flash('success', '应用 Token 已更新。');
            } elseif ($action === 'rotate') {
                $result = $service->rotate($userId, isset($_POST['id']) ? (int) $_POST['id'] : 0);
                $_SESSION['api_app_plain_token'] = [
                    'name' => isset($result['app']['name']) ? $result['app']['name'] : '应用 Token',
                    'token' => $result['token'],
                    'created_at' => now(),
                ];
                set_flash('success', '应用 Token 已重置，请同步更新客户端。');
            } elseif ($action === 'delete') {
                $service->delete($userId, isset($_POST['id']) ? (int) $_POST['id'] : 0);
                set_flash('success', '应用 Token 已删除。');
            }
        } catch (\Throwable $e) {
            remember_old();
            set_flash('error', $e->getMessage());
        }
        $this->redirect($back);
    }

    protected function apiAppsBackPath()
    {
        $requestPath = parse_url(isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
        return strpos((string) $requestPath, '/m/') === 0 ? 'm/api' : 'api/console';
    }

    protected function hitApiAuthLimit(RateLimitService $limiter, $identity, $label)
    {
        $limiter->hit('api_auth_ip', $identity, 30, 600, 900, $label . ':' . Auth::ip(), Auth::ip());
    }

    protected function validApiTokenFormat($token)
    {
        $token = (string) $token;
        return strlen($token) >= 16 && strlen($token) <= 128 && preg_match('/^[A-Za-z0-9._:-]+$/', $token);
    }

    protected function protectApiToken(array $user, $token, $tokenHash)
    {
        $stored = isset($user['api_token']) ? (string) $user['api_token'] : '';
        if (CryptoService::isEncrypted($stored) && (string) (isset($user['api_token_hash']) ? $user['api_token_hash'] : '') === (string) $tokenHash) {
            return;
        }
        Database::execute(
            'UPDATE ' . Database::table('users') . ' SET api_token = ?, api_token_hash = ?, updated_at = ? WHERE id = ?',
            [CryptoService::encrypt($token), $tokenHash, now(), $user['id']]
        );
    }

    protected function assertApiAllowed(array $user)
    {
        $package = Database::fetch('SELECT allow_api FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        if (!$package || (int) $package['allow_api'] !== 1) {
            $this->apiError($user, 'auth', '当前套餐不允许 API 调用。', 403);
        }
    }

    protected function rateLimit(array $user, $endpoint)
    {
        $perMinute = (int) setting('api_rate_limit_per_minute', 60);
        $perDay = (int) setting('api_rate_limit_per_day', 1000);
        if ($perMinute > 0) {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('api_logs') . ' WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)', [$user['id']]);
            if ((int) $row['c'] >= $perMinute) {
                $this->apiError($user, $endpoint, 'API 调用过于频繁，请稍后再试。', 429);
            }
        }
        if ($perDay > 0) {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('api_logs') . ' WHERE user_id = ? AND created_at >= CURDATE()', [$user['id']]);
            if ((int) $row['c'] >= $perDay) {
                $this->apiError($user, $endpoint, '今日 API 调用次数已达上限。', 429);
            }
        }
    }

    protected function apiError($user, $endpoint, $message, $status)
    {
        $this->logApi($user ?: null, $endpoint, $status, false, $message);
        $this->json(['success' => false, 'message' => $message], $status);
    }

    protected function apiUploadError($user, $message, $status)
    {
        $payload = (new UploadFailureService())->payload($message);
        if ($payload['error_type'] === 'php_upload_limit') {
            $payload['repair_url'] = url('admin/maintenance/environment');
        } elseif ($payload['error_type'] === 'quota_or_permission') {
            $payload['repair_url'] = url('packages');
        } elseif (in_array($payload['error_type'], ['storage_config', 'storage_upload', 'storage_url', 'storage_delete'], true)) {
            $payload['storage_url'] = url('admin/storages');
            $payload['repair_url'] = url('admin/storages');
        } elseif (in_array($payload['error_type'], ['schema', 'storage_db'], true)) {
            $payload['repair_url'] = url('admin/maintenance/schema-audit');
        }
        $this->logApi($user ?: null, 'upload', $status, false, $payload['message']);
        $this->json(['success' => false] + $payload, $status);
    }

    protected function apiIpAllowed(array $user)
    {
        $allowed = trim((string) (isset($user['api_allowed_ips']) ? $user['api_allowed_ips'] : ''));
        if ($allowed === '') {
            return true;
        }
        $current = Auth::ip();
        foreach (preg_split('/[\s,;]+/', $allowed) as $ip) {
            if (trim($ip) === $current) {
                return true;
            }
        }
        return false;
    }

    protected function logApi($userId, $endpoint, $status, $success, $message)
    {
        try {
            $appId = null;
            if (is_array($userId)) {
                $appId = isset($userId['_api_app_id']) ? (int) $userId['_api_app_id'] : null;
                $userId = isset($userId['id']) ? (int) $userId['id'] : null;
            }
            if (Database::columnExists(Database::table('api_logs'), 'app_id')) {
                Database::execute(
                    'INSERT INTO ' . Database::table('api_logs') . ' (user_id, app_id, endpoint, method, ip, status_code, is_success, message, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
                    [$userId, $appId, text_limit((string) $endpoint, 60), isset($_SERVER['REQUEST_METHOD']) ? text_limit((string) $_SERVER['REQUEST_METHOD'], 12) : 'POST', \App\Core\Auth::ip(), $status, $success ? 1 : 0, text_limit((string) $message, 500), now()]
                );
                return;
            }
            Database::execute(
                'INSERT INTO ' . Database::table('api_logs') . ' (user_id, endpoint, method, ip, status_code, is_success, message, created_at) VALUES (?,?,?,?,?,?,?,?)',
                [$userId, text_limit((string) $endpoint, 60), isset($_SERVER['REQUEST_METHOD']) ? text_limit((string) $_SERVER['REQUEST_METHOD'], 12) : 'POST', \App\Core\Auth::ip(), $status, $success ? 1 : 0, text_limit((string) $message, 500), now()]
            );
        } catch (\Throwable $e) {
            // API log failure must not break upload/list/delete responses.
        }
    }

    protected function apiSchemaReady()
    {
        try {
            return (bool) DatabaseUpgradeService::ensureApiSecuritySchema();
        } catch (\Throwable $e) {
            return false;
        }
    }

    protected function currentApiUserForDownload()
    {
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [Auth::id()]) ?: Auth::user();
        if ($user && isset($user['api_token'])) {
            $user['api_token'] = CryptoService::decrypt($user['api_token']);
        }
        return $user;
    }

    protected function integrationEndpoints()
    {
        return [
            'upload' => public_url('api/upload'),
            'files' => public_url('api/files'),
            'delete' => public_url('api/delete'),
            'quota' => public_url('api/quota'),
        ];
    }

    protected function sharexConfigPayload(array $user)
    {
        $endpoints = $this->integrationEndpoints();
        return [
            'Version' => '17.0.0',
            'Name' => app_brand_name() . ' Image Upload',
            'DestinationType' => 'ImageUploader, FileUploader',
            'RequestMethod' => 'POST',
            'RequestURL' => $endpoints['upload'],
            'Headers' => [
                'X-API-Token' => isset($user['api_token']) ? (string) $user['api_token'] : '',
            ],
            'Body' => 'MultipartFormData',
            'FileFormName' => 'file',
            'Arguments' => [
                'type' => 'image',
            ],
            'URL' => '$json:data.url$',
            'ThumbnailURL' => '$json:data.url$',
            'DeletionURL' => '',
            'ErrorMessage' => '$json:message$',
        ];
    }

    protected function picgoConfigPayload(array $user)
    {
        $endpoints = $this->integrationEndpoints();
        return [
            'name' => app_brand_name() . ' PicGo',
            'type' => 'customUploader',
            'request' => [
                'url' => $endpoints['upload'],
                'method' => 'POST',
                'headers' => [
                    'X-API-Token' => isset($user['api_token']) ? (string) $user['api_token'] : '',
                ],
                'formData' => [
                    'type' => 'image',
                ],
                'fileName' => 'file',
            ],
            'response' => [
                'successPath' => 'success',
                'urlPath' => 'data.url',
                'messagePath' => 'message',
            ],
            'tips' => [
                'PicGo 自定义上传插件版本较多，如字段不一致，请以接口地址、文件字段 file、Header X-API-Token、返回 data.url 为准。',
            ],
        ];
    }

    protected function downloadJson($filename, array $payload)
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '-', $filename) . '"');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }
}
