<?php
use App\Core\Config;
use App\Core\Csrf;
use App\Core\Database;

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function text_chars($value)
{
    $value = (string) $value;
    if ($value === '') {
        return [];
    }
    if (function_exists('preg_match_all') && @preg_match_all('/./us', $value, $matches)) {
        return $matches[0];
    }
    return str_split($value);
}

function text_limit($value, $length, $suffix = '')
{
    $value = (string) $value;
    $length = max(0, (int) $length);
    if ($length === 0 || $value === '') {
        return '';
    }
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        return mb_strlen($value, 'UTF-8') > $length
            ? mb_substr($value, 0, $length, 'UTF-8') . $suffix
            : $value;
    }
    $chars = text_chars($value);
    if (count($chars) <= $length) {
        return $value;
    }
    return implode('', array_slice($chars, 0, $length)) . $suffix;
}

function text_lower($value)
{
    $value = (string) $value;
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function text_initial($value, $fallback = 'B')
{
    $value = trim(strip_tags((string) $value));
    if ($value === '') {
        return (string) $fallback;
    }
    $initial = text_limit($value, 1);
    return preg_match('/^[a-z]$/', $initial) ? strtoupper($initial) : $initial;
}

function url($path = '')
{
    $base = rtrim(Config::get('app.base_url', ''), '/');
    $path = '/' . ltrim((string) $path, '/');
    return $base . $path;
}

if (!function_exists('bm_request_host')) {
    function bm_request_host()
    {
        $raw = isset($_SERVER['HTTP_HOST']) ? trim((string) $_SERVER['HTTP_HOST']) : '';
        if ($raw === '') {
            return '';
        }
        $raw = preg_replace('/[\x00-\x1F\x7F].*$/', '', $raw);
        $host = parse_url('http://' . $raw, PHP_URL_HOST);
        $port = parse_url('http://' . $raw, PHP_URL_PORT);
        if (!$host) {
            return '';
        }
        $host = strtolower($host);
        $plainHost = trim($host, '[]');
        $validIp = filter_var($plainHost, FILTER_VALIDATE_IP) !== false;
        $validDomain = preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/', $host);
        if (!$validIp && !$validDomain) {
            return '';
        }
        if ($port !== null) {
            $port = (int) $port;
            if ($port <= 0 || $port > 65535) {
                return '';
            }
            return $host . ':' . $port;
        }
        return $host;
    }
}

function public_url($path = '')
{
    $path = trim((string) $path);
    if ($path !== '' && preg_match('#^https?://#i', $path)) {
        return $path;
    }

    $base = trim((string) setting('site_public_url', ''));
    if ($base === '') {
        $configBase = trim((string) Config::get('app.base_url', ''));
        $requestHost = bm_request_host();
        if ($configBase !== '' && strpos($configBase, '/') === 0 && $requestHost !== '') {
            $https = function_exists('bm_is_https_request') ? bm_is_https_request() : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443));
            $base = ($https ? 'https://' : 'http://') . $requestHost . $configBase;
        } else {
            $base = $configBase;
        }
    }
    if ($base === '') {
        $requestHost = bm_request_host();
        if ($requestHost !== '') {
            $https = function_exists('bm_is_https_request') ? bm_is_https_request() : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443));
            $base = ($https ? 'https://' : 'http://') . $requestHost;
        }
    }
    if ($base !== '' && !preg_match('#^https?://#i', $base)) {
        $base = 'https://' . $base;
    }
    $base = rtrim($base, '/');

    if ($path === '') {
        return $base !== '' ? $base : url('/');
    }
    if (strpos($path, '//') === 0) {
        return '';
    }
    $path = '/' . ltrim($path, '/');
    return $base !== '' ? $base . $path : url($path);
}

function asset($path)
{
    $path = str_replace('\\', '/', ltrim((string) $path, '/'));
    $assetUrl = url('assets/' . $path);
    $assetsRoot = realpath(APP_ROOT . '/public/assets');
    $localFile = $assetsRoot ? realpath($assetsRoot . '/' . $path) : false;

    if ($assetsRoot && $localFile && is_file($localFile) && strpos($localFile, $assetsRoot . DIRECTORY_SEPARATOR) === 0) {
        return $assetUrl . '?v=' . filemtime($localFile);
    }

    return $assetUrl;
}

function favicon_tags()
{
    $ico = url('favicon.ico');
    return implode("\n    ", [
        '<link rel="icon" href="' . e($ico) . '" sizes="any">',
        '<link rel="icon" type="image/svg+xml" href="' . e(asset('icons/favicon.svg')) . '">',
        '<link rel="icon" type="image/png" sizes="32x32" href="' . e(asset('icons/favicon-32x32.png')) . '">',
        '<link rel="icon" type="image/png" sizes="16x16" href="' . e(asset('icons/favicon-16x16.png')) . '">',
        '<link rel="apple-touch-icon" sizes="180x180" href="' . e(asset('icons/apple-touch-icon.png')) . '">',
        '<link rel="manifest" href="' . e(url('site.webmanifest')) . '">',
        '<meta name="theme-color" content="#0f172a">',
    ]);
}

function app_brand_name()
{
    return \App\Services\BrandProtectionService::brandName();
}

function app_version()
{
    return \App\Services\BrandProtectionService::version();
}

function app_copyright_text()
{
    return \App\Services\BrandProtectionService::copyrightText();
}

function csrf_field()
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

function csrf_token()
{
    return Csrf::token();
}

function flash($key, $default = null)
{
    if (!isset($_SESSION['_flash'][$key])) {
        return $default;
    }
    $value = $_SESSION['_flash'][$key];
    unset($_SESSION['_flash'][$key]);
    return $value;
}

function set_flash($key, $value)
{
    $_SESSION['_flash'][$key] = $value;
}

function old($key, $default = '')
{
    return isset($_SESSION['_old'][$key]) ? $_SESSION['_old'][$key] : $default;
}

function remember_old()
{
    $old = $_POST;
    foreach (array_keys($old) as $key) {
        $normalized = strtolower((string) $key);
        if ($normalized === '_token' || strpos($normalized, 'password') !== false || strpos($normalized, 'token') !== false || strpos($normalized, 'secret') !== false || strpos($normalized, 'key') !== false) {
            unset($old[$key]);
        }
    }
    $_SESSION['_old'] = $old;
}

function clear_old()
{
    unset($_SESSION['_old']);
}

function format_bytes($bytes)
{
    $bytes = (float) $bytes;
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, $i === 0 ? 0 : 2) . ' ' . $units[$i];
}

function setting($key, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        if (file_exists(APP_ROOT . '/config/database.php')) {
            try {
                $rows = Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings'));
                foreach ($rows as $row) {
                    $cache[$row['setting_key']] = $row['setting_value'];
                }
            } catch (\Throwable $e) {
                $cache = [];
            }
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function now()
{
    return date('Y-m-d H:i:s');
}

function status_label($status)
{
    $map = [
        'online' => '在线',
        'offline' => '离线',
        'unknown' => '未知',
    ];
    return isset($map[$status]) ? $map[$status] : (string) $status;
}

function service_label($status)
{
    $map = [
        'running' => '运行中',
        'stopped' => '已停止',
        'unknown' => '未知',
        'online' => '在线',
        'offline' => '离线',
    ];
    return isset($map[$status]) ? $map[$status] : (string) $status;
}

function service_badge_class($status)
{
    if ($status === 'running' || $status === 'online') {
        return 'service-badge ok';
    }
    if ($status === 'stopped' || $status === 'offline') {
        return 'service-badge bad';
    }
    return 'service-badge muted';
}

function alert_level_label($level)
{
    $map = [
        'info' => '信息',
        'warning' => '警告',
        'danger' => '严重',
    ];
    return isset($map[$level]) ? $map[$level] : (string) $level;
}

function alert_status_label($status)
{
    $map = [
        'unread' => '未读',
        'read' => '已读',
        'resolved' => '已处理',
    ];
    return isset($map[$status]) ? $map[$status] : (string) $status;
}
