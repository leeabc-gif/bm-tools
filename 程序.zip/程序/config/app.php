<?php
return [
    'name' => 'BM TOOLS',
    'version' => '1.0.0',
    'debug' => false,
    'base_url' => '',
    'timezone' => 'Asia/Shanghai',
    'upload' => [
        'image_ext' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'],
        'file_ext' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'zip', 'rar', '7z', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'mp4', 'mp3', 'txt', 'md'],
    ],
    'security' => [
        'secret_key' => 'bm-tools-change-this-secret-key',
    ],
    'brand' => [
        'admin_copyright' => 'Powered by BM ucloud tools',
    ],
];
