#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = process.cwd();
const results = [];

function exists(file) {
  return fs.existsSync(path.join(root, file));
}

function read(file) {
  return fs.readFileSync(path.join(root, file), 'utf8');
}

function checkByteOrderMarks() {
  const issues = [];
  const roots = ['app', 'public', 'config', 'database', 'tools'];
  const textFile = /\.(?:php|css|js|sql|json|md|txt|conf|htaccess)$/i;

  for (const directory of roots) {
    for (const file of walk(directory, (item) => textFile.test(item))) {
      const bytes = fs.readFileSync(path.join(root, file));
      if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
        issues.push(file + ' starts with UTF-8 BOM');
      }
    }
  }

  for (const file of ['.htaccess', 'bt-nginx-rewrite.conf', 'index.php', 'cron_monitor.php']) {
    if (!exists(file)) continue;
    const bytes = fs.readFileSync(path.join(root, file));
    if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
      issues.push(file + ' starts with UTF-8 BOM');
    }
  }

  if (issues.length) return fail('byte order marks', issues.join('\n'));
  pass('byte order marks', 'PHP and asset text files start without UTF-8 BOM');
}

function walk(dir, matcher) {
  const base = path.join(root, dir);
  if (!fs.existsSync(base)) return [];
  const output = [];
  for (const name of fs.readdirSync(base)) {
    const file = path.join(base, name);
    const stat = fs.statSync(file);
    if (stat.isDirectory()) {
      output.push(...walk(path.relative(root, file), matcher));
    } else if (!matcher || matcher(file)) {
      output.push(path.relative(root, file).replace(/\\/g, '/'));
    }
  }
  return output;
}

function pass(name, detail) {
  results.push({ ok: true, name, detail: detail || '' });
}

function fail(name, detail) {
  results.push({ ok: false, name, detail: detail || '' });
}

function routeBlocks(router) {
  const blocks = {};
  for (const method of ['GET', 'POST']) {
    const match = router.match(new RegExp("'" + method + "'\\s*=>\\s*\\[([\\s\\S]*?)\\n\\s*\\]", 'm'));
    blocks[method] = match ? match[1] : '';
  }
  return blocks;
}

function checkRoutes() {
  const routerFile = 'app/Core/Router.php';
  if (!exists(routerFile)) return fail('routes', 'app/Core/Router.php not found');
  const router = read(routerFile);
  const blocks = routeBlocks(router);
  const targetIssues = [];
  const duplicateIssues = [];

  for (const method of Object.keys(blocks)) {
    const paths = [];
    for (const match of blocks[method].matchAll(/['"](\/[A-Za-z0-9_.\-\/]+)['"]\s*=>\s*['"]([A-Za-z0-9_]+)@([A-Za-z0-9_]+)['"]/g)) {
      paths.push(match[1]);
      const controllerFile = 'app/Controllers/' + match[2] + '.php';
      if (!exists(controllerFile)) {
        targetIssues.push(method + ' ' + match[1] + ' missing controller ' + controllerFile);
        continue;
      }
      const source = read(controllerFile);
      const methodPattern = new RegExp('function\\s+' + match[3] + '\\s*\\(');
      if (!methodPattern.test(source)) {
        targetIssues.push(method + ' ' + match[1] + ' missing method ' + match[2] + '@' + match[3]);
      }
    }
    const seen = new Set();
    for (const routePath of paths) {
      if (seen.has(routePath)) duplicateIssues.push(method + ' ' + routePath);
      seen.add(routePath);
    }
  }

  if (targetIssues.length || duplicateIssues.length) {
    return fail('routes', targetIssues.concat(duplicateIssues).join('\n'));
  }
  pass('routes', 'route targets and duplicate paths are clean');
}

function checkViews() {
  const issues = [];
  for (const file of walk('app/Controllers', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const match of source.matchAll(/->(?:adminView|view)\(\s*['"]([^'"]+)['"]/g)) {
      const view = 'app/Views/' + match[1] + '.php';
      if (!exists(view)) issues.push(file + ' references missing view ' + view);
    }
  }
  for (const layout of ['layouts/app', 'layouts/admin', 'layouts/auth', 'layouts/install', 'layouts/status', 'layouts/announcement']) {
    const file = 'app/Views/' + layout + '.php';
    if (!exists(file)) issues.push('missing layout ' + file);
  }
  if (issues.length) return fail('views', issues.join('\n'));
  pass('views', 'controller view references are present');
}

function checkViewLinks() {
  const routerFile = 'app/Core/Router.php';
  if (!exists(routerFile)) return fail('view links', 'app/Core/Router.php not found');

  const routes = new Set(['/']);
  for (const match of read(routerFile).matchAll(/['"](\/[A-Za-z0-9_.\-\/]+)['"]\s*=>/g)) {
    routes.add(match[1].replace(/\/$/, '') || '/');
  }

  const issues = [];
  for (const file of walk('app/Views', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const match of source.matchAll(/url\(\s*['"]([^'"]+)['"]\s*\)/g)) {
      let routePath = match[1] === '' ? '/' : match[1];
      if (routePath.includes('?') || routePath.includes('#') || /^https?:/i.test(routePath)) continue;
      if (!routePath.startsWith('/')) routePath = '/' + routePath;
      routePath = routePath.replace(/\/$/, '') || '/';
      if (!routes.has(routePath)) issues.push(file + ' links to missing route ' + routePath);
    }
  }

  if (issues.length) return fail('view links', [...new Set(issues)].join('\n'));
  pass('view links', 'literal view urls map to registered routes');
}

function controllerRoutes(method = 'GET') {
  const routerFile = 'app/Core/Router.php';
  const routes = {};
  if (!exists(routerFile)) return routes;
  const blocks = routeBlocks(read(routerFile));
  const block = blocks[method] || '';
  for (const match of block.matchAll(/['"](\/[A-Za-z0-9_.\-\/]+)['"]\s*=>\s*['"]([A-Za-z0-9_]+)@([A-Za-z0-9_]+)['"]/g)) {
    routes[match[1].replace(/\/$/, '') || '/'] = { controller: match[2], method: match[3] };
  }
  return routes;
}

function methodBody(source, name) {
  const match = new RegExp('function\\s+' + name + '\\s*\\([^)]*\\)\\s*\\{').exec(source);
  if (!match) return '';
  let index = match.index + match[0].length;
  let depth = 1;
  while (index < source.length && depth > 0) {
    const char = source[index++];
    if (char === '{') depth += 1;
    if (char === '}') depth -= 1;
  }
  return source.slice(match.index, index);
}

function checkAdminMenus() {
  const issues = [];
  const layoutFile = 'app/Views/layouts/admin.php';
  const adminFile = 'app/Controllers/AdminController.php';
  const routerFile = 'app/Core/Router.php';
  if (!exists(layoutFile)) return fail('admin menus', 'admin layout missing');
  if (!exists(adminFile)) return fail('admin menus', 'AdminController missing');
  if (!exists(routerFile)) return fail('admin menus', 'router missing');

  const layout = read(layoutFile);
  const admin = read(adminFile);
  const router = read(routerFile);
  const routes = controllerRoutes('GET');

  for (const marker of ['admin_badge_table_exists', 'catch (\\Throwable $e)', 'file_storage_backups']) {
    if (!layout.includes(marker)) {
      issues.push('admin layout badge queries are missing safety marker: ' + marker);
    }
  }
  for (const marker of ["strpos($uri, '/admin') === 0", "Auth::check()", '当前账号没有后台管理权限', 'ensureRuntimeSchema()', 'repair_url', 'catch (\\Throwable $e)', '后台入口预检查失败']) {
    if (!router.includes(marker)) {
      issues.push('router admin entry guard missing marker: ' + marker);
    }
  }

  const seen = new Set();
  for (const match of layout.matchAll(/\[\s*['"]path['"]\s*=>\s*['"]([^'"]+)['"]\s*,\s*['"]url['"]\s*=>\s*['"]([^'"]+)['"]/g)) {
    const menuPath = normalizeRoute(match[1]);
    const menuUrl = normalizeRoute(match[2].split(/[?#]/)[0]);
    const key = menuPath + '|' + menuUrl;
    if (seen.has(key)) continue;
    seen.add(key);
    if (menuPath !== menuUrl) {
      issues.push('admin menu path/url mismatch: ' + menuPath + ' -> ' + menuUrl);
    }
    const target = routes[menuUrl];
    if (!target) {
      issues.push('admin menu url has no GET route: ' + menuUrl);
      continue;
    }
    const controllerFile = 'app/Controllers/' + target.controller + '.php';
    if (!exists(controllerFile)) {
      issues.push('admin menu target controller missing: ' + controllerFile);
      continue;
    }
    const controller = read(controllerFile);
    if (!new RegExp('function\\s+' + target.method + '\\s*\\(').test(controller)) {
      issues.push('admin menu target method missing: ' + menuUrl + ' -> ' + target.controller + '@' + target.method);
    }
  }

  const guardedGetMethods = ['storageBackups', 'storageBackupTasks', 'storageBackupBackfill'];
  for (const name of guardedGetMethods) {
    const body = methodBody(admin, name);
    const hasStorageBackupGuard = body.includes('ensureStorageBackupSchema()')
      || (body.includes('safeSchemaReady') && body.includes('ensureStorageBackupSchema'));
    if (!body.includes('ensureAdminFeatureSchema') || !hasStorageBackupGuard) {
      issues.push('AdminController@' + name + ' must render a repair page when storage backup schema is not ready');
    }
  }
  const guardedPostMethods = ['saveStorageBackupPolicy', 'deleteStorageBackupPolicy', 'retryStorageBackup', 'retryFailedStorageBackups', 'runStorageBackupBackfill'];
  for (const name of guardedPostMethods) {
    const body = methodBody(admin, name);
    if (!body.includes('ensureStorageBackupSchemaOrRedirect')) {
      issues.push('AdminController@' + name + ' must redirect to schema repair when storage backup schema is not ready');
    }
  }
  const featureGuardMethods = [
    'coupons',
    'cards',
    'repositories',
    'repositoryDetail',
    'subsites',
    'serverOps',
    'sshSessions',
    'commandLogs',
    'monitors',
    'announcements',
    'themes',
  ];
  for (const name of featureGuardMethods) {
    const body = methodBody(admin, name);
    if (!body.includes('ensureAdminFeatureSchema')) {
      issues.push('AdminController@' + name + ' must show the schema repair page when its feature schema is not ready');
    }
  }
  if (!methodBody(admin, 'apiLogs').includes('ensureAdminTables')) {
    issues.push('AdminController@apiLogs must show the schema repair page when api_logs is missing');
  }
  if (!admin.includes('function ensureAdminTables')) {
    issues.push('AdminController missing ensureAdminTables helper');
  }
  if (!admin.includes('function ensureAdminFeatureSchemaOrRedirect')) {
    issues.push('AdminController missing POST/action schema redirect helper');
  }
  if (!admin.includes('function ensureStorageDriverSchemaReady')) {
    issues.push('AdminController missing storage driver schema guard helper');
  }

  const extraGetGuardMethods = [
    'packages',
    'storages',
    'storageIntegrations',
    'serverOpsSettings',
  ];
  for (const name of extraGetGuardMethods) {
    const body = methodBody(admin, name);
    if (!body.includes('ensureAdminFeatureSchema')) {
      issues.push('AdminController@' + name + ' must show the schema repair page when its feature schema is not ready');
    }
  }
  const storageDriverGetMethods = [
    'storages',
    'storageIntegrations',
    'storageBackups',
    'storageBackupTasks',
    'storageBackupBackfill',
  ];
  for (const name of storageDriverGetMethods) {
    const body = methodBody(admin, name);
    if (!body.includes('ensureStorageDriverSchemaReady')) {
      issues.push('AdminController@' + name + ' must verify storage driver schema before querying storage drivers');
    }
  }
  const actionGuardMethods = [
    'savePackage',
    'generateCards',
    'updateCardStatus',
    'deleteCard',
    'saveCoupon',
    'deleteCoupon',
    'saveStorage',
    'testStorage',
    'setDefaultStorage',
    'deleteStorage',
    'saveSubsiteSettings',
    'updateSubsiteStatus',
    'checkSubsiteDomain',
    'deleteSubsite',
    'saveServerOpsSettings',
    'repositoryStatus',
    'deleteRepository',
    'clearRepositoryLogs',
    'toggleMonitor',
    'collectMonitor',
    'saveMonitor',
    'testMonitor',
    'deleteMonitor',
    'resolveAlert',
    'saveAnnouncement',
    'deleteAnnouncement',
    'saveThemes',
  ];
  for (const name of actionGuardMethods) {
    const body = methodBody(admin, name);
    if (!body.includes('ensureAdminFeatureSchemaOrRedirect')) {
      issues.push('AdminController@' + name + ' must redirect/json to schema repair before running feature actions');
    }
  }

  if (!exists('app/Views/admin/schema_repair_required.php')) {
    issues.push('missing admin schema repair required view');
  }

  if (issues.length) return fail('admin menus', [...new Set(issues)].join('\n'));
  pass('admin menus', 'left menu routes, badge safety and storage backup repair guards are present');
}

function routeSets() {
  const router = read('app/Core/Router.php');
  const sets = { GET: new Set(['/']), POST: new Set() };
  for (const method of Object.keys(sets)) {
    const match = router.match(new RegExp("'" + method + "'\\s*=>\\s*\\[([\\s\\S]*?)\\n\\s*\\]", 'm'));
    if (!match) continue;
    for (const route of match[1].matchAll(/['"](\/[A-Za-z0-9_.\-\/]+)['"]\s*=>/g)) {
      sets[method].add(route[1].replace(/\/$/, '') || '/');
    }
  }
  return sets;
}

function normalizeRoute(routePath) {
  routePath = routePath === '' ? '/' : routePath;
  if (!routePath.startsWith('/')) routePath = '/' + routePath;
  return routePath.replace(/\/$/, '') || '/';
}

function checkFormActions() {
  const routes = routeSets();
  const issues = [];

  for (const file of walk('app/Views', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const match of source.matchAll(/<form\b[\s\S]*?>/ig)) {
      const tag = match[0];
      const methodMatch = tag.match(/method=["']([^"']+)["']/i);
      const method = (methodMatch ? methodMatch[1] : 'GET').toUpperCase();
      const actionMatch = tag.match(/action=["']<\?=\s*url\(['"]([^'"]+)['"]\)\s*\?>["']/i);
      if (!actionMatch) continue;
      const routePath = normalizeRoute(actionMatch[1]);
      const methodRoutes = routes[method] || routes.GET;
      if (!methodRoutes.has(routePath)) {
        issues.push(file + ' ' + method + ' form action has no route: ' + routePath);
      }
    }
  }

  if (issues.length) return fail('form actions', [...new Set(issues)].join('\n'));
  pass('form actions', 'literal form actions map to matching routes');
}

function checkRedirects() {
  const routes = routeSets();
  const issues = [];

  for (const file of walk('app/Controllers', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const match of source.matchAll(/->redirect\(\s*['"]([^'"]+)['"]\s*\)/g)) {
      const routePath = normalizeRoute(match[1]);
      if (!routes.GET.has(routePath)) {
        issues.push(file + ' redirects to missing GET route: ' + routePath);
      }
    }
  }

  if (issues.length) return fail('redirects', [...new Set(issues)].join('\n'));
  pass('redirects', 'literal controller redirects map to GET routes');
}

function checkAssets() {
  const issues = [];
  for (const file of walk('app/Views', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const match of source.matchAll(/asset\(\s*['"]([^'"]+)['"]\s*\)/g)) {
      const assetPath = 'public/assets/' + match[1].replace(/^\//, '');
      if (!exists(assetPath)) issues.push(file + ' references missing asset ' + assetPath);
    }
  }
  if (issues.length) return fail('assets', [...new Set(issues)].join('\n'));
  pass('assets', 'literal asset references exist');
}

function checkLayoutMeta() {
  const issues = [];
  for (const file of walk('app/Views/layouts', (item) => item.endsWith('.php'))) {
    const source = read(file);
    if (!source.includes('charset="utf-8"') && !source.includes('charset=utf-8')) {
      issues.push(file + ' missing utf-8 charset');
    }
    if (!source.includes('name="viewport"')) {
      issues.push(file + ' missing viewport');
    }
  }
  if (issues.length) return fail('layout meta', issues.join('\n'));
  pass('layout meta', 'all layouts include utf-8 and viewport');
}

function checkCsrf() {
  const issues = [];
  for (const file of walk('app/Views', (item) => item.endsWith('.php'))) {
    const source = read(file);
    const re = /<form\b[\s\S]*?<\/form>/ig;
    let match;
    while ((match = re.exec(source))) {
      const form = match[0];
      if (!/method=["']post["']/i.test(form)) continue;
      if (!form.includes('csrf_field()') && !/name=["']_token["']/.test(form)) {
        issues.push(file + ' POST form near offset ' + match.index + ' has no csrf token');
      }
    }
  }
  if (issues.length) return fail('csrf', issues.join('\n'));
  pass('csrf', 'POST forms include csrf tokens');
}

function templateTags(source, tagName) {
  const tags = [];
  const open = new RegExp('<' + tagName + '\\b', 'ig');
  let match;
  while ((match = open.exec(source))) {
    let index = match.index + match[0].length;
    let quote = '';
    while (index < source.length) {
      const char = source[index];
      if (quote) {
        if (char === quote) quote = '';
      } else if (char === '"' || char === "'") {
        quote = char;
      } else if (char === '>') {
        index += 1;
        break;
      }
      index += 1;
    }
    tags.push({ index: match.index, tag: source.slice(match.index, index) });
    open.lastIndex = index;
  }
  return tags;
}

function checkHtmlDetails() {
  const issues = [];
  for (const file of walk('app/Views', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const image of templateTags(source, 'img')) {
      const tag = image.tag;
      if (!/\balt=/.test(tag)) {
        issues.push(file + ' image near offset ' + image.index + ' is missing alt text');
      }
      if (/\balt=["']\s*["']/.test(tag)) {
        issues.push(file + ' image near offset ' + image.index + ' has empty alt text');
      }
    }
    for (const match of source.matchAll(/<form\b[\s\S]*?<\/form>/ig)) {
      const form = match[0];
      if (/method=["']post["']/i.test(form) && !/action=["'][^"']+["']/i.test(form)) {
        issues.push(file + ' POST form near offset ' + match.index + ' should declare action explicitly');
      }
    }
  }

  if (issues.length) return fail('html details', [...new Set(issues)].join('\n'));
  pass('html details', 'images and POST form details are explicit');
}

function checkCss() {
  const issues = [];
  for (const file of walk('public/assets/css', (item) => item.endsWith('.css'))) {
    const source = read(file);
    const open = (source.match(/\{/g) || []).length;
    const close = (source.match(/\}/g) || []).length;
    if (open !== close) issues.push(file + ' brace mismatch ' + open + '/' + close);
  }
  if (issues.length) return fail('css', issues.join('\n'));
  pass('css', 'css brace counts are balanced');
}

function checkJs() {
  const issues = [];
  for (const file of walk('public/assets/js', (item) => item.endsWith('.js'))) {
    try {
      new vm.Script(read(file), { filename: file });
    } catch (error) {
      issues.push(file + ' ' + error.message);
    }
  }
  if (issues.length) return fail('javascript', issues.join('\n'));
  pass('javascript', 'browser scripts compile');
}

function checkAjaxSafety() {
  const issues = [];
  const appJs = exists('public/assets/js/app.js') ? read('public/assets/js/app.js') : '';
  for (const marker of ['SKY_PARSE_JSON_RESPONSE', 'SKY_AJAX_ERROR_MESSAGE', 'safeJsonMessage', '接口返回了页面内容而不是 JSON']) {
    if (!appJs.includes(marker)) {
      issues.push('app.js missing safe AJAX JSON marker: ' + marker);
    }
  }
  for (const marker of ['SKY_TOAST', 'sky-toast-root', 'showToast']) {
    if (!appJs.includes(marker) && marker !== 'sky-toast-root') {
      issues.push('app.js missing unified toast marker: ' + marker);
    }
  }
  for (const marker of ['SKY_CONFIRM', 'showConfirm', 'inline-confirm-form', 'data-auto-select', 'data-reload-page']) {
    if (!appJs.includes(marker)) {
      issues.push('app.js missing product confirm/select marker: ' + marker);
    }
  }
  const appCss = exists('public/assets/css/app.css') ? read('public/assets/css/app.css') : '';
  for (const marker of ['.sky-toast-root', '.sky-toast', '.sky-toast-success', '.sky-toast-error']) {
    if (!appCss.includes(marker)) {
      issues.push('app.css missing unified toast style marker: ' + marker);
    }
  }
  for (const marker of ['.sky-confirm-backdrop', '.sky-confirm-dialog', '.sky-confirm-actions', '.sky-confirm-danger']) {
    if (!appCss.includes(marker)) {
      issues.push('app.css missing product confirm style marker: ' + marker);
    }
  }
  if (/\balert\s*\(/.test(appJs)) {
    issues.push('app.js should use SKY_TOAST instead of native alert() for product feedback');
  }
  if (/\b(?:window\.)?confirm\s*\(/.test(appJs)) {
    issues.push('app.js should use SKY_CONFIRM instead of native confirm() for destructive actions');
  }

  for (const file of walk('app/Views', (item) => item.endsWith('.php'))) {
    const source = read(file);
    if (source.includes('alert(')) {
      issues.push(file + ' should use SKY_TOAST or inline result panels instead of native alert()');
    }
    if (/\b(?:window\.)?confirm\s*\(/.test(source)) {
      issues.push(file + ' should use SKY_CONFIRM instead of native confirm()');
    }
    if (source.includes('onclick=')) {
      issues.push(file + ' should not use inline onclick handlers; use delegated app.js behaviours');
    }
    if (source.includes('javascript:void')) {
      issues.push(file + ' should not use javascript:void links; use buttons or anchored hrefs');
    }
    if (/开发中|未实现|coming soon|敬请期待|暂不可用|预留|待接入|占位/.test(source)) {
      issues.push(file + ' contains unfinished product wording');
    }
    if (!source.includes('fetch(')) continue;
    if (source.includes('installJson(')) continue;
    if (source.includes('res.json()') && !source.includes('SKY_PARSE_JSON_RESPONSE')) {
      issues.push(file + ' uses fetch/res.json without safe JSON parsing');
    }
  }

  if (appJs.includes('服务器处理上传时出错，请检查对象存储配置或 PHP 错误日志。')) {
    issues.push('app.js still hides upload 500 responses behind the old generic storage error');
  }

  for (const file of walk('app/Controllers', (item) => item.endsWith('.php'))) {
    const source = read(file);
    if (/json\(\s*\[\s*['"]success['"]\s*=>\s*false\s*\]\s*,/.test(source)) {
      issues.push(file + ' returns JSON failure without a message; frontend cannot show an actionable reason');
    }
  }

  const bootstrap = exists('app/bootstrap.php') ? read('app/bootstrap.php') : '';
  for (const marker of ['bm_request_expects_json', 'bm_emit_html_error', 'register_shutdown_function', 'error_id', 'Fatal error #']) {
    if (!bootstrap.includes(marker)) {
      issues.push('bootstrap.php missing AJAX fatal-error response marker: ' + marker);
    }
  }
  if (bootstrap.includes("echo '系统繁忙，请稍后再试。'")) {
    issues.push('bootstrap.php still emits the old generic busy page without an error id');
  }

  if (issues.length) return fail('ajax safety', issues.join('\n'));
  pass('ajax safety', 'fetch JSON parsing, toast and product confirmation guards are present');
}

function checkSchema() {
  if (!exists('database/schema.sql')) return fail('schema', 'database/schema.sql not found');
  const schema = read('database/schema.sql');
  const schemaMap = parseSchema(schema);
  const schemaTables = new Set(Object.keys(schemaMap));
  const codeTables = new Set();
  for (const file of walk('app', (item) => item.endsWith('.php'))) {
    const source = read(file);
    for (const match of source.matchAll(/Database::table\(\s*['"]([A-Za-z0-9_]+)['"]\s*\)/g)) {
      codeTables.add(match[1]);
    }
  }
  const missing = [...codeTables].filter((table) => !schemaTables.has(table)).sort();
  if (missing.length) return fail('schema', 'tables used by code but missing in schema.sql: ' + missing.join(', '));

  const requiredColumns = {
    users: ['id', 'username', 'nickname', 'email', 'password', 'role', 'balance', 'package_id', 'allow_image_override', 'allow_netdisk_override', 'total_storage', 'total_traffic', 'frontend_theme_style', 'admin_theme_style', 'api_token_hash', 'api_allowed_ips', 'status', 'created_at', 'updated_at'],
    packages: ['id', 'name', 'price', 'duration_type', 'storage_limit', 'traffic_limit', 'single_file_limit', 'allow_image', 'allow_netdisk', 'allow_api', 'allow_monitor', 'allow_share', 'allow_subsite', 'subsite_limit', 'status'],
    files: ['id', 'user_id', 'storage_id', 'folder_id', 'file_type', 'file_name', 'original_name', 'file_ext', 'mime_type', 'file_size', 'file_path', 'file_url', 'thumbnail_url', 'md5', 'width', 'height', 'is_public', 'download_count'],
    storage_drivers: ['id', 'name', 'type', 'access_key', 'secret_key', 'bucket', 'region', 'endpoint', 'domain', 'prefix', 'is_enabled', 'is_default', 'is_public'],
    file_repositories: ['id', 'user_id', 'title', 'slug', 'access_type', 'password_hash', 'admin_status', 'admin_remark', 'view_count', 'download_count'],
    monitor_servers: ['id', 'user_id', 'monitor_type', 'name', 'panel_url', 'api_key', 'server_ip', 'ssh_host', 'ssh_port', 'ssh_username', 'ssh_auth_type', 'ssh_password', 'ssh_private_key', 'agent_url', 'agent_token', 'is_enabled', 'frequency', 'status', 'last_error', 'last_checked_at'],
    monitor_metrics: ['id', 'server_id', 'cpu_usage', 'memory_usage', 'disk_usage', 'net_upload', 'net_download', 'raw_data', 'created_at'],
    server_ssh_sessions: ['id', 'user_id', 'server_id', 'token_hash', 'gateway_url', 'status', 'expires_at', 'created_at'],
    server_command_logs: ['id', 'user_id', 'server_id', 'session_id', 'command', 'output_summary', 'exit_status', 'risk_level', 'created_at'],
    server_monitor_pages: ['id', 'user_id', 'server_id', 'title', 'token', 'visibility', 'password_hash', 'show_metrics', 'show_services', 'view_count'],
    server_service_checks: ['id', 'user_id', 'server_id', 'type', 'name', 'target', 'port', 'method', 'status', 'response_time_ms', 'last_error', 'last_checked_at'],
    redeem_cards: ['id', 'batch_no', 'title', 'type', 'code_hash', 'code_preview', 'amount', 'package_id', 'duration_days', 'status', 'used_by', 'used_at'],
    subsites: ['id', 'user_id', 'name', 'slug', 'platform_domain', 'custom_domain', 'custom_domain_status', 'verification_token', 'title', 'subtitle', 'logo', 'theme_color', 'hero_title', 'hero_description', 'announcement', 'contact_email', 'icp_text', 'status', 'is_default', 'view_count', 'last_viewed_at', 'domain_check_result', 'domain_checked_at', 'admin_remark', 'created_at', 'updated_at'],
    subsite_access_logs: ['id', 'subsite_id', 'user_id', 'host', 'path', 'ip', 'user_agent', 'referer', 'created_at'],
    announcements: ['id', 'title', 'content', 'category', 'summary', 'cover_image', 'tags', 'content_format', 'view_count', 'is_top', 'show_home', 'status', 'published_at'],
    settings: ['id', 'setting_key', 'setting_value', 'created_at', 'updated_at'],
  };
  const columnIssues = [];
  for (const table of Object.keys(requiredColumns)) {
    if (!schemaMap[table]) {
      columnIssues.push(table + ' table missing from schema.sql');
      continue;
    }
    for (const column of requiredColumns[table]) {
      if (!schemaMap[table].columns.has(column)) {
        columnIssues.push(table + '.' + column + ' missing from schema.sql');
      }
    }
  }
  if (columnIssues.length) return fail('schema columns', columnIssues.join('\n'));

  pass('schema', 'schema tables=' + schemaTables.size + ', code referenced tables=' + codeTables.size + ', required columns checked=' + Object.keys(requiredColumns).length);
}

function checkSchemaRepairDiagnostics() {
  const issues = [];
  const service = exists('app/Services/DatabaseUpgradeService.php') ? read('app/Services/DatabaseUpgradeService.php') : '';
  const admin = exists('app/Controllers/AdminController.php') ? read('app/Controllers/AdminController.php') : '';
  const view = exists('app/Views/admin/schema_audit.php') ? read('app/Views/admin/schema_audit.php') : '';
  const css = exists('public/assets/css/app.css') ? read('public/assets/css/app.css') : '';

  for (const marker of ['schemaRepairSql', 'databasePrivilegeDiagnostics', 'databasePrivilegeProbe', 'schema_unresolved_count', 'repair_sql', 'SHOW GRANTS FOR CURRENT_USER()', 'standardSchemaReady', 'final_schema_ready']) {
    if (!service.includes(marker)) issues.push('DatabaseUpgradeService missing schema repair diagnostic marker: ' + marker);
  }
  for (const marker of ['schemaIssueCount', '失败项', '权限探针未通过', '待执行 SQL']) {
    if (!admin.includes(marker)) issues.push('AdminController repairSchema missing actionable failure marker: ' + marker);
  }
  for (const marker of ['FAILED TASKS', 'DDL PROBE', 'DATABASE PRIVILEGES', 'REPAIR SQL', 'schema-sql-textarea', '参考授权 SQL']) {
    if (!view.includes(marker)) issues.push('schema_audit.php missing diagnostic UI marker: ' + marker);
  }
  for (const marker of ['schema-sql-details', 'schema-sql-textarea']) {
    if (!css.includes(marker)) issues.push('app.css missing schema diagnostic style marker: ' + marker);
  }

  if (issues.length) return fail('schema repair diagnostics', issues.join('\n'));
  pass('schema repair diagnostics', 'failed tasks, privilege probe and manual repair SQL are visible');
}

function checkRuntimeSafety() {
  const issues = [];
  for (const root of ['app', 'public', 'config', 'database']) {
    if (!exists(root)) continue;
    for (const file of walk(root, (item) => item.endsWith('.php'))) {
      if (file.includes('/vendor/') || file.includes('\\vendor\\')) continue;
      const source = read(file);
      if (/catch\s*\(\s*\\?Exception\s+\$/.test(source)) {
        issues.push(file + ' catches Exception only; use Throwable so PHP runtime errors do not bypass product error handling');
      }
    }
  }

  const controller = exists('app/Core/Controller.php') ? read('app/Core/Controller.php') : '';
  const server = exists('app/Controllers/ServerController.php') ? read('app/Controllers/ServerController.php') : '';
  const monitor = exists('app/Controllers/MonitorController.php') ? read('app/Controllers/MonitorController.php') : '';
  const user = exists('app/Controllers/UserController.php') ? read('app/Controllers/UserController.php') : '';
  const file = exists('app/Controllers/FileController.php') ? read('app/Controllers/FileController.php') : '';
  const agent = exists('app/Controllers/AgentController.php') ? read('app/Controllers/AgentController.php') : '';

  for (const marker of ['function ensureFeatureReady', 'error_type', 'schema', '/cron/', '/api/', '/agent/']) {
    if (!controller.includes(marker)) {
      issues.push('Controller missing feature readiness marker: ' + marker);
    }
  }
  const controllerGuards = [
    [server, 'ServerController', 'ensureServerOpsReady'],
    [monitor, 'MonitorController', 'ensureMonitorReady'],
    [user, 'UserController', 'ensureUserSubsiteReady'],
    [user, 'UserController', 'ensureUserThemeReady'],
    [file, 'FileController', 'ensureFileLogsReady'],
  ];
  for (const [source, name, marker] of controllerGuards) {
    if (!source.includes(marker) || !source.includes('ensureFeatureReady')) {
      issues.push(name + ' missing feature readiness guard: ' + marker);
    }
  }
  if (!agent.includes('ensureFeatureReady') || !agent.includes('Agent 监控上报')) {
    issues.push('AgentController should return a clear schema response when monitor tables are missing');
  }

  if (issues.length) return fail('runtime safety', [...new Set(issues)].join('\n'));
  pass('runtime safety', 'feature schema guards and Throwable catches are in place');
}

function checkBrandProtectionSafety() {
  const issues = [];
  const source = exists('app/Services/BrandProtectionService.php') ? read('app/Services/BrandProtectionService.php') : '';
  const admin = exists('app/Views/layouts/admin.php') ? read('app/Views/layouts/admin.php') : '';

  if (!source) {
    issues.push('BrandProtectionService.php not found');
  } else {
    for (const marker of ['ADMIN_COPYRIGHT_BRAND', 'copyrightText', 'app/Views/layouts/admin.php', 'reportIssues']) {
      if (!source.includes(marker)) issues.push('BrandProtectionService.php missing marker: ' + marker);
    }
    for (const blocker of ['renderLockPage', 'http_response_code(423)', 'exit;', 'die(']) {
      if (source.includes(blocker)) issues.push('BrandProtectionService.php must not block normal site traffic with ' + blocker);
    }
  }

  if (!admin.includes('app_copyright_text()') || !admin.includes('admin-global-footer')) {
    issues.push('admin layout should keep visible admin copyright footer');
  }

  if (issues.length) return fail('brand protection safety', issues.join('\n'));
  pass('brand protection safety', 'admin copyright is checked without locking normal traffic');
}

function parseSchema(schema) {
  const output = {};
  const re = /CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`__PREFIX__([^`]+)`\s*\(([\s\S]*?)\n\)\s*ENGINE/gi;
  for (const match of schema.matchAll(re)) {
    output[match[1]] = {
      body: match[2],
      columns: new Set([...match[2].matchAll(/^\s*`([^`]+)`\s+/gm)].map((m) => m[1])),
    };
  }
  return output;
}

function checkEncodingHealth() {
  const issues = [];
  const mojibake = /(?:鍥|缃|鐢|鏂|绫|锛|涓|煎|悎|惧|簥|彴|厤|绔|鍔|櫒|搴|伅|寮|绋|犲|嗙|椁|嫨|樻|熺|棿|欓|炶)/;
  const files = []
    .concat(walk('app', (item) => /\.(php|css|js)$/i.test(item)))
    .concat(walk('config', (item) => /\.(php|css|js)$/i.test(item)))
    .concat(walk('database', (item) => /\.(sql)$/i.test(item)))
    .concat(walk('public', (item) => /\.(php|css|js|html)$/i.test(item)));

  for (const file of files) {
    const source = read(file);
    if (source.includes('\uFFFD')) {
      issues.push(file + ' contains UTF-8 replacement characters');
      continue;
    }
    if (mojibake.test(source)) {
      issues.push(file + ' contains likely mojibake text');
    }
  }

  if (issues.length) return fail('encoding', issues.slice(0, 30).join('\n') + (issues.length > 30 ? '\n... +' + (issues.length - 30) + ' more' : ''));
  pass('encoding', 'no replacement characters or common mojibake patterns found');
}

function checkResponsiveGuards() {
  const issues = [];
  const workspace = exists('public/assets/css/v2/workspace.css') ? read('public/assets/css/v2/workspace.css') : '';
  const responsive = exists('public/assets/css/responsive-fix.css') ? read('public/assets/css/responsive-fix.css') : '';
  const mobile = exists('public/assets/css/mobile.css') ? read('public/assets/css/mobile.css') : '';
  const css = workspace + '\n' + responsive + '\n' + mobile;
  const mobileMenu = exists('public/assets/js/mobile-menu.js') ? read('public/assets/js/mobile-menu.js') : '';
  const appJs = exists('public/assets/js/app.js') ? read('public/assets/js/app.js') : '';

  const requiredCss = [
    ['Product stability pass', workspace],
    ['box-sizing: border-box', css],
    ['admin-mobile-drawer-open', css],
    ['mobile-menu-mask', css],
    ['translateX(0)', css],
    ['td::before', css],
    ['mobile-bottom-nav', css],
    ['user-control-link', workspace],
  ];
  for (const [needle, haystack] of requiredCss) {
    if (!haystack.includes(needle)) issues.push('responsive guard missing CSS marker: ' + needle);
  }
  if (!mobileMenu.includes('window.SKY_MOBILE_MENU') || !mobileMenu.includes('admin-mobile-drawer-open')) {
    issues.push('mobile-menu.js does not expose the unified mobile menu controller');
  }
  if (appJs.includes("$(document).on('click', '.mobile-menu-mask', closeMobileMenu);")) {
    issues.push('app.js still binds the old unguarded mobile menu mask handler');
  }
  if (!appJs.includes('mobileMenuManagedExternally')) {
    issues.push('app.js is missing the external mobile menu guard');
  }

  if (issues.length) return fail('responsive guards', issues.join('\n'));
  pass('responsive guards', 'mobile drawer, card table and compact control guards are present');
}

function checkUploadSecurity() {
  const issues = [];
  if (!exists('app/Services/FileService.php')) {
    issues.push('app/Services/FileService.php not found');
  } else {
    const source = read('app/Services/FileService.php');
    for (const marker of ['assertSafeExtension', 'application/x-php', 'text/html', 'image/svg+xml', 'application/javascript', 'application/x-msdownload']) {
      if (!source.includes(marker)) issues.push('FileService upload guard missing marker: ' + marker);
    }
  }
  const config = exists('config/app.php') ? read('config/app.php') : '';
  const dangerousExt = ['php', 'phtml', 'phar', 'html', 'htm', 'svg', 'js', 'exe', 'sh', 'bat', 'cmd', 'ps1'];
  const appUploadBlock = config.match(/'upload'\s*=>\s*\[([\s\S]*?)\n\s*\],\n\s*'security'/);
  if (appUploadBlock) {
    for (const ext of dangerousExt) {
      if (new RegExp("'" + ext + "'").test(appUploadBlock[1])) {
        issues.push('config/app.php upload allowlist contains dangerous extension: ' + ext);
      }
    }
  }

  if (issues.length) return fail('upload security', issues.join('\n'));
  pass('upload security', 'dangerous extensions and executable MIME types are guarded');
}

function checkUploadWorkflowSafety() {
  const issues = [];
  const netdisk = exists('app/Controllers/NetdiskController.php') ? read('app/Controllers/NetdiskController.php') : '';
  if (netdisk.includes("$scope = $isImage ? 'image' : 'file'") || netdisk.includes('$isImage = strpos')) {
    issues.push('NetdiskController.php still treats netdisk image uploads as image-host uploads');
  }
  const fileItem = exists('app/Models/FileItem.php') ? read('app/Models/FileItem.php') : '';
  if (!fileItem.includes("mime_type LIKE 'image/%'")) {
    issues.push('FileItem.php image category should include image MIME files stored through netdisk');
  }
  const api = exists('app/Controllers/ApiController.php') ? read('app/Controllers/ApiController.php') : '';
  if (!api.includes('StorageBackupService') || !api.includes('deleteBackupsForFile($file)')) {
    issues.push('ApiController.php delete endpoint should remove storage backup copies');
  }
  for (const file of ['app/Controllers/FileController.php', 'app/Controllers/NetdiskController.php', 'app/Controllers/ApiController.php', 'app/Services/FileService.php']) {
    const source = exists(file) ? read(file) : '';
    if (!source.includes('catch (\\Throwable')) {
      issues.push(file + ' upload path should catch Throwable so PHP Error/TypeError returns JSON instead of HTML 500');
    }
  }
  const appJs = exists('public/assets/js/app.js') ? read('public/assets/js/app.js') : '';
  for (const marker of ['upload-progress-box', 'parseUploadResponse', 'xhr.upload.onprogress']) {
    if (!appJs.includes(marker)) issues.push('app.js missing upload progress marker: ' + marker);
  }
  const fileService = exists('app/Services/FileService.php') ? read('app/Services/FileService.php') : '';
  for (const marker of ['assertStoragePreflight', '默认存储【', '请到后台「资源功能管理」执行真实测试']) {
    if (!fileService.includes(marker)) issues.push('FileService.php missing upload storage preflight marker: ' + marker);
  }
  for (const marker of ['uploadImageThumbnail', 'createImageThumbnail', 'thumbnailObjectKey', 'image_thumbnail_max_side']) {
    if (!fileService.includes(marker)) issues.push('FileService.php missing thumbnail/compression workflow marker: ' + marker);
  }
  const fileController = exists('app/Controllers/FileController.php') ? read('app/Controllers/FileController.php') : '';
  const netdiskController = exists('app/Controllers/NetdiskController.php') ? read('app/Controllers/NetdiskController.php') : '';
  if (!fileController.includes("'thumbnail_url' => $thumbnailUrl")) {
    issues.push('FileController upload JSON response should include thumbnail_url');
  }
  if (!netdiskController.includes("'thumbnail_url' => $thumbnailUrl")) {
    issues.push('NetdiskController upload JSON response should include thumbnail_url for image-like netdisk files');
  }
  for (const marker of ['uploadErrorMessage', 'UPLOAD_ERR_INI_SIZE', 'upload_tmp_dir']) {
    if (!fileService.includes(marker)) issues.push('FileService.php missing readable PHP upload error marker: ' + marker);
  }
  if (fileService.includes('上传失败，请稍后重试。') && !appJs.includes('upload-file-row')) {
    issues.push('upload fallback messages should be paired with per-file upload rows so users can see which file failed');
  }
  const redeem = exists('app/Services/RedeemCardService.php') ? read('app/Services/RedeemCardService.php') : '';
  if (redeem.includes('卡密表结构未准备完成，请稍后重试。')) {
    issues.push('RedeemCardService.php still uses the old card schema message without a repair path');
  }
  const admin = exists('app/Controllers/AdminController.php') ? read('app/Controllers/AdminController.php') : '';
  for (const marker of ['uploadRuntimeChecks', 'uploadRuntimeCheck', 'upload_tmp_dir', 'default_storage', 'CURLFile 能力']) {
    if (!admin.includes(marker)) issues.push('AdminController.php missing upload runtime diagnostic marker: ' + marker);
  }
  for (const file of ['app/Views/admin/feature_audit.php', 'app/Views/admin/maintenance_environment.php', 'app/Views/admin/upload_limits.php']) {
    const source = exists(file) ? read(file) : '';
    if (!source.includes('上传链路') || !source.includes('upload-runtime-checks')) {
      issues.push(file + ' missing visible upload runtime diagnostics section');
    }
  }

  if (issues.length) return fail('upload workflow', issues.join('\n'));
  pass('upload workflow', 'netdisk permissions, API backup cleanup and upload progress are guarded');
}

function checkCommercialPhases() {
  const issues = [];
  const router = exists('app/Core/Router.php') ? read('app/Core/Router.php') : '';
  const adminLayout = exists('app/Views/layouts/admin.php') ? read('app/Views/layouts/admin.php') : '';
  const appLayout = exists('app/Views/layouts/app.php') ? read('app/Views/layouts/app.php') : '';
  const mobileAdminLayout = exists('app/Views/layouts/mobile_admin.php') ? read('app/Views/layouts/mobile_admin.php') : '';
  const mobileUserLayout = exists('app/Views/layouts/mobile_user.php') ? read('app/Views/layouts/mobile_user.php') : '';
  const apiView = exists('app/Views/user/api.php') ? read('app/Views/user/api.php') : '';
  const apiController = exists('app/Controllers/ApiController.php') ? read('app/Controllers/ApiController.php') : '';
  const adminController = exists('app/Controllers/AdminController.php') ? read('app/Controllers/AdminController.php') : '';
  const dbUpgrade = exists('app/Services/DatabaseUpgradeService.php') ? read('app/Services/DatabaseUpgradeService.php') : '';
  const schema = exists('database/schema.sql') ? read('database/schema.sql') : '';

  const requiredRoutes = [
    '/api/picgo-config',
    '/api/sharex-config',
    '/admin/orders/export',
    '/admin/package-expiry',
    '/admin/package-expiry/remind',
    '/admin/monitor-sla',
    '/admin/monitor-sla/export',
    '/admin/storage-migration',
    '/admin/storage-migration/run',
    '/teams',
    '/m/teams',
  ];
  for (const route of requiredRoutes) {
    if (!router.includes("'" + route + "'")) issues.push('commercial phase route missing: ' + route);
  }

  const requiredViews = [
    'app/Views/admin/package_expiry.php',
    'app/Views/admin/monitor_sla.php',
    'app/Views/admin/storage_migration.php',
    'app/Views/admin/storage_backups.php',
    'app/Views/user/api.php',
    'app/Views/user/teams.php',
    'app/Views/mobile/api.php',
    'app/Views/mobile/teams.php',
  ];
  for (const file of requiredViews) {
    if (!exists(file)) issues.push('commercial phase view missing: ' + file);
  }

  for (const marker of ['PicGo', 'ShareX', 'bmtools-picgo-config.json', 'bmtools-sharex.sxcu']) {
    if (!apiView.includes(marker) && !apiController.includes(marker)) issues.push('PicGo/ShareX integration marker missing: ' + marker);
  }
  for (const marker of ['exportOrders', 'sendPackageExpiryReminders', 'monitorSla', 'exportMonitorSla', 'runStorageMigration']) {
    if (!adminController.includes('function ' + marker + '(') && !adminController.includes('public function ' + marker + '(')) {
      issues.push('AdminController missing commercial phase action: ' + marker);
    }
  }
  for (const marker of ['ensureStorageBackupSchema', 'ensureApiAppSchema', 'ensureTeamSpaceSchema', 'ensureServerOpsSchema']) {
    if (!dbUpgrade.includes(marker)) issues.push('DatabaseUpgradeService missing phase schema helper: ' + marker);
  }
  for (const marker of ['storage_backup_policies', 'file_storage_backups', 'api_apps', 'teams', 'team_members', 'server_ssh_sessions']) {
    if (!schema.includes('`__PREFIX__' + marker + '`')) issues.push('schema.sql missing phase table: ' + marker);
  }
  for (const marker of ['admin/monitor-sla', 'admin/package-expiry', 'admin/storage-migration']) {
    if (!adminLayout.includes(marker)) issues.push('admin menu missing phase entry: ' + marker);
  }
  for (const marker of ['api/console', 'teams', 'subsites']) {
    if (!appLayout.includes(marker)) issues.push('frontend console menu missing phase entry: ' + marker);
  }
  for (const marker of ['admin/m/storage-backups', 'admin/m/schema-audit', 'admin/m/upload-limits']) {
    if (!mobileAdminLayout.includes(marker)) issues.push('mobile admin menu missing phase entry: ' + marker);
  }
  for (const marker of ['m/api', 'm/teams', 'm/subsites']) {
    if (!mobileUserLayout.includes(marker)) issues.push('mobile user menu missing phase entry: ' + marker);
  }

  if (issues.length) return fail('commercial phases', issues.join('\n'));
  pass('commercial phases', 'phase 1/2/3 routes, views, menus and schemas are covered');
}

function checkStorageSafety() {
  const issues = [];
  const abstractDriver = exists('app/Services/Storage/AbstractStorageDriver.php') ? read('app/Services/Storage/AbstractStorageDriver.php') : '';
  if (!abstractDriver) {
    issues.push('AbstractStorageDriver.php not found');
  } else {
    for (const marker of ['$code < 200 || $code >= 300', 'Location=', 'strip_tags($responseBody)']) {
      if (!abstractDriver.includes(marker)) {
        issues.push('AbstractStorageDriver.php missing storage HTTP status guard marker: ' + marker);
      }
    }
  }

  const storageTest = exists('app/Services/Storage/StorageTestService.php') ? read('app/Services/Storage/StorageTestService.php') : '';
  for (const marker of ['failed_stage', 'failed_stage_hint', 'docs_url', 'technical_message']) {
    if (!storageTest.includes(marker)) {
      issues.push('StorageTestService.php missing diagnostic marker: ' + marker);
    }
  }

  const bmtools = exists('app/Services/Storage/BmtoolsStorageDriver.php') ? read('app/Services/Storage/BmtoolsStorageDriver.php') : '';
  for (const marker of ['$code < 200 || $code >= 300', 'Location=', '同系统对接返回异常 HTTP']) {
    if (!bmtools.includes(marker)) {
      issues.push('BmtoolsStorageDriver.php missing remote storage status guard marker: ' + marker);
    }
  }

  const webdav = exists('app/Services/Storage/WebDavStorageDriver.php') ? read('app/Services/Storage/WebDavStorageDriver.php') : '';
  for (const marker of ['$code < 200 || $code >= 300', 'Location=', 'WebDAV 服务返回异常 HTTP']) {
    if (!webdav.includes(marker)) {
      issues.push('WebDavStorageDriver.php missing WebDAV status guard marker: ' + marker);
    }
  }

  const abstractStorage = abstractDriver;
  if (!abstractStorage.includes('function curlFile') || !abstractStorage.includes('CURLOPT_INFILE')) {
    issues.push('AbstractStorageDriver.php missing streaming upload helper; large cloud uploads may exhaust PHP memory');
  }
  for (const file of ['app/Services/Storage/OssStorageDriver.php', 'app/Services/Storage/CosStorageDriver.php', 'app/Services/Storage/S3StorageDriver.php', 'app/Services/Storage/WebDavStorageDriver.php']) {
    const source = exists(file) ? read(file) : '';
    if (!source.includes('curlFile(')) {
      issues.push(file + ' should stream uploads through curlFile() instead of loading the whole file into memory');
    }
    if (source.includes('file_get_contents($localPath)')) {
      issues.push(file + ' still reads the whole upload into memory');
    }
  }

  if (issues.length) return fail('storage safety', issues.join('\n'));
  pass('storage safety', 'object storage redirects and staged diagnostics are guarded');
}

function checkSqlSafety() {
  const issues = [];
  const database = exists('app/Core/Database.php') ? read('app/Core/Database.php') : '';
  const model = exists('app/Core/Model.php') ? read('app/Core/Model.php') : '';

  for (const marker of ['validateIdentifier', 'limitClause', 'offsetLimitClause', 'orderByClause']) {
    if (!database.includes(marker)) {
      issues.push('Database.php missing SQL safety helper: ' + marker);
    }
  }
  for (const marker of ['Database::validateIdentifier', 'Database::orderByClause']) {
    if (!model.includes(marker)) {
      issues.push('Model.php does not use SQL safety helper: ' + marker);
    }
  }

  const sqlFiles = []
    .concat(walk('app/Controllers', (item) => item.endsWith('.php')))
    .concat(walk('app/Services', (item) => item.endsWith('.php')))
    .concat(walk('app/Models', (item) => item.endsWith('.php')));

  for (const file of sqlFiles) {
    const lines = read(file).split(/\r?\n/);
    lines.forEach((line, index) => {
      const compact = line.trim();
      if (!compact || compact.startsWith('//')) return;
      if (/LIMIT\s+['"]?\s*\.\s*\$/.test(compact) && !compact.includes('Database::limitClause') && !compact.includes('Database::offsetLimitClause')) {
        issues.push(file + ':' + (index + 1) + ' concatenates LIMIT without Database::limitClause');
      }
      if (/ORDER\s+BY\s+['"]?\s*\.\s*\$/.test(compact) && !compact.includes('Database::orderByClause')) {
        issues.push(file + ':' + (index + 1) + ' concatenates ORDER BY without Database::orderByClause');
      }
      if (/Database::(?:fetch|fetchAll|execute|query)\([^;\n]*(?:SELECT|UPDATE|DELETE|INSERT|WHERE|ORDER|LIMIT)[^;\n]*\.\s*\$_(?:GET|POST|REQUEST)/i.test(compact)) {
        issues.push(file + ':' + (index + 1) + ' concatenates request data into SQL');
      }
      const sqlish = /(SELECT|WHERE|AND|OR|UPDATE|DELETE|INSERT|Database::|safeCount\()/i.test(compact);
      if (sqlish && /FIELD\([^;\n]*"[^"]+"/i.test(compact)) {
        issues.push(file + ':' + (index + 1) + ' uses double-quoted SQL string in FIELD(); use single quotes for ANSI_QUOTES compatibility');
      }
      if (sqlish && /CASE\s+WHEN[^;\n]*=\s*"[^"]+"/i.test(compact)) {
        issues.push(file + ':' + (index + 1) + ' uses double-quoted SQL string in CASE; use single quotes for ANSI_QUOTES compatibility');
      }
      if (sqlish && /\bIN\s*\([^;\n)]*"[^"]+"/i.test(compact)) {
        issues.push(file + ':' + (index + 1) + ' uses double-quoted SQL string in IN(); use single quotes for ANSI_QUOTES compatibility');
      }
      if (sqlish && /COALESCE\s*\([^;\n]*,\s*"[^"]+"/i.test(compact)) {
        issues.push(file + ':' + (index + 1) + ' uses double-quoted SQL string in COALESCE(); use single quotes for ANSI_QUOTES compatibility');
      }
      if (sqlish && /\b(?:WHERE|AND|OR)\b[^;\n]*(?:=|<>|!=)\s*"[^"]+"/i.test(compact)) {
        issues.push(file + ':' + (index + 1) + ' uses double-quoted SQL string in WHERE condition; use single quotes for ANSI_QUOTES compatibility');
      }
    });
  }

  if (issues.length) return fail('sql safety', [...new Set(issues)].join('\n'));
  pass('sql safety', 'identifier validation and dynamic LIMIT/ORDER guards are present');
}

function checkAuthSecurity() {
  const issues = [];
  const bootstrap = exists('app/bootstrap.php') ? read('app/bootstrap.php') : '';
  const controller = exists('app/Core/Controller.php') ? read('app/Core/Controller.php') : '';
  const auth = exists('app/Core/Auth.php') ? read('app/Core/Auth.php') : '';
  const csrf = exists('app/Core/Csrf.php') ? read('app/Core/Csrf.php') : '';

  for (const marker of ['Content-Security-Policy', 'X-Frame-Options', 'X-Content-Type-Options', 'session_set_cookie_params', "'httponly' => true", "'samesite' => 'Lax'"]) {
    if (!bootstrap.includes(marker)) issues.push('bootstrap.php missing security marker: ' + marker);
  }
  for (const marker of ['safeRedirectTarget', 'HTTP_X_CSRF_TOKEN', 'privateNoStoreHeaders', 'Cache-Control: no-store']) {
    if (!controller.includes(marker)) issues.push('Controller.php missing auth boundary marker: ' + marker);
  }
  for (const marker of ['function rotate', 'function clear', 'hash_equals']) {
    if (!csrf.includes(marker)) issues.push('Csrf.php missing CSRF marker: ' + marker);
  }
  for (const marker of ['Csrf::rotate', 'session_regenerate_id(true)', "preg_match('/^[a-f0-9]{64}$/i'", 'text_limit((string) $_SERVER[']) {
    if (!auth.includes(marker)) issues.push('Auth.php missing session/cookie marker: ' + marker);
  }

  if (issues.length) return fail('auth security', issues.join('\n'));
  pass('auth security', 'session rotation, CSRF header support, safe redirects and no-store guards are present');
}

function checkApiSecurity() {
  const issues = [];
  const api = exists('app/Controllers/ApiController.php') ? read('app/Controllers/ApiController.php') : '';
  for (const marker of ['validApiTokenFormat', 'strlen($token) >= 16', 'strlen($token) <= 128', 'preg_match', "text_limit((string) $endpoint", "text_limit((string) $message"]) {
    if (!api.includes(marker)) issues.push('ApiController.php missing API boundary marker: ' + marker);
  }
  if (issues.length) return fail('api security', issues.join('\n'));
  pass('api security', 'API token format and log truncation guards are present');
}

function checkConfigWarnings() {
  const warnings = [];
  if (exists('config/app.php') && read('config/app.php').includes("'secret_key' => 'bm-tools-change-this-secret-key'")) {
    warnings.push('source config/app.php keeps the install-time placeholder secret; installer should replace it in config/database.php on production installs');
  }
  pass('config warnings', warnings.length ? warnings.join('; ') : 'no configuration warnings');
}

function checkServerGuards() {
  const issues = [];

  if (!exists('.htaccess')) {
    issues.push('root .htaccess not found');
  } else {
    const htaccess = read('.htaccess');
    for (const dir of ['app', 'config', 'database', 'storage', 'vendor']) {
      if (!new RegExp(dir).test(htaccess)) {
        issues.push('root .htaccess does not mention protected directory: ' + dir);
      }
    }
    if (!/uploads.*php/i.test(htaccess)) {
      issues.push('root .htaccess does not block executable uploads');
    }
  }

  if (!exists('public/uploads/.htaccess')) {
    issues.push('public/uploads/.htaccess not found');
  } else {
    const uploadHtaccess = read('public/uploads/.htaccess');
    if (!/Require\s+all\s+denied/i.test(uploadHtaccess) || !/php_flag\s+engine\s+off/i.test(uploadHtaccess)) {
      issues.push('public/uploads/.htaccess should disable script execution');
    }
  }

  if (exists('bt-nginx-rewrite.conf')) {
    const nginx = read('bt-nginx-rewrite.conf');
    if (!/\^\s*\/\(app\|config\|database\|storage\|vendor\)/.test(nginx)) {
      issues.push('bt-nginx-rewrite.conf does not protect app/config/database/storage/vendor');
    }
    if (!/uploads\/\.\*\\\.\(php/i.test(nginx)) {
      issues.push('bt-nginx-rewrite.conf does not block executable uploads');
    }
  }

  if (issues.length) return fail('server guards', issues.join('\n'));
  pass('server guards', 'apache/nginx guard rules protect private and upload paths');
}

function run() {
  checkByteOrderMarks();
  checkRoutes();
  checkViews();
  checkViewLinks();
  checkAdminMenus();
  checkFormActions();
  checkRedirects();
  checkAssets();
  checkLayoutMeta();
  checkCsrf();
  checkHtmlDetails();
  checkCss();
  checkJs();
  checkAjaxSafety();
  checkRuntimeSafety();
  checkBrandProtectionSafety();
  checkSchema();
  checkSchemaRepairDiagnostics();
  checkServerGuards();
  checkEncodingHealth();
  checkResponsiveGuards();
  checkUploadSecurity();
  checkUploadWorkflowSafety();
  checkCommercialPhases();
  checkStorageSafety();
  checkSqlSafety();
  checkAuthSecurity();
  checkApiSecurity();
  checkConfigWarnings();

  let ok = true;
  for (const result of results) {
    if (!result.ok) ok = false;
    const mark = result.ok ? 'OK' : 'FAIL';
    console.log(mark + ' ' + result.name + (result.detail ? ' - ' + result.detail : ''));
  }
  process.exit(ok ? 0 : 1);
}

run();
