# BM TOOLS API 文档

本文档记录 BM TOOLS 当前开放 API。接口可用于 PicGo、ShareX、脚本上传，也可用于“同系统对接”。

基础地址以实际站点为准：

```text
https://你的域名
```

## 1. 鉴权

所有 API 都使用 API Token。

推荐放在请求头：

```http
X-API-Token: 用户API_TOKEN
```

兼容旧方式，也可以放在 POST 参数：

```text
token=用户API_TOKEN
```

正式接入建议只使用请求头，不要把 Token 拼到 URL。

如果同一个 IP 连续提交缺失或错误的 Token，系统会临时锁定该 IP 的 API 鉴权请求。锁定期间会返回 `429`，用于降低 Token 爆破风险。请求头和 POST 参数同时存在时，系统优先使用请求头中的 `X-API-Token`。

Token 在数据库中会加密保存，同时保存 SHA-256 摘要用于接口检索。旧版本已经生成的明文 Token 会在用户打开 API 管理、个人资料或调用 API 时自动升级，不需要手工执行 SQL。

## 2. API 权限要求

调用 API 需要满足：

- 用户账号未禁用。
- 用户套餐开启 API。
- 如果设置了 API 访问 IP 白名单，调用方 IP 必须在白名单内。
- 上传图片时，用户需要图床权限。
- 上传文件时，用户需要网盘权限。
- 接口调用不能超过后台设置的每分钟、每日频率限制。
- Token 鉴权失败次数不能超过安全限制。

API 白名单在用户侧配置：

```text
个人资料 -> API 访问 IP 白名单
```

每行一个 IPv4 或 IPv6。留空表示不限制。

## 3. 通用响应

成功：

```json
{
  "success": true,
  "data": {}
}
```

失败：

```json
{
  "success": false,
  "message": "错误原因"
}
```

常见 HTTP 状态码：

```text
200  成功
401  Token 无效
403  套餐无权限，或当前 IP 不在 API 白名单
422  参数错误、上传失败、文件类型不允许
429  调用频率过高
```

`429` 可能来自两类限制：

- Token 连续错误，属于鉴权保护。
- 有效 Token 调用接口过快，属于 API 调用频率限制。

## 4. 上传文件

接口：

```http
POST /api/upload
```

请求类型：

```text
multipart/form-data
```

请求头：

```http
X-API-Token: 用户API_TOKEN
```

字段：

| 字段 | 必填 | 说明 |
|---|---:|---|
| file | 是 | 上传文件字段 |
| type | 否 | `image` 或 `file`，默认 `image` |

`type=image`：

用于图床。系统会校验扩展名、MIME 和真实图片内容。

`type=file`：

用于个人网盘。系统会拦截 PHP 等可执行脚本 MIME。

curl 示例：

```bash
curl -X POST "https://你的域名/api/upload" \
  -H "X-API-Token: 用户API_TOKEN" \
  -F "type=image" \
  -F "file=@demo.jpg"
```

成功响应：

```json
{
  "success": true,
  "data": {
    "id": 128,
    "name": "demo.jpg",
    "size": 24581,
    "mime": "image/jpeg",
    "url": "https://你的域名/uploads/files/image/2026/05/13/xxx.jpg",
    "markdown": "![demo.jpg](https://你的域名/uploads/files/image/2026/05/13/xxx.jpg)",
    "html": "<img src=\"https://你的域名/uploads/files/image/2026/05/13/xxx.jpg\" alt=\"demo.jpg\">",
    "bbcode": "[img]https://你的域名/uploads/files/image/2026/05/13/xxx.jpg[/img]"
  }
}
```

字段说明：

| 字段 | 说明 |
|---|---|
| id | 文件 ID。删除接口需要使用这个 ID |
| name | 原始文件名 |
| size | 文件大小，单位字节 |
| mime | 文件 MIME |
| url | 完整外链 |
| markdown | Markdown 图片代码 |
| html | HTML 图片代码 |
| bbcode | BBCode 图片代码 |

## 5. 文件列表

接口：

```http
POST /api/files
```

请求头：

```http
X-API-Token: 用户API_TOKEN
```

字段：

| 字段 | 必填 | 默认 | 说明 |
|---|---:|---:|---|
| page | 否 | 1 | 页码 |
| limit | 否 | 20 | 每页数量，最大 100 |
| type | 否 | 空 | `image`、`file`，为空表示全部 |
| keyword | 否 | 空 | 按文件名搜索 |

curl 示例：

```bash
curl -X POST "https://你的域名/api/files" \
  -H "X-API-Token: 用户API_TOKEN" \
  -d "page=1&limit=20&type=image"
```

成功响应：

```json
{
  "success": true,
  "data": {
    "page": 1,
    "limit": 20,
    "total": 1,
    "items": [
      {
        "id": 128,
        "file_type": "image",
        "original_name": "demo.jpg",
        "file_ext": "jpg",
        "mime_type": "image/jpeg",
        "file_size": 24581,
        "file_url": "https://你的域名/uploads/files/image/2026/05/13/xxx.jpg",
        "thumbnail_url": "https://你的域名/uploads/files/image/2026/05/13/xxx.jpg",
        "created_at": "2026-05-13 12:00:00"
      }
    ]
  }
}
```

## 6. 删除文件

接口：

```http
POST /api/delete
```

请求头：

```http
X-API-Token: 用户API_TOKEN
```

字段：

| 字段 | 必填 | 说明 |
|---|---:|---|
| id | 是 | 文件 ID |

curl 示例：

```bash
curl -X POST "https://你的域名/api/delete" \
  -H "X-API-Token: 用户API_TOKEN" \
  -d "id=128"
```

成功响应：

```json
{
  "success": true,
  "message": "文件已删除。"
}
```

删除规则：

- 只能删除当前 Token 所属用户自己的文件。
- 删除数据库记录前，会先调用对应存储源删除远端对象。
- 如果文件本身存放在同系统对接中，删除动作会继续调用远端站点的 `/api/delete`。

## 7. 容量查询

接口：

```http
POST /api/quota
```

请求头：

```http
X-API-Token: 用户API_TOKEN
```

curl 示例：

```bash
curl -X POST "https://你的域名/api/quota" \
  -H "X-API-Token: 用户API_TOKEN"
```

成功响应：

```json
{
  "success": true,
  "data": {
    "used_storage": 1048576,
    "total_storage": 1073741824,
    "used_traffic": 0,
    "total_traffic": 5368709120,
    "file_count": 12,
    "balance": "0.00"
  }
}
```

字段说明：

| 字段 | 说明 |
|---|---|
| used_storage | 已用空间，字节 |
| total_storage | 总空间，字节。0 表示不限 |
| used_traffic | 已用流量，字节 |
| total_traffic | 总流量，字节。0 表示不限 |
| file_count | 当前用户文件数量 |
| balance | 账户余额 |

## 8. 同系统对接如何使用这些接口

主站 A 配置“同系统对接”后，会调用仓储站 B 的这些接口：

```text
POST /api/quota   测试 Token 和读取容量
POST /api/upload  上传图片或文件
POST /api/delete  删除远端文件
```

请求头固定使用：

```http
X-API-Token: 仓储站B远端用户Token
X-BMTOOLS-Storage-Hop: 链路层级
```

主站 A 不会使用 URL 参数传 Token。

`X-BMTOOLS-Storage-Hop` 由系统自动生成。正常 A 站传 B 站时是 `1`，如果 B 站又继续转发到 C 站会递增。超过 3 跳会中断，用来发现错误的循环存储配置。

上传图片时：

```text
type=image
```

上传普通网盘文件时：

```text
type=file
```

主站 A 保存远端文件时，本地 `file_path` 格式为：

```text
bmtools:远端文件ID
```

例如：

```text
bmtools:128
```

删除时，主站 A 解析出 `128`，再调用仓储站 B：

```http
POST /api/delete
id=128
```

## 9. PicGo 配置示例

PicGo 自定义 Web 图床可按以下方式填写：

```text
API 地址：https://你的域名/api/upload
请求方式：POST
文件字段名：file
请求头：X-API-Token: 用户API_TOKEN
返回 URL 路径：data.url
```

## 10. ShareX 配置示例

```json
{
  "RequestType": "POST",
  "RequestURL": "https://你的域名/api/upload",
  "FileFormName": "file",
  "Arguments": {
    "type": "image"
  },
  "Headers": {
    "X-API-Token": "用户API_TOKEN"
  },
  "URL": "$json:data.url$"
}
```

## 11. PHP 调用示例

```php
<?php
$ch = curl_init('https://你的域名/api/upload');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'X-API-Token: 用户API_TOKEN',
    ],
    CURLOPT_POSTFIELDS => [
        'type' => 'image',
        'file' => new CURLFile(__DIR__ . '/demo.jpg', 'image/jpeg', 'demo.jpg'),
    ],
    CURLOPT_RETURNTRANSFER => true,
]);
$body = curl_exec($ch);
curl_close($ch);
$json = json_decode($body, true);
if (!empty($json['success'])) {
    echo $json['data']['url'];
} else {
    echo isset($json['message']) ? $json['message'] : '上传失败';
}
```

## 12. 安全建议

- Token 只放请求头，不放 URL。
- 不要把 Token 写进前端公开代码、GitHub 仓库或浏览器地址栏。
- 同系统对接必须使用 HTTPS。
- 仓储站建议单独创建普通用户，不要复用管理员账号。
- 仓储站远端用户建议设置 API 白名单，只允许主站服务器出口 IP。
- 管理员可以在后台用户管理中直接给远端用户填写 API 白名单。
- Token 泄露后立即重置。
- 不要把两个站互相设置为默认同系统对接，避免循环上传。
- 正式运营前先测试上传、删除、容量查询三个接口。
