# BM TOOLS HTTP 探针监控说明

HTTP 探针用于解决主站没有 SSH 客户端能力的问题。  
不需要安装 Composer、phpseclib 或 PHP ssh2 扩展，只需要在被监控服务器放置一个 PHP 探针文件。

## 适合场景

- 被监控服务器可以访问 PHP 文件。
- 宝塔 API 没有开启或白名单不好配置。
- 不想安装 SSH 相关依赖。
- 只需要采集 CPU、内存、磁盘、网络、负载等基础状态。

## 部署步骤

### 1. 复制探针文件

项目内置：

```text
public/monitor-agent.php
```

把它上传到被监控服务器的网站目录，例如：

```text
/www/wwwroot/status.example.com/monitor-agent.php
```

### 2. 修改 Token

打开探针文件，修改顶部 Token：

```php
$token = 'CHANGE_THIS_TOKEN';
```

建议改成随机字符串：

```php
$token = 'BM_9d7f8a2c6e1b4f3a';
```

### 3. 浏览器测试

访问：

```text
https://status.example.com/monitor-agent.php?token=BM_9d7f8a2c6e1b4f3a
```

正常会返回 JSON。

### 4. 后台添加服务器

进入：

```text
后台管理 -> 监控管理
```

选择：

```text
HTTP 探针
```

填写探针 URL 和 Token，点击测试连接，成功后保存。

## 安全建议

- 必须修改默认 Token。
- 建议启用 HTTPS。
- 不要公开探针地址。
- 可在 Nginx 中限制只允许主站 IP 访问。
- 探针只读取状态，不执行外部传入命令。

## 支持指标

- CPU 使用率
- 内存总量、已用和使用率
- 磁盘使用率
- 网络上传和下载数据
- 系统负载
- 在线时间
- PHP 版本
- 主机名
- 系统内核信息
