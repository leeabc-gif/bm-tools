<?php
return [
    'host' => '127.0.0.1',
    'port' => '3306',
    'database' => 'skystorage',
    'username' => 'root',
    'password' => '',
    'prefix' => 'ss_',
    'charset' => 'utf8mb4',
];

