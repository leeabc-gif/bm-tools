(function () {
    var baseUrl = (window.SKY_BASE_URL || '').replace(/\/$/, '');
    function api(path) { return baseUrl + '/' + path.replace(/^\//, ''); }

    function autoTheme() {
        var hour = new Date().getHours();
        return hour >= 7 && hour < 19 ? 'light' : 'dark';
    }

    function normalizeThemeMode(mode) {
        return mode === 'light' || mode === 'dark' || mode === 'auto' ? mode : 'auto';
    }

    function applyTheme(mode, persist) {
        mode = normalizeThemeMode(mode);
        var resolved = mode === 'auto' ? autoTheme() : mode;
        document.body.setAttribute('data-theme-mode', mode);
        document.body.setAttribute('data-theme', resolved);
        $('.theme-toggle').attr('title', mode === 'auto' ? '主题：自动' : (mode === 'dark' ? '主题：深色' : '主题：浅色'));
        if (persist) localStorage.setItem('sky_theme_mode', mode);
    }

    var defaultTheme = normalizeThemeMode(window.SKY_DEFAULT_THEME || document.body.getAttribute('data-theme') || 'auto');
    var savedTheme = normalizeThemeMode(localStorage.getItem('sky_theme_mode') || localStorage.getItem('sky_theme') || defaultTheme);
    applyTheme(savedTheme, false);

    function toggleTheme() {
        var current = normalizeThemeMode(document.body.getAttribute('data-theme-mode') || savedTheme);
        applyTheme(current === 'auto' ? 'light' : (current === 'light' ? 'dark' : 'auto'), true);
    }

    var iconMap = {
        '保存': 'save',
        '删除': 'trash-2',
        '批量删除': 'trash-2',
        '编辑': 'pencil',
        '搜索': 'search',
        '筛选': 'filter',
        '重置': 'rotate-ccw',
        '上传': 'upload-cloud',
        '上传图片': 'upload-cloud',
        '开始上传': 'upload-cloud',
        '复制': 'copy',
        '分享': 'share-2',
        '关闭': 'x-circle',
        '启用': 'check-circle',
        '停用': 'pause-circle',
        '移动': 'folder-input',
        '测试': 'plug-zap',
        '发送': 'send',
        '导出': 'download',
        '通过': 'check',
        '拒绝': 'x',
        '购买': 'shopping-cart',
        '登录': 'log-in',
        '注册': 'user-plus',
        '退出': 'log-out',
        '返回': 'arrow-left',
        '下载': 'download',
        '立即采集': 'activity',
        '个人中心': 'layout-dashboard',
        '营销活动': 'badge-percent'
    };

    function iconNameFor(el) {
        var explicit = el.getAttribute('data-icon');
        if (explicit) return explicit;
        var text = (el.textContent || '').replace(/\s+/g, '').trim();
        if (iconMap[text]) return iconMap[text];
        Object.keys(iconMap).some(function (key) {
            if (text.indexOf(key) !== -1) {
                explicit = iconMap[key];
                return true;
            }
            return false;
        });
        return explicit || '';
    }

    function enhanceIcons() {
        document.querySelectorAll('.btn, .icon-btn, .site-nav a, .console-nav a, .admin-nav a, .admin-menu-toggle, .admin-right-rail button, .admin-right-rail a, .context-menu button, .product-link, [data-lucide]').forEach(function (el) {
            if (el.querySelector('.btn-icon')) return;
            if (el.hasAttribute('data-lucide') && !el.classList.contains('btn') && !el.classList.contains('icon-btn')) return;
            var icon = iconNameFor(el);
            if (!icon) return;
            var span = document.createElement('span');
            span.className = 'btn-icon';
            span.setAttribute('data-lucide', icon);
            el.insertBefore(span, el.firstChild);
        });
        if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
    }

    function setButtonText(btn, text) {
        btn.text(text);
        enhanceIcons();
    }

    function markActiveNav() {
        var current = window.location.pathname.replace(/\/$/, '') || '/';
        $('.site-nav a, .console-nav a, .admin-nav a').each(function () {
            var link = document.createElement('a');
            link.href = this.href;
            var path = link.pathname.replace(/\/$/, '') || '/';
            if (path === current || (path !== '/' && current.indexOf(path) === 0)) $(this).addClass('active');
        });
    }

    function markFormLoading(form) {
        var submit = form.find('button[type="submit"], .btn-primary').filter('button').first();
        if (submit.length && !submit.prop('disabled')) {
            submit.addClass('is-loading').prop('disabled', true);
            submit.append('<span class="loading-dot"></span>');
        }
    }

    $('.theme-toggle').on('click', toggleTheme);

    $('.mobile-menu-btn').on('click', function () {
        $('.site-nav, .console-sidebar').toggleClass('open');
        $('.console-layout').toggleClass('menu-open');
    });

    $('.admin-menu-group').each(function () {
        var key = $(this).data('menu-key');
        if (!key || $(this).find('.admin-submenu a.active').length) return;
        var saved = localStorage.getItem(key);
        if (saved === '1') $(this).addClass('open');
        if (saved === '0') $(this).removeClass('open');
    });

    $(document).on('click', '.admin-menu-toggle', function () {
        var group = $(this).closest('.admin-menu-group');
        group.toggleClass('open');
        var key = group.data('menu-key');
        if (key) localStorage.setItem(key, group.hasClass('open') ? '1' : '0');
    });

    $('.admin-right-rail [data-admin-tool]').on('click', function () {
        var tool = $(this).data('admin-tool');
        if (tool === 'search') {
            var field = $('input[type="search"], input[name="keyword"], input[name="q"], input[placeholder*="搜索"]').filter(':visible').first();
            field.length ? field.focus() : alert('当前页面没有可聚焦的搜索框。');
        }
        if (tool === 'favorite') {
            alert('可使用浏览器收藏当前页面。系统内收藏功能后续可接入管理员偏好。');
        }
    });

    enhanceIcons();
    markActiveNav();
    document.body.classList.add('page-ready');

    $(window).on('scroll', function () {
        var total = document.documentElement.scrollHeight - window.innerHeight;
        var pct = total > 0 ? (window.scrollY / total) * 100 : 0;
        $('.scroll-progress').css('width', pct + '%');
        $('.back-top').toggleClass('show', window.scrollY > 360);
    }).trigger('scroll');

    $('.back-top').on('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    var observer = window.IntersectionObserver ? new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) entry.target.classList.add('visible');
        });
    }, { threshold: 0.12 }) : null;
    document.querySelectorAll('.reveal').forEach(function (el) {
        if (observer) observer.observe(el); else el.classList.add('visible');
    });

    $('.drop-zone').on('dragenter dragover', function (e) {
        e.preventDefault();
        $(this).addClass('dragging');
    }).on('dragleave drop', function () {
        $(this).removeClass('dragging');
    });

    $(document).on('change', '.drop-zone input[type="file"]', function () {
        var input = this;
        var zone = $(input).closest('.drop-zone');
        var small = zone.find('small').first();
        if (!small.data('defaultText')) small.data('defaultText', small.text());
        if (!input.files || !input.files.length) {
            small.text(small.data('defaultText'));
            return;
        }
        var total = 0;
        Array.prototype.forEach.call(input.files, function (file) { total += file.size || 0; });
        var sizeText = total >= 1024 * 1024 ? (total / 1024 / 1024).toFixed(2) + ' MB' : (total / 1024).toFixed(1) + ' KB';
        small.text('已选择 ' + input.files.length + ' 个文件，共 ' + sizeText + '。');
        zone.addClass('dragging');
        setTimeout(function () { zone.removeClass('dragging'); }, 500);
    });

    document.addEventListener('paste', function (e) {
        var fileInput = document.querySelector('.upload-form input[type=file]');
        if (!fileInput || !e.clipboardData || !e.clipboardData.files.length) return;
        fileInput.files = e.clipboardData.files;
        if (window.jQuery) $(fileInput).trigger('change');
        var zone = fileInput.closest('.drop-zone');
        if (zone) {
            zone.classList.add('dragging');
            setTimeout(function () { zone.classList.remove('dragging'); }, 500);
        }
    });

    function ensureUploadProgress(form) {
        var box = form.find('.upload-progress-box');
        if (!box.length) {
            box = $('<div class="upload-progress-box"><div class="upload-progress-head"><b>准备上传</b><span>0%</span></div><div class="upload-progress-bar"><i></i></div><small>请保持页面打开，上传完成后会自动刷新。</small></div>');
            form.append(box);
        }
        return box;
    }

    function setUploadProgress(box, percent, text) {
        percent = Math.max(0, Math.min(100, Math.round(percent || 0)));
        box.find('.upload-progress-head b').text(text || '正在上传');
        box.find('.upload-progress-head span').text(percent + '%');
        box.find('.upload-progress-bar i').css('width', percent + '%');
        box.toggleClass('done', percent >= 100);
    }

    $('.upload-form').on('submit', function (e) {
        var form = $(this);
        var fileInput = form.find('input[type="file"]').get(0);
        if (!fileInput || !fileInput.files || !fileInput.files.length || !window.FormData || !window.XMLHttpRequest) return;
        e.preventDefault();
        var submit = form.find('button[type="submit"]').first();
        var progress = ensureUploadProgress(form);
        var xhr = new XMLHttpRequest();
        xhr.open((form.attr('method') || 'POST').toUpperCase(), form.attr('action'), true);
        submit.prop('disabled', true).addClass('is-loading');
        setUploadProgress(progress, 1, '正在连接');
        xhr.upload.onprogress = function (event) {
            setUploadProgress(progress, event.lengthComputable ? event.loaded / event.total * 100 : 35, '正在上传');
        };
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== 4) return;
            submit.prop('disabled', false).removeClass('is-loading');
            if (xhr.status >= 200 && xhr.status < 400) {
                setUploadProgress(progress, 100, '上传完成');
                setTimeout(function () { window.location.reload(); }, 500);
            } else {
                setUploadProgress(progress, 0, '上传失败');
                alert('上传失败，请检查文件大小、套餐容量或网络状态后重试。');
            }
        };
        xhr.onerror = function () {
            submit.prop('disabled', false).removeClass('is-loading');
            setUploadProgress(progress, 0, '网络异常');
            alert('网络异常，上传未完成。');
        };
        xhr.send(new FormData(form.get(0)));
    });

    $('.copy-selected').on('click', function () {
        var urls = [];
        $('input[name="ids[]"]:checked').each(function () { urls.push($(this).data('url')); });
        if (!urls.length) return alert('请选择图片');
        navigator.clipboard.writeText(urls.join('\n')).then(function () { alert('已复制'); });
    });

    $('.copy-current-inputs').on('click', function () {
        var values = [];
        $(this).closest('.detail-panel, .image-card, .table-card').find('input[readonly]').each(function () { values.push($(this).val()); });
        if (!values.length) return alert('没有可复制内容');
        navigator.clipboard.writeText(values.join('\n')).then(function () { alert('已复制全部链接'); });
    });

    $('.select-all').on('change', function () {
        $('input[data-group="' + $(this).data('target') + '"]').prop('checked', this.checked);
    });

    $(document).on('click', '.btn, .icon-btn, .admin-nav a, .site-nav a, .console-nav a, .context-menu button', function (e) {
        var target = $(this);
        var offset = target.offset();
        if (!offset) return;
        var ripple = $('<span class="click-ripple"></span>');
        var size = Math.max(target.outerWidth(), target.outerHeight());
        ripple.css({ width: size, height: size, left: e.pageX - offset.left - size / 2, top: e.pageY - offset.top - size / 2 });
        target.append(ripple);
        setTimeout(function () { ripple.remove(); }, 520);
    });

    $(document).on('submit', 'form:not(.confirm-form):not(.upload-form)', function () { markFormLoading($(this)); });
    $('.confirm-form').on('submit', function (e) {
        if (!confirm($(this).data('confirm') || '确定执行该操作吗？')) {
            e.preventDefault();
            return false;
        }
        markFormLoading($(this));
    });

    $('.send-code-btn').on('click', function () {
        var btn = $(this);
        var email = $('input[name="email"]').val();
        setButtonText(btn.prop('disabled', true), '发送中');
        $.post(api('/email-code'), { email: email, scene: btn.data('scene'), _token: btn.data('token') })
            .done(function (res) { alert(res.message || '验证码已发送'); })
            .fail(function (xhr) { alert((xhr.responseJSON && xhr.responseJSON.message) || '发送失败'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '发送'); });
    });

    $('.context-menu [data-action]').on('click', function () {
        var action = $(this).data('action');
        $('.context-menu').hide();
        if (action === 'refresh') location.reload();
        if (action === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
        if (action === 'theme') toggleTheme();
    });

    $(document).on('contextmenu', function (e) {
        if ($(e.target).closest('input,textarea,select').length) return;
        e.preventDefault();
        $('.context-menu').css({ left: e.clientX, top: e.clientY }).show();
    }).on('click', function () { $('.context-menu').hide(); });

    $('.collect-btn').on('click', function () {
        var btn = $(this);
        setButtonText(btn.prop('disabled', true), '采集中');
        $.post(api('/monitor/collect'), { id: btn.data('id'), _token: btn.data('token') })
            .done(function (res) { alert(res.message || '采集完成'); location.reload(); })
            .fail(function (xhr) { alert((xhr.responseJSON && xhr.responseJSON.message) || '采集失败'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '立即采集'); });
    });

    $('.monitor-test-btn').on('click', function () {
        var btn = $(this), form = btn.closest('form');
        setButtonText(btn.prop('disabled', true), '测试中');
        var endpoint = form.attr('action') && form.attr('action').indexOf('/admin/monitors/save') !== -1 ? '/admin/monitors/test' : '/monitor/test';
        $.post(api(endpoint), form.serialize() + '&_token=' + encodeURIComponent(btn.data('token')))
            .done(function (res) { alert((res && res.message) || '连接成功'); })
            .fail(function (xhr) { alert((xhr.responseJSON && xhr.responseJSON.message) || '连接失败'); })
            .always(function () { setButtonText(btn.prop('disabled', false), '测试连接'); });
    });

    $('.storage-test-btn').on('click', function () {
        var btn = $(this);
        var id = btn.data('id');
        var box = $('#storage-test-result-' + id + ' .storage-test-result');
        box.removeClass('ok warn error muted').addClass('warn').html('<b>测试中</b><span>正在上传测试文件并验证删除权限。</span>');
        setButtonText(btn.prop('disabled', true), '测试中');
        $.post(api('/admin/storages/test'), { id: id, _token: btn.data('token') })
            .done(function (res) {
                var ok = res && res.success;
                box.removeClass('ok warn error muted').addClass(ok ? 'ok' : 'error').html('<b>' + (ok ? '测试通过' : '测试失败') + '</b><span>' + ((res && res.message) || '') + '</span>');
                if (!ok) alert((res && res.message) || '测试失败');
            })
            .fail(function (xhr) {
                var msg = (xhr.responseJSON && xhr.responseJSON.message) || '测试失败';
                box.removeClass('ok warn error muted').addClass('error').html('<b>测试失败</b><span>' + msg + '</span>');
            })
            .always(function () { setButtonText(btn.prop('disabled', false), '真实测试'); });
    });

    $(document).on('click', '.quick-amount', function (e) {
        e.preventDefault();
        var amount = $(this).data('amount');
        var form = $(this).closest('form');
        var input = form.find('input[name="amount"]');
        if (!input.length) input = $('#rechargeAmount');
        input.val(amount).trigger('input').trigger('change').focus();
        form.find('.quick-amount').removeClass('active');
        $(this).addClass('active');
    });

    $('.payment-method-card input[type="radio"]').on('change', function () {
        $('.payment-method-card').removeClass('active');
        $(this).closest('.payment-method-card').addClass('active');
    });

    function renderMonitorChart() {
        var el = document.getElementById('monitorChart');
        if (!el || typeof echarts === 'undefined') return;
        var chart = echarts.init(el);
        function load() {
            $.get(api('/monitor/' + el.dataset.server + '/metrics'), { range: $('#rangeSelect').val() || '1h' }, function (res) {
                var rows = res.data || [];
                chart.setOption({
                    tooltip: { trigger: 'axis' },
                    legend: { data: ['CPU', '内存', '磁盘'] },
                    grid: { left: 40, right: 24, top: 48, bottom: 36 },
                    xAxis: { type: 'category', data: rows.map(function (r) { return r.created_at; }) },
                    yAxis: { type: 'value', max: 100 },
                    series: [
                        { name: 'CPU', type: 'line', smooth: true, data: rows.map(function (r) { return Number(r.cpu_usage); }) },
                        { name: '内存', type: 'line', smooth: true, data: rows.map(function (r) { return Number(r.memory_usage); }) },
                        { name: '磁盘', type: 'line', smooth: true, data: rows.map(function (r) { return Number(r.disk_usage); }) }
                    ]
                });
            });
        }
        $('#rangeSelect').on('change', load);
        load();
        window.addEventListener('resize', function () { chart.resize(); });
    }

    renderMonitorChart();
})();
