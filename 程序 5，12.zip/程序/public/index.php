<?php
define('APP_ROOT', dirname(__DIR__));

require APP_ROOT . '/app/bootstrap.php';

App\Core\Router::dispatch();

