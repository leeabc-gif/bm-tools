<?php
date_default_timezone_set('Asia/Shanghai');

spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) !== 0) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $file = APP_ROOT . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

$vendorAutoload = APP_ROOT . '/vendor/autoload.php';
if (is_file($vendorAutoload)) {
    require $vendorAutoload;
}

if (session_status() === PHP_SESSION_NONE) {
    session_name('BMToolsSID');
    session_start();
}

require APP_ROOT . '/app/helpers.php';

if (is_file(APP_ROOT . '/storage/install.lock') && is_file(APP_ROOT . '/config/database.php')) {
    try {
        App\Core\Auth::bootRemember();
    } catch (Exception $e) {
        App\Core\Logger::error('自动登录初始化失败：' . $e->getMessage());
    }
}

set_exception_handler(function ($e) {
    App\Core\Logger::error($e->getMessage(), [
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString(),
    ]);

    http_response_code(500);
    if (defined('APP_DEBUG') && APP_DEBUG) {
        echo '<pre>' . htmlspecialchars((string) $e, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
    echo '系统繁忙，请稍后再试。';
});
