<?php
namespace App\Core;

class Logger
{
    public static function error($message, array $context = [])
    {
        self::write('error', $message, $context);
    }

    public static function info($message, array $context = [])
    {
        self::write('info', $message, $context);
    }

    protected static function write($level, $message, array $context = [])
    {
        $dir = APP_ROOT . '/storage/logs';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $line = '[' . date('Y-m-d H:i:s') . '] ' . strtoupper($level) . ': ' . $message;
        if ($context) {
            $line .= ' ' . json_encode($context, JSON_UNESCAPED_UNICODE);
        }
        file_put_contents($dir . '/' . date('Y-m-d') . '.log', $line . PHP_EOL, FILE_APPEND);
    }
}

