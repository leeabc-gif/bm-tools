<?php
namespace App\Core;

class Auth
{
    protected static $user;

    public static function check()
    {
        return self::user() !== null;
    }

    public static function id()
    {
        $user = self::user();
        return $user ? (int) $user['id'] : null;
    }

    public static function user()
    {
        if (self::$user !== null) {
            return self::$user;
        }
        if (empty($_SESSION['user_id'])) {
            return null;
        }
        self::$user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$_SESSION['user_id']]);
        if (self::$user) {
            $model = new \App\Models\User();
            if ($model->downgradeIfExpired(self::$user)) {
                self::$user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$_SESSION['user_id']]);
            }
        }
        return self::$user ?: null;
    }

    public static function attempt($account, $password, $remember = false)
    {
        $user = Database::fetch(
            'SELECT * FROM ' . Database::table('users') . ' WHERE (username = ? OR email = ?) LIMIT 1',
            [$account, $account]
        );

        if (!$user || (int) $user['status'] !== 1 || !password_verify($password, $user['password'])) {
            self::logLogin($account, 0);
            return false;
        }

        self::login($user, $remember);
        self::logLogin($account, 1, (int) $user['id']);
        return true;
    }

    public static function login(array $user, $remember = false)
    {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        self::$user = $user;

        $token = $remember ? bin2hex(random_bytes(32)) : null;
        if ($remember) {
            setcookie('remember_token', $token, time() + 86400 * 30, '/', '', false, true);
        }

        Database::execute(
            'UPDATE ' . Database::table('users') . ' SET remember_token = ?, last_login_ip = ?, last_login_time = ?, updated_at = ? WHERE id = ?',
            [$token, self::ip(), now(), now(), $user['id']]
        );
    }

    public static function logout()
    {
        if (self::id()) {
            Database::execute('UPDATE ' . Database::table('users') . ' SET remember_token = NULL WHERE id = ?', [self::id()]);
        }
        self::$user = null;
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        setcookie('remember_token', '', time() - 3600, '/', '', false, true);
        session_destroy();
    }

    public static function bootRemember()
    {
        if (!empty($_SESSION['user_id']) || empty($_COOKIE['remember_token'])) {
            return;
        }
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE remember_token = ? AND status = 1 LIMIT 1', [$_COOKIE['remember_token']]);
        if ($user) {
            $_SESSION['user_id'] = (int) $user['id'];
            self::$user = $user;
        }
    }

    protected static function logLogin($account, $success, $userId = null)
    {
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('login_logs') . ' (user_id, account, ip, user_agent, is_success, created_at) VALUES (?,?,?,?,?,?)',
                [$userId, $account, self::ip(), isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', $success, now()]
            );
        } catch (\Exception $e) {
            Logger::error('登录日志写入失败：' . $e->getMessage());
        }
    }

    public static function ip()
    {
        $keys = ['HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        foreach ($keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = explode(',', $_SERVER[$key]);
                return trim($ip[0]);
            }
        }
        return '0.0.0.0';
    }
}
