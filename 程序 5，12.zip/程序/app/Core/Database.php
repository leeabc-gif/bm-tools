<?php
namespace App\Core;

use PDO;
use PDOException;

class Database
{
    protected static $pdo;
    protected static $prefix;

    public static function getInstance()
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $configPath = APP_ROOT . '/config/database.php';
        if (!is_file($configPath)) {
            throw new \RuntimeException('数据库配置不存在，请先完成安装。');
        }

        $config = require $configPath;
        self::$prefix = isset($config['prefix']) ? $config['prefix'] : 'bm_';
        $charset = isset($config['charset']) ? $config['charset'] : 'utf8mb4';
        $dsn = 'mysql:host=' . $config['host'] . ';port=' . $config['port'] . ';dbname=' . $config['database'] . ';charset=' . $charset;

        try {
            self::$pdo = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            throw new \RuntimeException('数据库连接失败：' . $e->getMessage());
        }

        return self::$pdo;
    }

    public static function prefix()
    {
        if (self::$prefix === null) {
            $configPath = APP_ROOT . '/config/database.php';
            if (is_file($configPath)) {
                $config = require $configPath;
                self::$prefix = isset($config['prefix']) ? $config['prefix'] : 'bm_';
            } else {
                self::$prefix = 'bm_';
            }
        }
        return self::$prefix;
    }

    public static function table($table)
    {
        return self::prefix() . $table;
    }

    public static function query($sql, array $params = [])
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function fetch($sql, array $params = [])
    {
        $stmt = self::query($sql, $params);
        $row = $stmt->fetch();
        return $row ? $row : null;
    }

    public static function fetchAll($sql, array $params = [])
    {
        return self::query($sql, $params)->fetchAll();
    }

    public static function execute($sql, array $params = [])
    {
        return self::query($sql, $params)->rowCount();
    }

    public static function lastInsertId()
    {
        return self::getInstance()->lastInsertId();
    }

    public static function begin()
    {
        self::getInstance()->beginTransaction();
    }

    public static function commit()
    {
        self::getInstance()->commit();
    }

    public static function rollBack()
    {
        if (self::getInstance()->inTransaction()) {
            self::getInstance()->rollBack();
        }
    }
}
