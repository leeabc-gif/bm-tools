<?php
namespace App\Core;

class Config
{
    protected static $items = [];

    public static function get($key, $default = null)
    {
        $segments = explode('.', $key);
        $file = array_shift($segments);

        if (!isset(self::$items[$file])) {
            $path = APP_ROOT . '/config/' . $file . '.php';
            self::$items[$file] = is_file($path) ? require $path : [];
        }

        $value = self::$items[$file];
        foreach ($segments as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }

        return $value;
    }

    public static function set($key, $value)
    {
        $segments = explode('.', $key);
        $file = array_shift($segments);
        if (!isset(self::$items[$file])) {
            self::$items[$file] = [];
        }

        $target =& self::$items[$file];
        foreach ($segments as $segment) {
            if (!isset($target[$segment]) || !is_array($target[$segment])) {
                $target[$segment] = [];
            }
            $target =& $target[$segment];
        }
        $target = $value;
    }
}

