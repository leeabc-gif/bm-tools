<?php
namespace App\Core;

class Router
{
    protected static $routes = [
        'GET' => [
            '/' => 'HomeController@index',
            '/status' => 'HomeController@status',
            '/install' => 'InstallController@index',
            '/login' => 'AuthController@login',
            '/register' => 'AuthController@register',
            '/forgot' => 'AuthController@forgot',
            '/logout' => 'AuthController@logout',
            '/dashboard' => 'UserController@dashboard',
            '/profile' => 'UserController@profile',
            '/password' => 'UserController@password',
            '/packages' => 'PackageController@index',
            '/recharge' => 'RechargeController@index',
            '/balance/logs' => 'RechargeController@balanceLogs',
            '/orders' => 'RechargeController@orders',
            '/pay/alipay/notify' => 'PaymentController@alipayNotify',
            '/files' => 'FileController@index',
            '/files/detail' => 'FileController@detail',
            '/netdisk' => 'NetdiskController@index',
            '/netdisk/recycle' => 'NetdiskController@recycle',
            '/shares' => 'NetdiskController@shares',
            '/monitor' => 'MonitorController@index',
            '/monitor/create' => 'MonitorController@create',
            '/alerts' => 'MonitorController@alerts',
            '/api/console' => 'ApiController@console',
            '/announcements' => 'AnnouncementController@index',
            '/notifications' => 'NotificationController@index',
            '/admin' => 'AdminController@dashboard',
            '/admin/users' => 'AdminController@users',
            '/admin/packages' => 'AdminController@packages',
            '/admin/coupons' => 'AdminController@coupons',
            '/admin/orders' => 'AdminController@orders',
            '/admin/orders/export' => 'AdminController@exportOrders',
            '/admin/recharges' => 'AdminController@recharges',
            '/admin/payments' => 'AdminController@payments',
            '/admin/storages' => 'AdminController@storages',
            '/admin/files' => 'AdminController@files',
            '/admin/api-logs' => 'AdminController@apiLogs',
            '/admin/balance-logs' => 'AdminController@balanceLogs',
            '/admin/monitors' => 'AdminController@monitors',
            '/admin/announcements' => 'AdminController@announcements',
            '/admin/maintenance' => 'AdminController@maintenance',
            '/admin/settings' => 'AdminController@settings',
            '/admin/logs' => 'AdminController@logs',
        ],
        'POST' => [
            '/install' => 'InstallController@install',
            '/install/test-db' => 'InstallController@testDatabase',
            '/login' => 'AuthController@postLogin',
            '/register' => 'AuthController@postRegister',
            '/email-code' => 'AuthController@sendEmailCode',
            '/forgot' => 'AuthController@postForgot',
            '/reset-password' => 'AuthController@postResetPassword',
            '/profile' => 'UserController@updateProfile',
            '/profile/api-token/reset' => 'UserController@resetApiToken',
            '/password' => 'UserController@updatePassword',
            '/packages/buy' => 'PackageController@buy',
            '/recharge' => 'RechargeController@create',
            '/pay/alipay/notify' => 'PaymentController@alipayNotify',
            '/pay/alipay/query' => 'PaymentController@alipayQuery',
            '/files/upload' => 'FileController@upload',
            '/files/fetch' => 'FileController@fetchUrl',
            '/files/delete' => 'FileController@delete',
            '/netdisk/folder' => 'NetdiskController@createFolder',
            '/netdisk/folder/delete' => 'NetdiskController@deleteFolder',
            '/netdisk/upload' => 'NetdiskController@upload',
            '/netdisk/rename' => 'NetdiskController@rename',
            '/netdisk/move' => 'NetdiskController@move',
            '/netdisk/share' => 'NetdiskController@createShare',
            '/netdisk/share/status' => 'NetdiskController@shareStatus',
            '/netdisk/delete' => 'NetdiskController@delete',
            '/netdisk/batch-delete' => 'NetdiskController@batchDelete',
            '/netdisk/restore' => 'NetdiskController@restore',
            '/netdisk/purge' => 'NetdiskController@purge',
            '/monitor' => 'MonitorController@store',
            '/monitor/test' => 'MonitorController@test',
            '/monitor/collect' => 'MonitorController@collect',
            '/monitor/toggle' => 'MonitorController@toggle',
            '/monitor/delete' => 'MonitorController@delete',
            '/alerts/read' => 'MonitorController@markAlertRead',
            '/alerts/resolve' => 'MonitorController@resolveAlert',
            '/notifications/read-all' => 'NotificationController@readAll',
            '/admin/users/update' => 'AdminController@updateUser',
            '/admin/packages/save' => 'AdminController@savePackage',
            '/admin/packages/delete' => 'AdminController@deletePackage',
            '/admin/coupons/save' => 'AdminController@saveCoupon',
            '/admin/coupons/delete' => 'AdminController@deleteCoupon',
            '/admin/storages/save' => 'AdminController@saveStorage',
            '/admin/storages/test' => 'AdminController@testStorage',
            '/admin/storages/default' => 'AdminController@setDefaultStorage',
            '/admin/storages/delete' => 'AdminController@deleteStorage',
            '/admin/files/delete' => 'AdminController@deleteFile',
            '/admin/monitors/toggle' => 'AdminController@toggleMonitor',
            '/admin/monitors/delete' => 'AdminController@deleteMonitor',
            '/admin/monitors/collect' => 'AdminController@collectMonitor',
            '/admin/monitors/save' => 'AdminController@saveMonitor',
            '/admin/monitors/test' => 'AdminController@testMonitor',
            '/admin/alerts/resolve' => 'AdminController@resolveAlert',
            '/admin/announcements/save' => 'AdminController@saveAnnouncement',
            '/admin/announcements/delete' => 'AdminController@deleteAnnouncement',
            '/admin/maintenance' => 'AdminController@saveMaintenance',
            '/admin/maintenance/export-db' => 'AdminController@exportDatabase',
            '/admin/settings' => 'AdminController@saveSettings',
            '/admin/recharges/audit' => 'AdminController@auditRecharge',
            '/admin/orders/manual-paid' => 'AdminController@manualPaidOrder',
            '/admin/payments/save' => 'AdminController@savePayment',
            '/admin/email/test' => 'AdminController@testEmail',
            '/api/upload' => 'ApiController@upload',
            '/api/files' => 'ApiController@files',
            '/api/delete' => 'ApiController@delete',
            '/api/quota' => 'ApiController@quota',
        ],
    ];

    public static function dispatch()
    {
        define('APP_DEBUG', (bool) Config::get('app.debug', false));

        $uri = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
        $uri = '/' . trim($uri, '/');
        if ($uri === '//') {
            $uri = '/';
        }
        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';

        if (!self::installed() && strpos($uri, '/install') !== 0) {
            header('Location: ' . url('install'));
            exit;
        }

        if (self::installed() && self::maintenanceActive($uri)) {
            http_response_code(503);
            header('Content-Type: text/html; charset=utf-8');
            $siteName = function_exists('setting') ? setting('site_name', 'BM TOOLS') : 'BM TOOLS';
            $message = function_exists('setting') ? setting('maintenance_message', '系统正在维护升级，请稍后再访问。') : '系统正在维护升级，请稍后再访问。';
            echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>系统维护中</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;font-family:Arial,"Microsoft YaHei",sans-serif;color:#10243f;background:linear-gradient(135deg,#eef6ff,#ffffff)}.card{width:min(520px,calc(100% - 32px));padding:34px;border-radius:18px;background:rgba(255,255,255,.86);box-shadow:0 24px 70px rgba(23,107,255,.12);border:1px solid #dce9fb}.tag{color:#176bff;font-weight:900;letter-spacing:.08em}.card h1{font-size:34px;margin:12px 0}.card p{line-height:1.8;color:#60748d}.btn{display:inline-flex;margin-top:16px;padding:11px 16px;border-radius:10px;color:#fff;background:#176bff;text-decoration:none;font-weight:900}</style></head><body><main class="card"><span class="tag">' . htmlspecialchars($siteName, ENT_QUOTES, 'UTF-8') . '</span><h1>系统维护中</h1><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><a class="btn" href="' . htmlspecialchars(url('login'), ENT_QUOTES, 'UTF-8') . '">管理员登录</a></main></body></html>';
            return;
        }

        $target = isset(self::$routes[$method][$uri]) ? self::$routes[$method][$uri] : null;

        if (!$target) {
            if (preg_match('#^/monitor/(\d+)$#', $uri, $m)) {
                $target = 'MonitorController@show';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/monitor/(\d+)/metrics$#', $uri, $m)) {
                $target = 'MonitorController@metrics';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/announcements/(\d+)$#', $uri, $m)) {
                $target = 'AnnouncementController@show';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/admin/orders/(\d+)$#', $uri, $m)) {
                $target = 'AdminController@orderDetail';
                $_GET['id'] = (int) $m[1];
            } elseif (preg_match('#^/pay/alipay/([A-Za-z0-9]+)$#', $uri, $m)) {
                $target = 'PaymentController@alipayPage';
                $_GET['order_no'] = $m[1];
            } elseif (preg_match('#^/share/([A-Za-z0-9]+)/download$#', $uri, $m)) {
                $target = 'NetdiskController@shareDownload';
                $_GET['code'] = $m[1];
            } elseif (preg_match('#^/share/([A-Za-z0-9]+)$#', $uri, $m)) {
                $target = 'NetdiskController@shareView';
                $_GET['code'] = $m[1];
            }
        }

        if (!$target) {
            http_response_code(404);
            echo '404 Not Found';
            return;
        }

        list($controller, $action) = explode('@', $target);
        $class = 'App\\Controllers\\' . $controller;
        $instance = new $class();
        call_user_func([$instance, $action]);
    }

    public static function installed()
    {
        return is_file(APP_ROOT . '/storage/install.lock') && is_file(APP_ROOT . '/config/database.php');
    }

    protected static function maintenanceActive($uri)
    {
        if (strpos($uri, '/admin') === 0 || strpos($uri, '/install') === 0 || $uri === '/login' || $uri === '/logout' || $uri === '/pay/alipay/notify') {
            return false;
        }
        try {
            if (class_exists('App\\Core\\Auth') && Auth::check()) {
                $user = Auth::user();
                if ($user && isset($user['role']) && $user['role'] === 'admin') {
                    return false;
                }
            }
            return function_exists('setting') && (string) setting('site_maintenance', '0') === '1';
        } catch (\Exception $e) {
            return false;
        }
    }
}
