<?php
namespace App\Core;

class Validator
{
    public static function required($value)
    {
        return trim((string) $value) !== '';
    }

    public static function email($value)
    {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function username($value)
    {
        return preg_match('/^[A-Za-z0-9_]{3,32}$/', (string) $value) === 1;
    }

    public static function password($value)
    {
        return strlen((string) $value) >= 6;
    }

    public static function int($value, $min = null, $max = null)
    {
        if (filter_var($value, FILTER_VALIDATE_INT) === false) {
            return false;
        }
        $value = (int) $value;
        if ($min !== null && $value < $min) {
            return false;
        }
        if ($max !== null && $value > $max) {
            return false;
        }
        return true;
    }
}

