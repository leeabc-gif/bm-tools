<?php
namespace App\Core;

class Controller
{
    protected function view($view, array $data = [], $layout = 'layouts/app')
    {
        extract($data);
        $viewFile = APP_ROOT . '/app/Views/' . $view . '.php';
        if (!is_file($viewFile)) {
            throw new \RuntimeException('视图不存在：' . $view);
        }
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        $layoutFile = APP_ROOT . '/app/Views/' . $layout . '.php';
        if ($layout && is_file($layoutFile)) {
            require $layoutFile;
        } else {
            echo $content;
        }
    }

    protected function adminView($view, array $data = [])
    {
        $this->requireAdmin();
        $this->view($view, $data, 'layouts/admin');
    }

    protected function json($data, $status = 200)
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function redirect($path)
    {
        header('Location: ' . url($path));
        exit;
    }

    protected function requireLogin()
    {
        if (!Auth::check()) {
            set_flash('error', '请先登录。');
            $this->redirect('login');
        }
    }

    protected function requireAdmin()
    {
        $this->requireLogin();
        $user = Auth::user();
        if (!$user || $user['role'] !== 'admin') {
            http_response_code(403);
            echo '403 Forbidden';
            exit;
        }
    }

    protected function verifyCsrf()
    {
        if (!Csrf::verify(isset($_POST['_token']) ? $_POST['_token'] : '')) {
            set_flash('error', '表单已过期，请重试。');
            remember_old();
            $this->back();
        }
    }

    protected function back()
    {
        $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : url('/');
        header('Location: ' . $referer);
        exit;
    }
}

