<?php
namespace App\Core;

class Model
{
    protected $table = '';
    protected $primaryKey = 'id';

    protected function table()
    {
        return Database::table($this->table);
    }

    public function find($id)
    {
        return Database::fetch('SELECT * FROM ' . $this->table() . ' WHERE ' . $this->primaryKey . ' = ? LIMIT 1', [$id]);
    }

    public function all($order = 'id DESC')
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' ORDER BY ' . $order);
    }

    public function create(array $data)
    {
        $keys = array_keys($data);
        $fields = implode(',', $keys);
        $marks = implode(',', array_fill(0, count($keys), '?'));
        Database::execute('INSERT INTO ' . $this->table() . ' (' . $fields . ') VALUES (' . $marks . ')', array_values($data));
        return Database::lastInsertId();
    }

    public function update($id, array $data)
    {
        $sets = [];
        foreach ($data as $key => $value) {
            $sets[] = $key . ' = ?';
        }
        $params = array_values($data);
        $params[] = $id;
        return Database::execute('UPDATE ' . $this->table() . ' SET ' . implode(',', $sets) . ' WHERE ' . $this->primaryKey . ' = ?', $params);
    }

    public function delete($id)
    {
        return Database::execute('DELETE FROM ' . $this->table() . ' WHERE ' . $this->primaryKey . ' = ?', [$id]);
    }
}

