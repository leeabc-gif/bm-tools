<?php
use App\Core\Config;
use App\Core\Csrf;
use App\Core\Database;

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function url($path = '')
{
    $base = rtrim(Config::get('app.base_url', ''), '/');
    $path = '/' . ltrim((string) $path, '/');
    return $base . $path;
}

function asset($path)
{
    return url('assets/' . ltrim((string) $path, '/'));
}

function csrf_field()
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

function csrf_token()
{
    return Csrf::token();
}

function flash($key, $default = null)
{
    if (!isset($_SESSION['_flash'][$key])) {
        return $default;
    }
    $value = $_SESSION['_flash'][$key];
    unset($_SESSION['_flash'][$key]);
    return $value;
}

function set_flash($key, $value)
{
    $_SESSION['_flash'][$key] = $value;
}

function old($key, $default = '')
{
    return isset($_SESSION['_old'][$key]) ? $_SESSION['_old'][$key] : $default;
}

function remember_old()
{
    $_SESSION['_old'] = $_POST;
}

function clear_old()
{
    unset($_SESSION['_old']);
}

function format_bytes($bytes)
{
    $bytes = (float) $bytes;
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, $i === 0 ? 0 : 2) . ' ' . $units[$i];
}

function setting($key, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        if (file_exists(APP_ROOT . '/config/database.php')) {
            try {
                $rows = Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings'));
                foreach ($rows as $row) {
                    $cache[$row['setting_key']] = $row['setting_value'];
                }
            } catch (Exception $e) {
                $cache = [];
            }
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function now()
{
    return date('Y-m-d H:i:s');
}

function status_label($status)
{
    $map = [
        'online' => '在线',
        'offline' => '离线',
        'unknown' => '未知',
    ];
    return isset($map[$status]) ? $map[$status] : (string) $status;
}

function service_label($status)
{
    $map = [
        'running' => '运行中',
        'stopped' => '已停止',
        'unknown' => '未知',
        'online' => '在线',
        'offline' => '离线',
    ];
    return isset($map[$status]) ? $map[$status] : (string) $status;
}

function service_badge_class($status)
{
    if ($status === 'running' || $status === 'online') {
        return 'service-badge ok';
    }
    if ($status === 'stopped' || $status === 'offline') {
        return 'service-badge bad';
    }
    return 'service-badge muted';
}

function alert_level_label($level)
{
    $map = [
        'info' => '信息',
        'warning' => '警告',
        'danger' => '严重',
    ];
    return isset($map[$level]) ? $map[$level] : (string) $level;
}

function alert_status_label($status)
{
    $map = [
        'unread' => '未读',
        'read' => '已读',
        'resolved' => '已处理',
    ];
    return isset($map[$status]) ? $map[$status] : (string) $status;
}
