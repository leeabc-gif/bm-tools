<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\MonitorMetric;
use App\Models\MonitorServer;
use App\Services\Monitor\MonitorService;

class MonitorController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $group = trim(isset($_GET['group']) ? $_GET['group'] : '');
        $status = trim(isset($_GET['status']) ? $_GET['status'] : '');

        $sql = 'SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE 1=1';
        $params = [];
        if ($keyword !== '') {
            $sql .= ' AND (name LIKE ? OR remark LIKE ? OR server_ip LIKE ? OR panel_url LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        if ($group !== '') {
            $sql .= ' AND group_name = ?';
            $params[] = $group;
        }
        if (in_array($status, ['online', 'offline', 'unknown'], true)) {
            $sql .= ' AND status = ?';
            $params[] = $status;
        }
        $sql .= ' ORDER BY FIELD(status, "offline", "unknown", "online"), id DESC';

        $servers = Database::fetchAll($sql, $params);
        $metricModel = new MonitorMetric();
        foreach ($servers as &$server) {
            $server['latest'] = $metricModel->latest($server['id']);
        }
        unset($server);

        $groups = Database::fetchAll('SELECT group_name, COUNT(*) AS total FROM ' . Database::table('monitor_servers') . ' WHERE group_name <> "" GROUP BY group_name ORDER BY total DESC, group_name ASC');
        $stats = [
            'total' => $this->countMonitorServers(),
            'online' => $this->countMonitorServers("status = 'online'"),
            'offline' => $this->countMonitorServers("status = 'offline'"),
            'unknown' => $this->countMonitorServers("status = 'unknown'"),
            'alerts_today' => $this->countMonitorAlerts("DATE(created_at) = CURDATE()"),
            'unread_alerts' => $this->countMonitorAlerts("status = 'unread'"),
        ];

        $this->view('monitor/index', [
            'title' => '服务器监控',
            'servers' => $servers,
            'groups' => $groups,
            'filters' => ['keyword' => $keyword, 'group' => $group, 'status' => $status],
            'stats' => $stats,
        ]);
    }

    public function create()
    {
        $this->requireLogin();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }
        $this->view('monitor/create', ['title' => '添加服务器']);
    }

    public function store()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $name = trim(isset($_POST['name']) ? $_POST['name'] : '');
        $panelUrl = trim(isset($_POST['panel_url']) ? $_POST['panel_url'] : '');
        $apiKey = trim(isset($_POST['api_key']) ? $_POST['api_key'] : '');
        if ($name === '' || $panelUrl === '' || $apiKey === '') {
            set_flash('error', '请填写服务器名称、宝塔面板地址和 API 密钥。');
            $this->back();
        }

        (new MonitorServer())->create([
            'user_id' => Auth::id(),
            'monitor_type' => 'bt',
            'name' => $name,
            'remark' => trim(isset($_POST['remark']) ? $_POST['remark'] : ''),
            'panel_url' => $panelUrl,
            'api_key' => $apiKey,
            'panel_port' => (int) (isset($_POST['panel_port']) ? $_POST['panel_port'] : 8888),
            'server_ip' => trim(isset($_POST['server_ip']) ? $_POST['server_ip'] : ''),
            'group_name' => trim(isset($_POST['group_name']) ? $_POST['group_name'] : ''),
            'is_enabled' => 1,
            'frequency' => max(30, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 60)),
            'threshold_config' => json_encode([
                'cpu' => (float) (isset($_POST['cpu_threshold']) ? $_POST['cpu_threshold'] : 90),
                'memory' => (float) (isset($_POST['memory_threshold']) ? $_POST['memory_threshold'] : 90),
                'disk' => (float) (isset($_POST['disk_threshold']) ? $_POST['disk_threshold'] : 90),
            ], JSON_UNESCAPED_UNICODE),
            'status' => 'unknown',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        set_flash('success', '监控服务器已添加，建议先执行一次立即采集确认数据。');
        $this->redirect('monitor');
    }

    public function test()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (Auth::user()['role'] !== 'admin') {
            $this->json(['success' => false, 'message' => '只有管理员可以测试运营服务器连接。'], 403);
        }

        $server = [
            'monitor_type' => 'bt',
            'panel_url' => isset($_POST['panel_url']) ? $_POST['panel_url'] : '',
            'api_key' => isset($_POST['api_key']) ? $_POST['api_key'] : '',
            'panel_port' => isset($_POST['panel_port']) ? $_POST['panel_port'] : null,
        ];

        try {
            $data = (new MonitorService())->test($server);
            $this->json(['success' => true, 'message' => '连接成功，已获取到服务器状态数据。', 'data' => $data]);
        } catch (\Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function collect()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (Auth::user()['role'] !== 'admin') {
            $this->json(['success' => false, 'message' => '只有管理员可以手动采集。'], 403);
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $server = (new MonitorServer())->find($id);
        if (!$server) {
            $this->json(['success' => false, 'message' => '服务器不存在。'], 404);
        }

        try {
            (new MonitorService())->collect($server);
            $this->json(['success' => true, 'message' => '采集完成，页面数据将刷新。']);
        } catch (\Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function show()
    {
        $this->requireLogin();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) $_GET['id'];
        $server = (new MonitorServer())->find($id);
        if (!$server) {
            http_response_code(404);
            echo '服务器不存在';
            return;
        }

        $this->view('monitor/show', [
            'title' => $server['name'],
            'server' => $server,
            'latest' => (new MonitorMetric())->latest($id),
            'alerts' => Database::fetchAll('SELECT * FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ? ORDER BY FIELD(status, "unread", "read", "resolved"), id DESC LIMIT 20', [$id]),
            'history' => $this->historySummary($id),
        ]);
    }

    public function metrics()
    {
        $this->requireLogin();
        if (Auth::user()['role'] !== 'admin') {
            $this->json(['success' => false], 403);
        }

        $id = (int) $_GET['id'];
        $range = isset($_GET['range']) ? $_GET['range'] : '1h';
        $server = (new MonitorServer())->find($id);
        if (!$server) {
            $this->json(['success' => false], 404);
        }

        $rows = (new MonitorMetric())->range($id, $range);
        $this->json(['success' => true, 'data' => $rows]);
    }

    public function alerts()
    {
        $this->requireLogin();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $status = isset($_GET['status']) ? trim($_GET['status']) : '';
        $level = isset($_GET['level']) ? trim($_GET['level']) : '';
        $serverId = (int) (isset($_GET['server_id']) ? $_GET['server_id'] : 0);
        if (!in_array($status, ['', 'unread', 'read', 'resolved'], true)) {
            $status = '';
        }
        if (!in_array($level, ['', 'info', 'warning', 'danger'], true)) {
            $level = '';
        }

        $sql = 'SELECT a.*, s.name AS server_name FROM ' . Database::table('monitor_alerts') . ' a LEFT JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id WHERE 1=1';
        $params = [];
        if ($status !== '') {
            $sql .= ' AND a.status = ?';
            $params[] = $status;
        }
        if ($level !== '') {
            $sql .= ' AND a.level = ?';
            $params[] = $level;
        }
        if ($serverId > 0) {
            $sql .= ' AND a.server_id = ?';
            $params[] = $serverId;
        }
        $sql .= ' ORDER BY FIELD(a.status, "unread", "read", "resolved"), a.id DESC LIMIT 300';

        $alerts = Database::fetchAll($sql, $params);
        $servers = Database::fetchAll('SELECT id, name FROM ' . Database::table('monitor_servers') . ' ORDER BY id DESC');
        $stats = [
            'total' => $this->countMonitorAlerts(),
            'unread' => $this->countMonitorAlerts("status = 'unread'"),
            'read' => $this->countMonitorAlerts("status = 'read'"),
            'resolved' => $this->countMonitorAlerts("status = 'resolved'"),
        ];

        $this->view('monitor/alerts', [
            'title' => '告警记录',
            'alerts' => $alerts,
            'servers' => $servers,
            'stats' => $stats,
            'filters' => ['status' => $status, 'level' => $level, 'server_id' => $serverId],
        ]);
    }

    public function markAlertRead()
    {
        $this->updateAlertStatus('read', null, '告警已标记为已读。');
    }

    public function resolveAlert()
    {
        $this->updateAlertStatus('resolved', now(), '告警已标记为已处理。');
    }

    protected function updateAlertStatus($status, $resolvedAt, $message)
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        if ($id <= 0) {
            set_flash('error', '告警记录不存在。');
            $this->back();
        }

        if ($status === 'resolved') {
            Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ?, resolved_at = ? WHERE id = ?', [$status, $resolvedAt, $id]);
        } else {
            Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ? WHERE id = ?', [$status, $id]);
        }
        set_flash('success', $message);
        $this->back();
    }

    public function toggle()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) $_POST['id'];
        $server = (new MonitorServer())->find($id);
        if (!$server) {
            set_flash('error', '服务器不存在。');
            $this->redirect('monitor');
        }

        $enabled = (int) $server['is_enabled'] ? 0 : 1;
        (new MonitorServer())->update($id, ['is_enabled' => $enabled, 'updated_at' => now()]);
        set_flash('success', $enabled ? '监控已启用。' : '监控已暂停。');
        $this->redirect('monitor');
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('status');
        }

        $id = (int) $_POST['id'];
        $server = (new MonitorServer())->find($id);
        if (!$server) {
            set_flash('error', '服务器不存在。');
            $this->redirect('monitor');
        }

        Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ?', [$id]);
        set_flash('success', '监控服务器已删除，历史数据也已清理。');
        $this->redirect('monitor');
    }

    protected function countMonitorServers($where = '1=1')
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('monitor_servers') . ' WHERE ' . $where);
        return $row ? (int) $row['c'] : 0;
    }

    protected function countMonitorAlerts($where = '1=1')
    {
        $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('monitor_alerts') . ' WHERE ' . $where);
        return $row ? (int) $row['c'] : 0;
    }

    protected function historySummary($serverId)
    {
        $rows = Database::fetchAll(
            'SELECT cpu_usage, memory_usage, disk_usage, load_avg, uptime, created_at FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 6',
            [$serverId]
        );
        return array_reverse($rows);
    }
}
