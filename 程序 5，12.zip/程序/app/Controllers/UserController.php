<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Validator;
use App\Models\FileItem;
use App\Models\User;

class UserController extends Controller
{
    public function dashboard()
    {
        $this->requireLogin();
        $user = Auth::user();
        $files = (new FileItem())->userFiles($user['id']);
        $this->view('user/dashboard', [
            'title' => '用户中心',
            'user' => $user,
            'package' => (new User())->packageInfo($user['id']),
            'files' => $files,
            'dashboardStats' => $this->dashboardStats($user),
        ]);
    }

    protected function dashboardStats(array $user)
    {
        $storageTotal = (int) $user['total_storage'];
        $storageUsed = (int) $user['used_storage'];
        $trafficTotal = (int) $user['total_traffic'];
        $trafficUsed = (int) $user['used_traffic'];
        $fileStats = Database::fetch('SELECT COUNT(*) AS total, SUM(file_type = "image") AS images, SUM(file_type = "file") AS files, COALESCE(SUM(file_size),0) AS size FROM ' . Database::table('files') . ' WHERE user_id = ?', [$user['id']]);
        $recent = Database::fetchAll('SELECT id, original_name, file_type, file_size, created_at FROM ' . Database::table('files') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 5', [$user['id']]);
        $storagePercent = $storageTotal > 0 ? min(100, round($storageUsed / $storageTotal * 100, 2)) : 0;
        $trafficPercent = $trafficTotal > 0 ? min(100, round($trafficUsed / $trafficTotal * 100, 2)) : 0;
        $tips = [];
        if ((float) $user['balance'] <= 0) {
            $tips[] = ['title' => '充值余额', 'desc' => '余额不足时无法购买套餐或续费。', 'url' => url('recharge'), 'icon' => 'wallet'];
        }
        if ($storagePercent >= 80) {
            $tips[] = ['title' => '升级容量', 'desc' => '存储空间接近上限，建议升级套餐或清理回收站。', 'url' => url('packages'), 'icon' => 'arrow-up-right'];
        }
        if ((int) $fileStats['total'] === 0) {
            $tips[] = ['title' => '上传第一张图片', 'desc' => '开始使用图床并复制 Markdown/HTML 外链。', 'url' => url('files'), 'icon' => 'upload-cloud'];
        }
        if (!$tips) {
            $tips[] = ['title' => '整理网盘', 'desc' => '按项目建立文件夹，让资料和分享更容易管理。', 'url' => url('netdisk'), 'icon' => 'folder-open'];
        }
        return [
            'storage_percent' => $storagePercent,
            'traffic_percent' => $trafficPercent,
            'file_total' => (int) $fileStats['total'],
            'image_total' => (int) $fileStats['images'],
            'netdisk_total' => (int) $fileStats['files'],
            'file_size' => (int) $fileStats['size'],
            'recent' => $recent,
            'tips' => $tips,
        ];
    }

    public function profile()
    {
        $this->requireLogin();
        $this->view('user/profile', ['title' => '个人资料', 'user' => Auth::user()]);
    }

    public function updateProfile()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $user = Auth::user();
        $nickname = trim(isset($_POST['nickname']) ? $_POST['nickname'] : '');
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        if (!$nickname || !Validator::email($email)) {
            set_flash('error', '昵称或邮箱格式不正确。');
            $this->redirect('profile');
        }
        $userModel = new User();
        if ($userModel->existsEmail($email, $user['id'])) {
            set_flash('error', '邮箱已被占用。');
            $this->redirect('profile');
        }
        $userModel->update($user['id'], [
            'nickname' => $nickname,
            'email' => $email,
            'avatar' => trim(isset($_POST['avatar']) ? $_POST['avatar'] : ''),
            'updated_at' => now(),
        ]);
        set_flash('success', '资料已更新。');
        $this->redirect('profile');
    }

    public function resetApiToken()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $token = bin2hex(random_bytes(24));
        (new User())->update(Auth::id(), [
            'api_token' => $token,
            'updated_at' => now(),
        ]);
        set_flash('success', 'API Token 已重置，旧 Token 将立即失效，请同步更新 PicGo、ShareX 或脚本配置。');
        $this->redirect('profile');
    }

    public function password()
    {
        $this->requireLogin();
        $this->view('user/password', ['title' => '修改密码']);
    }

    public function updatePassword()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $user = Auth::user();
        $old = isset($_POST['old_password']) ? $_POST['old_password'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
        if (!password_verify($old, $user['password']) || !Validator::password($password) || $password !== $confirm) {
            set_flash('error', '原密码错误，或新密码不符合要求。');
            $this->redirect('password');
        }
        (new User())->update($user['id'], ['password' => password_hash($password, PASSWORD_DEFAULT), 'updated_at' => now()]);
        set_flash('success', '密码已修改。');
        $this->redirect('password');
    }
}
