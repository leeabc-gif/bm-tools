<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\FileItem;
use App\Models\Folder;
use App\Models\StorageDriver;
use App\Services\FileService;
use App\Services\FileLogService;
use App\Services\FileTrashService;
use App\Services\Storage\StorageManager;

class NetdiskController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        $folderId = isset($_GET['folder_id']) ? (int) $_GET['folder_id'] : 0;
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $category = isset($_GET['category']) ? trim($_GET['category']) : '';
        if (!in_array($category, ['', 'image', 'document', 'archive', 'video', 'audio', 'other'], true)) {
            $category = '';
        }
        if (!$this->folderBelongsToUser($folderId, Auth::id())) {
            set_flash('error', '文件夹不存在或无权访问。');
            $this->redirect('netdisk');
        }
        $user = Auth::user();
        $this->view('netdisk/index', [
            'title' => '轻量网盘',
            'folderId' => $folderId,
            'folders' => (new Folder())->userFolders(Auth::id(), $folderId),
            'allFolders' => Database::fetchAll('SELECT * FROM ' . Database::table('file_folders') . ' WHERE user_id = ? ORDER BY parent_id ASC, name ASC', [Auth::id()]),
            'files' => (new FileItem())->searchUserFiles(Auth::id(), null, $folderId, $keyword, '', '', $category),
            'keyword' => $keyword,
            'category' => $category,
            'usage' => $this->usageSummary($user),
        ]);
    }

    public function createFolder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $name = trim(isset($_POST['name']) ? $_POST['name'] : '');
        $parentId = (int) (isset($_POST['parent_id']) ? $_POST['parent_id'] : 0);
        if ($name === '') {
            set_flash('error', '文件夹名称不能为空。');
            $this->redirect('netdisk');
        }
        if (!$this->folderBelongsToUser($parentId, Auth::id())) {
            set_flash('error', '父级文件夹不存在或无权访问。');
            $this->redirect('netdisk');
        }
        (new Folder())->create([
            'user_id' => Auth::id(),
            'parent_id' => $parentId,
            'name' => $name,
            'path' => '',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        set_flash('success', '文件夹已创建。');
        $this->redirect('netdisk?folder_id=' . $parentId);
    }

    public function deleteFolder()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $folderId = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $folder = (new Folder())->find($folderId);
        if (!$folder || (int) $folder['user_id'] !== Auth::id()) {
            set_flash('error', '文件夹不存在。');
            $this->redirect('netdisk');
        }

        $childCount = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_folders') . ' WHERE user_id = ? AND parent_id = ?', [Auth::id(), $folderId]);
        if ($childCount && (int) $childCount['c'] > 0) {
            set_flash('error', '该文件夹包含子文件夹，请先处理子文件夹后再删除。');
            $this->redirect('netdisk?folder_id=' . $folder['parent_id']);
        }

        $files = Database::fetchAll('SELECT * FROM ' . Database::table('files') . ' WHERE user_id = ? AND folder_id = ?', [Auth::id(), $folderId]);
        foreach ($files as $file) {
            (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
        }
        Database::execute('DELETE FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ?', [$folderId, Auth::id()]);
        (new FileLogService())->log(Auth::id(), null, 'folder_delete', $folder['name'], 0, ['folder_id' => $folderId, 'files' => count($files)]);
        set_flash('success', '文件夹已删除，文件已移入回收站。');
        $this->redirect('netdisk?folder_id=' . $folder['parent_id']);
    }

    public function upload()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $folderId = (int) (isset($_POST['folder_id']) ? $_POST['folder_id'] : 0);
        try {
            if (!$this->folderBelongsToUser($folderId, Auth::id())) {
                throw new \RuntimeException('目标文件夹不存在或无权访问。');
            }
            if (empty($_FILES['files'])) {
                throw new \RuntimeException('请选择文件。');
            }
            $files = $this->normalizeFiles($_FILES['files']);
            $service = new FileService();
            foreach ($files as $file) {
                $isImage = strpos((string) $file['type'], 'image/') === 0;
                $service->uploadForUser(Auth::user(), $file, $isImage ? 'image' : 'file', $folderId);
            }
            set_flash('success', '文件已上传。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('netdisk?folder_id=' . $folderId);
    }

    public function rename()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $type = $_POST['type'];
        $name = trim($_POST['name']);
        if ($name === '') {
            set_flash('error', '名称不能为空。');
            $this->redirect('netdisk');
        }
        if ($type === 'folder') {
            $folder = (new Folder())->find($id);
            if ($folder && (int) $folder['user_id'] === Auth::id()) {
                (new Folder())->update($id, ['name' => $name, 'updated_at' => now()]);
            }
        } else {
            $file = (new FileItem())->find($id);
            if ($file && (int) $file['user_id'] === Auth::id()) {
                (new FileItem())->update($id, ['original_name' => $name, 'updated_at' => now()]);
            }
        }
        set_flash('success', '名称已更新。');
        $this->redirect('netdisk?folder_id=' . (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0));
    }

    public function move()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $fileId = (int) $_POST['file_id'];
        $folderId = (int) $_POST['folder_id'];
        $file = (new FileItem())->find($fileId);
        if (!$file || (int) $file['user_id'] !== Auth::id()) {
            set_flash('error', '文件不存在。');
            $this->redirect('netdisk');
        }
        if ($folderId > 0) {
            $folder = (new Folder())->find($folderId);
            if (!$folder || (int) $folder['user_id'] !== Auth::id()) {
                set_flash('error', '目标文件夹不存在。');
                $this->redirect('netdisk');
            }
        }
        (new FileItem())->update($fileId, ['folder_id' => $folderId, 'updated_at' => now()]);
        set_flash('success', '文件已移动。');
        $this->redirect('netdisk?folder_id=' . $folderId);
    }

    public function createShare()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        if (!$this->packageAllowsShare()) {
            set_flash('error', '当前套餐不支持文件分享。');
            $this->redirect('netdisk');
        }
        $fileId = (int) (isset($_POST['file_id']) ? $_POST['file_id'] : 0);
        $file = (new FileItem())->find($fileId);
        if (!$file || (int) $file['user_id'] !== Auth::id()) {
            set_flash('error', '文件不存在。');
            $this->redirect('netdisk');
        }
        $code = bin2hex(random_bytes(5));
        $expireDays = (int) (isset($_POST['expire_days']) ? $_POST['expire_days'] : 0);
        Database::execute(
            'INSERT INTO ' . Database::table('file_shares') . ' (user_id, file_id, share_code, extract_code, expire_at, download_limit, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
            [Auth::id(), $fileId, $code, trim(isset($_POST['extract_code']) ? $_POST['extract_code'] : ''), $expireDays > 0 ? date('Y-m-d H:i:s', time() + $expireDays * 86400) : null, (int) (isset($_POST['download_limit']) ? $_POST['download_limit'] : 0), 1, now(), now()]
        );
        set_flash('success', '分享链接已生成：' . url('share/' . $code));
        $this->redirect('shares');
    }

    public function shares()
    {
        $this->requireLogin();
        $shares = Database::fetchAll('SELECT s.*, f.original_name, f.file_url FROM ' . Database::table('file_shares') . ' s LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id WHERE s.user_id = ? ORDER BY s.id DESC', [Auth::id()]);
        $this->view('netdisk/shares', ['title' => '分享记录', 'shares' => $shares]);
    }

    public function recycle()
    {
        $this->requireLogin();
        $items = (new FileTrashService())->userTrash(Auth::id());
        foreach ($items as &$item) {
            $snapshot = json_decode((string) $item['snapshot'], true);
            $item['file'] = is_array($snapshot) ? $snapshot : [];
        }
        $this->view('netdisk/recycle', ['title' => '回收站', 'items' => $items]);
    }

    public function shareStatus()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $status = (int) $_POST['status'];
        Database::execute('UPDATE ' . Database::table('file_shares') . ' SET status = ?, updated_at = ? WHERE id = ? AND user_id = ?', [$status ? 1 : 0, now(), $id, Auth::id()]);
        set_flash('success', '分享状态已更新。');
        $this->redirect('shares');
    }

    public function shareView()
    {
        $code = isset($_GET['code']) ? $_GET['code'] : '';
        $share = Database::fetch('SELECT s.*, f.* FROM ' . Database::table('file_shares') . ' s LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id WHERE s.share_code = ? AND s.status = 1 LIMIT 1', [$code]);
        if (!$this->shareAvailable($share)) {
            http_response_code(404);
            echo '分享不存在或已过期';
            return;
        }
        $inputCode = isset($_GET['extract_code']) ? trim($_GET['extract_code']) : '';
        $locked = !empty($share['extract_code']) && $inputCode !== $share['extract_code'];
        $this->view('netdisk/share_view', [
            'title' => '文件分享',
            'share' => $share,
            'locked' => $locked,
            'extractCode' => $inputCode,
        ]);
    }

    public function shareDownload()
    {
        $code = isset($_GET['code']) ? $_GET['code'] : '';
        $share = Database::fetch('SELECT s.*, f.file_url FROM ' . Database::table('file_shares') . ' s LEFT JOIN ' . Database::table('files') . ' f ON s.file_id = f.id WHERE s.share_code = ? AND s.status = 1 LIMIT 1', [$code]);
        if (!$this->shareAvailable($share)) {
            http_response_code(404);
            echo '分享不存在、已过期或下载次数已达上限';
            return;
        }
        $inputCode = isset($_GET['extract_code']) ? trim($_GET['extract_code']) : '';
        if (!empty($share['extract_code']) && $inputCode !== $share['extract_code']) {
            set_flash('error', '提取码错误。');
            $this->redirect('share/' . $code);
        }
        Database::execute('UPDATE ' . Database::table('file_shares') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $share['id']]);
        Database::execute('UPDATE ' . Database::table('files') . ' SET download_count = download_count + 1, updated_at = ? WHERE id = ?', [now(), $share['file_id']]);
        header('Location: ' . $share['file_url']);
        exit;
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $file = (new FileItem())->find($id);
        if ($file && (int) $file['user_id'] === Auth::id()) {
            (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
            set_flash('success', '文件已移入回收站。');
        }
        $this->redirect('netdisk?folder_id=' . (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0));
    }

    public function batchDelete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
        $currentFolderId = (int) (isset($_POST['current_folder_id']) ? $_POST['current_folder_id'] : 0);
        if (!$ids) {
            set_flash('error', '请选择要删除的文件。');
            $this->redirect('netdisk?folder_id=' . $currentFolderId);
        }

        $count = 0;
        foreach ($ids as $id) {
            $file = (new FileItem())->find((int) $id);
            if ($file && (int) $file['user_id'] === Auth::id()) {
                (new FileTrashService())->moveToTrash($file, $file['file_type'] === 'image' ? 'image_trash' : 'file_trash');
                $count++;
            }
        }
        set_flash('success', '已将 ' . $count . ' 个文件移入回收站。');
        $this->redirect('netdisk?folder_id=' . $currentFolderId);
    }

    public function restore()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        try {
            (new FileTrashService())->restore((int) $_POST['id'], Auth::id());
            set_flash('success', '文件已恢复。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('netdisk/recycle');
    }

    public function purge()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        try {
            $self = $this;
            (new FileTrashService())->purge((int) $_POST['id'], Auth::id(), function ($file) use ($self) {
                $self->deleteRemoteObject($file);
            });
            set_flash('success', '文件已彻底删除。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('netdisk/recycle');
    }

    protected function normalizeFiles(array $files)
    {
        $normalized = [];
        if (is_array($files['name'])) {
            foreach ($files['name'] as $i => $name) {
                $normalized[] = [
                    'name' => $name,
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i],
                ];
            }
        } else {
            $normalized[] = $files;
        }
        return $normalized;
    }

    protected function deleteRemoteObject(array $file)
    {
        if (empty($file['storage_id'])) {
            return;
        }
        try {
            $storage = (new StorageDriver())->find((int) $file['storage_id']);
            if ($storage) {
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Exception $e) {
            \App\Core\Logger::error('远程文件删除失败：' . $e->getMessage(), ['file_id' => $file['id']]);
        }
    }

    protected function packageAllowsShare()
    {
        $user = Auth::user();
        $package = Database::fetch('SELECT allow_share FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        return $package && (int) $package['allow_share'] === 1;
    }

    protected function usageSummary(array $user)
    {
        $count = Database::fetch('SELECT COUNT(*) AS c, COALESCE(SUM(file_size),0) AS s FROM ' . Database::table('files') . ' WHERE user_id = ?', [$user['id']]);
        $folderCount = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('file_folders') . ' WHERE user_id = ?', [$user['id']]);
        $package = Database::fetch('SELECT name, single_file_limit, allow_image, allow_netdisk, allow_api, allow_share, allow_video_preview FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        $total = (int) $user['total_storage'];
        $used = (int) $user['used_storage'];
        $percent = $total > 0 ? min(100, round($used / $total * 100, 2)) : 0;
        return [
            'package' => $package ?: ['name' => '默认套餐', 'single_file_limit' => 0, 'allow_share' => 0, 'allow_video_preview' => 0],
            'file_count' => (int) $count['c'],
            'folder_count' => (int) $folderCount['c'],
            'file_size' => (int) $count['s'],
            'used_storage' => $used,
            'total_storage' => $total,
            'free_storage' => max(0, $total - $used),
            'storage_percent' => $percent,
            'is_near_limit' => $total > 0 && $percent >= 80,
        ];
    }

    protected function shareAvailable($share)
    {
        if (!$share) {
            return false;
        }
        if (!empty($share['expire_at']) && strtotime($share['expire_at']) < time()) {
            return false;
        }
        if ((int) $share['download_limit'] > 0 && (int) $share['download_count'] >= (int) $share['download_limit']) {
            return false;
        }
        return true;
    }

    protected function folderBelongsToUser($folderId, $userId)
    {
        $folderId = (int) $folderId;
        if ($folderId === 0) {
            return true;
        }
        return Database::fetch('SELECT id FROM ' . Database::table('file_folders') . ' WHERE id = ? AND user_id = ? LIMIT 1', [$folderId, $userId]) !== null;
    }
}
