<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\FileItem;
use App\Models\StorageDriver;
use App\Services\FileService;
use App\Services\FileLogService;
use App\Services\FileTrashService;
use App\Services\Storage\StorageManager;

class FileController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $dateStart = trim(isset($_GET['date_start']) ? $_GET['date_start'] : '');
        $dateEnd = trim(isset($_GET['date_end']) ? $_GET['date_end'] : '');
        $user = Auth::user();
        $this->view('files/index', [
            'title' => '图片管理',
            'files' => (new FileItem())->searchUserFiles(Auth::id(), 'image', null, $keyword, $dateStart, $dateEnd),
            'keyword' => $keyword,
            'dateStart' => $dateStart,
            'dateEnd' => $dateEnd,
            'usage' => $this->usageSummary($user, 'image'),
        ]);
    }

    public function upload()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $uploaded = [];
        try {
            if (empty($_FILES['images'])) {
                throw new \RuntimeException('请选择图片。');
            }
            $files = $this->normalizeFiles($_FILES['images']);
            $service = new FileService();
            $failed = [];
            foreach ($files as $file) {
                try {
                    $uploaded[] = $service->uploadForUser(Auth::user(), $file, 'image', 0);
                } catch (\Exception $itemError) {
                    $failed[] = $file['name'] . '：' . $itemError->getMessage();
                }
            }
            if ($uploaded) {
                set_flash('success', '成功上传 ' . count($uploaded) . ' 个文件。');
            }
            if ($failed) {
                set_flash('error', '有 ' . count($failed) . ' 个文件上传失败：' . implode('；', array_slice($failed, 0, 3)) . (count($failed) > 3 ? '；更多失败请分批重试。' : ''));
            }
            if (!$uploaded && $failed) {
                $this->redirect('files');
            }
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('files');
    }

    public function detail()
    {
        $this->requireLogin();
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $file = (new FileItem())->find($id);
        if (!$file || (int) $file['user_id'] !== Auth::id() || $file['file_type'] !== 'image') {
            http_response_code(404);
            echo '图片不存在';
            return;
        }
        $this->view('files/detail', ['title' => '图片详情', 'file' => $file]);
    }

    public function fetchUrl()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $url = trim(isset($_POST['remote_url']) ? $_POST['remote_url'] : '');
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            set_flash('error', '请输入正确的远程图片地址。');
            $this->redirect('files');
        }

        $tmp = tempnam(sys_get_temp_dir(), 'ss_fetch_');
        try {
            $this->assertPublicRemoteUrl($url);
            $maxBytes = $this->remoteFetchMaxBytes(Auth::user());
            $body = $this->download($url, $maxBytes);
            file_put_contents($tmp, $body);
            $name = basename(parse_url($url, PHP_URL_PATH));
            if (!$name || strpos($name, '.') === false) {
                $name = 'remote-' . time() . '.jpg';
            }
            $mime = mime_content_type($tmp);
            if (strpos((string) $mime, 'image/') !== 0 || !@getimagesize($tmp)) {
                throw new \RuntimeException('远程地址返回的不是有效图片。');
            }
            $file = [
                'name' => $name,
                'type' => $mime,
                'tmp_name' => $tmp,
                'error' => UPLOAD_ERR_OK,
                'size' => filesize($tmp),
            ];
            (new FileService())->uploadForUser(Auth::user(), $file, 'image', 0);
            set_flash('success', '远程图片已保存。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        if (is_file($tmp)) {
            unlink($tmp);
        }
        $this->redirect('files');
    }

    public function delete()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : [];
        if (!$ids) {
            set_flash('error', '请选择要删除的图片。');
            $this->redirect('files');
        }
        foreach ($ids as $id) {
            $file = (new FileItem())->find((int) $id);
            if ($file && (int) $file['user_id'] === Auth::id()) {
                (new FileTrashService())->moveToTrash($file, 'image_trash');
            }
        }
        set_flash('success', '已移入回收站，可在网盘回收站中恢复或彻底删除。');
        $this->redirect('files');
    }

    protected function normalizeFiles(array $files)
    {
        $normalized = [];
        if (is_array($files['name'])) {
            foreach ($files['name'] as $i => $name) {
                $normalized[] = [
                    'name' => $name,
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i],
                ];
            }
        } else {
            $normalized[] = $files;
        }
        return $normalized;
    }

    protected function download($url, $maxBytes, $redirects = 0)
    {
        if ($redirects > 3) {
            throw new \RuntimeException('远程拉取失败：跳转次数过多。');
        }
        $this->assertPublicRemoteUrl($url);
        $body = '';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HEADER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'BMTOOLS Fetcher',
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$body, $maxBytes) {
                $body .= $chunk;
                return strlen($body) > $maxBytes ? 0 : strlen($chunk);
            },
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        if ($response === false || $error) {
            if (strlen($body) > $maxBytes) {
                throw new \RuntimeException('远程文件超过允许大小。');
            }
            throw new \RuntimeException('远程拉取失败：' . ($error ?: ('HTTP ' . $code)));
        }
        $headers = substr($response, 0, $headerSize);
        $content = substr($response, $headerSize);
        if (in_array($code, [301, 302, 303, 307, 308], true)) {
            if (!preg_match('/^Location:\s*(.+)$/mi', $headers, $m)) {
                throw new \RuntimeException('远程拉取失败：跳转地址缺失。');
            }
            $next = trim($m[1]);
            if (!preg_match('#^https?://#i', $next)) {
                $parts = parse_url($url);
                $base = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
                $next = $base . '/' . ltrim($next, '/');
            }
            return $this->download($next, $maxBytes, $redirects + 1);
        }
        if ($code >= 400) {
            throw new \RuntimeException('远程拉取失败：HTTP ' . $code);
        }
        if (strlen($content) > $maxBytes) {
            throw new \RuntimeException('远程文件超过允许大小。');
        }
        return $content;
    }

    protected function remoteFetchMaxBytes(array $user)
    {
        $package = Database::fetch('SELECT single_file_limit FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        $limits = [];
        if ($package && (int) $package['single_file_limit'] > 0) {
            $limits[] = (int) $package['single_file_limit'];
        }
        if ((int) $user['total_storage'] > 0) {
            $limits[] = max(0, (int) $user['total_storage'] - (int) $user['used_storage']);
        }
        $limits[] = 50 * 1024 * 1024;
        return max(1, min($limits));
    }

    protected function assertPublicRemoteUrl($url)
    {
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host']) || !in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
            throw new \RuntimeException('仅支持 http 或 https 图片地址。');
        }
        $host = $parts['host'];
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $ips = [$host];
        } else {
            $ips = gethostbynamel($host);
            if (!$ips) {
                throw new \RuntimeException('远程域名无法解析。');
            }
        }
        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                throw new \RuntimeException('不允许拉取内网或保留地址资源。');
            }
        }
    }

    protected function usageSummary(array $user, $type = null)
    {
        $where = 'user_id = ?';
        $params = [$user['id']];
        if ($type) {
            $where .= ' AND file_type = ?';
            $params[] = $type;
        }
        $count = Database::fetch('SELECT COUNT(*) AS c, COALESCE(SUM(file_size),0) AS s FROM ' . Database::table('files') . ' WHERE ' . $where, $params);
        $package = Database::fetch('SELECT name, single_file_limit, allow_image, allow_netdisk, allow_api, allow_share FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        $storage = (new StorageDriver())->defaultDriver();
        $total = (int) $user['total_storage'];
        $used = (int) $user['used_storage'];
        $percent = $total > 0 ? min(100, round($used / $total * 100, 2)) : 0;
        return [
            'package' => $package ?: ['name' => '默认套餐', 'single_file_limit' => 0, 'allow_api' => 0, 'allow_share' => 0],
            'file_count' => (int) $count['c'],
            'file_size' => (int) $count['s'],
            'used_storage' => $used,
            'total_storage' => $total,
            'free_storage' => max(0, $total - $used),
            'storage_percent' => $percent,
            'is_near_limit' => $total > 0 && $percent >= 80,
            'storage' => $storage,
        ];
    }

    protected function deleteRemoteObject(array $file)
    {
        if (empty($file['storage_id'])) {
            return;
        }
        try {
            $storage = (new StorageDriver())->find((int) $file['storage_id']);
            if ($storage) {
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Exception $e) {
            \App\Core\Logger::error('远程文件删除失败：' . $e->getMessage(), ['file_id' => $file['id']]);
        }
    }
}
