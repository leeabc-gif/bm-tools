<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Validator;
use App\Models\User;
use App\Services\MailerService;
use App\Services\NotificationService;

class AuthController extends Controller
{
    public function login()
    {
        $this->view('auth/login', ['title' => '登录']);
    }

    public function postLogin()
    {
        $this->verifyCsrf();
        $account = trim(isset($_POST['account']) ? $_POST['account'] : '');
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $remember = !empty($_POST['remember']);

        if (!Auth::attempt($account, $password, $remember)) {
            set_flash('error', '账号或密码错误，或账号已被禁用。');
            remember_old();
            $this->redirect('login');
        }

        clear_old();
        $user = Auth::user();
        $this->redirect($user['role'] === 'admin' ? 'admin' : 'dashboard');
    }

    public function register()
    {
        if ((string) setting('register_enabled', '1') !== '1') {
            set_flash('error', '站点暂未开放注册。');
            $this->redirect('login');
        }
        $this->view('auth/register', ['title' => '注册']);
    }

    public function postRegister()
    {
        $this->verifyCsrf();
        if ((string) setting('register_enabled', '1') !== '1') {
            set_flash('error', '站点暂未开放注册。');
            $this->redirect('login');
        }

        $username = trim(isset($_POST['username']) ? $_POST['username'] : '');
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
        $userModel = new User();
        $error = '';

        if (!Validator::username($username)) {
            $error = '用户名只能包含字母、数字、下划线，长度 3-32 位。';
        } elseif (!Validator::email($email)) {
            $error = '邮箱格式不正确。';
        } elseif (!Validator::password($password)) {
            $error = '密码长度至少 6 位。';
        } elseif ($password !== $confirm) {
            $error = '两次输入的密码不一致。';
        } elseif ($userModel->existsUsername($username)) {
            $error = '用户名已被注册。';
        } elseif ($userModel->existsEmail($email)) {
            $error = '邮箱已被注册。';
        } elseif ((string) setting('register_email_code_enabled', '0') === '1' && !$this->verifyEmailCode($email, 'register', trim(isset($_POST['email_code']) ? $_POST['email_code'] : ''))) {
            $error = '邮箱验证码错误或已过期。';
        }

        if ($error !== '') {
            set_flash('error', $error);
            remember_old();
            $this->redirect('register');
        }

        $id = $userModel->createUser($username, $email, $password);
        if ((string) setting('register_email_code_enabled', '0') === '1') {
            Database::execute('UPDATE ' . Database::table('email_codes') . ' SET is_used = 1 WHERE email = ? AND scene = ? AND code = ?', [$email, 'register', trim($_POST['email_code'])]);
        }
        $user = $userModel->find($id);
        Auth::login($user, true);
        (new NotificationService())->send($id, 'register', '注册成功', '欢迎加入 ' . setting('site_name', 'BM TOOLS') . '。');
        clear_old();
        $this->redirect('dashboard');
    }

    public function sendEmailCode()
    {
        $this->verifyCsrf();
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        $scene = isset($_POST['scene']) && $_POST['scene'] === 'reset_password' ? 'reset_password' : 'register';
        if (!Validator::email($email)) {
            $this->json(['success' => false, 'message' => '邮箱格式不正确。'], 422);
        }
        $code = (string) mt_rand(100000, 999999);
        Database::execute(
            'INSERT INTO ' . Database::table('email_codes') . ' (email, scene, code, is_used, expired_at, created_at) VALUES (?,?,?,?,?,?)',
            [$email, $scene, $code, 0, date('Y-m-d H:i:s', time() + 900), now()]
        );
        (new MailerService())->send($email, '邮箱验证码', '你的验证码是：' . $code . '，15 分钟内有效。');
        $this->json(['success' => true, 'message' => '验证码已发送。邮件未配置时可在 email_codes 表查看测试验证码。']);
    }

    public function forgot()
    {
        $this->view('auth/forgot', ['title' => '找回密码']);
    }

    public function postForgot()
    {
        $this->verifyCsrf();
        $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
        if (!Validator::email($email)) {
            set_flash('error', '请输入正确邮箱。');
            $this->redirect('forgot');
        }

        $user = (new User())->findByAccount($email);
        if (!$user) {
            set_flash('error', '该邮箱未注册。');
            $this->redirect('forgot');
        }

        $code = (string) mt_rand(100000, 999999);
        Database::execute(
            'INSERT INTO ' . Database::table('email_codes') . ' (email, scene, code, is_used, expired_at, created_at) VALUES (?,?,?,?,?,?)',
            [$email, 'reset_password', $code, 0, date('Y-m-d H:i:s', time() + 900), now()]
        );
        (new MailerService())->send($email, '密码重置验证码', '你的验证码是：' . $code . '，15 分钟内有效。');
        set_flash('success', '验证码已生成。如服务器邮件服务未配置，请在数据库 email_codes 表查看验证码完成测试。');
        $_SESSION['reset_email'] = $email;
        $this->view('auth/reset', ['title' => '重置密码', 'email' => $email]);
    }

    public function postResetPassword()
    {
        $this->verifyCsrf();
        $email = isset($_SESSION['reset_email']) ? $_SESSION['reset_email'] : '';
        $code = trim(isset($_POST['code']) ? $_POST['code'] : '');
        $password = isset($_POST['password']) ? $_POST['password'] : '';

        $record = Database::fetch(
            'SELECT * FROM ' . Database::table('email_codes') . ' WHERE email = ? AND scene = ? AND code = ? AND is_used = 0 AND expired_at >= ? ORDER BY id DESC LIMIT 1',
            [$email, 'reset_password', $code, now()]
        );
        if (!$record || !Validator::password($password)) {
            set_flash('error', '验证码错误或密码不符合要求。');
            $this->redirect('forgot');
        }
        Database::execute('UPDATE ' . Database::table('users') . ' SET password = ?, updated_at = ? WHERE email = ?', [password_hash($password, PASSWORD_DEFAULT), now(), $email]);
        Database::execute('UPDATE ' . Database::table('email_codes') . ' SET is_used = 1 WHERE id = ?', [$record['id']]);
        unset($_SESSION['reset_email']);
        set_flash('success', '密码已重置，请重新登录。');
        $this->redirect('login');
    }

    public function logout()
    {
        Auth::logout();
        $this->redirect('login');
    }

    protected function verifyEmailCode($email, $scene, $code)
    {
        if ($code === '') {
            return false;
        }
        return Database::fetch(
            'SELECT id FROM ' . Database::table('email_codes') . ' WHERE email = ? AND scene = ? AND code = ? AND is_used = 0 AND expired_at >= ? ORDER BY id DESC LIMIT 1',
            [$email, $scene, $code, now()]
        ) !== null;
    }
}
