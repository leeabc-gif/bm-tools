<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Logger;
use App\Models\Announcement;
use App\Models\Coupon;
use App\Models\Package;
use App\Models\StorageDriver;
use App\Models\User;
use App\Services\BalanceService;
use App\Services\CryptoService;
use App\Services\DatabaseUpgradeService;
use App\Services\MailerService;
use App\Services\Monitor\MonitorService;
use App\Services\NotificationService;
use App\Services\Payment\PaymentService;
use App\Services\Storage\StorageManager;
use App\Services\Storage\StorageTestService;

class AdminController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'users' => $this->count('users'),
            'today_users' => $this->count('users', 'DATE(created_at) = CURDATE()'),
            'files' => $this->count('files'),
            'images' => $this->count('files', "file_type = 'image'"),
            'netdisk_files' => $this->count('files', "file_type = 'file'"),
            'storage_used' => Database::fetch('SELECT COALESCE(SUM(file_size),0) AS total FROM ' . Database::table('files'))['total'],
            'today_orders' => $this->count('orders', 'DATE(created_at) = CURDATE()'),
            'today_recharge' => Database::fetch("SELECT COALESCE(SUM(amount),0) AS total FROM " . Database::table('recharges') . " WHERE status = 'paid' AND DATE(paid_at) = CURDATE()")['total'],
            'online_servers' => $this->count('monitor_servers', "is_enabled = 1 AND status = 'online'"),
            'abnormal_servers' => $this->count('monitor_servers', "is_enabled = 1 AND status = 'offline'"),
        ];
        $this->adminView('admin/dashboard', [
            'title' => '运营控制台',
            'stats' => $stats,
            'serverInfo' => $this->localServerInfo(),
            'revenueTrend' => $this->dashboardRevenueTrend(),
            'recentOrders' => $this->dashboardRecentOrders(),
            'pendingRecharges' => $this->dashboardPendingRecharges(),
            'opsTodos' => $this->dashboardOpsTodos(),
        ]);
    }

    public function users()
    {
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        $sql = 'SELECT u.*, p.name AS package_name FROM ' . Database::table('users') . ' u LEFT JOIN ' . Database::table('packages') . ' p ON u.package_id = p.id';
        $params = [];
        if ($keyword !== '') {
            $sql .= ' WHERE u.username LIKE ? OR u.email LIKE ?';
            $params = ['%' . $keyword . '%', '%' . $keyword . '%'];
        }
        $sql .= ' ORDER BY u.id DESC LIMIT 200';
        $this->adminView('admin/users', [
            'title' => '用户管理',
            'users' => Database::fetchAll($sql, $params),
            'packages' => (new Package())->all('sort_order ASC, id ASC'),
        ]);
    }

    public function updateUser()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $oldUser = (new User())->find($id);
        $data = [
            'balance' => round((float) $_POST['balance'], 2),
            'package_id' => (int) $_POST['package_id'],
            'status' => (int) $_POST['status'],
            'updated_at' => now(),
        ];
        if (!empty($_POST['password'])) {
            $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }
        (new User())->update($id, $data);
        if ($oldUser && (float) $oldUser['balance'] !== (float) $data['balance']) {
            (new BalanceService())->log($id, 'adjust', round((float) $data['balance'] - (float) $oldUser['balance'], 2), $oldUser['balance'], $data['balance'], 'admin', Auth::id(), '管理员调整余额');
        }
        $this->adminLog('更新用户', 'user', $id);
        set_flash('success', '用户已更新。');
        $this->redirect('admin/users');
    }

    public function packages()
    {
        $this->adminView('admin/packages', [
            'title' => '套餐管理',
            'packages' => (new Package())->all('sort_order ASC, id ASC'),
            'editPackage' => !empty($_GET['id']) ? (new Package())->find((int) $_GET['id']) : null,
        ]);
    }

    public function savePackage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $data = [
            'name' => trim($_POST['name']),
            'price' => round((float) $_POST['price'], 2),
            'duration_type' => $_POST['duration_type'],
            'duration_days' => (int) $_POST['duration_days'],
            'storage_limit' => (int) $_POST['storage_limit'],
            'traffic_limit' => (int) $_POST['traffic_limit'],
            'single_file_limit' => (int) $_POST['single_file_limit'],
            'allow_image' => isset($_POST['allow_image']) ? 1 : 0,
            'allow_netdisk' => isset($_POST['allow_netdisk']) ? 1 : 0,
            'allow_api' => isset($_POST['allow_api']) ? 1 : 0,
            'allow_monitor' => isset($_POST['allow_monitor']) ? 1 : 0,
            'allow_multi_storage' => isset($_POST['allow_multi_storage']) ? 1 : 0,
            'allow_share' => isset($_POST['allow_share']) ? 1 : 0,
            'allow_video_preview' => isset($_POST['allow_video_preview']) ? 1 : 0,
            'allow_external_link' => isset($_POST['allow_external_link']) ? 1 : 0,
            'status' => (int) $_POST['status'],
            'sort_order' => (int) $_POST['sort_order'],
            'description' => trim($_POST['description']),
            'updated_at' => now(),
        ];
        if ($data['name'] === '') {
            set_flash('error', '请填写套餐名称。');
            $this->back();
        }
        $model = new Package();
        if (!empty($_POST['id'])) {
            $id = (int) $_POST['id'];
            $model->update($id, $data);
        } else {
            $data['created_at'] = now();
            $id = $model->create($data);
        }
        $this->adminLog('保存套餐', 'package', $id);
        set_flash('success', '套餐已保存。');
        $this->redirect('admin/packages');
    }

    public function deletePackage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        (new Package())->delete($id);
        $this->adminLog('删除套餐', 'package', $id);
        set_flash('success', '套餐已删除。');
        $this->redirect('admin/packages');
    }

    public function coupons()
    {
        DatabaseUpgradeService::ensureMarketingSchema();
        $this->adminView('admin/coupons', [
            'title' => '营销活动',
            'coupons' => (new Coupon())->all('sort_order ASC, id DESC'),
            'packages' => (new Package())->all('sort_order ASC, id ASC'),
            'editCoupon' => !empty($_GET['id']) ? (new Coupon())->find((int) $_GET['id']) : null,
            'couponStats' => $this->couponStats(),
            'recentRedemptions' => $this->recentCouponRedemptions(),
        ]);
    }

    public function saveCoupon()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        DatabaseUpgradeService::ensureMarketingSchema();
        $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        $code = strtoupper(trim($_POST['code']));
        $data = [
            'title' => trim($_POST['title']),
            'code' => $code,
            'discount_type' => $_POST['discount_type'] === 'percent' ? 'percent' : 'fixed',
            'discount_value' => round((float) $_POST['discount_value'], 2),
            'min_amount' => round((float) $_POST['min_amount'], 2),
            'package_scope' => in_array($_POST['package_scope'], ['all', 'include', 'exclude'], true) ? $_POST['package_scope'] : 'all',
            'package_ids' => isset($_POST['package_ids']) && is_array($_POST['package_ids']) ? implode(',', array_map('intval', $_POST['package_ids'])) : '',
            'start_at' => $this->normalizeDateTime(isset($_POST['start_at']) ? $_POST['start_at'] : ''),
            'end_at' => $this->normalizeDateTime(isset($_POST['end_at']) ? $_POST['end_at'] : ''),
            'total_limit' => max(0, (int) $_POST['total_limit']),
            'user_limit' => max(0, (int) $_POST['user_limit']),
            'first_order_only' => isset($_POST['first_order_only']) ? 1 : 0,
            'status' => (int) $_POST['status'],
            'sort_order' => (int) $_POST['sort_order'],
            'description' => trim($_POST['description']),
            'updated_at' => now(),
        ];
        if ($data['title'] === '' || $data['code'] === '') {
            set_flash('error', '请填写活动名称和优惠码。');
            $this->back();
        }
        if ($data['discount_value'] <= 0) {
            set_flash('error', '优惠力度必须大于 0。');
            $this->back();
        }
        if ($data['discount_type'] === 'percent' && $data['discount_value'] > 100) {
            set_flash('error', '折扣比例不能超过 100%。');
            $this->back();
        }
        $exists = Database::fetch('SELECT id FROM ' . Database::table('coupons') . ' WHERE code = ? AND id <> ? LIMIT 1', [$data['code'], $id]);
        if ($exists) {
            set_flash('error', '优惠码已存在，请换一个更容易识别的代码。');
            $this->back();
        }
        if ($id) {
            (new Coupon())->update($id, $data);
        } else {
            $data['created_at'] = now();
            $id = (new Coupon())->create($data);
        }
        $this->adminLog('保存营销活动', 'coupon', $id);
        set_flash('success', '营销活动已保存。');
        $this->redirect('admin/coupons');
    }

    public function deleteCoupon()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        DatabaseUpgradeService::ensureMarketingSchema();
        $id = (int) $_POST['id'];
        $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('coupon_redemptions') . ' WHERE coupon_id = ?', [$id]);
        if ($used && (int) $used['c'] > 0) {
            Database::execute('UPDATE ' . Database::table('coupons') . ' SET status = 0, updated_at = ? WHERE id = ?', [now(), $id]);
            set_flash('success', '该活动已有使用记录，已改为停用。');
        } else {
            (new Coupon())->delete($id);
            set_flash('success', '营销活动已删除。');
        }
        $this->adminLog('删除营销活动', 'coupon', $id);
        $this->redirect('admin/coupons');
    }

    public function orders()
    {
        $rows = Database::fetchAll('SELECT o.*, u.username, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC LIMIT 300');
        $this->adminView('admin/orders', ['title' => '订单管理', 'orders' => $rows]);
    }

    public function orderDetail()
    {
        $id = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
        $order = Database::fetch('SELECT o.*, u.username, u.nickname, u.email, u.balance, u.created_at AS user_created_at, p.name AS package_name, p.price AS package_price FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id WHERE o.id = ? LIMIT 1', [$id]);
        if (!$order) {
            set_flash('error', '订单不存在。');
            $this->redirect('admin/orders');
        }
        $recharge = null;
        if ($order['type'] === 'recharge') {
            $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE order_id = ? LIMIT 1', [$order['id']]);
        }
        $balanceLogs = Database::fetchAll('SELECT * FROM ' . Database::table('balance_logs') . ' WHERE related_type IN ("order", "recharge") AND (related_id = ? OR related_id = ?) ORDER BY id DESC LIMIT 20', [$order['id'], $recharge ? $recharge['id'] : 0]);
        $this->adminView('admin/order_detail', [
            'title' => '订单详情',
            'order' => $order,
            'recharge' => $recharge,
            'balanceLogs' => $balanceLogs,
        ]);
    }

    public function exportOrders()
    {
        $this->requireAdmin();
        $rows = Database::fetchAll('SELECT o.*, u.username, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=orders-' . date('YmdHis') . '.csv');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        fputcsv($out, ['订单号', '用户', '类型', '套餐', '原价', '实付', '支付方式', '状态', '交易号', '支付时间', '创建时间']);
        foreach ($rows as $row) {
            fputcsv($out, [$row['order_no'], $row['username'], $row['type'], $row['package_name'], $row['amount'], $row['pay_amount'], $row['payment_method'], $row['status'], $row['trade_no'], $row['paid_at'], $row['created_at']]);
        }
        fclose($out);
        exit;
    }

    public function recharges()
    {
        $rows = Database::fetchAll('SELECT r.*, u.username, o.order_no FROM ' . Database::table('recharges') . ' r LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id LEFT JOIN ' . Database::table('orders') . ' o ON r.order_id = o.id ORDER BY r.id DESC LIMIT 300');
        $this->adminView('admin/recharges', ['title' => '充值审核', 'recharges' => $rows]);
    }

    public function payments()
    {
        $rows = Database::fetchAll('SELECT * FROM ' . Database::table('payment_config') . ' ORDER BY sort_order ASC, id ASC');
        $this->adminView('admin/payments', ['title' => '支付配置', 'payments' => $rows]);
    }

    public function savePayment()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $code = isset($_POST['code']) ? $_POST['code'] : '';
        $config = [];
        if ($code === 'alipay') {
            $config = [
                'app_id' => trim(isset($_POST['app_id']) ? $_POST['app_id'] : ''),
                'private_key' => trim(isset($_POST['private_key']) ? $_POST['private_key'] : ''),
                'alipay_public_key' => trim(isset($_POST['alipay_public_key']) ? $_POST['alipay_public_key'] : ''),
                'sandbox' => !empty($_POST['sandbox']),
                'notify_url' => trim(isset($_POST['notify_url']) ? $_POST['notify_url'] : ''),
                'timeout_express' => trim(isset($_POST['timeout_express']) ? $_POST['timeout_express'] : '10m'),
            ];
        } elseif ($code === 'manual') {
            $config = [
                'instructions' => trim(isset($_POST['instructions']) ? $_POST['instructions'] : ''),
                'contact' => trim(isset($_POST['contact']) ? $_POST['contact'] : ''),
            ];
        } elseif (!empty($_POST['config_json'])) {
            $decoded = json_decode($_POST['config_json'], true);
            if (!is_array($decoded)) {
                set_flash('error', '支付配置 JSON 格式错误。');
                $this->redirect('admin/payments');
            }
            $config = $decoded;
        }
        Database::execute(
            'UPDATE ' . Database::table('payment_config') . ' SET name = ?, config = ?, is_enabled = ?, sort_order = ?, updated_at = ? WHERE id = ?',
            [trim($_POST['name']), json_encode($config, JSON_UNESCAPED_UNICODE), (int) $_POST['is_enabled'], (int) $_POST['sort_order'], now(), $id]
        );
        $this->adminLog('保存支付配置', 'payment', $id);
        set_flash('success', '支付配置已保存。');
        $this->redirect('admin/payments');
    }

    public function auditRecharge()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$recharge || $recharge['status'] !== 'pending') {
            set_flash('error', '充值记录不存在或已处理。');
            $this->redirect('admin/recharges');
        }
        if ($_POST['action'] === 'approve') {
            Database::begin();
            try {
                Database::execute('UPDATE ' . Database::table('recharges') . ' SET status = ?, auditor_id = ?, audit_remark = ?, paid_at = ?, updated_at = ? WHERE id = ?', ['paid', Auth::id(), trim($_POST['remark']), now(), now(), $id]);
                Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, paid_at = ?, updated_at = ? WHERE id = ?', ['paid', now(), now(), $recharge['order_id']]);
                (new BalanceService())->add($recharge['user_id'], $recharge['amount'], 'recharge', 'recharge', $id, '人工充值审核通过');
                (new NotificationService())->send($recharge['user_id'], 'recharge', '充值成功', '你的账户已充值 ' . $recharge['amount'] . ' 元。');
                Database::commit();
            } catch (\Exception $e) {
                Database::rollBack();
                throw $e;
            }
        } else {
            Database::execute('UPDATE ' . Database::table('recharges') . ' SET status = ?, auditor_id = ?, audit_remark = ?, updated_at = ? WHERE id = ?', ['rejected', Auth::id(), trim($_POST['remark']), now(), $id]);
        }
        $this->adminLog('审核充值', 'recharge', $id);
        set_flash('success', '充值审核已处理。');
        $this->redirect('admin/recharges');
    }

    public function manualPaidOrder()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $orderNo = trim($_POST['order_no']);
        $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1', [$orderNo]);
        if (!$order || $order['status'] !== 'pending' || $order['type'] !== 'recharge') {
            set_flash('error', '仅支持处理待支付的充值订单。');
            $this->redirect('admin/orders');
        }
        try {
            (new PaymentService())->markRechargePaid($orderNo, 'MANUAL-' . date('YmdHis'), $order['pay_amount']);
            $this->adminLog('手动补单', 'order', $order['id']);
            set_flash('success', '手动补单成功，余额已入账。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/orders');
    }

    public function storages()
    {
        $storages = (new StorageDriver())->all('is_default DESC, id DESC');
        $this->adminView('admin/storages', [
            'title' => '存储管理',
            'storages' => $storages,
            'editStorage' => !empty($_GET['id']) ? (new StorageDriver())->find((int) $_GET['id']) : null,
            'storageStats' => $this->storageStats($storages),
        ]);
    }

    public function saveStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        $old = $id ? (new StorageDriver())->find($id) : null;
        $type = isset($_POST['type']) ? $_POST['type'] : 'local';
        if (!in_array($type, ['local', 'oss', 'cos', 'kodo'], true)) {
            set_flash('error', '不支持的存储类型。');
            $this->back();
        }
        $secret = trim(isset($_POST['secret_key']) ? $_POST['secret_key'] : '');
        if ($old && $secret === '') {
            $secret = $old['secret_key'];
        }
        $data = $this->normalizeStorageInput([
            'name' => trim($_POST['name']),
            'type' => $type,
            'access_key' => trim(isset($_POST['access_key']) ? $_POST['access_key'] : ''),
            'secret_key' => $secret,
            'bucket' => trim(isset($_POST['bucket']) ? $_POST['bucket'] : ''),
            'region' => trim(isset($_POST['region']) ? $_POST['region'] : ''),
            'endpoint' => trim(isset($_POST['endpoint']) ? $_POST['endpoint'] : ''),
            'domain' => trim(isset($_POST['domain']) ? $_POST['domain'] : ''),
            'prefix' => trim(trim(isset($_POST['prefix']) ? $_POST['prefix'] : ''), '/'),
            'is_enabled' => (int) (isset($_POST['is_enabled']) ? $_POST['is_enabled'] : 1),
            'is_default' => isset($_POST['is_default']) ? 1 : 0,
            'is_public' => isset($_POST['is_public']) ? 1 : 0,
            'updated_at' => now(),
        ]);
        $error = $this->validateStorageInput($data, $secret);
        if ($error !== '') {
            set_flash('error', $error);
            $this->back();
        }
        Database::begin();
        try {
            if ($data['is_default']) {
                Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 0');
            }
            if ($id) {
                (new StorageDriver())->update($id, $data);
            } else {
                $data['created_at'] = now();
                $id = (new StorageDriver())->create($data);
            }
            Database::commit();
        } catch (\Exception $e) {
            Database::rollBack();
            throw $e;
        }
        $this->adminLog('保存存储源', 'storage', $id);
        set_flash('success', '存储源已保存。');
        $this->redirect('admin/storages');
    }

    protected function normalizeStorageInput(array $data)
    {
        foreach (['access_key', 'secret_key', 'bucket', 'region', 'endpoint', 'domain', 'prefix'] as $field) {
            $data[$field] = trim((string) $data[$field]);
        }
        $data['endpoint'] = rtrim($data['endpoint'], '/');
        $data['domain'] = rtrim($data['domain'], '/');
        if ($data['type'] === 'oss') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
            if ($data['bucket'] !== '') {
                $data['endpoint'] = preg_replace('#^' . preg_quote($data['bucket'], '#') . '\.#', '', $data['endpoint']);
            }
        }
        if ($data['type'] === 'cos' && $data['endpoint'] !== '') {
            $data['endpoint'] = preg_replace('#^https?://#i', '', $data['endpoint']);
        }
        if ($data['domain'] !== '' && !preg_match('#^https?://#i', $data['domain'])) {
            $data['domain'] = 'https://' . $data['domain'];
        }
        if ($data['endpoint'] !== '' && in_array($data['type'], ['oss', 'cos', 'kodo'], true) && !preg_match('#^https?://#i', $data['endpoint'])) {
            $data['endpoint'] = 'https://' . $data['endpoint'];
        }
        return $data;
    }

    protected function validateStorageInput(array $data, $secret)
    {
        if ($data['name'] === '') {
            return '请填写存储源名称。';
        }
        if ($data['type'] === 'local') {
            return '';
        }
        if ($data['access_key'] === '') {
            return $data['type'] === 'cos' ? '请填写腾讯云 SecretId。' : '请填写 AccessKey。';
        }
        if ($secret === '') {
            return $data['type'] === 'cos' ? '请填写腾讯云 SecretKey。' : '请填写 SecretKey。';
        }
        if ($data['bucket'] === '') {
            return '请填写 Bucket，也就是对象存储里的空间或桶名称。';
        }
        if ($data['type'] === 'oss' && $data['endpoint'] === '') {
            return '请填写阿里云 OSS Endpoint，例如 oss-cn-hangzhou.aliyuncs.com。';
        }
        if ($data['type'] === 'cos' && $data['region'] === '' && $data['endpoint'] === '') {
            return '请填写腾讯云 COS 地域 Region，例如 ap-guangzhou；Endpoint 可留空。';
        }
        if ($data['type'] === 'kodo' && $data['domain'] === '') {
            return '请填写七牛云 Kodo 访问域名，例如 https://cdn.example.com。';
        }
        return '';
    }

    public function testStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $driver = (new StorageDriver())->find((int) $_POST['id']);
        if (!$driver) {
            $this->json(['success' => false, 'message' => '存储源不存在。'], 404);
        }
        $this->json((new StorageTestService())->run($driver));
    }

    public function setDefaultStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 0');
        Database::execute('UPDATE ' . Database::table('storage_drivers') . ' SET is_default = 1, updated_at = ? WHERE id = ?', [now(), $id]);
        $this->adminLog('设置默认存储源', 'storage', $id);
        set_flash('success', '默认存储源已更新。');
        $this->redirect('admin/storages');
    }

    public function deleteStorage()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE storage_id = ?', [$id]);
        if ($used && (int) $used['c'] > 0) {
            set_flash('error', '该存储源已有文件记录，不能直接删除。');
            $this->redirect('admin/storages');
        }
        (new StorageDriver())->delete($id);
        $this->adminLog('删除存储源', 'storage', $id);
        set_flash('success', '存储源已删除。');
        $this->redirect('admin/storages');
    }

    public function files()
    {
        $rows = Database::fetchAll('SELECT f.*, u.username, s.name AS storage_name FROM ' . Database::table('files') . ' f LEFT JOIN ' . Database::table('users') . ' u ON f.user_id = u.id LEFT JOIN ' . Database::table('storage_drivers') . ' s ON f.storage_id = s.id ORDER BY f.id DESC LIMIT 300');
        $this->adminView('admin/files', ['title' => '文件管理', 'files' => $rows]);
    }

    public function deleteFile()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $file = Database::fetch('SELECT * FROM ' . Database::table('files') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$file) {
            set_flash('error', '文件不存在。');
            $this->redirect('admin/files');
        }
        try {
            $storage = $file['storage_id'] ? (new StorageDriver())->find((int) $file['storage_id']) : null;
            if ($storage) {
                StorageManager::make($storage)->delete($file['file_path']);
            }
        } catch (\Exception $e) {
            Logger::error('后台远程文件删除失败：' . $e->getMessage(), ['file_id' => $id]);
        }
        Database::execute('DELETE FROM ' . Database::table('files') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除文件', 'file', $id);
        set_flash('success', '文件记录已删除。');
        $this->redirect('admin/files');
    }

    public function apiLogs()
    {
        $rows = Database::fetchAll('SELECT l.*, u.username FROM ' . Database::table('api_logs') . ' l LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id ORDER BY l.id DESC LIMIT 300');
        $this->adminView('admin/api_logs', ['title' => 'API 日志', 'logs' => $rows]);
    }

    public function balanceLogs()
    {
        $rows = Database::fetchAll('SELECT l.*, u.username FROM ' . Database::table('balance_logs') . ' l LEFT JOIN ' . Database::table('users') . ' u ON l.user_id = u.id ORDER BY l.id DESC LIMIT 300');
        $this->adminView('admin/balance_logs', ['title' => '余额流水', 'logs' => $rows]);
    }

    public function monitors()
    {
        DatabaseUpgradeService::ensureMonitorSchema();
        $servers = Database::fetchAll('SELECT * FROM ' . Database::table('monitor_servers') . ' ORDER BY id DESC');
        $alerts = Database::fetchAll('SELECT a.*, s.name AS server_name FROM ' . Database::table('monitor_alerts') . ' a LEFT JOIN ' . Database::table('monitor_servers') . ' s ON a.server_id = s.id ORDER BY a.id DESC LIMIT 100');
        $this->adminView('admin/monitors', ['title' => '监控管理', 'servers' => $servers, 'alerts' => $alerts]);
    }

    public function toggleMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$server) {
            set_flash('error', '监控服务器不存在。');
            $this->redirect('admin/monitors');
        }
        Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET is_enabled = ?, updated_at = ? WHERE id = ?', [(int) !$server['is_enabled'], now(), $id]);
        $this->adminLog('切换监控状态', 'monitor_server', $id);
        set_flash('success', '监控状态已更新。');
        $this->redirect('admin/monitors');
    }

    public function collectMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        $server = Database::fetch('SELECT * FROM ' . Database::table('monitor_servers') . ' WHERE id = ? LIMIT 1', [$id]);
        if (!$server) {
            set_flash('error', '监控服务器不存在。');
            $this->redirect('admin/monitors');
        }
        try {
            (new MonitorService())->collect($server);
            set_flash('success', '采集成功。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('admin/monitors');
    }

    public function saveMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        DatabaseUpgradeService::ensureMonitorSchema();
        $monitorType = in_array(isset($_POST['monitor_type']) ? $_POST['monitor_type'] : 'bt', ['bt', 'ssh', 'agent'], true) ? $_POST['monitor_type'] : 'bt';
        $name = trim($_POST['name']);
        if ($name === '') {
            set_flash('error', '服务器名称不能为空。');
            $this->redirect('admin/monitors');
        }
        $data = [
            'user_id' => Auth::id(),
            'monitor_type' => $monitorType,
            'name' => $name,
            'remark' => trim(isset($_POST['remark']) ? $_POST['remark'] : ''),
            'panel_url' => trim(isset($_POST['panel_url']) ? $_POST['panel_url'] : ''),
            'api_key' => trim(isset($_POST['api_key']) ? $_POST['api_key'] : ''),
            'panel_port' => isset($_POST['panel_port']) && (int) $_POST['panel_port'] > 0 ? (int) $_POST['panel_port'] : 8888,
            'server_ip' => trim(isset($_POST['server_ip']) ? $_POST['server_ip'] : ''),
            'ssh_host' => trim(isset($_POST['ssh_host']) ? $_POST['ssh_host'] : ''),
            'ssh_port' => isset($_POST['ssh_port']) && (int) $_POST['ssh_port'] > 0 ? (int) $_POST['ssh_port'] : 22,
            'ssh_username' => trim(isset($_POST['ssh_username']) ? $_POST['ssh_username'] : ''),
            'ssh_auth_type' => isset($_POST['ssh_auth_type']) && $_POST['ssh_auth_type'] === 'key' ? 'key' : 'password',
            'agent_url' => trim(isset($_POST['agent_url']) ? $_POST['agent_url'] : ''),
            'agent_token' => trim(isset($_POST['agent_token']) ? $_POST['agent_token'] : ''),
            'group_name' => trim(isset($_POST['group_name']) ? $_POST['group_name'] : '平台节点'),
            'is_enabled' => isset($_POST['is_enabled']) ? 1 : 0,
            'frequency' => max(30, (int) (isset($_POST['frequency']) ? $_POST['frequency'] : 60)),
            'threshold_config' => json_encode([
                'cpu' => (float) (isset($_POST['cpu_threshold']) ? $_POST['cpu_threshold'] : 90),
                'memory' => (float) (isset($_POST['memory_threshold']) ? $_POST['memory_threshold'] : 90),
                'disk' => (float) (isset($_POST['disk_threshold']) ? $_POST['disk_threshold'] : 90),
            ], JSON_UNESCAPED_UNICODE),
            'updated_at' => now(),
        ];
        if ($monitorType === 'ssh') {
            if (!empty($_POST['ssh_password'])) {
                $data['ssh_password'] = CryptoService::encrypt($_POST['ssh_password']);
            }
            if (!empty($_POST['ssh_private_key'])) {
                $data['ssh_private_key'] = CryptoService::encrypt($_POST['ssh_private_key']);
            }
            if (!empty($_POST['ssh_key_passphrase'])) {
                $data['ssh_key_passphrase'] = CryptoService::encrypt($_POST['ssh_key_passphrase']);
            }
        }
        if (!empty($_POST['id'])) {
            $id = (int) $_POST['id'];
            $existing = Database::fetch('SELECT ssh_password, ssh_private_key, ssh_key_passphrase FROM ' . Database::table('monitor_servers') . ' WHERE id = ? LIMIT 1', [$id]);
            foreach (['ssh_password', 'ssh_private_key', 'ssh_key_passphrase'] as $field) {
                if (!isset($data[$field]) && $existing) {
                    $data[$field] = $existing[$field];
                }
            }
            $set = [];
            $params = [];
            foreach ($data as $key => $value) {
                $set[] = $key . ' = ?';
                $params[] = $value;
            }
            $params[] = $id;
            Database::execute('UPDATE ' . Database::table('monitor_servers') . ' SET ' . implode(',', $set) . ' WHERE id = ?', $params);
        } else {
            $data['status'] = 'unknown';
            $data['created_at'] = now();
            $columns = array_keys($data);
            Database::execute('INSERT INTO ' . Database::table('monitor_servers') . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')', array_values($data));
            $id = Database::lastInsertId();
        }
        $this->adminLog('保存运营监控服务器', 'monitor_server', $id);
        set_flash('success', '运营监控服务器已保存。');
        $this->redirect('admin/monitors');
    }

    public function testMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        DatabaseUpgradeService::ensureMonitorSchema();
        $server = $_POST;
        $server['id'] = !empty($_POST['id']) ? (int) $_POST['id'] : 0;
        if (!empty($_POST['ssh_password'])) {
            $server['ssh_password'] = CryptoService::encrypt($_POST['ssh_password']);
        }
        if (!empty($_POST['ssh_private_key'])) {
            $server['ssh_private_key'] = CryptoService::encrypt($_POST['ssh_private_key']);
        }
        if (!empty($_POST['ssh_key_passphrase'])) {
            $server['ssh_key_passphrase'] = CryptoService::encrypt($_POST['ssh_key_passphrase']);
        }
        try {
            $data = (new MonitorService())->test($server);
            $this->json(['success' => true, 'message' => '连接成功，监控通道可用。', 'data' => $data]);
        } catch (\Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function deleteMonitor()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        Database::execute('DELETE FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_alerts') . ' WHERE server_id = ?', [$id]);
        Database::execute('DELETE FROM ' . Database::table('monitor_servers') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除监控服务器', 'monitor_server', $id);
        set_flash('success', '监控服务器已删除。');
        $this->redirect('admin/monitors');
    }

    public function resolveAlert()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        Database::execute('UPDATE ' . Database::table('monitor_alerts') . ' SET status = ?, resolved_at = ? WHERE id = ?', ['resolved', now(), $id]);
        $this->adminLog('处理监控告警', 'monitor_alert', $id);
        set_flash('success', '告警已标记为已解决。');
        $this->redirect('admin/monitors');
    }

    public function announcements()
    {
        DatabaseUpgradeService::ensureAnnouncementSchema();
        $this->adminView('admin/announcements', [
            'title' => '公告管理',
            'announcements' => Database::fetchAll('SELECT * FROM ' . Database::table('announcements') . ' ORDER BY id DESC'),
            'editAnnouncement' => !empty($_GET['id']) ? Database::fetch('SELECT * FROM ' . Database::table('announcements') . ' WHERE id = ? LIMIT 1', [(int) $_GET['id']]) : null,
            'announcementCategories' => Announcement::categories(),
        ]);
    }

    public function saveAnnouncement()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        DatabaseUpgradeService::ensureAnnouncementSchema();
        $categories = Announcement::categories();
        $category = isset($_POST['category']) && isset($categories[$_POST['category']]) ? $_POST['category'] : 'platform';
        $data = [
            'title' => trim($_POST['title']),
            'content' => trim($_POST['content']),
            'category' => $category,
            'summary' => trim(isset($_POST['summary']) ? $_POST['summary'] : ''),
            'cover_image' => trim(isset($_POST['cover_image']) ? $_POST['cover_image'] : ''),
            'tags' => trim(isset($_POST['tags']) ? $_POST['tags'] : ''),
            'content_format' => isset($_POST['content_format']) && $_POST['content_format'] === 'plain' ? 'plain' : 'html',
            'is_top' => isset($_POST['is_top']) ? 1 : 0,
            'show_home' => isset($_POST['show_home']) ? 1 : 0,
            'status' => (int) $_POST['status'],
            'published_at' => $_POST['published_at'] ?: now(),
            'updated_at' => now(),
        ];
        if (!empty($_POST['id'])) {
            Database::execute('UPDATE ' . Database::table('announcements') . ' SET title=?, content=?, category=?, summary=?, cover_image=?, tags=?, content_format=?, is_top=?, show_home=?, status=?, published_at=?, updated_at=? WHERE id=?', [$data['title'], $data['content'], $data['category'], $data['summary'], $data['cover_image'], $data['tags'], $data['content_format'], $data['is_top'], $data['show_home'], $data['status'], $data['published_at'], $data['updated_at'], (int) $_POST['id']]);
            $id = (int) $_POST['id'];
        } else {
            Database::execute('INSERT INTO ' . Database::table('announcements') . ' (title, content, category, summary, cover_image, tags, content_format, is_top, show_home, status, published_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', [$data['title'], $data['content'], $data['category'], $data['summary'], $data['cover_image'], $data['tags'], $data['content_format'], $data['is_top'], $data['show_home'], $data['status'], $data['published_at'], now(), now()]);
            $id = Database::lastInsertId();
        }
        $this->adminLog('保存公告', 'announcement', $id);
        set_flash('success', '公告已保存。');
        $this->redirect('admin/announcements');
    }

    public function deleteAnnouncement()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $id = (int) $_POST['id'];
        Database::execute('DELETE FROM ' . Database::table('announcements') . ' WHERE id = ?', [$id]);
        $this->adminLog('删除公告', 'announcement', $id);
        set_flash('success', '公告已删除。');
        $this->redirect('admin/announcements');
    }

    public function settings()
    {
        $settings = [];
        foreach (Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings')) as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        $this->adminView('admin/settings', ['title' => '系统设置', 'settings' => $settings, 'packages' => (new Package())->all()]);
    }

    public function saveSettings()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $keys = ['site_name', 'site_logo', 'seo_keywords', 'seo_description', 'register_enabled', 'register_email_code_enabled', 'default_theme', 'home_template', 'file_naming_strategy', 'default_free_package_id', 'api_rate_limit_per_minute', 'api_rate_limit_per_day', 'email_host', 'email_port', 'email_username', 'email_password', 'email_from'];
        foreach ($keys as $key) {
            $value = isset($_POST[$key]) ? $_POST[$key] : '';
            Database::execute(
                'INSERT INTO ' . Database::table('settings') . ' (setting_key, setting_value, created_at, updated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
                [$key, $value, now(), now()]
            );
        }
        $this->adminLog('保存系统设置', 'setting', null);
        set_flash('success', '系统设置已保存。');
        $this->redirect('admin/settings');
    }

    public function testEmail()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $email = trim($_POST['email']);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            set_flash('error', '测试邮箱格式不正确。');
            $this->redirect('admin/settings');
        }
        $ok = (new MailerService())->send($email, '邮件发送测试', '这是一封来自 ' . setting('site_name', 'BM TOOLS') . ' 的测试邮件。');
        set_flash($ok ? 'success' : 'error', $ok ? '测试邮件已发送。' : '测试邮件发送失败，请查看 storage/logs 日志。');
        $this->redirect('admin/settings');
    }

    public function maintenance()
    {
        $settings = [];
        foreach (Database::fetchAll('SELECT setting_key, setting_value FROM ' . Database::table('settings')) as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        $checks = [
            ['name' => 'PHP 版本', 'value' => PHP_VERSION, 'ok' => version_compare(PHP_VERSION, '7.4.0', '>=')],
            ['name' => 'PDO 扩展', 'value' => extension_loaded('pdo') ? '已启用' : '未启用', 'ok' => extension_loaded('pdo')],
            ['name' => 'cURL 扩展', 'value' => extension_loaded('curl') ? '已启用' : '未启用', 'ok' => extension_loaded('curl')],
            ['name' => 'OpenSSL 扩展', 'value' => extension_loaded('openssl') ? '已启用' : '未启用', 'ok' => extension_loaded('openssl')],
            ['name' => 'Fileinfo 扩展', 'value' => extension_loaded('fileinfo') ? '已启用' : '未启用', 'ok' => extension_loaded('fileinfo')],
            ['name' => 'storage 可写', 'value' => is_writable(APP_ROOT . '/storage') ? '可写' : '不可写', 'ok' => is_writable(APP_ROOT . '/storage')],
            ['name' => 'public/uploads 可写', 'value' => is_writable(APP_ROOT . '/public/uploads') ? '可写' : '不可写', 'ok' => is_writable(APP_ROOT . '/public/uploads')],
        ];
        try {
            $db = Database::fetch('SELECT VERSION() AS version');
            $dbVersion = $db ? $db['version'] : 'unknown';
        } catch (\Exception $e) {
            $dbVersion = '读取失败';
        }
        $this->adminView('admin/maintenance', [
            'title' => '系统维护',
            'settings' => $settings,
            'checks' => $checks,
            'serverInfo' => $this->localServerInfo(),
            'databaseVersion' => $dbVersion,
        ]);
    }

    public function saveMaintenance()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $maintenance = isset($_POST['site_maintenance']) ? '1' : '0';
        $message = trim(isset($_POST['maintenance_message']) ? $_POST['maintenance_message'] : '');
        if ($message === '') {
            $message = '系统正在维护升级，请稍后再访问。';
        }
        $this->saveSettingValue('site_maintenance', $maintenance);
        $this->saveSettingValue('maintenance_message', $message);
        $this->adminLog($maintenance === '1' ? '开启维护模式' : '关闭维护模式', 'maintenance', null);
        set_flash('success', $maintenance === '1' ? '维护模式已开启，前台访问将显示维护页。' : '维护模式已关闭，前台已恢复访问。');
        $this->redirect('admin/maintenance');
    }

    public function exportDatabase()
    {
        $this->requireAdmin();
        $this->verifyCsrf();
        $pdo = Database::getInstance();
        $prefix = Database::prefix();
        $tables = [];
        foreach ($pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_NUM) as $row) {
            $name = $row[0];
            if (strpos($name, $prefix) === 0) {
                $tables[] = $name;
            }
        }
        $fileName = 'bmtools-backup-' . date('Ymd-His') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        echo "-- BM TOOLS database backup\n";
        echo "-- Created at " . now() . "\n\n";
        echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";
        foreach ($tables as $table) {
            $quotedTable = $this->quoteIdentifier($table);
            $create = $pdo->query('SHOW CREATE TABLE ' . $quotedTable)->fetch(\PDO::FETCH_ASSOC);
            echo 'DROP TABLE IF EXISTS ' . $quotedTable . ";\n";
            echo $create['Create Table'] . ";\n\n";
            $stmt = $pdo->query('SELECT * FROM ' . $quotedTable);
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $columns = [];
                $values = [];
                foreach ($row as $column => $value) {
                    $columns[] = $this->quoteIdentifier($column);
                    $values[] = $value === null ? 'NULL' : $pdo->quote((string) $value);
                }
                echo 'INSERT INTO ' . $quotedTable . ' (' . implode(',', $columns) . ') VALUES (' . implode(',', $values) . ");\n";
            }
            echo "\n";
        }
        echo "SET FOREIGN_KEY_CHECKS=1;\n";
        $this->adminLog('导出数据库备份', 'maintenance', null);
        exit;
    }

    public function logs()
    {
        $logs = Database::fetchAll('SELECT l.*, u.username FROM ' . Database::table('admin_logs') . ' l LEFT JOIN ' . Database::table('users') . ' u ON l.admin_id = u.id ORDER BY l.id DESC LIMIT 300');
        $this->adminView('admin/logs', ['title' => '管理员日志', 'logs' => $logs]);
    }

    protected function couponStats()
    {
        return [
            'total' => $this->count('coupons'),
            'enabled' => $this->count('coupons', 'status = 1'),
            'used' => $this->count('coupon_redemptions'),
            'discount' => Database::fetch('SELECT COALESCE(SUM(discount_amount),0) AS total FROM ' . Database::table('coupon_redemptions'))['total'],
        ];
    }

    protected function recentCouponRedemptions()
    {
        DatabaseUpgradeService::ensureMarketingSchema();
        return Database::fetchAll('SELECT r.*, c.title AS coupon_title, c.code AS coupon_code, u.username, o.order_no, p.name AS package_name FROM ' . Database::table('coupon_redemptions') . ' r LEFT JOIN ' . Database::table('coupons') . ' c ON r.coupon_id = c.id LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id LEFT JOIN ' . Database::table('orders') . ' o ON r.order_id = o.id LEFT JOIN ' . Database::table('packages') . ' p ON r.package_id = p.id ORDER BY r.id DESC LIMIT 12');
    }

    protected function normalizeDateTime($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace('T', ' ', $value);
        if (strlen($value) === 16) {
            $value .= ':00';
        }
        return $value;
    }

    protected function count($table, $where = '')
    {
        $sql = 'SELECT COUNT(*) AS c FROM ' . Database::table($table);
        if ($where) {
            $sql .= ' WHERE ' . $where;
        }
        return (int) Database::fetch($sql)['c'];
    }

    protected function saveSettingValue($key, $value)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('settings') . ' (setting_key, setting_value, created_at, updated_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
            [$key, $value, now(), now()]
        );
    }

    protected function quoteIdentifier($name)
    {
        return '`' . str_replace('`', '``', $name) . '`';
    }

    protected function dashboardRevenueTrend()
    {
        $orderRows = Database::fetchAll(
            "SELECT DATE(created_at) AS day, COALESCE(SUM(pay_amount),0) AS total, COUNT(*) AS orders_count
             FROM " . Database::table('orders') . "
             WHERE status = 'paid' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
             GROUP BY DATE(created_at)
             ORDER BY day ASC"
        );
        $rechargeRows = Database::fetchAll(
            "SELECT DATE(paid_at) AS day, COALESCE(SUM(amount),0) AS total, COUNT(*) AS recharge_count
             FROM " . Database::table('recharges') . "
             WHERE status = 'paid' AND paid_at IS NOT NULL AND paid_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
             GROUP BY DATE(paid_at)
             ORDER BY day ASC"
        );
        $days = [];
        for ($i = 6; $i >= 0; $i--) {
            $days[date('Y-m-d', strtotime('-' . $i . ' day'))] = [
                'day' => date('m/d', strtotime('-' . $i . ' day')),
                'orders_total' => 0,
                'recharge_total' => 0,
                'orders_count' => 0,
                'recharge_count' => 0,
            ];
        }
        foreach ($orderRows as $row) {
            if (isset($days[$row['day']])) {
                $days[$row['day']]['orders_total'] = (float) $row['total'];
                $days[$row['day']]['orders_count'] = (int) $row['orders_count'];
            }
        }
        foreach ($rechargeRows as $row) {
            if (isset($days[$row['day']])) {
                $days[$row['day']]['recharge_total'] = (float) $row['total'];
                $days[$row['day']]['recharge_count'] = (int) $row['recharge_count'];
            }
        }
        return array_values($days);
    }

    protected function dashboardRecentOrders()
    {
        return Database::fetchAll(
            'SELECT o.*, u.username, u.nickname, p.name AS package_name FROM ' . Database::table('orders') . ' o LEFT JOIN ' . Database::table('users') . ' u ON o.user_id = u.id LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id ORDER BY o.id DESC LIMIT 8'
        );
    }

    protected function dashboardPendingRecharges()
    {
        return Database::fetchAll(
            'SELECT r.*, u.username, o.order_no FROM ' . Database::table('recharges') . ' r LEFT JOIN ' . Database::table('users') . ' u ON r.user_id = u.id LEFT JOIN ' . Database::table('orders') . ' o ON r.order_id = o.id WHERE r.status = \'pending\' ORDER BY r.id DESC LIMIT 8'
        );
    }

    protected function dashboardOpsTodos()
    {
        $storages = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('storage_drivers') . ' WHERE is_default = 1 AND is_enabled = 1');
        $pendingRecharge = $this->count('recharges', "status = 'pending'");
        $pendingOrders = $this->count('orders', "status = 'pending'");
        $offlineServers = $this->count('monitor_servers', "is_enabled = 1 AND status = 'offline'");
        return [
            'default_storage' => $storages ? (int) $storages['c'] : 0,
            'pending_recharge' => $pendingRecharge,
            'pending_orders' => $pendingOrders,
            'offline_servers' => $offlineServers,
        ];
    }

    protected function storageStats(array $storages)
    {
        $stats = ['total' => count($storages), 'enabled' => 0, 'cloud' => 0, 'default_name' => '未设置'];
        foreach ($storages as $storage) {
            if (!empty($storage['is_enabled'])) {
                $stats['enabled']++;
            }
            if (isset($storage['type']) && $storage['type'] !== 'local') {
                $stats['cloud']++;
            }
            if (!empty($storage['is_default'])) {
                $stats['default_name'] = $storage['name'];
            }
        }
        return $stats;
    }

    protected function localServerInfo()
    {
        try {
            $row = Database::fetch('SELECT VERSION() AS version');
            $dbVersion = $row ? $row['version'] : 'unknown';
        } catch (\Exception $e) {
            $dbVersion = '读取失败';
        }
        $root = defined('APP_ROOT') ? APP_ROOT : dirname(__DIR__, 2);
        $diskTotal = @disk_total_space($root);
        $diskFree = @disk_free_space($root);
        $diskUsed = $diskTotal && $diskFree !== false ? $diskTotal - $diskFree : 0;
        $extensions = [];
        foreach (['pdo', 'curl', 'openssl', 'fileinfo', 'mbstring', 'gd'] as $ext) {
            $extensions[$ext] = extension_loaded($ext);
        }
        return [
            'os' => php_uname('s') . ' ' . php_uname('r'),
            'php_version' => PHP_VERSION,
            'server_software' => isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'CLI/Unknown',
            'database_version' => $dbVersion,
            'memory_limit' => ini_get('memory_limit'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size'),
            'max_execution_time' => ini_get('max_execution_time') . 's',
            'disk_total' => $diskTotal ? format_bytes($diskTotal) : 'unknown',
            'disk_used' => $diskTotal ? format_bytes($diskUsed) : 'unknown',
            'disk_free' => $diskFree !== false ? format_bytes($diskFree) : 'unknown',
            'extensions' => $extensions,
            'time' => now(),
        ];
    }

    protected function adminLog($action, $targetType = null, $targetId = null)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('admin_logs') . ' (admin_id, action, target_type, target_id, ip, detail, created_at) VALUES (?,?,?,?,?,?,?)',
            [Auth::id(), $action, $targetType, $targetId, Auth::ip(), json_encode($this->redactLogData($_POST), JSON_UNESCAPED_UNICODE), now()]
        );
    }

    protected function redactLogData(array $data)
    {
        foreach ($data as $key => $value) {
            if (preg_match('/(password|secret|token|key|api_key)/i', (string) $key)) {
                $data[$key] = $value === '' ? '' : '******';
            } elseif (is_array($value)) {
                $data[$key] = $this->redactLogData($value);
            }
        }
        return $data;
    }
}
