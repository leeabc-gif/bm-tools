<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Models\Coupon;
use App\Models\Package;
use App\Services\DatabaseUpgradeService;
use App\Services\PackageService;

class PackageController extends Controller
{
    public function index()
    {
        DatabaseUpgradeService::ensureMarketingSchema();
        $this->view('packages/index', [
            'title' => '套餐',
            'packages' => (new Package())->enabled(),
            'coupons' => (new Coupon())->activeList(),
        ]);
    }

    public function buy()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        try {
            (new PackageService())->buyWithBalance(
                Auth::id(),
                (int) $_POST['package_id'],
                isset($_POST['coupon_code']) ? $_POST['coupon_code'] : ''
            );
            set_flash('success', '套餐购买成功。');
        } catch (\Exception $e) {
            set_flash('error', $e->getMessage());
        }
        $this->redirect('packages');
    }
}
