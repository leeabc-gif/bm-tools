<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\Order;
use App\Models\Recharge;
use App\Services\Payment\PaymentManager;

class RechargeController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        $this->view('recharge/index', [
            'title' => '账户充值',
            'recharges' => (new Recharge())->userRecharges(Auth::id()),
            'payments' => $this->enabledPayments(),
        ]);
    }

    public function create()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        $amount = round((float) (isset($_POST['amount']) ? $_POST['amount'] : 0), 2);
        $method = isset($_POST['payment_method']) ? $_POST['payment_method'] : 'manual';
        if ($amount <= 0) {
            set_flash('error', '充值金额必须大于 0。');
            $this->redirect('recharge');
        }
        $payment = $this->enabledPayment($method);
        if (!$payment) {
            set_flash('error', '该支付方式未启用或不存在，请选择可用支付方式。');
            $this->redirect('recharge');
        }
        if (in_array($method, ['wechat', 'epay', 'balance'], true)) {
            set_flash('error', '该支付方式当前未完成生产接入，请联系管理员配置真实支付网关。');
            $this->redirect('recharge');
        }

        $order = (new Order())->createOrder(Auth::id(), 'recharge', $amount, $method, null, '账户充值');
        (new Recharge())->create([
            'user_id' => Auth::id(),
            'order_id' => $order['id'],
            'amount' => $amount,
            'payment_method' => $method,
            'status' => 'pending',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $gateway = PaymentManager::driver($method);
        try {
            $result = $gateway->create($order);
        } catch (\Exception $e) {
            Database::execute('UPDATE ' . Database::table('orders') . ' SET status = ?, updated_at = ? WHERE id = ?', ['closed', now(), $order['id']]);
            Database::execute('UPDATE ' . Database::table('recharges') . ' SET status = ?, audit_remark = ?, updated_at = ? WHERE order_id = ?', ['rejected', mb_substr($e->getMessage(), 0, 250), now(), $order['id']]);
            set_flash('error', $e->getMessage());
            $this->redirect('recharge');
        }
        if ($method === 'alipay' && !empty($result['qr_code'])) {
            $_SESSION['alipay_qr'][$order['order_no']] = $result['qr_code'];
            $this->redirect('pay/alipay/' . $order['order_no']);
        }
        set_flash('success', $result['message']);
        $this->redirect('recharge');
    }

    public function orders()
    {
        $this->requireLogin();
        $this->view('recharge/orders', [
            'title' => '订单记录',
            'orders' => (new Order())->userOrders(Auth::id()),
        ]);
    }

    public function balanceLogs()
    {
        $this->requireLogin();
        $logs = Database::fetchAll('SELECT * FROM ' . Database::table('balance_logs') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 200', [Auth::id()]);
        $this->view('recharge/balance_logs', [
            'title' => '余额流水',
            'logs' => $logs,
        ]);
    }

    protected function enabledPayments()
    {
        $rows = Database::fetchAll('SELECT * FROM ' . Database::table('payment_config') . ' WHERE is_enabled = 1 ORDER BY sort_order ASC, id ASC');
        $allowed = [];
        foreach ($rows as $row) {
            if (in_array($row['code'], ['manual', 'alipay'], true)) {
                $allowed[] = $row;
            }
        }
        return $allowed;
    }

    protected function enabledPayment($code)
    {
        if (!preg_match('/^[a-z0-9_]+$/', (string) $code)) {
            return null;
        }
        return Database::fetch('SELECT * FROM ' . Database::table('payment_config') . ' WHERE code = ? AND is_enabled = 1 LIMIT 1', [$code]);
    }
}
