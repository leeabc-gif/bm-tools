<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\Notification;

class NotificationController extends Controller
{
    public function index()
    {
        $this->requireLogin();
        $this->view('notifications/index', [
            'title' => '通知中心',
            'notifications' => (new Notification())->userNotifications(Auth::id()),
        ]);
    }

    public function readAll()
    {
        $this->requireLogin();
        $this->verifyCsrf();
        Database::execute('UPDATE ' . Database::table('notifications') . ' SET is_read = 1, read_at = ? WHERE user_id = ?', [now(), Auth::id()]);
        set_flash('success', '通知已全部标记为已读。');
        $this->redirect('notifications');
    }
}

