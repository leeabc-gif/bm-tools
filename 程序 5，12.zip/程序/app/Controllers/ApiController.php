<?php
namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Models\FileItem;
use App\Models\StorageDriver;
use App\Services\FileService;
use App\Services\FileLogService;
use App\Services\Storage\StorageManager;

class ApiController extends Controller
{
    public function console()
    {
        $this->requireLogin();
        $logs = Database::fetchAll('SELECT * FROM ' . Database::table('api_logs') . ' WHERE user_id = ? ORDER BY id DESC LIMIT 100', [Auth::id()]);
        $this->view('user/api', [
            'title' => 'API 管理',
            'user' => Auth::user(),
            'logs' => $logs,
        ]);
    }

    public function upload()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'upload');

        if (empty($_FILES['file'])) {
            $this->apiError($user, 'upload', '请选择 file 字段上传。', 422);
        }

        try {
            $type = isset($_POST['type']) && $_POST['type'] === 'file' ? 'file' : 'image';
            $file = (new FileService())->uploadForUser($user, $_FILES['file'], $type, 0);
            $this->logApi($user['id'], 'upload', 200, true, '上传成功');
            $this->json([
                'success' => true,
                'data' => [
                    'id' => $file['id'],
                    'name' => $file['original_name'],
                    'size' => (int) $file['file_size'],
                    'mime' => $file['mime_type'],
                    'url' => $file['file_url'],
                    'markdown' => '![' . $file['original_name'] . '](' . $file['file_url'] . ')',
                    'html' => '<img src="' . $file['file_url'] . '" alt="' . htmlspecialchars($file['original_name'], ENT_QUOTES, 'UTF-8') . '">',
                    'bbcode' => '[img]' . $file['file_url'] . '[/img]',
                ],
            ]);
        } catch (\Exception $e) {
            $this->apiError($user, 'upload', $e->getMessage(), 422);
        }
    }

    public function files()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'files');
        $page = max(1, (int) (isset($_POST['page']) ? $_POST['page'] : 1));
        $limit = min(100, max(1, (int) (isset($_POST['limit']) ? $_POST['limit'] : 20)));
        $offset = ($page - 1) * $limit;
        $type = isset($_POST['type']) && in_array($_POST['type'], ['image', 'file'], true) ? $_POST['type'] : null;
        $keyword = trim(isset($_POST['keyword']) ? $_POST['keyword'] : '');

        $where = 'WHERE user_id = ?';
        $params = [$user['id']];
        if ($type) {
            $where .= ' AND file_type = ?';
            $params[] = $type;
        }
        if ($keyword !== '') {
            $where .= ' AND (original_name LIKE ? OR file_name LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        }
        $rows = Database::fetchAll('SELECT id, file_type, original_name, file_ext, mime_type, file_size, file_url, thumbnail_url, created_at FROM ' . Database::table('files') . ' ' . $where . ' ORDER BY id DESC LIMIT ' . $offset . ',' . $limit, $params);
        $total = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' ' . $where, $params);
        $this->logApi($user['id'], 'files', 200, true, '获取文件列表');
        $this->json(['success' => true, 'data' => ['page' => $page, 'limit' => $limit, 'total' => (int) $total['c'], 'items' => $rows]]);
    }

    public function delete()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'delete');
        $id = (int) (isset($_POST['id']) ? $_POST['id'] : 0);
        $file = (new FileItem())->find($id);
        if (!$file || (int) $file['user_id'] !== (int) $user['id']) {
            $this->apiError($user, 'delete', '文件不存在。', 404);
        }
        try {
            if ($file['storage_id']) {
                $storage = (new StorageDriver())->find((int) $file['storage_id']);
                if ($storage) {
                    StorageManager::make($storage)->delete($file['file_path']);
                }
            }
            Database::execute('DELETE FROM ' . Database::table('files') . ' WHERE id = ?', [$id]);
            Database::execute('UPDATE ' . Database::table('users') . ' SET used_storage = IF(used_storage >= ?, used_storage - ?, 0), updated_at = ? WHERE id = ?', [$file['file_size'], $file['file_size'], now(), $user['id']]);
            (new FileLogService())->log($user['id'], $id, 'api_delete', $file['original_name'], $file['file_size']);
            $this->logApi($user['id'], 'delete', 200, true, '删除文件');
            $this->json(['success' => true, 'message' => '文件已删除。']);
        } catch (\Exception $e) {
            $this->apiError($user, 'delete', $e->getMessage(), 422);
        }
    }

    public function quota()
    {
        $user = $this->apiUser();
        $this->assertApiAllowed($user);
        $this->rateLimit($user, 'quota');
        $count = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('files') . ' WHERE user_id = ?', [$user['id']]);
        $this->logApi($user['id'], 'quota', 200, true, '获取容量');
        $this->json([
            'success' => true,
            'data' => [
                'used_storage' => (int) $user['used_storage'],
                'total_storage' => (int) $user['total_storage'],
                'used_traffic' => (int) $user['used_traffic'],
                'total_traffic' => (int) $user['total_traffic'],
                'file_count' => (int) $count['c'],
                'balance' => $user['balance'],
            ],
        ]);
    }

    protected function apiUser()
    {
        $token = isset($_POST['token']) ? trim($_POST['token']) : (isset($_SERVER['HTTP_X_API_TOKEN']) ? trim($_SERVER['HTTP_X_API_TOKEN']) : '');
        $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE api_token = ? AND status = 1 LIMIT 1', [$token]);
        if (!$user) {
            $this->logApi(null, 'auth', 401, false, 'API Token 无效');
            $this->json(['success' => false, 'message' => 'API Token 无效。'], 401);
        }
        return $user;
    }

    protected function assertApiAllowed(array $user)
    {
        $package = Database::fetch('SELECT allow_api FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        if (!$package || (int) $package['allow_api'] !== 1) {
            $this->apiError($user, 'auth', '当前套餐不允许 API 调用。', 403);
        }
    }

    protected function rateLimit(array $user, $endpoint)
    {
        $perMinute = (int) setting('api_rate_limit_per_minute', 60);
        $perDay = (int) setting('api_rate_limit_per_day', 1000);
        if ($perMinute > 0) {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('api_logs') . ' WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)', [$user['id']]);
            if ((int) $row['c'] >= $perMinute) {
                $this->apiError($user, $endpoint, 'API 调用过于频繁，请稍后再试。', 429);
            }
        }
        if ($perDay > 0) {
            $row = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('api_logs') . ' WHERE user_id = ? AND created_at >= CURDATE()', [$user['id']]);
            if ((int) $row['c'] >= $perDay) {
                $this->apiError($user, $endpoint, '今日 API 调用次数已达上限。', 429);
            }
        }
    }

    protected function apiError($user, $endpoint, $message, $status)
    {
        $this->logApi($user ? $user['id'] : null, $endpoint, $status, false, $message);
        $this->json(['success' => false, 'message' => $message], $status);
    }

    protected function logApi($userId, $endpoint, $status, $success, $message)
    {
        Database::execute(
            'INSERT INTO ' . Database::table('api_logs') . ' (user_id, endpoint, method, ip, status_code, is_success, message, created_at) VALUES (?,?,?,?,?,?,?,?)',
            [$userId, $endpoint, isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'POST', \App\Core\Auth::ip(), $status, $success ? 1 : 0, $message, now()]
        );
    }
}
