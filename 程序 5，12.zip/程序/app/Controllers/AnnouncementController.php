<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Announcement;
use App\Services\DatabaseUpgradeService;

class AnnouncementController extends Controller
{
    public function index()
    {
        DatabaseUpgradeService::ensureAnnouncementSchema();
        $model = new Announcement();
        $category = trim(isset($_GET['category']) ? $_GET['category'] : '');
        $keyword = trim(isset($_GET['keyword']) ? $_GET['keyword'] : '');
        if ($category === 'all') {
            $category = '';
        }
        $this->view('announcements/index', [
            'title' => '公告中心',
            'announcements' => $model->visibleByCategory($category, $keyword),
            'categories' => Announcement::categories(),
            'counts' => $model->categoryCounts(),
            'currentCategory' => $category,
            'keyword' => $keyword,
        ], 'layouts/announcement');
    }

    public function show()
    {
        DatabaseUpgradeService::ensureAnnouncementSchema();
        $model = new Announcement();
        $item = $model->find((int) $_GET['id']);
        if (!$item || (int) $item['status'] !== 1) {
            http_response_code(404);
            echo '公告不存在';
            return;
        }
        $model->incrementViews($item['id']);
        $item['view_count'] = (int) $item['view_count'] + 1;
        $this->view('announcements/show', [
            'title' => $item['title'],
            'item' => $item,
            'categories' => Announcement::categories(),
        ], 'layouts/announcement');
    }
}
