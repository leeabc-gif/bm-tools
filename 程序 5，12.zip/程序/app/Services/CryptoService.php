<?php
namespace App\Services;

use App\Core\Config;

class CryptoService
{
    public static function encrypt($plain)
    {
        $plain = (string) $plain;
        if ($plain === '') {
            return '';
        }
        $key = self::key();
        $iv = random_bytes(16);
        $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) {
            throw new \RuntimeException('敏感配置加密失败，请检查 openssl 扩展。');
        }
        return base64_encode($iv) . ':' . base64_encode($cipher);
    }

    public static function decrypt($payload)
    {
        $payload = (string) $payload;
        if ($payload === '') {
            return '';
        }
        if (strpos($payload, ':') === false) {
            return $payload;
        }
        list($iv, $cipher) = explode(':', $payload, 2);
        $iv = base64_decode($iv, true);
        $cipher = base64_decode($cipher, true);
        if ($iv === false || $cipher === false) {
            return '';
        }
        $plain = openssl_decrypt($cipher, 'AES-256-CBC', self::key(), OPENSSL_RAW_DATA, $iv);
        return $plain === false ? '' : $plain;
    }

    protected static function key()
    {
        $secret = (string) Config::get('app.security.secret_key', '');
        if ($secret === '' || $secret === 'bm-tools-change-this-secret-key') {
            $db = APP_ROOT . '/config/database.php';
            if (is_file($db)) {
                $secret = hash_file('sha256', $db);
            } else {
                $secret = hash('sha256', APP_ROOT);
            }
        }
        return hash('sha256', $secret, true);
    }
}
