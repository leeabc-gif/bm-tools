<?php
namespace App\Services;

use App\Core\Config;
use App\Core\Database;
use App\Models\FileItem;
use App\Models\StorageDriver;
use App\Services\Storage\StorageManager;
use App\Services\FileLogService;

class FileService
{
    public function uploadForUser($user, array $file, $type = 'image', $folderId = 0)
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('上传失败，错误码：' . $file['error']);
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = $type === 'image' ? Config::get('app.upload.image_ext', []) : Config::get('app.upload.file_ext', []);
        if (!in_array($ext, $allowed, true)) {
            throw new \RuntimeException('不支持的文件类型。');
        }
        $this->assertFileContent($file, $type);

        $driverRecord = (new StorageDriver())->defaultDriver();
        if (!$driverRecord) {
            throw new \RuntimeException('请先在后台配置默认对象存储。');
        }

        $freshUser = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1', [$user['id']]);
        if (!$freshUser) {
            throw new \RuntimeException('用户不存在或已被禁用。');
        }
        $package = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$freshUser['package_id']]);
        $this->assertPackageAllow($package, $type, $file['size'], $freshUser);

        $objectKey = $this->buildObjectKey($file['name'], $ext, $type);
        $driver = StorageManager::make($driverRecord);
        $result = $driver->upload($file['tmp_name'], $objectKey, ['mime' => $file['type']]);

        $imageSize = $type === 'image' ? @getimagesize($file['tmp_name']) : null;
        $fileModel = new FileItem();
        Database::begin();
        try {
            $lockedUser = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? AND status = 1 LIMIT 1 FOR UPDATE', [$user['id']]);
            if (!$lockedUser) {
                throw new \RuntimeException('用户不存在或已被禁用。');
            }
            $this->assertPackageAllow($package, $type, $file['size'], $lockedUser);

            $id = $fileModel->create([
                'user_id' => $user['id'],
                'storage_id' => $driverRecord['id'],
                'folder_id' => $folderId,
                'file_type' => $type,
                'file_name' => basename($objectKey),
                'original_name' => $file['name'],
                'file_ext' => $ext,
                'mime_type' => $file['type'],
                'file_size' => $file['size'],
                'file_path' => $result['path'],
                'file_url' => $result['url'],
                'thumbnail_url' => $result['url'],
                'md5' => md5_file($file['tmp_name']),
                'width' => $imageSize ? $imageSize[0] : null,
                'height' => $imageSize ? $imageSize[1] : null,
                'is_public' => 1,
                'download_count' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            Database::execute('UPDATE ' . Database::table('users') . ' SET used_storage = used_storage + ?, updated_at = ? WHERE id = ?', [$file['size'], now(), $user['id']]);
            (new FileLogService())->log($user['id'], $id, $type === 'image' ? 'image_upload' : 'file_upload', $file['name'], $file['size'], ['storage_id' => $driverRecord['id']]);
            Database::commit();
            return $fileModel->find($id);
        } catch (\Exception $e) {
            Database::rollBack();
            try {
                $driver->delete($result['path']);
            } catch (\Exception $deleteError) {
                \App\Core\Logger::error('上传入库失败后清理远程文件失败：' . $deleteError->getMessage(), ['path' => $result['path']]);
            }
            throw $e;
        }
    }

    protected function assertPackageAllow($package, $type, $size, array $user)
    {
        if (!$package) {
            throw new \RuntimeException('当前账户未绑定套餐。');
        }
        if ($type === 'image' && !(int) $package['allow_image']) {
            throw new \RuntimeException('当前套餐不允许图床上传。');
        }
        if ($type === 'file' && !(int) $package['allow_netdisk']) {
            throw new \RuntimeException('当前套餐不允许网盘上传。');
        }
        if ((int) $package['single_file_limit'] > 0 && $size > (int) $package['single_file_limit']) {
            throw new \RuntimeException('文件大小超过套餐单文件限制。');
        }
        if ((int) $user['total_storage'] > 0 && ((int) $user['used_storage'] + $size) > (int) $user['total_storage']) {
            throw new \RuntimeException('剩余存储空间不足。');
        }
    }

    protected function assertFileContent(array $file, $type)
    {
        if (!is_file($file['tmp_name'])) {
            throw new \RuntimeException('上传临时文件不存在，请重试。');
        }

        $mime = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo) {
                $mime = (string) finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
            }
        }
        if ($mime === '' && function_exists('mime_content_type')) {
            $mime = (string) mime_content_type($file['tmp_name']);
        }

        if ($type === 'image') {
            $size = @getimagesize($file['tmp_name']);
            if (!$size || empty($size['mime']) || strpos($size['mime'], 'image/') !== 0) {
                throw new \RuntimeException('上传文件不是有效图片。');
            }
            $allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp'];
            if ($mime && !in_array($mime, $allowedMimes, true)) {
                throw new \RuntimeException('图片 MIME 类型异常：' . $mime);
            }
            return;
        }

        $blocked = ['application/x-php', 'text/x-php', 'application/x-httpd-php'];
        if ($mime && in_array($mime, $blocked, true)) {
            throw new \RuntimeException('出于安全考虑，不允许上传可执行脚本文件。');
        }
    }

    protected function buildObjectKey($originalName, $ext, $type)
    {
        $strategy = setting('file_naming_strategy', 'random');
        if ($strategy === 'original') {
            $name = pathinfo($originalName, PATHINFO_FILENAME);
            $name = preg_replace('/[^A-Za-z0-9_\x{4e00}-\x{9fa5}-]+/u', '-', $name);
        } elseif ($strategy === 'timestamp') {
            $name = date('YmdHis') . mt_rand(1000, 9999);
        } elseif ($strategy === 'hash') {
            $name = sha1($originalName . microtime(true) . mt_rand());
        } else {
            $name = bin2hex(random_bytes(12));
        }
        return trim($type, '/') . '/' . date('Y/m/d') . '/' . $name . '.' . $ext;
    }
}
