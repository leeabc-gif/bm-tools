<?php
namespace App\Services\Monitor;

use App\Services\CryptoService;

class SshMonitorClient
{
    protected $server;
    protected $timeout = 15;

    public function __construct(array $server)
    {
        $this->server = $server;
    }

    public function test()
    {
        $output = $this->exec('printf "BMTOOLS_SSH_OK"');
        if (trim($output) !== 'BMTOOLS_SSH_OK') {
            throw new \RuntimeException('SSH 连接成功，但测试命令返回异常。');
        }
        return true;
    }

    public function collect()
    {
        $json = $this->exec($this->collectCommand());
        $data = json_decode($json, true);
        if (!is_array($data)) {
            throw new \RuntimeException('SSH 采集结果无法解析，请确认目标服务器为 Linux 且常用命令可用。返回：' . mb_substr(trim($json), 0, 160));
        }
        return $data;
    }

    protected function exec($command)
    {
        if (class_exists('\\phpseclib3\\Net\\SSH2')) {
            return $this->execByPhpseclib($command);
        }
        if (function_exists('ssh2_connect')) {
            return $this->execByExtension($command);
        }
        throw new \RuntimeException('当前环境缺少 SSH 客户端能力。请安装 Composer 依赖 phpseclib/phpseclib，或安装 PHP ssh2 扩展。推荐：composer require phpseclib/phpseclib:^3.0');
    }

    protected function execByPhpseclib($command)
    {
        $class = '\\phpseclib3\\Net\\SSH2';
        $ssh = new $class($this->host(), $this->port(), $this->timeout);
        if (!$this->loginPhpseclib($ssh)) {
            throw new \RuntimeException('SSH 登录失败，请检查用户名、密码/私钥和服务器安全组。');
        }
        $ssh->setTimeout($this->timeout);
        $output = $ssh->exec($command);
        if ($output === false) {
            throw new \RuntimeException('SSH 命令执行失败。');
        }
        return $output;
    }

    protected function loginPhpseclib($ssh)
    {
        $username = $this->username();
        if ($this->authType() === 'key') {
            if (!class_exists('\\phpseclib3\\Crypt\\PublicKeyLoader')) {
                throw new \RuntimeException('phpseclib 缺少 PublicKeyLoader，无法使用私钥登录。');
            }
            $loader = '\\phpseclib3\\Crypt\\PublicKeyLoader';
            $key = $loader::load(CryptoService::decrypt(isset($this->server['ssh_private_key']) ? $this->server['ssh_private_key'] : ''), CryptoService::decrypt(isset($this->server['ssh_key_passphrase']) ? $this->server['ssh_key_passphrase'] : ''));
            return $ssh->login($username, $key);
        }
        return $ssh->login($username, CryptoService::decrypt(isset($this->server['ssh_password']) ? $this->server['ssh_password'] : ''));
    }

    protected function execByExtension($command)
    {
        $connection = @ssh2_connect($this->host(), $this->port());
        if (!$connection) {
            throw new \RuntimeException('SSH 连接失败，请检查 IP、端口、防火墙和安全组。');
        }
        if ($this->authType() === 'key') {
            throw new \RuntimeException('当前 ssh2 扩展备用通道暂不支持数据库私钥内容登录，请安装 phpseclib 3.0。');
        }
        if (!@ssh2_auth_password($connection, $this->username(), CryptoService::decrypt(isset($this->server['ssh_password']) ? $this->server['ssh_password'] : ''))) {
            throw new \RuntimeException('SSH 登录失败，请检查用户名和密码。');
        }
        $stream = @ssh2_exec($connection, $command);
        if (!$stream) {
            throw new \RuntimeException('SSH 命令执行失败。');
        }
        stream_set_blocking($stream, true);
        stream_set_timeout($stream, $this->timeout);
        $output = stream_get_contents($stream);
        fclose($stream);
        return $output;
    }

    protected function collectCommand()
    {
        return <<<'SH'
printf '{';
printf '"uptime":"%s",' "$(uptime -p 2>/dev/null | sed 's/"/\\"/g')";
printf '"load":"%s",' "$(cat /proc/loadavg 2>/dev/null | awk '{print $1","$2","$3}')";
printf '"mem_total":%s,' "$(awk '/MemTotal/ {print $2*1024}' /proc/meminfo)";
printf '"mem_available":%s,' "$(awk '/MemAvailable/ {print $2*1024}' /proc/meminfo)";
printf '"cpu_line_1":"%s",' "$(head -n1 /proc/stat)";
sleep 1;
printf '"cpu_line_2":"%s",' "$(head -n1 /proc/stat)";
printf '"disk":[';
df -B1 -P | awk 'NR>1 {printf "%s{\"path\":\"%s\",\"total\":%s,\"used\":%s}", sep, $6, $2, $3; sep=","}';
printf '],';
printf '"network":[';
cat /proc/net/dev | awk 'NR>2 {gsub(":","",$1); printf "%s{\"iface\":\"%s\",\"rx\":%s,\"tx\":%s}", sep, $1, $2, $10; sep=","}';
printf ']';
printf '}';
SH;
    }

    protected function host()
    {
        $host = trim((string) (isset($this->server['ssh_host']) && $this->server['ssh_host'] !== '' ? $this->server['ssh_host'] : (isset($this->server['server_ip']) ? $this->server['server_ip'] : '')));
        if ($host === '') {
            throw new \RuntimeException('SSH 主机不能为空。');
        }
        return $host;
    }

    protected function port()
    {
        $port = (int) (isset($this->server['ssh_port']) ? $this->server['ssh_port'] : 22);
        return $port > 0 ? $port : 22;
    }

    protected function username()
    {
        $username = trim((string) (isset($this->server['ssh_username']) ? $this->server['ssh_username'] : ''));
        if ($username === '') {
            throw new \RuntimeException('SSH 用户名不能为空。');
        }
        return $username;
    }

    protected function authType()
    {
        return isset($this->server['ssh_auth_type']) && $this->server['ssh_auth_type'] === 'key' ? 'key' : 'password';
    }
}
