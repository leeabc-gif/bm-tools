<?php
namespace App\Services\Monitor;

use App\Core\Logger;

class BtPanelClient
{
    protected $panelUrl;
    protected $apiKey;
    protected $cookieFile;

    public function __construct($panelUrl, $apiKey, $port = null)
    {
        $this->panelUrl = $this->normalizePanelUrl($panelUrl, $port);
        $this->apiKey = $apiKey;
        $this->cookieFile = APP_ROOT . '/storage/cache/bt_' . md5($this->panelUrl . $apiKey) . '.cookie';
    }

    public function request($path, array $data = [])
    {
        $requestTime = time();
        $data['request_time'] = $requestTime;
        $data['request_token'] = md5($requestTime . md5($this->apiKey));

        $url = $this->panelUrl . '/' . ltrim($path, '/');
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_COOKIEJAR => $this->cookieFile,
            CURLOPT_COOKIEFILE => $this->cookieFile,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded',
                'User-Agent: BMTOOLS-Monitor/1.0',
            ],
        ]);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $error) {
            throw new \RuntimeException('宝塔 API 连接失败：' . ($error ?: '未知网络错误') . '，请检查面板地址、端口、防火墙和 API 白名单。');
        }
        if ($code >= 400) {
            Logger::error('宝塔 API HTTP 异常', ['url' => $url, 'code' => $code, 'body' => mb_substr($body, 0, 500)]);
            throw new \RuntimeException('宝塔 API HTTP 状态异常：' . $code . '，请确认面板地址可访问。');
        }

        $json = json_decode($body, true);
        if (!is_array($json)) {
            Logger::error('宝塔 API 返回无法解析', ['url' => $url, 'body' => mb_substr($body, 0, 500)]);
            throw new \RuntimeException('宝塔 API 返回无法解析，可能是面板登录页、404 页面或反向代理拦截：' . mb_substr(strip_tags($body), 0, 120));
        }
        if (isset($json['status']) && $json['status'] === false && isset($json['msg'])) {
            throw new \RuntimeException('宝塔 API 返回错误：' . $json['msg']);
        }
        if (isset($json['msg']) && is_string($json['msg']) && stripos($json['msg'], 'api') !== false && stripos($json['msg'], 'not') !== false) {
            throw new \RuntimeException('宝塔 API 可能未开启或 IP 未加入白名单：' . $json['msg']);
        }
        return $json;
    }

    public function systemTotal()
    {
        return $this->request('/system?action=GetSystemTotal');
    }

    public function diskInfo()
    {
        return $this->request('/system?action=GetDiskInfo');
    }

    public function network()
    {
        return $this->request('/system?action=GetNetWork');
    }

    public function serviceStatus($name)
    {
        return $this->request('/system?action=ServiceAdmin', ['name' => $name, 'type' => 'status']);
    }

    protected function normalizePanelUrl($panelUrl, $port = null)
    {
        $panelUrl = trim((string) $panelUrl);
        if ($panelUrl === '') {
            throw new \InvalidArgumentException('宝塔面板地址不能为空。');
        }
        if (!preg_match('#^https?://#i', $panelUrl)) {
            $panelUrl = 'http://' . $panelUrl;
        }
        $parts = parse_url($panelUrl);
        if (!$parts || empty($parts['host'])) {
            throw new \InvalidArgumentException('宝塔面板地址格式不正确。');
        }
        $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'http';
        $host = $parts['host'];
        $path = isset($parts['path']) ? rtrim($parts['path'], '/') : '';
        $finalPort = isset($parts['port']) ? $parts['port'] : ($port ? (int) $port : null);
        $url = $scheme . '://' . $host . ($finalPort ? ':' . $finalPort : '') . $path;
        return rtrim($url, '/');
    }
}
