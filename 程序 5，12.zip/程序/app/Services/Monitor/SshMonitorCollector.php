<?php
namespace App\Services\Monitor;

use App\Core\Database;

class SshMonitorCollector
{
    public function test(array $server)
    {
        return (new SshMonitorClient($server))->test();
    }

    public function collect(array $server)
    {
        $client = new SshMonitorClient($server);
        $data = $client->collect();

        $memoryTotal = (float) (isset($data['mem_total']) ? $data['mem_total'] : 0);
        $memoryAvailable = (float) (isset($data['mem_available']) ? $data['mem_available'] : 0);
        $memoryUsed = max(0, $memoryTotal - $memoryAvailable);
        $memoryUsage = $memoryTotal > 0 ? round($memoryUsed / $memoryTotal * 100, 2) : 0;

        $diskTotal = 0;
        $diskUsed = 0;
        $realDisks = isset($data['disk']) && is_array($data['disk']) ? $this->realDisks($data['disk']) : [];
        if ($realDisks) {
            foreach ($realDisks as $disk) {
                $diskTotal += (float) (isset($disk['total']) ? $disk['total'] : 0);
                $diskUsed += (float) (isset($disk['used']) ? $disk['used'] : 0);
            }
        }
        $diskUsage = $diskTotal > 0 ? round($diskUsed / $diskTotal * 100, 2) : 0;

        $net = $this->networkSpeed($server, $data);

        return [
            'cpu_usage' => $this->cpuUsage(isset($data['cpu_line_1']) ? $data['cpu_line_1'] : '', isset($data['cpu_line_2']) ? $data['cpu_line_2'] : ''),
            'memory_total' => (int) $memoryTotal,
            'memory_used' => (int) $memoryUsed,
            'memory_usage' => $memoryUsage,
            'disk_total' => (int) $diskTotal,
            'disk_used' => (int) $diskUsed,
            'disk_usage' => $diskUsage,
            'net_upload' => $net['upload'],
            'net_download' => $net['download'],
            'load_avg' => (string) (isset($data['load']) ? $data['load'] : ''),
            'uptime' => (string) (isset($data['uptime']) ? $data['uptime'] : ''),
            'nginx_status' => 'unknown',
            'mysql_status' => 'unknown',
            'php_status' => 'unknown',
            'panel_status' => 'ssh',
            'raw_data' => ['ssh' => array_merge($data, ['disk' => $realDisks]), 'services' => ['source' => 'ssh']],
        ];
    }

    protected function realDisks(array $disks)
    {
        $rows = [];
        foreach ($disks as $disk) {
            if (!is_array($disk)) {
                continue;
            }
            $path = isset($disk['path']) ? (string) $disk['path'] : '';
            if ($this->isIgnoredDisk($path)) {
                continue;
            }
            $rows[] = $disk;
        }
        return $rows;
    }

    protected function isIgnoredDisk($path)
    {
        foreach (['/run', '/dev', '/sys', '/proc', '/var/lib/docker/overlay', '/var/lib/docker/containers'] as $prefix) {
            if ($path === $prefix || strpos($path, $prefix . '/') === 0) {
                return true;
            }
        }
        return false;
    }

    protected function cpuUsage($line1, $line2)
    {
        $a = $this->cpuParts($line1);
        $b = $this->cpuParts($line2);
        if (!$a || !$b) {
            return 0;
        }
        $idleDelta = ($b['idle'] + $b['iowait']) - ($a['idle'] + $a['iowait']);
        $totalDelta = $b['total'] - $a['total'];
        if ($totalDelta <= 0) {
            return 0;
        }
        return round(($totalDelta - $idleDelta) / $totalDelta * 100, 2);
    }

    protected function cpuParts($line)
    {
        $parts = preg_split('/\s+/', trim((string) $line));
        if (count($parts) < 8 || $parts[0] !== 'cpu') {
            return null;
        }
        $values = array_map('floatval', array_slice($parts, 1));
        return [
            'idle' => isset($values[3]) ? $values[3] : 0,
            'iowait' => isset($values[4]) ? $values[4] : 0,
            'total' => array_sum($values),
        ];
    }

    protected function networkSpeed(array $server, array $data)
    {
        $currentRx = 0;
        $currentTx = 0;
        if (isset($data['network']) && is_array($data['network'])) {
            foreach ($data['network'] as $row) {
                $iface = isset($row['iface']) ? (string) $row['iface'] : '';
                if ($iface === 'lo') {
                    continue;
                }
                $currentRx += (float) (isset($row['rx']) ? $row['rx'] : 0);
                $currentTx += (float) (isset($row['tx']) ? $row['tx'] : 0);
            }
        }

        $previous = Database::fetch('SELECT raw_data, created_at FROM ' . Database::table('monitor_metrics') . ' WHERE server_id = ? ORDER BY id DESC LIMIT 1', [$server['id']]);
        if (!$previous || empty($previous['raw_data'])) {
            return ['upload' => 0, 'download' => 0];
        }

        $raw = json_decode($previous['raw_data'], true);
        $previousNetwork = isset($raw['ssh']['network']) && is_array($raw['ssh']['network']) ? $raw['ssh']['network'] : [];
        $previousRx = 0;
        $previousTx = 0;
        foreach ($previousNetwork as $row) {
            $iface = isset($row['iface']) ? (string) $row['iface'] : '';
            if ($iface === 'lo') {
                continue;
            }
            $previousRx += (float) (isset($row['rx']) ? $row['rx'] : 0);
            $previousTx += (float) (isset($row['tx']) ? $row['tx'] : 0);
        }

        $seconds = max(1, time() - strtotime($previous['created_at']));
        return [
            'upload' => max(0, round(($currentTx - $previousTx) / $seconds, 2)),
            'download' => max(0, round(($currentRx - $previousRx) / $seconds, 2)),
        ];
    }
}
