<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Models\Coupon;

class CouponService
{
    public function quote($userId, array $package, $amount, $code)
    {
        $amount = round(max(0, (float) $amount), 2);
        $code = strtoupper(trim((string) $code));
        if ($code === '' || $amount <= 0) {
            return [
                'coupon' => null,
                'discount' => 0.00,
                'final_amount' => $amount,
                'message' => '',
            ];
        }

        $coupon = (new Coupon())->findByCode($code);
        $this->assertUsable($coupon, $userId, $package, $amount);

        $discount = $this->calculateDiscount($coupon, $amount);
        return [
            'coupon' => $coupon,
            'discount' => $discount,
            'final_amount' => round(max(0, $amount - $discount), 2),
            'message' => '优惠码已生效，抵扣 ' . number_format($discount, 2) . ' 元',
        ];
    }

    public function redeem(array $coupon, $userId, $orderId, $packageId, $discount, $finalAmount)
    {
        if (!$coupon || (float) $discount <= 0) {
            return;
        }
        Database::execute(
            'INSERT INTO ' . Database::table('coupon_redemptions') . ' (coupon_id, user_id, order_id, package_id, discount_amount, final_amount, ip, used_at) VALUES (?,?,?,?,?,?,?,?)',
            [(int) $coupon['id'], $userId, $orderId, $packageId, round((float) $discount, 2), round((float) $finalAmount, 2), Auth::ip(), now()]
        );
    }

    protected function assertUsable($coupon, $userId, array $package, $amount)
    {
        if (!$coupon || (int) $coupon['status'] !== 1) {
            throw new \RuntimeException('优惠码不存在或已停用。');
        }
        if (!empty($coupon['start_at']) && strtotime($coupon['start_at']) > time()) {
            throw new \RuntimeException('该活动尚未开始。');
        }
        if (!empty($coupon['end_at']) && strtotime($coupon['end_at']) < time()) {
            throw new \RuntimeException('该优惠码已过期。');
        }
        if ((float) $amount < (float) $coupon['min_amount']) {
            throw new \RuntimeException('当前订单金额未达到优惠码最低使用金额。');
        }
        if (!$this->packageAllowed($coupon, (int) $package['id'])) {
            throw new \RuntimeException('该优惠码不适用于当前套餐。');
        }
        if ((int) $coupon['first_order_only'] === 1) {
            $paid = Database::fetch("SELECT id FROM " . Database::table('orders') . " WHERE user_id = ? AND type = 'package' AND status = 'paid' LIMIT 1", [$userId]);
            if ($paid) {
                throw new \RuntimeException('该优惠码仅限首次购买套餐使用。');
            }
        }
        if ((int) $coupon['total_limit'] > 0) {
            $used = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('coupon_redemptions') . ' WHERE coupon_id = ?', [(int) $coupon['id']]);
            if ($used && (int) $used['c'] >= (int) $coupon['total_limit']) {
                throw new \RuntimeException('该优惠码已被领用完。');
            }
        }
        if ((int) $coupon['user_limit'] > 0) {
            $usedByUser = Database::fetch('SELECT COUNT(*) AS c FROM ' . Database::table('coupon_redemptions') . ' WHERE coupon_id = ? AND user_id = ?', [(int) $coupon['id'], $userId]);
            if ($usedByUser && (int) $usedByUser['c'] >= (int) $coupon['user_limit']) {
                throw new \RuntimeException('你已经使用过该优惠码。');
            }
        }
    }

    protected function packageAllowed(array $coupon, $packageId)
    {
        $scope = isset($coupon['package_scope']) ? $coupon['package_scope'] : 'all';
        if ($scope === 'all') {
            return true;
        }
        $ids = array_filter(array_map('intval', explode(',', (string) $coupon['package_ids'])));
        $inList = in_array((int) $packageId, $ids, true);
        return $scope === 'include' ? $inList : !$inList;
    }

    protected function calculateDiscount(array $coupon, $amount)
    {
        if ($coupon['discount_type'] === 'percent') {
            $discount = $amount * max(0, min(100, (float) $coupon['discount_value'])) / 100;
        } else {
            $discount = (float) $coupon['discount_value'];
        }
        return round(min($amount, max(0, $discount)), 2);
    }
}
