<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;

class FileTrashService
{
    public function moveToTrash(array $file, $action = 'trash')
    {
        Database::begin();
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('file_recycle_bin') . ' (user_id, file_id, snapshot, deleted_at) VALUES (?,?,?,?)',
                [
                    $file['user_id'],
                    $file['id'],
                    json_encode($file, JSON_UNESCAPED_UNICODE),
                    now(),
                ]
            );
            Database::execute('DELETE FROM ' . Database::table('files') . ' WHERE id = ?', [$file['id']]);
            Database::execute(
                'UPDATE ' . Database::table('users') . ' SET used_storage = IF(used_storage >= ?, used_storage - ?, 0), updated_at = ? WHERE id = ?',
                [$file['file_size'], $file['file_size'], now(), $file['user_id']]
            );
            (new FileLogService())->log($file['user_id'], $file['id'], $action, $file['original_name'], $file['file_size'], ['trash' => true]);
            Database::commit();
        } catch (\Exception $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function userTrash($userId)
    {
        return Database::fetchAll(
            'SELECT * FROM ' . Database::table('file_recycle_bin') . ' WHERE user_id = ? ORDER BY deleted_at DESC',
            [$userId]
        );
    }

    public function restore($trashId, $userId)
    {
        $trash = $this->findUserTrash($trashId, $userId);
        if (!$trash) {
            throw new \RuntimeException('回收站记录不存在。');
        }
        $file = json_decode((string) $trash['snapshot'], true);
        if (!is_array($file)) {
            throw new \RuntimeException('回收站快照损坏，无法恢复。');
        }

        $originalId = isset($file['id']) ? (int) $file['id'] : 0;
        $exists = $originalId > 0 ? Database::fetch('SELECT id FROM ' . Database::table('files') . ' WHERE id = ? LIMIT 1', [$originalId]) : null;
        if ($exists) {
            unset($file['id']);
        }
        $fileSize = isset($file['file_size']) ? (int) $file['file_size'] : 0;
        $fileName = isset($file['original_name']) ? $file['original_name'] : '';

        $columns = array_keys($file);
        $placeholders = implode(',', array_fill(0, count($columns), '?'));

        Database::begin();
        try {
            Database::execute(
                'INSERT INTO ' . Database::table('files') . ' (' . implode(',', $columns) . ') VALUES (' . $placeholders . ')',
                array_values($file)
            );
            $restoredId = isset($file['id']) && $file['id'] ? (int) $file['id'] : (int) Database::lastInsertId();
            Database::execute('DELETE FROM ' . Database::table('file_recycle_bin') . ' WHERE id = ?', [$trashId]);
            Database::execute(
                'UPDATE ' . Database::table('users') . ' SET used_storage = used_storage + ?, updated_at = ? WHERE id = ?',
                [$fileSize, now(), $userId]
            );
            (new FileLogService())->log($userId, $restoredId, 'file_restore', $fileName, $fileSize);
            Database::commit();
        } catch (\Exception $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public function purge($trashId, $userId, callable $remoteDelete)
    {
        $trash = $this->findUserTrash($trashId, $userId);
        if (!$trash) {
            throw new \RuntimeException('回收站记录不存在。');
        }
        $file = json_decode((string) $trash['snapshot'], true);
        if (!is_array($file)) {
            $file = ['id' => $trash['file_id'], 'original_name' => '', 'file_size' => 0];
        }
        call_user_func($remoteDelete, $file);
        Database::execute('DELETE FROM ' . Database::table('file_recycle_bin') . ' WHERE id = ?', [$trashId]);
        (new FileLogService())->log($userId, isset($file['id']) ? $file['id'] : null, 'file_purge', isset($file['original_name']) ? $file['original_name'] : '', isset($file['file_size']) ? $file['file_size'] : 0);
    }

    protected function findUserTrash($trashId, $userId)
    {
        return Database::fetch(
            'SELECT * FROM ' . Database::table('file_recycle_bin') . ' WHERE id = ? AND user_id = ? LIMIT 1',
            [(int) $trashId, (int) $userId]
        );
    }
}
