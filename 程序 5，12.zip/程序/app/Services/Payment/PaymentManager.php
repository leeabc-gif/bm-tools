<?php
namespace App\Services\Payment;

class PaymentManager
{
    public static function driver($code)
    {
        switch ($code) {
            case 'balance':
                return new BalanceGateway();
            case 'manual':
                return new ManualGateway();
            case 'alipay':
                return new AlipayF2FGateway(AlipayF2FGateway::config());
            case 'wechat':
            case 'epay':
                return new PlaceholderGateway($code);
            default:
                throw new \InvalidArgumentException('未知支付方式：' . $code);
        }
    }
}
