<?php
namespace App\Services\Payment;

interface PaymentGatewayInterface
{
    public function create(array $order);

    public function verifyNotify(array $payload);
}

