<?php
namespace App\Services\Payment;

class PlaceholderGateway implements PaymentGatewayInterface
{
    protected $code;

    public function __construct($code)
    {
        $this->code = $code;
    }

    public function create(array $order)
    {
        return [
            'type' => $this->code,
            'message' => '该支付网关已预留接口，请在后台配置真实支付参数后接入回调。',
            'order_no' => $order['order_no'],
        ];
    }

    public function verifyNotify(array $payload)
    {
        return false;
    }
}

