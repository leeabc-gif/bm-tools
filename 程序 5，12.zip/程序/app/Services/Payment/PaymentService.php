<?php
namespace App\Services\Payment;

use App\Core\Database;
use App\Services\BalanceService;
use App\Services\NotificationService;

class PaymentService
{
    public function markRechargePaid($orderNo, $tradeNo, $amount = null)
    {
        Database::begin();
        try {
            $order = Database::fetch('SELECT * FROM ' . Database::table('orders') . ' WHERE order_no = ? LIMIT 1 FOR UPDATE', [$orderNo]);
            if (!$order || $order['type'] !== 'recharge') {
                throw new \RuntimeException('充值订单不存在。');
            }
            if ($order['status'] === 'paid') {
                Database::commit();
                return true;
            }
            if ($order['status'] !== 'pending') {
                throw new \RuntimeException('订单状态不可入账。');
            }
            if ($amount !== null && abs((float) $order['pay_amount'] - (float) $amount) > 0.01) {
                throw new \RuntimeException('支付金额与订单金额不一致。');
            }

            $recharge = Database::fetch('SELECT * FROM ' . Database::table('recharges') . ' WHERE order_id = ? LIMIT 1 FOR UPDATE', [$order['id']]);
            if (!$recharge) {
                throw new \RuntimeException('充值记录不存在。');
            }
            if ($recharge['status'] === 'paid') {
                Database::commit();
                return true;
            }
            if ($recharge['status'] !== 'pending') {
                throw new \RuntimeException('充值记录状态不可入账。');
            }

            Database::execute(
                'UPDATE ' . Database::table('orders') . ' SET status = ?, trade_no = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                ['paid', $tradeNo, now(), now(), $order['id']]
            );
            Database::execute(
                'UPDATE ' . Database::table('recharges') . ' SET status = ?, paid_at = ?, updated_at = ? WHERE id = ?',
                ['paid', now(), now(), $recharge['id']]
            );
            (new BalanceService())->add($order['user_id'], $order['pay_amount'], 'recharge', 'order', $order['id'], '充值订单入账：' . $order['order_no']);
            (new NotificationService())->send($order['user_id'], 'recharge', '充值成功', '你的账户已充值 ' . $order['pay_amount'] . ' 元。');
            Database::commit();
            return true;
        } catch (\Exception $e) {
            Database::rollBack();
            throw $e;
        }
    }
}
