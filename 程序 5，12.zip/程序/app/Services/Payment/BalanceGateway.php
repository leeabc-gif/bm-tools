<?php
namespace App\Services\Payment;

class BalanceGateway implements PaymentGatewayInterface
{
    public function create(array $order)
    {
        return [
            'type' => 'balance',
            'message' => '余额支付订单已创建。',
            'order_no' => $order['order_no'],
        ];
    }

    public function verifyNotify(array $payload)
    {
        return true;
    }
}

