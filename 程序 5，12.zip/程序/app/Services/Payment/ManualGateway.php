<?php
namespace App\Services\Payment;

class ManualGateway implements PaymentGatewayInterface
{
    public function create(array $order)
    {
        return [
            'type' => 'manual',
            'message' => '人工充值订单已提交，请按页面提示联系管理员审核。',
            'order_no' => $order['order_no'],
        ];
    }

    public function verifyNotify(array $payload)
    {
        return true;
    }
}
