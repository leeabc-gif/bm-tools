<?php
namespace App\Services\Storage;

use App\Core\Logger;

class StorageTestService
{
    public function run(array $record)
    {
        $started = microtime(true);
        $driver = StorageManager::make($record);
        $basic = $driver->test();
        if (empty($basic['success'])) {
            return [
                'success' => false,
                'message' => isset($basic['message']) ? $basic['message'] : '存储配置未通过基础检查。',
                'stage' => 'config',
            ];
        }

        $tmp = $this->makeTempFile($record);
        $objectKey = 'bmtools-healthcheck/' . date('Ymd') . '/storage-test-' . date('His') . '-' . bin2hex(random_bytes(4)) . '.txt';
        $uploaded = null;
        $deleteSuccess = false;

        try {
            $uploaded = $driver->upload($tmp, $objectKey, ['mime' => 'text/plain']);
            $uploadMs = (int) round((microtime(true) - $started) * 1000);
            if (empty($uploaded['path']) || empty($uploaded['url'])) {
                throw new \RuntimeException('云存储返回结果不完整，请检查驱动配置。');
            }

            try {
                $deleteSuccess = (bool) $driver->delete($uploaded['path']);
            } catch (\Exception $deleteError) {
                Logger::error('存储测试删除测试文件失败：' . $deleteError->getMessage(), [
                    'storage_id' => isset($record['id']) ? $record['id'] : null,
                    'path' => $uploaded['path'],
                ]);
                return [
                    'success' => false,
                    'partial_success' => true,
                    'message' => '测试文件上传成功，但删除失败。上传权限可用，删除权限异常，请检查 Bucket 删除权限或 Key 授权。',
                    'stage' => 'delete',
                    'url' => $uploaded['url'],
                    'object_key' => $uploaded['path'],
                    'upload_ms' => $uploadMs,
                    'delete_success' => false,
                ];
            }

            return [
                'success' => true,
                'message' => '存储测试通过：Key、Bucket、Endpoint、上传权限和删除权限均可用。',
                'stage' => 'done',
                'url' => $uploaded['url'],
                'object_key' => $uploaded['path'],
                'upload_ms' => $uploadMs,
                'delete_success' => $deleteSuccess,
            ];
        } catch (\Exception $e) {
            Logger::error('存储连通性测试失败：' . $e->getMessage(), [
                'storage_id' => isset($record['id']) ? $record['id'] : null,
                'type' => isset($record['type']) ? $record['type'] : '',
            ]);
            return [
                'success' => false,
                'message' => $this->friendlyError($record, $e->getMessage()),
                'stage' => 'upload',
                'object_key' => $objectKey,
            ];
        } finally {
            if (is_file($tmp)) {
                unlink($tmp);
            }
        }
    }

    protected function makeTempFile(array $record)
    {
        $tmp = tempnam(sys_get_temp_dir(), 'bm_storage_');
        if ($tmp === false) {
            throw new \RuntimeException('无法创建临时测试文件，请检查服务器临时目录权限。');
        }
        $content = "BM TOOLS storage health check\n";
        $content .= 'storage=' . (isset($record['name']) ? $record['name'] : '') . "\n";
        $content .= 'time=' . date('Y-m-d H:i:s') . "\n";
        file_put_contents($tmp, $content);
        return $tmp;
    }

    protected function friendlyError(array $record, $message)
    {
        $type = isset($record['type']) ? $record['type'] : '';
        $tips = [
            'oss' => '阿里云 OSS 请确认：1）Endpoint 填 oss-cn-hangzhou.aliyuncs.com 这种地域地址，不要带 Bucket；2）Bucket 名称正确；3）AccessKey 有 PutObject 和 DeleteObject 权限。',
            'cos' => '腾讯云 COS 请确认：1）SecretId/SecretKey 正确；2）Bucket 通常带数字后缀，例如 bmtools-1250000000；3）Region 填 ap-guangzhou 这种格式；4）Endpoint 可留空。',
            'kodo' => '七牛云 Kodo 请确认：1）AccessKey/SecretKey 正确；2）Bucket 是空间名称；3）访问域名必须是绑定到空间的外链域名；4）上传域名一般可留空。',
            'local' => '本地存储请确认 public/uploads 目录可写。',
        ];
        $hint = isset($tips[$type]) ? $tips[$type] : '请检查存储配置。';
        return '存储测试失败：' . $this->humanizeCloudError($type, $message) . ' ' . $hint;
    }

    protected function cleanError($message)
    {
        $message = trim(strip_tags((string) $message));
        if (mb_strlen($message) > 360) {
            $message = mb_substr($message, 0, 360) . '...';
        }
        return $message;
    }

    protected function humanizeCloudError($type, $message)
    {
        $clean = $this->cleanError($message);
        $lower = strtolower($clean);
        if (strpos($lower, 'signature') !== false || strpos($lower, 'sign') !== false) {
            return '签名校验失败，通常是密钥填错、Endpoint/Region 填错，或服务器时间偏差过大。原始信息：' . $clean;
        }
        if (strpos($lower, 'accessdenied') !== false || strpos($lower, 'access denied') !== false || strpos($lower, '403') !== false || strpos($lower, 'forbidden') !== false) {
            return '权限被拒绝，通常是 Key 没有当前 Bucket 的上传/删除权限，或 Bucket 不属于这个账号。原始信息：' . $clean;
        }
        if (strpos($lower, 'nosuchbucket') !== false || strpos($lower, 'bucket') !== false && strpos($lower, 'not') !== false) {
            return 'Bucket 不存在或名称不匹配，请检查空间/桶名称是否复制完整。原始信息：' . $clean;
        }
        if (strpos($lower, 'resolve') !== false || strpos($lower, 'could not') !== false || strpos($lower, 'timeout') !== false || strpos($lower, 'timed out') !== false) {
            return '网络连接失败，通常是 Endpoint 写错、服务器无法访问外网，或防火墙拦截。原始信息：' . $clean;
        }
        if ($type === 'cos' && strpos($lower, 'region') !== false) {
            return '腾讯云 Region 可能填写错误，例如广州应填 ap-guangzhou。原始信息：' . $clean;
        }
        return $clean;
    }
}
