<?php
namespace App\Services\Storage;

abstract class AbstractStorageDriver implements StorageInterface
{
    protected $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain) {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($objectKey);
        }
        $endpoint = rtrim(isset($this->config['endpoint']) ? $this->config['endpoint'] : '', '/');
        if ($endpoint && !preg_match('#^https?://#i', $endpoint)) {
            $endpoint = 'https://' . $endpoint;
        }
        return $endpoint . '/' . $this->encodePath($objectKey);
    }

    public function test()
    {
        return [
            'success' => !empty($this->config['bucket']) && !empty($this->config['access_key']),
            'message' => '配置字段检查完成，可以继续进行真实上传测试。',
        ];
    }

    protected function objectKey($objectKey)
    {
        $prefix = trim(isset($this->config['prefix']) ? $this->config['prefix'] : '', '/');
        $objectKey = ltrim($objectKey, '/');
        if ($prefix === '' || strpos($objectKey, $prefix . '/') === 0) {
            return $objectKey;
        }
        return $prefix . '/' . $objectKey;
    }

    protected function endpoint($withScheme = true)
    {
        $endpoint = trim(isset($this->config['endpoint']) ? $this->config['endpoint'] : '');
        if ($endpoint === '') {
            return '';
        }
        if ($withScheme && !preg_match('#^https?://#i', $endpoint)) {
            $endpoint = 'https://' . $endpoint;
        }
        return rtrim($endpoint, '/');
    }

    protected function encodePath($path)
    {
        return implode('/', array_map('rawurlencode', explode('/', ltrim($path, '/'))));
    }

    protected function curl($method, $url, array $headers = [], $body = null)
    {
        if (!function_exists('curl_init')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl 扩展，无法连接对象存储。');
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 60,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        if ($response === false || $error) {
            throw new \RuntimeException('存储请求失败：' . $error);
        }

        $responseBody = substr($response, $headerSize);
        if ($code >= 400) {
            throw new \RuntimeException('存储服务返回异常 HTTP ' . $code . '：' . mb_substr($responseBody, 0, 300));
        }

        return ['code' => $code, 'body' => $responseBody];
    }

    protected function base64Url($value)
    {
        return strtr(base64_encode($value), '+/', '-_');
    }
}
