<?php
namespace App\Services\Storage;

class KodoStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!function_exists('curl_init') || !class_exists('\CURLFile')) {
            throw new \RuntimeException('当前 PHP 环境缺少 curl/CURLFile 能力，无法连接七牛云 Kodo。');
        }
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }
        $objectKey = $this->objectKey($objectKey);
        $policy = [
            'scope' => $this->config['bucket'] . ':' . $objectKey,
            'deadline' => time() + 3600,
            'returnBody' => '{"key":"$(key)","hash":"$(etag)","size":$(fsize)}',
        ];
        $encodedPolicy = $this->base64Url(json_encode($policy, JSON_UNESCAPED_SLASHES));
        $sign = hash_hmac('sha1', $encodedPolicy, $this->config['secret_key'], true);
        $token = $this->config['access_key'] . ':' . $this->base64Url($sign) . ':' . $encodedPolicy;
        $uploadHost = $this->endpoint(true);
        if ($uploadHost === '') {
            $uploadHost = 'https://upload.qiniup.com';
        }
        $ch = curl_init($uploadHost);
        $post = [
            'token' => $token,
            'key' => $objectKey,
            'file' => new \CURLFile($localPath, isset($options['mime']) ? $options['mime'] : 'application/octet-stream', basename($objectKey)),
        ];
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $post,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 60,
        ]);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $error || $code >= 400) {
            throw new \RuntimeException('七牛上传失败：' . ($error ?: ('HTTP ' . $code . ' ' . mb_substr((string) $body, 0, 300))));
        }
        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => 'kodo',
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $entry = $this->base64Url($this->config['bucket'] . ':' . $objectKey);
        $path = '/delete/' . $entry;
        $host = 'https://rs.qiniu.com';
        $sign = hash_hmac('sha1', $path . "\n", $this->config['secret_key'], true);
        $token = 'QBox ' . $this->config['access_key'] . ':' . $this->base64Url($sign);
        $this->curl('POST', $host . $path, ['Authorization: ' . $token], '');
        return true;
    }

    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || empty($this->config['domain'])) {
            return ['success' => false, 'message' => '七牛云 Kodo 需要填写 AccessKey、SecretKey、Bucket 和访问域名。访问域名是绑定到空间的外链域名，不是上传域名。'];
        }
        return ['success' => true, 'message' => 'Kodo 基础配置完整，可以进行真实上传测试。'];
    }
}
