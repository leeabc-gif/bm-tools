<?php
namespace App\Services\Storage;

class CosStorageDriver extends AbstractStorageDriver
{
    public function upload($localPath, $objectKey, array $options = [])
    {
        if (!is_file($localPath)) {
            throw new \RuntimeException('本地文件不存在。');
        }
        $objectKey = $this->objectKey($objectKey);
        $contentType = isset($options['mime']) && $options['mime'] ? $options['mime'] : 'application/octet-stream';
        $body = file_get_contents($localPath);
        $contentMd5 = base64_encode(md5($body, true));
        $url = $this->uploadUrl($objectKey);
        $host = parse_url($url, PHP_URL_HOST);
        $headers = [
            'Host: ' . $host,
            'Content-Type: ' . $contentType,
            'Content-MD5: ' . $contentMd5,
            'Authorization: ' . $this->authorization('put', '/' . $this->encodePath($objectKey), [
                'content-md5' => $contentMd5,
                'content-type' => $contentType,
                'host' => $host,
            ]),
        ];
        $this->curl('PUT', $url, $headers, $body);
        return [
            'path' => $objectKey,
            'url' => $this->url($objectKey),
            'driver' => 'cos',
        ];
    }

    public function delete($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $url = $this->uploadUrl($objectKey);
        $host = parse_url($url, PHP_URL_HOST);
        $this->curl('DELETE', $url, [
            'Host: ' . $host,
            'Authorization: ' . $this->authorization('delete', '/' . $this->encodePath($objectKey), ['host' => $host]),
        ]);
        return true;
    }

    public function test()
    {
        if (empty($this->config['access_key']) || empty($this->config['secret_key']) || empty($this->config['bucket']) || (empty($this->config['region']) && empty($this->config['endpoint']))) {
            return ['success' => false, 'message' => '腾讯云 COS 需要填写 SecretId、SecretKey、Bucket，并填写 Region。Endpoint 可以留空，系统会按 Bucket 和 Region 自动生成。'];
        }
        return ['success' => true, 'message' => 'COS 基础配置完整，可以进行真实上传测试。'];
    }

    protected function uploadUrl($objectKey)
    {
        $endpoint = $this->endpoint(true);
        if ($endpoint === '') {
            $endpoint = 'https://' . $this->config['bucket'] . '.cos.' . $this->config['region'] . '.myqcloud.com';
        } else {
            $host = parse_url($endpoint, PHP_URL_HOST);
            if ($host && strpos($host, $this->config['bucket'] . '.') !== 0) {
                $endpoint = preg_replace('#^(https?://)#', '$1' . $this->config['bucket'] . '.', $endpoint);
            }
        }
        return $endpoint . '/' . $this->encodePath($objectKey);
    }

    protected function authorization($method, $path, array $headers)
    {
        $start = time() - 60;
        $end = $start + 3600;
        ksort($headers);
        $headerKeys = array_map('strtolower', array_keys($headers));
        sort($headerKeys);
        $headerList = implode(';', $headerKeys);
        $canonicalHeaders = '';
        foreach ($headers as $key => $value) {
            $canonicalHeaders .= strtolower($key) . '=' . rawurlencode($value) . '&';
        }
        $canonicalHeaders = rtrim($canonicalHeaders, '&');
        $canonicalRequest = strtolower($method) . "\n" . $path . "\n\n" . $canonicalHeaders . "\n" . $headerList . "\n";
        $signKey = hash_hmac('sha1', $start . ';' . $end, $this->config['secret_key']);
        $stringToSign = "sha1\n" . $start . ';' . $end . "\n" . sha1($canonicalRequest) . "\n";
        $signature = hash_hmac('sha1', $stringToSign, $signKey);
        return 'q-sign-algorithm=sha1&q-ak=' . $this->config['access_key'] . '&q-sign-time=' . $start . ';' . $end . '&q-key-time=' . $start . ';' . $end . '&q-header-list=' . $headerList . '&q-url-param-list=&q-signature=' . $signature;
    }

    public function url($objectKey)
    {
        $objectKey = $this->objectKey($objectKey);
        $domain = rtrim(isset($this->config['domain']) ? $this->config['domain'] : '', '/');
        if ($domain) {
            if (!preg_match('#^https?://#i', $domain)) {
                $domain = 'https://' . $domain;
            }
            return $domain . '/' . $this->encodePath($objectKey);
        }
        return $this->uploadUrl($objectKey);
    }
}
