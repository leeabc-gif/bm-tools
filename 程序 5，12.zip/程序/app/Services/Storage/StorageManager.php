<?php
namespace App\Services\Storage;

use App\Models\StorageDriver;

class StorageManager
{
    public static function defaultDriverRecord()
    {
        return (new StorageDriver())->defaultDriver();
    }

    public static function make(array $record)
    {
        switch ($record['type']) {
            case 'local':
                return new LocalStorageDriver($record);
            case 'oss':
                return new OssStorageDriver($record);
            case 'cos':
                return new CosStorageDriver($record);
            case 'kodo':
                return new KodoStorageDriver($record);
            default:
                throw new \InvalidArgumentException('未知存储类型：' . $record['type']);
        }
    }

    public static function default()
    {
        $record = self::defaultDriverRecord();
        if (!$record) {
            return null;
        }
        return self::make($record);
    }
}
