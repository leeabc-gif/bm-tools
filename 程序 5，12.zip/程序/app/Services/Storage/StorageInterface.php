<?php
namespace App\Services\Storage;

interface StorageInterface
{
    public function upload($localPath, $objectKey, array $options = []);

    public function delete($objectKey);

    public function url($objectKey);

    public function test();
}

