<?php
namespace App\Services;

use App\Core\Database;
use App\Core\Logger;

class DatabaseUpgradeService
{
    public static function ensureMarketingSchema()
    {
        try {
            $couponTable = Database::table('coupons');
            if (!self::tableExists($couponTable)) {
                Database::execute("CREATE TABLE `" . $couponTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `title` varchar(120) NOT NULL,
                    `code` varchar(40) NOT NULL,
                    `discount_type` enum('fixed','percent') NOT NULL DEFAULT 'fixed',
                    `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `min_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `package_scope` enum('all','include','exclude') NOT NULL DEFAULT 'all',
                    `package_ids` varchar(500) NOT NULL DEFAULT '',
                    `start_at` datetime DEFAULT NULL,
                    `end_at` datetime DEFAULT NULL,
                    `total_limit` int(10) unsigned NOT NULL DEFAULT '0',
                    `user_limit` int(10) unsigned NOT NULL DEFAULT '1',
                    `first_order_only` tinyint(1) NOT NULL DEFAULT '0',
                    `status` tinyint(1) NOT NULL DEFAULT '1',
                    `sort_order` int(11) NOT NULL DEFAULT '0',
                    `description` varchar(500) NOT NULL DEFAULT '',
                    `created_at` datetime NOT NULL,
                    `updated_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `uk_code` (`code`),
                    KEY `idx_status_time` (`status`, `start_at`, `end_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            $redemptionTable = Database::table('coupon_redemptions');
            if (!self::tableExists($redemptionTable)) {
                Database::execute("CREATE TABLE `" . $redemptionTable . "` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `coupon_id` int(10) unsigned NOT NULL,
                    `user_id` int(10) unsigned NOT NULL,
                    `order_id` int(10) unsigned DEFAULT NULL,
                    `package_id` int(10) unsigned DEFAULT NULL,
                    `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `final_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
                    `ip` varchar(45) NOT NULL DEFAULT '',
                    `used_at` datetime NOT NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_coupon` (`coupon_id`),
                    KEY `idx_user` (`user_id`),
                    KEY `idx_order` (`order_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }
            return true;
        } catch (\Exception $e) {
            Logger::error('营销活动表结构自动升级失败：' . $e->getMessage());
            return false;
        }
    }

    public static function ensureMonitorSchema()
    {
        try {
            $table = Database::table('monitor_servers');
            if (!self::tableExists($table)) {
                return false;
            }

            $monitorTypeColumn = self::column($table, 'monitor_type');
            if ($monitorTypeColumn) {
                $type = isset($monitorTypeColumn['Type']) ? $monitorTypeColumn['Type'] : (isset($monitorTypeColumn['type']) ? $monitorTypeColumn['type'] : '');
                if (stripos($type, 'agent') === false) {
                    Database::execute("ALTER TABLE `" . $table . "` MODIFY COLUMN `monitor_type` enum('bt','ssh','agent') NOT NULL DEFAULT 'bt'");
                }
            } else {
                Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN `monitor_type` enum('bt','ssh','agent') NOT NULL DEFAULT 'bt' AFTER `user_id`");
            }

            $columns = [
                'ssh_host' => "`ssh_host` varchar(120) DEFAULT NULL AFTER `server_ip`",
                'ssh_port' => "`ssh_port` int(10) unsigned NOT NULL DEFAULT '22' AFTER `ssh_host`",
                'ssh_username' => "`ssh_username` varchar(80) DEFAULT NULL AFTER `ssh_port`",
                'ssh_auth_type' => "`ssh_auth_type` enum('password','key') NOT NULL DEFAULT 'password' AFTER `ssh_username`",
                'ssh_password' => "`ssh_password` text AFTER `ssh_auth_type`",
                'ssh_private_key' => "`ssh_private_key` mediumtext AFTER `ssh_password`",
                'ssh_key_passphrase' => "`ssh_key_passphrase` text AFTER `ssh_private_key`",
                'agent_url' => "`agent_url` varchar(255) DEFAULT NULL AFTER `ssh_key_passphrase`",
                'agent_token' => "`agent_token` varchar(120) DEFAULT NULL AFTER `agent_url`",
            ];

            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            return true;
        } catch (\Exception $e) {
            Logger::error('监控表结构自动升级失败：' . $e->getMessage());
            return false;
        }
    }

    public static function ensureAnnouncementSchema()
    {
        try {
            $table = Database::table('announcements');
            if (!self::tableExists($table)) {
                return false;
            }
            $columns = [
                'category' => "`category` varchar(40) NOT NULL DEFAULT 'platform' AFTER `content`",
                'summary' => "`summary` varchar(300) NOT NULL DEFAULT '' AFTER `category`",
                'cover_image' => "`cover_image` varchar(255) NOT NULL DEFAULT '' AFTER `summary`",
                'tags' => "`tags` varchar(255) NOT NULL DEFAULT '' AFTER `cover_image`",
                'content_format' => "`content_format` varchar(20) NOT NULL DEFAULT 'html' AFTER `tags`",
                'view_count' => "`view_count` int(10) unsigned NOT NULL DEFAULT '0' AFTER `content_format`",
            ];
            foreach ($columns as $name => $definition) {
                if (!self::hasColumn($table, $name)) {
                    Database::execute("ALTER TABLE `" . $table . "` ADD COLUMN " . $definition);
                }
            }
            if (!self::hasIndex($table, 'idx_category_status')) {
                Database::execute("ALTER TABLE `" . $table . "` ADD KEY `idx_category_status` (`category`, `status`, `published_at`)");
            }
            return true;
        } catch (\Exception $e) {
            Logger::error('公告表结构自动升级失败：' . $e->getMessage());
            return false;
        }
    }

    protected static function tableExists($table)
    {
        $row = Database::fetch('SHOW TABLES LIKE ?', [$table]);
        return (bool) $row;
    }

    protected static function hasColumn($table, $column)
    {
        return (bool) self::column($table, $column);
    }

    protected static function column($table, $column)
    {
        return Database::fetch('SHOW COLUMNS FROM `' . $table . '` LIKE ?', [$column]);
    }

    protected static function hasIndex($table, $index)
    {
        $row = Database::fetch('SHOW INDEX FROM `' . $table . '` WHERE Key_name = ? LIMIT 1', [$index]);
        return (bool) $row;
    }
}
