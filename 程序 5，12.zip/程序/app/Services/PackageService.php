<?php
namespace App\Services;

use App\Core\Database;
use App\Models\Order;
use App\Models\Package;

class PackageService
{
    public function buyWithBalance($userId, $packageId, $couponCode = '')
    {
        DatabaseUpgradeService::ensureMarketingSchema();

        $package = (new Package())->find($packageId);
        if (!$package || (int) $package['status'] !== 1) {
            throw new \RuntimeException('套餐不存在或已停用。');
        }

        Database::begin();
        try {
            $user = Database::fetch('SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1 FOR UPDATE', [$userId]);
            if (!$user) {
                throw new \RuntimeException('用户不存在。');
            }

            $originalAmount = $this->calculatePayAmount($user, $package);
            $couponQuote = (new CouponService())->quote($userId, $package, $originalAmount, $couponCode);
            $payAmount = $couponQuote['final_amount'];

            if ((float) $user['balance'] < $payAmount) {
                throw new \RuntimeException('账户余额不足，请先充值。');
            }

            $remark = '余额购买套餐';
            if ($couponQuote['coupon']) {
                $remark .= '，优惠码：' . $couponQuote['coupon']['code'] . '，抵扣：' . number_format($couponQuote['discount'], 2) . ' 元';
            }

            $order = (new Order())->createOrder($userId, 'package', $originalAmount, 'balance', $packageId, $remark, $payAmount);
            if ($payAmount > 0) {
                (new BalanceService())->subtract($userId, $payAmount, 'consume', 'order', $order['id'], '购买套餐：' . $package['name']);
            }

            (new CouponService())->redeem($couponQuote['coupon'], $userId, $order['id'], $packageId, $couponQuote['discount'], $payAmount);

            $expire = $this->calculateExpire($user, $package);
            Database::execute(
                'UPDATE ' . Database::table('users') . ' SET package_id = ?, package_expire_time = ?, total_storage = ?, total_traffic = ?, updated_at = ? WHERE id = ?',
                [$package['id'], $expire, $package['storage_limit'], $package['traffic_limit'], now(), $userId]
            );

            (new Order())->markPaid($order['id'], 'BALANCE-' . $order['order_no']);
            (new NotificationService())->send($userId, 'package', '套餐购买成功', '你已成功购买 ' . $package['name'] . '。');

            Database::commit();
            return true;
        } catch (\Exception $e) {
            Database::rollBack();
            throw $e;
        }
    }

    protected function calculateExpire(array $user, array $package)
    {
        if ($package['duration_type'] === 'forever') {
            return null;
        }
        $base = time();
        if (!empty($user['package_expire_time']) && strtotime($user['package_expire_time']) > $base && (int) $user['package_id'] === (int) $package['id']) {
            $base = strtotime($user['package_expire_time']);
        }
        return date('Y-m-d H:i:s', $base + ((int) $package['duration_days'] * 86400));
    }

    protected function calculatePayAmount(array $user, array $newPackage)
    {
        $price = (float) $newPackage['price'];
        if (empty($user['package_id']) || (int) $user['package_id'] === (int) $newPackage['id']) {
            return $price;
        }

        if (empty($user['package_expire_time']) || strtotime($user['package_expire_time']) <= time()) {
            return $price;
        }

        $oldPackage = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$user['package_id']]);
        if (!$oldPackage || (float) $oldPackage['price'] <= 0 || (int) $oldPackage['duration_days'] <= 0) {
            return $price;
        }

        $remainingDays = max(0, (strtotime($user['package_expire_time']) - time()) / 86400);
        $credit = ((float) $oldPackage['price']) * min(1, $remainingDays / max(1, (int) $oldPackage['duration_days']));
        return round(max(0, $price - $credit), 2);
    }
}
