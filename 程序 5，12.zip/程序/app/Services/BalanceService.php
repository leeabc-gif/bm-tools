<?php
namespace App\Services;

use App\Core\Database;

class BalanceService
{
    public function add($userId, $amount, $type, $relatedType = null, $relatedId = null, $remark = '')
    {
        $user = $this->user($userId);
        $before = (float) $user['balance'];
        $after = round($before + (float) $amount, 2);
        Database::execute('UPDATE ' . Database::table('users') . ' SET balance = ?, updated_at = ? WHERE id = ?', [$after, now(), $userId]);
        $this->log($userId, $type, abs((float) $amount), $before, $after, $relatedType, $relatedId, $remark);
        return $after;
    }

    public function subtract($userId, $amount, $type, $relatedType = null, $relatedId = null, $remark = '')
    {
        $user = $this->user($userId);
        $before = (float) $user['balance'];
        if ($before < (float) $amount) {
            throw new \RuntimeException('余额不足。');
        }
        $after = round($before - (float) $amount, 2);
        Database::execute('UPDATE ' . Database::table('users') . ' SET balance = ?, updated_at = ? WHERE id = ?', [$after, now(), $userId]);
        $this->log($userId, $type, -abs((float) $amount), $before, $after, $relatedType, $relatedId, $remark);
        return $after;
    }

    public function log($userId, $type, $amount, $before, $after, $relatedType = null, $relatedId = null, $remark = '')
    {
        Database::execute(
            'INSERT INTO ' . Database::table('balance_logs') . ' (user_id, type, amount, balance_before, balance_after, related_type, related_id, remark, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
            [$userId, $type, $amount, $before, $after, $relatedType, $relatedId, $remark, now()]
        );
    }

    protected function user($userId)
    {
        $sql = 'SELECT * FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1';
        try {
            if (Database::getInstance()->inTransaction()) {
                $sql .= ' FOR UPDATE';
            }
        } catch (\Exception $e) {
            // Keep the balance service usable during installation or transient DB errors.
        }
        $user = Database::fetch($sql, [$userId]);
        if (!$user) {
            throw new \RuntimeException('用户不存在。');
        }
        return $user;
    }
}
