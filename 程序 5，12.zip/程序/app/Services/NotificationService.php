<?php
namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Models\Notification;

class NotificationService
{
    public function send($userId, $type, $title, $content)
    {
        $notification = new Notification();
        return $notification->createForUser($userId, $type, $title, $content);
    }

    public function sendEmail($userId, $subject, $content)
    {
        $user = Database::fetch('SELECT email FROM ' . Database::table('users') . ' WHERE id = ? LIMIT 1', [$userId]);
        if (!$user || !$user['email']) {
            return false;
        }

        $ok = (new MailerService())->send($user['email'], $subject, $content);
        if (!$ok) {
            Logger::error('邮件发送失败。', ['user_id' => $userId, 'subject' => $subject]);
        }
        return $ok;
    }
}
