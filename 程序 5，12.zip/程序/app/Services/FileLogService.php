<?php
namespace App\Services;

use App\Core\Auth;
use App\Core\Database;

class FileLogService
{
    public function log($userId, $fileId, $action, $fileName = '', $fileSize = 0, array $detail = [])
    {
        Database::execute(
            'INSERT INTO ' . Database::table('file_logs') . ' (user_id, file_id, action, file_name, file_size, ip, detail, created_at) VALUES (?,?,?,?,?,?,?,?)',
            [$userId, $fileId, $action, $fileName, $fileSize, Auth::ip(), json_encode($detail, JSON_UNESCAPED_UNICODE), now()]
        );
    }
}

