<?php
namespace App\Services;

use App\Core\Logger;

class MailerService
{
    public function send($to, $subject, $content)
    {
        $host = setting('email_host', '');
        $port = (int) setting('email_port', '465');
        $username = setting('email_username', '');
        $password = setting('email_password', '');
        $from = setting('email_from', $username);

        if ($host && $username && $password && $from) {
            return $this->sendSmtp($host, $port, $username, $password, $from, $to, $subject, $content);
        }

        if (!$from) {
            Logger::info('邮件未发送：尚未配置发件邮箱。', ['to' => $to, 'subject' => $subject]);
            return false;
        }

        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/plain; charset=utf-8',
            'From: ' . $from,
        ];
        return @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $content, implode("\r\n", $headers));
    }

    protected function sendSmtp($host, $port, $username, $password, $from, $to, $subject, $content)
    {
        $remote = ((int) $port === 465 ? 'ssl://' : '') . $host;
        $fp = @stream_socket_client($remote . ':' . $port, $errno, $errstr, 15, STREAM_CLIENT_CONNECT);
        if (!$fp) {
            Logger::error('SMTP 连接失败：' . $errstr, ['errno' => $errno, 'host' => $host]);
            return false;
        }
        stream_set_timeout($fp, 15);

        try {
            $this->expect($fp, 220);
            $this->cmd($fp, 'EHLO ' . (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost'), 250);
            if ((int) $port === 587) {
                $this->cmd($fp, 'STARTTLS', 220);
                stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                $this->cmd($fp, 'EHLO ' . (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost'), 250);
            }
            $this->cmd($fp, 'AUTH LOGIN', 334);
            $this->cmd($fp, base64_encode($username), 334);
            $this->cmd($fp, base64_encode($password), 235);
            $this->cmd($fp, 'MAIL FROM:<' . $from . '>', 250);
            $this->cmd($fp, 'RCPT TO:<' . $to . '>', [250, 251]);
            $this->cmd($fp, 'DATA', 354);

            $message = $this->buildMessage($from, $to, $subject, $content);
            fwrite($fp, $message . "\r\n.\r\n");
            $this->expect($fp, 250);
            $this->cmd($fp, 'QUIT', 221);
            fclose($fp);
            return true;
        } catch (\Exception $e) {
            Logger::error('SMTP 发送失败：' . $e->getMessage(), ['to' => $to, 'subject' => $subject]);
            fclose($fp);
            return false;
        }
    }

    protected function buildMessage($from, $to, $subject, $content)
    {
        $headers = [
            'From: ' . $from,
            'To: ' . $to,
            'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=',
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
            'Date: ' . date('r'),
        ];
        return implode("\r\n", $headers) . "\r\n\r\n" . chunk_split(base64_encode($content));
    }

    protected function cmd($fp, $command, $expected)
    {
        fwrite($fp, $command . "\r\n");
        return $this->expect($fp, $expected);
    }

    protected function expect($fp, $expected)
    {
        $expected = (array) $expected;
        $response = '';
        while (($line = fgets($fp, 512)) !== false) {
            $response .= $line;
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        $code = (int) substr($response, 0, 3);
        if (!in_array($code, $expected, true)) {
            throw new \RuntimeException('SMTP 响应异常：' . trim($response));
        }
        return $response;
    }
}

