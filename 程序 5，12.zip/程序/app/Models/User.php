<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class User extends Model
{
    protected $table = 'users';

    public function findByAccount($account)
    {
        return Database::fetch(
            'SELECT * FROM ' . $this->table() . ' WHERE username = ? OR email = ? LIMIT 1',
            [$account, $account]
        );
    }

    public function existsUsername($username, $exceptId = null)
    {
        $sql = 'SELECT id FROM ' . $this->table() . ' WHERE username = ?';
        $params = [$username];
        if ($exceptId) {
            $sql .= ' AND id <> ?';
            $params[] = $exceptId;
        }
        return Database::fetch($sql . ' LIMIT 1', $params) !== null;
    }

    public function existsEmail($email, $exceptId = null)
    {
        $sql = 'SELECT id FROM ' . $this->table() . ' WHERE email = ?';
        $params = [$email];
        if ($exceptId) {
            $sql .= ' AND id <> ?';
            $params[] = $exceptId;
        }
        return Database::fetch($sql . ' LIMIT 1', $params) !== null;
    }

    public function createUser($username, $email, $password, $role = 'user')
    {
        $package = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [(int) setting('default_free_package_id', 1)]);
        $storage = $package ? (int) $package['storage_limit'] : 0;
        $traffic = $package ? (int) $package['traffic_limit'] : 0;
        $expire = $package && $package['duration_type'] !== 'forever' ? date('Y-m-d H:i:s', time() + ((int) $package['duration_days'] * 86400)) : null;

        return $this->create([
            'username' => $username,
            'nickname' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'avatar' => '',
            'role' => $role,
            'balance' => 0,
            'package_id' => $package ? (int) $package['id'] : null,
            'package_expire_time' => $expire,
            'used_storage' => 0,
            'total_storage' => $storage,
            'used_traffic' => 0,
            'total_traffic' => $traffic,
            'status' => 1,
            'api_token' => bin2hex(random_bytes(24)),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function packageInfo($userId)
    {
        return Database::fetch(
            'SELECT p.* FROM ' . Database::table('users') . ' u LEFT JOIN ' . Database::table('packages') . ' p ON u.package_id = p.id WHERE u.id = ? LIMIT 1',
            [$userId]
        );
    }

    public function downgradeIfExpired(array $user)
    {
        if (empty($user['package_expire_time']) || strtotime($user['package_expire_time']) >= time()) {
            return false;
        }

        $defaultId = (int) setting('default_free_package_id', 1);
        $package = Database::fetch('SELECT * FROM ' . Database::table('packages') . ' WHERE id = ? LIMIT 1', [$defaultId]);
        if (!$package) {
            return false;
        }

        $expire = $package['duration_type'] === 'forever' ? null : date('Y-m-d H:i:s', time() + ((int) $package['duration_days'] * 86400));
        $this->update($user['id'], [
            'package_id' => $package['id'],
            'package_expire_time' => $expire,
            'total_storage' => $package['storage_limit'],
            'total_traffic' => $package['traffic_limit'],
            'updated_at' => now(),
        ]);
        return true;
    }

    public function addBalance($userId, $amount)
    {
        return Database::execute('UPDATE ' . $this->table() . ' SET balance = balance + ?, updated_at = ? WHERE id = ?', [$amount, now(), $userId]);
    }

    public function consumeBalance($userId, $amount)
    {
        return Database::execute('UPDATE ' . $this->table() . ' SET balance = balance - ?, updated_at = ? WHERE id = ? AND balance >= ?', [$amount, now(), $userId, $amount]);
    }
}
