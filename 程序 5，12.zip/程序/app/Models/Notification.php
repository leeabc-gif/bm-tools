<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Notification extends Model
{
    protected $table = 'notifications';

    public function userNotifications($userId)
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' WHERE user_id = ? ORDER BY id DESC', [$userId]);
    }

    public function createForUser($userId, $type, $title, $content)
    {
        return $this->create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'content' => $content,
            'is_read' => 0,
            'created_at' => now(),
        ]);
    }
}

