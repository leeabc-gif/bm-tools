<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Package extends Model
{
    protected $table = 'packages';

    public function enabled()
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' WHERE status = 1 ORDER BY sort_order ASC, id ASC');
    }
}

