<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Recharge extends Model
{
    protected $table = 'recharges';

    public function userRecharges($userId)
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' WHERE user_id = ? ORDER BY id DESC', [$userId]);
    }
}

