<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Announcement extends Model
{
    protected $table = 'announcements';

    public static function categories()
    {
        return [
            'platform' => ['name' => '平台公告', 'icon' => 'megaphone', 'desc' => '平台运营、服务变更、维护通知'],
            'system' => ['name' => '系统公告', 'icon' => 'bell-ring', 'desc' => '系统升级、安全提醒、故障说明'],
            'help' => ['name' => '平台帮助', 'icon' => 'circle-help', 'desc' => '常见问题、功能说明、使用帮助'],
            'tutorial' => ['name' => '平台教程', 'icon' => 'book-open-check', 'desc' => '图床、网盘、API、对象存储教程'],
        ];
    }

    public function visible($limit = null, $homeOnly = false)
    {
        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE status = 1 AND (published_at IS NULL OR published_at <= ?)';
        $params = [now()];
        if ($homeOnly) {
            $sql .= ' AND show_home = 1';
        }
        $sql .= ' ORDER BY is_top DESC, published_at DESC, id DESC';
        if ($limit) {
            $sql .= ' LIMIT ' . (int) $limit;
        }
        return Database::fetchAll($sql, $params);
    }

    public function visibleByCategory($category = '', $keyword = '', $limit = null)
    {
        $sql = 'SELECT * FROM ' . $this->table() . ' WHERE status = 1 AND (published_at IS NULL OR published_at <= ?)';
        $params = [now()];
        if ($category !== '' && isset(self::categories()[$category])) {
            $sql .= ' AND category = ?';
            $params[] = $category;
        }
        if ($keyword !== '') {
            $sql .= ' AND (title LIKE ? OR summary LIKE ? OR tags LIKE ? OR content LIKE ?)';
            $like = '%' . $keyword . '%';
            array_push($params, $like, $like, $like, $like);
        }
        $sql .= ' ORDER BY is_top DESC, published_at DESC, id DESC';
        if ($limit) {
            $sql .= ' LIMIT ' . (int) $limit;
        }
        return Database::fetchAll($sql, $params);
    }

    public function categoryCounts()
    {
        $rows = Database::fetchAll('SELECT category, COUNT(*) AS c FROM ' . $this->table() . ' WHERE status = 1 AND (published_at IS NULL OR published_at <= ?) GROUP BY category', [now()]);
        $counts = ['all' => 0];
        foreach (array_keys(self::categories()) as $key) {
            $counts[$key] = 0;
        }
        foreach ($rows as $row) {
            $key = $row['category'] ?: 'platform';
            if (!isset($counts[$key])) {
                $counts[$key] = 0;
            }
            $counts[$key] = (int) $row['c'];
            $counts['all'] += (int) $row['c'];
        }
        return $counts;
    }

    public function incrementViews($id)
    {
        Database::execute('UPDATE ' . $this->table() . ' SET view_count = view_count + 1 WHERE id = ?', [(int) $id]);
    }
}
