<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Order extends Model
{
    protected $table = 'orders';

    public function createOrder($userId, $type, $amount, $paymentMethod, $packageId = null, $remark = '', $payAmount = null)
    {
        $orderNo = date('YmdHis') . mt_rand(100000, 999999);
        $id = $this->create([
            'order_no' => $orderNo,
            'user_id' => $userId,
            'type' => $type,
            'package_id' => $packageId,
            'amount' => $amount,
            'pay_amount' => $payAmount === null ? $amount : $payAmount,
            'payment_method' => $paymentMethod,
            'status' => 'pending',
            'remark' => $remark,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $this->find($id);
    }

    public function userOrders($userId)
    {
        return Database::fetchAll('SELECT o.*, p.name AS package_name FROM ' . $this->table() . ' o LEFT JOIN ' . Database::table('packages') . ' p ON o.package_id = p.id WHERE o.user_id = ? ORDER BY o.id DESC', [$userId]);
    }

    public function markPaid($orderId, $tradeNo = null)
    {
        return $this->update($orderId, [
            'status' => 'paid',
            'trade_no' => $tradeNo,
            'paid_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
