<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Coupon extends Model
{
    protected $table = 'coupons';

    public function activeList()
    {
        return Database::fetchAll(
            'SELECT * FROM ' . $this->table() . " WHERE status = 1 AND (start_at IS NULL OR start_at <= ?) AND (end_at IS NULL OR end_at >= ?) ORDER BY sort_order ASC, id DESC",
            [now(), now()]
        );
    }

    public function findByCode($code)
    {
        return Database::fetch('SELECT * FROM ' . $this->table() . ' WHERE code = ? LIMIT 1', [strtoupper(trim($code))]);
    }
}
