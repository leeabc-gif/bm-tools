<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class StorageDriver extends Model
{
    protected $table = 'storage_drivers';

    public function enabled()
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' WHERE is_enabled = 1 ORDER BY is_default DESC, id ASC');
    }

    public function defaultDriver()
    {
        $driver = Database::fetch('SELECT * FROM ' . $this->table() . ' WHERE is_enabled = 1 AND is_default = 1 LIMIT 1');
        if (!$driver) {
            $driver = Database::fetch('SELECT * FROM ' . $this->table() . ' WHERE is_enabled = 1 ORDER BY id ASC LIMIT 1');
        }
        return $driver;
    }
}

