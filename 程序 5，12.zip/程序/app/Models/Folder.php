<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class Folder extends Model
{
    protected $table = 'file_folders';

    public function userFolders($userId, $parentId = 0)
    {
        return Database::fetchAll('SELECT * FROM ' . $this->table() . ' WHERE user_id = ? AND parent_id = ? ORDER BY name ASC', [$userId, $parentId]);
    }
}

