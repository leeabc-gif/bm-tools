<?php
namespace App\Models;

use App\Core\Database;
use App\Core\Model;

class MonitorMetric extends Model
{
    protected $table = 'monitor_metrics';

    public function latest($serverId)
    {
        return Database::fetch('SELECT * FROM ' . $this->table() . ' WHERE server_id = ? ORDER BY id DESC LIMIT 1', [$serverId]);
    }

    public function range($serverId, $range)
    {
        $hours = $range === '7d' ? 168 : ($range === '24h' ? 24 : 1);
        return Database::fetchAll(
            'SELECT * FROM ' . $this->table() . ' WHERE server_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL ' . (int) $hours . ' HOUR) ORDER BY created_at ASC',
            [$serverId]
        );
    }
}

