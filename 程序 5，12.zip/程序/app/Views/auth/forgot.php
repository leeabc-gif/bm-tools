<section class="auth-shell reveal">
    <form class="auth-card glass" method="post" action="<?= url('forgot') ?>">
        <?= csrf_field() ?>
        <p class="eyebrow">Reset</p>
        <h1>找回密码</h1>
        <label>注册邮箱<input type="email" name="email" value="<?= e(old('email')) ?>" required></label>
        <button class="btn btn-primary full" type="submit">发送验证码</button>
    </form>
</section>

