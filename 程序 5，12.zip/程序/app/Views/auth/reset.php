<section class="auth-shell reveal">
    <form class="auth-card glass" method="post" action="<?= url('reset-password') ?>">
        <?= csrf_field() ?>
        <p class="eyebrow">Reset</p>
        <h1>重置密码</h1>
        <p>验证码已为 <?= e($email) ?> 生成。</p>
        <label>验证码<input name="code" required></label>
        <label>新密码<input type="password" name="password" required></label>
        <button class="btn btn-primary full" type="submit">重置密码</button>
    </form>
</section>

