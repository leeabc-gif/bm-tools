<section class="auth-shell reveal">
    <form class="auth-card glass" method="post" action="<?= url('register') ?>">
        <?= csrf_field() ?>
        <p class="eyebrow">New account</p>
        <h1>注册</h1>
        <label>用户名<input name="username" value="<?= e(old('username')) ?>" required></label>
        <label>邮箱<input type="email" name="email" value="<?= e(old('email')) ?>" required></label>
        <?php if ((string) setting('register_email_code_enabled', '0') === '1'): ?>
            <label>邮箱验证码
                <div class="input-action">
                    <input name="email_code" required>
                    <button class="btn btn-ghost send-code-btn" type="button" data-scene="register" data-token="<?= e(csrf_token()) ?>">发送</button>
                </div>
            </label>
        <?php endif; ?>
        <label>密码<input type="password" name="password" required></label>
        <label>确认密码<input type="password" name="password_confirm" required></label>
        <button class="btn btn-primary full" type="submit">创建账号</button>
        <div class="form-links"><a href="<?= url('login') ?>">已有账号登录</a></div>
    </form>
</section>
