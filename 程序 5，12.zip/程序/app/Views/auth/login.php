<section class="auth-shell reveal">
    <form class="auth-card glass" method="post" action="<?= url('login') ?>">
        <?= csrf_field() ?>
        <p class="eyebrow">Welcome back</p>
        <h1>登录</h1>
        <label>用户名或邮箱<input name="account" value="<?= e(old('account')) ?>" required></label>
        <label>密码<input type="password" name="password" required></label>
        <label class="inline-check"><input type="checkbox" name="remember" value="1"> 记住登录状态</label>
        <button class="btn btn-primary full" type="submit">登录</button>
        <div class="form-links"><a href="<?= url('forgot') ?>">找回密码</a><a href="<?= url('register') ?>">注册账号</a></div>
    </form>
</section>

