<section class="aurora-hero reveal">
    <div class="aurora-panel glass">
        <p class="eyebrow">Aurora Gallery</p>
        <h1>上传即分发，素材有秩序</h1>
        <p class="hero-copy">用更柔和的视觉呈现图床和网盘能力，首页按钮直达上传、网盘、套餐、公告和个人中心。</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?= \App\Core\Auth::check() ? url('files') : url('register') ?>" data-icon="upload-cloud">上传图片</a>
            <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="folder-open">打开网盘</a>
            <a class="btn btn-ghost" href="<?= url('dashboard') ?>" data-icon="layout-dashboard">个人中心</a>
        </div>
    </div>
    <div class="aurora-stack">
        <a class="aurora-tile glass" href="<?= url('packages') ?>">
            <b>套餐订阅</b>
            <span>空间、流量、API 权限按需升级</span>
        </a>
        <a class="aurora-tile glass" href="<?= url('announcements') ?>">
            <b>公告通知</b>
            <span>版本更新、维护计划和运营通知</span>
        </a>
        <a class="aurora-tile glass" href="<?= url('api/console') ?>">
            <b>开放 API</b>
            <span>接入 PicGo、ShareX 和自定义脚本</span>
        </a>
    </div>
</section>

<section class="aurora-ribbon reveal">
    <a href="<?= url('files') ?>"><span>01</span><b>图床</b><small>多格式外链生成</small></a>
    <a href="<?= url('netdisk') ?>"><span>02</span><b>网盘</b><small>个人文件管理</small></a>
    <a href="<?= url('api/console') ?>"><span>03</span><b>API</b><small>开发者上传接口</small></a>
    <a href="<?= url('packages') ?>"><span>04</span><b>套餐</b><small>余额购买与续费</small></a>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/stats_rings.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/product_links.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/packages_notice.php'; ?>
