<section class="nebula-hero glass reveal">
    <div class="nebula-copy">
        <p class="eyebrow">Nebula Storage</p>
        <h1>把图片、文件与外链分发接入同一片云端</h1>
        <p class="hero-copy">适合站长、开发者、内容创作者和小团队使用，支持图床上传、轻量网盘、多对象存储、套餐订阅和开放 API。</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?= \App\Core\Auth::check() ? url('files') : url('register') ?>" data-icon="rocket">立即开始</a>
            <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="hard-drive">个人网盘</a>
            <a class="btn btn-ghost" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">套餐价格</a>
        </div>
    </div>
    <div class="nebula-orbit">
        <a href="<?= url('files') ?>" class="orbit-card glass">
            <span class="home-icon" data-lucide="image"></span>
            <b>图床外链</b>
            <small>Markdown / HTML / BBCode</small>
        </a>
        <a href="<?= url('netdisk') ?>" class="orbit-card glass">
            <span class="home-icon" data-lucide="folder-open"></span>
            <b>轻量网盘</b>
            <small>文件夹 / 分享 / 预览</small>
        </a>
        <a href="<?= url('api/console') ?>" class="orbit-card glass">
            <span class="home-icon" data-lucide="terminal"></span>
            <b>API 接入</b>
            <small>PicGo / ShareX / 脚本</small>
        </a>
        <a href="<?= url('packages') ?>" class="orbit-card glass">
            <span class="home-icon" data-lucide="badge-dollar-sign"></span>
            <b>套餐订阅</b>
            <small>容量 / 流量 / 权限</small>
        </a>
    </div>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/stats_rings.php'; ?>

<section class="feature-grid reveal">
    <a class="feature-card glass" href="<?= url('files') ?>"><b>图片上传与外链</b><p>支持批量上传、拖拽、粘贴、URL 拉取和 API 上传。</p></a>
    <a class="feature-card glass" href="<?= url('admin/storages') ?>"><b>多云存储架构</b><p>后台统一管理 OSS、COS、Kodo 等对象存储源。</p></a>
    <a class="feature-card glass" href="<?= url('dashboard') ?>"><b>个人工作台</b><p>用户中心聚合图片、网盘、余额、套餐、订单和 API Token。</p></a>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/product_links.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/packages_notice.php'; ?>
