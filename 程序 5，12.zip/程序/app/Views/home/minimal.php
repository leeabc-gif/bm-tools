<section class="minimal-hero reveal">
    <p class="eyebrow">Clean Storage Platform</p>
    <h1><?= e(setting('site_name', 'BM TOOLS')) ?></h1>
    <p>把图片上传、外链分发、个人网盘、套餐订阅和 API 接入收进一个安静、高效、清爽的工作台。</p>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= \App\Core\Auth::check() ? url('files') : url('register') ?>" data-icon="rocket">立即使用</a>
        <a class="btn btn-ghost" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">套餐价格</a>
        <a class="btn btn-ghost" href="<?= url('announcements') ?>" data-icon="megaphone">公告帮助</a>
    </div>
</section>

<section class="minimal-strip reveal">
    <a href="<?= url('files') ?>"><b>图床</b><span>上传并生成多格式外链</span></a>
    <a href="<?= url('netdisk') ?>"><b>网盘</b><span>轻量文件管理和分享</span></a>
    <a href="<?= url('api/console') ?>"><b>API</b><span>PicGo / ShareX / 脚本</span></a>
    <a href="<?= url('packages') ?>"><b>套餐</b><span>容量、流量和权限升级</span></a>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/stats_rings.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/product_links.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/packages_notice.php'; ?>
