<section class="creator-hero glass reveal">
    <div>
        <p class="eyebrow">For Creators</p>
        <h1>让作品、素材和外链都有漂亮秩序</h1>
        <p class="hero-copy">适合博客作者、设计师、文档维护者和内容团队。上传图片后可直接获取 Markdown、HTML、BBCode 和原图直链。</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?= \App\Core\Auth::check() ? url('files') : url('register') ?>" data-icon="image">创建图库</a>
            <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="folder-open">整理素材</a>
            <a class="btn btn-ghost" href="<?= url('announcements') ?>" data-icon="megaphone">平台公告</a>
        </div>
    </div>
    <div class="creator-board">
        <div class="shot large"></div>
        <div class="shot"></div>
        <div class="shot tint"></div>
        <div class="shot wide"></div>
    </div>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/stats_rings.php'; ?>

<section class="feature-grid reveal">
    <a class="feature-card glass" href="<?= url('files') ?>"><b>外链输出</b><p>原图、Markdown、HTML、BBCode 一键复制。</p></a>
    <a class="feature-card glass" href="<?= url('netdisk') ?>"><b>素材归档</b><p>图片、文档、音视频集中存放。</p></a>
    <a class="feature-card glass" href="<?= url('packages') ?>"><b>容量套餐</b><p>按创作规模选择空间、流量和 API 权限。</p></a>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/product_links.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/packages_notice.php'; ?>
