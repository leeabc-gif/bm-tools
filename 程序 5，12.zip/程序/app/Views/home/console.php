<section class="console-hero glass reveal">
    <div class="console-window">
        <div class="console-bar"><span></span><span></span><span></span></div>
        <pre>POST /api/upload
X-API-Token: ********

storage: OSS / COS / Kodo
output: direct_url, markdown, html, bbcode
status: ready</pre>
    </div>
    <div>
        <p class="eyebrow">Developer Console</p>
        <h1>为开发者和站长准备的图床工作流</h1>
        <p class="hero-copy">偏工具化的首页风格，突出 API 上传、PicGo、ShareX、多对象存储和个人文件工作台。</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?= \App\Core\Auth::check() ? url('api/console') : url('register') ?>" data-icon="terminal">API 控制台</a>
            <a class="btn btn-ghost" href="<?= url('files') ?>" data-icon="image">图片管理</a>
            <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="hard-drive">个人网盘</a>
        </div>
    </div>
</section>

<section class="console-grid reveal">
    <a class="console-cell glass" href="<?= url('files') ?>"><b>Image Host</b><span>拖拽、粘贴、URL 拉取、批量复制</span></a>
    <a class="console-cell glass" href="<?= url('netdisk') ?>"><b>Drive</b><span>文件夹、分享链接、基础预览</span></a>
    <a class="console-cell glass" href="<?= url('packages') ?>"><b>Billing</b><span>余额充值、套餐购买、订单记录</span></a>
    <a class="console-cell glass" href="<?= url('api/console') ?>"><b>API</b><span>Token 上传、脚本接入、容量查询</span></a>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/stats_rings.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/product_links.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/packages_notice.php'; ?>
