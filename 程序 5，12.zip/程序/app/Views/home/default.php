<section class="hero glass reveal">
    <div>
        <p class="eyebrow">IMAGE HOST · PERSONAL DRIVE</p>
        <h1><?= e(setting('site_name', 'BM TOOLS')) ?></h1>
        <p class="hero-copy">面向站长、开发者、内容创作者和小团队的图床与轻量网盘平台，支持多对象存储、外链生成、套餐订阅、余额充值和开放 API。</p>
        <div class="hero-actions">
            <?php if (\App\Core\Auth::check()): ?>
                <a class="btn btn-primary" href="<?= url('files') ?>" data-icon="upload-cloud">立即上传</a>
                <a class="btn btn-ghost" href="<?= url('netdisk') ?>" data-icon="hard-drive">个人网盘</a>
                <a class="btn btn-ghost" href="<?= url('dashboard') ?>" data-icon="layout-dashboard">个人中心</a>
            <?php else: ?>
                <a class="btn btn-primary" href="<?= url('register') ?>" data-icon="sparkles">注册体验</a>
                <a class="btn btn-ghost" href="<?= url('login') ?>" data-icon="log-in">登录账号</a>
                <a class="btn btn-ghost" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">查看套餐</a>
            <?php endif; ?>
        </div>
    </div>
    <form class="upload-panel glass" method="post" action="<?= url('files/upload') ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="drop-zone">
            <input type="file" name="images[]" multiple accept="image/*">
            <span>拖拽、点击或粘贴图片上传</span>
            <small>支持批量上传，容量和单文件大小由当前套餐决定</small>
        </div>
        <button class="btn btn-primary full" type="submit" data-icon="upload-cloud">上传图片</button>
    </form>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/stats_rings.php'; ?>

<section class="feature-grid reveal">
    <a class="feature-card glass" href="<?= url('files') ?>">
        <b>图床服务</b>
        <p>上传图片后自动生成原图直链、Markdown、HTML 和 BBCode，适合博客、论坛和文档写作。</p>
    </a>
    <a class="feature-card glass" href="<?= url('netdisk') ?>">
        <b>个人网盘</b>
        <p>管理文件夹、上传常用文件、生成分享链接，让素材和文档更好归档。</p>
    </a>
    <a class="feature-card glass" href="<?= url('packages') ?>">
        <b>充值套餐</b>
        <p>通过余额购买或续费套餐，按需扩展容量、流量、API 上传和更多使用权限。</p>
    </a>
    <a class="feature-card glass" href="<?= url('api/console') ?>">
        <b>开放 API</b>
        <p>提供 Token 上传接口，方便对接 PicGo、ShareX、Markdown 编辑器和自定义脚本。</p>
    </a>
    <a class="feature-card glass" href="<?= url('announcements') ?>">
        <b>公告帮助</b>
        <p>查看平台公告、维护计划、功能更新和使用教程，快速了解最新服务信息。</p>
    </a>
    <a class="feature-card glass" href="<?= url('dashboard') ?>">
        <b>个人中心</b>
        <p>集中查看图片、网盘、订单、余额、套餐、资料和 API Token。</p>
    </a>
</section>

<?php require APP_ROOT . '/app/Views/home/partials/product_links.php'; ?>

<?php require APP_ROOT . '/app/Views/home/partials/packages_notice.php'; ?>
