<section class="section-heading reveal">
    <p class="eyebrow">Packages</p>
    <h2>套餐方案</h2>
</section>
<div class="pricing-grid reveal">
    <?php if (!$packages): ?>
        <article class="price-card glass">
            <h3>暂无套餐</h3>
            <p>管理员可以在后台创建免费版、基础版、专业版或企业版套餐。</p>
            <a class="btn btn-ghost full" href="<?= url('packages') ?>">查看套餐页</a>
        </article>
    <?php endif; ?>
    <?php foreach ($packages as $package): ?>
        <article class="price-card glass">
            <h3><?= e($package['name']) ?></h3>
            <div class="price">￥<?= e($package['price']) ?></div>
            <p><?= e($package['description']) ?></p>
            <ul class="clean-list">
                <li>空间 <?= e(format_bytes($package['storage_limit'])) ?></li>
                <li>流量 <?= e(format_bytes($package['traffic_limit'])) ?></li>
                <li>单文件 <?= e(format_bytes($package['single_file_limit'])) ?></li>
            </ul>
            <a class="btn btn-ghost full" href="<?= url('packages') ?>">查看详情</a>
        </article>
    <?php endforeach; ?>
</div>

<?php if ($announcements): ?>
<section class="section-heading reveal">
    <p class="eyebrow">Notice</p>
    <h2>最新公告</h2>
</section>
<div class="notice-list reveal">
    <?php foreach ($announcements as $item): ?>
        <a class="notice-item glass" href="<?= url('announcements/' . $item['id']) ?>">
            <b><?= e($item['title']) ?></b>
            <span><?= e($item['published_at']) ?></span>
        </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>
