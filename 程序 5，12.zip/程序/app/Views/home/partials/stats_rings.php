<?php
$homeStats = isset($stats) && is_array($stats) ? $stats : [];
$files = isset($homeStats['files']) ? (int) $homeStats['files'] : 0;
$todayUploads = isset($homeStats['today_uploads']) ? (int) $homeStats['today_uploads'] : 0;
$storage = isset($homeStats['storage']) ? (int) $homeStats['storage'] : 0;
$packageCount = isset($packages) && is_array($packages) ? count($packages) : 0;

$fileProgress = min(100, max(6, $files > 0 ? 72 : 10));
$uploadProgress = min(100, max(6, $todayUploads > 0 ? 64 : 10));
$storageProgress = min(100, max(6, $storage > 0 ? 58 : 10));
$packageProgress = min(100, max(6, $packageCount > 0 ? 76 : 10));

$items = [
    ['label' => '全站文件', 'value' => number_format($files), 'unit' => '个', 'progress' => $fileProgress, 'icon' => 'files'],
    ['label' => '今日上传', 'value' => number_format($todayUploads), 'unit' => '次', 'progress' => $uploadProgress, 'icon' => 'upload-cloud'],
    ['label' => '存储占用', 'value' => format_bytes($storage), 'unit' => '', 'progress' => $storageProgress, 'icon' => 'database'],
    ['label' => '可选套餐', 'value' => number_format($packageCount), 'unit' => '款', 'progress' => $packageProgress, 'icon' => 'badge-dollar-sign'],
];
?>
<section class="home-ring-stats reveal">
    <?php foreach ($items as $item): ?>
        <article class="home-progress-card glass">
            <div class="home-progress-head">
                <span class="home-progress-icon" data-lucide="<?= e($item['icon']) ?>"></span>
                <div>
                    <span><?= e($item['label']) ?></span>
                    <b><?= e($item['value']) ?><?php if ($item['unit'] !== ''): ?><small><?= e($item['unit']) ?></small><?php endif; ?></b>
                </div>
            </div>
            <div class="home-progress-track" aria-hidden="true">
                <i style="width: <?= e($item['progress']) ?>%"></i>
            </div>
        </article>
    <?php endforeach; ?>
</section>
