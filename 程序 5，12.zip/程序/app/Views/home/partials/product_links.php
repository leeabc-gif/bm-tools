<section class="product-links reveal">
    <a class="product-link glass" href="<?= url('files') ?>" data-icon="image">
        <b>图床上传</b>
        <span>上传图片并复制多格式外链</span>
    </a>
    <a class="product-link glass" href="<?= url('netdisk') ?>" data-icon="hard-drive">
        <b>个人网盘</b>
        <span>管理文件、文件夹和分享链接</span>
    </a>
    <a class="product-link glass" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">
        <b>套餐订阅</b>
        <span>余额购买、续费与升级套餐</span>
    </a>
    <a class="product-link glass" href="<?= url('api/console') ?>" data-icon="terminal">
        <b>开放 API</b>
        <span>PicGo、ShareX、脚本上传</span>
    </a>
    <a class="product-link glass" href="<?= url('announcements') ?>" data-icon="megaphone">
        <b>公告帮助</b>
        <span>维护计划、教程和产品更新</span>
    </a>
    <a class="product-link glass" href="<?= url('dashboard') ?>" data-icon="layout-dashboard">
        <b>个人中心</b>
        <span>资料、余额、订单和套餐</span>
    </a>
</section>
