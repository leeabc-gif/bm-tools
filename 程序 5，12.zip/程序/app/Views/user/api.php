<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Open API</p>
        <h1>API 管理</h1>
        <p>适用于 PicGo、ShareX、Markdown 编辑器和自定义脚本上传图片或管理文件。这里给出接口地址、鉴权方式和最近调用记录，方便快速接入。</p>
    </div>
</section>

<section class="form-section glass reveal">
    <h2>鉴权信息</h2>
    <div class="form-grid">
        <label>API Token<input readonly value="<?= e($user['api_token']) ?>"></label>
        <label>上传接口<input readonly value="<?= e(url('api/upload')) ?>"></label>
        <label>文件列表接口<input readonly value="<?= e(url('api/files')) ?>"></label>
        <label>删除接口<input readonly value="<?= e(url('api/delete')) ?>"></label>
        <label>容量接口<input readonly value="<?= e(url('api/quota')) ?>"></label>
    </div>
</section>

<section class="feature-grid reveal">
    <div class="feature-card glass">
        <b>PicGo 上传示例</b>
        <p>请求方式 POST，文件字段名为 <code>file</code>，请求头添加 <code>X-API-Token</code>。</p>
        <pre class="code-block">URL: <?= e(url('api/upload')) ?>
Method: POST
File field: file
Header: X-API-Token: <?= e($user['api_token']) ?>
Response path: data.url</pre>
    </div>
    <div class="feature-card glass">
        <b>ShareX 配置示例</b>
        <p>使用自定义上传器，表单文件字段设置为 <code>file</code>，请求头携带 Token。</p>
        <pre class="code-block">{
  "RequestURL": "<?= e(url('api/upload')) ?>",
  "FileFormName": "file",
  "Headers": {
    "X-API-Token": "<?= e($user['api_token']) ?>"
  },
  "URL": "$json:data.url$"
}</pre>
    </div>
    <div class="feature-card glass">
        <b>curl 示例</b>
        <p>适合命令行、CI、脚本和文档站调用。</p>
        <pre class="code-block"># 上传
curl -X POST "<?= e(url('api/upload')) ?>" \
  -H "X-API-Token: <?= e($user['api_token']) ?>" \
  -F "type=image" \
  -F "file=@demo.jpg"

# 文件列表
curl -X POST "<?= e(url('api/files')) ?>" \
  -H "X-API-Token: <?= e($user['api_token']) ?>" \
  -d "page=1&limit=20"

# 删除文件
curl -X POST "<?= e(url('api/delete')) ?>" \
  -H "X-API-Token: <?= e($user['api_token']) ?>" \
  -d "id=文件ID"

# 容量查询
curl -X POST "<?= e(url('api/quota')) ?>" \
  -H "X-API-Token: <?= e($user['api_token']) ?>"</pre>
    </div>
</section>

<section class="table-card glass reveal">
    <h2>最近 API 调用</h2>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>接口</th><th>方式</th><th>IP</th><th>状态码</th><th>结果</th><th>信息</th><th>时间</th></tr>
            </thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= e($log['endpoint']) ?></td>
                    <td><?= e($log['method']) ?></td>
                    <td><?= e($log['ip']) ?></td>
                    <td><?= e($log['status_code']) ?></td>
                    <td><?= $log['is_success'] ? '成功' : '失败' ?></td>
                    <td><?= e($log['message']) ?></td>
                    <td><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
