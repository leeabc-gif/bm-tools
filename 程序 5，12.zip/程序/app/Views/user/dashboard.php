<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Dashboard</p>
        <h1><?= e($user['nickname'] ?: $user['username']) ?></h1>
        <p>当前套餐 <?= e($package ? $package['name'] : '未绑定') ?> · 余额 ¥<?= e($user['balance']) ?> · 个人中心专注图床与网盘服务</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url('files') ?>" data-icon="upload-cloud">上传图片</a>
        <a class="btn btn-ghost" href="<?= url('recharge') ?>" data-icon="wallet">充值余额</a>
        <a class="btn btn-ghost" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">升级套餐</a>
    </div>
</section>

<section class="workspace-summary-grid reveal">
    <article class="workspace-summary-card glass <?= $dashboardStats['storage_percent'] >= 80 ? 'warn' : '' ?>">
        <span>存储使用</span>
        <b><?= e($dashboardStats['storage_percent']) ?>%</b>
        <small><?= e(format_bytes($user['used_storage'])) ?> / <?= e(format_bytes($user['total_storage'])) ?></small>
        <i><em style="width: <?= e($dashboardStats['storage_percent']) ?>%"></em></i>
    </article>
    <article class="workspace-summary-card glass">
        <span>流量使用</span>
        <b><?= e($dashboardStats['traffic_percent']) ?>%</b>
        <small><?= e(format_bytes($user['used_traffic'])) ?> / <?= e(format_bytes($user['total_traffic'])) ?></small>
        <i><em style="width: <?= e($dashboardStats['traffic_percent']) ?>%"></em></i>
    </article>
    <article class="workspace-summary-card glass">
        <span>文件资产</span>
        <b><?= e($dashboardStats['file_total']) ?></b>
        <small>图片 <?= e($dashboardStats['image_total']) ?> · 网盘 <?= e($dashboardStats['netdisk_total']) ?></small>
    </article>
    <article class="workspace-summary-card glass">
        <span>账户余额</span>
        <b>¥<?= e($user['balance']) ?></b>
        <small><?= (float) $user['balance'] <= 0 ? '建议充值后再购买套餐' : '余额状态正常' ?></small>
    </article>
</section>

<section class="dashboard-two-col reveal">
    <article class="table-card glass">
        <div class="section-heading compact">
            <p class="eyebrow">Next Actions</p>
            <h2>下一步建议</h2>
        </div>
        <div class="action-stack">
            <?php foreach ($dashboardStats['tips'] as $tip): ?>
                <a class="action-card" href="<?= e($tip['url']) ?>" data-icon="<?= e($tip['icon']) ?>">
                    <b><?= e($tip['title']) ?></b>
                    <span><?= e($tip['desc']) ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="table-card glass">
        <div class="section-heading compact">
            <p class="eyebrow">Recent Files</p>
            <h2>最近文件</h2>
        </div>
        <div class="compact-file-list">
            <?php if (!$dashboardStats['recent']): ?>
                <div class="compact-file-row empty-row"><b>暂无文件</b><span>上传图片或网盘文件后会出现在这里。</span></div>
            <?php endif; ?>
            <?php foreach ($dashboardStats['recent'] as $file): ?>
                <a class="compact-file-row" href="<?= $file['file_type'] === 'image' ? url('files/detail?id=' . $file['id']) : url('netdisk') ?>">
                    <b><?= e($file['original_name']) ?></b>
                    <span><?= e($file['file_type'] === 'image' ? '图片' : '文件') ?> · <?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </article>
</section>

<section class="quick-grid reveal">
    <a class="feature-card glass" href="<?= url('files') ?>" data-icon="image"><b>图片管理</b><p>查看缩略图、复制外链、批量删除。</p></a>
    <a class="feature-card glass" href="<?= url('netdisk') ?>" data-icon="hard-drive"><b>轻量网盘</b><p>管理文件夹、上传文件与生成分享。</p></a>
    <a class="feature-card glass" href="<?= url('api/console') ?>" data-icon="terminal"><b>API 接入</b><p>查看 Token，配置 PicGo、ShareX 和脚本上传。</p></a>
    <a class="feature-card glass" href="<?= url('profile') ?>" data-icon="user"><b>个人资料</b><p>修改昵称、头像、邮箱和密码。</p></a>
</section>
