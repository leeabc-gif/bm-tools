<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Account</p>
        <h1>个人资料</h1>
        <p>管理你的基础资料、头像、邮箱和 API Token。Token 用于 PicGo、ShareX、脚本上传等开放接口场景，请妥善保管。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url('api/console') ?>" data-icon="terminal">API 管理</a>
        <a class="btn btn-ghost" href="<?= url('password') ?>" data-icon="lock-keyhole">修改密码</a>
    </div>
</section>

<section class="profile-layout">
    <article class="form-section glass reveal">
        <div class="section-heading compact">
            <p class="eyebrow">Basic</p>
            <h2>基础资料</h2>
        </div>
        <form method="post" action="<?= url('profile') ?>" class="form-grid two">
            <?= csrf_field() ?>
            <label>用户名<input value="<?= e($user['username']) ?>" disabled></label>
            <label>昵称<input name="nickname" value="<?= e($user['nickname']) ?>" required></label>
            <label>邮箱<input type="email" name="email" value="<?= e($user['email']) ?>" required></label>
            <label>头像 URL<input name="avatar" value="<?= e($user['avatar']) ?>" placeholder="可填写图片直链，例如 https://example.com/avatar.png"></label>
            <label>注册时间<input value="<?= e($user['created_at']) ?>" disabled></label>
            <label>上次登录<input value="<?= e($user['last_login_time'] ?: '暂无记录') ?>" disabled></label>
            <div class="form-actions span-all">
                <button class="btn btn-primary" type="submit" data-icon="save">保存资料</button>
                <a class="btn btn-ghost" href="<?= url('dashboard') ?>" data-icon="layout-dashboard">返回工作台</a>
            </div>
        </form>
    </article>

    <aside class="form-section glass reveal profile-security-card">
        <div class="section-heading compact">
            <p class="eyebrow">Security</p>
            <h2>接口安全</h2>
        </div>
        <div class="api-token-box">
            <span>当前 API Token</span>
            <code><?= e($user['api_token']) ?></code>
        </div>
        <p class="muted-text">重置后旧 Token 会立即失效。已接入 PicGo、ShareX、自动化脚本的设备，需要同步替换为新的 Token。</p>
        <form method="post" action="<?= url('profile/api-token/reset') ?>" onsubmit="return confirm('确认重置 API Token？旧 Token 将立即失效。');">
            <?= csrf_field() ?>
            <button class="btn btn-danger" type="submit" data-icon="refresh-cw">重置 Token</button>
        </form>
    </aside>
</section>
