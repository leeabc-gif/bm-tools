<?php
$storage = isset($usage['storage']) ? $usage['storage'] : null;
$package = isset($usage['package']) ? $usage['package'] : ['name' => '默认套餐', 'single_file_limit' => 0, 'allow_api' => 0];
$singleLimit = (int) $package['single_file_limit'] > 0 ? format_bytes($package['single_file_limit']) : '不限';
$storageTypeNames = ['local' => '本地存储', 'oss' => '阿里云 OSS', 'cos' => '腾讯云 COS', 'kodo' => '七牛云 Kodo'];
?>

<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Image Host</p>
        <h1>图床工作台</h1>
        <p>支持批量上传、拖拽上传、粘贴上传和远程 URL 拉取。上传后自动生成直链、Markdown、HTML 和 BBCode，适合站长、开发者和内容团队日常使用。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">升级套餐</a>
        <a class="btn btn-ghost" href="<?= url('api/console') ?>" data-icon="terminal">API 上传</a>
    </div>
</section>

<section class="workspace-summary-grid reveal">
    <article class="workspace-summary-card glass">
        <span>当前套餐</span>
        <b><?= e($package['name']) ?></b>
        <small>单文件限制：<?= e($singleLimit) ?></small>
    </article>
    <article class="workspace-summary-card glass <?= $usage['is_near_limit'] ? 'warn' : '' ?>">
        <span>容量使用</span>
        <b><?= e($usage['storage_percent']) ?>%</b>
        <small><?= e(format_bytes($usage['used_storage'])) ?> / <?= e(format_bytes($usage['total_storage'])) ?></small>
        <i><em style="width: <?= e($usage['storage_percent']) ?>%"></em></i>
    </article>
    <article class="workspace-summary-card glass">
        <span>图片数量</span>
        <b><?= e($usage['file_count']) ?></b>
        <small>累计占用：<?= e(format_bytes($usage['file_size'])) ?></small>
    </article>
    <article class="workspace-summary-card glass">
        <span>默认存储</span>
        <b><?= e($storage ? (isset($storageTypeNames[$storage['type']]) ? $storageTypeNames[$storage['type']] : $storage['type']) : '未配置') ?></b>
        <small><?= e($storage ? $storage['name'] : '请先在后台配置默认存储源') ?></small>
    </article>
</section>

<?php if ($usage['is_near_limit']): ?>
    <section class="commercial-tip reveal">
        <b>容量即将用满</b>
        <span>当前空间已使用 <?= e($usage['storage_percent']) ?>%，建议清理回收站或升级套餐，避免后续上传失败。</span>
        <a class="btn btn-primary" href="<?= url('packages') ?>" data-icon="arrow-up-right">查看升级方案</a>
    </section>
<?php endif; ?>

<?php if (!$storage): ?>
    <section class="commercial-tip reveal">
        <b>当前没有可用存储线路</b>
        <span>图床上传依赖后台默认对象存储，请先在后台配置并测试存储源。</span>
    </section>
<?php endif; ?>

<section class="upload-workbench glass reveal">
    <div class="upload-guidance">
        <b>上传说明</b>
        <span>支持 JPG、PNG、GIF、WebP 等格式。建议文件命名清晰，品牌内容优先使用自定义域名，方便统一外链形象。</span>
    </div>
    <form method="post" action="<?= url('files/upload') ?>" enctype="multipart/form-data" class="upload-form">
        <?= csrf_field() ?>
        <div class="drop-zone large">
            <input type="file" name="images[]" multiple accept="image/*">
            <span>拖拽图片到这里，或点击选择图片</span>
            <small>也可以直接粘贴截图。上传后自动生成多格式外链。</small>
        </div>
        <button class="btn btn-primary" type="submit" data-icon="upload-cloud">开始上传</button>
    </form>
    <form method="post" action="<?= url('files/fetch') ?>" class="url-fetch">
        <?= csrf_field() ?>
        <input name="remote_url" placeholder="https://example.com/image.jpg">
        <button class="btn btn-ghost" type="submit" data-icon="link">URL 拉取</button>
    </form>
</section>

<form method="get" action="<?= url('files') ?>" class="toolbar glass reveal">
    <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索文件名">
    <input type="date" name="date_start" value="<?= e($dateStart) ?>">
    <input type="date" name="date_end" value="<?= e($dateEnd) ?>">
    <button class="btn btn-ghost" type="submit" data-icon="filter">筛选</button>
    <a class="btn btn-ghost" href="<?= url('files') ?>" data-icon="rotate-ccw">重置</a>
</form>

<form method="post" action="<?= url('files/delete') ?>" class="reveal confirm-form" data-confirm="确认把选中的图片移入回收站吗？">
    <?= csrf_field() ?>
    <div class="toolbar glass">
        <button class="btn btn-ghost" type="submit" data-icon="archive-x">移入回收站</button>
        <button class="btn btn-ghost copy-selected" type="button" data-icon="copy">批量复制直链</button>
        <a class="btn btn-ghost" href="<?= url('netdisk/recycle') ?>" data-icon="rotate-ccw">回收站</a>
    </div>
    <div class="image-grid">
        <?php if (!$files): ?>
            <article class="image-card glass empty-card image-empty-card">
                <b>还没有图片</b>
                <p>从上方上传区拖拽图片，或粘贴截图快速上传。上传后会在这里显示缩略图和常用外链。</p>
                <a class="btn btn-primary" href="#top" data-icon="upload-cloud">去上传</a>
            </article>
        <?php endif; ?>
        <?php foreach ($files as $file): ?>
            <article class="image-card glass">
                <input type="checkbox" name="ids[]" value="<?= e($file['id']) ?>" data-url="<?= e($file['file_url']) ?>">
                <img src="<?= e($file['thumbnail_url'] ?: $file['file_url']) ?>" alt="<?= e($file['original_name']) ?>" loading="lazy">
                <div class="image-meta">
                    <b title="<?= e($file['original_name']) ?>"><?= e($file['original_name']) ?></b>
                    <small><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></small>
                </div>
                <div class="link-box">
                    <label>直链<input readonly value="<?= e($file['file_url']) ?>"></label>
                    <label>Markdown<input readonly value="![<?= e($file['original_name']) ?>](<?= e($file['file_url']) ?>)"></label>
                    <label>HTML<input readonly value="<img src=&quot;<?= e($file['file_url']) ?>&quot; alt=&quot;<?= e($file['original_name']) ?>&quot;>"></label>
                    <label>BBCode<input readonly value="[img]<?= e($file['file_url']) ?>[/img]"></label>
                </div>
                <div class="card-actions">
                    <button class="btn btn-ghost copy-current-inputs" type="button" data-icon="copy">复制链接</button>
                    <a class="btn btn-ghost" href="<?= url('files/detail?id=' . $file['id']) ?>" data-icon="eye">详情</a>
                    <a class="btn btn-ghost" href="<?= e($file['file_url']) ?>" target="_blank" data-icon="external-link">原图</a>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</form>
