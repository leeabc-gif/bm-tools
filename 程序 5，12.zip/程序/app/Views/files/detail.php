<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Image Detail</p>
        <h1>图片详情</h1>
        <p><?= e($file['original_name']) ?> · <?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('files') ?>" data-icon="arrow-left">返回图片管理</a>
        <a class="btn btn-primary" href="<?= e($file['file_url']) ?>" target="_blank" data-icon="external-link">查看原图</a>
    </div>
</section>

<section class="detail-layout reveal">
    <article class="glass detail-preview">
        <img src="<?= e($file['file_url']) ?>" alt="<?= e($file['original_name']) ?>">
    </article>
    <article class="glass detail-panel">
        <div class="section-heading compact">
            <p class="eyebrow">Links</p>
            <h2>外链格式</h2>
        </div>
        <div class="link-box rich">
            <label>原图直链<input readonly value="<?= e($file['file_url']) ?>"></label>
            <label>Markdown<input readonly value="![<?= e($file['original_name']) ?>](<?= e($file['file_url']) ?>)"></label>
            <label>HTML<input readonly value="<img src=&quot;<?= e($file['file_url']) ?>&quot; alt=&quot;<?= e($file['original_name']) ?>&quot;>"></label>
            <label>BBCode<input readonly value="[img]<?= e($file['file_url']) ?>[/img]"></label>
        </div>
        <div class="card-actions">
            <button class="btn btn-primary copy-current-inputs" type="button" data-icon="copy">复制全部链接</button>
        </div>
        <div class="section-heading compact">
            <p class="eyebrow">Meta</p>
            <h2>文件信息</h2>
        </div>
        <div class="meta-table">
            <span>文件名</span><b><?= e($file['original_name']) ?></b>
            <span>文件大小</span><b><?= e(format_bytes($file['file_size'])) ?></b>
            <span>图片尺寸</span><b><?= e(($file['width'] ?: '-') . ' x ' . ($file['height'] ?: '-')) ?></b>
            <span>MIME</span><b><?= e($file['mime_type']) ?></b>
            <span>MD5</span><b><?= e($file['md5'] ?: '-') ?></b>
            <span>存储路径</span><b><?= e($file['file_path']) ?></b>
        </div>
    </article>
</section>
