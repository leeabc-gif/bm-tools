<?php
$catKey = isset($item['category']) && isset($categories[$item['category']]) ? $item['category'] : 'platform';
$cat = $categories[$catKey];
$tags = array_filter(array_map('trim', explode(',', isset($item['tags']) ? $item['tags'] : '')));
$content = (string) $item['content'];
if ((isset($item['content_format']) ? $item['content_format'] : 'html') !== 'html') {
    $content = nl2br(e($content));
}
?>

<article class="notice-article">
    <a class="btn btn-ghost" href="<?= url('announcements') ?>" data-icon="arrow-left">返回公告中心</a>

    <header class="notice-article-head">
        <div class="notice-post-meta">
            <span><i data-lucide="<?= e($cat['icon']) ?>"></i><?= e($cat['name']) ?></span>
            <?php if (!empty($item['is_top'])): ?><span class="hot">置顶</span><?php endif; ?>
            <time><?= e($item['published_at'] ?: $item['created_at']) ?></time>
            <span><?= e((int) $item['view_count']) ?> 次阅读</span>
        </div>
        <h1><?= e($item['title']) ?></h1>
        <?php if (!empty($item['summary'])): ?><p><?= e($item['summary']) ?></p><?php endif; ?>
        <?php if ($tags): ?>
            <div class="notice-tags">
                <?php foreach ($tags as $tag): ?><span>#<?= e($tag) ?></span><?php endforeach; ?>
            </div>
        <?php endif; ?>
    </header>

    <?php if (!empty($item['cover_image'])): ?>
        <figure class="notice-article-cover">
            <img src="<?= e($item['cover_image']) ?>" alt="<?= e($item['title']) ?>">
        </figure>
    <?php endif; ?>

    <section class="notice-article-body">
        <?= $content ?>
    </section>
</article>
