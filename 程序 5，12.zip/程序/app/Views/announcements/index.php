<?php
$currentCategory = isset($currentCategory) ? $currentCategory : '';
$keyword = isset($keyword) ? $keyword : '';
$categoryName = $currentCategory && isset($categories[$currentCategory]) ? $categories[$currentCategory]['name'] : '全部内容';
if (!function_exists('announcement_excerpt')) {
function announcement_excerpt($item)
{
    $summary = isset($item['summary']) ? trim($item['summary']) : '';
    if ($summary !== '') {
        return $summary;
    }
    return mb_substr(trim(strip_tags($item['content'])), 0, 120);
}
}
?>

<section class="notice-hero glass reveal">
    <div>
        <p class="eyebrow">BM TOOLS Notice Hub</p>
        <h1>公告与帮助中心</h1>
        <p>集中展示平台公告、系统通知、帮助文档和使用教程。页面独立展示，适配 PC 与手机端，方便用户快速查找重点内容。</p>
    </div>
    <div class="notice-total glass">
        <b><?= e(isset($counts['all']) ? $counts['all'] : count($announcements)) ?></b>
        <span>已发布内容</span>
    </div>
</section>

<form method="get" action="<?= url('announcements') ?>" class="notice-search glass reveal">
    <?php if ($currentCategory): ?><input type="hidden" name="category" value="<?= e($currentCategory) ?>"><?php endif; ?>
    <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索标题、标签、摘要或正文内容">
    <button class="btn btn-primary" data-icon="search">搜索</button>
    <?php if ($keyword || $currentCategory): ?><a class="btn btn-ghost" href="<?= url('announcements') ?>" data-icon="rotate-ccw">重置</a><?php endif; ?>
</form>

<section class="notice-category-row reveal">
    <a class="<?= $currentCategory === '' ? 'active' : '' ?>" href="<?= url('announcements') ?>">
        <span data-lucide="layout-grid"></span>
        <b>全部内容</b>
        <small><?= e(isset($counts['all']) ? $counts['all'] : 0) ?> 篇</small>
    </a>
    <?php foreach ($categories as $key => $meta): ?>
        <a class="<?= $currentCategory === $key ? 'active' : '' ?>" href="<?= url('announcements?category=' . $key) ?>">
            <span data-lucide="<?= e($meta['icon']) ?>"></span>
            <b><?= e($meta['name']) ?></b>
            <small><?= e(isset($counts[$key]) ? $counts[$key] : 0) ?> 篇 · <?= e($meta['desc']) ?></small>
        </a>
    <?php endforeach; ?>
</section>

<section class="notice-list-head reveal">
    <div>
        <p class="eyebrow">Content Feed</p>
        <h2><?= e($categoryName) ?></h2>
        <p><?= $keyword ? '搜索：' . e($keyword) : '按发布时间倒序展示，置顶内容优先。' ?></p>
    </div>
</section>

<section class="notice-feed reveal">
    <?php if (!$announcements): ?>
        <article class="notice-empty glass">
            <b>暂无匹配内容</b>
            <p>换一个关键词，或切换到其他分类试试。</p>
        </article>
    <?php endif; ?>

    <?php foreach ($announcements as $item): ?>
        <?php
        $cat = isset($item['category']) && isset($categories[$item['category']]) ? $categories[$item['category']] : $categories['platform'];
        $tags = array_filter(array_map('trim', explode(',', isset($item['tags']) ? $item['tags'] : '')));
        ?>
        <article class="notice-post glass <?= !empty($item['is_top']) ? 'pinned' : '' ?> <?= empty($item['cover_image']) ? 'no-cover' : '' ?>">
            <?php if (!empty($item['cover_image'])): ?>
                <a class="notice-cover" href="<?= url('announcements/' . $item['id']) ?>">
                    <img src="<?= e($item['cover_image']) ?>" alt="<?= e($item['title']) ?>">
                </a>
            <?php endif; ?>
            <div class="notice-post-main">
                <div class="notice-post-meta">
                    <span><i data-lucide="<?= e($cat['icon']) ?>"></i><?= e($cat['name']) ?></span>
                    <?php if (!empty($item['is_top'])): ?><span class="hot">置顶</span><?php endif; ?>
                    <time><?= e($item['published_at'] ?: $item['created_at']) ?></time>
                </div>
                <h2><a href="<?= url('announcements/' . $item['id']) ?>"><?= e($item['title']) ?></a></h2>
                <p><?= e(announcement_excerpt($item)) ?></p>
                <div class="notice-post-bottom">
                    <div class="notice-tags">
                        <?php foreach (array_slice($tags, 0, 4) as $tag): ?><span>#<?= e($tag) ?></span><?php endforeach; ?>
                    </div>
                    <a class="btn btn-ghost" href="<?= url('announcements/' . $item['id']) ?>" data-icon="arrow-right">阅读全文</a>
                </div>
            </div>
        </article>
    <?php endforeach; ?>
</section>
