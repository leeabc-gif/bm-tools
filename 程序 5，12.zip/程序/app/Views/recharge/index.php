<?php
$methodNames = ['manual' => '人工充值审核', 'alipay' => '支付宝当面付', 'wechat' => '微信支付', 'epay' => '易支付', 'balance' => '余额支付'];
$statusNames = ['pending' => '待支付 / 待审核', 'paid' => '已入账', 'rejected' => '已拒绝', 'closed' => '已关闭'];
$quickAmounts = [10, 30, 50, 100, 200, 500];
?>

<section class="dashboard-hero glass reveal pay-hero">
    <div>
        <p class="eyebrow">Recharge Center</p>
        <h1>账户充值</h1>
        <p>充值余额可用于购买套餐、续费套餐和后续增值服务。在线支付成功后自动入账，人工充值需要管理员审核。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('orders') ?>" data-icon="receipt-text">订单记录</a>
        <a class="btn btn-ghost" href="<?= url('balance/logs') ?>" data-icon="coins">余额流水</a>
    </div>
</section>

<section class="pay-layout reveal">
    <article class="form-section glass pay-panel">
        <div class="section-head">
            <div>
                <p class="eyebrow">Create Order</p>
                <h2>创建充值订单</h2>
            </div>
            <span class="status-pill soft">人民币 CNY</span>
        </div>

        <form method="post" action="<?= url('recharge') ?>" class="recharge-form">
            <?= csrf_field() ?>
            <label class="pay-amount-field">充值金额
                <input id="rechargeAmount" type="number" step="0.01" min="1" max="99999" name="amount" required placeholder="请输入充值金额">
            </label>
            <div class="quick-amounts" aria-label="快捷金额">
                <?php foreach ($quickAmounts as $amount): ?>
                    <button class="btn btn-ghost quick-amount" type="button" data-amount="<?= e($amount) ?>">￥<?= e($amount) ?></button>
                <?php endforeach; ?>
            </div>

            <div class="payment-method-grid">
                <?php foreach ($payments as $index => $payment): ?>
                    <?php $code = $payment['code']; ?>
                    <label class="payment-method-card <?= $index === 0 ? 'active' : '' ?>">
                        <input type="radio" name="payment_method" value="<?= e($code) ?>" <?= $index === 0 ? 'checked' : '' ?>>
                        <span class="payment-icon" data-lucide="<?= $code === 'alipay' ? 'scan-line' : 'badge-check' ?>"></span>
                        <b><?= e($payment['name']) ?></b>
                        <small>
                            <?php if ($code === 'alipay'): ?>
                                扫码支付，成功后自动入账
                            <?php elseif ($code === 'manual'): ?>
                                提交订单后由管理员审核
                            <?php else: ?>
                                当前支付通道已启用
                            <?php endif; ?>
                        </small>
                    </label>
                <?php endforeach; ?>
            </div>

            <button class="btn btn-primary pay-submit" type="submit" <?= empty($payments) ? 'disabled' : '' ?> data-icon="plus-circle">创建充值订单</button>
        </form>

        <?php if (empty($payments)): ?>
            <div class="alert error">暂无可用充值方式，请管理员先在后台启用人工充值或配置支付宝当面付。</div>
        <?php endif; ?>
    </article>

    <aside class="glass pay-tips">
        <h2>充值说明</h2>
        <div class="pay-tip-item">
            <b>快捷金额</b>
            <span>点击金额按钮会自动填入充值金额，也可以手动输入任意合法金额。</span>
        </div>
        <div class="pay-tip-item">
            <b>自动入账</b>
            <span>支付宝当面付支付成功后会自动回调入账，也可以在扫码页手动刷新订单状态。</span>
        </div>
        <div class="pay-tip-item">
            <b>人工审核</b>
            <span>人工充值订单创建后请联系管理员，审核通过后余额会进入账户。</span>
        </div>
    </aside>
</section>

<section class="table-card glass reveal">
    <div class="section-head">
        <div>
            <p class="eyebrow">Recharge Logs</p>
            <h2>充值记录</h2>
        </div>
        <a class="btn btn-ghost" href="<?= url('orders') ?>" data-icon="external-link">查看全部订单</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>金额</th><th>方式</th><th>状态</th><th>时间</th></tr></thead>
            <tbody>
            <?php if (!$recharges): ?>
                <tr><td colspan="4" class="empty-table">暂无充值记录。</td></tr>
            <?php endif; ?>
            <?php foreach ($recharges as $row): ?>
                <tr>
                    <td>￥<?= e(number_format((float) $row['amount'], 2)) ?></td>
                    <td><?= e(isset($methodNames[$row['payment_method']]) ? $methodNames[$row['payment_method']] : $row['payment_method']) ?></td>
                    <td><span class="status-pill <?= $row['status'] === 'paid' ? 'ok' : ($row['status'] === 'pending' ? 'soft' : 'muted') ?>"><?= e(isset($statusNames[$row['status']]) ? $statusNames[$row['status']] : $row['status']) ?></span></td>
                    <td><?= e($row['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
