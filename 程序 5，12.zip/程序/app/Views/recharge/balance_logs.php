<section class="table-card glass reveal">
    <div class="section-heading"><p class="eyebrow">Balance</p><h1>余额流水</h1></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>类型</th><th>金额</th><th>变动前</th><th>变动后</th><th>关联</th><th>备注</th><th>时间</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $row): ?>
                <tr>
                    <td><?= e($row['type']) ?></td>
                    <td><?= e($row['amount']) ?></td>
                    <td><?= e($row['balance_before']) ?></td>
                    <td><?= e($row['balance_after']) ?></td>
                    <td><?= e($row['related_type']) ?> #<?= e($row['related_id']) ?></td>
                    <td><?= e($row['remark']) ?></td>
                    <td><?= e($row['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

