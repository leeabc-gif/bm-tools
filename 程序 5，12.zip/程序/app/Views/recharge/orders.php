<?php
$typeNames = ['recharge' => '账户充值', 'package' => '套餐购买'];
$methodNames = ['manual' => '人工充值', 'alipay' => '支付宝', 'wechat' => '微信支付', 'epay' => '易支付', 'balance' => '余额'];
$statusNames = ['pending' => '待支付', 'paid' => '已支付', 'closed' => '已关闭', 'refunded' => '已退款'];
?>

<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Orders</p>
        <h1>订单记录</h1>
        <p>查看充值、套餐购买、支付状态和交易号。支付后未到账时，可把订单号提供给管理员核查。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url('recharge') ?>" data-icon="plus-circle">发起充值</a>
        <a class="btn btn-ghost" href="<?= url('balance/logs') ?>" data-icon="coins">余额流水</a>
    </div>
</section>

<section class="table-card glass reveal">
    <div class="table-wrap">
        <table>
            <thead><tr><th>订单号</th><th>类型</th><th>套餐</th><th>金额</th><th>支付方式</th><th>状态</th><th>交易号</th><th>创建时间</th><th>操作</th></tr></thead>
            <tbody>
            <?php if (!$orders): ?>
                <tr><td colspan="9" class="empty-table">暂无订单记录。</td></tr>
            <?php endif; ?>
            <?php foreach ($orders as $row): ?>
                <tr>
                    <td><b><?= e($row['order_no']) ?></b></td>
                    <td><?= e(isset($typeNames[$row['type']]) ? $typeNames[$row['type']] : $row['type']) ?></td>
                    <td><?= e($row['package_name'] ?: '-') ?></td>
                    <td>¥<?= e(number_format((float) $row['pay_amount'], 2)) ?></td>
                    <td><?= e(isset($methodNames[$row['payment_method']]) ? $methodNames[$row['payment_method']] : $row['payment_method']) ?></td>
                    <td><span class="status-pill <?= $row['status'] === 'paid' ? 'ok' : ($row['status'] === 'pending' ? 'soft' : 'muted') ?>"><?= e(isset($statusNames[$row['status']]) ? $statusNames[$row['status']] : $row['status']) ?></span></td>
                    <td><?= e($row['trade_no'] ?: '-') ?></td>
                    <td><?= e($row['created_at']) ?></td>
                    <td>
                        <?php if ($row['type'] === 'recharge' && $row['payment_method'] === 'alipay' && $row['status'] === 'pending'): ?>
                            <a class="btn btn-ghost" href="<?= url('pay/alipay/' . $row['order_no']) ?>" data-icon="scan-line">继续支付</a>
                        <?php else: ?>
                            <span class="muted-text">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
