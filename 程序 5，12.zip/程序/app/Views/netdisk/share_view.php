<section class="auth-shell reveal">
    <div class="auth-card glass">
        <p class="eyebrow">Shared file</p>
        <h1><?= e($share['original_name']) ?></h1>
        <p><?= e(format_bytes($share['file_size'])) ?> · <?= e($share['created_at']) ?></p>
        <?php if ($locked): ?>
            <form method="get" action="<?= url('share/' . $share['share_code']) ?>" class="form-grid">
                <label>提取码<input name="extract_code" value="<?= e($extractCode) ?>" required></label>
                <button class="btn btn-primary full" type="submit">解锁文件</button>
            </form>
        <?php else: ?>
            <?php if (strpos($share['mime_type'], 'image/') === 0): ?><img class="preview-media" src="<?= e($share['file_url']) ?>" alt=""><?php endif; ?>
            <?php if (strpos($share['mime_type'], 'video/') === 0): ?><video class="preview-media" src="<?= e($share['file_url']) ?>" controls></video><?php endif; ?>
            <?php if (strpos($share['mime_type'], 'audio/') === 0): ?><audio class="preview-media" src="<?= e($share['file_url']) ?>" controls></audio><?php endif; ?>
            <a class="btn btn-primary full" href="<?= url('share/' . $share['share_code'] . '/download?extract_code=' . urlencode($extractCode)) ?>">下载文件</a>
        <?php endif; ?>
    </div>
</section>
