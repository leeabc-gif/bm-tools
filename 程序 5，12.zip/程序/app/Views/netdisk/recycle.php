<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Recycle Bin</p>
        <h1>回收站</h1>
        <p>误删的图片和网盘文件会先保存在这里。你可以恢复文件，也可以彻底删除远程对象。彻底删除后无法恢复。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url('netdisk') ?>" data-icon="hard-drive">返回网盘</a>
        <a class="btn btn-ghost" href="<?= url('files') ?>" data-icon="image">返回图床</a>
    </div>
</section>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Deleted files</p>
        <h2>已删除文件</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>文件</th><th>类型</th><th>大小</th><th>删除时间</th><th>原路径</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="6" class="empty-table">回收站为空。</td></tr>
            <?php endif; ?>
            <?php foreach ($items as $item): ?>
                <?php $file = $item['file']; ?>
                <tr>
                    <td><?= e(isset($file['original_name']) ? $file['original_name'] : '未知文件') ?></td>
                    <td><?= e(isset($file['file_type']) ? ($file['file_type'] === 'image' ? '图片' : '文件') : '-') ?></td>
                    <td><?= e(isset($file['file_size']) ? format_bytes($file['file_size']) : '-') ?></td>
                    <td><?= e($item['deleted_at']) ?></td>
                    <td><?= e(isset($file['file_path']) ? $file['file_path'] : '-') ?></td>
                    <td>
                        <div class="table-actions">
                            <form method="post" action="<?= url('netdisk/restore') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($item['id']) ?>">
                                <button class="btn btn-primary btn-sm" type="submit" data-icon="rotate-ccw">恢复</button>
                            </form>
                            <form method="post" action="<?= url('netdisk/purge') ?>" class="confirm-form" data-confirm="彻底删除后无法恢复，并且会删除远程对象，确认继续吗？">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($item['id']) ?>">
                                <button class="btn btn-ghost btn-sm" type="submit" data-icon="trash-2">彻底删除</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
