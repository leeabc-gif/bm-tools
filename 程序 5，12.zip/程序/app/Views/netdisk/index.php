<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Netdisk</p>
        <h1>轻量网盘</h1>
        <p>用于文件分类、在线预览、分享和回收站管理。适合存放文档、压缩包、音视频和团队资料，不只是图床的附属功能。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('shares') ?>" data-icon="share-2">分享记录</a>
        <a class="btn btn-ghost" href="<?= url('netdisk/recycle') ?>" data-icon="archive-restore">回收站</a>
        <a class="btn btn-ghost" href="<?= url('packages') ?>" data-icon="badge-dollar-sign">扩容</a>
    </div>
</section>

<section class="workspace-summary-grid reveal">
    <article class="workspace-summary-card glass">
        <span>当前套餐</span>
        <b><?= e($usage['package']['name']) ?></b>
        <small>分享：<?= !empty($usage['package']['allow_share']) ? '已开启' : '未开启' ?> · 视频预览：<?= !empty($usage['package']['allow_video_preview']) ? '已开启' : '未开启' ?></small>
    </article>
    <article class="workspace-summary-card glass <?= $usage['is_near_limit'] ? 'warn' : '' ?>">
        <span>容量使用</span>
        <b><?= e($usage['storage_percent']) ?>%</b>
        <small><?= e(format_bytes($usage['used_storage'])) ?> / <?= e(format_bytes($usage['total_storage'])) ?></small>
        <i><em style="width: <?= e($usage['storage_percent']) ?>%"></em></i>
    </article>
    <article class="workspace-summary-card glass">
        <span>文件 / 文件夹</span>
        <b><?= e($usage['file_count']) ?> / <?= e($usage['folder_count']) ?></b>
        <small>总占用：<?= e(format_bytes($usage['file_size'])) ?></small>
    </article>
    <article class="workspace-summary-card glass">
        <span>单文件限制</span>
        <b><?= e((int) $usage['package']['single_file_limit'] > 0 ? format_bytes($usage['package']['single_file_limit']) : '不限') ?></b>
        <small><?= $usage['is_near_limit'] ? '容量偏紧，建议扩容' : '可继续上传文件' ?></small>
    </article>
</section>

<?php if ($usage['is_near_limit']): ?>
    <section class="commercial-tip reveal">
        <b>网盘容量接近上限</b>
        <span>当前空间已使用 <?= e($usage['storage_percent']) ?>%，建议清理回收站或升级套餐，避免大文件上传失败。</span>
        <a class="btn btn-primary" href="<?= url('packages') ?>" data-icon="arrow-up-right">立即扩容</a>
    </section>
<?php endif; ?>

<section class="upload-workbench glass reveal">
    <div class="upload-guidance">
        <b>文件工作台</b>
        <span>建议按项目创建文件夹。需要对外发送资料时使用分享链接，可设置提取码、有效期和下载次数。</span>
    </div>
    <form method="get" action="<?= url('netdisk') ?>" class="url-fetch">
        <input type="hidden" name="folder_id" value="<?= e($folderId) ?>">
        <input name="keyword" value="<?= e($keyword) ?>" placeholder="搜索当前文件夹文件">
        <select name="category">
            <option value="">全部类型</option>
            <option value="image" <?= $category === 'image' ? 'selected' : '' ?>>图片</option>
            <option value="document" <?= $category === 'document' ? 'selected' : '' ?>>文档</option>
            <option value="archive" <?= $category === 'archive' ? 'selected' : '' ?>>压缩包</option>
            <option value="video" <?= $category === 'video' ? 'selected' : '' ?>>视频</option>
            <option value="audio" <?= $category === 'audio' ? 'selected' : '' ?>>音频</option>
            <option value="other" <?= $category === 'other' ? 'selected' : '' ?>>其他</option>
        </select>
        <button class="btn btn-ghost" type="submit" data-icon="search">搜索</button>
        <a class="btn btn-ghost" href="<?= url('netdisk?folder_id=' . $folderId) ?>" data-icon="rotate-ccw">重置</a>
    </form>
    <form method="post" action="<?= url('netdisk/folder') ?>" class="url-fetch">
        <?= csrf_field() ?>
        <input type="hidden" name="parent_id" value="<?= e($folderId) ?>">
        <input name="name" placeholder="新建文件夹名称">
        <button class="btn btn-ghost" type="submit" data-icon="folder-plus">新建文件夹</button>
    </form>
    <form method="post" action="<?= url('netdisk/upload') ?>" enctype="multipart/form-data" class="upload-form">
        <?= csrf_field() ?>
        <input type="hidden" name="folder_id" value="<?= e($folderId) ?>">
        <div class="drop-zone">
            <input type="file" name="files[]" multiple>
            <span>上传任意文件</span>
        </div>
        <button class="btn btn-primary" type="submit" data-icon="upload-cloud">上传文件</button>
    </form>
</section>

<section class="file-list glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Folders</p>
        <h2>文件夹</h2>
    </div>
    <div class="list-grid">
        <?php if (!$folders): ?>
            <div class="file-row empty-row">
                <div class="file-main"><span class="file-badge">DIR</span><b>暂无文件夹</b><small>先创建一个项目文件夹，后续管理会更清晰。</small></div>
            </div>
        <?php endif; ?>
        <?php foreach ($folders as $folder): ?>
            <div class="file-row">
                <a class="file-main" href="<?= url('netdisk?folder_id=' . $folder['id']) ?>"><span class="file-badge">DIR</span><b><?= e($folder['name']) ?></b><small><?= e($folder['created_at']) ?></small></a>
                <form method="post" action="<?= url('netdisk/rename') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($folder['id']) ?>">
                    <input type="hidden" name="type" value="folder">
                    <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                    <input name="name" value="<?= e($folder['name']) ?>">
                    <button class="btn btn-ghost" type="submit" data-icon="pencil">重命名</button>
                </form>
                <form method="post" action="<?= url('netdisk/folder/delete') ?>" class="confirm-form" data-confirm="确认删除该文件夹吗？文件夹内文件会移入回收站。">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($folder['id']) ?>">
                    <button class="btn btn-ghost" type="submit" data-icon="archive-x">删除</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="section-heading compact">
        <p class="eyebrow">Files</p>
        <h2>文件</h2>
    </div>
    <form id="batchDeleteForm" method="post" action="<?= url('netdisk/batch-delete') ?>" class="confirm-form" data-confirm="确认把选中文件移入回收站吗？">
        <?= csrf_field() ?>
        <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
        <div class="toolbar">
            <label class="inline-check"><input type="checkbox" class="select-all" data-target="netdisk-file"> 全选文件</label>
            <button class="btn btn-ghost" type="submit" data-icon="archive-x">批量删除</button>
        </div>
    </form>
    <div class="list-grid">
        <?php if (!$files): ?>
            <div class="file-row empty-row">
                <div class="file-main"><span class="file-badge">FILE</span><b>当前文件夹暂无文件</b><small>上传文件后会在这里统一展示。</small></div>
            </div>
        <?php endif; ?>
        <?php foreach ($files as $file): ?>
            <div class="file-row">
                <div class="file-main">
                    <input form="batchDeleteForm" type="checkbox" name="ids[]" value="<?= e($file['id']) ?>" data-group="netdisk-file">
                    <span class="file-badge"><?= $file['file_type'] === 'image' ? 'IMG' : 'FILE' ?></span>
                    <b><?= e($file['original_name']) ?></b>
                    <small><?= e(format_bytes($file['file_size'])) ?> · <?= e($file['created_at']) ?></small>
                </div>
                <a class="btn btn-ghost" href="<?= e($file['file_url']) ?>" target="_blank" data-icon="eye">预览</a>
                <form method="post" action="<?= url('netdisk/rename') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                    <input type="hidden" name="type" value="file">
                    <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                    <input name="name" value="<?= e($file['original_name']) ?>">
                    <button class="btn btn-ghost" type="submit" data-icon="pencil">重命名</button>
                </form>
                <form method="post" action="<?= url('netdisk/move') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                    <select name="folder_id">
                        <option value="0">根目录</option>
                        <?php foreach ($allFolders as $folder): ?>
                            <option value="<?= e($folder['id']) ?>"><?= e($folder['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn btn-ghost" type="submit" data-icon="folder-input">移动</button>
                </form>
                <form method="post" action="<?= url('netdisk/share') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="file_id" value="<?= e($file['id']) ?>">
                    <input name="extract_code" placeholder="提取码">
                    <input type="number" name="expire_days" placeholder="有效天数">
                    <input type="number" name="download_limit" placeholder="下载次数">
                    <button class="btn btn-primary" type="submit" data-icon="share-2">分享</button>
                </form>
                <form method="post" action="<?= url('netdisk/delete') ?>" class="confirm-form" data-confirm="确认把该文件移入回收站吗？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($file['id']) ?>">
                    <input type="hidden" name="current_folder_id" value="<?= e($folderId) ?>">
                    <button class="btn btn-ghost" type="submit" data-icon="archive-x">删除</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</section>
