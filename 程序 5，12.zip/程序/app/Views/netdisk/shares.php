<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Shares</p>
        <h1>分享记录</h1>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>文件</th><th>链接</th><th>提取码</th><th>有效期</th><th>下载次数</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php foreach ($shares as $row): ?>
                <tr>
                    <td><?= e($row['original_name']) ?></td>
                    <td><input readonly value="<?= e(url('share/' . $row['share_code'])) ?>"></td>
                    <td><?= e($row['extract_code'] ?: '-') ?></td>
                    <td><?= e($row['expire_at'] ?: '永久') ?></td>
                    <td><?= e($row['download_count']) ?>/<?= e($row['download_limit'] ?: '不限') ?></td>
                    <td><?= $row['status'] ? '启用' : '关闭' ?></td>
                    <td>
                        <form method="post" action="<?= url('netdisk/share/status') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($row['id']) ?>">
                            <input type="hidden" name="status" value="<?= $row['status'] ? 0 : 1 ?>">
                            <button class="btn btn-ghost" type="submit"><?= $row['status'] ? '关闭' : '启用' ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
