<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Monitor Center</p>
        <h1>服务器监控</h1>
        <p>集中监控运营服务器的 CPU、内存、硬盘、服务状态和告警。这里仅展示运营侧节点，不开放给普通用户管理。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= url('monitor/create') ?>" data-icon="server-cog">添加服务器</a>
        <a class="btn btn-ghost" href="<?= url('alerts') ?>" data-icon="bell-ring">告警记录</a>
    </div>
</section>

<section class="server-overview-grid reveal">
    <article class="workspace-summary-card glass">
        <span>服务器总数</span>
        <b><?= e($stats['total']) ?></b>
        <small>已纳入 BM TOOLS 运营监控</small>
    </article>
    <article class="workspace-summary-card glass">
        <span>在线节点</span>
        <b><?= e($stats['online']) ?></b>
        <small>最近一次采集状态正常</small>
    </article>
    <article class="workspace-summary-card glass <?= $stats['offline'] > 0 ? 'warn' : '' ?>">
        <span>离线节点</span>
        <b><?= e($stats['offline']) ?></b>
        <small>需要优先排查连接或服务</small>
    </article>
    <article class="workspace-summary-card glass <?= $stats['unread_alerts'] > 0 ? 'warn' : '' ?>">
        <span>未读告警</span>
        <b><?= e($stats['unread_alerts']) ?></b>
        <small>今日告警 <?= e($stats['alerts_today']) ?> 条</small>
    </article>
</section>

<form method="get" action="<?= url('monitor') ?>" class="monitor-filter-bar glass reveal">
    <input name="keyword" value="<?= e($filters['keyword']) ?>" placeholder="搜索服务器名称、IP、备注或面板地址">
    <select name="group">
        <option value="">全部分组</option>
        <?php foreach ($groups as $item): ?>
            <option value="<?= e($item['group_name']) ?>" <?= $filters['group'] === $item['group_name'] ? 'selected' : '' ?>>
                <?= e($item['group_name']) ?>（<?= e($item['total']) ?>）
            </option>
        <?php endforeach; ?>
    </select>
    <select name="status">
        <option value="">全部状态</option>
        <option value="online" <?= $filters['status'] === 'online' ? 'selected' : '' ?>>在线</option>
        <option value="offline" <?= $filters['status'] === 'offline' ? 'selected' : '' ?>>离线</option>
        <option value="unknown" <?= $filters['status'] === 'unknown' ? 'selected' : '' ?>>未知</option>
    </select>
    <button class="btn btn-ghost" type="submit" data-icon="filter">筛选</button>
    <a class="btn btn-ghost" href="<?= url('monitor') ?>" data-icon="rotate-ccw">重置</a>
</form>

<section class="server-grid reveal">
    <?php if (!$servers): ?>
        <article class="server-card glass">
            <div class="server-head">
                <div>
                    <h3>暂无服务器</h3>
                    <p>添加宝塔面板服务器后，这里会显示实时状态、服务运行情况、采集时间和告警入口。</p>
                </div>
            </div>
            <a class="btn btn-primary" href="<?= url('monitor/create') ?>" data-icon="server-cog">添加第一台服务器</a>
        </article>
    <?php endif; ?>

    <?php foreach ($servers as $server): ?>
        <?php
        $m = $server['latest'];
        $cpu = $m ? (float) $m['cpu_usage'] : 0;
        $memory = $m ? (float) $m['memory_usage'] : 0;
        $disk = $m ? (float) $m['disk_usage'] : 0;
        ?>
        <article class="server-card glass">
            <div class="server-head">
                <div>
                    <h3><?= e($server['name']) ?></h3>
                    <p><?= e($server['server_ip'] ?: $server['panel_url']) ?><?= $server['group_name'] ? ' · ' . e($server['group_name']) : '' ?></p>
                </div>
                <span class="status-dot <?= e($server['status']) ?>"><?= e(status_label($server['status'])) ?></span>
            </div>

            <div class="metric-grid">
                <span>CPU<b><?= e($cpu) ?>%</b></span>
                <span>内存<b><?= e($memory) ?>%</b></span>
                <span>硬盘<b><?= e($disk) ?>%</b></span>
                <span>采集时间<b><?= e($server['last_checked_at'] ?: '-') ?></b></span>
            </div>

            <div class="monitor-mini-rings">
                <div class="mini-ring" style="--value: <?= e($cpu) ?>;"><b><?= e($cpu) ?>%</b><span>CPU</span></div>
                <div class="mini-ring" style="--value: <?= e($memory) ?>;"><b><?= e($memory) ?>%</b><span>内存</span></div>
                <div class="mini-ring" style="--value: <?= e($disk) ?>;"><b><?= e($disk) ?>%</b><span>硬盘</span></div>
            </div>

            <?php if ($m): ?>
                <div class="service-badges">
                    <span class="<?= e(service_badge_class($m['nginx_status'])) ?>">Nginx <?= e(service_label($m['nginx_status'])) ?></span>
                    <span class="<?= e(service_badge_class($m['mysql_status'])) ?>">MySQL <?= e(service_label($m['mysql_status'])) ?></span>
                    <span class="<?= e(service_badge_class($m['php_status'])) ?>">PHP <?= e(service_label($m['php_status'])) ?></span>
                </div>
            <?php endif; ?>

            <?php if (!empty($server['last_error'])): ?>
                <div class="alert error"><?= e($server['last_error']) ?></div>
            <?php endif; ?>

            <div class="card-actions">
                <a class="btn btn-ghost" href="<?= url('monitor/' . $server['id']) ?>" data-icon="eye">详情</a>
                <button class="btn btn-primary collect-btn" data-id="<?= e($server['id']) ?>" data-token="<?= e(csrf_token()) ?>" data-icon="refresh-cw">立即采集</button>
                <form method="post" action="<?= url('monitor/toggle') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                    <button class="btn btn-ghost" type="submit" data-icon="<?= $server['is_enabled'] ? 'pause-circle' : 'play-circle' ?>"><?= $server['is_enabled'] ? '暂停' : '启用' ?></button>
                </form>
                <form method="post" action="<?= url('monitor/delete') ?>" class="confirm-form" data-confirm="确认删除该监控服务器吗？历史采集数据和告警也会一起删除。">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e($server['id']) ?>">
                    <button class="btn btn-ghost" type="submit" data-icon="trash-2">删除</button>
                </form>
            </div>
        </article>
    <?php endforeach; ?>
</section>
