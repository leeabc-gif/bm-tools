<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Add Server</p>
        <h1>添加监控服务器</h1>
        <p>填写宝塔面板地址和 API 密钥后，系统会采集 CPU、内存、硬盘、服务状态与告警数据。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('monitor') ?>" data-icon="arrow-left">返回监控</a>
</section>

<section class="form-section glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Bt Panel</p>
        <h2>宝塔 API 配置</h2>
    </div>
    <form method="post" action="<?= url('monitor') ?>" class="form-grid two monitor-create-form">
        <?= csrf_field() ?>
        <label>服务器名称<input name="name" placeholder="例如：主站服务器" required></label>
        <label>备注<input name="remark" placeholder="例如：南京节点 / 图片存储节点"></label>
        <label>宝塔面板地址<input name="panel_url" placeholder="https://1.2.3.4:8888" required></label>
        <label>宝塔 API 密钥<input name="api_key" placeholder="复制自宝塔面板 API 设置页" required></label>
        <label>面板端口<input type="number" name="panel_port" value="8888" min="1"></label>
        <label>服务器 IP<input name="server_ip" placeholder="例如：1.2.3.4"></label>
        <label>分组名称<input name="group_name" placeholder="例如：生产环境 / 存储节点"></label>
        <label>监控频率（秒）<input type="number" name="frequency" value="60" min="30"></label>
        <label>CPU 告警阈值（%）<input type="number" name="cpu_threshold" value="90" min="1" max="100"></label>
        <label>内存告警阈值（%）<input type="number" name="memory_threshold" value="90" min="1" max="100"></label>
        <label>硬盘告警阈值（%）<input type="number" name="disk_threshold" value="90" min="1" max="100"></label>
        <div class="form-actions span-all">
            <button class="btn btn-primary" type="submit" data-icon="save">保存服务器</button>
            <button class="btn btn-ghost monitor-test-btn" type="button" data-token="<?= e(csrf_token()) ?>" data-icon="plug-zap">测试连接</button>
        </div>
    </form>
</section>

<section class="commercial-tip reveal">
    <b>接入建议</b>
    <span>先在宝塔面板开启 API，并把当前主站 IP 加入白名单。填写后建议先点“测试连接”，确认可以返回系统状态后再保存。</span>
</section>
