<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Alerts</p>
        <h1>告警记录</h1>
        <p>集中查看 CPU、内存、硬盘、面板离线和服务异常告警。未读告警会优先展示，处理后可标记为已处理。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('monitor') ?>" data-icon="activity">返回监控</a>
</section>

<section class="server-overview-grid reveal">
    <article class="workspace-summary-card glass">
        <span>告警总数</span>
        <b><?= e($stats['total']) ?></b>
        <small>历史告警记录</small>
    </article>
    <article class="workspace-summary-card glass <?= $stats['unread'] > 0 ? 'warn' : '' ?>">
        <span>未读告警</span>
        <b><?= e($stats['unread']) ?></b>
        <small>需要尽快检查</small>
    </article>
    <article class="workspace-summary-card glass">
        <span>已读告警</span>
        <b><?= e($stats['read']) ?></b>
        <small>已查看但未关闭</small>
    </article>
    <article class="workspace-summary-card glass">
        <span>已处理</span>
        <b><?= e($stats['resolved']) ?></b>
        <small>已确认或处理完成</small>
    </article>
</section>

<form method="get" action="<?= url('alerts') ?>" class="monitor-filter-bar alerts-filter-bar glass reveal">
    <select name="status">
        <option value="">全部状态</option>
        <option value="unread" <?= $filters['status'] === 'unread' ? 'selected' : '' ?>>未读</option>
        <option value="read" <?= $filters['status'] === 'read' ? 'selected' : '' ?>>已读</option>
        <option value="resolved" <?= $filters['status'] === 'resolved' ? 'selected' : '' ?>>已处理</option>
    </select>
    <select name="level">
        <option value="">全部级别</option>
        <option value="info" <?= $filters['level'] === 'info' ? 'selected' : '' ?>>信息</option>
        <option value="warning" <?= $filters['level'] === 'warning' ? 'selected' : '' ?>>警告</option>
        <option value="danger" <?= $filters['level'] === 'danger' ? 'selected' : '' ?>>严重</option>
    </select>
    <select name="server_id">
        <option value="0">全部服务器</option>
        <?php foreach ($servers as $server): ?>
            <option value="<?= e($server['id']) ?>" <?= (int) $filters['server_id'] === (int) $server['id'] ? 'selected' : '' ?>><?= e($server['name']) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn btn-ghost" type="submit" data-icon="filter">筛选</button>
    <a class="btn btn-ghost" href="<?= url('alerts') ?>" data-icon="rotate-ccw">重置</a>
</form>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Server Alerts</p>
        <h2>告警列表</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>服务器</th><th>级别</th><th>指标</th><th>标题</th><th>内容</th><th>状态</th><th>时间</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$alerts): ?>
                <tr><td colspan="8" class="empty-table">暂无告警记录。</td></tr>
            <?php endif; ?>
            <?php foreach ($alerts as $alert): ?>
                <tr>
                    <td><?= e($alert['server_name'] ?: '-') ?></td>
                    <td><span class="status-pill <?= $alert['level'] === 'danger' ? 'bad' : 'soft' ?>"><?= e(alert_level_label($alert['level'])) ?></span></td>
                    <td><?= e($alert['metric']) ?></td>
                    <td><?= e($alert['title']) ?></td>
                    <td><?= e($alert['content']) ?></td>
                    <td><?= e(alert_status_label($alert['status'])) ?></td>
                    <td><?= e($alert['created_at']) ?></td>
                    <td>
                        <div class="table-actions">
                            <?php if ($alert['status'] === 'unread'): ?>
                                <form method="post" action="<?= url('alerts/read') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= e($alert['id']) ?>">
                                    <button class="btn btn-ghost btn-sm" type="submit" data-icon="mail-open">已读</button>
                                </form>
                            <?php endif; ?>
                            <?php if ($alert['status'] !== 'resolved'): ?>
                                <form method="post" action="<?= url('alerts/resolve') ?>" class="confirm-form" data-confirm="确认将该告警标记为已处理吗？">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= e($alert['id']) ?>">
                                    <button class="btn btn-ghost btn-sm" type="submit" data-icon="check-circle-2">已处理</button>
                                </form>
                            <?php else: ?>
                                <span class="status-pill ok">已处理</span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
