<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">Server Detail</p>
        <h1><?= e($server['name']) ?></h1>
        <p><?= e($server['panel_url']) ?> · <?= e(status_label($server['status'])) ?></p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('monitor') ?>" data-icon="arrow-left">返回列表</a>
        <button class="btn btn-primary collect-btn" data-id="<?= e($server['id']) ?>" data-token="<?= e(csrf_token()) ?>" data-icon="refresh-cw">立即采集</button>
    </div>
</section>

<div class="server-detail-layout">
    <section class="server-detail-panel glass reveal">
        <div class="section-heading compact">
            <p class="eyebrow">Health</p>
            <h2>实时状态</h2>
        </div>
        <div class="server-health-grid">
            <div class="server-health-item">
                <span>CPU 使用率</span>
                <div class="health-ring" style="--value: <?= e($latest ? $latest['cpu_usage'] : 0) ?>;"><b><?= e($latest ? $latest['cpu_usage'] : 0) ?>%</b></div>
            </div>
            <div class="server-health-item">
                <span>内存使用率</span>
                <div class="health-ring" style="--value: <?= e($latest ? $latest['memory_usage'] : 0) ?>;"><b><?= e($latest ? $latest['memory_usage'] : 0) ?>%</b></div>
            </div>
            <div class="server-health-item">
                <span>硬盘使用率</span>
                <div class="health-ring" style="--value: <?= e($latest ? $latest['disk_usage'] : 0) ?>;"><b><?= e($latest ? $latest['disk_usage'] : 0) ?>%</b></div>
            </div>
            <div class="server-health-item">
                <span>在线时长</span>
                <b><?= e($latest ? ($latest['uptime'] ?: '-') : '-') ?></b>
            </div>
        </div>
    </section>

    <section class="server-detail-panel glass reveal">
        <div class="section-heading compact">
            <p class="eyebrow">Info</p>
            <h2>服务器信息</h2>
        </div>
        <div class="meta-table">
            <span>服务器名称</span><b><?= e($server['name']) ?></b>
            <span>备注</span><b><?= e($server['remark'] ?: '-') ?></b>
            <span>面板地址</span><b><?= e($server['panel_url']) ?></b>
            <span>服务器 IP</span><b><?= e($server['server_ip'] ?: '-') ?></b>
            <span>分组</span><b><?= e($server['group_name'] ?: '-') ?></b>
            <span>采集频率</span><b><?= e($server['frequency']) ?> 秒</b>
            <span>最后采集</span><b><?= e($server['last_checked_at'] ?: '-') ?></b>
            <span>最后错误</span><b><?= e($server['last_error'] ?: '-') ?></b>
        </div>
    </section>
</div>

<section class="server-detail-panel glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Trend</p>
        <h2>历史趋势</h2>
    </div>
    <div class="monitor-history-grid">
        <?php if (!$history): ?>
            <div class="admin-empty">暂无历史采集数据，请先点击“立即采集”。</div>
        <?php endif; ?>
        <?php foreach ($history as $row): ?>
            <article class="monitor-history-card">
                <b><?= e($row['created_at']) ?></b>
                <span>CPU <?= e($row['cpu_usage']) ?>%</span>
                <span>内存 <?= e($row['memory_usage']) ?>%</span>
                <span>硬盘 <?= e($row['disk_usage']) ?>%</span>
                <small>负载 <?= e($row['load_avg'] ?: '-') ?></small>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="chart-panel glass reveal">
    <div class="chart-toolbar">
        <h2>监控图表</h2>
        <select id="rangeSelect">
            <option value="1h">1 小时</option>
            <option value="24h">24 小时</option>
            <option value="7d">7 天</option>
        </select>
    </div>
    <div id="monitorChart" data-server="<?= e($server['id']) ?>" style="height:360px"></div>
</section>

<section class="table-card glass reveal">
    <div class="section-heading compact">
        <p class="eyebrow">Alerts</p>
        <h2>最近告警</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>级别</th><th>指标</th><th>标题</th><th>内容</th><th>时间</th></tr></thead>
            <tbody>
            <?php if (!$alerts): ?>
                <tr><td colspan="5" class="empty-table">暂无告警记录。</td></tr>
            <?php endif; ?>
            <?php foreach ($alerts as $alert): ?>
                <tr>
                    <td><span class="status-pill <?= $alert['level'] === 'danger' ? 'bad' : 'soft' ?>"><?= e($alert['level']) ?></span></td>
                    <td><?= e($alert['metric']) ?></td>
                    <td><?= e($alert['title']) ?></td>
                    <td><?= e($alert['content']) ?></td>
                    <td><?= e($alert['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
