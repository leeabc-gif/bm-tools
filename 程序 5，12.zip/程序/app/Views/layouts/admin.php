<?php
$currentUser = \App\Core\Auth::user();
$siteName = setting('site_name', 'BM TOOLS');
$adminPath = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/admin', PHP_URL_PATH);
$adminText = [
    'backend' => '&#21518;&#21488;',
    'operationBackend' => '&#36816;&#33829;&#21518;&#21488;',
    'operations' => '&#36816;&#33829;&#31649;&#29702;',
    'commerce' => '&#21830;&#19994;&#20132;&#26131;',
    'resources' => '&#36164;&#28304;&#20869;&#23481;',
    'audit' => '&#31995;&#32479;&#23457;&#35745;',
    'dashboard' => '&#25511;&#21046;&#21488;',
    'users' => '&#29992;&#25143;&#31649;&#29702;',
    'packages' => '&#22871;&#39184;&#31649;&#29702;',
    'coupons' => '&#33829;&#38144;&#27963;&#21160;',
    'orders' => '&#35746;&#21333;&#31649;&#29702;',
    'recharges' => '&#20805;&#20540;&#23457;&#26680;',
    'payments' => '&#25903;&#20184;&#37197;&#32622;',
    'balanceLogs' => '&#20313;&#39069;&#27969;&#27700;',
    'storages' => '&#23384;&#20648;&#31649;&#29702;',
    'files' => '&#25991;&#20214;&#31649;&#29702;',
    'monitors' => '&#30417;&#25511;&#31649;&#29702;',
    'announcements' => '&#20844;&#21578;&#31649;&#29702;',
    'apiLogs' => 'API &#26085;&#24535;',
    'settings' => '&#31995;&#32479;&#35774;&#32622;',
    'adminLogs' => '&#31649;&#29702;&#21592;&#26085;&#24535;',
    'menu' => '&#33756;&#21333;',
    'current' => '&#24403;&#21069;&#20301;&#32622;',
    'theme' => '&#20999;&#25442;&#20027;&#39064;',
    'frontend' => '&#21069;&#21488;',
    'logout' => '&#36864;&#20986;',
    'copyright' => '&#29256;&#26435;&#25152;&#26377; · &#20316;&#32773;&#65306;&#38463;&#35328;&#35201;&#21162;&#21147;',
    'search' => '&#25628;&#32034;',
    'favorite' => '&#25910;&#34255;',
    'record' => '&#35760;&#24405;',
    'log' => '&#26085;&#24535;',
];

function admin_count_badge($sql)
{
    try {
        $row = \App\Core\Database::fetch($sql);
        return $row ? (int) $row['c'] : 0;
    } catch (\Exception $e) {
        return 0;
    }
}

$adminBadges = [
    '/admin/orders' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('orders') . " WHERE status = 'pending'"),
    '/admin/recharges' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('recharges') . " WHERE status = 'pending'"),
    '/admin/monitors' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('monitor_servers') . " WHERE is_enabled = 1 AND status = 'offline'"),
    '/admin/api-logs' => admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('api_logs') . " WHERE DATE(created_at) = CURDATE()"),
];
$adminUnreadAlerts = admin_count_badge("SELECT COUNT(*) AS c FROM " . \App\Core\Database::table('monitor_alerts') . " WHERE status = 'unread'");
$adminBadges['/admin/monitors'] += $adminUnreadAlerts;

$adminMenus = [
    [
        'title' => $adminText['operations'],
        'icon' => 'layout-dashboard',
        'items' => [
            ['path' => '/admin', 'url' => 'admin', 'icon' => 'layout-dashboard', 'label' => $adminText['dashboard']],
            ['path' => '/admin/users', 'url' => 'admin/users', 'icon' => 'users', 'label' => $adminText['users']],
            ['path' => '/admin/packages', 'url' => 'admin/packages', 'icon' => 'package', 'label' => $adminText['packages']],
            ['path' => '/admin/coupons', 'url' => 'admin/coupons', 'icon' => 'badge-percent', 'label' => $adminText['coupons']],
        ],
    ],
    [
        'title' => $adminText['commerce'],
        'icon' => 'wallet-cards',
        'items' => [
            ['path' => '/admin/orders', 'url' => 'admin/orders', 'icon' => 'receipt-text', 'label' => $adminText['orders']],
            ['path' => '/admin/recharges', 'url' => 'admin/recharges', 'icon' => 'wallet-cards', 'label' => $adminText['recharges']],
            ['path' => '/admin/payments', 'url' => 'admin/payments', 'icon' => 'credit-card', 'label' => $adminText['payments']],
            ['path' => '/admin/balance-logs', 'url' => 'admin/balance-logs', 'icon' => 'coins', 'label' => $adminText['balanceLogs']],
        ],
    ],
    [
        'title' => $adminText['resources'],
        'icon' => 'folder-cog',
        'items' => [
            ['path' => '/admin/storages', 'url' => 'admin/storages', 'icon' => 'database', 'label' => $adminText['storages']],
            ['path' => '/admin/files', 'url' => 'admin/files', 'icon' => 'files', 'label' => $adminText['files']],
            ['path' => '/admin/monitors', 'url' => 'admin/monitors', 'icon' => 'activity', 'label' => $adminText['monitors']],
            ['path' => '/admin/announcements', 'url' => 'admin/announcements', 'icon' => 'megaphone', 'label' => $adminText['announcements']],
        ],
    ],
    [
        'title' => $adminText['audit'],
        'icon' => 'shield-check',
        'items' => [
            ['path' => '/admin/api-logs', 'url' => 'admin/api-logs', 'icon' => 'terminal', 'label' => $adminText['apiLogs']],
            ['path' => '/admin/maintenance', 'url' => 'admin/maintenance', 'icon' => 'wrench', 'label' => '&#31995;&#32479;&#32500;&#25252;'],
            ['path' => '/admin/settings', 'url' => 'admin/settings', 'icon' => 'settings', 'label' => $adminText['settings']],
            ['path' => '/admin/logs', 'url' => 'admin/logs', 'icon' => 'clipboard-list', 'label' => $adminText['adminLogs']],
        ],
    ],
];
$isActiveAdminPath = function ($path) use ($adminPath) {
    if ($path === '/admin') {
        return $adminPath === '/admin';
    }
    return strpos($adminPath, $path) === 0;
};
$activeGroup = $adminText['backend'];
$activeLabel = isset($title) ? e($title) : $adminText['dashboard'];
foreach ($adminMenus as $group) {
    foreach ($group['items'] as $item) {
        if ($isActiveAdminPath($item['path'])) {
            $activeGroup = $group['title'];
            $activeLabel = $item['label'];
            break 2;
        }
    }
}
$adminTodoItems = [
    ['label' => '&#24453;&#22788;&#29702;&#35746;&#21333;', 'value' => $adminBadges['/admin/orders'], 'url' => 'admin/orders', 'icon' => 'receipt-text'],
    ['label' => '&#24453;&#23457;&#26680;&#20805;&#20540;', 'value' => $adminBadges['/admin/recharges'], 'url' => 'admin/recharges', 'icon' => 'wallet-cards'],
    ['label' => '&#30417;&#25511;&#25552;&#37266;', 'value' => $adminBadges['/admin/monitors'], 'url' => 'admin/monitors', 'icon' => 'activity'],
];
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= isset($title) ? e($title) . ' - ' : '' ?><?= $adminText['backend'] ?></title>
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body data-theme="<?= e(setting('default_theme', 'auto')) ?>" class="console-body admin-body">
<div class="console-layout admin-layout">
    <aside class="console-sidebar admin-sidebar glass">
        <a class="console-brand" href="<?= url('admin') ?>">
            <span class="brand-mark"></span>
            <span><b><?= e($siteName) ?></b><small><?= $adminText['operationBackend'] ?></small></span>
        </a>
        <nav class="console-nav admin-nav admin-tree-nav">
            <?php foreach ($adminMenus as $groupIndex => $group): ?>
                <?php
                $groupOpen = false;
                foreach ($group['items'] as $item) {
                    if ($isActiveAdminPath($item['path'])) {
                        $groupOpen = true;
                        break;
                    }
                }
                ?>
                <section class="admin-menu-group <?= $groupOpen ? 'open' : '' ?>" data-menu-key="admin_menu_<?= e($groupIndex) ?>">
                    <button class="admin-menu-toggle" type="button" data-icon="<?= e($group['icon']) ?>">
                        <span><?= $group['title'] ?></span>
                        <i data-lucide="chevron-down"></i>
                    </button>
                    <div class="admin-submenu">
                        <?php foreach ($group['items'] as $item): ?>
                            <?php $badge = isset($adminBadges[$item['path']]) ? (int) $adminBadges[$item['path']] : 0; ?>
                            <a href="<?= url($item['url']) ?>" data-icon="<?= e($item['icon']) ?>" class="<?= $isActiveAdminPath($item['path']) ? 'active' : '' ?>">
                                <span><?= $item['label'] ?></span>
                                <?php if ($badge > 0): ?><em class="admin-menu-badge"><?= e($badge > 99 ? '99+' : $badge) ?></em><?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        </nav>
    </aside>
    <section class="console-workspace admin-main">
        <header class="console-topbar admin-top glass">
            <div class="admin-top-title">
                <button class="icon-btn mobile-menu-btn" type="button" title="<?= $adminText['menu'] ?>" data-icon="menu"></button>
                <div>
                    <nav class="admin-breadcrumb" aria-label="<?= $adminText['current'] ?>">
                        <span><?= $adminText['backend'] ?></span>
                        <i>/</i>
                        <span><?= $activeGroup ?></span>
                    </nav>
                    <strong><?= $activeLabel ?></strong>
                </div>
            </div>
            <div class="console-actions">
                <button class="theme-toggle icon-btn" type="button" title="<?= $adminText['theme'] ?>" aria-label="<?= $adminText['theme'] ?>" data-icon="sun-moon"></button>
                <a class="btn btn-ghost" href="<?= url('/') ?>" data-icon="home"><?= $adminText['frontend'] ?></a>
                <a class="btn btn-primary" href="<?= url('logout') ?>" data-icon="log-out"><?= $adminText['logout'] ?></a>
            </div>
        </header>
        <section class="admin-todo-strip glass">
            <?php foreach ($adminTodoItems as $todo): ?>
                <a href="<?= url($todo['url']) ?>" data-icon="<?= e($todo['icon']) ?>" class="<?= $todo['value'] > 0 ? 'has-work' : '' ?>">
                    <span><?= $todo['label'] ?></span>
                    <b><?= e($todo['value']) ?></b>
                </a>
            <?php endforeach; ?>
        </section>
        <main class="console-content">
            <?php if ($msg = flash('success')): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="alert error"><?= e($msg) ?></div><?php endif; ?>
            <?= $content ?>
            <footer class="admin-global-footer glass">
                <b>BM TOOLS</b>
                <span><?= $adminText['copyright'] ?></span>
            </footer>
        </main>
    </section>
    <aside class="admin-right-rail">
        <button type="button" title="<?= $adminText['search'] ?>" data-icon="search" data-admin-tool="search"></button>
        <button type="button" title="<?= $adminText['favorite'] ?>" data-icon="star" data-admin-tool="favorite"></button>
        <a href="<?= url('admin/logs') ?>" title="<?= $adminText['record'] ?>" data-icon="clock-3"></a>
        <a href="<?= url('admin/settings') ?>" title="<?= $adminText['settings'] ?>" data-icon="settings"></a>
        <a href="<?= url('admin/logs') ?>" title="<?= $adminText['log'] ?>" data-icon="clipboard-list"></a>
    </aside>
</div>
<script>
window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
window.SKY_DEFAULT_THEME = "<?= e(setting('default_theme', 'auto')) ?>";
</script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
