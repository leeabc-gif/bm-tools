<?php
$siteName = setting('site_name', 'BM TOOLS');
$currentUser = \App\Core\Auth::user();
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : '公告中心 - ' . $siteName) ?></title>
    <meta name="keywords" content="<?= e(setting('seo_keywords', '图床,网盘,对象存储,公告,帮助中心')) ?>">
    <meta name="description" content="<?= e(setting('seo_description', 'BM TOOLS 公告中心，提供平台公告、系统公告、帮助文档和平台教程。')) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="notice-body" data-theme="<?= e(setting('default_theme', 'auto')) ?>">
<header class="notice-topbar">
    <a class="notice-brand" href="<?= url('/') ?>">
        <span class="brand-mark"></span>
        <span><b><?= e($siteName) ?></b><small>公告与帮助中心</small></span>
    </a>
    <nav class="notice-nav">
        <a href="<?= url('/') ?>" data-icon="home">首页</a>
        <a href="<?= url('packages') ?>" data-icon="badge-dollar-sign">套餐</a>
        <a href="<?= url('status') ?>" data-icon="activity">状态</a>
        <?php if ($currentUser): ?>
            <a href="<?= url('dashboard') ?>" data-icon="layout-dashboard">个人中心</a>
        <?php else: ?>
            <a href="<?= url('login') ?>" data-icon="log-in">登录</a>
        <?php endif; ?>
        <button class="theme-toggle notice-icon-btn" type="button" data-icon="sun-moon" aria-label="切换主题"></button>
    </nav>
</header>

<main class="notice-page">
    <?= $content ?>
</main>

<footer class="notice-footer">
    <b>BM TOOLS</b>
    <span>平台公告、系统公告、帮助文档与教程中心</span>
</footer>

<script>
window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
window.SKY_DEFAULT_THEME = "<?= e(setting('default_theme', 'auto')) ?>";
</script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
