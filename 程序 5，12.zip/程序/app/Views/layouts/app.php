<?php
$currentUser = \App\Core\Auth::user();
$siteName = setting('site_name', 'BM TOOLS');
$isAdmin = $currentUser && $currentUser['role'] === 'admin';
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(isset($title) ? $title . ' - ' . $siteName : $siteName) ?></title>
    <meta name="keywords" content="<?= e(setting('seo_keywords', '图床,网盘,对象存储,服务器状态,宝塔监控')) ?>">
    <meta name="description" content="<?= e(setting('seo_description', '综合型图床、轻量网盘、套餐充值、多对象存储与运营方服务器状态展示平台。')) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.5.1/dist/echarts.min.js"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="console-body" data-theme="<?= e(setting('default_theme', 'light')) ?>">
<div class="console-layout">
    <aside class="console-sidebar glass">
        <a class="console-brand" href="<?= url('/') ?>">
            <span class="brand-mark"></span>
            <span><b><?= e($siteName) ?></b><small>Cloud Tools</small></span>
        </a>
        <nav class="console-nav">
            <p>平台服务</p>
            <a href="<?= url('/') ?>" data-icon="home">首页</a>
            <a href="<?= url('packages') ?>" data-icon="badge-dollar-sign">套餐价格</a>
            <a href="<?= url('announcements') ?>" data-icon="megaphone">公告通知</a>
            <a href="<?= url('status') ?>" data-icon="activity">服务器状态</a>
            <?php if ($currentUser): ?>
                <p>用户中心</p>
                <a href="<?= url('dashboard') ?>" data-icon="layout-dashboard">个人中心</a>
                <a href="<?= url('files') ?>" data-icon="image">图床服务</a>
                <a href="<?= url('netdisk') ?>" data-icon="hard-drive">个人网盘</a>
                <a href="<?= url('recharge') ?>" data-icon="wallet">账户充值</a>
                <a href="<?= url('orders') ?>" data-icon="receipt-text">订单记录</a>
                <a href="<?= url('api/console') ?>" data-icon="terminal">API 管理</a>
                <a href="<?= url('notifications') ?>" data-icon="bell">消息中心</a>
            <?php else: ?>
                <p>账户</p>
                <a href="<?= url('login') ?>" data-icon="log-in">登录</a>
                <a href="<?= url('register') ?>" data-icon="user-plus">注册</a>
            <?php endif; ?>
        </nav>
    </aside>

    <section class="console-workspace">
        <header class="console-topbar glass">
            <div>
                <button class="icon-btn mobile-menu-btn" type="button" title="菜单" data-icon="menu"></button>
                <strong><?= e(isset($title) ? $title : $siteName) ?></strong>
            </div>
            <div class="console-actions">
                <button class="theme-toggle icon-btn" type="button" title="切换主题" aria-label="切换主题" data-icon="sun-moon"></button>
                <?php if ($currentUser): ?>
                    <a class="btn btn-ghost" href="<?= url('profile') ?>" data-icon="user">资料</a>
                    <a class="btn btn-primary" href="<?= url('logout') ?>" data-icon="log-out">退出</a>
                <?php else: ?>
                    <a class="btn btn-ghost" href="<?= url('login') ?>" data-icon="log-in">登录</a>
                    <a class="btn btn-primary" href="<?= url('register') ?>" data-icon="user-plus">注册</a>
                <?php endif; ?>
            </div>
        </header>

        <main class="console-content">
            <?php if ($msg = flash('success')): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
            <?php if ($msg = flash('error')): ?><div class="alert error"><?= e($msg) ?></div><?php endif; ?>
            <?= $content ?>
        </main>
    </section>
</div>

<button class="back-top" type="button" data-icon="arrow-up"></button>
<script>
window.SKY_BASE_URL = "<?= e(rtrim(url('/'), '/')) ?>";
window.SKY_DEFAULT_THEME = "<?= e(setting('default_theme', 'light')) ?>";
</script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
