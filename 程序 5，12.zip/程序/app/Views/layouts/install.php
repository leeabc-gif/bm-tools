<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(isset($title) ? $title : '安装向导') ?></title>
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
</head>
<body class="install-body install-light page-ready" data-theme="light">
<main class="install-shell">
    <?= $content ?>
</main>
<script>
(function () {
    document.body.setAttribute('data-theme', 'light');
    document.body.setAttribute('data-theme-mode', 'light');
    document.querySelectorAll('[data-icon]').forEach(function (el) {
        if (el.querySelector('.btn-icon')) return;
        var icon = el.getAttribute('data-icon');
        if (!icon) return;
        var span = document.createElement('span');
        span.className = 'btn-icon';
        span.setAttribute('data-lucide', icon);
        el.insertBefore(span, el.firstChild);
    });
    if (window.lucide) {
        window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
    }
})();
</script>
</body>
</html>
