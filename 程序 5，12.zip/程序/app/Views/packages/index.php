<section class="section-heading reveal">
    <p class="eyebrow">套餐订阅</p>
    <h1>选择适合你的套餐</h1>
    <p>套餐会影响图床、个人网盘、API 上传、分享能力、容量、流量和单文件大小。服务器状态监控由平台运营方统一展示。</p>
</section>

<?php if (!empty($coupons)): ?>
    <section class="coupon-strip glass reveal">
        <div>
            <b>当前可用活动</b>
            <span>购买套餐时输入优惠码即可抵扣，实际可用规则以提交订单时校验为准。</span>
        </div>
        <div class="coupon-chip-list">
            <?php foreach ($coupons as $coupon): ?>
                <span class="coupon-chip">
                    <strong><?= e($coupon['code']) ?></strong>
                    <?= $coupon['discount_type'] === 'percent' ? e($coupon['discount_value']) . '% 折扣' : '立减 ¥' . e($coupon['discount_value']) ?>
                </span>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<div class="pricing-grid reveal">
    <?php foreach ($packages as $package): ?>
        <?php
        $displayPrice = (float) $package['price'];
        if (\App\Core\Auth::check()) {
            $u = \App\Core\Auth::user();
            if (!empty($u['package_id']) && (int) $u['package_id'] !== (int) $package['id'] && !empty($u['package_expire_time']) && strtotime($u['package_expire_time']) > time()) {
                $old = \App\Core\Database::fetch('SELECT * FROM ' . \App\Core\Database::table('packages') . ' WHERE id = ? LIMIT 1', [$u['package_id']]);
                if ($old && (float) $old['price'] > 0) {
                    $remainingDays = max(0, (strtotime($u['package_expire_time']) - time()) / 86400);
                    $credit = ((float) $old['price']) * min(1, $remainingDays / max(1, (int) $old['duration_days']));
                    $displayPrice = round(max(0, (float) $package['price'] - $credit), 2);
                }
            }
        }
        ?>
        <article class="price-card glass">
            <h3><?= e($package['name']) ?></h3>
            <div class="price">¥<?= e(number_format($displayPrice, 2)) ?></div>
            <?php if ($displayPrice != (float) $package['price']): ?>
                <small>已按当前套餐剩余价值抵扣，原价 ¥<?= e($package['price']) ?></small>
            <?php endif; ?>
            <p><?= e($package['description']) ?></p>
            <ul class="clean-list">
                <li>时长：<?= e($package['duration_type'] === 'forever' ? '永久' : $package['duration_days'] . ' 天') ?></li>
                <li>空间：<?= e(format_bytes($package['storage_limit'])) ?></li>
                <li>月流量：<?= e(format_bytes($package['traffic_limit'])) ?></li>
                <li>单文件：<?= e(format_bytes($package['single_file_limit'])) ?></li>
                <li><?= $package['allow_image'] ? '支持图床服务' : '不支持图床服务' ?></li>
                <li><?= $package['allow_netdisk'] ? '支持个人网盘' : '不支持个人网盘' ?></li>
                <li><?= $package['allow_api'] ? '支持 API 上传' : '不支持 API 上传' ?></li>
                <li><?= $package['allow_share'] ? '支持文件分享' : '不支持文件分享' ?></li>
            </ul>
            <?php if (\App\Core\Auth::check()): ?>
                <form method="post" action="<?= url('packages/buy') ?>" class="package-buy-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="package_id" value="<?= e($package['id']) ?>">
                    <label>优惠码（可选）
                        <input name="coupon_code" placeholder="有活动码时填写，例如 NEW2026">
                    </label>
                    <button class="btn btn-primary full" type="submit" data-icon="shopping-cart">余额购买</button>
                </form>
            <?php else: ?>
                <a class="btn btn-primary full" href="<?= url('login') ?>" data-icon="log-in">登录后购买</a>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>
</div>
