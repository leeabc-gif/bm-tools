<section class="table-card glass">
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>用户</th><th>类型</th><th>金额</th><th>变动前</th><th>变动后</th><th>关联</th><th>备注</th><th>时间</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= e($log['id']) ?></td>
                    <td><?= e($log['username']) ?></td>
                    <td><?= e($log['type']) ?></td>
                    <td><?= e($log['amount']) ?></td>
                    <td><?= e($log['balance_before']) ?></td>
                    <td><?= e($log['balance_after']) ?></td>
                    <td><?= e($log['related_type']) ?> #<?= e($log['related_id']) ?></td>
                    <td><?= e($log['remark']) ?></td>
                    <td><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

