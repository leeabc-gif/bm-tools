<?php
$homeTemplate = isset($settings['home_template']) ? $settings['home_template'] : 'default';
if ($homeTemplate === 'business') {
    $homeTemplate = 'nebula';
}
$templateOptions = [
    'default' => '玻璃上传风',
    'nebula' => '星云科技风',
    'minimal' => '极简留白风',
    'creator' => '创作者画廊风',
    'aurora' => '极光卡片风',
    'console' => '开发者终端风',
];
?>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">站点设置</p>
        <h2>系统设置</h2>
        <p>这里配置站点基础信息、首页展示风格、注册策略、API 限制和邮件服务。</p>
    </div>

    <form method="post" action="<?= url('admin/settings') ?>" class="form-grid two">
        <?= csrf_field() ?>

        <label>网站名称
            <input name="site_name" value="<?= e(isset($settings['site_name']) ? $settings['site_name'] : '') ?>">
        </label>
        <label>Logo URL
            <input name="site_logo" value="<?= e(isset($settings['site_logo']) ? $settings['site_logo'] : '') ?>">
        </label>
        <label>SEO 关键词
            <input name="seo_keywords" value="<?= e(isset($settings['seo_keywords']) ? $settings['seo_keywords'] : '') ?>">
        </label>
        <label>SEO 描述
            <input name="seo_description" value="<?= e(isset($settings['seo_description']) ? $settings['seo_description'] : '') ?>">
        </label>

        <label>注册开关
            <select name="register_enabled">
                <option value="1" <?= (isset($settings['register_enabled']) ? $settings['register_enabled'] : '1') === '1' ? 'selected' : '' ?>>开启</option>
                <option value="0" <?= (isset($settings['register_enabled']) ? $settings['register_enabled'] : '1') === '0' ? 'selected' : '' ?>>关闭</option>
            </select>
        </label>
        <label>注册邮箱验证码
            <select name="register_email_code_enabled">
                <option value="0" <?= (isset($settings['register_email_code_enabled']) ? $settings['register_email_code_enabled'] : '0') === '0' ? 'selected' : '' ?>>关闭</option>
                <option value="1" <?= (isset($settings['register_email_code_enabled']) ? $settings['register_email_code_enabled'] : '0') === '1' ? 'selected' : '' ?>>开启</option>
            </select>
        </label>

        <label>默认主题
            <select name="default_theme">
                <?php $defaultTheme = isset($settings['default_theme']) ? $settings['default_theme'] : 'auto'; ?>
                <option value="auto" <?= $defaultTheme === 'auto' ? 'selected' : '' ?>>自动跟随昼夜</option>
                <option value="light" <?= $defaultTheme === 'light' ? 'selected' : '' ?>>浅色</option>
                <option value="dark" <?= (isset($settings['default_theme']) ? $settings['default_theme'] : '') === 'dark' ? 'selected' : '' ?>>深色</option>
            </select>
        </label>
        <label>首页模板风格
            <select name="home_template">
                <?php foreach ($templateOptions as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= $homeTemplate === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>文件命名策略
            <select name="file_naming_strategy">
                <?php $strategy = isset($settings['file_naming_strategy']) ? $settings['file_naming_strategy'] : 'random'; ?>
                <option value="random" <?= $strategy === 'random' ? 'selected' : '' ?>>随机字符串</option>
                <option value="timestamp" <?= $strategy === 'timestamp' ? 'selected' : '' ?>>时间戳</option>
                <option value="hash" <?= $strategy === 'hash' ? 'selected' : '' ?>>文件 Hash</option>
                <option value="original" <?= $strategy === 'original' ? 'selected' : '' ?>>原始文件名</option>
            </select>
        </label>
        <label>默认免费套餐
            <select name="default_free_package_id">
                <?php foreach ($packages as $p): ?>
                    <option value="<?= e($p['id']) ?>" <?= (isset($settings['default_free_package_id']) && (int) $settings['default_free_package_id'] === (int) $p['id']) ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>API 每分钟限制
            <input name="api_rate_limit_per_minute" value="<?= e(isset($settings['api_rate_limit_per_minute']) ? $settings['api_rate_limit_per_minute'] : '60') ?>">
        </label>
        <label>API 每日限制
            <input name="api_rate_limit_per_day" value="<?= e(isset($settings['api_rate_limit_per_day']) ? $settings['api_rate_limit_per_day'] : '1000') ?>">
        </label>

        <label>邮件 Host
            <input name="email_host" value="<?= e(isset($settings['email_host']) ? $settings['email_host'] : '') ?>">
        </label>
        <label>邮件端口
            <input name="email_port" value="<?= e(isset($settings['email_port']) ? $settings['email_port'] : '465') ?>">
        </label>
        <label>邮件账号
            <input name="email_username" value="<?= e(isset($settings['email_username']) ? $settings['email_username'] : '') ?>">
        </label>
        <label>邮件密码
            <input name="email_password" value="<?= e(isset($settings['email_password']) ? $settings['email_password'] : '') ?>">
        </label>
        <label>发件邮箱
            <input name="email_from" value="<?= e(isset($settings['email_from']) ? $settings['email_from'] : '') ?>">
        </label>

        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存设置</button>
            <a class="btn btn-ghost" href="<?= url('/') ?>" target="_blank" data-icon="external-link">预览首页</a>
        </div>
    </form>
</section>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">邮件测试</p>
        <h2>邮件测试</h2>
    </div>
    <form method="post" action="<?= url('admin/email/test') ?>" class="url-fetch">
        <?= csrf_field() ?>
        <input type="email" name="email" placeholder="接收测试邮件的邮箱" required>
        <button class="btn btn-ghost" type="submit" data-icon="send">发送测试邮件</button>
    </form>
</section>
