<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">操作审计</p>
        <h1>管理员日志</h1>
        <p>记录后台管理员的重要操作，便于商业运营排查误操作、补单、删除和配置变更。</p>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <h2>日志列表</h2>
            <p>展示最近 <?= e(count($logs)) ?> 条后台操作记录。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>ID</th><th>管理员</th><th>动作</th><th>对象</th><th>IP 地址</th><th>时间</th></tr>
            </thead>
            <tbody>
            <?php if (!$logs): ?>
                <tr><td colspan="6" class="empty-table">暂无管理员操作日志。</td></tr>
            <?php endif; ?>
            <?php foreach ($logs as $l): ?>
                <tr>
                    <td><?= e($l['id']) ?></td>
                    <td><b><?= e($l['username'] ?: '-') ?></b></td>
                    <td><?= e($l['action']) ?></td>
                    <td><span class="status-pill soft"><?= e($l['target_type']) ?> #<?= e($l['target_id']) ?></span></td>
                    <td><?= e($l['ip']) ?></td>
                    <td><?= e($l['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
