<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">用户运营</p>
        <h1>用户管理</h1>
        <p>搜索用户、调整余额、修改套餐、启用或禁用账号。重置密码属于敏感操作，请确认用户身份后再执行。</p>
    </div>
</section>

<section class="table-card glass admin-users-card">
    <div class="section-head">
        <div>
            <h2>用户列表</h2>
            <p>当前展示 <?= e(count($users)) ?> 个用户。</p>
        </div>
        <form class="admin-search-form" method="get" action="<?= url('admin/users') ?>">
            <input name="keyword" value="<?= e(isset($_GET['keyword']) ? $_GET['keyword'] : '') ?>" placeholder="搜索用户名或邮箱">
            <button class="btn btn-ghost" data-icon="search">搜索</button>
        </form>
    </div>

    <div class="table-wrap">
        <table class="admin-users-table">
            <thead>
            <tr><th>ID</th><th>用户</th><th>邮箱</th><th>角色</th><th>余额</th><th>套餐</th><th>状态</th><th>重置密码</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$users): ?>
                <tr><td colspan="9" class="empty-table">没有找到用户。</td></tr>
            <?php endif; ?>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= e($u['id']) ?></td>
                    <td class="user-cell"><b><?= e($u['username']) ?></b><small><?= e($u['nickname'] ?: '未设置昵称') ?></small></td>
                    <td><?= e($u['email']) ?></td>
                    <td><span class="status-pill <?= $u['role'] === 'admin' ? 'soft' : 'muted' ?>"><?= e($u['role'] === 'admin' ? '管理员' : '普通用户') ?></span></td>
                    <td>
                        <input form="user-form-<?= e($u['id']) ?>" type="hidden" name="id" value="<?= e($u['id']) ?>">
                        <input form="user-form-<?= e($u['id']) ?>" type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                        <input form="user-form-<?= e($u['id']) ?>" name="balance" value="<?= e($u['balance']) ?>" class="admin-mini-input" aria-label="余额">
                    </td>
                    <td>
                        <select form="user-form-<?= e($u['id']) ?>" name="package_id" class="admin-mini-select" aria-label="套餐">
                            <?php foreach ($packages as $p): ?>
                                <option value="<?= e($p['id']) ?>" <?= (int) $u['package_id'] === (int) $p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select form="user-form-<?= e($u['id']) ?>" name="status" class="admin-mini-select" aria-label="状态">
                            <option value="1" <?= $u['status'] ? 'selected' : '' ?>>启用</option>
                            <option value="0" <?= !$u['status'] ? 'selected' : '' ?>>禁用</option>
                        </select>
                    </td>
                    <td><input form="user-form-<?= e($u['id']) ?>" name="password" placeholder="留空不修改" class="admin-mini-input" aria-label="新密码"></td>
                    <td>
                        <form method="post" action="<?= url('admin/users/update') ?>" id="user-form-<?= e($u['id']) ?>"></form>
                        <button form="user-form-<?= e($u['id']) ?>" class="btn btn-primary btn-sm" data-icon="save">保存</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
