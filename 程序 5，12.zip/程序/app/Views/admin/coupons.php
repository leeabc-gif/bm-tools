<?php
$edit = isset($editCoupon) && $editCoupon ? $editCoupon : null;
$selectedPackages = $edit && !empty($edit['package_ids']) ? array_map('intval', explode(',', $edit['package_ids'])) : [];
$recentRedemptions = isset($recentRedemptions) ? $recentRedemptions : [];
?>
<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">增长运营</p>
        <h1>营销活动</h1>
        <p>创建优惠码、首购活动和限时促销，用于提升套餐转化率。所有使用记录会自动留痕，方便复盘和对账。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/packages') ?>" data-icon="package">返回套餐</a>
</section>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>活动总数</span><b><?= e($couponStats['total']) ?></b><small>含停用活动</small></article>
    <article class="ops-metric-card glass ok"><span>启用中</span><b><?= e($couponStats['enabled']) ?></b><small>用户可使用</small></article>
    <article class="ops-metric-card glass"><span>使用次数</span><b><?= e($couponStats['used']) ?></b><small>累计核销</small></article>
    <article class="ops-metric-card glass"><span>累计让利</span><b>¥<?= e(number_format((float) $couponStats['discount'], 2)) ?></b><small>营销成本</small></article>
</section>

<section class="marketing-admin-grid">
    <article class="form-section glass">
        <h2><?= $edit ? '编辑活动 #' . e($edit['id']) : '创建优惠活动' ?></h2>
        <form method="post" action="<?= url('admin/coupons/save') ?>" class="form-grid two">
            <?= csrf_field() ?>
            <?php if ($edit): ?><input type="hidden" name="id" value="<?= e($edit['id']) ?>"><?php endif; ?>
            <label>活动名称<input name="title" value="<?= e($edit ? $edit['title'] : '') ?>" required placeholder="例如：新用户首购立减"></label>
            <label>优惠码<input name="code" value="<?= e($edit ? $edit['code'] : '') ?>" required placeholder="例如：NEW2026"></label>
            <label>优惠类型<select name="discount_type">
                <option value="fixed" <?= !$edit || $edit['discount_type'] === 'fixed' ? 'selected' : '' ?>>固定金额抵扣</option>
                <option value="percent" <?= $edit && $edit['discount_type'] === 'percent' ? 'selected' : '' ?>>按比例折扣</option>
            </select></label>
            <label>优惠力度<input name="discount_value" type="number" step="0.01" value="<?= e($edit ? $edit['discount_value'] : '5.00') ?>" placeholder="固定抵扣填金额，比例折扣填 1-100"></label>
            <label>最低订单金额<input name="min_amount" type="number" step="0.01" value="<?= e($edit ? $edit['min_amount'] : '0.00') ?>"></label>
            <label>适用范围<select name="package_scope">
                <option value="all" <?= !$edit || $edit['package_scope'] === 'all' ? 'selected' : '' ?>>全部套餐</option>
                <option value="include" <?= $edit && $edit['package_scope'] === 'include' ? 'selected' : '' ?>>仅指定套餐</option>
                <option value="exclude" <?= $edit && $edit['package_scope'] === 'exclude' ? 'selected' : '' ?>>排除指定套餐</option>
            </select></label>
            <label class="span-all">指定套餐
                <select name="package_ids[]" multiple size="4">
                    <?php foreach ($packages as $package): ?>
                        <option value="<?= e($package['id']) ?>" <?= in_array((int) $package['id'], $selectedPackages, true) ? 'selected' : '' ?>><?= e($package['name']) ?> · ¥<?= e($package['price']) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>适用范围选择“全部套餐”时可不选。按住 Ctrl 可多选。</small>
            </label>
            <label>开始时间<input name="start_at" type="datetime-local" value="<?= e($edit && $edit['start_at'] ? str_replace(' ', 'T', substr($edit['start_at'], 0, 16)) : '') ?>"></label>
            <label>结束时间<input name="end_at" type="datetime-local" value="<?= e($edit && $edit['end_at'] ? str_replace(' ', 'T', substr($edit['end_at'], 0, 16)) : '') ?>"></label>
            <label>总使用次数<input name="total_limit" type="number" value="<?= e($edit ? $edit['total_limit'] : '0') ?>"><small>填 0 表示不限总次数。</small></label>
            <label>每人可用次数<input name="user_limit" type="number" value="<?= e($edit ? $edit['user_limit'] : '1') ?>"></label>
            <label>状态<select name="status">
                <option value="1" <?= !$edit || $edit['status'] ? 'selected' : '' ?>>启用</option>
                <option value="0" <?= $edit && !$edit['status'] ? 'selected' : '' ?>>停用</option>
            </select></label>
            <label>排序<input name="sort_order" type="number" value="<?= e($edit ? $edit['sort_order'] : '0') ?>"></label>
            <label class="inline-check span-all"><input type="checkbox" name="first_order_only" <?= $edit && $edit['first_order_only'] ? 'checked' : '' ?>> 仅限首次购买套餐使用</label>
            <label class="span-all">活动说明<textarea name="description" placeholder="写给运营人员看的活动规则，例如适合投放渠道、活动成本、注意事项"><?= e($edit ? $edit['description'] : '') ?></textarea></label>
            <button class="btn btn-primary" data-icon="save">保存活动</button>
            <?php if ($edit): ?><a class="btn btn-ghost" href="<?= url('admin/coupons') ?>" data-icon="plus">新增活动</a><?php endif; ?>
        </form>
    </article>

    <aside class="table-card glass marketing-guide">
        <h2>运营建议</h2>
        <p>正式投放前，建议先用一个测试账号完成“充值、输入优惠码、购买套餐、核对订单金额”全流程。</p>
        <div>
            <span><b>首购转化</b><small>设置首购专用优惠码，例如 NEW2026，降低首次付费门槛。</small></span>
            <span><b>限时促销</b><small>配合公告、首页 Banner 或社群投放，设置明确结束时间。</small></span>
            <span><b>成本控制</b><small>用总次数和最低金额控制营销预算，避免过度让利。</small></span>
        </div>
    </aside>
</section>

<section class="table-card glass marketing-redemption-card">
    <div class="section-head">
        <div>
            <p class="eyebrow">核销记录</p>
            <h2>最近优惠码使用</h2>
        </div>
        <span class="storage-test-hint">用于活动复盘、让利核对和异常排查。</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>时间</th><th>用户</th><th>活动</th><th>套餐</th><th>订单</th><th>抵扣</th><th>实付</th></tr></thead>
            <tbody>
            <?php foreach ($recentRedemptions as $row): ?>
                <tr>
                    <td><?= e($row['used_at']) ?></td>
                    <td><?= e($row['username'] ?: '-') ?></td>
                    <td><b><?= e($row['coupon_code'] ?: '-') ?></b><br><small><?= e($row['coupon_title'] ?: '') ?></small></td>
                    <td><?= e($row['package_name'] ?: '-') ?></td>
                    <td><?= e($row['order_no'] ?: '-') ?></td>
                    <td>¥<?= e(number_format((float) $row['discount_amount'], 2)) ?></td>
                    <td>¥<?= e(number_format((float) $row['final_amount'], 2)) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($recentRedemptions)): ?>
                <tr><td colspan="7">暂无核销记录。可以使用测试账号购买套餐并输入优惠码验证完整链路。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="table-card glass">
    <h2>活动列表</h2>
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>活动</th><th>优惠码</th><th>规则</th><th>限制</th><th>时间</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
            <?php foreach ($coupons as $coupon): ?>
                <tr>
                    <td><?= e($coupon['id']) ?></td>
                    <td><b><?= e($coupon['title']) ?></b><br><small><?= e($coupon['description']) ?></small></td>
                    <td><code><?= e($coupon['code']) ?></code></td>
                    <td><?= $coupon['discount_type'] === 'percent' ? e($coupon['discount_value']) . '% 折扣' : '立减 ¥' . e($coupon['discount_value']) ?><br><small>满 ¥<?= e($coupon['min_amount']) ?> 可用</small></td>
                    <td>总 <?= (int) $coupon['total_limit'] === 0 ? '不限' : e($coupon['total_limit']) ?> / 每人 <?= e($coupon['user_limit']) ?><br><small><?= $coupon['first_order_only'] ? '仅首购' : '不限首购' ?></small></td>
                    <td><small><?= e($coupon['start_at'] ?: '立即') ?><br><?= e($coupon['end_at'] ?: '长期') ?></small></td>
                    <td><?= $coupon['status'] ? '启用' : '停用' ?></td>
                    <td>
                        <a class="btn btn-ghost" href="<?= url('admin/coupons?id=' . $coupon['id']) ?>" data-icon="pencil">编辑</a>
                        <form class="confirm-form" method="post" action="<?= url('admin/coupons/delete') ?>" data-confirm="确定删除或停用这个活动吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($coupon['id']) ?>">
                            <button class="btn btn-ghost" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($coupons)): ?>
                <tr><td colspan="8">还没有营销活动。可以先创建一个首购优惠码用于测试商业链路。</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
