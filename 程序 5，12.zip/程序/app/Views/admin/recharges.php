<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">充值审核</p>
        <h1>充值管理</h1>
        <p>处理人工充值申请，核对收款后通过审核，系统会自动给用户余额入账。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/payments') ?>" data-icon="credit-card">支付配置</a>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <h2>充值记录</h2>
            <p>待审核记录请先确认实际收款，再点击通过。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>ID</th><th>用户</th><th>订单号</th><th>金额</th><th>支付方式</th><th>状态</th><th>审核操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$recharges): ?>
                <tr><td colspan="7" class="empty-table">暂无充值记录。</td></tr>
            <?php endif; ?>
            <?php foreach ($recharges as $r): ?>
                <tr>
                    <td><?= e($r['id']) ?></td>
                    <td><b><?= e($r['username'] ?: '-') ?></b></td>
                    <td><?= e($r['order_no']) ?></td>
                    <td><b>¥<?= e($r['amount']) ?></b></td>
                    <td><?= e($r['payment_method']) ?></td>
                    <td><span class="status-pill <?= $r['status'] === 'paid' || $r['status'] === 'approved' ? 'ok' : ($r['status'] === 'pending' ? 'soft' : 'muted') ?>"><?= e($r['status']) ?></span></td>
                    <td>
                        <?php if ($r['status'] === 'pending'): ?>
                            <form method="post" action="<?= url('admin/recharges/audit') ?>" class="admin-row-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($r['id']) ?>">
                                <input name="remark" placeholder="审核备注，可留空">
                                <button class="btn btn-primary" name="action" value="approve" data-icon="check">通过</button>
                                <button class="btn btn-ghost danger" name="action" value="reject" data-icon="x">拒绝</button>
                            </form>
                        <?php else: ?>
                            <span class="muted-text">已处理</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
