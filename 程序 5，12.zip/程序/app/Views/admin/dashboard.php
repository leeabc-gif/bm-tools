<?php
$statCards = [
    ['key' => 'users', 'label' => '用户总数', 'icon' => 'users'],
    ['key' => 'today_users', 'label' => '今日注册', 'icon' => 'user-plus'],
    ['key' => 'files', 'label' => '文件总数', 'icon' => 'files'],
    ['key' => 'images', 'label' => '图片总数', 'icon' => 'image'],
    ['key' => 'netdisk_files', 'label' => '网盘文件', 'icon' => 'hard-drive'],
    ['key' => 'storage_used', 'label' => '存储占用', 'icon' => 'database'],
    ['key' => 'today_orders', 'label' => '今日订单', 'icon' => 'receipt-text'],
    ['key' => 'today_recharge', 'label' => '今日充值', 'icon' => 'wallet-cards'],
    ['key' => 'online_servers', 'label' => '在线服务器', 'icon' => 'activity'],
    ['key' => 'abnormal_servers', 'label' => '异常服务器', 'icon' => 'alert-triangle'],
];
$trendMax = 0;
foreach ($revenueTrend as $row) {
    $trendMax = max($trendMax, (float) $row['orders_total'], (float) $row['recharge_total']);
}
$trendMax = $trendMax > 0 ? $trendMax : 1;
?>

<section class="admin-dashboard-hero glass">
    <div class="admin-dashboard-hero__copy">
        <p class="eyebrow">运营控制台</p>
        <h1>BM TOOLS 商业运营中枢</h1>
        <p>这里汇总用户、订单、充值、存储和本机环境状态，帮助你快速判断今天该处理什么、哪里需要关注。</p>
    </div>
    <div class="admin-dashboard-hero__actions">
        <a class="btn btn-primary" href="<?= url('admin/orders') ?>" data-icon="receipt-text">查看订单</a>
        <a class="btn btn-ghost" href="<?= url('admin/recharges') ?>" data-icon="wallet-cards">充值审核</a>
        <a class="btn btn-ghost" href="<?= url('admin/settings') ?>" data-icon="settings">系统设置</a>
    </div>
</section>

<section class="admin-dashboard-grid">
    <?php foreach ($statCards as $card): ?>
        <article class="admin-dashboard-card glass">
            <div class="admin-dashboard-card__icon"><i data-lucide="<?= e($card['icon']) ?>"></i></div>
            <span><?= e($card['label']) ?></span>
            <b><?= e($card['key'] === 'storage_used' ? format_bytes($stats[$card['key']]) : $stats[$card['key']]) ?></b>
        </article>
    <?php endforeach; ?>
</section>

<section class="admin-dashboard-layout">
    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">七日趋势</p>
            <h2>收入与订单走势</h2>
        </div>
        <div class="admin-trend-bars">
            <?php foreach ($revenueTrend as $row): ?>
                <div class="admin-trend-bar">
                    <div class="admin-trend-bar__head">
                        <strong><?= e($row['day']) ?></strong>
                        <span>订单 <?= e($row['orders_count']) ?> / 充值 <?= e($row['recharge_count']) ?></span>
                    </div>
                    <div class="admin-trend-bar__row">
                        <label>订单收入</label>
                        <div class="admin-trend-bar__track">
                            <i style="width: <?= round(((float) $row['orders_total'] / $trendMax) * 100, 2) ?>%"></i>
                        </div>
                        <b>¥<?= number_format((float) $row['orders_total'], 2) ?></b>
                    </div>
                    <div class="admin-trend-bar__row">
                        <label>充值收入</label>
                        <div class="admin-trend-bar__track alt">
                            <i style="width: <?= round(((float) $row['recharge_total'] / $trendMax) * 100, 2) ?>%"></i>
                        </div>
                        <b>¥<?= number_format((float) $row['recharge_total'], 2) ?></b>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <aside class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">今日待办</p>
            <h2>运营提醒</h2>
        </div>
        <div class="admin-todo-list">
            <div><span>待审核充值</span><b><?= e($opsTodos['pending_recharge']) ?></b></div>
            <div><span>待处理订单</span><b><?= e($opsTodos['pending_orders']) ?></b></div>
            <div><span>离线服务器</span><b><?= e($opsTodos['offline_servers']) ?></b></div>
            <div><span>默认存储</span><b><?= $opsTodos['default_storage'] > 0 ? '已配置' : '未配置' ?></b></div>
        </div>
        <div class="admin-todo-actions">
            <a class="btn btn-ghost" href="<?= url('admin/storages') ?>" data-icon="database">存储管理</a>
            <a class="btn btn-ghost" href="<?= url('admin/monitors') ?>" data-icon="activity">监控管理</a>
        </div>
    </aside>
</section>

<section class="admin-dashboard-layout">
    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">最近订单</p>
            <h2>最新业务流转</h2>
        </div>
        <div class="admin-mini-table">
            <div class="admin-mini-table__head">
                <span>订单号</span><span>用户</span><span>类型</span><span>套餐</span><span>金额</span><span>状态</span>
            </div>
            <?php foreach ($recentOrders as $order): ?>
                <div class="admin-mini-table__row">
                    <span><?= e($order['order_no']) ?></span>
                    <span><?= e($order['nickname'] ?: $order['username'] ?: '-') ?></span>
                    <span><?= e($order['type'] === 'recharge' ? '充值' : '套餐') ?></span>
                    <span><?= e($order['package_name'] ?: '-') ?></span>
                    <span>¥<?= number_format((float) $order['pay_amount'], 2) ?></span>
                    <span><?= e($order['status']) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </article>

    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">待审核充值</p>
            <h2>人工充值审核</h2>
        </div>
        <div class="admin-mini-table">
            <div class="admin-mini-table__head">
                <span>用户</span><span>金额</span><span>方式</span><span>时间</span>
            </div>
            <?php if ($pendingRecharges): ?>
                <?php foreach ($pendingRecharges as $recharge): ?>
                    <div class="admin-mini-table__row">
                        <span><?= e($recharge['username'] ?: '-') ?></span>
                        <span>¥<?= number_format((float) $recharge['amount'], 2) ?></span>
                        <span><?= e($recharge['payment_method']) ?></span>
                        <span><?= e($recharge['created_at']) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="admin-empty">当前没有待审核充值。</div>
            <?php endif; ?>
        </div>
        <div class="admin-todo-actions">
            <a class="btn btn-primary" href="<?= url('admin/recharges') ?>" data-icon="check-circle-2">进入审核</a>
        </div>
    </article>
</section>

<section class="admin-dashboard-layout">
    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">本机环境</p>
            <h2>服务器与运行信息</h2>
        </div>
        <div class="admin-env-grid">
            <div class="admin-env-item"><span>操作系统</span><b><?= e($serverInfo['os']) ?></b></div>
            <div class="admin-env-item"><span>运行软件</span><b><?= e($serverInfo['server_software']) ?></b></div>
            <div class="admin-env-item"><span>PHP 版本</span><b><?= e($serverInfo['php_version']) ?></b></div>
            <div class="admin-env-item"><span>数据库版本</span><b><?= e($serverInfo['database_version']) ?></b></div>
            <div class="admin-env-item"><span>内存限制</span><b><?= e($serverInfo['memory_limit']) ?></b></div>
            <div class="admin-env-item"><span>上传限制</span><b><?= e($serverInfo['upload_max_filesize']) ?></b></div>
            <div class="admin-env-item"><span>POST 限制</span><b><?= e($serverInfo['post_max_size']) ?></b></div>
            <div class="admin-env-item"><span>执行时间</span><b><?= e($serverInfo['max_execution_time']) ?></b></div>
            <div class="admin-env-item"><span>磁盘总量</span><b><?= e($serverInfo['disk_total']) ?></b></div>
            <div class="admin-env-item"><span>磁盘已用</span><b><?= e($serverInfo['disk_used']) ?></b></div>
            <div class="admin-env-item"><span>磁盘剩余</span><b><?= e($serverInfo['disk_free']) ?></b></div>
            <div class="admin-env-item"><span>当前时间</span><b><?= e($serverInfo['time']) ?></b></div>
        </div>
    </article>

    <article class="panel glass">
        <div class="section-heading compact">
            <p class="eyebrow">扩展检测</p>
            <h2>关键 PHP 扩展</h2>
        </div>
        <div class="extension-grid">
            <?php foreach ($serverInfo['extensions'] as $name => $loaded): ?>
                <span class="extension-pill <?= $loaded ? 'ok' : 'bad' ?>">
                    <?= e(strtoupper($name)) ?> <?= $loaded ? '已启用' : '未启用' ?>
                </span>
            <?php endforeach; ?>
        </div>
    </article>
</section>
