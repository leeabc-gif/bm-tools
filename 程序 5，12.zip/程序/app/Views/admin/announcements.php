<?php
$ea = isset($editAnnouncement) && $editAnnouncement ? $editAnnouncement : null;
$categories = isset($announcementCategories) ? $announcementCategories : \App\Models\Announcement::categories();
$currentCategory = $ea && !empty($ea['category']) ? $ea['category'] : 'platform';
?>

<section class="dashboard-hero glass reveal">
    <div>
        <p class="eyebrow">内容运营</p>
        <h1>公告与内容管理</h1>
        <p>发布平台公告、系统公告、帮助文档和平台教程。编辑器支持常用排版、标签、封面、摘要和预览，适合做成博客/微博式内容流。</p>
    </div>
    <div class="hero-actions">
        <a class="btn btn-ghost" href="<?= url('announcements') ?>" target="_blank" data-icon="external-link">预览内容中心</a>
        <a class="btn btn-primary" href="<?= url('admin/announcements') ?>" data-icon="plus">新建内容</a>
    </div>
</section>

<section class="content-admin-layout reveal">
    <article class="form-section glass content-editor-card">
        <div class="section-head">
            <div>
                <p class="eyebrow"><?= $ea ? '编辑内容' : '新建内容' ?></p>
                <h2><?= $ea ? '编辑内容 #' . e($ea['id']) : '发布新内容' ?></h2>
            </div>
            <?php if ($ea): ?><a class="btn btn-ghost" href="<?= url('admin/announcements') ?>" data-icon="x">取消编辑</a><?php endif; ?>
        </div>

        <form method="post" action="<?= url('admin/announcements/save') ?>" class="content-editor-form">
            <?= csrf_field() ?>
            <?php if ($ea): ?><input type="hidden" name="id" value="<?= e($ea['id']) ?>"><?php endif; ?>

            <div class="form-grid two">
                <label>内容分类
                    <select name="category">
                        <?php foreach ($categories as $key => $meta): ?>
                            <option value="<?= e($key) ?>" <?= $currentCategory === $key ? 'selected' : '' ?>><?= e($meta['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>发布时间
                    <input name="published_at" value="<?= e($ea ? $ea['published_at'] : date('Y-m-d H:i:s')) ?>" placeholder="YYYY-mm-dd HH:ii:ss">
                </label>
            </div>

            <label>标题
                <input name="title" value="<?= e($ea ? $ea['title'] : '') ?>" required placeholder="输入一个清晰、有信息量的标题">
            </label>

            <label>摘要
                <textarea name="summary" rows="3" maxlength="300" placeholder="用于列表页摘要，建议 60-120 字。"><?= e($ea ? (isset($ea['summary']) ? $ea['summary'] : '') : '') ?></textarea>
            </label>

            <div class="form-grid two">
                <label>封面图 URL
                    <input name="cover_image" value="<?= e($ea ? (isset($ea['cover_image']) ? $ea['cover_image'] : '') : '') ?>" placeholder="https://example.com/cover.jpg">
                </label>
                <label>标签
                    <input name="tags" value="<?= e($ea ? (isset($ea['tags']) ? $ea['tags'] : '') : '') ?>" placeholder="图床,网盘,教程">
                </label>
            </div>

            <div class="editor-toolbar">
                <button type="button" data-editor-insert="<h2>小标题</h2>" data-icon="heading-2">标题</button>
                <button type="button" data-editor-wrap="<strong>|</strong>" data-icon="bold">加粗</button>
                <button type="button" data-editor-wrap="<blockquote>|</blockquote>" data-icon="quote">引用</button>
                <button type="button" data-editor-insert="<ul><li>列表项</li></ul>" data-icon="list">列表</button>
                <button type="button" data-editor-wrap="<code>|</code>" data-icon="code">代码</button>
                <button type="button" data-editor-insert="<a href=&quot;https://&quot; target=&quot;_blank&quot;>链接文字</a>" data-icon="link">链接</button>
                <button type="button" data-editor-insert="<img src=&quot;https://&quot; alt=&quot;图片说明&quot;>" data-icon="image">图片</button>
                <button type="button" data-editor-preview data-icon="eye">预览</button>
            </div>

            <label>正文内容
                <textarea id="announcementEditor" name="content" rows="16" required placeholder="支持 HTML 排版，可插入标题、引用、列表、代码、图片等内容。"><?= e($ea ? $ea['content'] : '') ?></textarea>
            </label>

            <div class="editor-preview glass" id="announcementPreview" hidden></div>

            <div class="form-grid three">
                <label>内容格式
                    <select name="content_format">
                        <option value="html" <?= !$ea || (isset($ea['content_format']) ? $ea['content_format'] : 'html') === 'html' ? 'selected' : '' ?>>HTML / 富文本</option>
                        <option value="plain" <?= $ea && (isset($ea['content_format']) ? $ea['content_format'] : '') === 'plain' ? 'selected' : '' ?>>纯文本</option>
                    </select>
                </label>
                <label>状态
                    <select name="status">
                        <option value="1" <?= !$ea || $ea['status'] ? 'selected' : '' ?>>显示</option>
                        <option value="0" <?= $ea && !$ea['status'] ? 'selected' : '' ?>>隐藏</option>
                    </select>
                </label>
                <label class="inline-check storage-check"><input type="checkbox" name="is_top" <?= $ea && $ea['is_top'] ? 'checked' : '' ?>> 置顶</label>
                <label class="inline-check storage-check"><input type="checkbox" name="show_home" <?= !$ea || $ea['show_home'] ? 'checked' : '' ?>> 首页展示</label>
            </div>

            <button class="btn btn-primary" data-icon="save">保存内容</button>
        </form>
    </article>

    <aside class="glass content-editor-guide">
        <h2>编辑建议</h2>
        <p>平台公告偏运营通知，系统公告偏服务状态，平台帮助解决常见问题，平台教程适合写图床、网盘、API、对象存储接入流程。</p>
        <div>
            <?php foreach ($categories as $key => $meta): ?>
                <span><i data-lucide="<?= e($meta['icon']) ?>"></i><b><?= e($meta['name']) ?></b><small><?= e($meta['desc']) ?></small></span>
            <?php endforeach; ?>
        </div>
    </aside>
</section>

<section class="table-card glass reveal">
    <div class="section-head">
        <div>
            <p class="eyebrow">内容列表</p>
            <h2>内容列表</h2>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>标题</th><th>分类</th><th>置顶</th><th>首页</th><th>状态</th><th>阅读</th><th>发布时间</th><th>操作</th></tr></thead>
            <tbody>
            <?php foreach ($announcements as $a): ?>
                <?php $cat = isset($categories[$a['category']]) ? $categories[$a['category']]['name'] : '平台公告'; ?>
                <tr>
                    <td><?= e($a['id']) ?></td>
                    <td><b><?= e($a['title']) ?></b><small><?= e(isset($a['summary']) ? mb_substr($a['summary'], 0, 42) : '') ?></small></td>
                    <td><?= e($cat) ?></td>
                    <td><?= $a['is_top'] ? '是' : '否' ?></td>
                    <td><?= $a['show_home'] ? '是' : '否' ?></td>
                    <td><?= $a['status'] ? '显示' : '隐藏' ?></td>
                    <td><?= e(isset($a['view_count']) ? $a['view_count'] : 0) ?></td>
                    <td><?= e($a['published_at']) ?></td>
                    <td class="table-actions">
                        <a class="btn btn-ghost" href="<?= url('admin/announcements?id=' . $a['id']) ?>" data-icon="pencil">编辑</a>
                        <a class="btn btn-ghost" href="<?= url('announcements/' . $a['id']) ?>" target="_blank" data-icon="external-link">查看</a>
                        <form method="post" action="<?= url('admin/announcements/delete') ?>" class="confirm-form" data-confirm="确定删除这条内容吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($a['id']) ?>">
                            <button class="btn btn-ghost danger" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
