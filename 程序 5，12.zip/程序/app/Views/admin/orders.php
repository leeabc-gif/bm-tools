<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">订单运营</p>
        <h1>订单管理</h1>
        <p>查看套餐购买、余额充值和支付状态。手动补单仅用于已确认收款但系统未自动入账的充值订单。</p>
    </div>
    <a class="btn btn-ghost" href="<?= url('admin/orders/export') ?>" data-icon="download">导出订单</a>
</section>

<section class="form-section glass admin-compact-section">
    <div class="section-head">
        <div>
            <h2>手动补单</h2>
            <p>请输入待补单的充值订单号，确认收款后再操作。</p>
        </div>
    </div>
    <form method="post" action="<?= url('admin/orders/manual-paid') ?>" class="admin-inline-form">
        <?= csrf_field() ?>
        <input name="order_no" placeholder="输入充值订单号，例如 R202605110001" required>
        <button class="btn btn-primary" data-icon="badge-check">补单入账</button>
    </form>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <h2>订单列表</h2>
            <p>当前展示最近 <?= e(count($orders)) ?> 条订单记录。</p>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>订单号</th><th>用户</th><th>类型</th><th>套餐</th><th>金额</th><th>支付方式</th><th>状态</th><th>交易号</th><th>创建时间</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$orders): ?>
                <tr><td colspan="10" class="empty-table">暂无订单记录。</td></tr>
            <?php endif; ?>
            <?php foreach ($orders as $o): ?>
                <tr>
                    <td><b><?= e($o['order_no']) ?></b></td>
                    <td><?= e($o['username'] ?: '-') ?></td>
                    <td><span class="status-pill soft"><?= e($o['type'] === 'recharge' ? '充值' : '套餐') ?></span></td>
                    <td><?= e($o['package_name'] ?: '-') ?></td>
                    <td><b>¥<?= e($o['pay_amount']) ?></b></td>
                    <td><?= e($o['payment_method'] ?: '-') ?></td>
                    <td><span class="status-pill <?= $o['status'] === 'paid' ? 'ok' : ($o['status'] === 'pending' ? 'soft' : 'muted') ?>"><?= e($o['status']) ?></span></td>
                    <td><?= e($o['trade_no'] ?: '-') ?></td>
                    <td><?= e($o['created_at']) ?></td>
                    <td><a class="btn btn-ghost btn-sm" href="<?= url('admin/orders/' . $o['id']) ?>" data-icon="search">详情</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
