<section class="table-card glass">
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>用户</th><th>接口</th><th>方法</th><th>IP</th><th>状态码</th><th>结果</th><th>信息</th><th>时间</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= e($log['id']) ?></td>
                    <td><?= e($log['username'] ?: '-') ?></td>
                    <td><?= e($log['endpoint']) ?></td>
                    <td><?= e($log['method']) ?></td>
                    <td><?= e($log['ip']) ?></td>
                    <td><?= e($log['status_code']) ?></td>
                    <td><?= $log['is_success'] ? '成功' : '失败' ?></td>
                    <td><?= e($log['message']) ?></td>
                    <td><?= e($log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

