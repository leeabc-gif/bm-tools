<?php
$es = isset($editStorage) && $editStorage ? $editStorage : null;
$stats = isset($storageStats) ? $storageStats : ['total' => 0, 'enabled' => 0, 'cloud' => 0, 'default_name' => '未设置'];
$types = [
    'local' => ['name' => '本地测试存储', 'icon' => 'hard-drive', 'badge' => 'Local'],
    'oss' => ['name' => '阿里云 OSS', 'icon' => 'cloud', 'badge' => 'OSS'],
    'cos' => ['name' => '腾讯云 COS', 'icon' => 'cloud-sun', 'badge' => 'COS'],
    'kodo' => ['name' => '七牛云 Kodo', 'icon' => 'cloud-upload', 'badge' => 'Kodo'],
];
$guides = [
    'oss' => [
        'title' => '阿里云 OSS 怎么填写',
        'items' => [
            ['AccessKey / SecretKey', '在阿里云 RAM 访问控制里创建，建议只授权当前 Bucket 的上传和删除权限。'],
            ['Bucket', '填写空间名称，例如 bmtools-img，不要填写域名。'],
            ['Endpoint', '填写地域节点，例如 oss-cn-hangzhou.aliyuncs.com，不要写 bucket.oss-cn-hangzhou.aliyuncs.com。'],
            ['访问域名', '可填写绑定的 CDN 或自定义域名，例如 https://img.example.com；没有就先留空。'],
        ],
    ],
    'cos' => [
        'title' => '腾讯云 COS 怎么填写',
        'items' => [
            ['SecretId / SecretKey', '在腾讯云访问管理里获取，注意不是 AppID。'],
            ['Bucket', '填写完整 Bucket 名称，通常类似 bmtools-1250000000。'],
            ['Region', '填写地域，例如 ap-guangzhou、ap-shanghai；Endpoint 可以留空。'],
            ['访问域名', '如果有 CDN 或自定义域名就填写；没有时系统会使用 COS 默认访问地址。'],
        ],
    ],
    'kodo' => [
        'title' => '七牛云 Kodo 怎么填写',
        'items' => [
            ['AccessKey / SecretKey', '在七牛云密钥管理里获取。'],
            ['Bucket', '填写空间名称，不是域名。'],
            ['Endpoint / 上传域名', '一般可留空，默认使用 https://upload.qiniup.com；特殊区域再填写对应上传域名。'],
            ['访问域名', '必须填写空间绑定域名，例如 https://cdn.example.com，否则上传成功后无法生成可访问外链。'],
        ],
    ],
];
?>

<section class="admin-page-head glass">
    <div>
        <p class="eyebrow">对象存储</p>
        <h1>存储管理</h1>
        <p>统一管理本地测试、阿里云 OSS、腾讯云 COS、七牛云 Kodo。正式运营建议至少配置一个第三方对象存储并完成真实上传测试。</p>
    </div>
    <a class="btn btn-primary" href="#storage-form" data-icon="plus">添加存储源</a>
</section>

<section class="workspace-summary-grid reveal">
    <article class="workspace-summary-card glass"><span>存储源总数</span><b><?= e($stats['total']) ?></b><small>包含本地测试与第三方云存储</small></article>
    <article class="workspace-summary-card glass"><span>启用中</span><b><?= e($stats['enabled']) ?></b><small>上传服务只会使用启用的存储源</small></article>
    <article class="workspace-summary-card glass"><span>第三方云存储</span><b><?= e($stats['cloud']) ?></b><small>商业运营建议至少配置 1 个云存储</small></article>
    <article class="workspace-summary-card glass"><span>默认上传线路</span><b><?= e($stats['default_name']) ?></b><small>图床和网盘默认写入此线路</small></article>
</section>

<section class="storage-help-card glass reveal">
    <div>
        <p class="eyebrow">配置帮助</p>
        <h2>怎么填写才容易成功</h2>
        <p>点击下面的云厂商按钮查看填写说明，说明会以弹窗展示，不占用配置表单空间。</p>
    </div>
    <div class="storage-help-actions">
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="oss" data-icon="cloud">阿里云 OSS</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="cos" data-icon="cloud-sun">腾讯云 COS</button>
        <button type="button" class="btn btn-ghost storage-guide-open" data-guide="kodo" data-icon="cloud-upload">七牛云 Kodo</button>
    </div>
</section>

<section class="form-section glass reveal" id="storage-form">
    <div class="section-head">
        <div>
            <p class="eyebrow"><?= $es ? '编辑存储' : '新增存储' ?></p>
            <h2><?= $es ? '编辑存储源 #' . e($es['id']) : '添加存储源' ?></h2>
        </div>
        <?php if ($es): ?><a class="btn btn-ghost" href="<?= url('admin/storages') ?>" data-icon="x">取消编辑</a><?php endif; ?>
    </div>

    <form method="post" action="<?= url('admin/storages/save') ?>" class="form-grid three storage-config-form">
        <?= csrf_field() ?>
        <?php if ($es): ?><input type="hidden" name="id" value="<?= e($es['id']) ?>"><?php endif; ?>

        <label>存储名称
            <input name="name" value="<?= e($es ? $es['name'] : '') ?>" placeholder="例如：阿里云杭州主线路" required>
            <small class="field-help">只给后台识别使用，建议写清楚云厂商和地域。</small>
        </label>
        <label>存储类型
            <select name="type" id="storageType">
                <?php foreach ($types as $k => $v): ?>
                    <option value="<?= e($k) ?>" <?= $es && $es['type'] === $k ? 'selected' : '' ?>><?= e($v['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>状态
            <select name="is_enabled">
                <option value="1" <?= !$es || $es['is_enabled'] ? 'selected' : '' ?>>启用</option>
                <option value="0" <?= $es && !$es['is_enabled'] ? 'selected' : '' ?>>停用</option>
            </select>
        </label>

        <label class="storage-field cloud-field">AccessKey / SecretId
            <input name="access_key" value="<?= e($es ? $es['access_key'] : '') ?>" autocomplete="off" placeholder="阿里云/七牛填 AccessKey，腾讯云填 SecretId">
            <small class="field-help">从云厂商的密钥管理页面复制，不要填写账号密码。</small>
        </label>
        <label class="storage-field cloud-field">SecretKey
            <input name="secret_key" type="password" value="" autocomplete="new-password" placeholder="<?= $es ? '留空表示不修改原 SecretKey' : '云厂商 SecretKey' ?>">
            <small class="field-help">编辑时不想更换密钥可留空；新建第三方存储必须填写。</small>
        </label>
        <label class="storage-field cloud-field">Bucket
            <input name="bucket" value="<?= e($es ? $es['bucket'] : '') ?>" placeholder="空间或桶名称，例如 bmtools-img">
            <small class="field-help">填写对象存储里的 Bucket 名称，不要填写访问域名。</small>
        </label>

        <label class="storage-field region-field">Region
            <input name="region" value="<?= e($es ? $es['region'] : '') ?>" placeholder="腾讯云例如 ap-guangzhou">
            <small class="field-help">腾讯云建议必填；阿里云通常由 Endpoint 表示地域。</small>
        </label>
        <label class="storage-field endpoint-field">Endpoint / 上传域名
            <input name="endpoint" value="<?= e($es ? $es['endpoint'] : '') ?>" placeholder="例如 oss-cn-hangzhou.aliyuncs.com">
            <small class="field-help">用于上传连接，不一定是用户访问图片的域名。</small>
        </label>
        <label class="storage-field domain-field">自定义访问域名
            <input name="domain" value="<?= e($es ? $es['domain'] : '') ?>" placeholder="例如 https://img.example.com">
            <small class="field-help">用户最终打开图片或文件的域名；七牛云必须填写已绑定到空间的访问域名。</small>
        </label>

        <label>目录前缀
            <input name="prefix" value="<?= e($es ? $es['prefix'] : '') ?>" placeholder="例如 bmtools/uploads">
            <small class="field-help">可理解为云存储里的文件夹，留空表示上传到 Bucket 根目录。</small>
        </label>
        <label class="inline-check storage-check"><input type="checkbox" name="is_default" <?= $es && $es['is_default'] ? 'checked' : '' ?>> 设为默认存储</label>
        <label class="inline-check storage-check"><input type="checkbox" name="is_public" <?= !$es || $es['is_public'] ? 'checked' : '' ?>> 公开读访问</label>

        <div class="form-actions span-3">
            <button class="btn btn-primary" type="submit" data-icon="save">保存存储源</button>
            <span class="form-help">保存后点击列表中的“真实测试”，系统会上传并删除一个极小测试文件。</span>
        </div>
    </form>
</section>

<section class="table-card glass reveal">
    <div class="section-head">
        <div>
            <p class="eyebrow">存储线路</p>
            <h2>存储源列表</h2>
        </div>
        <span class="storage-test-hint">每次修改 Key、Bucket、Endpoint 后都建议执行真实测试。</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr><th>ID</th><th>名称</th><th>类型</th><th>Bucket / 前缀</th><th>访问域名</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php if (!$storages): ?>
                <tr><td colspan="7" class="empty-table">还没有存储源，请先添加本地测试或第三方对象存储。</td></tr>
            <?php endif; ?>
            <?php foreach ($storages as $s): ?>
                <?php $meta = isset($types[$s['type']]) ? $types[$s['type']] : ['name' => $s['type'], 'icon' => 'database', 'badge' => $s['type']]; ?>
                <tr>
                    <td><?= e($s['id']) ?></td>
                    <td><b><?= e($s['name']) ?></b><?php if ($s['is_default']): ?> <span class="status-pill ok">默认</span><?php endif; ?></td>
                    <td><span class="status-pill soft"><?= e($meta['badge']) ?></span></td>
                    <td><div><?= e($s['bucket'] ?: '-') ?></div><small><?= e($s['prefix'] ?: '未设置前缀') ?></small></td>
                    <td class="storage-domain-cell"><?= e($s['domain'] ?: $s['endpoint'] ?: '-') ?></td>
                    <td>
                        <span class="status-pill <?= $s['is_enabled'] ? 'ok' : 'muted' ?>"><?= $s['is_enabled'] ? '启用' : '停用' ?></span>
                        <span class="status-pill <?= $s['is_public'] ? 'soft' : 'muted' ?>"><?= $s['is_public'] ? '公开读' : '私有' ?></span>
                    </td>
                    <td class="table-actions storage-actions">
                        <a class="btn btn-ghost" href="<?= url('admin/storages?id=' . $s['id']) ?>" data-icon="pencil">编辑</a>
                        <button class="btn btn-ghost storage-test-btn" data-id="<?= e($s['id']) ?>" data-token="<?= e(csrf_token()) ?>" type="button" data-icon="plug-zap">真实测试</button>
                        <?php if (!$s['is_default']): ?>
                            <form method="post" action="<?= url('admin/storages/default') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                                <button class="btn btn-ghost" data-icon="check">设为默认</button>
                            </form>
                        <?php endif; ?>
                        <form method="post" action="<?= url('admin/storages/delete') ?>" class="confirm-form" data-confirm="确定删除该存储源吗？已有文件记录的存储源不能删除。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="btn btn-ghost danger" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
                <tr class="storage-test-result-row" id="storage-test-result-<?= e($s['id']) ?>">
                    <td colspan="7"><div class="storage-test-result muted">尚未执行本次页面测试。</div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<div class="storage-guide-modal" id="storageGuideModal" aria-hidden="true">
    <div class="storage-guide-backdrop" data-close-storage-guide></div>
    <section class="storage-guide-dialog glass" role="dialog" aria-modal="true" aria-labelledby="storageGuideTitle">
        <button type="button" class="icon-btn storage-guide-close" data-close-storage-guide data-icon="x" aria-label="关闭"></button>
        <div class="storage-guide-dialog-head">
            <span data-lucide="info"></span>
            <div>
                <p class="eyebrow">填写说明</p>
                <h2 id="storageGuideTitle">对象存储填写说明</h2>
            </div>
        </div>
        <div class="storage-guide-dialog-body" id="storageGuideBody"></div>
    </section>
</div>

<script>
window.BM_STORAGE_GUIDES = <?= json_encode($guides, JSON_UNESCAPED_UNICODE) ?>;
(function () {
    var modal = document.getElementById('storageGuideModal');
    var title = document.getElementById('storageGuideTitle');
    var body = document.getElementById('storageGuideBody');
    var guides = window.BM_STORAGE_GUIDES || {};

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[char];
        });
    }

    function openGuide(key) {
        var guide = guides[key];
        if (!guide || !modal) return;
        title.textContent = guide.title;
        body.innerHTML = '<div class="storage-guide-lines">' + guide.items.map(function (item) {
            return '<p><b>' + escapeHtml(item[0]) + '</b><span>' + escapeHtml(item[1]) + '</span></p>';
        }).join('') + '</div>';
        modal.classList.add('open');
        modal.setAttribute('aria-hidden', 'false');
        if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 2 } });
    }

    function closeGuide() {
        if (!modal) return;
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden', 'true');
    }

    document.querySelectorAll('.storage-guide-open').forEach(function (button) {
        button.addEventListener('click', function () {
            openGuide(button.getAttribute('data-guide'));
        });
    });
    document.querySelectorAll('[data-close-storage-guide]').forEach(function (button) {
        button.addEventListener('click', closeGuide);
    });
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeGuide();
    });

    function refreshStorageFields() {
        var type = document.getElementById('storageType');
        if (!type) return;
        var value = type.value || 'local';
        document.querySelectorAll('.cloud-field,.region-field,.endpoint-field,.domain-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', value === 'local');
        });
        document.querySelectorAll('.region-field').forEach(function (el) {
            el.classList.toggle('soft-hidden', value === 'local' || value === 'kodo');
        });
    }
    var typeSelect = document.getElementById('storageType');
    if (typeSelect) {
        typeSelect.addEventListener('change', refreshStorageFields);
        refreshStorageFields();
    }
})();
</script>
