<?php
$maintenanceOn = isset($settings['site_maintenance']) && (string) $settings['site_maintenance'] === '1';
$message = isset($settings['maintenance_message']) ? $settings['maintenance_message'] : '系统正在维护升级，请稍后再访问。';
?>

<section class="admin-page-head maintenance-head glass">
    <div>
        <p class="eyebrow">System Maintenance</p>
        <h1>系统维护中心</h1>
        <p>用于正规售后维护和站点运营排查。所有操作都需要管理员登录，并会写入管理员日志。</p>
    </div>
    <span class="status-pill <?= $maintenanceOn ? 'bad' : 'ok' ?>"><?= $maintenanceOn ? '维护中' : '正常运行' ?></span>
</section>

<section class="maintenance-grid">
    <article class="form-section glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Maintenance Mode</p>
                <h2>维护模式</h2>
            </div>
        </div>
        <form method="post" action="<?= url('admin/maintenance') ?>" class="maintenance-form">
            <?= csrf_field() ?>
            <label class="inline-check maintenance-switch">
                <input type="checkbox" name="site_maintenance" value="1" <?= $maintenanceOn ? 'checked' : '' ?>>
                <span>开启前台维护模式</span>
            </label>
            <label>维护提示文案
                <textarea name="maintenance_message" rows="4" placeholder="例如：系统正在维护升级，请稍后再访问。"><?= e($message) ?></textarea>
            </label>
            <div class="form-actions">
                <button class="btn btn-primary" type="submit" data-icon="save">保存维护设置</button>
            </div>
        </form>
    </article>

    <article class="form-section glass">
        <div class="section-head compact">
            <div>
                <p class="eyebrow">Database Backup</p>
                <h2>数据库备份</h2>
            </div>
        </div>
        <p class="muted-text">导出当前项目表前缀下的完整 SQL 备份文件。建议在升级、迁移、批量维护前先导出备份。</p>
        <form method="post" action="<?= url('admin/maintenance/export-db') ?>" class="confirm-form" data-confirm="确定导出数据库备份吗？文件会通过浏览器下载。">
            <?= csrf_field() ?>
            <button class="btn btn-primary" type="submit" data-icon="download">导出数据库 SQL</button>
        </form>
    </article>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Environment</p>
            <h2>环境检查</h2>
        </div>
        <span class="status-pill soft">MySQL <?= e($databaseVersion) ?></span>
    </div>
    <div class="maintenance-check-grid">
        <?php foreach ($checks as $check): ?>
            <article class="<?= $check['ok'] ? 'ok' : 'bad' ?>">
                <b><?= e($check['name']) ?></b>
                <span><?= e($check['value']) ?></span>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="table-card glass">
    <div class="section-head">
        <div>
            <p class="eyebrow">Local Server</p>
            <h2>本机环境信息</h2>
        </div>
    </div>
    <div class="meta-table">
        <span>操作系统</span><b><?= e($serverInfo['os']) ?></b>
        <span>PHP 版本</span><b><?= e($serverInfo['php_version']) ?></b>
        <span>Web 服务</span><b><?= e($serverInfo['server_software']) ?></b>
        <span>数据库版本</span><b><?= e($serverInfo['database_version']) ?></b>
        <span>内存限制</span><b><?= e($serverInfo['memory_limit']) ?></b>
        <span>上传限制</span><b><?= e($serverInfo['upload_max_filesize']) ?> / POST <?= e($serverInfo['post_max_size']) ?></b>
        <span>执行时间</span><b><?= e($serverInfo['max_execution_time']) ?></b>
        <span>磁盘空间</span><b>已用 <?= e($serverInfo['disk_used']) ?>，剩余 <?= e($serverInfo['disk_free']) ?></b>
        <span>检查时间</span><b><?= e($serverInfo['time']) ?></b>
    </div>
</section>
