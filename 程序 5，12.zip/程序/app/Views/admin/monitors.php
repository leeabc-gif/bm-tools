<?php
$edit = null;
if (!empty($_GET['id'])) {
    foreach ($servers as $item) {
        if ((int) $item['id'] === (int) $_GET['id']) {
            $edit = $item;
            break;
        }
    }
}
$threshold = ['cpu' => 90, 'memory' => 90, 'disk' => 90];
if ($edit && !empty($edit['threshold_config'])) {
    $decoded = json_decode($edit['threshold_config'], true);
    if (is_array($decoded)) {
        $threshold = array_merge($threshold, $decoded);
    }
}
$monitorStats = ['total' => 0, 'online' => 0, 'offline' => 0, 'unknown' => 0, 'bt' => 0, 'ssh' => 0, 'agent' => 0];
foreach ($servers as $item) {
    $monitorStats['total']++;
    $status = isset($item['status']) && isset($monitorStats[$item['status']]) ? $item['status'] : 'unknown';
    $monitorStats[$status]++;
    $type = isset($item['monitor_type']) && isset($monitorStats[$item['monitor_type']]) ? $item['monitor_type'] : 'bt';
    $monitorStats[$type]++;
}
?>

<section class="ops-metric-grid">
    <article class="ops-metric-card glass"><span>服务器总数</span><b><?= e($monitorStats['total']) ?></b><small>已接入运营节点</small></article>
    <article class="ops-metric-card glass ok"><span>在线</span><b><?= e($monitorStats['online']) ?></b><small>最近采集正常</small></article>
    <article class="ops-metric-card glass bad"><span>异常</span><b><?= e($monitorStats['offline']) ?></b><small>需要排查连接</small></article>
    <article class="ops-metric-card glass"><span>探针接入</span><b><?= e($monitorStats['agent']) ?></b><small>免 SSH 依赖</small></article>
</section>

<section class="form-section glass">
    <div class="section-heading compact">
        <p class="eyebrow">运营监控</p>
        <h2><?= $edit ? '编辑运营服务器' : '新增运营服务器' ?></h2>
        <p>这里维护平台运营者的服务器状态，前台只展示公开健康状态，不展示宝塔 API 密钥。</p>
    </div>
    <form method="post" action="<?= url('admin/monitors/save') ?>" class="form-grid three monitor-create-form">
        <?= csrf_field() ?>
        <?php if ($edit): ?><input type="hidden" name="id" value="<?= e($edit['id']) ?>"><?php endif; ?>
        <label>监控方式<select name="monitor_type" data-monitor-type>
            <option value="bt" <?= !$edit || (isset($edit['monitor_type']) ? $edit['monitor_type'] : 'bt') === 'bt' ? 'selected' : '' ?>>宝塔 API</option>
            <option value="ssh" <?= $edit && (isset($edit['monitor_type']) ? $edit['monitor_type'] : 'bt') === 'ssh' ? 'selected' : '' ?>>SSH 直连</option>
            <option value="agent" <?= $edit && (isset($edit['monitor_type']) ? $edit['monitor_type'] : 'bt') === 'agent' ? 'selected' : '' ?>>HTTP 探针（免 SSH 依赖）</option>
        </select></label>
        <label>服务器名称<input name="name" value="<?= e($edit ? $edit['name'] : '') ?>" required></label>
        <label>分组名称<input name="group_name" value="<?= e($edit ? $edit['group_name'] : '平台节点') ?>"></label>
        <label>服务器 IP<input name="server_ip" value="<?= e($edit ? $edit['server_ip'] : '') ?>"></label>
        <label data-bt-field>宝塔面板地址<input name="panel_url" placeholder="https://1.2.3.4:8888" value="<?= e($edit ? $edit['panel_url'] : '') ?>"></label>
        <label data-bt-field>宝塔 API 密钥<input name="api_key" value="<?= e($edit ? $edit['api_key'] : '') ?>"></label>
        <label data-bt-field>面板端口<input type="number" name="panel_port" value="<?= e($edit ? $edit['panel_port'] : '8888') ?>"></label>
        <label data-ssh-field>SSH 主机/IP<input name="ssh_host" placeholder="1.2.3.4" value="<?= e($edit && isset($edit['ssh_host']) ? $edit['ssh_host'] : '') ?>"></label>
        <label data-ssh-field>SSH 端口<input type="number" name="ssh_port" value="<?= e($edit && isset($edit['ssh_port']) ? $edit['ssh_port'] : '22') ?>"></label>
        <label data-ssh-field>SSH 用户名<input name="ssh_username" placeholder="root 或监控专用用户" value="<?= e($edit && isset($edit['ssh_username']) ? $edit['ssh_username'] : '') ?>"></label>
        <label data-ssh-field>认证方式<select name="ssh_auth_type">
            <option value="password" <?= !$edit || (isset($edit['ssh_auth_type']) ? $edit['ssh_auth_type'] : 'password') === 'password' ? 'selected' : '' ?>>密码</option>
            <option value="key" <?= $edit && (isset($edit['ssh_auth_type']) ? $edit['ssh_auth_type'] : 'password') === 'key' ? 'selected' : '' ?>>私钥</option>
        </select></label>
        <label data-ssh-field>SSH 密码<input type="password" name="ssh_password" placeholder="<?= $edit ? '留空表示不修改' : '请输入 SSH 密码' ?>"></label>
        <label class="span-all" data-ssh-field>SSH 私钥<textarea name="ssh_private_key" placeholder="<?= $edit ? '留空表示不修改，支持 RSA/OPENSSH 私钥' : '使用私钥登录时填写' ?>"></textarea></label>
        <label data-ssh-field>私钥口令<input type="password" name="ssh_key_passphrase" placeholder="<?= $edit ? '留空表示不修改' : '无口令可留空' ?>"></label>
        <label class="span-all" data-agent-field>HTTP 探针地址<input name="agent_url" placeholder="https://server.com/monitor-agent.php" value="<?= e($edit && isset($edit['agent_url']) ? $edit['agent_url'] : '') ?>"></label>
        <label data-agent-field>探针 Token<span class="input-action"><input name="agent_token" placeholder="和探针文件中的 Token 保持一致" value="<?= e($edit && isset($edit['agent_token']) ? $edit['agent_token'] : '') ?>"><button class="btn btn-ghost" type="button" data-generate-agent-token data-icon="key-round">生成</button></span></label>
        <div class="span-all install-tip" data-agent-field>
            <b>免安装 SSH 客户端方案</b>
            <span>把 public/monitor-agent.php 上传到被监控服务器，修改文件顶部 Token，然后在这里填写探针 URL 和 Token。主站无需安装 phpseclib 或 ssh2 扩展。</span>
        </div>
        <div class="span-all agent-helper" data-agent-field>
            <div class="agent-helper-head">
                <div>
                    <b>HTTP 探针部署助手</b>
                    <span>给运营人员准备的最短接入流程，复制后按步骤在被监控服务器执行。</span>
                </div>
                <button class="btn btn-ghost" type="button" data-copy-agent-guide data-icon="copy">复制部署说明</button>
            </div>
            <div class="agent-helper-grid">
                <div>
                    <span>1. 上传探针文件</span>
                    <code>public/monitor-agent.php</code>
                </div>
                <div>
                    <span>2. 修改探针 Token</span>
                    <code data-agent-token-preview><?= e($edit && isset($edit['agent_token']) && $edit['agent_token'] ? $edit['agent_token'] : '点击生成 Token') ?></code>
                </div>
                <div>
                    <span>3. 测试访问地址</span>
                    <code data-agent-test-url><?= e($edit && !empty($edit['agent_url']) && !empty($edit['agent_token']) ? $edit['agent_url'] . '?token=' . $edit['agent_token'] : '填写探针地址和 Token 后自动生成') ?></code>
                </div>
            </div>
            <textarea class="agent-guide-source" readonly data-agent-guide-source>HTTP 探针部署：
1. 将 BM TOOLS 项目 public/monitor-agent.php 上传到被监控服务器网站目录。
2. 打开 monitor-agent.php，把 $token = 'CHANGE_THIS_TOKEN'; 改成后台生成的 Token。
3. 在浏览器访问：{AGENT_TEST_URL}
4. 返回 JSON 且 success=true 后，回到后台点击“测试连接”。
</textarea>
        </div>
        <label>监控频率（秒）<input type="number" name="frequency" value="<?= e($edit ? $edit['frequency'] : '60') ?>"></label>
        <label>CPU 告警阈值 %<input type="number" name="cpu_threshold" value="<?= e($threshold['cpu']) ?>"></label>
        <label>内存告警阈值 %<input type="number" name="memory_threshold" value="<?= e($threshold['memory']) ?>"></label>
        <label>磁盘告警阈值 %<input type="number" name="disk_threshold" value="<?= e($threshold['disk']) ?>"></label>
        <label>备注<input name="remark" value="<?= e($edit ? $edit['remark'] : '') ?>"></label>
        <label class="inline-check"><input type="checkbox" name="is_enabled" <?= !$edit || $edit['is_enabled'] ? 'checked' : '' ?>> 启用公开状态监控</label>
        <label class="inline-check"><input type="checkbox" name="test_after_save" checked> 保存后立即测试采集</label>
        <div class="span-all card-actions">
            <button class="btn btn-primary" type="submit" data-icon="save">保存服务器</button>
            <button class="btn btn-ghost monitor-test-btn" type="button" data-token="<?= e(csrf_token()) ?>" data-icon="plug-zap">测试连接</button>
            <a class="btn btn-ghost" href="<?= url('status') ?>" target="_blank" data-icon="external-link">查看前台状态页</a>
        </div>
    </form>
</section>

<script>
(function () {
    function syncMonitorFields() {
        var type = document.querySelector('[data-monitor-type]');
        if (!type) return;
        var isSsh = type.value === 'ssh';
        var isAgent = type.value === 'agent';
        document.querySelectorAll('[data-bt-field]').forEach(function (el) { el.style.display = (!isSsh && !isAgent) ? 'grid' : 'none'; });
        document.querySelectorAll('[data-ssh-field]').forEach(function (el) { el.style.display = isSsh ? 'grid' : 'none'; });
        document.querySelectorAll('[data-agent-field]').forEach(function (el) { el.style.display = isAgent ? 'grid' : 'none'; });
        updateAgentGuide();
    }
    function agentTestUrl() {
        var url = document.querySelector('input[name="agent_url"]');
        var token = document.querySelector('input[name="agent_token"]');
        var u = url && url.value ? url.value.trim() : '';
        var t = token && token.value ? token.value.trim() : '';
        if (!u || !t) return '';
        return u + (u.indexOf('?') === -1 ? '?' : '&') + 'token=' + encodeURIComponent(t);
    }
    function updateAgentGuide() {
        var token = document.querySelector('input[name="agent_token"]');
        var preview = document.querySelector('[data-agent-token-preview]');
        var testUrl = document.querySelector('[data-agent-test-url]');
        var guide = document.querySelector('[data-agent-guide-source]');
        var tokenText = token && token.value ? token.value.trim() : '点击生成 Token';
        var urlText = agentTestUrl() || '填写探针地址和 Token 后自动生成';
        if (preview) preview.textContent = tokenText;
        if (testUrl) testUrl.textContent = urlText;
        if (guide) {
            guide.value = 'HTTP 探针部署：\n' +
                '1. 将 BM TOOLS 项目 public/monitor-agent.php 上传到被监控服务器网站目录。\n' +
                "2. 打开 monitor-agent.php，把 $token = 'CHANGE_THIS_TOKEN'; 改成：" + tokenText + '\n' +
                '3. 在浏览器访问：' + urlText + '\n' +
                '4. 返回 JSON 且 success=true 后，回到后台点击“测试连接”。';
        }
    }
    function copyText(text) {
        if (!text) return;
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () { alert('已复制'); });
            return;
        }
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        alert('已复制');
    }
    document.addEventListener('change', function (e) {
        if (e.target && e.target.matches('[data-monitor-type]')) {
            syncMonitorFields();
        }
    });
    document.addEventListener('input', function (e) {
        if (e.target && (e.target.name === 'agent_url' || e.target.name === 'agent_token')) {
            updateAgentGuide();
        }
    });
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-generate-agent-token]');
        if (btn) {
            var input = document.querySelector('input[name="agent_token"]');
            if (!input) return;
            var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
            var token = 'BM_';
            var values = new Uint32Array(24);
            if (window.crypto && window.crypto.getRandomValues) {
                window.crypto.getRandomValues(values);
                for (var i = 0; i < values.length; i++) token += chars[values[i] % chars.length];
            } else {
                for (var j = 0; j < 24; j++) token += chars[Math.floor(Math.random() * chars.length)];
            }
            input.value = token;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            return;
        }
        var copyBtn = e.target.closest('[data-copy-agent-guide]');
        if (copyBtn) {
            var guide = document.querySelector('[data-agent-guide-source]');
            copyText(guide ? guide.value : '');
        }
    });
    syncMonitorFields();
})();
</script>

<section class="table-card glass">
    <div class="section-heading compact">
        <p class="eyebrow">服务器列表</p>
        <h2>运营服务器</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>名称</th><th>方式</th><th>分组</th><th>IP</th><th>启用</th><th>状态</th><th>最近错误</th><th>检查时间</th><th>操作</th></tr></thead>
            <tbody>
            <?php foreach ($servers as $s): ?>
                <tr>
                    <td><?= e($s['id']) ?></td>
                    <td><?= e($s['name']) ?></td>
                    <td><?php $mt = isset($s['monitor_type']) ? $s['monitor_type'] : 'bt'; ?><?= e($mt === 'ssh' ? 'SSH' : ($mt === 'agent' ? 'HTTP 探针' : '宝塔 API')) ?></td>
                    <td><?= e($s['group_name']) ?></td>
                    <td><?= e($s['server_ip']) ?></td>
                    <td><?= $s['is_enabled'] ? '是' : '否' ?></td>
                    <td><span class="status-dot <?= e($s['status']) ?>"><?= e($s['status']) ?></span></td>
                    <td><?= e($s['last_error']) ?></td>
                    <td><?= e($s['last_checked_at'] ?: '等待采集') ?></td>
                    <td>
                        <a class="btn btn-ghost" href="<?= url('admin/monitors?id=' . $s['id']) ?>" data-icon="pencil">编辑</a>
                        <form method="post" action="<?= url('admin/monitors/collect') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="btn btn-primary" type="submit" data-icon="activity">立即采集</button>
                        </form>
                        <form method="post" action="<?= url('admin/monitors/toggle') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="btn btn-ghost" type="submit" data-icon="<?= $s['is_enabled'] ? 'pause-circle' : 'play-circle' ?>"><?= $s['is_enabled'] ? '暂停监控' : '启用监控' ?></button>
                        </form>
                        <form method="post" action="<?= url('admin/monitors/delete') ?>" class="confirm-form" data-confirm="确定删除该服务器及监控历史吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                            <button class="btn btn-ghost" type="submit" data-icon="trash-2">删除</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="table-card glass">
    <div class="section-heading compact">
        <p class="eyebrow">告警列表</p>
        <h2>告警列表</h2>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>服务器</th><th>等级</th><th>标题</th><th>内容</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
            <tbody>
            <?php foreach ($alerts as $a): ?>
                <tr>
                    <td><?= e($a['server_name']) ?></td>
                    <td><?= e($a['level']) ?></td>
                    <td><?= e($a['title']) ?></td>
                    <td><?= e($a['content']) ?></td>
                    <td><?= e($a['status']) ?></td>
                    <td><?= e($a['created_at']) ?></td>
                    <td>
                        <?php if ($a['status'] !== 'resolved'): ?>
                            <form method="post" action="<?= url('admin/alerts/resolve') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= e($a['id']) ?>">
                                <button class="btn btn-ghost" type="submit" data-icon="check-circle">标记解决</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
