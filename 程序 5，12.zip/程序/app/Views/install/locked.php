<section class="install-card glass reveal">
    <p class="eyebrow">Installed</p>
    <h1>系统已安装</h1>
    <p>检测到安装锁文件，安装入口已禁用，避免重复初始化数据。</p>
    <a class="btn btn-primary" href="<?= url('login') ?>">前往登录</a>
</section>

