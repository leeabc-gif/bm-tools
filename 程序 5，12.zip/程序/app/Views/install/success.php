<section class="install-card glass reveal">
    <p class="eyebrow">Success</p>
    <h1>安装完成</h1>
    <p>数据库表、初始套餐、支付配置、公告和管理员账号已创建。建议在宝塔中将运行目录设置为 `public`，并保留安装锁文件。</p>
    <a class="btn btn-primary" href="<?= url('login') ?>">进入后台登录</a>
</section>

