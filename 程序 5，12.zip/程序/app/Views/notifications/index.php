<section class="table-card glass reveal">
    <div class="section-heading"><p class="eyebrow">Notifications</p><h1>通知中心</h1></div>
    <form method="post" action="<?= url('notifications/read-all') ?>"><?= csrf_field() ?><button class="btn btn-ghost" type="submit">一键已读</button></form>
    <div class="notice-list">
        <?php foreach ($notifications as $item): ?>
            <div class="notice-item glass <?= $item['is_read'] ? 'read' : '' ?>">
                <b><?= e($item['title']) ?></b>
                <p><?= e($item['content']) ?></p>
                <span><?= e($item['created_at']) ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</section>

